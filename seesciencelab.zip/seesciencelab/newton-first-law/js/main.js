(function () {
  var N = window.Newton, D = window.NewtonDraw, f = N.f, SURF = N.SURF;
  var $ = function (id) { return document.getElementById(id); };
  var qa = function (sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); };
  var NAME = '牛顿第一定律';

  var state = {
    scene: 'ramp',
    slows: { ramp: 0.5, galileo: 1, inertia: 0.25 },
    // ① 斜面小车
    surf: 'towel', h: 0.1, all: false, graph: true, forces: true, vel: true,
    runs: [], t: 0, running: false, paused: false, recs: {},
    // ② 理想斜面
    a2: 30, fric: false, ball: null, path: null, gRun: false, marks: [],
    // ③ 惯性
    imode: 'stop', smooth: false, sim: null, iRun: false, iWait: 0
  };

  var HINTS = {
    ramp: '让小车从斜面同一高度滑下，比较它在不同表面上滑行的距离',
    galileo: '小球从左斜面滚下，看它在右斜面上能滚到多高、多远',
    inertia: '小车突然启动或突然停下，看车上的木块怎样运动'
  };
  var A2S = [60, 30, 15, 10, 0];

  var stage = $('stage'), panel = $('panel'), cv = $('view');
  var view = D.View(cv);
  function setSeg(attr, val) { qa('[data-' + attr + ']').forEach(function (b) { b.classList.toggle('on', b.dataset[attr] === String(val)); }); }

  // ---------- ① 斜面小车 ----------
  function keys() { return state.all ? N.ORDER : [state.surf]; }
  function resetRamp() {
    state.runs = keys().map(function (k) { return N.ramp(state.h, k); });
    state.t = 0; state.running = false; state.paused = false;
  }
  // 本次实验结束的时刻：无阻力时小车驶出轨道再多走一段
  function runEnd(r) { return isFinite(r.tEnd) ? r.tEnd : r.t1 + (N.TRACK + 0.35) / r.v0; }
  function rampEnd() { return Math.max.apply(null, state.runs.map(runEnd)) + 0.35; }
  function release() {
    if (state.t > 0) resetRamp();
    state.running = true; state.paused = false; syncUI();
    Analytics.track(NAME, '释放小车', state.all ? '并排' : SURF[state.surf].name);
  }
  function finishRamp() {
    state.running = false;
    state.runs.forEach(function (r) { state.recs[r.key] = { h: r.h, s: r.s, run: r }; });
    syncUI();
  }
  // 一键完成毛巾、棉布、木板三次实验
  function autoThree() {
    ['towel', 'cotton', 'wood'].forEach(function (k) { var r = N.ramp(state.h, k); state.recs[k] = { h: r.h, s: r.s, run: r }; });
    resetRamp(); syncUI();
  }
  function graphTMax() {
    var t = 0;
    N.ORDER.forEach(function (k) {
      var rc = state.recs[k], r = rc ? rc.run : null;
      if (r && isFinite(r.tEnd)) t = Math.max(t, r.tEnd);
    });
    state.runs.forEach(function (r) { t = Math.max(t, isFinite(r.tEnd) ? r.tEnd : 0, N.ramp(r.h, 'wood').tEnd); });
    return Math.ceil(t * 1.08 / 0.5) * 0.5;
  }

  // ---------- ② 理想斜面 ----------
  function mu() { return state.fric ? N.GAL.MU : 0; }
  function resetGal() {
    state.path = N.galPath(state.a2); state.ball = N.galBall(N.GAL.H); state.gRun = false; state.paused = false;
  }
  function stepGal(dt) {
    var b = state.ball;
    N.galStep(b, state.path, mu(), dt);
    if (b.turns.length && state.a2 > 0) {
      var have = state.marks.filter(function (m) { return m.a2 === state.a2; })[0];
      if (!have) state.marks.push({ a2: state.a2, s: b.turns[0] }); else have.s = b.turns[0];
    }
    if (state.path.pos(b.s).x > N.GAL.RIGHT_MAX + 0.4 || b.stopped) state.gRun = false;
  }

  // ---------- ③ 惯性 ----------
  function resetInr() { state.sim = N.inertia(state.imode, state.smooth); state.iRun = false; state.iWait = 0; state.paused = false; }
  function stepInr(dt) {
    N.inertiaStep(state.sim, dt);
    if (state.sim.done && !state.sim.going) { state.iWait += dt; if (state.iWait > 0.3) state.iRun = false; }
  }

  // ---------- 控件 ----------
  qa('[data-scene]').forEach(function (b) {
    b.addEventListener('click', function () { setScene(b.dataset.scene); Analytics.track(NAME, '场景', b.textContent); });
  });
  function setScene(sc) { state.scene = sc; state.paused = false; syncUI(); }

  qa('[data-surf]').forEach(function (b) {
    b.addEventListener('click', function () { state.surf = b.dataset.surf; state.all = false; resetRamp(); syncUI(); Analytics.track(NAME, '表面', SURF[state.surf].name); });
  });
  qa('[data-slow]').forEach(function (b) {
    b.addEventListener('click', function () { state.slows[state.scene] = parseFloat(b.dataset.slow); syncUI(); Analytics.track(NAME, '播放速度', b.textContent); });
  });
  qa('[data-a2]').forEach(function (b) {
    b.addEventListener('click', function () { state.a2 = parseFloat(b.dataset.a2); resetGal(); syncUI(); Analytics.track(NAME, '右斜面倾角', b.textContent); });
  });
  qa('[data-imode]').forEach(function (b) {
    b.addEventListener('click', function () { state.imode = b.dataset.imode; resetInr(); syncUI(); Analytics.track(NAME, '惯性', b.textContent); });
  });
  var hEl = $('h');
  hEl.addEventListener('input', function () { state.h = parseFloat(hEl.value) / 100; resetRamp(); syncUI(); });
  hEl.addEventListener('change', function () { Analytics.track(NAME, '滑块', '高度'); });
  $('all').addEventListener('change', function () { state.all = $('all').checked; resetRamp(); syncUI(); Analytics.track(NAME, '并排比较', String(state.all)); });
  $('graph').addEventListener('change', function () { state.graph = $('graph').checked; });
  $('forces').addEventListener('change', function () { state.forces = $('forces').checked; });
  $('vel').addEventListener('change', function () { state.vel = $('vel').checked; });
  $('fric').addEventListener('change', function () { state.fric = $('fric').checked; resetGal(); state.marks = []; syncUI(); Analytics.track(NAME, '摩擦', String(state.fric)); });
  $('smooth').addEventListener('change', function () { state.smooth = $('smooth').checked; resetInr(); syncUI(); Analytics.track(NAME, '光滑车面', String(state.smooth)); });

  $('releaseBtn').addEventListener('click', release);
  $('autoBtn').addEventListener('click', function () { autoThree(); Analytics.track(NAME, '一键三次', f(state.h * 100) + ' cm'); });
  $('clearBtn').addEventListener('click', function () { state.recs = {}; resetRamp(); syncUI(); });
  $('galBtn').addEventListener('click', function () {
    if (state.ball.s !== N.galBall(N.GAL.H).s) resetGal();
    state.gRun = true; syncUI(); Analytics.track(NAME, '释放小球', state.a2 + '°');
  });
  $('galReset').addEventListener('click', function () { resetGal(); state.marks = []; syncUI(); });
  $('inrBtn').addEventListener('click', function () {
    if (state.sim.t > 0) resetInr();
    N.inertiaStart(state.sim); state.iRun = true; syncUI();
    Analytics.track(NAME, '惯性演示', (state.imode === 'start' ? '突然启动' : '突然停止') + (state.smooth ? ' 光滑' : ''));
  });
  $('inrReset').addEventListener('click', function () { resetInr(); syncUI(); });
  function running() { return state.scene === 'ramp' ? state.running : state.scene === 'galileo' ? state.gRun : state.iRun; }
  function togglePause() { if (!running()) { startScene(); return; } state.paused = !state.paused; syncUI(); }
  function startScene() { if (state.scene === 'ramp') release(); else if (state.scene === 'galileo') $('galBtn').click(); else $('inrBtn').click(); }
  qa('.pause').forEach(function (b) { b.addEventListener('click', togglePause); });

  // 点画布：没在运动时开始一次
  cv.addEventListener('pointerdown', function (e) { if (e.button === 0 && !running()) startScene(); });

  // ---------- 面板 ----------
  $('panelToggle').addEventListener('click', function () { panel.classList.toggle('collapsed'); });
  if (window.matchMedia('(max-width: 760px)').matches) panel.classList.add('collapsed');
  window.addEventListener('keydown', function (e) {
    var tg = e.target.tagName;
    if (tg === 'INPUT' || tg === 'SELECT' || tg === 'BUTTON' || tg === 'TEXTAREA') return;
    if (e.code === 'Space') { e.preventDefault(); togglePause(); }
  });

  function syncUI() {
    var sc = state.scene;
    setSeg('scene', sc);
    qa('[data-for]').forEach(function (el) { el.hidden = el.dataset.for.split(' ').indexOf(sc) < 0; });
    $('hint').textContent = HINTS[sc];
    setSeg('surf', state.all ? '' : state.surf);
    setSeg('slow', state.slows[sc]);
    setSeg('a2', state.a2);
    setSeg('imode', state.imode);
    hEl.value = Math.round(state.h * 100);
    $('hOut').textContent = f(state.h * 100, 1) + ' cm';
    $('all').checked = state.all; $('graph').checked = state.graph; $('forces').checked = state.forces; $('vel').checked = state.vel;
    $('fric').checked = state.fric; $('smooth').checked = state.smooth;
    qa('.pause').forEach(function (b) { b.textContent = running() && state.paused ? '▶ 继续' : '❚❚ 暂停'; b.disabled = !running(); });
    $('releaseBtn').textContent = state.t > 0 && !state.running ? '↺ 再放一次' : '▶ 释放小车';
    $('inrBtn').textContent = state.imode === 'start' ? '▶ 突然拉动小车' : '▶ 让小车撞上障碍物';
    renderTable();
  }

  // 实验记录表
  function renderTable() {
    var hs = {}, html = '<thead><tr><th>表面</th><th>阻力</th><th>高度</th><th>滑行距离</th></tr></thead><tbody>';
    N.ORDER.forEach(function (k) {
      var r = state.recs[k];
      if (r) hs[f(r.h * 100, 1)] = 1;
      html += '<tr><td>' + SURF[k].name + '</td><td>' + SURF[k].rough + '</td><td>' + (r ? f(r.h * 100, 1) + ' cm' : '—') + '</td><td>'
        + (r ? (isFinite(r.s) ? f(r.s * 100, 1) + ' cm' : '无限远') : '—') + '</td></tr>';
    });
    $('table').innerHTML = html + '</tbody>';
    $('recWarn').hidden = Object.keys(hs).length < 2;
  }

  // ---------- 读数 ----------
  var lastText = {};
  function setText(id, s) { if (lastText[id] !== s) { lastText[id] = s; $(id).textContent = s; } }
  function rows(list) {
    for (var k = 1; k <= 5; k++) {
      var r = list[k - 1] || ['', ''];
      setText('d' + k, r[0]); setText('r' + k, r[1]);
      $('d' + k).hidden = $('r' + k).hidden = !r[0];
    }
  }
  var PHASE = { rest: '静止在斜面上', ramp: '沿斜面加速', flat: '在水平面上减速', stop: '停下' };

  function readRamp() {
    var r0 = state.runs[0], v0 = r0.v0;
    if (state.all) {
      setText('rName', '四种表面同时比较');
      setText('rKind', state.running ? (state.paused ? '暂停' : '运动中') : state.t > 0 ? '完成' : '准备释放');
      setText('rTip', '同一高度滑下，到达水平面时速度都是 ' + f(v0) + ' m/s；表面越光滑，阻力越小，速度减小得越慢，滑行得越远。');
      rows(state.runs.map(function (r) {
        var st = r.at(state.t);
        return [SURF[r.key].name, isFinite(r.s) ? '滑行 ' + f(st.d * 100, 1) + ' cm' + (st.phase === 'stop' ? '（停下）' : '') : (st.phase === 'flat' ? '速度不变，' + f(v0) + ' m/s' : '—')];
      }));
      return;
    }
    var r = r0, st = r.at(state.t), ideal = r.mu === 0;
    setText('rName', SURF[r.key].name + (ideal ? '（推理）' : ''));
    setText('rKind', ideal && st.phase === 'flat' ? '匀速直线运动' : PHASE[st.phase]);
    var tip;
    if (st.phase === 'rest') tip = '小车从斜面上同一高度由静止滑下，是为了让它到达水平面时的速度相同（控制变量）。';
    else if (st.phase === 'ramp') tip = '小车沿斜面向下加速，到达底端时速度 v = ' + f(v0) + ' m/s，只与释放高度有关。';
    else if (ideal) tip = '如果水平面绝对光滑、小车不受阻力，它的速度将不会减小，永远以 ' + f(v0) + ' m/s 做匀速直线运动。';
    else if (st.phase === 'flat') tip = '水平方向只受阻力，阻力改变了小车的运动状态，使它的速度越来越小。';
    else tip = '在' + SURF[r.key].name + '表面上滑行了 ' + f(r.s * 100, 1) + ' cm。换一种更光滑的表面再试，比较滑行距离。';
    setText('rTip', tip);
    rows([
      ['速度', 'v = ' + f(st.v) + ' m/s'],
      ['滑行距离', isFinite(r.s) || st.phase !== 'flat' ? f(st.d * 100, 1) + ' cm' + (isFinite(r.s) ? '（共 ' + f(r.s * 100, 1) + ' cm）' : '') : f(st.d * 100, 0) + ' cm，一直增加'],
      ['到达底端', 'v0 = ' + f(v0) + ' m/s（h = ' + f(r.h * 100, 1) + ' cm）'],
      ['阻力', ideal ? '为零（设想）' : SURF[r.key].rough + '，约为车重的 ' + f(r.mu) + ' 倍'],
      ['时间', 't = ' + f(state.t) + ' s']
    ]);
  }

  function readGal() {
    var b = state.ball, p = state.path, pos = p.pos(b.s), H = N.GAL.H, m = mu();
    var hr = N.reach(H, N.GAL.a1, state.a2, m), lr = N.reachLen(H, N.GAL.a1, state.a2, m);
    setText('rName', '右斜面 ' + (state.a2 > 0 ? state.a2 + '°' : '水平'));
    setText('rKind', state.gRun ? (state.paused ? '暂停' : '运动中') : b.s === N.galBall(H).s ? '准备释放' : '停止');
    var tip;
    if (state.a2 === 0) tip = m > 0 ? '有摩擦时小球在水平面上滚很远才停下；摩擦越小，滚得越远。' : '右侧变成水平面，小球永远达不到原来的高度，将以恒定速度永远运动下去。';
    else tip = m > 0 ? '有摩擦时，小球到达的高度略低于释放高度；摩擦越小，越接近原来的高度。'
      : '没有摩擦时，小球总能滚到与释放点相同的高度；右斜面越平缓，滚过的路程越长。';
    setText('rTip', tip);
    rows([
      ['释放高度', 'H = ' + f(H * 100) + ' cm'],
      ['能到达', state.a2 > 0 ? 'h = ' + f(hr * 100, 1) + ' cm' : m > 0 ? '在水平面上滚 ' + f(lr) + ' m 后停下' : '达不到，永远运动'],
      [state.a2 > 0 ? '沿右斜面' : '水平面上', state.a2 > 0 ? '滚过 ' + f(lr * 100, 1) + ' cm' : m > 0 ? '滚过 ' + f(lr, 2) + ' m' : '无限远'],
      ['速度', 'v = ' + f(Math.abs(b.v)) + ' m/s'],
      ['当前高度', f(pos.y * 100, 1) + ' cm']
    ]);
  }

  // 画面上的说明：开始前提示要看什么，开始后给出现象和解释
  function inrNote() {
    var s = state.sim, start = state.imode === 'start';
    if (s.t === 0) return { title: start ? '小车和木块原来都静止' : '小车和木块一起向右匀速运动',
      text: (start ? '猛地拉动小车，' : '小车撞上障碍物突然停下，') + '车上的木块会怎样运动？点“开始”或点画面。' };
    return { title: lastText.rName + '：木块' + lastText.r2, text: lastText.rTip };
  }

  function readInr() {
    var s = state.sim, start = state.imode === 'start';
    setText('rName', start ? '小车突然启动' : '小车突然停止');
    setText('rKind', state.smooth ? '车面光滑' : '车面粗糙');
    var tip, blk;
    if (!state.smooth) {
      blk = s.th <= 0.001 ? '直立' : s.th >= Math.PI / 2 - 0.01 ? (s.side < 0 ? '向后倒下' : '向前倒下') : (s.side < 0 ? '向后倾倒中' : '向前倾倒中');
      tip = start ? '木块底部受摩擦力随小车一起运动，上部由于惯性仍保持原来的静止状态，所以木块向后倒。'
        : '小车停下时，木块底部随车停止，上部由于惯性仍保持原来的运动状态，所以木块向前倒。';
    } else {
      blk = s.onCart ? (Math.abs(s.bv) > 0.01 ? '在车面上滑动' : '相对地面静止') : s.landed ? (Math.abs(s.bv) > 0.01 ? '在地面上滑行' : '停在地面上') : '下落';
      tip = start ? '车面光滑，木块不受水平方向的力，由于惯性保持静止（相对地面不动），小车从它下面被拉走。'
        : '车面光滑，小车停下后木块不受水平方向的力，由于惯性保持原来的速度继续向前运动，滑出小车。';
    }
    setText('rTip', tip);
    rows([
      ['小车速度', f(s.cv) + ' m/s'],
      ['木块', blk],
      [state.smooth ? '木块速度' : '倾角', state.smooth ? f(Math.abs(s.bv)) + ' m/s' : f(s.th / N.DEG, 0) + '°'],
      ['时间', 't = ' + f(s.t) + ' s']
    ]);
  }

  // ---------- 尺寸与主循环 ----------
  function resize() { view.resize(stage.clientWidth, stage.clientHeight); }
  new ResizeObserver(resize).observe(stage);

  // 支持 ?scene=ramp|galileo|inertia；斜面小车 &surf=towel|cotton|wood|ideal、&h=5~20（cm）、&all=1、&rec=1（预填三次记录）、
  // &graph=0、&forces=0；理想斜面 &a2=60|30|15|10|0、&fric=1；惯性 &mode=start|stop、&smooth=1；
  // 通用 &slow=1|0.5|0.25、&t=（秒，从开始运动到该时刻后暂停）
  var qs = new URLSearchParams(location.search);
  if (HINTS[qs.get('scene')]) state.scene = qs.get('scene');
  if (SURF[qs.get('surf')]) state.surf = qs.get('surf');
  var x = parseFloat(qs.get('h'));
  if (x >= 5 && x <= 20) state.h = Math.round(x) / 100;
  if (qs.get('all') === '1') state.all = true;
  if (qs.get('graph') === '0') state.graph = false;
  if (qs.get('forces') === '0') state.forces = false;
  x = parseFloat(qs.get('a2'));
  if (A2S.indexOf(x) >= 0) state.a2 = x;
  if (qs.get('fric') === '1') state.fric = true;
  if (qs.get('mode') === 'start' || qs.get('mode') === 'stop') state.imode = qs.get('mode');
  if (qs.get('smooth') === '1') state.smooth = true;
  x = parseFloat(qs.get('slow'));
  if ([1, 0.5, 0.25].indexOf(x) >= 0) state.slows[state.scene] = x;

  resetRamp(); resetGal(); resetInr();
  if (qs.get('rec') === '1') autoThree();
  resize();
  setScene(state.scene);
  x = parseFloat(qs.get('t'));
  if (x > 0 && x < 30) {
    if (state.scene === 'ramp') { state.running = true; state.t = Math.min(x, rampEnd()); }
    else if (state.scene === 'galileo') { state.gRun = true; for (var i = 0; i < Math.ceil(x / 0.02); i++) stepGal(0.02); }
    else { N.inertiaStart(state.sim); state.iRun = true; N.inertiaStep(state.sim, x); }
    state.paused = true; syncUI();
  }

  var lastT = performance.now(), wasRunning = null;
  function frame(now) {
    var dt = Math.min((now - lastT) / 1000, 0.1) * state.slows[state.scene];
    lastT = now;
    var sc = state.scene;
    if (!state.paused) {
      if (sc === 'ramp' && state.running) { state.t += dt; if (state.t >= rampEnd()) { state.t = rampEnd(); finishRamp(); } }
      if (sc === 'galileo' && state.gRun) stepGal(dt);
      if (sc === 'inertia' && state.iRun) stepInr(dt);
    }
    if (running() !== wasRunning) { wasRunning = running(); syncUI(); }

    if (sc === 'ramp') {
      var cur = {}, curves = [];
      state.runs.forEach(function (r) { cur[r.key] = 1; });
      N.ORDER.forEach(function (k) {
        var rc = state.recs[k];
        if (rc && !(cur[k] && (state.running || state.t > 0))) curves.push({ key: k, run: rc.run, t: runEnd(rc.run), cur: false });
      });
      state.runs.forEach(function (r) { if (state.running || state.t > 0) curves.push({ key: r.key, run: r, t: state.t, cur: true }); });
      view.drawRamp({
        lanes: state.runs.map(function (r) { return { key: r.key, run: r, t: state.t, rec: state.recs[r.key] }; }),
        h: state.h, graph: state.graph, forces: state.forces, vel: state.vel, curves: curves, tMax: graphTMax()
      });
      readRamp();
    } else if (sc === 'galileo') {
      view.drawGalileo({ a2: state.a2, mu: mu(), ball: state.ball, path: state.path, marks: state.marks, H: N.GAL.H });
      readGal();
    } else {
      readInr();
      view.drawInertia({ s: state.sim, note: inrNote() });
    }
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // 调试用
  window.__model = {
    state: state, setScene: setScene, syncUI: syncUI, release: release, autoThree: autoThree,
    setH: function (cm) { state.h = N.clamp(Math.round(cm), 5, 20) / 100; resetRamp(); syncUI(); },
    setSurf: function (k) { if (SURF[k]) { state.surf = k; state.all = false; resetRamp(); syncUI(); } },
    setA2: function (a) { state.a2 = a; resetGal(); syncUI(); }
  };
})();
