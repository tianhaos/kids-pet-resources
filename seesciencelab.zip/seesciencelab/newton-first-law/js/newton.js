// 牛顿第一定律：计算模块（不碰 DOM）
// 单位：m、s、m/s、°；世界坐标 x 右、y 上
// ① 斜面小车：斜面底端在原点，小车从斜面上高 h 处由静止滑下，斜面视为光滑（同一高度 → 到达水平面的速度相同），
//    水平面上受阻力 f = μmg 做匀减速运动，滑行距离 s = v0²/(2μg) = h/μ
// ② 伽利略理想斜面：两个斜面在底端相接，沿路程 s 积分（s < 0 在左斜面、s > 0 在右斜面），可加很小的摩擦
// ③ 惯性：小车载着木块突然启动/突然停止，木块绕底边翻倒（小车参考系中加惯性力 −ma），或在光滑车面上保持原来的运动
(function () {
  var G = 9.8, DEG = Math.PI / 180;

  // 水平面材料：μ 为等效阻力系数（含滚动阻力），取值让滑行距离接近课堂实验（h = 10 cm 时约 20、40、80 cm）
  var SURF = {
    towel:  { name: '毛巾', mu: 0.5,  color: '#c98b6b', rough: '最大' },
    cotton: { name: '棉布', mu: 0.25, color: '#9fb6d6', rough: '较大' },
    wood:   { name: '木板', mu: 0.12, color: '#c9a36b', rough: '较小' },
    ideal:  { name: '无阻力', mu: 0,  color: '#7ee081', rough: '为零（推理）' }
  };
  var ORDER = ['towel', 'cotton', 'wood', 'ideal'];
  var RAMP_DEG = 25, TRACK = 1.8, H_RANGE = [0.05, 0.2];

  function clamp(x, a, b) { return Math.max(a, Math.min(b, x)); }
  function f(x, n) { n = n == null ? 2 : n; var s = (+x).toFixed(n); return s.indexOf('.') >= 0 ? s.replace(/0+$/, '').replace(/\.$/, '') : s; }

  // ---------- ① 斜面小车 ----------
  // 返回一次实验的全部参数；at(t) 给出 t 时刻的位置和速度
  function ramp(h, key) {
    var th = RAMP_DEG * DEG, mu = SURF[key].mu;
    var L = h / Math.sin(th), a1 = G * Math.sin(th), t1 = Math.sqrt(2 * L / a1), v0 = Math.sqrt(2 * G * h);
    var dec = mu * G, tStop = mu > 0 ? v0 / dec : Infinity, s = mu > 0 ? v0 * v0 / (2 * dec) : Infinity;
    function at(t) {
      if (t <= t1) {
        var d = a1 * t * t / 2, r = L - d;   // r：离底端的斜面长度
        return { phase: t <= 0 ? 'rest' : 'ramp', x: -r * Math.cos(th), y: r * Math.sin(th), v: a1 * t, d: 0, a: a1 };
      }
      var u = t - t1;
      if (u >= tStop) return { phase: 'stop', x: s, y: 0, v: 0, d: s, a: 0 };
      var x = v0 * u - dec * u * u / 2;
      return { phase: 'flat', x: x, y: 0, v: v0 - dec * u, d: x, a: -dec };
    }
    return { h: h, key: key, mu: mu, th: th, L: L, t1: t1, v0: v0, dec: dec, tStop: tStop, s: s, tEnd: t1 + tStop, at: at };
  }

  // ---------- ② 伽利略理想斜面 ----------
  var GAL = { a1: 30, H: 0.3, TOP: 1.2, RIGHT_MAX: 2.0, MU: 0.03 };
  // 路程 s 处的位置与坡角（坡角为沿 +s 方向的上升角）
  function galPath(a2deg) {
    var a1 = GAL.a1 * DEG, a2 = a2deg * DEG, top = GAL.H * GAL.TOP;
    var sMin = -top / Math.sin(a1), sMax = a2 > 0 ? Math.min(top / Math.sin(a2), GAL.RIGHT_MAX / Math.cos(a2)) : Infinity;
    return {
      a1: a1, a2: a2, sMin: sMin, sMax: sMax,
      pos: function (s) { return s < 0 ? { x: s * Math.cos(a1), y: -s * Math.sin(a1) } : { x: s * Math.cos(a2), y: s * Math.sin(a2) }; },
      slope: function (s) { return s < 0 ? -a1 : a2; }
    };
  }
  // 无摩擦时到达右斜面的高度等于 H；有摩擦时 h2 = H(1 − μcot a1)/(1 + μcot a2)
  function reach(H, a1deg, a2deg, mu) {
    if (a2deg <= 0) return mu > 0 ? 0 : Infinity;
    var c1 = 1 / Math.tan(a1deg * DEG), c2 = 1 / Math.tan(a2deg * DEG);
    return H * (1 - mu * c1) / (1 + mu * c2);
  }
  // 右斜面上滚过的路程（沿斜面）
  function reachLen(H, a1deg, a2deg, mu) {
    if (a2deg <= 0) return mu > 0 ? H * (1 - mu / Math.tan(a1deg * DEG)) / mu : Infinity;
    return reach(H, a1deg, a2deg, mu) / Math.sin(a2deg * DEG);
  }
  // 小球状态 b = { s, v, stopped }，沿路程积分
  function galStep(b, path, mu, dt) {
    if (b.stopped) return b;
    var n = Math.max(1, Math.ceil(dt / 0.002)), h = dt / n;
    for (var i = 0; i < n; i++) {
      var phi = path.slope(b.s), acc = -G * Math.sin(phi);
      if (mu > 0) {
        var fr = mu * G * Math.cos(phi);
        if (Math.abs(b.v) < 1e-4 && Math.abs(acc) <= fr) { b.v = 0; b.stopped = true; break; }
        var dir = Math.abs(b.v) > 1e-9 ? Math.sign(b.v) : Math.sign(acc);
        var nv = b.v + (acc - dir * fr) * h;
        // 摩擦只能使速度减到零，不能使它反向
        if (b.v !== 0 && Math.sign(nv) !== Math.sign(b.v) && Math.abs(acc) <= fr) nv = 0;
        b.v = nv;
      } else b.v += acc * h;
      var ns = b.s + b.v * h;
      if (ns < path.sMin) { ns = path.sMin; b.v = 0; }
      if (ns > path.sMax) { ns = path.sMax; b.v = 0; }
      // 记录转向点（右斜面上达到的最高点）
      if (b.s > 0 && b.v <= 0 && b.vPrev > 0) b.turns.push(b.s);
      b.vPrev = b.v;
      b.s = ns;
    }
    return b;
  }
  function galBall(H) {
    return { s: -H / Math.sin(GAL.a1 * DEG), v: 0, vPrev: 0, stopped: false, turns: [] };
  }

  // ---------- ③ 惯性 ----------
  // 木块（有摩擦）：宽 w、高 hh，竖放在车面上；光滑车面：扁木块，与车面间无摩擦
  var INR = { CART: 0.36, DECK: 0.09, W: 0.045, HH: 0.14, SW: 0.1, SH: 0.05, V: 1.2, A_START: 14, A_STOP: 40,
    X0_START: 0.25, X0_STOP: -0.2, WALL: 1.45, GROUND_MU: 0.8 };
  // mode: 'start' 突然启动 | 'stop' 突然停止；smooth：车面光滑
  function inertia(mode, smooth) {
    var s = {
      mode: mode, smooth: smooth, t: 0, done: false,
      cx: mode === 'start' ? INR.X0_START : INR.X0_STOP,  // 小车中心
      cv: mode === 'start' ? 0 : INR.V, ca: 0, going: mode === 'stop',
      th: 0, om: 0, side: 0,          // 木块倾角（≥0）、角速度、翻倒方向 −1 向后 / +1 向前
      bx: 0, by: 0, bv: 0, bvy: 0, onCart: true, landed: false   // 光滑车面：木块中心（地面坐标）与速度
    };
    var w = smooth ? INR.SW : INR.W, hh = smooth ? INR.SH : INR.HH;
    s.w = w; s.hh = hh;
    s.bx = s.x0 = s.cx; s.by = INR.DECK + hh / 2; s.bv = s.cv;
    return s;
  }
  function inertiaStart(s) { s.going = true; }
  function inertiaStep(s, dt) {
    var n = Math.max(1, Math.ceil(dt / 0.001)), h = dt / n;
    for (var i = 0; i < n; i++) step1(s, h);
    return s;
  }
  function step1(s, h) {
    var a = 0;
    // 小车：启动时以很大的加速度加速到 V；撞到挡板时以更大的加速度停下
    if (s.going) {
      var front = s.cx + INR.CART / 2;
      if (front >= INR.WALL - 1e-9 && s.cv > 0) a = -INR.A_STOP;
      else if (s.mode === 'start' && s.cv < INR.V) a = INR.A_START;
      var nv = s.cv + a * h;
      if (a < 0 && nv <= 0) { nv = 0; s.going = false; s.stopT = s.t; }
      if (a > 0 && nv >= INR.V) nv = INR.V;
      s.cv = nv;
      s.cx += s.cv * h;
      if (s.cx + INR.CART / 2 > INR.WALL && a >= 0 && s.cv === 0) s.cx = INR.WALL - INR.CART / 2;
    }
    s.ca = a;
    s.t += h;
    if (s.smooth) smoothStep(s, h); else tipStep(s, a, h);
  }
  // 木块绕底边翻倒：小车参考系中受重力和惯性力 −ma，绕支点转动，I = m(w² + h²)/3
  function tipStep(s, a, h) {
    var w = s.w, hh = s.hh, crit = G * w / hh;
    if (s.th >= Math.PI / 2) return;   // 已倒在车面上，之后随小车一起运动
    if (s.side === 0) {
      if (a > crit) s.side = -1; else if (-a > crit) s.side = 1; else return;
    }
    var aeff = s.side < 0 ? a : -a, th = s.th;
    var cx = w / 2 * Math.cos(th) - hh / 2 * Math.sin(th), cy = w / 2 * Math.sin(th) + hh / 2 * Math.cos(th);
    var I = (w * w + hh * hh) / 3, tq = -G * cx + aeff * cy;
    s.om += tq / I * h;
    s.th += s.om * h;
    if (s.th <= 0) { s.th = 0; s.om = 0; s.side = 0; }
    if (s.th >= Math.PI / 2) { s.th = Math.PI / 2; s.om = 0; s.done = true; }
  }
  // 光滑车面：木块水平方向不受力，保持原来的速度；离开车面后下落，落地后受地面摩擦减速
  function smoothStep(s, h) {
    var half = INR.CART / 2;
    if (s.onCart) {
      s.bx += s.bv * h;
      if (s.bx < s.cx - half || s.bx > s.cx + half) { s.onCart = false; s.bvy = 0; }
      return;
    }
    if (!s.landed) {
      s.bvy -= G * h; s.bx += s.bv * h; s.by += s.bvy * h;
      if (s.by <= s.hh / 2) { s.by = s.hh / 2; s.landed = true; s.bvy = 0; }
      return;
    }
    if (s.bv !== 0) {
      var nv = s.bv - Math.sign(s.bv) * INR.GROUND_MU * G * h;
      s.bv = Math.sign(nv) === Math.sign(s.bv) ? nv : 0;
      s.bx += s.bv * h;
    }
    if (s.bv === 0) s.done = true;
  }

  window.Newton = {
    G: G, DEG: DEG, SURF: SURF, ORDER: ORDER, RAMP_DEG: RAMP_DEG, TRACK: TRACK, H_RANGE: H_RANGE,
    clamp: clamp, f: f, ramp: ramp,
    GAL: GAL, galPath: galPath, galStep: galStep, galBall: galBall, reach: reach, reachLen: reachLen,
    INR: INR, inertia: inertia, inertiaStart: inertiaStart, inertiaStep: inertiaStep
  };
})();
