// 2D 绘制：斜面小车（单条轨道或四种表面并排）与 v-t 图像、伽利略理想斜面、惯性（小车载木块突然启动/停止）
// 世界坐标同 Newton：x 右、y 上，单位 m；frame(R, box, ax) 把世界范围 box 等比放进屏幕矩形 R
(function () {
  var N = window.Newton, f = N.f, SURF = N.SURF, DEG = N.DEG;
  var MUTED = '#8d99ab', TEXT = '#e6ebf2', GRID = 'rgba(141,153,171,.14)', LINE = '#4a5670';
  var CAR = '#ffc94a', VEL = '#4fc3f7', FRIC = '#ff7a59', GRAV = '#c9a7ff', NORM = '#7ee081';
  var FONT = '-apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", sans-serif';

  function font(px, w) { return (w ? w + ' ' : '') + px + 'px ' + FONT; }
  function label(ctx, s, x, y, o) {
    o = o || {};
    ctx.font = font(o.size || 12, o.bold ? 600 : null);
    ctx.textAlign = o.align || 'center'; ctx.textBaseline = o.base || 'middle';
    ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(5,7,13,.85)'; ctx.strokeText(s, x, y);
    ctx.fillStyle = o.color || TEXT; ctx.fillText(s, x, y);
  }
  function arrow(ctx, x1, y1, x2, y2, color, o) {
    o = o || {};
    var a = Math.atan2(y2 - y1, x2 - x1), len = Math.hypot(x2 - x1, y2 - y1), size = Math.min(o.size || 9, len * 0.6);
    if (len < 2) return;
    ctx.strokeStyle = ctx.fillStyle = color; ctx.lineWidth = o.width || 2.2; ctx.setLineDash(o.dash || []);
    ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2 - Math.cos(a) * size * 0.6, y2 - Math.sin(a) * size * 0.6); ctx.stroke();
    ctx.setLineDash([]);
    ctx.beginPath();
    ctx.moveTo(x2, y2);
    ctx.lineTo(x2 - size * Math.cos(a - 0.42), y2 - size * Math.sin(a - 0.42));
    ctx.lineTo(x2 - size * Math.cos(a + 0.42), y2 - size * Math.sin(a + 0.42));
    ctx.closePath(); ctx.fill();
  }
  function line(ctx, a, b, color, o) {
    o = o || {};
    ctx.strokeStyle = color; ctx.lineWidth = o.width || 1.2; ctx.setLineDash(o.dash || []);
    ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke(); ctx.setLineDash([]);
  }
  function poly(ctx, pts, fill, stroke) {
    ctx.beginPath(); pts.forEach(function (p, i) { if (i) ctx.lineTo(p.x, p.y); else ctx.moveTo(p.x, p.y); }); ctx.closePath();
    if (fill) { ctx.fillStyle = fill; ctx.fill(); }
    if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = 1.5; ctx.setLineDash([]); ctx.stroke(); }
  }

  function frame(R, box, ax) {
    var k = Math.min(R.w / (box.x1 - box.x0), R.h / (box.y1 - box.y0)), slack = R.w - (box.x1 - box.x0) * k;
    var cx = R.x + R.w / 2 + (ax == null ? 0 : (ax - 0.5) * slack), cy = R.y + R.h / 2, mx = (box.x0 + box.x1) / 2, my = (box.y0 + box.y1) / 2;
    return {
      k: k, R: R,
      p: function (x, y) { return { x: cx + (x - mx) * k, y: cy - (y - my) * k }; },
      view: { x0: mx - R.w / 2 / k, x1: mx + R.w / 2 / k }
    };
  }

  // 小车：p 为车底中点（屏幕），ang 为所在表面的坡角（世界角，向右上为正），L 为车长（像素）
  function car(ctx, p, ang, L, o) {
    o = o || {};
    var r = L * 0.13, bh = L * 0.3;
    ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(-ang);
    ctx.globalAlpha = o.alpha == null ? 1 : o.alpha;
    ctx.fillStyle = o.color || CAR; ctx.strokeStyle = '#7a5a12'; ctx.lineWidth = 1.2;
    ctx.beginPath(); ctx.roundRect(-L / 2, -2 * r - bh, L, bh, 3); ctx.fill(); ctx.stroke();
    ctx.fillStyle = 'rgba(0,0,0,.25)'; ctx.fillRect(-L / 2 + 3, -2 * r - bh + 3, L - 6, bh * 0.28);
    [-L * 0.3, L * 0.3].forEach(function (x) {
      ctx.fillStyle = '#2a2f3a'; ctx.beginPath(); ctx.arc(x, -r, r, 0, 7); ctx.fill();
      ctx.fillStyle = '#9aa4b5'; ctx.beginPath(); ctx.arc(x, -r, r * 0.4, 0, 7); ctx.fill();
    });
    ctx.restore(); ctx.globalAlpha = 1;
  }

  // 水平面材料的纹理：屏幕矩形 x0..x1、表面 y、厚度 d
  function surface(ctx, key, x0, x1, y, d) {
    var c = SURF[key].color, i;
    ctx.save(); ctx.beginPath(); ctx.rect(x0, y, x1 - x0, d); ctx.clip();
    if (key === 'ideal') {
      var g = ctx.createLinearGradient(0, y, 0, y + d);
      g.addColorStop(0, 'rgba(126,224,129,.55)'); g.addColorStop(1, 'rgba(126,224,129,.08)');
      ctx.fillStyle = g; ctx.fillRect(x0, y, x1 - x0, d);
    } else {
      ctx.fillStyle = c; ctx.globalAlpha = 0.55; ctx.fillRect(x0, y, x1 - x0, d); ctx.globalAlpha = 1;
      ctx.strokeStyle = 'rgba(5,7,13,.45)'; ctx.lineWidth = 1;
      ctx.beginPath();
      if (key === 'towel') for (i = x0; i < x1; i += 5) { ctx.moveTo(i + 2.5, y + 2); ctx.arc(i + 2.5, y + 2, 2, 0, Math.PI); }
      else if (key === 'cotton') for (i = x0 - d; i < x1; i += 4) { ctx.moveTo(i, y + d); ctx.lineTo(i + d, y); }
      else for (i = 0; i < 3; i++) { ctx.moveTo(x0, y + d * (0.25 + i * 0.25)); ctx.lineTo(x1, y + d * (0.25 + i * 0.25) + (i - 1) * 1.5); }
      ctx.stroke();
    }
    ctx.restore();
    ctx.strokeStyle = key === 'ideal' ? '#7ee081' : c; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(x0, y); ctx.lineTo(x1, y); ctx.stroke();
  }

  function flag(ctx, p, color, text, hgt) {
    line(ctx, p, { x: p.x, y: p.y - hgt }, color, { width: 1.6 });
    ctx.fillStyle = color; ctx.beginPath(); ctx.moveTo(p.x, p.y - hgt); ctx.lineTo(p.x + 10, p.y - hgt + 4); ctx.lineTo(p.x, p.y - hgt + 8); ctx.fill();
    if (text) label(ctx, text, p.x, p.y - hgt - 9, { size: 11, color: color, bold: true });
  }

  function View(canvas) {
    var ctx = canvas.getContext('2d'), W = 0, H = 0, dpr = 1, narrow = false;
    function resize(w, h) {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      W = w; H = h; narrow = w < 640;
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
      canvas.style.width = w + 'px'; canvas.style.height = h + 'px';
    }
    function bg() {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      var g = ctx.createLinearGradient(0, 0, 0, H);
      g.addColorStop(0, '#04060c'); g.addColorStop(1, '#0a1120');
      ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    }
    function area() {
      var t0 = narrow ? 84 : 44, bottom = narrow ? 44 : 46;
      return { x: 14, y: t0, w: W - 28, h: Math.max(160, H - t0 - bottom) };
    }

    // ---------- ① 斜面小车 ----------
    var RAMP_TOP = 0.22;
    // 一条轨道：lane = { key, run, t, rec }，rec 为这种表面已记录的结果
    function lane(fr, ln, o) {
      var th = N.RAMP_DEG * DEG, k = fr.k, xTop = -RAMP_TOP / Math.tan(th);
      var A = fr.p(xTop, RAMP_TOP), B = fr.p(0, 0), C = fr.p(xTop, 0), E = fr.p(N.TRACK, 0), d = Math.max(6, Math.min(12, k * 0.025));
      // 斜面（同一个斜面，表面光滑）
      poly(ctx, [A, B, { x: B.x, y: B.y + d }, { x: C.x, y: C.y + d }], 'rgba(111,134,201,.28)', '#6f86c9');
      surface(ctx, ln.key, B.x, E.x, B.y, d);
      // 刻度尺（cm）
      var every = 0.1 * k < 26 ? 2 : 1;
      for (var i = 0; i * 0.1 <= N.TRACK + 1e-9; i++) {
        var q = fr.p(i * 0.1, 0);
        line(ctx, { x: q.x, y: q.y + d }, { x: q.x, y: q.y + d + (i % every ? 2 : 4) }, MUTED);
        if (i % every === 0) label(ctx, String(i * 10), q.x, q.y + d + 12, { size: 10, color: MUTED });
      }
      if (!o.compact) label(ctx, 'cm', E.x + 26, E.y + d + 12, { size: 10, color: MUTED });
      // 释放点
      var rp = fr.p(-o.h / Math.tan(th), o.h);
      line(ctx, { x: C.x, y: rp.y }, { x: rp.x, y: rp.y }, MUTED, { dash: [3, 3] });
      arrow(ctx, C.x + 5, C.y - 1, C.x + 5, rp.y, MUTED, { width: 1, size: 5 });
      arrow(ctx, C.x + 5, rp.y, C.x + 5, C.y - 1, MUTED, { width: 1, size: 5 });
      if (C.y - rp.y > 14) label(ctx, 'h = ' + f(o.h * 100, 1) + ' cm', C.x + 9, (C.y + rp.y) / 2, { size: 11, color: TEXT, align: 'left' });
      else label(ctx, 'h = ' + f(o.h * 100, 1) + ' cm', C.x + 9, rp.y - 8, { size: 11, color: TEXT, align: 'left' });
      // 名称
      var nm = SURF[ln.key].name + (ln.key === 'ideal' ? '（推理）' : '');
      label(ctx, nm, E.x - 2, B.y - (o.compact ? 26 : 40), { size: o.compact ? 12 : 13, bold: true, color: ln.key === 'ideal' ? '#7ee081' : SURF[ln.key].color, align: 'right' });
      // 以前记录的停止位置
      var st = ln.run.at(ln.t);
      if (ln.rec && isFinite(ln.rec.s) && st.phase !== 'stop') flag(ctx, fr.p(ln.rec.s, 0), SURF[ln.key].color, '上次 ' + f(ln.rec.s * 100, 1) + ' cm', o.compact ? 18 : 26);
      // 小车
      var L = Math.max(26, Math.min(64, k * 0.1)), onRamp = st.phase === 'rest' || st.phase === 'ramp';
      if (st.x > fr.view.x1 + 0.05) {
        // 无阻力：小车驶出画面，一直运动下去
        var ex = fr.R.x + fr.R.w - 4;
        arrow(ctx, ex - 64, B.y - L * 0.3, ex, B.y - L * 0.3, '#7ee081', { width: 2.6 });
        label(ctx, '永远运动下去', ex - 34, B.y - L * 0.3 - 14, { size: 12, color: '#7ee081', bold: true });
      } else {
        var cp = fr.p(st.x, st.y);
        car(ctx, cp, onRamp ? -th : 0, L);
        var top = cp.y - L * 0.6;
        if (st.v > 0.01 && o.vel) arrow(ctx, cp.x, top - 6, cp.x + st.v * L * 0.75, top - 6, VEL, { width: 2.4 });
        if (o.forces && st.phase === 'flat') {
          var G0 = L * 0.55;
          if (!o.compact) {
            arrow(ctx, cp.x, cp.y - L * 0.25, cp.x, cp.y - L * 0.25 + G0, GRAV, { width: 2 });
            arrow(ctx, cp.x + 2, cp.y - L * 0.25, cp.x + 2, cp.y - L * 0.25 - G0, NORM, { width: 2 });
          }
          if (ln.run.mu > 0) arrow(ctx, cp.x - L * 0.5, cp.y - 1, cp.x - L * 0.5 - G0 * ln.run.mu * 2.4, cp.y - 1, FRIC, { width: 2.4 });
          if (!o.compact) {
            label(ctx, 'G', cp.x + 10, cp.y - L * 0.25 + G0, { size: 11, color: GRAV, bold: true });
            label(ctx, 'F支', cp.x + 16, cp.y - L * 0.25 - G0 + 4, { size: 11, color: NORM, bold: true });
            if (ln.run.mu > 0) label(ctx, 'f 阻', cp.x - L * 0.5 - G0 * ln.run.mu * 2.4 - 14, cp.y - 10, { size: 11, color: FRIC, bold: true });
            else label(ctx, '不受阻力', cp.x - L * 0.5 - 30, cp.y - 10, { size: 11, color: FRIC });
          }
        }
        if (st.phase === 'stop') flag(ctx, fr.p(st.x, 0), SURF[ln.key].color, '停下 s = ' + f(st.d * 100, 1) + ' cm', o.compact ? 18 : 26);
      }
    }

    // v-t 图像：curves = [{ key, run, t, cur }]
    function vtGraph(R, curves, o) {
      ctx.fillStyle = 'rgba(17,23,35,.6)'; ctx.fillRect(R.x, R.y, R.w, R.h);
      ctx.strokeStyle = 'rgba(42,52,70,.9)'; ctx.lineWidth = 1; ctx.strokeRect(R.x + 0.5, R.y + 0.5, R.w - 1, R.h - 1);
      var P = { x: R.x + 42, y: R.y + 22, w: R.w - 60, h: R.h - 50 };
      var vMax = Math.ceil(Math.sqrt(2 * N.G * N.H_RANGE[1]) * 2) / 2, tMax = o.tMax;
      var X = function (t) { return P.x + t / tMax * P.w; }, Y = function (v) { return P.y + P.h - v / vMax * P.h; };
      ctx.strokeStyle = GRID; ctx.lineWidth = 1; ctx.beginPath();
      var ts = tMax > 2 ? 0.5 : 0.25, i;
      for (i = 0; i * ts <= tMax + 1e-9; i++) { ctx.moveTo(X(i * ts), P.y); ctx.lineTo(X(i * ts), P.y + P.h); label(ctx, f(i * ts), X(i * ts), P.y + P.h + 11, { size: 10, color: MUTED }); }
      for (i = 0; i * 0.5 <= vMax + 1e-9; i++) { ctx.moveTo(P.x, Y(i * 0.5)); ctx.lineTo(P.x + P.w, Y(i * 0.5)); label(ctx, f(i * 0.5, 1), P.x - 6, Y(i * 0.5), { size: 10, color: MUTED, align: 'right' }); }
      ctx.stroke();
      arrow(ctx, P.x, P.y + P.h, P.x + P.w + 12, P.y + P.h, MUTED, { width: 1.2, size: 7 });
      arrow(ctx, P.x, P.y + P.h, P.x, P.y - 12, MUTED, { width: 1.2, size: 7 });
      label(ctx, 't / s', P.x + P.w + 4, P.y + P.h - 10, { size: 11, color: MUTED, align: 'right' });
      label(ctx, 'v / (m·s⁻¹)', P.x + 6, R.y + 10, { size: 11, color: MUTED, align: 'left' });
      label(ctx, '速度—时间图像（从释放小车开始计时）', P.x + P.w, R.y + 11, { size: 11, color: MUTED, align: 'right' });
      ctx.save(); ctx.beginPath(); ctx.rect(P.x, P.y - 4, P.w + 2, P.h + 6); ctx.clip();
      curves.forEach(function (c) {
        var r = c.run, t1 = Math.min(c.t, tMax), col = c.key === 'ideal' ? '#7ee081' : SURF[c.key].color;
        ctx.strokeStyle = col; ctx.lineWidth = c.cur ? 2.6 : 1.8; ctx.globalAlpha = c.cur ? 1 : 0.75;
        ctx.setLineDash(c.key === 'ideal' ? [6, 5] : []);
        ctx.beginPath();
        for (var j = 0; j <= 160; j++) { var t = t1 * j / 160, v = r.at(t).v; if (j) ctx.lineTo(X(t), Y(v)); else ctx.moveTo(X(t), Y(v)); }
        ctx.stroke(); ctx.setLineDash([]); ctx.globalAlpha = 1;
        if (c.cur) { ctx.fillStyle = col; ctx.beginPath(); ctx.arc(X(t1), Y(r.at(t1).v), 4, 0, 7); ctx.fill(); }
        if (c.t > r.t1 + 0.05 && !c.cur) {
          var tl = Math.min(r.t1 + (isFinite(r.tStop) ? r.tStop * 0.45 : tMax), tMax * 0.92);
          label(ctx, SURF[c.key].name, X(tl) + 4, Y(r.at(tl).v) - 10, { size: 11, color: col, bold: true, align: 'left' });
        }
      });
      ctx.restore();
    }

    // o: { lanes: [...], h, graph, forces, vel, curves, tMax }
    function drawRamp(o) {
      bg();
      var R = area(), n = o.lanes.length, compact = n > 1;
      var th = N.RAMP_DEG * DEG, box = { x0: -RAMP_TOP / Math.tan(th) - 0.04, x1: N.TRACK + 0.12, y0: -0.07, y1: RAMP_TOP + (compact ? 0.08 : 0.16) };
      // 轨道按宽度定比例，只占需要的高度；剩下的给 v-t 图像，整体竖直居中
      var need = n * (box.y1 - box.y0) * R.w / (box.x1 - box.x0) + 8;
      var gh = o.graph ? Math.max(130, Math.min(R.h * 0.45, 300)) : 0, gap = o.graph ? 18 : 0;
      var lhTot = Math.min(R.h - gh - gap, need), slack = R.h - gh - gap - lhTot;
      if (o.graph) { var add = Math.min(slack * 0.5, 340 - gh); if (add > 0) { gh += add; slack -= add; } }
      var LR = { x: R.x, y: R.y + slack / 2, w: R.w, h: lhTot }, lh = LR.h / n;
      o.lanes.forEach(function (ln, i) {
        var fr = frame({ x: LR.x, y: LR.y + i * lh, w: LR.w, h: lh }, box, 0.5);
        lane(fr, ln, { h: o.h, compact: compact, forces: o.forces, vel: o.vel });
      });
      if (o.graph) vtGraph({ x: R.x, y: LR.y + LR.h + gap, w: R.w, h: gh }, o.curves, o);
    }

    // ---------- ② 伽利略理想斜面 ----------
    // o: { a2, mu, ball, path, marks: [{ a2, s }], H }
    function drawGalileo(o) {
      bg();
      var R = area(), G = N.GAL, a1 = G.a1 * DEG, top = G.H * G.TOP, xl = -top / Math.tan(a1);
      var fr = frame({ x: R.x, y: R.y + 30, w: R.w, h: R.h - 60 }, { x0: xl - 0.08, x1: G.RIGHT_MAX + 0.05, y0: -0.12, y1: top + 0.08 }, 0.5);
      var O = fr.p(0, 0), base = fr.p(0, -0.05), k = fr.k, BR = Math.max(7, Math.min(12, k * 0.018));
      // 以前试过的右斜面（淡）及到达的位置
      o.marks.forEach(function (m) {
        if (m.a2 === o.a2) return;
        var p = N.galPath(m.a2), e = p.pos(p.sMax), q = p.pos(m.s);
        line(ctx, fr.p(0, 0), fr.p(e.x, e.y), 'rgba(141,153,171,.35)', { width: 1.5, dash: [4, 4] });
        var qp = fr.p(q.x, q.y);
        ctx.fillStyle = 'rgba(255,201,74,.45)'; ctx.beginPath(); ctx.arc(qp.x, qp.y - BR, 4, 0, 7); ctx.fill();
        label(ctx, m.a2 + '°', qp.x + 4, qp.y - BR - 12, { size: 10, color: MUTED });
      });
      // 斜面
      var path = o.path, L = fr.p(xl, top), Rt = path.a2 > 0 ? path.pos(path.sMax) : { x: fr.view.x1 + 1, y: 0 }, RP = fr.p(Rt.x, Rt.y);
      poly(ctx, [L, O, RP, { x: RP.x, y: base.y }, { x: L.x, y: base.y }], 'rgba(111,134,201,.22)', null);
      ctx.strokeStyle = '#6f86c9'; ctx.lineWidth = 2.4; ctx.beginPath(); ctx.moveTo(L.x, L.y); ctx.lineTo(O.x, O.y); ctx.lineTo(RP.x, RP.y); ctx.stroke();
      // 释放高度
      var hp = fr.p(0, o.H);
      line(ctx, { x: fr.R.x, y: hp.y - BR }, { x: fr.R.x + fr.R.w, y: hp.y - BR }, CAR, { dash: [6, 5], width: 1.2 });
      label(ctx, '释放高度 H', fr.R.x + fr.R.w - 4, hp.y - BR - 12, { size: 12, color: CAR, align: 'right' });
      // 角度
      line(ctx, { x: O.x - 70, y: O.y }, { x: O.x + 80, y: O.y }, MUTED, { dash: [3, 3] });
      ctx.strokeStyle = MUTED; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.arc(O.x, O.y, 40, Math.PI + a1, Math.PI, true); ctx.stroke();
      label(ctx, G.a1 + '°', O.x - 56, O.y - 12, { size: 11, color: MUTED });
      if (path.a2 > 0) {
        ctx.beginPath(); ctx.arc(O.x, O.y, 60, -path.a2, 0); ctx.stroke();
        label(ctx, o.a2 + '°', O.x + 60 + 14, O.y - 60 * Math.sin(path.a2 / 2) - 2, { size: 11, color: MUTED });
      }
      else label(ctx, '右侧变成水平面', O.x + 70, O.y + 18, { size: 11, color: MUTED });
      // 小球
      var b = o.ball, bp = path.pos(b.s), phi = path.slope(b.s), sp = fr.p(bp.x, bp.y);
      var nx = -Math.sin(phi), ny = Math.cos(phi);   // 表面法向（世界）
      var c = { x: sp.x + nx * BR, y: sp.y - ny * BR };
      if (c.x > fr.R.x + fr.R.w + BR) {
        var ex = fr.R.x + fr.R.w - 4;
        arrow(ctx, ex - 70, O.y - BR, ex, O.y - BR, '#7ee081', { width: 2.6 });
        label(ctx, o.mu > 0 ? '滚得很远很远' : '永远运动下去', ex - 36, O.y - BR - 16, { size: 12, color: '#7ee081', bold: true });
      } else {
        var g = ctx.createRadialGradient(c.x - BR * 0.35, c.y - BR * 0.35, 1, c.x, c.y, BR);
        g.addColorStop(0, '#fff'); g.addColorStop(0.35, CAR); g.addColorStop(1, '#6b5214');
        ctx.fillStyle = g; ctx.beginPath(); ctx.arc(c.x, c.y, BR, 0, 7); ctx.fill();
        if (Math.abs(b.v) > 0.02) {
          var vl = b.v * 32;
          arrow(ctx, c.x, c.y, c.x + Math.cos(phi) * vl, c.y - Math.sin(phi) * vl, VEL, { width: 2.2 });
        }
      }
      // 本次到达的最高点
      if (b.turns.length && path.a2 > 0) {
        var q = path.pos(b.turns[0]), qp = fr.p(q.x, q.y);
        ctx.strokeStyle = CAR; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(qp.x, qp.y - BR, BR + 3, 0, 7); ctx.stroke();
      }
      label(ctx, '左斜面倾角不变，从同一高度释放；改变右斜面的倾角', fr.R.x + 4, R.y + 10, { size: 12, color: MUTED, align: 'left' });
    }

    // 画面上方的说明卡片（窄屏时面板收起，也能看到现象和解释）；返回占用的高度
    function wrap(text, maxW) {
      var out = [], cur = '';
      for (var i = 0; i < text.length; i++) {
        var t = cur + text[i];
        if (ctx.measureText(t).width > maxW && cur) { out.push(cur); cur = text[i]; } else cur = t;
      }
      if (cur) out.push(cur);
      return out;
    }
    function card(R, note) {
      var w = Math.min(R.w, 600), x = R.x + (R.w - w) / 2, y = R.y + 4;
      ctx.font = font(13);
      var lines = wrap(note.text, w - 28), h = 40 + lines.length * 19;
      ctx.fillStyle = 'rgba(17,23,35,.85)'; ctx.strokeStyle = '#2a3446'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.roundRect(x, y, w, h, 10); ctx.fill(); ctx.stroke();
      ctx.fillStyle = CAR; ctx.fillRect(x, y + 10, 3, h - 20);
      label(ctx, note.title, x + 14, y + 18, { size: 14, bold: true, color: CAR, align: 'left' });
      ctx.font = font(13); ctx.fillStyle = TEXT; ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
      lines.forEach(function (l, i) { ctx.fillText(l, x + 14, y + 40 + i * 19); });
      return h + 4;
    }

    // ---------- ③ 惯性 ----------
    // o: { s: Newton.inertia 状态, note: { title, text } }
    function drawInertia(o) {
      bg();
      var s = o.s, I = N.INR, R = area();
      var cardH = o.note ? card(R, o.note) : 0;
      // 窄屏：镜头跟着小车（光滑车面木块飞出后取两者中点），画面放大
      var box = { x0: -0.36, x1: 1.85, y0: -0.12, y1: 0.4 };
      if (narrow) {
        var c = s.smooth && !s.onCart ? (s.cx + s.bx) / 2 : s.cx;
        c = N.clamp(c, box.x0 + 0.55, box.x1 - 0.55);
        box = { x0: c - 0.55, x1: c + 0.55, y0: -0.12, y1: 0.36 };
      }
      var fr = frame({ x: R.x, y: R.y + cardH + 10, w: R.w, h: R.h - cardH - 30 }, box, 0.5), k = fr.k;
      var g0 = fr.p(0, 0);
      ctx.fillStyle = 'rgba(43,51,70,.55)'; ctx.fillRect(0, g0.y, W, H - g0.y);
      line(ctx, { x: 0, y: g0.y }, { x: W, y: g0.y }, LINE, { width: 2 });
      // 挡板
      var w0 = fr.p(I.WALL, 0.05), w1 = fr.p(I.WALL + 0.06, 0);
      ctx.fillStyle = '#8a6a4a'; ctx.fillRect(w0.x, w0.y, w1.x - w0.x, w1.y - w0.y);
      ctx.strokeStyle = '#5a442e'; ctx.lineWidth = 1.2; ctx.strokeRect(w0.x, w0.y, w1.x - w0.x, w1.y - w0.y);
      label(ctx, '障碍物', (w0.x + w1.x) / 2, w1.y + 14, { size: 11, color: MUTED });
      // 小车
      var half = I.CART / 2, r = 0.03, b0 = fr.p(s.cx - half, I.DECK), b1 = fr.p(s.cx + half, 0.03);
      ctx.fillStyle = '#3b5a8f'; ctx.strokeStyle = '#6f86c9'; ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.roundRect(b0.x, b0.y, b1.x - b0.x, b1.y - b0.y, 4); ctx.fill(); ctx.stroke();
      ctx.fillStyle = s.smooth ? 'rgba(200,230,255,.8)' : '#c9a36b';
      ctx.fillRect(b0.x, b0.y - 3, b1.x - b0.x, 3);
      [-0.11, 0.11].forEach(function (dx) {
        var wc = fr.p(s.cx + dx, r);
        ctx.fillStyle = '#2a2f3a'; ctx.beginPath(); ctx.arc(wc.x, wc.y, r * k, 0, 7); ctx.fill();
        ctx.fillStyle = '#9aa4b5'; ctx.beginPath(); ctx.arc(wc.x, wc.y, r * k * 0.4, 0, 7); ctx.fill();
      });
      // 木块
      var bw = s.w * k, bh = s.hh * k, bc;
      ctx.save();
      if (s.smooth) {
        // 突然启动：标出木块原来的位置
        var g0p = fr.p(s.x0, I.DECK + s.hh / 2);
        if (s.mode === 'start' && s.t > 0) {
          ctx.strokeStyle = 'rgba(255,201,74,.45)'; ctx.setLineDash([4, 4]); ctx.lineWidth = 1.2;
          ctx.strokeRect(g0p.x - bw / 2, g0p.y - bh / 2, bw, bh); ctx.setLineDash([]);
        }
        if (s.mode === 'start' && s.t > 0) label(ctx, '木块原来的位置', g0p.x, g0p.y - bh / 2 - 10, { size: 11, color: MUTED });
        bc = fr.p(s.bx, s.by);
        ctx.translate(bc.x, bc.y);
        ctx.fillStyle = CAR; ctx.strokeStyle = '#7a5a12'; ctx.lineWidth = 1.2;
        ctx.fillRect(-bw / 2, -bh / 2, bw, bh); ctx.strokeRect(-bw / 2, -bh / 2, bw, bh);
      } else {
        var side = s.side || (s.th > 0 ? 1 : 0), px = s.cx + (side < 0 ? -s.w / 2 : s.w / 2), pv = fr.p(px, I.DECK);
        ctx.translate(pv.x, pv.y - 3);
        ctx.rotate(side < 0 ? -s.th : s.th);
        var x0 = side < 0 ? 0 : -bw;
        ctx.fillStyle = CAR; ctx.strokeStyle = '#7a5a12'; ctx.lineWidth = 1.2;
        ctx.fillRect(x0, -bh, bw, bh); ctx.strokeRect(x0, -bh, bw, bh);
        ctx.strokeStyle = 'rgba(122,90,18,.6)'; ctx.beginPath();
        for (var j = 1; j < 4; j++) { ctx.moveTo(x0 + 3, -bh * j / 4); ctx.lineTo(x0 + bw - 3, -bh * j / 4 + 2); }
        ctx.stroke();
        bc = fr.p(s.cx, I.DECK + s.hh / 2);
      }
      ctx.restore();
      // 速度箭头（地面参考系）
      var cy = fr.p(0, 0.015).y + 32;
      if (s.cv > 0.01) {
        arrow(ctx, (b0.x + b1.x) / 2, cy, (b0.x + b1.x) / 2 + s.cv * 60, cy, VEL, { width: 2.4 });
        label(ctx, '小车 v', (b0.x + b1.x) / 2 - 22, cy, { size: 11, color: VEL });
      } else label(ctx, '小车静止', (b0.x + b1.x) / 2, cy, { size: 11, color: VEL });
      if (s.smooth && Math.abs(s.bv) > 0.01) {
        var ty = bc.y - bh / 2 - 14;
        arrow(ctx, bc.x, ty, bc.x + s.bv * 60, ty, CAR, { width: 2.4 });
        label(ctx, '木块 v', bc.x - 24, ty, { size: 11, color: CAR });
      }
      if (s.ca !== 0 && Math.abs(s.ca) > 1) {
        var ay = fr.p(0, 0.38).y, ac = (b0.x + b1.x) / 2;
        label(ctx, s.ca > 0 ? '小车突然加速' : '小车突然停下', ac, ay, { size: 13, color: FRIC, bold: true });
      }
    }

    return { resize: resize, drawRamp: drawRamp, drawGalileo: drawGalileo, drawInertia: drawInertia, size: function () { return { w: W, h: H, narrow: narrow }; } };
  }

  window.NewtonDraw = { View: View };
})();
