// 连续模型；时间为教学单位，数量为期望值。计算层不访问 DOM。
(function () {
  'use strict';
  function value(p, t, kind) {
    if (kind === 'j') return p.n0 * Math.exp(p.r * t);
    return p.k / (1 + (p.k / p.n0 - 1) * Math.exp(-p.r * t));
  }
  function rate(p, n, kind) { return p.r * n * (kind === 'j' ? 1 : 1 - n / p.k); }
  function peakTime(p) { return p.n0 <= p.k / 2 ? Math.log(p.k / p.n0 - 1) / p.r : null; }
  function sample(p, t) {
    const s = value(p, t, 's'), j = value(p, t, 'j');
    return { s, j, ds: rate(p, s, 's'), dj: rate(p, j, 'j'), perS: p.r * (1 - s / p.k), perJ: p.r };
  }
  window.Growth = { value, rate, peakTime, sample };
})();
