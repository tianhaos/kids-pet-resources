// 池塘用相同面积和比例表现数量；两张图共用同一时间坐标。
(function () {
  'use strict';
  const gold = '#ffd073', blue = '#79d9ff', muted = '#a8b8cb';
  const plots = new WeakMap();
  const pondLimit = 1600;
  const plantUnit = 20;
  const plants = [];
  let seed = 74821;
  function random() {
    seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
    return seed / 4294967296;
  }
  for (let i = 0; i < pondLimit / plantUnit; i++) {
    plants.push({
      x: (i % 10 + .18 + random() * .64) / 10,
      y: (Math.floor(i / 10) + .12 + random() * .76) / 8,
      angle: random() * Math.PI * 2,
      size: .7 + random() * .4,
      order: random()
    });
  }
  plants.sort((a, b) => a.order - b.order);

  function surface(canvas) {
    const { width: w, height: h } = canvas.getBoundingClientRect();
    const dpr = Math.min(devicePixelRatio || 1, 2);
    const width = Math.round(w * dpr), height = Math.round(h * dpr);
    if (canvas.width !== width || canvas.height !== height) {
      canvas.width = width;
      canvas.height = height;
    }
    const ctx = canvas.getContext('2d');
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, w, h);
    return { ctx, w, h };
  }

  function leaf(ctx, x, y, scale, angle, color) {
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(angle);
    ctx.scale(scale, scale);
    ctx.beginPath();
    ctx.moveTo(-6, 0);
    ctx.bezierCurveTo(-6, -5, 2, -7, 7, -2);
    ctx.bezierCurveTo(10, 2, 2, 6, -3, 4);
    ctx.quadraticCurveTo(-6, 3, -6, 0);
    ctx.fillStyle = color;
    ctx.shadowColor = '#061213';
    ctx.shadowBlur = 3;
    ctx.shadowOffsetY = 2;
    ctx.fill();
    ctx.shadowColor = 'transparent';
    ctx.strokeStyle = '#eef3c746';
    ctx.lineWidth = .65;
    ctx.beginPath();
    ctx.moveTo(-3, 1);
    ctx.quadraticCurveTo(1, -1, 6, -1.7);
    ctx.stroke();
    ctx.restore();
  }

  function water(ctx, w, h, isJ, count) {
    const color = ctx.createLinearGradient(0, 0, w, h);
    color.addColorStop(0, isJ ? '#102832' : '#1b3533');
    color.addColorStop(.57, isJ ? '#133042' : '#153b39');
    color.addColorStop(1, '#08151d');
    ctx.fillStyle = color;
    ctx.fillRect(0, 0, w, h);
    // 曲线状反光只用于辨认水面。
    for (let i = 0; i < 32; i++) {
      const x = ((i * 43 % 97) / 97) * w, y = ((i * 37 % 101) / 101) * h;
      const len = Math.min(w * .25, 14 + i % 7 * 6);
      ctx.beginPath();
      ctx.moveTo(x, y);
      ctx.quadraticCurveTo(x + len * .46, y - 3, x + len, y);
      ctx.strokeStyle = i % 3 ? '#84d0d41e' : '#aef1d83b';
      ctx.lineWidth = i % 3 ? .7 : 1;
      ctx.stroke();
    }
    const scale = Math.min(1.4, w / 255, h / 119);
    const quantity = Math.min(plants.length, count / plantUnit);
    for (let i = 0; i < Math.ceil(quantity); i++) {
      const plant = plants[i];
      const x = 12 + plant.x * (w - 24);
      const y = 61 + plant.y * Math.max(10, h - 85);
      const s = scale * plant.size;
      ctx.globalAlpha = Math.min(1, quantity - i);
      leaf(ctx, x - s * 3, y + s * 2, s * .64, plant.angle + 2, isJ ? '#74bac3' : '#9ebb62');
      leaf(ctx, x + s * 3, y, s, plant.angle, isJ ? '#9bddcf' : '#cfdb7c');
      leaf(ctx, x, y - s * 3, s * .45, plant.angle - 1, isJ ? '#57a09e' : '#6fa25e');
    }
    ctx.globalAlpha = 1;
    const shade = ctx.createLinearGradient(0, 0, 0, 54);
    shade.addColorStop(0, '#07121ce8');
    shade.addColorStop(1, '#07121c00');
    ctx.fillStyle = shade;
    ctx.fillRect(0, 0, w, 54);
  }

  function pond(canvas, compare, sample) {
    const { ctx, w, h } = surface(canvas);
    const span = compare ? w / 2 : w;
    water(ctx, span, h, false, sample.s);
    if (!compare) return;
    ctx.save();
    ctx.translate(span, 0);
    water(ctx, span, h, true, sample.j);
    ctx.fillStyle = '#92b3c176';
    ctx.fillRect(-.5, 0, 1, h);
    ctx.restore();
  }

  function axis(p, ratePlot) {
    const upper = ratePlot ? p.r * p.k / 4 * 1.15 : Math.max(p.k, p.n0) * 1.12;
    const lower = ratePlot ? Math.min(0, Growth.rate(p, p.n0, 's') * 1.08) : 0;
    const rawStep = (upper - lower) / 4;
    const magnitude = 10 ** Math.floor(Math.log10(rawStep));
    const step = [1, 2, 2.5, 5, 10].find(n => n * magnitude >= rawStep) * magnitude;
    return { min: Math.floor(lower / step) * step, max: Math.ceil(upper / step) * step, step };
  }

  function chart(canvas, p, ratePlot, sample) {
    const { ctx, w, h } = surface(canvas);
    const { min, max, step } = axis(p, ratePlot);
    const left = 44, right = w - 33, top = 9, bottom = h - 23;
    if (right <= left || bottom <= top) return '';
    const x = t => left + t / 24 * (right - left);
    const y = n => bottom - (n - min) / (max - min) * (bottom - top);
    const currentX = x(p.t);
    plots.set(canvas, { left, right });
    ctx.font = '11px system-ui, sans-serif';
    function text(value, x, y, color = muted, align = 'left') {
      ctx.fillStyle = color;
      ctx.textAlign = align;
      ctx.fillText(value, x, y);
    }
    function line(x1, y1, x2, y2, color, dash = []) {
      ctx.beginPath();
      ctx.strokeStyle = color;
      ctx.lineWidth = 1;
      ctx.setLineDash(dash);
      ctx.moveTo(x1, y1);
      ctx.lineTo(x2, y2);
      ctx.stroke();
      ctx.setLineDash([]);
    }

    for (let n = min; n <= max; n += step) {
      line(left, y(n), right, y(n), n === 0 ? '#597082' : '#213044');
      text(n.toLocaleString('zh-CN'), left - 6, y(n) + 4, muted, 'right');
    }
    for (let t = 0; t <= 24; t += 6) {
      line(x(t), top, x(t), bottom, '#213044');
      text(String(t), x(t), bottom + 16, muted, 'center');
    }
    text('t', right + 19, bottom + 16, muted);
    if (!ratePlot) {
      line(left, y(p.k), right, y(p.k), '#8ed5a5', [5, 4]);
      text('K', right + 5, y(p.k) + 4, '#8ed5a5');
      line(left, y(p.k / 2), right, y(p.k / 2), '#936e35', [3, 5]);
      text('K/2', right + 5, y(p.k / 2) + 4, gold);
    }

    const compare = p.scene === 'compare';
    const jNow = ratePlot ? sample.dj : sample.j;
    const sNow = ratePlot ? sample.ds : sample.s;
    const jExit = Math.log(max / (p.n0 * (ratePlot ? p.r : 1))) / p.r;
    ctx.save();
    ctx.beginPath();
    ctx.rect(left - 1, top - 1, right - left + 2, bottom - top + 2);
    ctx.clip();
    const area = ctx.createLinearGradient(0, top, 0, bottom);
    area.addColorStop(0, '#ffd07330');
    area.addColorStop(1, '#ffd07303');
    function trace(kind, limit) {
      for (let i = 0; i <= 180; i++) {
        const t = limit * i / 180, n = Growth.value(p, t, kind);
        const pointY = y(ratePlot ? Growth.rate(p, n, kind) : n);
        if (i === 0) ctx.moveTo(x(t), pointY);
        else ctx.lineTo(x(t), pointY);
      }
    }
    ctx.beginPath();
    trace('s', 24);
    ctx.lineTo(right, y(0));
    ctx.lineTo(left, y(0));
    ctx.closePath();
    ctx.fillStyle = area;
    ctx.fill();
    ctx.beginPath();
    if (compare && jExit > 0) {
      trace('j', Math.min(24, jExit));
      ctx.strokeStyle = blue;
      ctx.lineWidth = 2;
      ctx.setLineDash([5, 4]);
      ctx.stroke();
      ctx.setLineDash([]);
    }
    ctx.beginPath();
    trace('s', 24);
    ctx.strokeStyle = gold;
    ctx.lineWidth = 2.6;
    ctx.stroke();
    ctx.restore();
    line(currentX, top, currentX, bottom, '#bdcede', [3, 4]);

    const peak = Growth.peakTime(p);
    if (peak !== null && peak <= 24) {
      ctx.beginPath();
      ctx.arc(x(peak), y(ratePlot ? p.r * p.k / 4 : p.k / 2), 7, 0, Math.PI * 2);
      ctx.strokeStyle = gold;
      ctx.lineWidth = 1;
      ctx.stroke();
    }
    function dot(value, color) {
      ctx.beginPath();
      ctx.arc(currentX, y(value), 4.5, 0, Math.PI * 2);
      ctx.fillStyle = color;
      ctx.fill();
      ctx.strokeStyle = '#07121b';
      ctx.lineWidth = 1.3;
      ctx.stroke();
    }
    if (compare && jNow <= max) dot(jNow, blue);
    dot(sNow, gold);
    if (compare && jExit > 0 && jExit <= 24) {
      const exitX = x(jExit);
      ctx.beginPath();
      ctx.moveTo(exitX, top - 6);
      ctx.lineTo(exitX + 4, top + 2);
      ctx.lineTo(exitX - 4, top + 2);
      ctx.fillStyle = blue;
      ctx.fill();
    }
    return compare && jNow > max ? 'J 型已离图' : '';
  }

  function timeAt(canvas, x) {
    const plot = plots.get(canvas);
    return plot ? Math.max(0, Math.min(24, (x - plot.left) / (plot.right - plot.left) * 24)) : null;
  }
  window.GrowthDraw = { pond, chart, timeAt, pondLimit };
})();
