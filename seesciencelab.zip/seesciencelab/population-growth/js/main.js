(function () {
  'use strict';
  const $ = id => document.getElementById(id);
  const params = new URLSearchParams(location.search);
  const sceneButtons = [...document.querySelectorAll('[data-scene]')];
  const jMetrics = document.querySelectorAll('.j-metric');
  const mobile = matchMedia('(max-width:760px)');
  const rangeKeys = ['n0', 'k', 'r', 't'];
  const stage = $('stage'), panel = $('panel');
  const charts = [$('population'), $('speed')];

  function preset(scene) {
    if (scene === 'above') return { n0: 800, k: 500, r: .4, t: 0 };
    const defaults = { n0: 50, k: 1000, r: .4 };
    return { ...defaults, t: Growth.peakTime(defaults) };
  }
  function number(key, def) {
    const input = $(key);
    const n = params.has(key) ? Number(params.get(key)) : def;
    return Number.isFinite(n) ? Math.max(Number(input.min), Math.min(Number(input.max), n)) : def;
  }
  const scene = sceneButtons.some(button => button.dataset.scene === params.get('scene')) ? params.get('scene') : 'compare';
  const state = { scene, ...preset(scene), play: params.get('play') === '1' };
  for (const key of rangeKeys) state[key] = number(key, state[key]);

  function track(action, label) {
    if (window.Analytics) Analytics.track('种群增长', action, String(label));
  }
  function write(id, value) {
    const node = $(id);
    if (node.textContent !== value) node.textContent = value;
  }
  const readers = [0, 1, 2, 3].map(digits => new Intl.NumberFormat('zh-CN', {
    minimumFractionDigits: digits, maximumFractionDigits: digits
  }));
  function format(value, digits) {
    return readers[digits].format(Number(value.toFixed(digits)));
  }
  function observation(v) {
    const { k, n0 } = state;
    const peak = Growth.peakTime(state);
    if (Math.abs(v.s - k) < .05) {
      write('phase', n0 === k ? 'N = K · 数量稳定' : '逼近 K · 净增长接近零');
      write('explain', n0 === k ? '初始数量等于环境容纳量，数量与净增长速率保持不变。' : '数量曲线逐渐变平，净增长速率趋近零。');
    } else if (v.s > k) {
      write('phase', 'N > K · 数量回落');
      write('explain', '净增长速率为负，数量从上方趋近 K，下降逐渐变慢。');
    } else if (peak !== null && Math.abs(v.s - k / 2) < k * .0003) {
      write('phase', 'K/2 · 净增长最快');
      write('explain', '数量曲线在这里最陡，下图同一时刻达到峰值。');
    } else if (v.s < k / 2) {
      write('phase', 'N < K/2 · 越长越快');
      write('explain', '数量与净增长速率都在增加，人均瞬时增长率逐渐下降。');
    } else {
      write('phase', 'K/2 < N < K · 增长放慢');
      write('explain', '数量仍在增加，净增长速率开始下降。');
    }
    const unavailable = peak === null || peak > 24;
    $('peak').disabled = unavailable;
    const note = peak === null ? '初始数量已高于 K/2，这条轨迹不会经过该点。' :
      peak > 24 ? '达到 K/2 的时刻在图示时间之外。' :
      'K/2 = ' + format(k / 2, 0) + ' 个，最大净增长速率 ' + format(state.r * k / 4, 1) + '。';
    write('peakNote', note);
    $('peak').title = unavailable ? note : '同步定位两张图';
  }

  function update() {
    const compare = state.scene === 'compare';
    for (const button of sceneButtons) {
      const selected = button.dataset.scene === state.scene;
      button.classList.toggle('on', selected);
      button.setAttribute('aria-pressed', selected);
    }
    for (const key of rangeKeys) {
      $(key).value = state[key];
      write(key + 'Val', state[key].toFixed(key === 'r' || key === 't' ? 2 : 0));
    }
    const v = Growth.sample(state, state.t);
    $('jPond').hidden = !compare;
    for (const metric of jMetrics) metric.hidden = !compare;
    write('sCount', format(v.s, 1) + ' 个');
    write('jCount', format(v.j, 1) + ' 个');
    write('pondKey', compare && v.j > GrowthDraw.pondLimit ?
      '约 20 个/株 · J 型示意已满' : '浮萍疏密示意 · 约 20 个/株');
    write('sN', format(v.s, 1));
    write('jN', format(v.j, 1));
    write('sRate', format(v.ds, 2));
    write('sSpeed', 'S ' + format(v.ds, 1));
    write('jRate', format(v.dj, 2));
    write('sPer', format(v.perS, 3));
    write('jPer', format(v.perJ, 3));
    observation(v);
    write('play', state.play ? 'Ⅱ 暂停' : '▶ 播放');
    GrowthDraw.pond($('pond'), compare, v);
    write('jOutN', GrowthDraw.chart(charts[0], state, false, v));
    write('jOutRate', GrowthDraw.chart(charts[1], state, true, v));
  }

  for (const key of rangeKeys) {
    $(key).addEventListener('input', () => {
      state[key] = Number($(key).value);
      state.play = false;
      update();
    });
    $(key).addEventListener('change', () => track('调节' + key, state[key]));
  }
  for (const button of sceneButtons) {
    button.onclick = () => {
      const next = button.dataset.scene;
      if (next === state.scene) return;
      Object.assign(state, preset(next), { scene: next, play: false });
      track('切换场景', next);
      update();
    };
  }
  $('play').onclick = () => {
    if (state.t >= 24) state.t = 0;
    state.play = !state.play;
    track('播放', state.play);
    update();
  };
  $('reset').onclick = () => {
    state.t = 0;
    state.play = false;
    track('重置', state.scene);
    update();
  };
  $('peak').onclick = () => {
    const t = Growth.peakTime(state);
    if (t === null || t > 24) return;
    state.t = t;
    state.play = false;
    track('定位', 'K/2');
    update();
  };
  $('share').onclick = async () => {
    const url = new URL(location.href);
    url.search = '';
    url.hash = '';
    for (const key of ['scene', ...rangeKeys]) url.searchParams.set(key, state[key]);
    url.searchParams.set('play', '0');
    try {
      await navigator.clipboard.writeText(url.href);
      write('shareStatus', '已复制当前实验链接');
    } catch (error) {
      write('shareStatus', url.href);
    }
    track('分享', state.scene);
  };

  for (const canvas of charts) {
    let pointer = null;
    function seek(event) {
      const t = GrowthDraw.timeAt(canvas, event.clientX - canvas.getBoundingClientRect().left);
      if (t === null) return;
      state.t = t;
      state.play = false;
      update();
    }
    canvas.onpointerdown = event => {
      if (event.button !== 0 || pointer !== null) return;
      pointer = event.pointerId;
      canvas.setPointerCapture(pointer);
      seek(event);
    };
    canvas.onpointermove = event => {
      if (event.pointerId === pointer) seek(event);
    };
    canvas.onpointerup = event => {
      if (event.pointerId === pointer) track('拖动时间', state.t.toFixed(2));
    };
    canvas.onlostpointercapture = () => { pointer = null; };
  }

  function setPanel(open) {
    panel.classList.toggle('collapsed', !open);
    panel.inert = !open;
    $('panelToggle').setAttribute('aria-expanded', open);
  }
  setPanel(!mobile.matches);
  mobile.addEventListener('change', () => setPanel(!mobile.matches));
  $('panelToggle').onclick = () => setPanel(panel.classList.contains('collapsed'));
  $('panelClose').onclick = () => {
    setPanel(false);
    $('panelToggle').focus();
  };
  panel.querySelector('.learn-link').addEventListener('click', () => {
    if (mobile.matches) setPanel(false);
  });
  window.addEventListener('keydown', event => {
    if (event.key === 'Escape' && mobile.matches && !panel.inert) $('panelClose').click();
    if (event.code === 'Space' && !/INPUT|SELECT|BUTTON|TEXTAREA|A/.test(event.target.tagName)) {
      event.preventDefault();
      $('play').click();
    }
  });

  let last = 0;
  function frame(now) {
    if (state.play) {
      state.t = Math.min(24, state.t + Math.min((now - last) / 1000, .1) * 1.2);
      if (state.t === 24) state.play = false;
      update();
    }
    last = now;
    requestAnimationFrame(frame);
  }
  window.__model = { state, update, sample: () => Growth.sample(state, state.t) };
  new ResizeObserver(update).observe(stage);
  update();
  requestAnimationFrame(frame);
})();
