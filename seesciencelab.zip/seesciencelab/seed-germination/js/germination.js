/* 菜豆种子萌发的定性时序；时间与尺寸用于观察，不作实际培养预测。 */
(function () {
  'use strict';
  const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
  const base = { water: 'moist', temp: 25, light: true, alive: true, dormant: false };
  const group = (id, name, note, extra) => Object.assign({}, base, { id, name, note }, extra);
  const scenes = {
    conditions: {
      title: '水够了，种子就一定会萌发吗？',
      intro: '同批菜豆 · 选 B 组与另一组对照，探究水分、空气或温度。',
      question: '与 B 组相比，C 组主要缺少什么？', answer: 'oxygen',
      groups: [
        group('dry', 'A · 干燥', '干纸巾 · 25 °C', {water:'dry'}),
        group('control', 'B · 湿润', '湿纸巾 · 25 °C', {}),
        group('flood', 'C · 淹没', '水淹种子 · 25 °C', {water:'flood'}),
        group('cold', 'D · 低温', '湿纸巾 · 5 °C', {temp:5})
      ],
      conclusion: 'A/B 比水分，B/C 比空气，B/D 比温度。A、C、D 之间同时有多个差异，不能互作单因素对照。'
    },
    light: {
      title: '没有光，菜豆种子也能萌发吗？',
      intro: '同批菜豆 · 同为湿润、通气、25 °C；只改变光照。',
      question: '这组实验能说明所有种子都不需要光吗？', answer: 'no',
      groups: [group('lit', 'A · 明处', '湿润 · 通气 · 25 °C', {}), group('dark', 'B · 暗处', '遮光罩 · 通气 · 25 °C', {light:false})],
      conclusion: '菜豆可利用子叶储存的营养萌发。这里不能推广到所有植物；有些种子的萌发受光促进或抑制。只比较萌发，不预测暗处后续生长。'
    },
    viability: {
      title: '外界条件合适，为什么还有种子不萌发？',
      intro: '同为湿润、通气、25 °C、明处；改变种子自身条件。',
      question: '煮熟的种子，补足水分后能重新萌发吗？', answer: 'no',
      groups: [group('healthy', 'A · 正常种子', '胚完整、有活力 · 已解除休眠', {}), group('dead', 'B · 煮熟种子', '胚已失去活力', {alive:false}), group('dormant', 'C · 休眠种子', '胚有活力 · 未解除休眠', {dormant:true})],
      conclusion: '外界条件之外，还需完整且有活力的胚，以及解除休眠等自身条件。本场景不模拟休眠解除的方法。'
    }
  };
  function sample(g, day, index = 0) {
    const d = clamp(day, 0, 6);
    const imbibed = g.water === 'dry' ? 0 : clamp(d / .9, 0, 1);
    const eligible = g.water === 'moist' && g.temp === 25 && g.alive && !g.dormant;
    const emergence = 1.45 + index * .13;
    const root = eligible ? clamp((d - emergence) / 2.8, 0, 1) : 0;
    // 暗处只呈现胚根突破，不模拟长期形态，避免把明暗幼苗画成相同。
    const shoot = eligible && g.light ? clamp((d - 2.7 - index * .13) / 3.1, 0, 1) : 0;
    let reason = '';
    if (g.water === 'dry') reason = '缺少萌发所需的水分';
    else if (!g.alive) reason = '胚已失活，不能恢复生长';
    else if (g.dormant) reason = '尚未解除休眠';
    else if (g.water === 'flood') reason = '久置水下，氧气供应不足';
    else if (g.temp !== 25) reason = '低温下，本观察期内未见萌发';
    const stage = root > 0 ? (shoot > .25 ? '幼苗生长' : '胚根突破种皮') : (imbibed > .1 ? '吸水膨胀，未见胚根' : '尚未吸水');
    return {imbibed, eligible, root, shoot, emerged:root > 0, stage, reason};
  }
  function summary(g, day) {
    const samples = [0,1,2,3].map(i => sample(g, day, i));
    return { ...samples[0], count:samples.filter(s => s.emerged).length };
  }
  window.Germination = {clamp, scenes, sample, summary};
})();
