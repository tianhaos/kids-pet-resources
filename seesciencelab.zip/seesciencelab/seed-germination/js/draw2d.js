/* 培养瓶、种子与可回看的时间轴，全部使用CSS像素绘制。 */
(function () {
  'use strict';
  const canvas = document.getElementById('seeds'), ctx = canvas.getContext('2d');
  const C = {text:'#e3ecf2', muted:'#9db0c3', line:'#344758', green:'#96d9a3', root:'#f3e5bc', gold:'#efbb70'};
  let w=0,h=0,hover=null;
  function round(x,y,a,b,r,fill,stroke){
    ctx.beginPath();ctx.roundRect(x,y,a,b,r);
    if(fill){ctx.fillStyle=fill;ctx.fill();}
    if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=1;ctx.stroke();}
  }
  function text(s,x,y,size=12,color=C.text,align='left'){
    ctx.font=`${size}px -apple-system,BlinkMacSystemFont,"PingFang SC","Microsoft YaHei",sans-serif`;
    ctx.fillStyle=color;ctx.textAlign=align;ctx.fillText(s,x,y);
  }
  function line(points,color,width){
    ctx.beginPath();ctx.moveTo(...points[0]);
    for(let i=1;i<points.length;i++)ctx.lineTo(...points[i]);
    ctx.strokeStyle=color;ctx.lineWidth=width;ctx.lineCap='round';ctx.stroke();
  }
  function layout(state){
    const n=Germination.scenes[state.scene].groups.length;
    const pad=w<600?12:26,gap=w<600?10:22;
    const top=126,bottom=h-177;
    const cols=h<650&&w>780?4:2,rows=Math.ceil(n/cols),cw=(w-2*pad-gap*(cols-1))/cols,ch=Math.max(125,(bottom-top-gap*(rows-1))/rows);
    const jars=Array.from({length:n},(_,i)=>({x:pad+(i%cols)*(cw+gap),y:top+Math.floor(i/cols)*(ch+gap),w:cw,h:ch}));
    return {jars,detail:{x:pad,y:h-161,w:w-2*pad,h:81},timeline:{x:pad+10,y:h-49,w:w-2*pad-20}};
  }
  function leaf(x,y,dx,dy,color){
    ctx.beginPath();ctx.moveTo(x,y);ctx.quadraticCurveTo(x+dx*.15,y+dy*1.2,x+dx,y+dy);
    ctx.quadraticCurveTo(x+dx*.95,y-dy*.2,x,y);ctx.fillStyle=color;ctx.fill();
    line([[x,y],[x+dx*.8,y+dy*.85]],'#b3d69a',.6);
  }
  function seed(x,y,r,s,lit=true,index=0){
    const rr=r*(1+s.imbibed*.22),root=s.root,shoot=s.shoot;
    ctx.save();
    // 胚根先伸出，下行主根随后发生侧根。
    if(root>0){
      const length=rr*(.3+root*3.6);
      ctx.beginPath();ctx.moveTo(x+rr*.35,y+rr*.35);
      ctx.bezierCurveTo(x+rr*.85,y+rr,x-rr*.5,y+length*.65,x+rr*.1,y+length);
      ctx.strokeStyle=C.root;ctx.lineWidth=rr*.22;ctx.lineCap='round';ctx.stroke();
      if(root>.45)for(let i=0;i<3;i++){
        const yy=y+length*(.4+i*.15),side=(i+index)%2?1:-1;
        line([[x+rr*.12,yy],[x+side*rr*.6*root,yy+rr*.6]],'#d9d1af',Math.max(1,rr*.08));
      }
    }
    // 菜豆胚轴拱起，再托举子叶；位置与种皮不混为一体。
    if(shoot>0){
      const height=rr*(1+shoot*4.1),sx=x+rr*.2,sy=y-height;
      ctx.beginPath();ctx.moveTo(x+rr*.2,y+rr*.5);
      ctx.bezierCurveTo(x-rr*.2,y-height*.5,x-rr*.7,sy-rr*.5,sx,sy);
      ctx.strokeStyle='#87bb7d';ctx.lineWidth=rr*.22;ctx.stroke();
      if(shoot>.23){
        leaf(sx,sy,-rr*(.8+shoot*.5),-rr*.5,'#b9d38a');
        leaf(sx,sy,rr*(.9+shoot*.4),-rr*.4,'#9abf71');
      }
      if(shoot>.65){
        line([[sx,sy],[sx,sy-rr*.9]],'#8ecb91',rr*.13);
        leaf(sx,sy-rr*.8,-rr*1.1,-rr*.55,'#5bab71');
        leaf(sx,sy-rr*.8,rr*1.1,-rr*.65,'#77c38b');
      }
    }
    ctx.translate(x,y);ctx.rotate(-.35+index*.12);
    // 出苗后下方仅余种皮，两片子叶已随胚轴升起。
    if(shoot>.2){ctx.globalAlpha=1-shoot*.7;}
    const skin=ctx.createLinearGradient(-rr,-rr,rr,rr);
    skin.addColorStop(0,'#e8b673');skin.addColorStop(.4,'#ac6b3d');skin.addColorStop(1,'#643b29');
    ctx.beginPath();ctx.moveTo(0,-rr*.65);
    ctx.bezierCurveTo(rr*1.4,-rr*1.05,rr*1.45,rr*.8,rr*.05,rr*.72);
    ctx.bezierCurveTo(-rr*1.15,rr*.7,-rr*1.2,-rr*.8,0,-rr*.65);
    ctx.fillStyle=skin;ctx.fill();ctx.strokeStyle='#edc189';ctx.lineWidth=.7;ctx.stroke();
    ctx.beginPath();ctx.ellipse(-rr*.2,0,rr*.16,rr*.37,.1,0,Math.PI*2);
    ctx.fillStyle='#e5d7ae';ctx.fill();
    if(root>0){line([[rr*.33,rr*.2],[rr*.49,rr*.55]],'#392e29',rr*.12);}
    ctx.restore();
  }
  function jar(box,g,state,index){
    const {x,y,w:bw,h:bh}=box,small=w<600;
    const selected=state.selected===index,hot=hover===index;
    const s=Germination.summary(g,state.day);
    round(x,y,bw,bh,12,selected?'#0e1c23':'#0a111b',selected?'#7dbb99':hot?'#718ca5':'#243547');
    text(g.name,x+12,y+22,small?13:15,selected?'#b4e8c5':C.text);
    text(g.note,x+12,y+40,small?10:12,C.muted);
    const jw=bw*.7,jx=x+(bw-jw)/2,jy=y+53,jh=Math.max(30,bh-93);
    // 开口玻璃培养瓶，明暗组的观察窗共享轮廓。
    const glass=ctx.createLinearGradient(jx,0,jx+jw,0);
    glass.addColorStop(0,'#38627336');glass.addColorStop(.2,'#182b3422');glass.addColorStop(.8,'#182b3422');glass.addColorStop(1,'#517c8b33');
    round(jx,jy,jw,jh,8,glass,'#638594');
    if(!g.light){
      round(jx-5,jy-7,jw+10,jh+12,10,'#121323aa','#79748b');
      text('遮光罩 · 观察窗示意',x+bw/2,jy+15,small?9:11,'#b6b0cb','center');
    }
    ctx.save();ctx.beginPath();ctx.roundRect(jx+1,jy+1,jw-2,jh-2,7);ctx.clip();
    const surface=jy+jh*.62;
    if(g.water==='flood'){
      const waterTop=jy+jh*.27;
      const water=ctx.createLinearGradient(0,waterTop,0,jy+jh);
      water.addColorStop(0,'#398bab60');water.addColorStop(1,'#17587990');
      ctx.fillStyle=water;ctx.fillRect(jx,waterTop,jw,jh);
      line([[jx,waterTop],[jx+jw,waterTop]],'#69bedc',1.5);
      text('水面',jx+6,waterTop-5,10,'#8acbdf');
    }
    // 湿纸层仍保留透视，根在其内可见，并非悬空生长。
    ctx.fillStyle=g.water==='dry'?'#c2b8a52b':'#b2d2ce28';ctx.fillRect(jx+7,surface+2,jw-14,jh*.32);
    for(let j=0;j<6;j++)line([[jx+9,surface+6+j*4],[jx+jw-9,surface+6+j*4]],g.water==='dry'?'#95887529':'#95d5d528',.7);
    const r=Math.min(small?9:14,jw/15,jh/14);
    for(let i=0;i<4;i++){
      const xx=jx+jw*(.16+i*.225),yy=surface+((i%2)*.9- .45)*r;
      seed(xx,yy,r,Germination.sample(g,state.day,i),g.light,i);
    }
    ctx.restore();
    ctx.beginPath();ctx.ellipse(jx+jw/2,jy,jw/2,4,0,0,Math.PI*2);ctx.strokeStyle='#8cabb8';ctx.lineWidth=1.2;ctx.stroke();
    line([[jx+5,jy+13],[jx+5,jy+jh-15]],'#abcdd32a',2);
    if(g.temp===5){
      text('5 °C',jx+jw-5,jy+22,12,'#8fcfff','right');
      text('低温对照',jx+jw/2,jy+jh-9,10,'#8fcfff','center');
    }
    text(s.emerged?`${s.count}/4 粒见胚根`:'未见胚根',x+12,y+bh-19,small?11:12,s.emerged?C.green:C.gold);
    if(selected)text('●',x+bw-16,y+21,10,C.green,'center');
  }
  function anatomy(b){
    round(b.x,b.y,b.w,b.h,12,'#0b141b','#243547');
    text('种子内部 · 剖面示意',b.x+12,b.y+23,w<600?12:14,C.green);
    const x=b.x+b.w*.32,y=b.y+b.h*.52,r=Math.min(b.w*.23,b.h*.31);
    ctx.save();ctx.translate(x,y);ctx.rotate(-.2);
    ctx.beginPath();ctx.ellipse(0,0,r*.78,r,0,0,Math.PI*2);ctx.fillStyle='#a66c40';ctx.fill();
    ctx.beginPath();ctx.ellipse(0,0,r*.65,r*.87,0,0,Math.PI*2);ctx.fillStyle='#e3d2a3';ctx.fill();
    ctx.beginPath();ctx.ellipse(-r*.07,0,r*.4,r*.75,0,0,Math.PI*2);ctx.fillStyle='#f2e7be';ctx.fill();
    ctx.beginPath();ctx.moveTo(r*.2,r*.65);ctx.bezierCurveTo(-r*.1,r*.2,r*.5,-r*.1,r*.12,-r*.5);
    ctx.strokeStyle='#70ac76';ctx.lineWidth=Math.max(3,r*.12);ctx.lineCap='round';ctx.stroke();
    leaf(r*.12,-r*.45,-r*.22,-r*.18,'#70ac76');leaf(r*.12,-r*.45,r*.25,-r*.22,'#91bc84');ctx.restore();
    const tx=b.x+b.w*.64;
    line([[x+r*.4,y-r*.3],[tx-7,y-r*.3]],'#758b9c',1);
    text('子叶',tx,y-r*.3,12,C.root);text('营养储备',tx,y-r*.3+17,10,C.muted);
    line([[x+r*.15,y+r*.4],[tx-7,y+r*.4]],'#758b9c',1);
    text('胚',tx,y+r*.4,12,C.green);text('发育成幼苗',tx,y+r*.4+17,10,C.muted);
    text('子叶属于胚的一部分',b.x+12,b.y+b.h-18,w<600?10:12,C.muted);
  }
  function render(state){
    const rect=canvas.getBoundingClientRect(),dpr=Math.min(devicePixelRatio||1,2);
    w=rect.width;h=rect.height;
    if(canvas.width!==Math.round(w*dpr)||canvas.height!==Math.round(h*dpr)){
      canvas.width=Math.round(w*dpr);canvas.height=Math.round(h*dpr);
    }
    ctx.setTransform(dpr,0,0,dpr,0,0);ctx.fillStyle='#05070d';ctx.fillRect(0,0,w,h);
    const geometry=layout(state),groups=Germination.scenes[state.scene].groups;
    geometry.jars.forEach((box,i)=>jar(box,groups[i],state,i));
    if(groups.length===3 && geometry.jars[2].y>geometry.jars[0].y){
      const first=geometry.jars[0],last=geometry.jars[2];
      anatomy({x:geometry.jars[1].x,y:last.y,w:first.w,h:first.h});
    }
    const g=groups[state.selected],s=Germination.sample(g,state.day),d=geometry.detail;
    round(d.x,d.y,d.w,d.h,9,'#101a24','#293c4a');
    seed(d.x+40,d.y+36,12,{...s,root:s.root*.5,shoot:0},g.light);
    text(`${g.name} · 放大观察`,d.x+80,d.y+22,12,C.green);
    text(s.stage,d.x+80,d.y+43,12,C.text);
    const note=s.reason||(s.root>0?'胚根先突破种皮，再发育成根':'先吸水，再观察胚是否生长');
    text(note,d.x+80,d.y+64,w<600?10:12,C.muted);
    const t=geometry.timeline;
    text(`观察第 ${state.day.toFixed(1)} 天`,t.x,t.y-23,12,C.gold);
    text('拖动时间回看',t.x+t.w,t.y-23,11,C.muted,'right');
    line([[t.x,t.y],[t.x+t.w,t.y]],'#304456',4);
    line([[t.x,t.y],[t.x+t.w*state.day/6,t.y]],'#85cda0',4);
    for(let i=0;i<=6;i++){
      line([[t.x+t.w*i/6,t.y-4],[t.x+t.w*i/6,t.y+4]],'#98a9b7',1);
      text(String(i),t.x+t.w*i/6,t.y+18,10,C.muted,'center');
    }
    ctx.beginPath();ctx.arc(t.x+t.w*state.day/6,t.y,8,0,Math.PI*2);ctx.fillStyle='#c4edcc';ctx.fill();
  }
  function hit(x,y,state){
    const geo=layout(state);
    if(Math.abs(y-geo.timeline.y)<23 && x>=geo.timeline.x-15&&x<=geo.timeline.x+geo.timeline.w+15)return 'timeline';
    const i=geo.jars.findIndex(b=>x>=b.x&&x<=b.x+b.w&&y>=b.y&&y<=b.y+b.h);
    return i>=0?i:null;
  }
  function dayAt(x,state){const t=layout(state).timeline;return Germination.clamp((x-t.x)/t.w*6,0,6);}
  window.SeedDraw={render,layout,hit,dayAt,setHover(v){hover=v;}};
})();
