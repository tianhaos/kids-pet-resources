(function () {
  'use strict';
  const $=id=>document.getElementById(id),qs=new URLSearchParams(location.search);
  const initial=Object.hasOwn(Germination.scenes,qs.get('scene'))?qs.get('scene'):'conditions';
  const finite=(value,fallback)=>value!==null&&value.trim()!==''&&Number.isFinite(Number(value))?Number(value):fallback;
  const state={scene:initial,day:Germination.clamp(finite(qs.get('day'),3.2),0,6),selected:0,
    play:!matchMedia('(prefers-reduced-motion: reduce)').matches && qs.get('play')!=='0'};
  state.selected=Germination.clamp(Math.floor(finite(qs.get('group'),1)),0,groups().length-1);
  const records=[];
  let drag=false,last=0,lastUI=-1;
  function groups(){return Germination.scenes[state.scene].groups;}
  function track(action,label=''){if(window.Analytics)Analytics.track('种子萌发条件',action,label);}
  function update(){
    const scene=Germination.scenes[state.scene],g=groups()[state.selected],s=Germination.summary(g,state.day);
    $('sceneTitle').textContent=scene.title;$('sceneIntro').textContent=scene.intro;
    $('selection').textContent=g.name;$('status').textContent=s.stage;
    $('reason').textContent=s.reason||(s.root>0?'胚根已突破种皮，萌发已经发生。':'先吸水膨胀，尚需观察胚根是否突破。');
    $('waterValue').textContent=g.water==='dry'?'干燥':g.water==='flood'?'水淹种子':'湿润通气';
    $('tempValue').textContent=g.temp+' °C';$('lightValue').textContent=g.light?'明处':'暗处';
    $('aliveValue').textContent=!g.alive?'胚已失活':g.dormant?'未解除休眠':'胚有活力';
    $('conclusion').textContent=scene.conclusion;$('question').textContent=scene.question;
    $('timeValue').textContent=state.day.toFixed(1)+' 天';$('day').value=state.day;
    $('play').textContent=state.play?'❚❚ 暂停观察':'▶ 继续观察';
    document.querySelectorAll('[data-scene]').forEach(b=>{b.classList.toggle('on',b.dataset.scene===state.scene);b.setAttribute('aria-pressed',b.dataset.scene===state.scene);});
    document.querySelectorAll('[data-group]').forEach(b=>{b.classList.toggle('on',Number(b.dataset.group)===state.selected);b.setAttribute('aria-pressed',Number(b.dataset.group)===state.selected);});
    SeedDraw.render(state);lastUI=state.day;
  }
  function bottleButtons(){
    $('bottles').replaceChildren();
    groups().forEach((g,i)=>{const b=document.createElement('button');b.textContent=g.name;b.dataset.group=i;b.onclick=()=>select(i);$('bottles').append(b);});
  }
  function select(i){state.selected=Germination.clamp(i,0,groups().length-1);update();track('点选培养瓶',groups()[state.selected].id);}
  function setScene(scene){
    if(!Object.hasOwn(Germination.scenes,scene))return;
    state.scene=scene;state.selected=scene==='conditions'?1:0;state.day=3.2;state.play=false;
    $('feedback').textContent='';$('answer').value='';$('message').textContent='';bottleButtons();update();track('切换场景',scene);
  }
  function setDay(day){if(!Number.isFinite(day))return;state.day=Germination.clamp(day,0,6);state.play=false;update();}
  document.querySelectorAll('[data-scene]').forEach(b=>b.onclick=()=>setScene(b.dataset.scene));
  $('play').onclick=()=>{if(state.day>=6)state.day=0;state.play=!state.play;update();track('播放暂停',state.play?'播放':'暂停');};
  $('reset').onclick=()=>{setDay(0);track('重做实验',state.scene);};
  $('day').addEventListener('input',()=>setDay(Number($('day').value)));
  $('day').addEventListener('change',()=>track('拖动时间','面板'));
  const canvas=$('seeds');
  function point(e){const r=canvas.getBoundingClientRect();return {x:e.clientX-r.left,y:e.clientY-r.top};}
  canvas.addEventListener('pointerdown',e=>{
    if(e.button!==0)return;
    const p=point(e),hit=SeedDraw.hit(p.x,p.y,state);
    if(hit==='timeline'){
      drag=true;canvas.classList.add('dragging');canvas.setPointerCapture(e.pointerId);setDay(SeedDraw.dayAt(p.x,state));e.preventDefault();
    }else if(typeof hit==='number')select(hit);
  });
  canvas.addEventListener('pointermove',e=>{
    const p=point(e),hit=SeedDraw.hit(p.x,p.y,state);
    if(drag){setDay(SeedDraw.dayAt(p.x,state));return;}
    SeedDraw.setHover(hit);canvas.style.cursor=hit==='timeline'?'ew-resize':typeof hit==='number'?'pointer':'';
  });
  function end(e){if(drag){drag=false;canvas.classList.remove('dragging');if(canvas.hasPointerCapture(e.pointerId))canvas.releasePointerCapture(e.pointerId);track('拖动时间','画面');}}
  canvas.addEventListener('pointerup',end);canvas.addEventListener('pointercancel',end);
  canvas.addEventListener('pointerleave',()=>SeedDraw.setHover(null));
  $('record').onclick=()=>{
    const g=groups()[state.selected],s=Germination.summary(g,state.day);
    const entry=`${Germination.scenes[state.scene].title} ${g.name} · 第${state.day.toFixed(1)}天：${s.stage}`;
    if(records.includes(entry)){$('message').textContent='这一观察已记录。';return;}
    records.unshift(entry);if(records.length>6)records.pop();$('recordList').replaceChildren();
    records.forEach(r=>{const li=document.createElement('li');li.textContent=r;$('recordList').append(li);});
    $('message').textContent='已记下观察（仅保存在本页）。';track('记录观察',g.id);
  };
  $('share').onclick=async()=>{
    const url=new URL(location.href);url.search=new URLSearchParams({scene:state.scene,day:state.day.toFixed(2),group:String(state.selected),play:'0'}).toString();url.hash='';
    try{await navigator.clipboard.writeText(url.href);$('message').textContent='已复制当前实验链接。';}
    catch{const input=$('shareURL');input.hidden=false;input.value=url.href;input.focus();input.select();$('message').textContent='请复制下方链接。';}
    track('分享实验',state.scene);
  };
  $('checkAnswer').onclick=()=>{
    const value=$('answer').value,correct=Germination.scenes[state.scene].answer;
    if(!value){$('feedback').textContent='先选择你的判断。';return;}
    $('feedback').textContent=value===correct?'判断正确。'+Germination.scenes[state.scene].conclusion:'再观察对照条件。'+Germination.scenes[state.scene].conclusion;
    track('判断',value===correct?'正确':'重试');
  };
  $('panelToggle').onclick=()=>{
    const collapsed=$('panel').classList.toggle('collapsed');$('panelToggle').setAttribute('aria-expanded',!collapsed);
  };
  if(innerWidth<=760)$('panel').classList.add('collapsed');
  $('panelToggle').setAttribute('aria-expanded',innerWidth>760);
  function frame(now){
    const dt=Math.min((now-last)/1000,.1);last=now;
    if(state.play){state.day=Math.min(6,state.day+dt*.17);if(state.day>=6)state.play=false;}
    SeedDraw.render(state);
    if(Math.abs(state.day-lastUI)>.025 || state.day===6&&$('play').textContent.includes('暂停'))update();
    requestAnimationFrame(frame);
  }
  bottleButtons();update();requestAnimationFrame(frame);
  window.__model={state,setScene,setDay,select,update,groups,records,layout:()=>SeedDraw.layout(state)};
})();
