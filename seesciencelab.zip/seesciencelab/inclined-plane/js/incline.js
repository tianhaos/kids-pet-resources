/* 斜面匀速向上运动：计算模块，SI单位，不操作DOM。 */
(function () {
  'use strict';
  const presets = {
    smooth: { name: '光滑斜面', angle: 30, mu: 0 },
    rough: { name: '有摩擦斜面', angle: 30, mu: 0.2 },
    gentle: { name: '缓坡对照', angle: 15, mu: 0.2 }
  };
  function number(value, fallback, min, max) {
    const n = Number(value);
    return value === null || value === '' || !Number.isFinite(n) ? fallback : Math.max(min, Math.min(max, n));
  }
  function clean(s) {
    return { scene: presets[s.scene] ? s.scene : 'rough', angle: number(s.angle, 30, 12, 55),
      mu: number(s.mu, 0.2, 0, 0.5), mass: number(s.mass, 10, 5, 20), p: number(s.p, 0.4, 0, 1) };
  }
  function solve(input) {
    const s = clean(input), a = s.angle * Math.PI / 180, G = s.mass * 10;
    // 固定总提升高度1m；更缓意味着更长的路程。
    const H = 1, L = H / Math.sin(a), base = H / Math.tan(a);
    const N = G * Math.cos(a), friction = s.mu * N, parallel = G * Math.sin(a);
    const F = parallel + friction, distance = L * s.p, height = H * s.p;
    return { ...s, a, G, H, L, base, N, friction, parallel, F, distance, height,
      useful: G * height, loss: friction * distance, input: F * distance,
      eta: parallel / F, saving: F < G, ratio: L / H };
  }
  window.Incline = { presets, number, clean, solve };
}());
