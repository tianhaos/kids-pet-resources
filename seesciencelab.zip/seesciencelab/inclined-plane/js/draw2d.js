/* 场景采用等比例米制几何；装置坐标通过layout公开给交互层。 */
(function () {
  'use strict';
  const C = { gold: '#ffc94a', blue: '#72d8f4', red: '#ff947a', green: '#8adcb1', text: '#e9f1f4', muted: '#9cb1bf' };
  function layout(q, width = 480) {
    const unit = Math.min(210, 248 - 135 * Math.sin(q.a) - 22 * Math.cos(q.a), (width - 205) / Math.max(2.1, q.base));
    const start = { x: 60, y: 390 }, end = { x: 60 + unit * q.base, y: 390 - unit };
    const u = { x: Math.cos(q.a), y: -Math.sin(q.a) }, n = { x: -Math.sin(q.a), y: -Math.cos(q.a) };
    const box = { x: start.x + (end.x - start.x) * q.p, y: start.y + (end.y - start.y) * q.p };
    const handle = { x: end.x, y: end.y + 45 };
    return { unit, start, end, u, n, box, handle };
  }
  function render(canvas, state, q) {
    const rect = canvas.getBoundingClientRect(), dpr = Math.min(window.devicePixelRatio || 1, 2);
    if (canvas.width !== Math.round(rect.width * dpr) || canvas.height !== Math.round(rect.height * dpr)) {
      canvas.width = Math.round(rect.width * dpr); canvas.height = Math.round(rect.height * dpr);
    }
    const ctx = canvas.getContext('2d'), W = rect.width, H = rect.height;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.clearRect(0, 0, W, H);
    const wide = W > 760, vw = wide ? 900 : 480;
    const scale = Math.min(W / vw, (H - 140) / 660), ox = (W - vw * scale) / 2, oy = wide ? 24 : 68;
    ctx.translate(ox, oy); ctx.scale(scale, scale);
    function text(t, x, y, color = C.text, size = 14, align = 'left') {
      ctx.fillStyle = color; ctx.font = `${Math.max(size, 11 / scale)}px -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif`; ctx.textAlign = align; ctx.fillText(t, x, y);
    }
    function line(x, y, X, Y, color, width = 2, dash = []) {
      ctx.beginPath(); ctx.setLineDash(dash); ctx.moveTo(x, y); ctx.lineTo(X, Y); ctx.strokeStyle = color; ctx.lineWidth = width; ctx.stroke(); ctx.setLineDash([]);
    }
    function round(x, y, w, h, fill, radius = 10) { ctx.beginPath(); ctx.roundRect(x, y, w, h, radius); ctx.fillStyle = fill; ctx.fill(); }
    function arrow(x, y, X, Y, color) {
      line(x, y, X, Y, color, 3); const a = Math.atan2(Y - y, X - x);
      ctx.beginPath(); ctx.moveTo(X, Y); ctx.lineTo(X - 9 * Math.cos(a - .4), Y - 9 * Math.sin(a - .4)); ctx.lineTo(X - 9 * Math.cos(a + .4), Y - 9 * Math.sin(a + .4)); ctx.closePath(); ctx.fillStyle = color; ctx.fill();
    }
    const g = layout(q, vw), { start: b, end: e, box: p, unit, u, n } = g;
    const right = vw - 34, floor = 390;
    // 近黑实验台：细网格只提供空间参照，不代表测量精度。
    for (let x = 36; x < vw - 20; x += 40) line(x, 160, x, floor, '#111b29', 1);
    for (let y = 170; y < floor; y += 40) line(30, y, right, y, '#111b29', 1);
    const glow = ctx.createRadialGradient(vw / 2, 340, 10, vw / 2, 340, vw / 2);
    glow.addColorStop(0, '#11212d88'); glow.addColorStop(1, '#05070d00');
    round(20, 150, vw - 40, 270, glow, 16);
    line(30, floor + 10, right, floor + 10, '#435268', 2);
    round(e.x, e.y + 3, Math.max(12, right - e.x - 22), 13, '#3c4d60', 3);
    for (const x of [e.x + 18, right - 40]) {
      line(x, e.y + 16, x, floor + 8, '#263547', 9);
      line(x - 10, floor + 8, x + 10, floor + 8, '#627287', 3);
    }
    ctx.beginPath(); ctx.moveTo(b.x, b.y + 8); ctx.lineTo(e.x, e.y + 8); ctx.lineTo(e.x, floor); ctx.closePath(); ctx.fillStyle = '#17202b'; ctx.fill();
    line(b.x, b.y + 6, e.x, e.y + 6, '#6e583c', 12);
    line(b.x, b.y, e.x, e.y, q.mu ? '#dfbd80' : '#a5dce8', 4);
    // 粗糙度纹理严格贴在坡面上；没有摩擦时不画颗粒。
    if (q.mu) for (let d = 5; d < q.L * unit; d += Math.max(5, 15 - q.mu * 20)) {
      const x = b.x + d * u.x, y = b.y + d * u.y;
      line(x, y, x + n.x * 3, y + n.y * 3, '#f0cc91', 1.5);
    }
    for (let i = 0; i <= 4; i++) {
      const x = b.x + (e.x - b.x) * i / 4, y = b.y + (e.y - b.y) * i / 4;
      line(x, y + 8, x - n.x * 9, y - n.y * 9, '#8299a6', 1);
    }
    // 顶端拖把手；通过水平位置调角度，固定提升高度。
    line(e.x, e.y + 14, g.handle.x, g.handle.y, '#7895a5', 2);
    ctx.beginPath(); ctx.arc(g.handle.x, g.handle.y, state.hover === 'angle' || state.drag === 'angle' ? 17 : 14, 0, Math.PI * 2); ctx.fillStyle = C.blue; ctx.fill();
    text('↔', g.handle.x, g.handle.y + 5, '#12313b', 20, 'center');
    text('↔ 拖蓝点调坡度', right, 435, C.blue, 13, 'right');
    // 高度线跟随货箱参考点，整趟高度以淡线作对照。
    line(right - 4, floor, right - 4, floor - unit, '#304457', 1, [4, 5]);
    line(right - 4, floor, right - 4, floor - unit * q.p, C.green, 3);
    line(right - 12, floor - unit * q.p, right + 4, floor - unit * q.p, C.green, 2);
    text('H = 1 m', right - 12, floor - unit - 12, C.muted, 12, 'right');
    ctx.beginPath(); ctx.arc(b.x, b.y, 47, -q.a, 0); ctx.strokeStyle = '#72d8f477'; ctx.lineWidth = 1.5; ctx.stroke();
    text(`${q.angle.toFixed(0)}°`, b.x + 52, b.y - 6, C.blue, 13);
    // 货箱和沿斜面的拉力计一起运动，标尺不用于精密读数。
    ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(-q.a);
    if (state.hover === 'box' || state.drag === 'box') { ctx.shadowColor = C.gold; ctx.shadowBlur = 15; }
    round(-24, -43, 48, 42, '#b87d3d', 4); ctx.shadowBlur = 0;
    round(-20, -39, 40, 34, '#dda85b', 2);
    line(-18, -37, 18, -7, '#8e6032', 3); line(-18, -7, 18, -37, '#8e6032', 3);
    round(-4, -43, 8, 42, '#e8c279', 1);
    line(24, -22, 40, -22, C.gold, 2);
    round(40, -33, 89, 22, '#b4cbd5', 5); round(45, -29, 60, 14, '#223b48', 2);
    const extension = 11 + q.F / 280 * 42;
    ctx.beginPath(); ctx.moveTo(46, -22); for (let i = 0; i < 13; i++) ctx.lineTo(46 + extension * i / 12, -22 + (i % 2 ? 5 : -5)); ctx.lineWidth = 1.5; ctx.strokeStyle = C.gold; ctx.stroke();
    line(46 + extension, -22, 120, -22, C.gold, 2);
    ctx.beginPath(); ctx.arc(135, -22, 7, 0, Math.PI * 2); ctx.strokeStyle = '#c9dde7'; ctx.stroke();
    ctx.restore();
    text('沿坡拉力 F', 32, 91, C.muted, 12);
    text(`${q.F.toFixed(1)} N`, 32, 119, C.gold, wide ? 18 : 20);
    text('机械效率 η', vw / 2, 91, C.muted, 12, 'center');
    text(`${(q.eta * 100).toFixed(1)}%`, vw / 2, 119, C.green, wide ? 18 : 20, 'center');
    text('全坡长 L', right, 91, C.muted, 12, 'right');
    text(`${q.L.toFixed(2)} m`, right, 119, C.text, wide ? 18 : 20, 'right');
    // 同比例受力矢量，全部从箱体中心出发。
    if (state.forces) {
      const x = p.x + n.x * 22, y = p.y + n.y * 22;
      // 受力共用比例，临近上下边界时收紧，避开主读数与路程标注。
      const k = Math.min(.45, (418 - y) / q.G, (y - 148) / Math.max(q.N * Math.cos(q.a), q.F * Math.sin(q.a)));
      arrow(x, y, x, y + q.G * k, C.red);
      arrow(x, y, x + n.x * q.N * k, y + n.y * q.N * k, C.green);
      arrow(x, y, x + u.x * q.F * k, y + u.y * q.F * k, C.gold);
      if (q.friction) arrow(x, y, x - u.x * q.friction * k, y - u.y * q.friction * k, C.blue);
    }
    text('斜面装货实验', 30, 28, C.text, wide ? 18 : 20);
    text(state.play ? '● 匀速上拉中' : state.p >= 1 ? '● 已到坡顶' : '● 拖货箱，观察功的变化', right, 28, state.play ? C.green : C.muted, 12, 'right');
    text('相同提升高度，省力会省功吗？', 30, 52, C.muted, 13);
    text(`沿坡 s  ${q.distance.toFixed(2)} m`, 32, 435, C.gold, 15);
    text(`竖直升高 h  ${q.height.toFixed(2)} m`, 32, 461, C.green, 15);
    // 三项功共用整趟输入功刻度，颜色与物理含义一一对应。
    round(22, 490, vw - 44, 158, '#101722', 12);
    text('功的去向', 38, 516, C.text, 15);
    text('输入 = 抬高 + 克服摩擦', right - 6, 516, C.muted, 12, 'right');
    const fullInput = q.F * q.L, maxWidth = vw - 210;
    const rows = [['输入功', q.input, C.gold], ['有用功', q.useful, C.green], ['额外功', q.loss, C.red]];
    rows.forEach((r, i) => {
      const y = 543 + i * 32; text(r[0], 38, y + 4, C.muted, 12);
      round(106, y - 8, maxWidth, 12, '#202c3d', 3);
      if (r[1] > 0) round(106, y - 8, Math.max(.1, r[1] / fullInput * maxWidth), 12, r[2], 3);
      text(`${r[1].toFixed(1)} J`, right - 6, y + 4, r[2], 13, 'right');
    });
    text('从坡底起算 · 暂停保留匀速上拉条件', vw / 2, 634, C.muted, 11, 'center');
    return { ...g, scale, ox, oy };
  }
  function point(event, canvas, geo) {
    const r = canvas.getBoundingClientRect(); return { x: (event.clientX - r.left - geo.ox) / geo.scale, y: (event.clientY - r.top - geo.oy) / geo.scale };
  }
  function hit(p, g, q) {
    if (Math.hypot(p.x - g.handle.x, p.y - g.handle.y) < 28) return 'angle';
    const dx = p.x - g.box.x, dy = p.y - g.box.y;
    const along = dx * g.u.x + dy * g.u.y, up = dx * g.n.x + dy * g.n.y;
    return along > -36 && along < 146 && up > -8 && up < 55 ? 'box' : '';
  }
  window.InclineDraw = { layout, render, point, hit };
}());
