(function () {
  'use strict';
  const $ = id => document.getElementById(id), url = new URLSearchParams(location.search);
  const scene = Incline.presets[url.get('scene')] ? url.get('scene') : 'rough', preset = Incline.presets[scene];
  const state = { ...Incline.clean({ scene, angle: url.get('angle') ?? preset.angle, mu: url.get('mu') ?? preset.mu,
    mass: url.get('mass'), p: url.get('p') }), play: url.get('play') === '1', forces: url.get('forces') === '1', hover: '', drag: '', records: [] };
  if (matchMedia('(max-width:760px)').matches) $('panel').classList.add('collapsed');
  const canvas = $('incline'); let geometry, last = 0, dragOffset = 0;
  const track = (action, value) => { if (window.Analytics) Analytics.track('斜面与机械效率', action, String(value ?? state.scene)); };
  const fmt = (v, n = 2) => v.toFixed(n);
  function solve() { return Incline.solve(state); }
  function update() {
    Object.assign(state, Incline.clean(state)); const q = solve();
    ['angle', 'mu', 'mass', 'p'].forEach(k => { $(k).value = state[k]; });
    $('angleOut').textContent = fmt(q.angle, 1) + '°'; $('muOut').textContent = fmt(q.mu);
    $('massOut').textContent = fmt(q.mass, 1) + ' kg'; $('pOut').textContent = fmt(q.p * 100, 0) + '%';
    $('reading').textContent = `拉力 ${fmt(q.F, 1)} N`;
    $('weight').textContent = `${fmt(q.G, 1)} N`;
    $('distance').textContent = `${fmt(q.distance)} m / ${fmt(q.height)} m`;
    $('friction').textContent = `${fmt(q.friction, 1)} N`;
    $('efficiency').textContent = `${fmt(q.eta * 100, 1)}%`;
    $('work').textContent = `${fmt(q.input, 1)} = ${fmt(q.useful, 1)} + ${fmt(q.loss, 1)} J`;
    $('equation').textContent = q.saving ? '现在省力；沿坡路程比竖直提升更长。' : '摩擦较大，此条件下连力也不省。';
    $('play').textContent = state.play ? '❚❚ 暂停' : '▶ 匀速上拉'; $('forces').checked = state.forces;
    $('forceLegend').hidden = !state.forces;
    $('stagePlay').textContent = $('play').textContent;
    $('play').setAttribute('aria-pressed', String(state.play));
    $('stagePlay').setAttribute('aria-pressed', String(state.play));
    document.querySelectorAll('[data-scene]').forEach(b => { b.classList.toggle('on', b.dataset.scene === state.scene); b.setAttribute('aria-pressed', String(b.dataset.scene === state.scene)); });
    geometry = InclineDraw.render(canvas, state, q);
  }
  function setScene(name) {
    if (!Incline.presets[name]) return;
    Object.assign(state, Incline.presets[name], { scene: name, p: .4, play: false }); update(); track('切换预设', name);
  }
  document.querySelectorAll('[data-scene]').forEach(b => b.addEventListener('click', () => setScene(b.dataset.scene)));
  ['angle', 'mu', 'mass', 'p'].forEach(k => {
    $(k).addEventListener('input', () => { state[k] = Number($(k).value); state.play = false; update(); });
    $(k).addEventListener('change', () => track('调节' + k, state[k]));
  });
  $('play').onclick = () => { if (state.p >= 1) state.p = 0; state.play = !state.play; update(); track('演示', state.play); };
  $('reset').onclick = () => { state.p = 0; state.play = false; update(); track('回起点'); };
  $('stagePlay').onclick = () => $('play').click();
  $('stageReset').onclick = () => $('reset').click();
  $('forces').onchange = () => { state.forces = $('forces').checked; update(); track('受力图', state.forces); };
  function records() {
    $('records').replaceChildren();
    state.records.forEach((q, i) => {
      const p = document.createElement('p'); p.textContent = `${i + 1}. ${fmt(q.angle, 1)}° / μ=${fmt(q.mu)} / ${fmt(q.mass, 0)}kg：F=${fmt(q.F, 1)}N，η=${fmt(q.eta * 100, 1)}%，s=${fmt(q.distance)}m，h=${fmt(q.height)}m`; $('records').append(p);
    });
  }
  $('record').onclick = () => { state.records.push(solve()); if (state.records.length > 8) state.records.shift(); records(); track('记录'); };
  $('clear').onclick = () => { state.records = []; records(); };
  function link() {
    const u = new URL(location.href); u.search = ''; u.hash = '';
    ['scene', 'angle', 'mu', 'mass', 'p'].forEach(k => u.searchParams.set(k, typeof state[k] === 'number' ? String(Number(state[k].toFixed(5))) : state[k]));
    u.searchParams.set('forces', state.forces ? '1' : '0'); u.searchParams.set('play', '0'); return u.href;
  }
  $('share').onclick = async () => {
    const value = link(); try { await navigator.clipboard.writeText(value); $('shareNote').textContent = '已复制，打开时暂停在当前条件。'; }
    catch { $('shareNote').textContent = value; } track('分享');
  };
  $('panelToggle').onclick = () => { const open = !$('panel').classList.toggle('collapsed'); $('panelToggle').setAttribute('aria-expanded', String(open)); };
  canvas.addEventListener('pointerdown', e => {
    const q = solve(), p = InclineDraw.point(e, canvas, geometry), hit = InclineDraw.hit(p, geometry, q);
    if (!hit) return;
    e.preventDefault(); state.drag = hit; state.play = false; canvas.setPointerCapture(e.pointerId);
    dragOffset = hit === 'angle' ? p.x - geometry.handle.x : ((p.x - geometry.start.x) * geometry.u.x + (p.y - geometry.start.y) * geometry.u.y) / (geometry.unit * q.L) - state.p;
    update();
  });
  canvas.addEventListener('pointermove', e => {
    const p = InclineDraw.point(e, canvas, geometry), q = solve();
    if (state.drag === 'box') state.p = Math.max(0, Math.min(1, ((p.x - geometry.start.x) * geometry.u.x + (p.y - geometry.start.y) * geometry.u.y) / (geometry.unit * q.L) - dragOffset));
    if (state.drag === 'angle') {
      // 画面尺度随缓坡适配；拖动用起始像素差映射角度，避免比例变化反馈。
      state.angle = Math.max(12, Math.min(55, dragAngle + (dragX - e.clientX) / geometry.scale * .16));
    }
    state.hover = state.drag || InclineDraw.hit(p, geometry, q); canvas.style.cursor = state.drag ? 'grabbing' : state.hover ? 'grab' : 'default'; update();
  });
  let dragAngle = 0, dragX = 0;
  canvas.addEventListener('pointerdown', e => { dragAngle = state.angle; dragX = e.clientX; });
  function release() { if (state.drag) track('画面拖动', state.drag); state.drag = ''; update(); }
  canvas.addEventListener('pointerup', release); canvas.addEventListener('pointercancel', release);
  canvas.addEventListener('pointerleave', () => { if (!state.drag) { state.hover = ''; update(); } });
  window.addEventListener('resize', update);
  document.addEventListener('keydown', e => { if (e.code === 'Space' && !/INPUT|BUTTON|SELECT|TEXTAREA/.test(document.activeElement.tagName)) { e.preventDefault(); $('play').click(); } });
  function frame(t) {
    const dt = Math.min((t - last) / 1000 || 0, .05); last = t;
    if (state.play && !state.drag) { state.p = Math.min(1, state.p + .32 * dt / solve().L); if (state.p >= 1) state.play = false; }
    update(); requestAnimationFrame(frame);
  }
  window.__model = { state, solve, update, setScene, link, setProgress(p) { state.p = p; state.play = false; update(); } };
  update(); requestAnimationFrame(frame);
}());
