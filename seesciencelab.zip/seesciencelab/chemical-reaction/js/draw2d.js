// 2D 绘制：化学方程式与步骤条、反应容器里的分子 / 原子动画、底部的“反应前 | 原子 | 反应后”计数条、练习题的微观示意图
// 进度 t ∈ [0, 3]：0→1 分子拉开成原子，1→2 原子移到生成物分子的位置，2→3 原子靠拢结合成新分子；水的蒸发只是分子间隔变大
(function () {
  var M = window.Micro, EL = M.EL, MOL = M.MOL;
  var MUTED = '#8d99ab', TEXT = '#e6ebf2', LINE = '#2a3446', GOLD = '#ffc94a', HOT = '#ff9a4a';
  var FONT = '-apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", sans-serif';
  var TAU = Math.PI * 2, SPREAD = 1.85;

  function font(px, w) { return (w ? w + ' ' : '') + px + 'px ' + FONT; }
  function label(ctx, s, x, y, o) {
    o = o || {};
    ctx.font = font(o.size || 12, o.bold ? 600 : null);
    ctx.textAlign = o.align || 'center'; ctx.textBaseline = o.base || 'middle';
    ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(5,7,13,.85)'; ctx.strokeText(s, x, y);
    ctx.fillStyle = o.color || TEXT; ctx.fillText(s, x, y);
  }
  function rrect(ctx, x, y, w, h, r) {
    ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
  }
  function ease(x) { x = Math.max(0, Math.min(1, x)); return x * x * (3 - 2 * x); }
  function hash(n) { var x = Math.sin(n * 127.1 + 311.7) * 43758.5453; return x - Math.floor(x); }
  function shade(hex, k) {
    var n = parseInt(hex.slice(1), 16), r = n >> 16, g = (n >> 8) & 255, b = n & 255;
    function c(v) { return Math.round(k > 0 ? v + (255 - v) * k : v * (1 + k)); }
    return 'rgb(' + c(r) + ',' + c(g) + ',' + c(b) + ')';
  }
  // 一个原子：带高光的小球，可写元素符号
  function atom(ctx, el, x, y, r, o) {
    var E = EL[el], g = ctx.createRadialGradient(x - r * 0.35, y - r * 0.4, r * 0.1, x, y, r);
    g.addColorStop(0, shade(E.c, 0.55)); g.addColorStop(0.55, E.c); g.addColorStop(1, shade(E.c, -0.45));
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill();
    ctx.strokeStyle = 'rgba(0,0,0,.5)'; ctx.lineWidth = 0.8; ctx.stroke();
    if (o && o.letters && r >= 7) {
      ctx.font = font(Math.round(r * (el.length > 1 ? 0.78 : 0.95)), 600);
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillStyle = el === 'C' || el === 'N' ? '#f2f5fa' : '#1a2130';
      ctx.fillText(el, x, y + r * 0.04);
    }
  }
  // 小图标：一个分子（用于图例和计数条）
  function molIcon(ctx, id, x, y, r) {
    MOL[id].atoms.forEach(function (a) { atom(ctx, a[0], x + a[1] * r, y + a[2] * r, EL[a[0]].r * r); });
  }
  function molWidth(id) {
    var lo = 0, hi = 0;
    MOL[id].atoms.forEach(function (a) { lo = Math.min(lo, a[1] - EL[a[0]].r); hi = Math.max(hi, a[1] + EL[a[0]].r); });
    return { lo: lo, hi: hi };
  }

  // ---------- 格位：N 个分子在框里排成网格，带一点确定的抖动 ----------
  function grid(N, box, packed) {
    // 选列数使格子最大
    var cols = 1, cell = 0;
    for (var cc = 1; cc <= Math.max(1, N); cc++) {
      var ce = Math.min(box.w / cc, box.h / Math.ceil(N / cc));
      if (ce > cell + 0.5) { cell = ce; cols = cc; }
    }
    var rows = Math.ceil(N / cols), out = [];
    var r = Math.min(cell * 0.165, 34);
    if (packed) {
      // 液态：紧挨着堆在框底
      var pc = Math.max(1, Math.ceil(Math.sqrt(N * 2.2))), pr = Math.ceil(N / pc), s = r * 2.9;
      for (var k = 0; k < N; k++) {
        var i = k % pc, j = Math.floor(k / pc);
        out.push({ x: box.x + box.w / 2 + (i - (pc - 1) / 2) * s + (j % 2 ? s * 0.25 : -s * 0.25), y: box.y + box.h - 14 - r * 1.4 - j * s * 0.86, a: (hash(k + 5) - 0.5) * 3 });
      }
      return { pos: out, r: r, cell: cell, top: box.y + box.h - 14 - r * 1.4 - (pr - 1) * s * 0.86 - r * 1.8 };
    }
    var ox = box.x + (box.w - cell * cols) / 2, oy = box.y + (box.h - cell * rows) / 2;
    for (var n = 0; n < N; n++) {
      var c = n % cols, w = Math.floor(n / cols);
      // 最后一行居中
      var inRow = w === rows - 1 ? N - cols * (rows - 1) : cols, shift = (cols - inRow) * cell / 2;
      out.push({ x: ox + shift + (c + 0.5) * cell + (hash(n) - 0.5) * cell * 0.22, y: oy + (w + 0.5) * cell + (hash(n + 50) - 0.5) * cell * 0.18,
        a: (hash(n + 99) - 0.5) * 1.3 });
    }
    return { pos: out, r: r, cell: cell };
  }

  // 每个原子在进度 t 的位置；wob 为热运动的小抖动
  function atomPos(p, G, Gb, x, t, now) {
    var r = G.r;
    function at(list, Gx, idx, k, sp) {
      var m = list[idx[0]], P = Gx.pos[m.slot], d = MOL[m.m].atoms[idx[1]], c = Math.cos(P.a), s = Math.sin(P.a);
      var w = Math.sin(now * 1.7 + m.slot * 2.1) * r * 0.25, v = Math.cos(now * 1.3 + m.slot * 1.3) * r * 0.25;
      return { x: P.x + (d[1] * c - d[2] * s) * r * sp + w * k, y: P.y + (d[1] * s + d[2] * c) * r * sp + v * k };
    }
    if (p.rx.phys) {
      var e = ease(t / 3), A = at(p.before, Gb, x.b, 1, 1), B = at(p.after, G, x.a, 1 + 2 * e, 1);
      return { x: A.x + (B.x - A.x) * e, y: A.y + (B.y - A.y) * e };
    }
    if (x.left) return at(p.before, G, x.b, 1, 1);
    if (t <= 1) return at(p.before, G, x.b, 1, 1 + (SPREAD - 1) * ease(t));
    if (t >= 2) return at(p.after, G, x.a, 1, SPREAD - (SPREAD - 1) * ease(t - 2));
    var a = at(p.before, G, x.b, 1, SPREAD), b = at(p.after, G, x.a, 1, SPREAD), f = ease(t - 1);
    // 走一点弧线，避免原子全挤在直线上
    var mx = (a.x + b.x) / 2, my = (a.y + b.y) / 2, dx = b.x - a.x, dy = b.y - a.y, bend = 0.18 * Math.sin(f * Math.PI);
    return { x: a.x + dx * f - dy * bend, y: a.y + dy * f + dx * bend, mx: mx, my: my };
  }

  // 一个框里的微观图：t 为进度，o.letters / o.labels / o.marks（剩余分子标注）/ o.glow
  function drawBox(ctx, p, box, t, now, o) {
    var G = grid(p.N, box, false), Gb = p.rx.phys ? grid(p.N, box, true) : G, r = G.r;
    if (p.rx.phys) {
      // 液面：随蒸发变淡
      var a = 1 - ease(t / 2.2);
      if (a > 0.01) {
        ctx.fillStyle = 'rgba(79,160,255,' + (0.16 * a) + ')';
        ctx.fillRect(box.x + 4, Gb.top, box.w - 8, box.y + box.h - 4 - Gb.top);
        ctx.strokeStyle = 'rgba(111,182,255,' + (0.7 * a) + ')'; ctx.lineWidth = 1.2;
        ctx.beginPath(); ctx.moveTo(box.x + 4, Gb.top); ctx.lineTo(box.x + box.w - 4, Gb.top); ctx.stroke();
      }
    }
    // 反应时的“能量”光晕
    if (o.glow && !p.rx.phys && t > 0.02 && t < 1.4) {
      var ga = Math.sin(Math.min(1, t / 1.4) * Math.PI) * 0.45;
      p.before.forEach(function (m) {
        if (m.left) return;
        var P = G.pos[m.slot], g = ctx.createRadialGradient(P.x, P.y, 0, P.x, P.y, G.cell * 0.42);
        g.addColorStop(0, 'rgba(255,154,74,' + (ga * 0.55) + ')'); g.addColorStop(1, 'rgba(255,154,74,0)');
        ctx.fillStyle = g; ctx.beginPath(); ctx.arc(P.x, P.y, G.cell * 0.42, 0, TAU); ctx.fill();
      });
    }
    // 剩余分子：虚线圈
    if (o.marks && t > 0.4 && !p.rx.phys) {
      var la = Math.min(1, (t - 0.4) / 0.4);
      p.before.forEach(function (m) {
        if (!m.left) return;
        var P = G.pos[m.slot], w = molWidth(m.m), rr = Math.max(w.hi - w.lo, 2.2) * r * 0.62 + 6;
        ctx.globalAlpha = la; ctx.setLineDash([4, 4]); ctx.strokeStyle = MUTED; ctx.lineWidth = 1.2;
        ctx.beginPath(); ctx.arc(P.x, P.y, rr, 0, TAU); ctx.stroke(); ctx.setLineDash([]);
        label(ctx, '没有参加反应', P.x, P.y + rr + 9, { size: 11, color: MUTED });
        ctx.globalAlpha = 1;
      });
    }
    // 绘制顺序：前半程按反应物分子，后半程按生成物分子（分子内后画的原子在上层）
    var key = t < 1.5 ? 'b' : 'a';
    var list = p.atoms.map(function (x) { var q = atomPos(p, G, Gb, x, t, now); return { el: x.el, x: q.x, y: q.y, k: x[key][0] * 10 + x[key][1] }; });
    list.sort(function (u, v) { return u.k - v.k; });
    list.forEach(function (q) { atom(ctx, q.el, q.x, q.y, EL[q.el].r * r, o); });
    // 化学式标签：只在完整分子（反应前 / 反应后）时显示
    if (o.labels) {
      var showB = p.rx.phys ? 1 - ease(t * 4) : 1 - ease(t * 3), showA = p.rx.phys ? ease((t - 2.4) * 2) : ease((t - 2.5) * 2.5);
      [[p.before, showB, Gb], [p.after, showA, G]].forEach(function (pair) {
        if (pair[1] < 0.02) return;
        ctx.globalAlpha = pair[1];
        pair[0].forEach(function (m) {
          if (m.left && pair[0] === p.after && !p.rx.phys) return;
          var P = pair[2].pos[m.slot], w = molWidth(m.m);
          var yy = P.y + Math.max(1.75, (w.hi - w.lo) * 0.45) * r + 10 + Math.cos(now * 1.3 + m.slot * 1.3) * r * 0.25;
          if (o.marks && m.left && t > 0.4) return;
          label(ctx, MOL[m.m].f, P.x + Math.sin(now * 1.7 + m.slot * 2.1) * r * 0.25, yy, { size: 13, color: '#cfd6e0' });
        });
        ctx.globalAlpha = 1;
      });
    }
    return G;
  }

  // 化学方程式：条件写在等号上方；hl 0 反应物高亮、1 生成物高亮
  function drawEq(ctx, id, cx, y, size, hl) {
    var rx = M.RX[id], text = M.equation(id);
    var parts = rx.phys ? ['H₂O（液）', '', 'H₂O（气）'] : text.split(/ =(.*)= /);
    ctx.font = font(size, 600);
    var wl = ctx.measureText(parts[0]).width, wr = ctx.measureText(parts[2]).width;
    ctx.font = font(Math.round(size * 0.6));
    var wc = Math.max(ctx.measureText(parts[1]).width + 12, size * 1.8);
    var gap = size * 0.4, total = wl + wr + wc + gap * 2, x = cx - total / 2;
    label(ctx, parts[0], x, y, { size: size, bold: true, align: 'left', color: hl === 0 ? GOLD : TEXT });
    var ex = x + wl + gap;
    ctx.strokeStyle = TEXT; ctx.lineWidth = 1.6;
    if (rx.phys) {
      ctx.beginPath(); ctx.moveTo(ex, y); ctx.lineTo(ex + wc - 2, y); ctx.stroke();
      ctx.fillStyle = TEXT; ctx.beginPath(); ctx.moveTo(ex + wc, y); ctx.lineTo(ex + wc - 8, y - 4); ctx.lineTo(ex + wc - 8, y + 4); ctx.fill();
      label(ctx, '吸热', ex + wc / 2, y - size * 0.55, { size: Math.round(size * 0.6), color: HOT });
    } else {
      ctx.beginPath(); ctx.moveTo(ex, y - 2.5); ctx.lineTo(ex + wc, y - 2.5); ctx.moveTo(ex, y + 2.5); ctx.lineTo(ex + wc, y + 2.5); ctx.stroke();
      label(ctx, parts[1], ex + wc / 2, y - size * 0.62, { size: Math.round(size * 0.6), color: HOT });
    }
    label(ctx, parts[2], ex + wc + gap, y, { size: size, bold: true, align: 'left', color: hl === 1 ? GOLD : TEXT });
    return total;
  }

  // 步骤条：当前步骤 cur（0–3），moving 表示正在动画
  function drawSteps(ctx, names, cx, y, cur, narrow) {
    var sz = narrow ? 11 : 13, padX = narrow ? 6 : 10, arrow = narrow ? 12 : 22, rects = [];
    ctx.font = font(sz, 600);
    var ws = names.map(function (n, i) { return ctx.measureText((narrow ? '' : '①②③④'[i] + ' ') + n).width + padX * 2; });
    var total = ws.reduce(function (a, b) { return a + b; }, 0) + arrow * 3, x = cx - total / 2, h = sz + 12;
    names.forEach(function (n, i) {
      var on = i === cur, done = i < cur;
      rrect(ctx, x, y - h / 2, ws[i], h, h / 2);
      ctx.fillStyle = on ? 'rgba(255,201,74,.18)' : 'rgba(17,23,35,.85)'; ctx.fill();
      ctx.strokeStyle = on ? GOLD : done ? '#5a6a80' : LINE; ctx.lineWidth = 1.2; ctx.stroke();
      label(ctx, (narrow ? '' : '①②③④'[i] + ' ') + n, x + ws[i] / 2, y + 0.5, { size: sz, bold: on, color: on ? GOLD : done ? '#cfd6e0' : MUTED });
      rects.push({ x: x, y: y - h / 2, w: ws[i], h: h, i: i });
      x += ws[i];
      if (i < 3) {
        ctx.strokeStyle = MUTED; ctx.lineWidth = 1.2;
        ctx.beginPath(); ctx.moveTo(x + 4, y); ctx.lineTo(x + arrow - 4, y); ctx.lineTo(x + arrow - 8, y - 3); ctx.moveTo(x + arrow - 4, y); ctx.lineTo(x + arrow - 8, y + 3); ctx.stroke();
        x += arrow;
      }
    });
    return rects;
  }

  // 计数条：反应前分子 | 原子 | 反应后分子；col 为当前高亮的一栏
  function drawTally(ctx, p, st, box, col, narrow) {
    var cw = box.w / 3, cols = [
      { title: p.rx.phys ? '液态水' : '反应前（分子）', items: Object.keys(st.molB).map(function (k) { return { m: k, n: st.molB[k], left: p.rx.phys ? 0 : leftOf(p, k) }; }) },
      { title: p.rx.phys ? '原子（没有拆开）' : '原子（种类、数目不变）', atoms: true, items: Object.keys(st.atomB).map(function (k) { return { el: k, n: st.atomB[k] }; }) },
      { title: p.rx.phys ? '水蒸气' : '反应后（分子）', items: Object.keys(st.molA).map(function (k) { return { m: k, n: st.molA[k], left: p.rx.phys ? 0 : leftOf(p, k) }; }) }
    ];
    var ir = narrow ? 6.5 : 9;
    cols.forEach(function (c, i) {
      var x = box.x + i * cw + 3, on = i === col;
      rrect(ctx, x, box.y, cw - 6, box.h, 8);
      ctx.fillStyle = on ? 'rgba(255,201,74,.10)' : 'rgba(17,23,35,.75)'; ctx.fill();
      ctx.strokeStyle = on ? GOLD : LINE; ctx.lineWidth = 1; ctx.stroke();
      label(ctx, narrow ? c.title.replace(/（.*）/, '') : c.title, x + (cw - 6) / 2, box.y + 12, { size: narrow ? 11 : 12, color: on ? GOLD : MUTED, bold: on });
      // 条目：图标 + ×n，放不下就换行
      var lineH = narrow ? 24 : 30, y = box.y + 28 + lineH / 2, xx = x + 8, maxX = x + cw - 14;
      ctx.font = font(narrow ? 12 : 14, 600);
      c.items.forEach(function (it) {
        var w0, t = '×' + it.n + (it.left ? '（剩 ' + it.left + '）' : '');
        if (it.el) { w0 = EL[it.el].r * ir * 2; }
        else { var mw = molWidth(it.m); w0 = (mw.hi - mw.lo) * ir; }
        var need = w0 + 4 + ctx.measureText(t).width + 12;
        if (xx + need > maxX && xx > x + 8) { xx = x + 8; y += lineH; }
        if (y > box.y + box.h - 6) return;
        if (it.el) atom(ctx, it.el, xx + w0 / 2, y, EL[it.el].r * ir, {});
        else molIcon(ctx, it.m, xx - molWidth(it.m).lo * ir, y, ir);
        label(ctx, t, xx + w0 + 4, y, { size: narrow ? 12 : 14, align: 'left', color: TEXT, bold: true });
        ctx.font = font(narrow ? 12 : 14, 600);
        xx += need;
      });
    });
  }
  function leftOf(p, m) {
    var n = 0;
    p.rx.r.forEach(function (s, i) { if (s[0] === m) n += p.left[i]; });
    return n;
  }

  // 原子图例：“● H 氢原子”
  function legend(ctx, els, x, y, maxW, o) {
    var sz = 12, r = 6.5, xx = x, items = els.map(function (k) { return { k: k, t: (o && o.quiz ? '表示' : k + ' ') + EL[k].name + '原子' }; });
    ctx.font = font(sz);
    var total = items.reduce(function (s, it) { return s + r * 2 + 6 + ctx.measureText(it.t).width + 16; }, -16);
    if (o && o.center) xx = x + (maxW - total) / 2;
    items.forEach(function (it) {
      atom(ctx, it.k, xx + r, y, EL[it.k].r / 0.92 * r, {});
      label(ctx, it.t, xx + r * 2 + 6, y, { size: sz, align: 'left', color: '#cfd6e0' });
      ctx.font = font(sz);
      xx += r * 2 + 6 + ctx.measureText(it.t).width + 16;
    });
  }
  function elsOf(p) {
    var o = [];
    p.before.forEach(function (m) { MOL[m.m].atoms.forEach(function (a) { if (o.indexOf(a[0]) < 0) o.push(a[0]); }); });
    var keys = Object.keys(EL);
    return o.sort(function (a, b) { return keys.indexOf(a) - keys.indexOf(b); });
  }

  // ---------- 视图 ----------
  function View(canvas) {
    var ctx = canvas.getContext('2d'), W = 0, H = 0, dpr = 1, narrow = false, steps = [], boxRect = null;
    function resize(w, h) {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      W = w; H = h; narrow = w < 640;
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
      canvas.style.width = w + 'px'; canvas.style.height = h + 'px';
    }
    function bg() {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      var g = ctx.createLinearGradient(0, 0, 0, H);
      g.addColorStop(0, '#04060c'); g.addColorStop(1, '#0a1120');
      ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    }
    function vessel(b) {
      rrect(ctx, b.x, b.y, b.w, b.h, 14);
      ctx.fillStyle = 'rgba(13,20,34,.7)'; ctx.fill();
      ctx.strokeStyle = '#33405a'; ctx.lineWidth = 1.4; ctx.stroke();
    }
    // state: plan, stats, t, now, letters, labels
    function drawSim(s) {
      bg();
      var p = s.plan, rx = p.rx, side = narrow ? 10 : 24;
      var eqY = narrow ? 96 : 66, stepY = narrow ? 128 : 106, size = narrow ? 17 : 24;
      var cur = s.t < 0.001 ? 0 : Math.min(3, Math.ceil(s.t - 1e-6));
      drawEq(ctx, p.id, W / 2, eqY, size, cur === 0 ? 0 : cur === 3 ? 1 : -1);
      steps = drawSteps(ctx, M.phaseNames(p.id), W / 2, stepY, cur, narrow);
      var tallyH = narrow ? 84 : 92, bottom = narrow ? 48 : 54;
      var top = stepY + (narrow ? 20 : 26), legH = 24;
      var b = { x: side, y: top, w: W - side * 2, h: H - top - bottom - tallyH - legH - 10 };
      boxRect = b;
      vessel(b);
      var inner = { x: b.x + 10, y: b.y + 10, w: b.w - 20, h: b.h - 30 };
      if (p.U || rx.phys) drawBox(ctx, p, inner, s.t, s.now, { letters: s.letters, labels: s.labels, marks: true, glow: true });
      else {
        drawBox(ctx, p, inner, 0, s.now, { letters: s.letters, labels: s.labels, marks: false });
        label(ctx, '分子个数不够一组，不能反应', b.x + b.w / 2, b.y + 22, { size: 13, color: '#ff7a59' });
      }
      if (rx.cond && !narrow) label(ctx, '条件：' + (rx.cond === '△' ? '加热（△）' : rx.cond === 'MnO₂' ? 'MnO₂ 作催化剂' : rx.cond), b.x + 14, b.y + 16, { size: 12, align: 'left', color: HOT });
      legend(ctx, elsOf(p), b.x, b.y + b.h + legH / 2 + 4, b.w, { center: true });
      var col = cur === 0 ? 0 : cur === 3 ? 2 : 1;
      drawTally(ctx, p, s.stats, { x: b.x, y: b.y + b.h + legH + 10, w: b.w, h: tallyH }, col, narrow);
    }
    // 练习：反应前 → 反应后两框，原子图例在上
    function drawQuiz(q, answered, o) {
      bg();
      if (!q) return;
      var p = q.plan, top = narrow ? 96 : 60, bottom = (o.quizH || 150) + 60;
      legend(ctx, elsOf(p), 0, top, W, { center: true, quiz: true });
      var arrowW = narrow ? 52 : 90, side = narrow ? 8 : 30;
      var bw = (W - side * 2 - arrowW) / 2, bh = Math.max(120, Math.min(H - top - 30 - bottom, bw * (narrow ? 1.5 : 0.9))), by = top + 22;
      var b1 = { x: side, y: by, w: bw, h: bh }, b2 = { x: side + bw + arrowW, y: by, w: bw, h: bh };
      [b1, b2].forEach(function (b, i) {
        vessel(b);
        label(ctx, i ? '反应后' : '反应前', b.x + b.w / 2, b.y + b.h + 14, { size: 12, color: MUTED });
        drawBox(ctx, p, { x: b.x + 8, y: b.y + 8, w: b.w - 16, h: b.h - 16 }, i ? 3 : 0, 0, { letters: false, labels: false, marks: answered });
      });
      var ax = side + bw + 8, ay = by + bh / 2, aw = arrowW - 16;
      ctx.strokeStyle = TEXT; ctx.lineWidth = 1.6;
      ctx.beginPath(); ctx.moveTo(ax, ay); ctx.lineTo(ax + aw, ay); ctx.lineTo(ax + aw - 7, ay - 4); ctx.moveTo(ax + aw, ay); ctx.lineTo(ax + aw - 7, ay + 4); ctx.stroke();
      label(ctx, p.rx.cond, ax + aw / 2, ay - 12, { size: 12, color: HOT });
    }
    // 点在步骤条上 → 步骤序号；点在容器里 → 'box'
    function hit(x, y) {
      for (var i = 0; i < steps.length; i++) { var r = steps[i]; if (x >= r.x && x <= r.x + r.w && y >= r.y - 4 && y <= r.y + r.h + 4) return r.i; }
      if (boxRect && x >= boxRect.x && x <= boxRect.x + boxRect.w && y >= boxRect.y && y <= boxRect.y + boxRect.h) return 'box';
      return null;
    }
    return { resize: resize, drawSim: drawSim, drawQuiz: drawQuiz, hit: hit };
  }

  window.MicroDraw = { View: View };
})();
