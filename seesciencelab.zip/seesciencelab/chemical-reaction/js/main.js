(function () {
  var M = window.Micro, D = window.MicroDraw;
  var $ = function (id) { return document.getElementById(id); };
  var qa = function (sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); };
  var NAME = '化学反应的微观过程';
  var RATE = 0.7;   // 每秒推进的步数（1× 速度）
  var HOLD = 1.1;   // 自动播放时每一步停留的秒数

  var state = {
    scene: 'sim', rx: 'h2', counts: M.defaults('h2'), plan: null, stats: null,
    t: 0, target: 0, playing: false, hold: 0, speed: 1, letters: true, labels: true, now: 0,
    quiz: null, quizOnly: null, answered: false, correct: false, choice: null, score: { n: 0, ok: 0 }
  };
  var HINTS = {
    sim: '点“播放”或点容器，一步一步看分子怎样分成原子、原子怎样重新组合',
    quiz: '化学反应的微观示意图 · 判断练习'
  };

  var stage = $('stage'), panel = $('panel'), cv = $('view');
  var view = D.View(cv);
  function setSeg(attr, val) { qa('[data-' + attr + ']').forEach(function (b) { b.classList.toggle('on', b.dataset[attr] === String(val)); }); }

  // ---------- 反应与分子数 ----------
  function rebuild() {
    state.plan = M.plan(state.rx, state.counts);
    state.stats = M.stats(state.plan);
  }
  function setRx(id, counts) {
    state.rx = id;
    state.counts = counts || M.defaults(id);
    rebuild(); buildCounts();
    state.t = 0; state.target = 0; state.playing = false;
    syncUI();
  }
  function buildCounts() {
    var rx = M.RX[state.rx], box = $('counts'), html = '';
    rx.r.forEach(function (s, i) {
      var lo = rx.phys ? 4 : 1, hi = rx.phys ? 16 : M.MAXN, mol = M.MOL[s[0]];
      html += '<div class="slider"><label for="n' + i + '">' + mol.f + '</label>' +
        '<input type="range" id="n' + i + '" data-i="' + i + '" min="' + lo + '" max="' + hi + '" step="1" value="' + state.counts[i] + '">' +
        '<output id="o' + i + '"></output></div>';
    });
    box.innerHTML = html;
    qa('#counts input').forEach(function (inp) {
      inp.addEventListener('input', function () {
        state.counts[+inp.dataset.i] = +inp.value;
        rebuild();
        // 动画到一半时改分子数，回到反应前
        if (state.t > 0 && state.t < 3) { state.t = 0; state.target = 0; state.playing = false; }
        syncUI();
      });
      inp.addEventListener('change', function () { Analytics.track(NAME, '分子数', M.RX[state.rx].name + ' ' + state.counts.join(',')); });
    });
    $('rxNote').textContent = rx.note + '。';
    $('stoichBtn').hidden = !!rx.phys;
  }

  // ---------- 播放 ----------
  function goTo(k) { state.playing = false; state.target = Math.max(0, Math.min(3, k)); }
  function next() {
    if (state.t >= 3 - 1e-6) { state.t = 0; state.target = 0; return; }
    goTo(Math.floor(state.t + 1e-6) + 1);
  }
  function prev() { goTo(Math.ceil(state.t - 1e-6) - 1); }
  function play() {
    if (state.playing) { state.playing = false; state.target = state.t; return; }
    if (state.t >= 3 - 1e-6) state.t = 0;
    state.playing = true; state.hold = 0.3;
    state.target = state.t;
  }
  function advance(dt) {
    if (state.playing && Math.abs(state.target - state.t) < 1e-6) {
      if (state.t >= 3 - 1e-6) state.playing = false;
      else if ((state.hold -= dt) <= 0) { state.target = Math.floor(state.t + 1e-6) + 1; state.hold = HOLD; }
    }
    var d = state.target - state.t, stp = RATE * state.speed * dt;
    if (Math.abs(d) <= stp) state.t = state.target; else state.t += d > 0 ? stp : -stp;
  }

  // ---------- 控件 ----------
  qa('[data-scene]').forEach(function (b) {
    b.addEventListener('click', function () { setScene(b.dataset.scene); Analytics.track(NAME, '场景', b.textContent); });
  });
  function setScene(sc) {
    state.scene = sc;
    if (sc === 'quiz' && !state.quiz) newQuiz();
    syncUI();
  }
  qa('[data-rx]').forEach(function (b) {
    b.addEventListener('click', function () {
      setRx(b.dataset.rx);
      play();
      Analytics.track(NAME, '反应', M.RX[state.rx].name);
    });
  });
  $('playBtn').addEventListener('click', function () { play(); syncUI(); Analytics.track(NAME, '播放'); });
  $('nextBtn').addEventListener('click', function () { next(); syncUI(); Analytics.track(NAME, '下一步'); });
  $('prevBtn').addEventListener('click', function () { prev(); syncUI(); });
  $('resetBtn').addEventListener('click', function () { state.playing = false; state.t = 0; state.target = 0; syncUI(); });
  $('stoichBtn').addEventListener('click', function () {
    var rx = M.RX[state.rx];
    setRx(state.rx, rx.r.map(function (s) { return s[1] * 2; }));
    Analytics.track(NAME, '恰好完全反应');
  });
  qa('[data-speed]').forEach(function (b) {
    b.addEventListener('click', function () { state.speed = +b.dataset.speed; syncUI(); });
  });
  $('letters').addEventListener('change', function () { state.letters = $('letters').checked; });
  $('labels').addEventListener('change', function () { state.labels = $('labels').checked; });
  window.addEventListener('keydown', function (e) {
    var tg = e.target.tagName;
    if (tg === 'INPUT' || tg === 'SELECT' || tg === 'BUTTON' || tg === 'TEXTAREA' || state.scene !== 'sim') return;
    if (e.code === 'Space') { e.preventDefault(); play(); syncUI(); }
    else if (e.code === 'ArrowRight') { next(); syncUI(); }
    else if (e.code === 'ArrowLeft') { prev(); syncUI(); }
  });
  // 点步骤条跳到那一步，点容器走下一步
  cv.addEventListener('click', function (e) {
    if (state.scene !== 'sim') return;
    var r = cv.getBoundingClientRect(), h = view.hit(e.clientX - r.left, e.clientY - r.top);
    if (h === 'box') { next(); Analytics.track(NAME, '点容器'); }
    else if (h != null) goTo(h);
    else return;
    syncUI();
  });

  // ---------- 练习 ----------
  function newQuiz() {
    state.quiz = M.quiz(Math.random, state.quiz, state.quizOnly);
    state.answered = false; state.choice = null;
    var box = $('quizOpts');
    box.innerHTML = '';
    state.quiz.options.forEach(function (o) {
      var b = document.createElement('button');
      b.className = 'small';
      b.textContent = o;
      b.addEventListener('click', function () { answer(o); });
      box.appendChild(b);
    });
    box.classList.toggle('one', state.quiz.options.some(function (o) { return o.length > 13; }));
    syncUI();
  }
  function answer(o) {
    if (state.answered) return;
    state.answered = true; state.choice = o;
    state.correct = o === state.quiz.answer;
    state.score.n++; if (state.correct) state.score.ok++;
    Analytics.track(NAME, '练习', state.quiz.type + (state.correct ? ' 对' : ' 错'));
    syncUI();
  }
  $('nextQ').addEventListener('click', newQuiz);
  $('showQ').addEventListener('click', function () {
    var q = state.quiz;
    setRx(q.rx, q.counts.slice());
    setScene('sim');
    play();
    Analytics.track(NAME, '练习 → 模型', q.type);
  });

  // ---------- 面板 ----------
  $('panelToggle').addEventListener('click', function () { panel.classList.toggle('collapsed'); });
  if (window.matchMedia('(max-width: 760px)').matches) panel.classList.add('collapsed');

  function syncUI() {
    var sc = state.scene;
    setSeg('scene', sc);
    qa('[data-for]').forEach(function (el) { el.hidden = el.dataset.for.split(' ').indexOf(sc) < 0; });
    $('hint').textContent = HINTS[sc];
    setSeg('rx', state.rx);
    setSeg('speed', state.speed);
    $('playBtn').textContent = state.playing ? '❚❚ 暂停' : state.t >= 3 - 1e-6 ? '↻ 再播一次' : '▶ 播放';
    $('letters').checked = state.letters; $('labels').checked = state.labels;
    var rx = M.RX[state.rx];
    state.counts.forEach(function (n, i) {
      var inp = $('n' + i); if (!inp) return;
      inp.value = n;
      var left = state.plan.left[i];
      $('o' + i).textContent = n + ' 个' + (left && !rx.phys ? '（剩 ' + left + '）' : '');
    });
    var q = state.quiz;
    if (q) {
      $('quizQ').textContent = q.prompt;
      qa('#quizOpts button').forEach(function (b) {
        b.disabled = state.answered;
        b.classList.toggle('on', state.answered && b.textContent === q.answer);
        b.classList.toggle('no', state.answered && b.textContent === state.choice && !state.correct);
      });
      $('quizMsg').innerHTML = !state.answered ? ''
        : '<b class="' + (state.correct ? 'ok">✓ 答对了' : 'bad">✗ 应选「' + q.answer + '」') + '</b>' + q.explain;
      $('nextQ').textContent = state.answered ? '下一题 →' : '换一题';
      $('showQ').hidden = !state.answered;
    }
  }

  // ---------- 读数 ----------
  var lastText = {};
  function setText(id, t) { if (lastText[id] !== t) { lastText[id] = t; $(id).textContent = t; } }
  function rows(list) {
    for (var k = 1; k <= 6; k++) {
      var r = list[k - 1] || ['', ''];
      setText('d' + k, r[0]); setText('r' + k, r[1]);
      $('d' + k).hidden = $('r' + k).hidden = !r[0];
    }
  }
  function molList(o) { return Object.keys(o).map(function (k) { return M.MOL[k].f + ' ' + o[k]; }).join('、'); }
  function readSim() {
    var p = state.plan, st = state.stats, rx = p.rx;
    var cur = state.t < 0.001 ? 0 : Math.min(3, Math.ceil(state.t - 1e-6));
    var moving = Math.abs(state.target - state.t) > 1e-6;
    setText('rName', M.phaseNames(state.rx)[cur] + (moving ? '…' : ''));
    $('rName').className = cur === 3 && !moving ? 'gold' : '';
    setText('rKind', rx.phys ? '物理变化' : rx.type);
    setText('rTip', M.describe(p, cur));
    var list = [['方程式', M.equation(state.rx)]];
    if (rx.phys) {
      list.push(['分子', '水分子 ' + st.nB + ' 个 → ' + st.nA + ' 个，种类不变']);
      list.push(['原子', atomLine(st)]);
      list.push(['变化', '只是分子间隔变大，没有新分子生成']);
    } else if (p.U) {
      list.push(['分子', '反应前 ' + st.nB + ' 个（' + molList(st.molB) + '）→ 反应后 ' + st.nA + ' 个（' + molList(st.molA) + '）']);
      list.push(['原子', atomLine(st) + '（种类、数目不变）']);
      list.push(['质量', '参加反应 ' + st.termsIn.join(' + ') + ' = ' + fm(st.mIn) + '；生成 ' + st.termsOut.join(' + ') + ' = ' + fm(st.mOut)]);
      var left = p.left.map(function (n, i) { var m = M.MOL[rx.r[i][0]]; return n ? n + ' 个 ' + m.f + (m.byAtom ? ' 原子' : ' 分子') : ''; }).filter(Boolean);
      if (left.length) list.push(['剩余', left.join('、') + '没有参加反应']);
      else list.push(['剩余', '无，反应物恰好完全反应']);
    } else {
      list.push(['分子', molList(st.molB)]);
      list.push(['提示', '按化学计量数，至少需要 ' + rx.r.map(function (s) { return s[1] + ' 个 ' + M.MOL[s[0]].f; }).join(' 和 ')]);
    }
    rows(list);
  }
  function atomLine(st) {
    return Object.keys(st.atomB).map(function (k) { return k + ' ' + st.atomB[k] + ' → ' + (st.atomA[k] || 0); }).join('，');
  }
  function fm(x) { return Math.round(x * 10) / 10 + ''; }
  function readQuiz() {
    var sc = state.score;
    setText('rName', !state.answered ? '判断练习' : state.correct ? '✓ 答对了' : '✗ 答错了');
    $('rName').className = !state.answered ? '' : state.correct ? 'ok' : 'bad';
    setText('rKind', '得分 ' + sc.ok + ' / ' + sc.n);
    setText('rTip', state.answered ? state.quiz.explain : '看图中反应前、反应后的微粒，先划掉没有参加反应的分子，再作答。');
    rows([]);
  }

  // ---------- 尺寸与主循环 ----------
  function resize() { view.resize(stage.clientWidth, stage.clientHeight); }
  new ResizeObserver(resize).observe(stage);

  // 支持 ?scene=sim|quiz、&rx=h2o|h2|hgo|hcl|h2o2|co|ch4|cw|noco|evap、&n=4,2（各反应物分子数）、
  // &t=0~3（停在第几步，可带小数）、&play=0（打开时不自动播放）、&speed=0.5|1|2、&letters=0、&labels=0、练习 &q=type|ratio|judge|eq
  var qs = new URLSearchParams(location.search);
  if (HINTS[qs.get('scene')]) state.scene = qs.get('scene');
  if (M.RX[qs.get('rx')]) state.rx = qs.get('rx');
  if (['0.5', '1', '2'].indexOf(qs.get('speed')) >= 0) state.speed = +qs.get('speed');
  if (qs.get('letters') === '0') state.letters = false;
  if (qs.get('labels') === '0') state.labels = false;
  if (M.TYPES.indexOf(qs.get('q')) >= 0) state.quizOnly = qs.get('q');
  var counts = M.defaults(state.rx), nq = (qs.get('n') || '').split(',').map(Number);
  var phys = M.RX[state.rx].phys;
  counts = counts.map(function (c, i) { var v = nq[i]; return v >= (phys ? 4 : 1) && v <= (phys ? 16 : M.MAXN) ? Math.round(v) : c; });
  resize();
  setRx(state.rx, counts);
  var t0 = parseFloat(qs.get('t'));
  if (isFinite(t0)) { state.t = state.target = Math.max(0, Math.min(3, t0)); }
  else if (qs.get('play') !== '0') play();
  setScene(state.scene);

  var lastT = performance.now(), last = '';
  function frame(now) {
    var dt = Math.min((now - lastT) / 1000, 0.1);
    lastT = now;
    state.now += dt;
    if (state.scene === 'sim') {
      advance(dt);
      view.drawSim(state);
      readSim();
      var sig = state.playing + ':' + (state.t >= 3 - 1e-6);
      if (sig !== last) { last = sig; syncUI(); }
    } else {
      view.drawQuiz(state.quiz, state.answered, { quizH: $('quizBar').offsetHeight });
      readQuiz();
    }
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // 调试用
  window.__model = {
    state: state, M: M, view: view, setRx: setRx, goTo: goTo, next: next, prev: prev, play: play, setScene: setScene, newQuiz: newQuiz,
    answer: function (o) { answer(o == null ? state.quiz.answer : o); }
  };
})();
