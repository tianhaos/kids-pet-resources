// 化学反应的微观过程：元素、分子形状、反应数据，“分子分成原子 → 原子重新组合”的安排与计数、判断练习（不碰 DOM）
// 分子形状以“原子半径单位”计（O 原子半径约 1），绘制时再乘以像素比例；
// 一次反应的安排 plan：参加反应的分子按“反应单元”（一组化学计量数的分子）依次占据格位 0、1、2…，未参加反应的分子从最后一格倒着放、前后不动
(function () {
  // 元素：名称、相对原子质量、显示半径、颜色
  var EL = {
    H: { name: '氢', m: 1, r: 0.6, c: '#eef2f7' },
    C: { name: '碳', m: 12, r: 0.98, c: '#5c6573' },
    N: { name: '氮', m: 14, r: 0.96, c: '#5b7cff' },
    O: { name: '氧', m: 16, r: 0.92, c: '#ff5a4a' },
    Cl: { name: '氯', m: 35.5, r: 1.12, c: '#5fd37a' },
    Hg: { name: '汞', m: 201, r: 1.25, c: '#a9bccf' }
  };
  // 分子（或直接由原子构成的物质的一个原子）：f 化学式，name 物质名，pname 微粒名，atoms [元素, dx, dy]
  var MOL = {
    H2: { f: 'H₂', name: '氢气', pname: '氢分子', atoms: [['H', -0.42, 0], ['H', 0.42, 0]] },
    O2: { f: 'O₂', name: '氧气', pname: '氧分子', atoms: [['O', -0.6, 0], ['O', 0.6, 0]] },
    N2: { f: 'N₂', name: '氮气', pname: '氮分子', atoms: [['N', -0.62, 0], ['N', 0.62, 0]] },
    Cl2: { f: 'Cl₂', name: '氯气', pname: '氯分子', atoms: [['Cl', -0.72, 0], ['Cl', 0.72, 0]] },
    H2O: { f: 'H₂O', name: '水', pname: '水分子', atoms: [['O', 0, 0], ['H', -0.86, 0.66], ['H', 0.86, 0.66]] },
    H2O2: { f: 'H₂O₂', name: '过氧化氢', pname: '过氧化氢分子', atoms: [['O', -0.56, 0], ['O', 0.56, 0], ['H', -1.12, -0.66], ['H', 1.12, 0.66]] },
    HgO: { f: 'HgO', name: '氧化汞', pname: '氧化汞分子', atoms: [['Hg', -0.5, 0], ['O', 1.0, 0]] },
    Hg: { f: 'Hg', name: '汞', pname: '汞原子', atoms: [['Hg', 0, 0]] },
    HCl: { f: 'HCl', name: '氯化氢', pname: '氯化氢分子', atoms: [['H', -0.95, 0], ['Cl', 0.28, 0]] },
    CH4: { f: 'CH₄', name: '甲烷', pname: '甲烷分子', atoms: [['H', 0, -1.08], ['C', 0, 0], ['H', -1.04, 0.12], ['H', 1.04, 0.12], ['H', 0.22, 1.0]] },
    CO2: { f: 'CO₂', name: '二氧化碳', pname: '二氧化碳分子', atoms: [['O', -1.1, 0], ['O', 1.1, 0], ['C', 0, 0]] },
    CO: { f: 'CO', name: '一氧化碳', pname: '一氧化碳分子', atoms: [['C', -0.55, 0], ['O', 0.55, 0]] },
    NO: { f: 'NO', name: '一氧化氮', pname: '一氧化氮分子', atoms: [['N', -0.55, 0], ['O', 0.55, 0]] },
    C: { f: 'C', name: '碳', pname: '碳原子', atoms: [['C', 0, 0]] }
  };
  Object.keys(MOL).forEach(function (k) {
    var m = MOL[k], els = {};
    m.id = k;
    m.atoms.forEach(function (a) { els[a[0]] = (els[a[0]] || 0) + 1; });
    m.els = els;
    m.single = Object.keys(els).length === 1;          // 单质
    m.byAtom = m.atoms.length === 1;                    // 由原子直接构成
    m.Mr = m.atoms.reduce(function (s, a) { return s + EL[a[0]].m; }, 0);
  });

  // 反应：r / p 为 [分子, 化学计量数, 生成物是否标 ↑]；type 为基本反应类型
  var RX = {
    h2o: { name: '电解水', cond: '通电', type: '分解反应', r: [['H2O', 2]], p: [['H2', 2, 1], ['O2', 1, 1]],
      note: '水通电分解生成氢气和氧气，说明水由氢、氧两种元素组成（正极产生氧气，负极产生氢气，体积比约 1∶2）' },
    h2: { name: '氢气燃烧', cond: '点燃', type: '化合反应', r: [['H2', 2], ['O2', 1]], p: [['H2O', 2]],
      note: '氢气在空气中燃烧，产生淡蓝色火焰，生成物只有水，是最清洁的燃料' },
    hgo: { name: '氧化汞受热分解', cond: '△', type: '分解反应', r: [['HgO', 2]], p: [['Hg', 2], ['O2', 1, 1]],
      note: '拉瓦锡研究空气成分时用到的反应。汞是金属，由汞原子直接构成' },
    hcl: { name: '氢气在氯气中燃烧', cond: '点燃', type: '化合反应', r: [['H2', 1], ['Cl2', 1]], p: [['HCl', 2]],
      note: '氢气在氯气中安静地燃烧，发出苍白色火焰，生成氯化氢（溶于水即盐酸）' },
    h2o2: { name: '过氧化氢分解', cond: 'MnO₂', type: '分解反应', r: [['H2O2', 2]], p: [['H2O', 2], ['O2', 1, 1]],
      note: '实验室制取氧气的方法之一，二氧化锰是催化剂，反应前后质量和化学性质不变，不参加原子的重新组合' },
    co: { name: '一氧化碳燃烧', cond: '点燃', type: '化合反应', r: [['CO', 2], ['O2', 1]], p: [['CO2', 2]],
      note: '一氧化碳燃烧发出蓝色火焰，可以用作燃料；一氧化碳有毒' },
    ch4: { name: '甲烷燃烧', cond: '点燃', type: '不属于基本反应类型', r: [['CH4', 1], ['O2', 2]], p: [['CO2', 1], ['H2O', 2]],
      note: '天然气、沼气的主要成分是甲烷。生成物有两种化合物，不属于四种基本反应类型，但它是物质与氧气的反应，属于氧化反应' },
    cw: { name: '碳与水蒸气（水煤气）', cond: '高温', type: '置换反应', r: [['C', 1], ['H2O', 1]], p: [['CO', 1], ['H2', 1]],
      note: '高温下碳与水蒸气反应生成一氧化碳和氢气（水煤气）。一种单质与一种化合物反应，生成另一种单质和另一种化合物，属于置换反应' },
    noco: { name: '汽车尾气催化转化', cond: '催化剂', type: '不属于基本反应类型', r: [['CO', 2], ['NO', 2]], p: [['CO2', 2], ['N2', 1]],
      note: '汽车尾气催化转化器把有毒的 CO 和 NO 转化为无毒的 CO₂ 和 N₂。反应物是两种化合物，不属于置换反应' },
    evap: { name: '水的蒸发（物理变化）', phys: true, cond: '', type: '物理变化', r: [['H2O', 1]], p: [['H2O', 1]],
      note: '对比：水蒸发时水分子本身没有变，只是分子间的间隔变大，没有生成新的分子，是物理变化' }
  };
  var ORDER = ['h2o', 'h2', 'hgo', 'hcl', 'h2o2', 'co', 'ch4', 'cw', 'noco', 'evap'];
  var MAXN = 8;           // 每种反应物最多的分子数
  var TYPES4 = ['化合反应', '分解反应', '置换反应', '不属于基本反应类型'];

  // 默认分子数：化学计量数 × 2（水的蒸发 10 个）
  function defaults(id) {
    var rx = RX[id];
    if (rx.phys) return [10];
    return rx.r.map(function (s) { return s[1] * 2; });
  }
  function sum(a) { return a.reduce(function (s, x) { return s + x; }, 0); }
  function gcd(a, b) { return b ? gcd(b, a % b) : a; }
  function ratio(a, b) { var g = gcd(a, b) || 1; return (a / g) + '∶' + (b / g); }

  // 安排：before / after 为分子 {m, slot, unit, left}；atoms 为 {el, b: [before 序号, 原子序号], a: [after 序号, 原子序号], left}
  function plan(id, counts) {
    var rx = RX[id], before = [], after = [], atoms = [];
    if (rx.phys) {
      for (var i = 0; i < counts[0]; i++) {
        before.push({ m: 'H2O', slot: i, unit: i, left: false });
        after.push({ m: 'H2O', slot: i, unit: i, left: false });
        MOL.H2O.atoms.forEach(function (a, k) { atoms.push({ el: a[0], b: [i, k], a: [i, k], left: false }); });
      }
      return { id: id, rx: rx, U: counts[0], left: [0], N: counts[0], before: before, after: after, atoms: atoms, counts: counts.slice() };
    }
    var U = Infinity;
    rx.r.forEach(function (s, i) { U = Math.min(U, Math.floor(counts[i] / s[1])); });
    var left = rx.r.map(function (s, i) { return counts[i] - U * s[1]; });
    var nR = sum(rx.r.map(function (s) { return s[1]; })), nP = sum(rx.p.map(function (s) { return s[1]; }));
    var L = sum(left), N = Math.max(U * nR, U * nP) + L;
    for (var u = 0; u < U; u++) {
      var rb = [], pa = [];
      rx.r.forEach(function (s) { for (var j = 0; j < s[1]; j++) { rb.push(before.length); before.push({ m: s[0], slot: u * nR + rb.length - 1, unit: u, left: false }); } });
      rx.p.forEach(function (s) { for (var j = 0; j < s[1]; j++) { pa.push(after.length); after.push({ m: s[0], slot: u * nP + pa.length - 1, unit: u, left: false }); } });
      // 同种元素的原子按先后一一对应
      var pool = {};
      pa.forEach(function (ai) { MOL[after[ai].m].atoms.forEach(function (a, k) { (pool[a[0]] = pool[a[0]] || []).push([ai, k]); }); });
      rb.forEach(function (bi) {
        MOL[before[bi].m].atoms.forEach(function (a, k) { atoms.push({ el: a[0], b: [bi, k], a: pool[a[0]].shift(), left: false }); });
      });
    }
    var slot = N - 1;
    rx.r.forEach(function (s, i) {
      for (var j = 0; j < left[i]; j++, slot--) {
        var bi = before.length, ai = after.length;
        before.push({ m: s[0], slot: slot, unit: -1, left: true });
        after.push({ m: s[0], slot: slot, unit: -1, left: true });
        MOL[s[0]].atoms.forEach(function (a, k) { atoms.push({ el: a[0], b: [bi, k], a: [ai, k], left: true }); });
      }
    });
    return { id: id, rx: rx, U: U, left: left, N: N, before: before, after: after, atoms: atoms, counts: counts.slice() };
  }

  // 计数：分子（全部 / 参加反应的）、原子、相对质量
  function tally(list) {
    var o = {};
    list.forEach(function (x) { o[x.m] = (o[x.m] || 0) + 1; });
    return o;
  }
  function atomCount(list) {
    var o = {};
    list.forEach(function (x) { var e = MOL[x.m].els; for (var k in e) o[k] = (o[k] || 0) + e[k]; });
    // 按 EL 的顺序（H、C、N、O…）排列
    var out = {};
    Object.keys(EL).forEach(function (k) { if (o[k]) out[k] = o[k]; });
    return out;
  }
  function stats(p) {
    var rx = p.rx, reacted = p.before.filter(function (x) { return !x.left; }), made = p.after.filter(function (x) { return !x.left; });
    var mIn = 0, mOut = 0, termsIn = [], termsOut = [];
    rx.r.forEach(function (s) { var n = p.U * s[1]; mIn += n * MOL[s[0]].Mr; if (n) termsIn.push(n + '×' + fmtM(MOL[s[0]].Mr)); });
    rx.p.forEach(function (s) { var n = p.U * s[1]; mOut += n * MOL[s[0]].Mr; if (n) termsOut.push(n + '×' + fmtM(MOL[s[0]].Mr)); });
    return {
      molB: tally(p.before), molA: tally(p.after), nB: p.before.length, nA: p.after.length,
      reacted: tally(reacted), made: tally(made),
      atomB: atomCount(p.before), atomA: atomCount(p.after),
      mIn: mIn, mOut: mOut, termsIn: termsIn, termsOut: termsOut
    };
  }
  function fmtM(x) { return Math.round(x * 10) / 10 + ''; }

  // 化学方程式文字：coef 为各物质的系数（缺省为化学计量数），反应条件写在等号中间 =点燃=
  function eqText(rx, rc, pc, swap) {
    function side(list, cs, up) {
      return list.map(function (s, i) {
        var c = cs ? cs[i] : s[1];
        return (c === 1 ? '' : c) + MOL[s[0]].f + (up && s[2] ? '↑' : '');
      }).join(' + ');
    }
    if (swap) return side(rx.p, pc, false) + ' =' + rx.cond + '= ' + side(rx.r, rc, false);
    return side(rx.r, rc, false) + ' =' + rx.cond + '= ' + side(rx.p, pc, true);
  }
  function equation(id) { return RX[id].phys ? 'H₂O(液) → H₂O(气)' : eqText(RX[id]); }

  // 物质与微粒的说明：“氢气（由氢分子构成）”
  function madeOf(m) { var M = MOL[m]; return M.name + '由' + M.pname + (M.byAtom ? '直接' : '') + '构成'; }
  function compo(m) {
    var M = MOL[m];
    return elOrder(m).map(function (k) { return M.els[k] + ' 个' + EL[k].name + '原子'; }).join('和 ');
  }
  // 元素按化学式里的顺序：CO₂ 先碳后氧
  function elOrder(m) { return m.match(/[A-Z][a-z]?/g).filter(function (k, i, a) { return a.indexOf(k) === i; }); }
  function listNames(list, key) {
    var seen = {}, out = [];
    list.forEach(function (s) { var t = MOL[s[0]][key]; if (!seen[t]) { seen[t] = 1; out.push(t); } });
    return out.join('、');
  }
  function elsOf(list) {
    var o = {};
    list.forEach(function (s) { elOrder(s[0]).forEach(function (k) { o[k] = 1; }); });
    return Object.keys(o).map(function (k) { return EL[k].name + '原子'; }).join('、');
  }

  // 四个阶段的名称与说明（phase 0 反应前、1 分子分成原子、2 原子重新组合、3 反应后）
  var PHASES = ['反应前', '分子分成原子', '原子重新组合', '反应后'];
  var PHASES_PHYS = ['液态水', '吸收热量', '分子间隔变大', '水蒸气'];
  function phaseNames(id) { return RX[id].phys ? PHASES_PHYS : PHASES; }
  function describe(p, phase) {
    var rx = p.rx;
    if (rx.phys) {
      return ['液态水中水分子间的间隔很小，分子在不停地运动。',
        '水吸收热量，水分子的运动加快，一些分子挣脱其他分子的束缚，离开液面。',
        '水分子之间的间隔变大，但每个水分子仍然由 2 个氢原子和 1 个氧原子构成，分子本身没有改变。',
        '水变成了水蒸气，只是状态改变，没有生成新的分子，是物理变化。物理变化中分子本身不变，化学变化中分子分成原子、原子重新组合成新的分子。'][phase];
    }
    if (!p.U) return '分子个数不够，按 ' + eqText(rx) + '，凑不齐一组反应的分子，不能反应。增加反应物的分子数试试。';
    var cond = rx.cond === '△' ? '加热' : rx.cond === 'MnO₂' ? '二氧化锰催化' : rx.cond;
    var leftTxt = p.left.map(function (n, i) { return n ? n + ' 个' + MOL[rx.r[i][0]].pname : ''; }).filter(Boolean).join('、');
    switch (phase) {
      case 0: return '反应前：' + rx.r.map(function (s) { return madeOf(s[0]); }).join('，') + '。反应条件：' + cond + '。';
      case 1:
        var mols = rx.r.filter(function (s) { return !MOL[s[0]].byAtom; }), atomsR = rx.r.filter(function (s) { return MOL[s[0]].byAtom; });
        return '在' + cond + '的条件下，' + listNames(mols, 'pname') + '分裂成' + elsOf(mols) + '——化学变化中，分子可以分成原子。' +
        (atomsR.length ? listNames(atomsR, 'name') + '由原子直接构成，' + listNames(atomsR, 'pname') + '本来就是单个的原子。' : '') +
        (leftTxt ? '多出来的 ' + leftTxt + '没有参加反应。' : '');
      case 2: return '原子重新组合：' + rx.p.map(function (s) {
        var M = MOL[s[0]];
        return M.byAtom ? M.pname + '聚集成金属' + M.name : compo(s[0]) + '结合成 1 个' + M.pname;
      }).join('，') + '。原子在化学变化中不能再分，只是重新组合。';
      default: return '反应后：生成了' + listNames(rx.p, 'name') + '。反应前后原子的种类没有改变、数目没有增减、质量也没有改变，所以参加反应的各物质的质量总和等于生成的各物质的质量总和。' +
        (leftTxt ? '剩余的 ' + leftTxt + '没有参加反应，不计入“参加反应的”质量。' : '');
    }
  }

  // ---------- 判断练习 ----------
  var TYPES = ['type', 'ratio', 'judge', 'eq'];
  var QUIZ_RX = ORDER.filter(function (k) { return !RX[k].phys; });
  function pick(rand, arr) { return arr[Math.floor(rand() * arr.length)]; }
  function shuffle(rand, arr) {
    for (var i = arr.length - 1; i > 0; i--) { var j = Math.floor(rand() * (i + 1)), t = arr[i]; arr[i] = arr[j]; arr[j] = t; }
    return arr;
  }
  function uniq(arr) { return arr.filter(function (x, i) { return x && arr.indexOf(x) === i; }); }
  // 题目的分子数：1～2 组，ratio / eq 题大多再多放 1～2 个某种反应物（不参加反应），做成“有剩余”的陷阱
  function quizCounts(rand, id, type) {
    var rx = RX[id], m = rand() < 0.5 ? 1 : 2;
    var c = rx.r.map(function (s) { return s[1] * m; });
    var p = type === 'ratio' ? 0.75 : type === 'eq' ? 0.5 : 0.4;
    if (rand() < p) { var j = Math.floor(rand() * c.length); c[j] += 1 + (rand() < 0.4 ? 1 : 0); }
    return c;
  }
  function pairs(rx) {
    var out = [];
    if (rx.r.length > 1) out.push({ a: rx.r[0], b: rx.r[1], pre: '参加反应的', mid: '与', w: 3 });
    if (rx.p.length > 1) out.push({ a: rx.p[0], b: rx.p[1], pre: '生成的', mid: '与', w: 2 });
    out.push({ a: rx.r[rx.r.length - 1], b: rx.p[0], pre: '参加反应的', mid: '与生成的', w: 1 });
    return out;
  }
  function ratioOpts(rand, ans, extra) {
    var pool = uniq([ans].concat(extra, ['1∶1', '2∶1', '1∶2', '2∶3', '3∶2', '1∶3']));
    var opts = [ans];
    pool.slice(1).forEach(function (x) { if (opts.length < 4 && extra.indexOf(x) >= 0) opts.push(x); });
    shuffle(rand, pool.slice(1)).forEach(function (x) { if (opts.length < 4 && opts.indexOf(x) < 0) opts.push(x); });
    return opts;
  }
  function hasLeft(p) { return p.left.some(function (n) { return n > 0; }); }
  function leftText(p) {
    return p.left.map(function (n, i) { var M = MOL[p.rx.r[i][0]]; return n ? n + ' 个 ' + M.f + (M.byAtom ? ' 原子' : ' 分子') : ''; }).filter(Boolean).join('、');
  }
  function kindText(rx) {
    function k(list) { return list.map(function (s) { return MOL[s[0]].f + '（' + (MOL[s[0]].single ? '单质' : '化合物') + '）'; }).join('、'); }
    return '反应物是 ' + k(rx.r) + '，生成物是 ' + k(rx.p);
  }
  var TYPE_WHY = {
    '化合反应': '由两种或两种以上的物质生成另一种物质，是化合反应（多变一）',
    '分解反应': '由一种物质生成两种或两种以上其他物质，是分解反应（一变多）',
    '置换反应': '一种单质与一种化合物反应，生成另一种单质和另一种化合物，是置换反应',
    '不属于基本反应类型': '既不是“多变一”“一变多”，也不是“单质 + 化合物 → 单质 + 化合物”，不属于化合、分解、置换反应'
  };

  function quiz(rand, prev, only) {
    rand = rand || Math.random;
    var type = only, id, guard = 0;
    if (TYPES.indexOf(type) < 0) do { type = pick(rand, TYPES); } while (prev && type === prev.type && guard++ < 5);
    guard = 0;
    do { id = pick(rand, QUIZ_RX); } while (prev && id === prev.rx && guard++ < 5);
    var rx = RX[id], counts = quizCounts(rand, id, type), p = plan(id, counts), st = stats(p);
    var q = { type: type, rx: id, counts: counts, plan: p };
    var lt = hasLeft(p) ? '图中反应后还剩 ' + leftText(p) + '，它们没有参加反应，要先划掉。' : '';
    if (type === 'type') {
      q.prompt = '图中反应属于哪种基本反应类型？';
      q.options = TYPES4.slice();
      q.answer = rx.type;
      q.explain = kindText(rx) + '。' + TYPE_WHY[rx.type] + '。' + (rx.type === '不属于基本反应类型' && id === 'ch4' ? '它是物质与氧气的反应，属于氧化反应。' : '');
    } else if (type === 'ratio') {
      var ws = [];
      pairs(rx).forEach(function (pr) { for (var k = 0; k < pr.w; k++) ws.push(pr); });
      var pr = pick(rand, ws), A = MOL[pr.a[0]].f, B = MOL[pr.b[0]].f;
      var word = MOL[pr.a[0]].byAtom || MOL[pr.b[0]].byAtom ? '粒子' : '分子';
      q.prompt = pr.pre + ' ' + A + ' ' + pr.mid + ' ' + B + ' 的' + word + '个数比为';
      q.answer = ratio(pr.a[1], pr.b[1]);
      var gen = pr.pre === '生成的', seen = ratio((gen ? st.molA : st.molB)[pr.a[0]] || 0, (gen || pr.mid !== '与' ? st.molA : st.molB)[pr.b[0]] || 0);
      var extra = [];
      if (seen !== q.answer && seen.indexOf('0') !== 0) extra.push(seen);
      extra.push(ratio(pr.b[1], pr.a[1]));
      q.options = ratioOpts(rand, q.answer, extra);
      q.explain = lt + '参加反应和生成的' + word + '个数比等于化学方程式 ' + eqText(rx) + ' 中的化学计量数之比：' + A + '∶' + B + ' = ' + q.answer + '。';
    } else if (type === 'eq') {
      q.prompt = '图中反应的化学方程式是';
      var right = eqText(rx), ds = [];
      if (hasLeft(p)) {
        var lc = rx.p.map(function (s) { return st.molA[s[0]] || 0; });
        var rc = rx.r.map(function (s) { return st.molB[s[0]]; });
        // 把剩余的分子也写进方程式（两边都写）：典型错误
        var tx = eqText(rx, rc, lc), extraL = p.left.map(function (n, i) { return n ? ' + ' + (n === 1 ? '' : n) + MOL[rx.r[i][0]].f : ''; }).join('');
        ds.push(tx + extraL);
      }
      ds.push(eqText(rx, rx.r.map(function () { return 1; }), rx.p.map(function () { return 1; })));
      ds.push(eqText(rx, null, null, true));
      // 改一个系数
      var bump = rx.p.map(function (s) { return s[1]; }); bump[bump.length - 1] += 1;
      ds.push(eqText(rx, null, bump));
      ds.push(eqText(rx, rx.r.map(function (s) { return s[1] * 2; }), rx.p.map(function (s) { return s[1] * 2; })));
      ds = uniq(ds).filter(function (x) { return x !== right; });
      q.options = shuffle(rand, [right].concat(ds.slice(0, 3)));
      q.answer = right;
      q.explain = lt + '数出参加反应的分子和生成的分子，写成最简整数比，再检查两边各种原子的个数相等：' + right + '。' +
        (id === 'h2o2' ? '二氧化锰是催化剂，写在等号上方。' : '');
    } else {
      // 判断说法：每个话题出一条真或假的说法，选 1 条“正确”（或“错误”）的
      var wantTrue = rand() < 0.7, topics = [];
      var nIn = sum(rx.r.map(function (s) { return s[1]; })), nOut = sum(rx.p.map(function (s) { return s[1]; }));
      topics.push(['反应前后原子的种类和数目都不变', '反应前后原子的数目发生了改变']);
      topics.push(['反应前后分子的种类发生了改变', '反应前后分子的种类没有改变']);
      topics.push(['化学变化中分子可以再分，原子不能再分', '原子在化学变化中可以再分']);
      topics.push(['反应前后元素的种类不变', '反应前后元素的种类发生了改变']);
      var wrongT = TYPES4.filter(function (t) { return t !== rx.type; });
      topics.push([rx.type === '不属于基本反应类型' ? '该反应不属于化合、分解、置换反应' : '该反应属于' + rx.type,
        '该反应属于' + pick(rand, wrongT.filter(function (t) { return t !== '不属于基本反应类型'; }))]);
      var nOutTrue = nIn === nOut ? '参加反应的分子总数与生成的分子总数相等' : '参加反应的分子总数与生成的分子总数不相等';
      var nOutFalse = nIn === nOut ? '反应后分子总数减少了' : '参加反应的分子总数与生成的分子总数相等';
      topics.push([nOutTrue, nOutFalse]);
      var nc = rx.p.filter(function (s) { return !MOL[s[0]].single; }).length;
      topics.push(['生成物中有 ' + nc + ' 种化合物', '生成物中有 ' + (nc === 0 ? 2 : nc === 2 ? 1 : nc + 1) + ' 种化合物']);
      if (rx.r.length > 1) {
        var A2 = MOL[rx.r[0][0]].f, B2 = MOL[rx.r[1][0]].f, good = ratio(rx.r[0][1], rx.r[1][1]);
        var bad = ratio(st.molB[rx.r[0][0]], st.molB[rx.r[1][0]]);
        if (bad === good) bad = ratio(rx.r[1][1], rx.r[0][1]);
        if (bad === good) bad = ratio(rx.r[0][1] + 1, rx.r[1][1]);
        var w2 = MOL[rx.r[0][0]].byAtom || MOL[rx.r[1][0]].byAtom ? '粒子' : '分子';
        topics.push(['参加反应的 ' + A2 + ' 与 ' + B2 + ' 的' + w2 + '个数比为 ' + good, '参加反应的 ' + A2 + ' 与 ' + B2 + ' 的' + w2 + '个数比为 ' + bad]);
      }
      shuffle(rand, topics);
      var opts = topics.slice(0, 4).map(function (t, i) { return i === 0 ? t[wantTrue ? 0 : 1] : t[wantTrue ? 1 : 0]; });
      q.answer = opts[0];
      q.options = shuffle(rand, opts);
      q.prompt = '关于图中的反应，下列说法' + (wantTrue ? '正确' : '错误') + '的是';
      q.explain = lt + '化学方程式为 ' + eqText(rx) + '。' + kindText(rx) + '。化学变化中分子分成原子、原子重新组合，原子的种类、数目、质量都不变，元素种类不变；分子种类一定改变，分子总数可能改变。';
    }
    return q;
  }

  window.Micro = {
    EL: EL, MOL: MOL, RX: RX, ORDER: ORDER, MAXN: MAXN, TYPES: TYPES, TYPES4: TYPES4,
    defaults: defaults, plan: plan, stats: stats, eqText: eqText, equation: equation,
    phaseNames: phaseNames, describe: describe, ratio: ratio, quiz: quiz
  };
})();
