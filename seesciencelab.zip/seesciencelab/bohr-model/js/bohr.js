// 玻尔模型的计算：氢原子能级 En = E1/n²、轨道半径 rn = n²r1、跃迁光子 hν = Em − En、谱线系、吸收与碰撞激发、电离、判断练习
// 单位：能量 eV，波长 nm，频率 Hz，半径 m；能级 n = 1～NMAX，n = Infinity 表示电离（E = 0）
// 常量取精确值（h = 6.626×10⁻³⁴ J·s、e = 1.602×10⁻¹⁹ C、c = 2.998×10⁸ m/s），使算出的巴耳末线与教材 656.3、486.1、434.1、410.2 nm 一致
(function () {
  var E1 = -13.6, R1 = 0.53e-10, V1 = 2.19e6;
  var H = 6.626e-34, E0 = 1.602e-19, C = 2.998e8;
  var HC = H * C / E0 * 1e9;      // hc ≈ 1239.8 eV·nm
  var NMAX = 6;
  var TOL = 0.02;                  // 光子能量与能级差“恰好相等”的容差（eV），与读数保留两位小数一致
  var SERIES = {
    1: { id: 'lyman', name: '莱曼系', band: '紫外' },
    2: { id: 'balmer', name: '巴耳末系', band: '可见光（及近紫外）' },
    3: { id: 'paschen', name: '帕邢系', band: '红外' },
    4: { id: 'brackett', name: '布喇开系', band: '红外' },
    5: { id: 'pfund', name: '普丰德系', band: '红外' }
  };
  var SERIES_ID = { lyman: 1, balmer: 2, paschen: 3 };
  var BALMER_NAME = { 3: 'Hα', 4: 'Hβ', 5: 'Hγ', 6: 'Hδ' };

  function clamp(x, a, b) { return Math.max(a, Math.min(b, x)); }

  // ---------- 能级与轨道 ----------
  function E(n) { return n === Infinity ? 0 : E1 / (n * n); }
  function r(n) { return n * n * R1; }
  // 电子在第 n 条轨道上：动能 Ek = −En，电势能 Ep = 2En，速度 v = v1/n
  function ek(n) { return -E(n); }
  function ep(n) { return 2 * E(n); }
  function v(n) { return V1 / n; }
  // 电离能：从 n 能级到 ∞
  function ionize(n) { return -E(n); }

  // ---------- 跃迁与光子 ----------
  function dE(m, n) { return Math.abs(E(m) - E(n)); }
  function lamOf(ev) { return HC / ev; }
  function nuOf(ev) { return ev * E0 / H; }
  function evOfLam(lam) { return HC / lam; }
  // 一条谱线：上能级 up → 下能级 lo
  function line(up, lo) {
    var e = dE(up, lo), lam = lamOf(e), s = SERIES[lo];
    return { up: up, lo: lo, ev: e, lam: lam, nu: nuOf(e), series: s ? s.id : '', seriesName: s ? s.name : '',
      name: lo === 2 && BALMER_NAME[up] ? BALMER_NAME[up] : '' };
  }
  // 一群处于 n 能级的氢原子能发出的全部谱线（C(n,2) 条），按波长从短到长
  function linesFrom(n) {
    var out = [];
    for (var up = 2; up <= n; up++) for (var lo = 1; lo < up; lo++) out.push(line(up, lo));
    return out.sort(function (a, b) { return a.lam - b.lam; });
  }
  // 某个线系里 up ≤ nmax 的谱线
  function seriesLines(lo, nmax) {
    var out = [];
    for (var up = lo + 1; up <= nmax; up++) out.push(line(up, lo));
    return out;
  }
  // 线系极限（up → ∞）
  function seriesLimit(lo) { return lamOf(-E(lo)); }
  function countGroup(n) { return n * (n - 1) / 2; }
  function countOne(n) { return n - 1; }
  // 巴耳末公式 1/λ = R(1/2² − 1/n²)，R 取教材 1.10×10⁷ m⁻¹，返回 nm
  var RYD = 1.10e7;
  function balmer(n) { return 1 / (RYD * (1 / 4 - 1 / (n * n))) * 1e9; }

  // ---------- 吸收与碰撞 ----------
  // 处于 n 能级的原子遇到能量为 ev 的光子：
  //   恰好等于某个 Em − En（m > n）→ 吸收，跃迁到 m；ev ≥ 电离能 → 吸收并电离，电子剩余动能 ev − |En|；否则不吸收
  function absorbPhoton(n, ev) {
    var ion = ionize(n);
    if (ev >= ion - 1e-9) return { kind: 'ionize', to: Infinity, rest: ev - ion };
    for (var m = n + 1; m <= 40; m++) {
      if (Math.abs(dE(m, n) - ev) <= TOL) return { kind: 'jump', to: m, rest: 0 };
      if (dE(m, n) > ev + TOL) break;
    }
    return { kind: 'pass', to: n, rest: ev };
  }
  // 能量为 ev 的电子碰撞处于 n 能级的原子：只要 ev ≥ Em − En 就可能使原子跃迁到 m，原子只取走能级差，电子带走剩余动能
  // 返回能到达的最高能级（不超过 nmax）和是否能电离
  function collideMax(n, ev, nmax) {
    var top = n;
    for (var m = n + 1; m <= (nmax || NMAX); m++) if (dE(m, n) <= ev + 1e-9) top = m;
    return { top: top, ionize: ev >= ionize(n) - 1e-9 };
  }
  // 用某条谱线的光照射逸出功为 W 的金属：最大初动能（可为负）
  function photoEk(up, lo, W) { return dE(up, lo) - W; }

  // ---------- 判断练习 ----------
  function pick(rnd, arr) { return arr[Math.floor(rnd() * arr.length)]; }
  function shuffle(rnd, arr) {
    for (var i = arr.length - 1; i > 0; i--) { var j = Math.floor(rnd() * (i + 1)), t = arr[i]; arr[i] = arr[j]; arr[j] = t; }
    return arr;
  }
  function fmt(x, d) { return x.toFixed(d == null ? 2 : d); }
  // 选项去重：从候选里补足 4 个与答案不同的
  function options(rnd, ans, cands) {
    var seen = {}, out = [ans];
    seen[ans] = 1;
    shuffle(rnd, cands.slice()).forEach(function (c) { if (out.length < 4 && !seen[c]) { seen[c] = 1; out.push(c); } });
    return shuffle(rnd, out);
  }
  function tr(up, lo) { return 'n=' + up + ' → n=' + lo; }
  var METALS = [{ name: '钠', W: 2.29 }, { name: '钾', W: 2.25 }, { name: '钙', W: 3.20 }, { name: '锌', W: 3.34 }, { name: '钨', W: 4.54 }];
  var KINDS = ['group', 'one', 'longest', 'shortest', 'absorb', 'collide', 'ion', 'visible', 'photo'];
  // 返回 { kind, text, options[], answer, explain, show: { n, lines: [[up, lo]...], hi: [up, lo] } }，show 供能级图高亮
  function quiz(rnd, kind, prev) {
    rnd = rnd || Math.random;
    if (!kind || KINDS.indexOf(kind) < 0) {
      do kind = pick(rnd, KINDS); while (prev && kind === prev.kind && rnd() < 0.8);
    }
    var n, q = { kind: kind }, ls, a, i;
    if (kind === 'group' || kind === 'one') {
      n = 3 + Math.floor(rnd() * 4);
      var one = kind === 'one', ans = one ? countOne(n) : countGroup(n);
      q.text = (one ? '一个' : '一群') + '处于 n = ' + n + ' 能级的氢原子向低能级跃迁，最多能辐射出几种不同频率的光子？';
      q.options = options(rnd, ans + ' 种', [countGroup(n), countOne(n), n, countGroup(n - 1), countGroup(n + 1), n + 1].map(function (x) { return x + ' 种'; }));
      q.answer = ans + ' 种';
      q.explain = one
        ? '一个氢原子一次只处于一个能级，最多是逐级向下跳：' + n + '→' + (n - 1) + '→…→1，共 n − 1 = ' + ans + ' 种。'
        : '一群原子各种跃迁都会发生，任取两个能级就是一种：C(' + n + ', 2) = n(n − 1)/2 = ' + ans + ' 种。';
      q.show = { n: n, lines: one ? chain(n) : allPairs(n) };
    } else if (kind === 'longest' || kind === 'shortest') {
      n = 4 + Math.floor(rnd() * 2);
      ls = linesFrom(n);
      var best = kind === 'longest' ? ls[ls.length - 1] : ls[0];
      q.text = '一群处于 n = ' + n + ' 能级的氢原子向低能级跃迁，辐射出的光子中' + (kind === 'longest' ? '波长最长' : '频率最高') + '的是哪个跃迁产生的？';
      q.answer = tr(best.up, best.lo);
      q.options = options(rnd, q.answer, ls.map(function (l) { return tr(l.up, l.lo); }));
      q.explain = kind === 'longest'
        ? '波长最长 ↔ 光子能量最小 ↔ 能级差最小：相邻的两个最高能级 ' + q.answer + '，ΔE = ' + fmt(best.ev) + ' eV，λ ≈ ' + fmt(best.lam, 0) + ' nm。'
        : '频率最高 ↔ 能级差最大：从最高能级直接跳到基态 ' + q.answer + '，hν = ' + fmt(best.ev) + ' eV。';
      q.show = { n: n, lines: allPairs(n), hi: [best.up, best.lo] };
    } else if (kind === 'absorb') {
      // 基态氢原子能吸收哪个光子：一个恰好等于能级差，其他三个不等（且都小于 13.6 eV，不能电离）
      var m = 2 + Math.floor(rnd() * 3), good = dE(m, 1);
      var bads = [10.0, 11.0, 11.5, 12.0, 12.5, 13.0, 9.0, 3.4].filter(function (x) { return absorbPhoton(1, x).kind === 'pass'; });
      q.text = '处于基态的氢原子，能吸收下列哪种能量的光子而跃迁到激发态？';
      q.answer = fmt(good) + ' eV';
      q.options = options(rnd, q.answer, bads.map(function (x) { return fmt(x, 1) + ' eV'; }));
      q.explain = '光子要被吸收，能量必须恰好等于两能级之差（大于电离能时例外）：E' + m + ' − E1 = ' + fmt(E(m)) + ' − (−13.6) = ' + fmt(good) + ' eV，原子跃迁到 n = ' + m + '。其他能量都不等于能级差，光子不被吸收。';
      q.show = { n: m, lines: [[m, 1]], hi: [m, 1], absorb: true };
    } else if (kind === 'collide') {
      var evs = [10.5, 11.0, 12.3, 12.5, 12.9, 13.0];
      var ev = pick(rnd, evs), top = collideMax(1, ev).top;
      q.text = '用动能为 ' + fmt(ev, 1) + ' eV 的电子轰击一群处于基态的氢原子，氢原子最高能跃迁到哪个能级？';
      q.answer = 'n = ' + top;
      q.options = options(rnd, q.answer, ['n = 1（不跃迁）', 'n = 2', 'n = 3', 'n = 4', 'n = 5']);
      q.explain = '电子与原子碰撞时，原子只取走能级差那部分能量，电子带着剩余动能离开，所以电子动能大于等于能级差就行：E' + top + ' − E1 = ' + fmt(dE(top, 1)) + ' eV ≤ ' + fmt(ev, 1) + ' eV < E' + (top + 1) + ' − E1 = ' + fmt(dE(top + 1, 1)) + ' eV。';
      q.show = { n: top, lines: [[top, 1]], hi: [top, 1], absorb: true };
    } else if (kind === 'ion') {
      n = 1 + Math.floor(rnd() * 4);
      var e = ionize(n);
      q.text = '处于 n = ' + n + ' 能级的氢原子，至少要吸收多少能量才能电离？';
      q.answer = fmt(e) + ' eV';
      q.options = options(rnd, q.answer, [1, 2, 3, 4, 5].filter(function (k) { return k !== n; }).map(function (k) { return fmt(ionize(k)) + ' eV'; }).concat([fmt(dE(n + 1, n)) + ' eV']));
      q.explain = '电离就是把电子移到 n = ∞（E = 0），所需最小能量 0 − E' + n + ' = ' + fmt(e) + ' eV。能量更大的光子也能使它电离，多出的部分成为电子的动能。';
      q.show = { n: n, lines: [[Infinity, n]], hi: [Infinity, n], absorb: true };
    } else if (kind === 'visible') {
      n = 3 + Math.floor(rnd() * 4);
      ls = linesFrom(n);
      var vis = ls.filter(function (l) { return l.lam >= 380 && l.lam <= 750; }).length;
      q.text = '一群处于 n = ' + n + ' 能级的氢原子向低能级跃迁，辐射的光中有几种是可见光（光子能量 1.62～3.11 eV）？';
      q.answer = vis + ' 种';
      q.options = options(rnd, q.answer, [0, 1, 2, 3, 4, 5, 6].map(function (x) { return x + ' 种'; }));
      q.explain = '可见光都在巴耳末系（跃迁到 n = 2）中：' + ls.filter(function (l) { return l.lam >= 380 && l.lam <= 750; }).map(function (l) { return tr(l.up, l.lo) + ' ' + fmt(l.ev) + ' eV'; }).join('，') + '。跃迁到 n = 1 的光子能量都大于 10.2 eV（紫外），跃迁到 n = 3 及以上的都小于 1.51 eV（红外）。';
      q.show = { n: n, lines: allPairs(n), vis: true };
    } else {
      // 与光电效应结合：用 up → lo 的光照射金属，求最大初动能
      var pairs = [[2, 1], [3, 1], [4, 1], [4, 2], [3, 2]], p = pick(rnd, pairs), mt = pick(rnd, METALS), k = photoEk(p[0], p[1], mt.W);
      if (k <= 0) { mt = METALS[0]; k = photoEk(p[0], p[1], mt.W); }
      if (k <= 0) { p = [4, 1]; k = photoEk(4, 1, mt.W); }
      q.text = '用氢原子从 n = ' + p[0] + ' 跃迁到 n = ' + p[1] + ' 时辐射的光照射' + mt.name + '（逸出功 ' + fmt(mt.W) + ' eV），光电子的最大初动能是多少？';
      q.answer = fmt(k) + ' eV';
      var hv = dE(p[0], p[1]);
      q.options = options(rnd, q.answer, [hv, hv + mt.W, -E(p[0]) - mt.W, -E(p[1]) - mt.W, k + 1, k - 1].filter(function (x) { return x > 0; }).map(function (x) { return fmt(x) + ' eV'; }));
      q.explain = '光子能量 hν = E' + p[0] + ' − E' + p[1] + ' = ' + fmt(hv) + ' eV，由光电效应方程 Ekmax = hν − W₀ = ' + fmt(hv) + ' − ' + fmt(mt.W) + ' = ' + fmt(k) + ' eV。';
      q.show = { n: p[0], lines: [p], hi: p };
    }
    return q;
  }
  function chain(n) { var out = []; for (var i = n; i > 1; i--) out.push([i, i - 1]); return out; }
  function allPairs(n) { return linesFrom(n).map(function (l) { return [l.up, l.lo]; }); }

  // ---------- 格式 ----------
  function sci(x, n) {
    if (x === 0) return '0';
    var e = Math.floor(Math.log10(Math.abs(x))), m = x / Math.pow(10, e);
    if (Math.abs(m) >= 9.995) { m /= 10; e++; }
    var sup = String(e).replace(/-/g, '⁻').replace(/\d/g, function (d) { return '⁰¹²³⁴⁵⁶⁷⁸⁹'[d]; });
    return m.toFixed(n == null ? 2 : n) + '×10' + sup;
  }
  function nName(n) { return n === Infinity ? '∞' : String(n); }

  window.Bohr = {
    E1: E1, R1: R1, V1: V1, H: H, E0: E0, C: C, HC: HC, NMAX: NMAX, TOL: TOL, SERIES: SERIES, SERIES_ID: SERIES_ID, RYD: RYD, KINDS: KINDS,
    clamp: clamp, E: E, r: r, ek: ek, ep: ep, v: v, ionize: ionize, dE: dE, lamOf: lamOf, nuOf: nuOf, evOfLam: evOfLam,
    line: line, linesFrom: linesFrom, seriesLines: seriesLines, seriesLimit: seriesLimit, countGroup: countGroup, countOne: countOne, balmer: balmer,
    absorbPhoton: absorbPhoton, collideMax: collideMax, photoEk: photoEk, quiz: quiz, sci: sci, nName: nName, fmt: fmt
  };
})();
