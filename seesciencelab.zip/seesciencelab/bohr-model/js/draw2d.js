// 2D 绘制：玻尔轨道图（rn = n²r1 按比例）、氢原子能级图与跃迁箭头、氢原子光谱（全波段对数刻度 + 可见光放大）
// 能级图纵轴按 y ∝ (|E|/13.6)^0.35 压缩（示意，拉开 n = 4、5、6 的间距），n = ∞ 紧贴在最高能级上方；能量数值按 En = −13.6/n² 标注
(function () {
  var B = window.Bohr, SP = window.Spectrum;
  var ELEC = '#4fc3f7', GOLD = '#ffc94a', RED = '#ff7a59', GREEN = '#7ee081';
  var MUTED = '#8d99ab', TEXT = '#e6ebf2', LINE = 'rgba(141,153,171,.55)';
  var FONT = '-apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", sans-serif';
  var LAM0 = 90, LAM1 = 8000;      // 全波段光谱条的范围（nm，对数刻度）
  var GAMMA = 0.35;

  function font(px, w) { return (w ? w + ' ' : '') + px + 'px ' + FONT; }
  function label(ctx, s, x, y, o) {
    o = o || {};
    ctx.font = font(o.size || 12, o.bold ? 600 : null);
    ctx.textAlign = o.align || 'center'; ctx.textBaseline = o.base || 'middle';
    ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(5,7,13,.85)'; ctx.strokeText(s, x, y);
    ctx.fillStyle = o.color || TEXT; ctx.fillText(s, x, y);
  }
  function arrow(ctx, x1, y1, x2, y2, size, color, width, dash) {
    var a = Math.atan2(y2 - y1, x2 - x1), len = Math.hypot(x2 - x1, y2 - y1);
    if (len < 1) return;
    size = Math.min(size, len * 0.6);
    ctx.strokeStyle = ctx.fillStyle = color; ctx.lineWidth = width || 2; ctx.setLineDash(dash || []);
    ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2 - Math.cos(a) * size * 0.6, y2 - Math.sin(a) * size * 0.6); ctx.stroke();
    ctx.setLineDash([]);
    ctx.beginPath();
    ctx.moveTo(x2, y2);
    ctx.lineTo(x2 - size * Math.cos(a - 0.42), y2 - size * Math.sin(a - 0.42));
    ctx.lineTo(x2 - size * Math.cos(a + 0.42), y2 - size * Math.sin(a + 0.42));
    ctx.closePath(); ctx.fill();
  }
  // 光子：一小段正弦波包，沿 (dx, dy) 方向前进，头部在 (x, y)
  function photon(ctx, x, y, dx, dy, color, k) {
    var len = Math.hypot(dx, dy) || 1, ux = dx / len, uy = dy / len, L = 22 * k, amp = 4 * k;
    ctx.strokeStyle = color; ctx.lineWidth = Math.max(1.5, 2 * k); ctx.setLineDash([]);
    ctx.beginPath();
    for (var i = 0; i <= 24; i++) {
      var s = -L + L * i / 24, w = Math.sin(i / 24 * Math.PI * 4) * amp * Math.sin(i / 24 * Math.PI);
      var px = x + ux * s - uy * w, py = y + uy * s + ux * w;
      if (i) ctx.lineTo(px, py); else ctx.moveTo(px, py);
    }
    ctx.stroke();
    ctx.fillStyle = color; ctx.beginPath(); ctx.arc(x, y, Math.max(2, 2.4 * k), 0, 7); ctx.fill();
  }
  function electron(ctx, x, y, r, alpha) {
    ctx.globalAlpha = alpha == null ? 1 : alpha;
    var g = ctx.createRadialGradient(x, y, 0, x, y, r * 2.6);
    g.addColorStop(0, 'rgba(79,195,247,.6)'); g.addColorStop(1, 'rgba(79,195,247,0)');
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r * 2.6, 0, 7); ctx.fill();
    ctx.fillStyle = ELEC; ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.fill();
    if (r >= 4) { ctx.strokeStyle = '#06202c'; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.moveTo(x - r * 0.5, y); ctx.lineTo(x + r * 0.5, y); ctx.stroke(); }
    ctx.globalAlpha = 1;
  }
  function nucleus(ctx, x, y, r) {
    var g = ctx.createRadialGradient(x - r * 0.3, y - r * 0.3, 0, x, y, r);
    g.addColorStop(0, '#ffb199'); g.addColorStop(1, '#d9472b');
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.fill();
    ctx.strokeStyle = '#3a0d05'; ctx.lineWidth = 1.4;
    ctx.beginPath(); ctx.moveTo(x - r * 0.5, y); ctx.lineTo(x + r * 0.5, y); ctx.moveTo(x, y - r * 0.5); ctx.lineTo(x, y + r * 0.5); ctx.stroke();
  }
  // 自动换行（中文按字符断开）
  function wrap(ctx, s, maxW) {
    var out = [], cur = '';
    for (var i = 0; i < s.length; i++) {
      var t = cur + s[i];
      // 标点不放在行首
      if (ctx.measureText(t).width > maxW && cur && '，。？、；：）'.indexOf(s[i]) < 0) { out.push(cur); cur = s[i]; } else cur = t;
    }
    if (cur) out.push(cur);
    return out;
  }
  function eTxt(n) { return n === Infinity ? '0' : B.E(n).toFixed(2); }
  function lineKey(up, lo) { return B.nName(up) + '-' + lo; }

  // ---------- 视图 ----------
  function View(canvas) {
    var ctx = canvas.getContext('2d'), W = 0, H = 0, dpr = 1, narrow = false, geo = {};
    function resize(w, h) {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      W = w; H = h; narrow = w < 640;
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
      canvas.style.width = w + 'px'; canvas.style.height = h + 'px';
    }
    function bg() {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      var g = ctx.createLinearGradient(0, 0, 0, H);
      g.addColorStop(0, '#04060c'); g.addColorStop(1, '#0a1120');
      ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    }
    // 区域 A 与 G：宽屏左右排，窄屏上下排
    function split(ratio, top) {
      var t0 = top != null ? top : (narrow ? 70 : 48), bottom = 40, h = Math.max(220, H - t0 - bottom);
      if (W >= 760 && W / h > 1.2) {
        var aw = Math.round((W - 28) * ratio);
        return { wide: true, A: { x: 14, y: t0, w: aw, h: h }, G: { x: 14 + aw + 14, y: t0, w: W - aw - 42, h: h } };
      }
      var ah = Math.round(h * ratio);
      return { wide: false, A: { x: 10, y: t0, w: W - 20, h: ah }, G: { x: 10, y: t0 + ah + 6, w: W - 20, h: h - ah - 6 } };
    }

    // ---------- 能级图 ----------
    // o: { nMax, cur（当前能级，可为 Infinity 或 null）, hover, arrows: [{ up, lo, emit, color, w, alpha, label, x?, prog }], layout: 'col'|'center', nLab }
    // 返回 { ys: {n: y}, x0, x1, ax: {key: x} }
    function levelDiagram(R, o) {
      var nMax = o.nMax || B.NMAX, fs = R.w < 360 ? 10.5 : 12;
      var L = R.w < 360 ? 34 : 42, Rm = R.w < 360 ? 58 : 70;
      var x0 = R.x + L, x1 = R.x + R.w - Rm, top = R.y + 16, bot = R.y + R.h - 12;
      // n = ∞ 不按比例：放在 n = nMax 上方 2.2 个“nMax 与 nMax−1 间距”处，省出上方的空白
      function u(n) { return Math.pow(-B.E(n) / 13.6, GAMMA); }
      var uInf = u(nMax) - 2.2 * (u(nMax - 1) - u(nMax));
      function Y(n) { return top + (n === Infinity ? 0 : (u(n) - uInf) / (1 - uInf)) * (bot - top); }
      var ys = {}, levels = [];
      for (var n = 1; n <= nMax; n++) levels.push(n);
      levels.push(Infinity);
      // 电离区（E > 0）淡色带
      var gi = ctx.createLinearGradient(0, R.y, 0, Y(Infinity));
      gi.addColorStop(0, 'rgba(79,195,247,.10)'); gi.addColorStop(1, 'rgba(79,195,247,0)');
      ctx.fillStyle = gi; ctx.fillRect(x0, R.y, x1 - x0, Y(Infinity) - R.y);
      levels.forEach(function (n) {
        var y = Y(n), on = o.cur === n, hov = o.hover === n;
        ys[n] = y;
        ctx.strokeStyle = on ? GOLD : hov ? TEXT : n === Infinity ? 'rgba(141,153,171,.75)' : LINE;
        ctx.lineWidth = on ? 2.4 : hov ? 2 : 1.4;
        ctx.setLineDash(n === Infinity ? [5, 4] : []);
        ctx.beginPath(); ctx.moveTo(x0, y); ctx.lineTo(x1, y); ctx.stroke(); ctx.setLineDash([]);
        label(ctx, 'n=' + B.nName(n), x0 - 6, y, { align: 'right', size: fs, color: on ? GOLD : hov ? TEXT : MUTED, bold: on });
        label(ctx, eTxt(n) + ' eV', x1 + 6, y, { align: 'left', size: fs, color: on ? GOLD : MUTED });
      });
      if (o.nLab !== false && !narrow) label(ctx, 'E', x1 + 6, R.y + 2, { align: 'left', size: fs, color: MUTED });
      if (o.ionLabel) label(ctx, '电离（E > 0，电子自由）', (x0 + x1) / 2, R.y + 4, { size: fs - 1, color: 'rgba(141,153,171,.9)' });

      // 箭头位置：col 布局按下能级分组排成若干列（与教材谱线系图相同），center 布局都放在中间
      var arrows = o.arrows || [], ax = {};
      if (o.layout === 'col' && arrows.length) {
        var groups = {}, order = [];
        arrows.forEach(function (a) { if (!groups[a.lo]) { groups[a.lo] = []; order.push(a.lo); } groups[a.lo].push(a); });
        order.sort(function (a, b) { return a - b; });
        var slots = arrows.length + (order.length - 1) * 1.2 + 1, step = (x1 - x0) / slots, sx = x0 + step;
        order.forEach(function (lo, gi2) {
          if (gi2) sx += step * 1.2;
          groups[lo].sort(function (a, b) { return a.up - b.up; });
          groups[lo].forEach(function (a) { ax[lineKey(a.up, a.lo)] = sx; sx += step; });
        });
      }
      arrows.forEach(function (a, i) {
        var x = a.x != null ? a.x : ax[lineKey(a.up, a.lo)] != null ? ax[lineKey(a.up, a.lo)] : x0 + (x1 - x0) * (0.5 + (i - (arrows.length - 1) / 2) * 0.12);
        ax[lineKey(a.up, a.lo)] = x;
        var yu = ys[a.up], yl = ys[a.lo], p = a.prog == null ? 1 : a.prog;
        if (yu == null || yl == null) return;
        ctx.globalAlpha = a.alpha == null ? 1 : a.alpha;
        if (a.glow) {
          ctx.strokeStyle = a.color; ctx.lineWidth = 9; ctx.globalAlpha *= 0.25;
          ctx.beginPath(); ctx.moveTo(x, yu); ctx.lineTo(x, yl); ctx.stroke();
          ctx.globalAlpha = a.alpha == null ? 1 : a.alpha;
        }
        if (a.emit) arrow(ctx, x, yu, x, yu + (yl - yu) * p, 8, a.color, a.w || 2);
        else arrow(ctx, x, yl, x, yl + (yu - yl) * p, 8, a.color, a.w || 2, a.dash);
        ctx.globalAlpha = 1;
        if (a.label && p >= 1) {
          var ly = (yu + yl) / 2;
          label(ctx, a.label, x + 7, ly, { align: 'left', size: fs, color: a.labelColor || TEXT });
          if (a.label2) label(ctx, a.label2, x + 7, ly + fs + 3, { align: 'left', size: fs - 1, color: MUTED });
        }
      });
      // 当前能级上的电子
      if (o.cur != null && ys[o.cur] != null && o.dot !== false) electron(ctx, x0 + 12, ys[o.cur], 4.5, o.dotAlpha);
      return { ys: ys, x0: x0, x1: x1, ax: ax, R: R };
    }

    // ---------- 场景一：轨道与能级跃迁 ----------
    // o: { n, shown（轨道图里电子所在能级）, zoom, ang, jump: { from, to, t }, photons: [{ x, y, dx, dy, lam, label }], free: [{ x, y, a }],
    //      arrow: { up, lo, emit, lam, prog }, hover, busy }
    // 轨道图坐标：以原子核为原点、轨道图半径 Rpx 为单位（u），x 右 y 下
    function drawLevels(o) {
      bg();
      var S = split(narrow ? 0.46 : 0.5), A = S.A, G = S.G;
      var cx = A.x + A.w / 2, cy = A.y + A.h / 2 - (S.wide ? 8 : 0), Rp = Math.max(40, Math.min(A.w, A.h) / 2 - 18), k = Math.max(0.7, Math.min(1.3, Rp / 170));
      function px(u) { return cx + u * Rp; }
      function py(u) { return cy + u * Rp; }
      function rad(n) { return n * n / (o.zoom * o.zoom); }
      ctx.save();
      ctx.beginPath(); ctx.rect(A.x, A.y - 4, A.w, A.h + 8); ctx.clip();
      // 轨道
      for (var n = 1; n <= B.NMAX; n++) {
        var rr = rad(n) * Rp, on = o.shown === n;
        if (rr > Math.hypot(A.w, A.h)) continue;
        ctx.strokeStyle = on ? 'rgba(255,201,74,.75)' : 'rgba(141,153,171,.38)';
        ctx.lineWidth = on ? 1.8 : 1.1; ctx.setLineDash(on ? [] : [4, 5]);
        ctx.beginPath(); ctx.arc(cx, cy, rr, 0, 7); ctx.stroke(); ctx.setLineDash([]);
        if (rr > 9) {
          var la = -Math.PI / 4, lx = cx + Math.cos(la) * rr, ly = cy + Math.sin(la) * rr;
          if (lx + 34 < A.x + A.w && ly > A.y + 6) label(ctx, 'n=' + n, lx + 4, ly - 6, { align: 'left', size: 11, color: on ? GOLD : MUTED });
        }
      }
      nucleus(ctx, cx, cy, Math.max(5, 6 * k));
      // 电子：跃迁时旧位置淡出、新位置出现（中间没有轨迹，只画一条虚线表示“跳”过去）
      if (o.jump && o.jump.t < 1 && o.jump.to !== Infinity && o.jump.from !== Infinity) {
        var t = o.jump.t, r0 = rad(o.jump.from), r1 = rad(o.jump.to);
        var x0 = px(Math.cos(o.ang) * r0), y0 = py(Math.sin(o.ang) * r0), x1 = px(Math.cos(o.ang) * r1), y1 = py(Math.sin(o.ang) * r1);
        ctx.strokeStyle = 'rgba(79,195,247,' + (0.6 * (1 - t)) + ')'; ctx.lineWidth = 1.2; ctx.setLineDash([3, 4]);
        ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke(); ctx.setLineDash([]);
        electron(ctx, x0, y0, 5 * k, 1 - t);
        electron(ctx, x1, y1, 5 * k, t);
        ctx.strokeStyle = 'rgba(79,195,247,' + (0.8 * (1 - t)) + ')'; ctx.lineWidth = 1.5;
        ctx.beginPath(); ctx.arc(x1, y1, 5 * k + 14 * t, 0, 7); ctx.stroke();
      } else if (o.shown !== Infinity && o.shown != null) {
        var re = rad(o.shown);
        electron(ctx, px(Math.cos(o.ang) * re), py(Math.sin(o.ang) * re), 5 * k);
      }
      (o.free || []).forEach(function (e) {
        electron(ctx, px(e.x), py(e.y), 5 * k, e.a);
        if (e.label) label(ctx, e.label, px(e.x), py(e.y) + 16 * k, { size: 11, color: ELEC });
      });
      (o.photons || []).forEach(function (p) {
        var col = SP.lamCSS(p.lam, p.a == null ? 0.95 : p.a);
        photon(ctx, px(p.x), py(p.y), p.dx, p.dy, col, k);
        if (p.label) label(ctx, p.label, px(p.x), py(p.y) - 16 * k, { size: 11, color: col });
      });
      ctx.restore();
      label(ctx, '轨道半径 rn = n²r1（按比例画）', cx, A.y + A.h + (S.wide ? 4 : -8), { size: 11, color: MUTED });

      // 能级图
      var arrows = [];
      if (o.arrow) {
        // 碰撞激发不是光子，用电子的颜色画虚线箭头
        var a = o.arrow, col = a.byE ? ELEC : SP.lamCSS(a.lam, 1), ev = B.dE(a.up, a.lo);
        arrows.push({ up: a.up, lo: a.lo, emit: a.emit, color: col, w: 2.6, prog: a.prog, x: null, dash: a.byE ? [6, 4] : null,
          label: (a.emit ? '放出 ' : a.byE ? '碰撞获得 ' : '吸收 ') + (a.ev || ev).toFixed(2) + ' eV' + (a.up === Infinity && !a.emit ? '（电离）' : ''), label2: a.byE || a.up === Infinity ? '' : 'λ = ' + fmtLam(a.lam), labelColor: col });
      }
      var gR = S.wide ? { x: G.x, y: G.y + 10, w: G.w, h: G.h - 20 } : { x: G.x, y: G.y + 6, w: G.w, h: G.h - 10 };
      geo = { scene: 'levels', lv: levelDiagram(gR, { cur: o.n, hover: o.hover, arrows: arrows, ionLabel: true }) };
      if (S.wide) label(ctx, '点能级线：让电子跃迁到该能级', G.x + G.w / 2, G.y + G.h + 4, { size: 11, color: MUTED });
    }
    function fmtLam(lam) { return lam >= 1000 ? (lam / 1000).toFixed(2) + ' μm' : lam.toFixed(0) + ' nm'; }

    // ---------- 场景二：谱线系与光谱 ----------
    // o: { nTop, filter（'all'|lyman|balmer|paschen）, mode（emit|absorb）, sel: { up, lo }, pulses: [{ up, lo, a }] }
    function seriesOn(o, lo) { return o.filter === 'all' || B.SERIES_ID[o.filter] === lo; }
    function drawSpectrum(o) {
      bg();
      var S = split(narrow ? 0.5 : 0.5), G = S.A, P = S.G;
      var lines = B.linesFrom(o.nTop), pul = {};
      (o.pulses || []).forEach(function (p) { pul[lineKey(p.up, p.lo)] = p.a; });
      var selK = o.sel ? lineKey(o.sel.up, o.sel.lo) : '';
      var arrows = lines.map(function (l) {
        var key = lineKey(l.up, l.lo), on = seriesOn(o, l.lo), sel = key === selK, pa = pul[key] || 0;
        return { up: l.up, lo: l.lo, emit: o.mode === 'emit', color: SP.lamCSS(l.lam, 1), w: sel ? 3.2 : 2, alpha: on ? (sel ? 1 : 0.55 + 0.45 * pa) : 0.15, glow: sel || pa > 0.3,
          label: sel ? (l.name ? l.name + ' ' : '') + fmtLam(l.lam) : '', labelColor: SP.lamCSS(l.lam, 1) };
      });
      var gR = { x: G.x, y: G.y + 6, w: G.w, h: G.h - 26 };
      var lv = levelDiagram(gR, { nMax: B.NMAX, cur: null, arrows: arrows, layout: 'col', dot: false });
      // 线系名称（放在每组箭头下方的能级线下）
      var hits = [];
      [1, 2, 3, 4, 5].forEach(function (lo) {
        var xs = lines.filter(function (l) { return l.lo === lo; }).map(function (l) { return lv.ax[lineKey(l.up, l.lo)]; });
        if (!xs.length) return;
        var xm = (Math.min.apply(null, xs) + Math.max.apply(null, xs)) / 2, s = B.SERIES[lo];
        label(ctx, xs.length > 1 || lo <= 3 ? s.name : '', xm, lv.ys[lo] + 11, { size: 11, color: seriesOn(o, lo) ? TEXT : MUTED, bold: lo <= 3 && seriesOn(o, lo) && o.filter !== 'all' });
      });
      lines.forEach(function (l) {
        var x = lv.ax[lineKey(l.up, l.lo)];
        hits.push({ x0: x - 7, x1: x + 7, y0: lv.ys[l.up] - 4, y1: lv.ys[l.lo] + 4, up: l.up, lo: l.lo });
      });
      label(ctx, '一群 n = ' + o.nTop + ' 的氢原子：' + lines.length + ' 种谱线（C(' + o.nTop + ',2)）', G.x + G.w / 2, G.y + G.h - 8, { size: 12, color: GOLD });

      // 光谱条：全波段（对数刻度）+ 可见光放大
      var ph = P.h, sw = P.w - 20, sx = P.x + 10;
      var h1 = Math.max(34, Math.min(70, ph * 0.2)), h2 = Math.max(40, Math.min(90, ph * 0.26));
      var gap = S.wide ? 76 : 54, content = h1 + gap + h2 + 82;
      var y1 = P.y + (S.wide ? Math.max(24, (ph - content) / 2) : 24), y2 = y1 + h1 + gap;
      var absorb = o.mode === 'absorb';
      function LX(lam) { return sx + sw * (Math.log(lam) - Math.log(LAM0)) / (Math.log(LAM1) - Math.log(LAM0)); }
      function VX(lam) { return sx + sw * (lam - 380) / 370; }
      label(ctx, absorb ? '吸收光谱：连续谱上的暗线' : '发射光谱：暗背景上的亮线', sx, y1 - 14, { align: 'left', size: 12, bold: true });
      // 全波段
      var gr = ctx.createLinearGradient(LX(LAM0), 0, LX(LAM1), 0);
      for (var s = 0; s <= 40; s++) {
        var lam = Math.exp(Math.log(LAM0) + (Math.log(LAM1) - Math.log(LAM0)) * s / 40), c = SP.lamRGB(lam);
        gr.addColorStop(s / 40, SP.css(c, absorb ? (SP.visible(lam) ? 0.95 : 0.2) : 0.10));
      }
      ctx.fillStyle = absorb ? gr : '#05070d'; ctx.fillRect(sx, y1, sw, h1);
      if (!absorb) { ctx.fillStyle = gr; ctx.fillRect(sx, y1, sw, h1); }
      ctx.strokeStyle = LINE; ctx.lineWidth = 1; ctx.strokeRect(sx + 0.5, y1 + 0.5, sw - 1, h1 - 1);
      // 波段分界
      [380, 750].forEach(function (lam) {
        ctx.strokeStyle = 'rgba(230,235,242,.35)'; ctx.setLineDash([3, 3]);
        ctx.beginPath(); ctx.moveTo(LX(lam), y1 - 4); ctx.lineTo(LX(lam), y1 + h1 + 4); ctx.stroke(); ctx.setLineDash([]);
      });
      label(ctx, '紫外', (LX(LAM0) + LX(380)) / 2, y1 + h1 + 24, { size: 11, color: MUTED });
      label(ctx, '可见', (LX(380) + LX(750)) / 2, y1 + h1 + 24, { size: 11, color: MUTED });
      label(ctx, '红外', (LX(750) + LX(LAM1)) / 2, y1 + h1 + 24, { size: 11, color: MUTED });
      [100, 200, 500, 1000, 2000, 5000].forEach(function (lam) {
        var x = LX(lam);
        ctx.strokeStyle = MUTED; ctx.beginPath(); ctx.moveTo(x, y1 + h1); ctx.lineTo(x, y1 + h1 + 4); ctx.stroke();
        label(ctx, lam >= 1000 ? lam / 1000 + ' μm' : lam + ' nm', x, y1 + h1 + 11, { size: 10, color: MUTED });
      });
      function drawLine(x, yy, hh, l, sel, pa) {
        var on = seriesOn(o, l.lo), col = SP.lamCSS(l.lam, on ? 1 : 0.3);
        if (absorb) {
          ctx.fillStyle = on ? 'rgba(0,0,0,.92)' : 'rgba(0,0,0,.35)'; ctx.fillRect(x - (sel ? 1.8 : 1.2), yy, sel ? 3.6 : 2.4, hh);
        } else {
          if (on && (sel || pa > 0.05)) {
            ctx.fillStyle = SP.lamCSS(l.lam, 0.25 + 0.3 * (sel ? 1 : pa)); ctx.fillRect(x - 5, yy, 10, hh);
          }
          ctx.fillStyle = col; ctx.fillRect(x - (sel ? 1.6 : 1.1), yy, sel ? 3.2 : 2.2, hh);
        }
        if (sel) { ctx.strokeStyle = GOLD; ctx.lineWidth = 1.5; ctx.strokeRect(x - 5, yy - 3, 10, hh + 6); }
      }
      lines.forEach(function (l) {
        var x = LX(l.lam), key = lineKey(l.up, l.lo);
        if (l.lam > LAM1) return;
        drawLine(x, y1, h1, l, key === selK, pul[key] || 0);
        hits.push({ x0: x - 5, x1: x + 5, y0: y1, y1: y1 + h1, up: l.up, lo: l.lo });
      });
      // 线系标注（全波段条上方）
      [1, 2, 3].forEach(function (lo) {
        var ls = lines.filter(function (l) { return l.lo === lo; });
        if (!ls.length) return;
        var xa = LX(Math.min.apply(null, ls.map(function (l) { return l.lam; }))), xb = LX(Math.max.apply(null, ls.map(function (l) { return l.lam; })));
        ctx.strokeStyle = seriesOn(o, lo) ? 'rgba(230,235,242,.6)' : 'rgba(141,153,171,.3)'; ctx.lineWidth = 1;
        ctx.beginPath(); ctx.moveTo(xa, y1 - 3); ctx.lineTo(xa, y1 - 6); ctx.lineTo(xb, y1 - 6); ctx.lineTo(xb, y1 - 3); ctx.stroke();
      });
      // 可见光放大
      label(ctx, '可见光部分放大（巴耳末系）', sx, y2 - 14, { align: 'left', size: 12, bold: true });
      var gv = ctx.createLinearGradient(VX(380), 0, VX(750), 0);
      for (var v = 0; v <= 30; v++) { var lv2 = 380 + 370 * v / 30; gv.addColorStop(v / 30, SP.lamCSS(lv2, absorb ? 1 : 0.08)); }
      ctx.fillStyle = absorb ? gv : '#05070d'; ctx.fillRect(sx, y2, sw, h2);
      if (!absorb) { ctx.fillStyle = gv; ctx.fillRect(sx, y2, sw, h2); }
      ctx.strokeStyle = LINE; ctx.strokeRect(sx + 0.5, y2 + 0.5, sw - 1, h2 - 1);
      [400, 500, 600, 700].forEach(function (lam) {
        var x = VX(lam);
        ctx.strokeStyle = MUTED; ctx.beginPath(); ctx.moveTo(x, y2 + h2); ctx.lineTo(x, y2 + h2 + 4); ctx.stroke();
        label(ctx, lam + ' nm', x, y2 + h2 + 12, { size: 10, color: MUTED });
      });
      var visLines = lines.filter(function (l) { return SP.visible(l.lam); }).sort(function (a, b) { return a.lam - b.lam; }), prevX = -1e9, row = 0;
      visLines.forEach(function (l) {
        var x = VX(l.lam), key = lineKey(l.up, l.lo);
        drawLine(x, y2, h2, l, key === selK, pul[key] || 0);
        hits.push({ x0: x - 7, x1: x + 7, y0: y2, y1: y2 + h2, up: l.up, lo: l.lo });
        row = x - prevX < 72 ? 1 - row : 0; prevX = x;    // 挨得太近的标注错开一行
        label(ctx, (l.name ? l.name + ' ' : '') + l.lam.toFixed(1), x, y2 + h2 + 26 + row * 14, { size: 10.5, color: seriesOn(o, l.lo) ? SP.lamCSS(l.lam, 1) : MUTED });
      });
      if (!visLines.length) label(ctx, 'n = 2 时还没有可见光谱线（只有莱曼系的一条紫外线）', sx + sw / 2, y2 + h2 / 2, { size: 12, color: MUTED });
      var yf = y2 + h2 + 60;
      if (yf + 14 < P.y + P.h) label(ctx, '巴耳末公式 1/λ = R(1/2² − 1/n²)，n = 3, 4, 5, …', sx, yf, { align: 'left', size: 12, color: MUTED });
      if (yf + 34 < P.y + P.h) label(ctx, '点能级图上的箭头或光谱线查看这条谱线', sx, yf + 20, { align: 'left', size: 11, color: MUTED });
      geo = { scene: 'spectrum', hits: hits };
    }

    // ---------- 场景三：判断练习 ----------
    // o: { q, answered }：答题前只标出起始能级，答完画出相关跃迁并高亮答案
    function drawQuiz(o) {
      bg();
      var q = o.q;
      if (!q) return;
      var t0 = narrow ? 136 : 96, mw = Math.min(W - 32, 720), x = (W - mw) / 2;    // 窄屏让开右上角的面板按钮
      ctx.font = font(narrow ? 14 : 16, 600);
      var ls = wrap(ctx, q.text, mw), lh = narrow ? 20 : 23;
      ls.forEach(function (s, i) { label(ctx, s, x, t0 + 4 + i * lh, { align: 'left', size: narrow ? 14 : 16, bold: true }); });
      var gy = t0 + ls.length * lh + 16, gw = Math.min(W - 24, 620);
      var R = { x: (W - gw) / 2, y: gy, w: gw, h: Math.max(200, H - gy - 60) };
      var sh = q.show || {}, arrows = [];
      if (o.answered) {
        var hiK = sh.hi ? lineKey(sh.hi[0], sh.hi[1]) : '';
        arrows = (sh.lines || []).map(function (p) {
          var up = p[0], lo = p[1], lam = B.lamOf(B.dE(up, lo)), key = lineKey(up, lo), hi = key === hiK;
          var dim = sh.vis && !SP.visible(lam);
          return { up: up, lo: lo, emit: !sh.absorb, color: SP.lamCSS(lam, 1), w: hi ? 3 : 2, alpha: dim ? 0.25 : hi || !sh.hi ? 1 : 0.4, glow: hi || (sh.vis && !dim),
            label: hi || (sh.lines.length <= 2) ? B.dE(up, lo).toFixed(2) + ' eV' : '', labelColor: SP.lamCSS(lam, 1) };
        });
      }
      levelDiagram(R, { cur: sh.n, arrows: arrows, layout: arrows.length > 2 ? 'col' : 'center', ionLabel: q.kind === 'ion' });
      geo = { scene: 'quiz' };
    }

    return { resize: resize, drawLevels: drawLevels, drawSpectrum: drawSpectrum, drawQuiz: drawQuiz, geo: function () { return geo; }, narrow: function () { return narrow; } };
  }

  window.BohrDraw = { View: View };
})();
