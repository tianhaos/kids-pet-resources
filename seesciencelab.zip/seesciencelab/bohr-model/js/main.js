(function () {
  var B = window.Bohr, SP = window.Spectrum, BD = window.BohrDraw;
  var $ = function (id) { return document.getElementById(id); };
  var qa = function (sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); };
  var NAME = '玻尔模型';

  var state = {
    scene: 'levels', paused: false,
    // 能级跃迁：n 为能级（Infinity 表示已电离），shown 为轨道图里电子所在能级（跃迁动画中途切换）
    n: 1, shown: 1, zoom: 3.36, ang: -0.6, auto: false, inKind: 'photon', inE: 10.2, hover: null, msg: '', last: null,
    // 谱线系：一群处于 nTop 的氢原子
    nTop: 4, filter: 'all', mode: 'emit', sel: null,
    // 练习
    quiz: null, qKind: '', score: { right: 0, total: 0 }
  };
  var HINTS = {
    levels: '电子只能在特定轨道上运动；在能级间跃迁时吸收或放出光子，hν = Em − En',
    spectrum: '一群处于高能级的氢原子，各种跃迁都会发生：氢原子光谱是一条条分立的亮线',
    quiz: '先在能级图上找出起止能级，再算能级差'
  };
  var SPEED = 1.15;                // 光子、入射电子在轨道图中的速度（轨道图半径 / s）
  var START = -1.7;                // 入射粒子出发的位置（轨道图左侧外）

  var stage = $('stage'), panel = $('panel'), cv = $('view');
  var view = BD.View(cv);
  function setSeg(attr, val) { qa('[data-' + attr + ']').forEach(function (b) { b.classList.toggle('on', b.dataset[attr] === String(val)); }); }

  // ---------- 场景 ----------
  qa('[data-scene]').forEach(function (b) {
    b.addEventListener('click', function () { setScene(b.dataset.scene); Analytics.track(NAME, '场景', b.textContent); });
  });
  function setScene(sc) {
    state.scene = sc;
    if (sc === 'quiz') {
      if (!state.quiz) nextQuiz();
      panel.classList.remove('collapsed');
    }
    syncUI();
  }

  // ---------- 能级跃迁：动画 ----------
  // photons / free 用轨道图坐标（原子核为原点，单位为轨道图半径，x 右 y 下）
  var anim = { photons: [], free: [], jump: null, arrow: null, idle: 0 };
  function busy() {
    return anim.photons.some(function (p) { return p.incoming && !p.done; }) || anim.free.some(function (e) { return e.incoming && !e.done; }) || (anim.jump && anim.jump.t < 1);
  }
  function lamOfJump(a, b) { return B.lamOf(B.dE(a, b)); }
  // 轨道图缩放：最高轨道画在半径的 1/1.12 处，留出光子飞出的空间
  function zoomFor(n) { return 1.12 * B.clamp(n === Infinity ? B.NMAX : Math.max(3, n), 3, B.NMAX); }
  // 电子所在位置（轨道图坐标）
  function elecPos(n) { var rr = n * n / (state.zoom * state.zoom); return { x: Math.cos(state.ang) * rr, y: Math.sin(state.ang) * rr }; }

  function doJump(from, to) {
    anim.jump = { from: from, to: to, t: 0 };
    state.n = to; anim.idle = 0;
    if (to === Infinity) {
      // 电离：电子离开原子
      var p = elecPos(from), a = state.ang;
      anim.free.push({ x: p.x, y: p.y, vx: Math.cos(a) * 0.6, vy: Math.sin(a) * 0.6, a: 1 });
      state.shown = Infinity;
    }
  }
  // 放出光子：电子从 from 跳到更低的 to
  function emit(from, to) {
    var lam = lamOfJump(from, to), p = from === Infinity ? { x: -0.9, y: -0.2 } : elecPos(from);
    if (from === Infinity) { anim.free = []; }
    doJump(from, to);
    var a = Math.atan2(p.y, p.x) + (Math.random() - 0.5) * 0.5;
    anim.photons.push({ x: p.x, y: p.y, dx: Math.cos(a), dy: Math.sin(a), lam: lam, label: B.dE(from, to).toFixed(2) + ' eV', a: 1 });
    anim.arrow = { up: from, lo: to, emit: true, lam: lam, prog: 0 };
    state.last = { up: from, lo: to, emit: true };
    state.msg = from === Infinity
      ? '自由电子被 H⁺ 俘获，落到 n = ' + to + '，放出 ' + B.dE(from, to).toFixed(2) + ' eV 的光子（假设电子原来静止）。'
      : '从 n = ' + from + ' 跃迁到 n = ' + to + '，放出光子 hν = E' + from + ' − E' + to + ' = ' + B.dE(from, to).toFixed(2) + ' eV。';
  }
  // 射入一个光子（能量 ev）
  function firePhoton(ev, why) {
    var lam = B.lamOf(ev);
    anim.photons.push({ x: START, y: -0.02, dx: 1, dy: 0, lam: lam, label: ev.toFixed(2) + ' eV', a: 1, incoming: true, ev: ev, why: why });
    state.msg = '射入能量为 ' + ev.toFixed(2) + ' eV 的光子……';
  }
  function fireElectron(ev) {
    anim.free.push({ x: START, y: 0.04, vx: SPEED * 0.8, vy: 0, a: 1, incoming: true, ev: ev, label: '电子 ' + ev.toFixed(2) + ' eV' });
    state.msg = '射入动能为 ' + ev.toFixed(2) + ' eV 的电子……';
  }
  // 入射光子到达原子核附近
  function photonHit(p) {
    p.done = true;
    var n = state.n;
    if (n === Infinity) { p.incoming = false; state.msg = '原子已电离（只剩 H⁺），没有电子可以吸收这个光子，光子穿过。'; return; }
    var r = B.absorbPhoton(n, p.ev);
    if (r.kind === 'pass') {
      p.incoming = false;
      state.msg = p.ev.toFixed(2) + ' eV 不等于 n = ' + n + ' 与任何能级的能量差，也小于电离能 ' + B.ionize(n).toFixed(2) + ' eV：光子不被吸收，直接穿过。';
      return;
    }
    p.a = 0;
    if (r.kind === 'jump') {
      doJump(n, r.to);
      anim.arrow = { up: r.to, lo: n, emit: false, lam: p.lam, prog: 0 };
      state.last = { up: r.to, lo: n, emit: false };
      state.msg = '光子能量恰好等于 E' + r.to + ' − E' + n + ' = ' + B.dE(r.to, n).toFixed(2) + ' eV，被吸收，电子跃迁到 n = ' + r.to + '。';
    } else {
      doJump(n, Infinity);
      var f = anim.free[anim.free.length - 1];
      var sp = 0.5 + 0.35 * Math.sqrt(r.rest);
      f.vx = Math.cos(state.ang) * sp; f.vy = Math.sin(state.ang) * sp;
      anim.arrow = { up: Infinity, lo: n, emit: false, lam: p.lam, prog: 0, ev: p.ev };
      state.last = { up: Infinity, lo: n, emit: false, rest: r.rest };
      state.msg = '光子能量 ' + p.ev.toFixed(2) + ' eV ≥ 电离能 ' + B.ionize(n).toFixed(2) + ' eV：被吸收，原子电离，电子带着 ' + r.rest.toFixed(2) + ' eV 的动能离开。';
    }
  }
  // 入射电子与原子碰撞：可以只交出一部分能量
  function electronHit(e) {
    e.done = true; e.incoming = false;
    var n = state.n;
    if (n === Infinity) { state.msg = '原子已电离，入射电子穿过。'; return; }
    var c = B.collideMax(n, e.ev, B.NMAX), cands = [];
    for (var m = n + 1; m <= c.top; m++) cands.push(m);
    if (c.ionize) cands.push(Infinity);
    if (!cands.length) {
      state.msg = '电子动能 ' + e.ev.toFixed(2) + ' eV 小于 E' + (n + 1) + ' − E' + n + ' = ' + B.dE(n + 1, n).toFixed(2) + ' eV，不能使原子跃迁（弹性碰撞），电子带着原有动能离开。';
      return;
    }
    var to = cands[Math.floor(Math.random() * cands.length)], give = to === Infinity ? B.ionize(n) : B.dE(to, n), rest = e.ev - give;
    e.vx = SPEED * 0.8 * Math.sqrt(Math.max(0.04, rest / e.ev)); e.vy = 0.12; e.label = '剩 ' + rest.toFixed(2) + ' eV';
    doJump(n, to);
    if (to === Infinity) { var f = anim.free[anim.free.length - 1]; f.vx = Math.cos(state.ang) * 0.5; f.vy = Math.sin(state.ang) * 0.5; }
    anim.arrow = { up: to, lo: n, emit: false, lam: B.lamOf(give), prog: 0, byE: true };
    state.last = { up: to, lo: n, emit: false, byE: true, rest: rest };
    var range = c.ionize ? 'n = ' + (n + 1) + ' 以上的任一能级，甚至电离' : c.top === n + 1 ? 'n = ' + c.top : 'n = ' + (n + 1) + '～' + c.top + ' 中的任一能级';
    state.msg = '电子动能 ' + e.ev.toFixed(2) + ' eV，可使原子跃迁到 ' + range + '。这次原子取走 ' + give.toFixed(2) + ' eV' + (to === Infinity ? '（电离）' : '，跃迁到 n = ' + to) + '，入射电子剩 ' + rest.toFixed(2) + ' eV 继续前进。';
  }
  // 让原子跃迁到 m（点能级线、能级按钮）：向下直接放出光子；向上射入恰好能量的光子
  function jumpTo(m) {
    if (busy()) return false;
    var n = state.n;
    if (m === n) return false;
    if (m < n) emit(n, m);
    else firePhoton(m === Infinity ? B.ionize(n) : B.dE(m, n), 'click');
    return true;
  }
  function stepLevels(dt) {
    if (state.shown !== Infinity) state.ang += dt * 2.2 / Math.pow(state.shown, 1.5);
    state.zoom += (zoomFor(Math.max(state.n === Infinity ? B.NMAX : state.n, state.shown === Infinity ? 1 : state.shown)) - state.zoom) * Math.min(1, dt * 3);
    if (anim.jump) {
      anim.jump.t = Math.min(1, anim.jump.t + dt / 0.35);
      if (anim.jump.t >= 0.5 && anim.jump.to !== Infinity) state.shown = anim.jump.to;
    }
    if (anim.arrow) anim.arrow.prog = Math.min(1, anim.arrow.prog + dt / 0.35);
    anim.photons.forEach(function (p) {
      var ox = p.x;
      p.x += p.dx * SPEED * dt; p.y += p.dy * SPEED * dt;
      if (p.incoming && !p.done && ox < 0 && p.x >= 0) photonHit(p);
      if (Math.abs(p.x) > 2.2 || Math.abs(p.y) > 2.2) p.a = 0;
    });
    anim.photons = anim.photons.filter(function (p) { return p.a > 0; });
    anim.free.forEach(function (e) {
      var ox = e.x;
      e.x += e.vx * dt; e.y += e.vy * dt;
      if (e.incoming && !e.done && ox < 0 && e.x >= 0) electronHit(e);
      if (Math.abs(e.x) > 2.4 || Math.abs(e.y) > 2.4) e.a = 0;
    });
    anim.free = anim.free.filter(function (e) { return e.a > 0; });
    // 自发跃迁：激发态停留一会儿后随机跳到某个更低能级
    anim.idle += dt;
    if (state.auto && state.n !== Infinity && state.n > 1 && !busy() && anim.idle > 1.6) {
      emit(state.n, 1 + Math.floor(Math.random() * (state.n - 1)));
    }
  }
  function resetAtom() {
    anim.photons = []; anim.free = []; anim.jump = null; anim.arrow = null;
    state.n = state.shown = 1; state.msg = ''; state.last = null;
  }

  // ---------- 谱线系：随机闪烁 ----------
  var pulses = [], pulseNext = 0;
  function stepSpectrum(dt) {
    pulses.forEach(function (p) { p.a -= dt * 1.4; });
    pulses = pulses.filter(function (p) { return p.a > 0; });
    pulseNext -= dt;
    if (pulseNext <= 0) {
      pulseNext = 0.28;
      var ls = B.linesFrom(state.nTop).filter(function (l) { return state.filter === 'all' || B.SERIES_ID[state.filter] === l.lo; });
      if (ls.length) { var l = ls[Math.floor(Math.random() * ls.length)]; pulses.push({ up: l.up, lo: l.lo, a: 1 }); }
    }
  }

  // ---------- 控件 ----------
  qa('[data-n]').forEach(function (b) {
    b.addEventListener('click', function () {
      var m = b.dataset.n === 'inf' ? Infinity : +b.dataset.n;
      if (jumpTo(m)) Analytics.track(NAME, '跃迁', '按钮 n=' + B.nName(m));
    });
  });
  qa('[data-in]').forEach(function (b) { b.addEventListener('click', function () { state.inKind = b.dataset.in; syncUI(); Analytics.track(NAME, '入射粒子', b.textContent); }); });
  qa('[data-ev]').forEach(function (b) { b.addEventListener('click', function () { state.inE = +b.dataset.ev; Analytics.track(NAME, '能量预设', b.dataset.ev); }); });
  $('fire').addEventListener('click', function () {
    if (busy()) return;
    if (state.inKind === 'photon') firePhoton(state.inE); else fireElectron(state.inE);
    Analytics.track(NAME, '射入', (state.inKind === 'photon' ? '光子 ' : '电子 ') + state.inE.toFixed(2));
  });
  $('ground').addEventListener('click', function () { resetAtom(); Analytics.track(NAME, '回到基态', ''); });
  $('auto').addEventListener('change', function () { state.auto = $('auto').checked; anim.idle = 0; Analytics.track(NAME, '开关', '自发跃迁' + (state.auto ? '开' : '关')); });
  qa('[data-top]').forEach(function (b) { b.addEventListener('click', function () { setTop(+b.dataset.top); Analytics.track(NAME, '最高能级', b.dataset.top); }); });
  qa('[data-series]').forEach(function (b) { b.addEventListener('click', function () { state.filter = b.dataset.series; state.sel = null; syncUI(); Analytics.track(NAME, '线系', b.textContent); }); });
  qa('[data-mode]').forEach(function (b) { b.addEventListener('click', function () { state.mode = b.dataset.mode; syncUI(); Analytics.track(NAME, '光谱', b.textContent); }); });
  function setTop(n) { state.nTop = B.clamp(n, 2, B.NMAX); if (state.sel && state.sel.up > state.nTop) state.sel = null; syncUI(); }
  var inE = $('inE');
  inE.addEventListener('input', function () { state.inE = parseFloat(inE.value); });
  inE.addEventListener('change', function () { Analytics.track(NAME, '滑块', 'inE'); });
  qa('.pauseBtn').forEach(function (b) { b.addEventListener('click', function () { state.paused = !state.paused; syncUI(); }); });

  // ---------- 练习 ----------
  function nextQuiz() {
    var q = B.quiz(Math.random, state.qKind, state.quiz);
    state.quiz = q; q.answered = false;
    $('qText').textContent = q.text;
    var box = $('qOpts');
    box.innerHTML = '';
    q.options.forEach(function (o) {
      var b = document.createElement('button');
      b.textContent = o;
      b.addEventListener('click', function () { answer(b, o); });
      box.appendChild(b);
    });
    $('qFeedback').textContent = '';
    $('qFeedback').className = 'note';
    $('qNext').hidden = true;
  }
  function answer(btn, o) {
    var q = state.quiz;
    if (q.answered) return;
    q.answered = true;
    var ok = o === q.answer;
    state.score.total++;
    if (ok) state.score.right++;
    qa('#qOpts button').forEach(function (b) {
      b.classList.toggle('right', b.textContent === q.answer);
      b.classList.toggle('wrong', b === btn && !ok);
      b.disabled = true;
    });
    $('qFeedback').textContent = (ok ? '✓ 答对了。' : '✗ 不对，正确答案是 ' + q.answer + '。') + q.explain;
    $('qFeedback').className = 'note ' + (ok ? 'ok' : 'bad');
    $('qScore').textContent = '答对 ' + state.score.right + ' / ' + state.score.total;
    $('qNext').hidden = false;
    Analytics.track(NAME, '练习', q.kind + (ok ? ' 对' : ' 错'));
  }
  $('qNext').addEventListener('click', nextQuiz);
  $('qKind').addEventListener('change', function () { state.qKind = $('qKind').value; nextQuiz(); Analytics.track(NAME, '题型', state.qKind || '随机'); });

  // ---------- 画布：点能级线跃迁、点谱线选中 ----------
  function levelAt(x, y) {
    var g = view.geo();
    if (!g || !g.lv) return null;
    var lv = g.lv, best = null, bd = 1e9;
    if (x < lv.x0 - 44 || x > lv.x1 + 76) return null;
    Object.keys(lv.ys).forEach(function (k) {
      var d = Math.abs(lv.ys[k] - y);
      if (d < bd) { bd = d; best = k === 'Infinity' ? Infinity : +k; }
    });
    return bd < 16 ? best : null;
  }
  function hitAt(x, y) {
    var g = view.geo();
    if (!g || !g.hits) return null;
    var h = null;
    g.hits.forEach(function (t) { if (x >= t.x0 && x <= t.x1 && y >= t.y0 && y <= t.y1) h = t; });
    return h;
  }
  function pos(e) { var r = cv.getBoundingClientRect(); return { x: e.clientX - r.left, y: e.clientY - r.top }; }
  cv.addEventListener('pointerdown', function (e) {
    if (e.button !== 0) return;
    var p = pos(e);
    if (state.scene === 'levels') {
      var m = levelAt(p.x, p.y);
      if (m != null && jumpTo(m)) Analytics.track(NAME, '跃迁', '能级图 n=' + B.nName(m));
    } else if (state.scene === 'spectrum') {
      var h = hitAt(p.x, p.y);
      if (h) { state.sel = { up: h.up, lo: h.lo }; Analytics.track(NAME, '谱线', h.up + '→' + h.lo); }
    }
  });
  cv.addEventListener('pointermove', function (e) {
    var p = pos(e), cur = 'default';
    if (state.scene === 'levels') { state.hover = levelAt(p.x, p.y); if (state.hover != null && state.hover !== state.n) cur = 'pointer'; }
    else if (state.scene === 'spectrum' && hitAt(p.x, p.y)) cur = 'pointer';
    cv.style.cursor = cur;
  });
  cv.addEventListener('pointerleave', function () { state.hover = null; });

  // ---------- 面板 ----------
  $('panelToggle').addEventListener('click', function () { panel.classList.toggle('collapsed'); });
  if (window.matchMedia('(max-width: 760px)').matches) panel.classList.add('collapsed');
  window.addEventListener('keydown', function (e) {
    var tg = e.target.tagName;
    if (tg === 'INPUT' || tg === 'SELECT' || tg === 'BUTTON' || tg === 'TEXTAREA') return;
    if (e.code === 'Space') { e.preventDefault(); state.paused = !state.paused; syncUI(); }
  });

  function syncUI() {
    var sc = state.scene;
    setSeg('scene', sc);
    qa('[data-for]').forEach(function (el) { el.hidden = el.dataset.for.split(' ').indexOf(sc) < 0; });
    $('hint').textContent = HINTS[sc];
    setSeg('in', state.inKind); setSeg('top', state.nTop); setSeg('series', state.filter); setSeg('mode', state.mode);
    $('auto').checked = state.auto;
    $('qKind').value = state.qKind;
    qa('.pauseBtn').forEach(function (b) { b.textContent = state.paused ? '▶ 继续' : '❚❚ 暂停'; });
  }

  // ---------- 读数 ----------
  var lastText = {};
  function setText(id, s) { if (lastText[id] !== s) { lastText[id] = s; $(id).textContent = s; } }
  function rows(list) {
    for (var k = 1; k <= 5; k++) {
      var r = list[k - 1] || ['', ''];
      setText('d' + k, r[0]); setText('r' + k, r[1]);
      $('d' + k).hidden = $('r' + k).hidden = !r[0];
    }
  }
  function lamText(lam) { return lam >= 1000 ? (lam / 1000).toFixed(2) + ' μm' : lam.toFixed(1) + ' nm'; }
  function lineRow(up, lo) {
    var e = B.dE(up, lo), lam = B.lamOf(e);
    return 'λ = ' + lamText(lam) + '，ν = ' + B.sci(B.nuOf(e)) + ' Hz（' + SP.colorName(lam) + '）';
  }
  function readLevels() {
    var n = state.n;
    if (n === Infinity) {
      setText('rName', '已电离'); setText('rKind', 'H⁺ + e⁻');
      setText('rTip', state.msg || '电子脱离原子核的束缚成为自由电子。点任一能级，让 H⁺ 俘获一个电子并放出光子。');
      rows([['能量', 'E∞ = 0（电子刚好脱离时）'], ['电离能', '基态 13.6 eV']].concat(lastRows()));
      return;
    }
    setText('rName', 'n = ' + n + '，E' + n + ' = ' + B.E(n).toFixed(2) + ' eV');
    setText('rKind', n === 1 ? '基态' : n === 2 ? '第一激发态' : '激发态');
    setText('rTip', state.msg || (n === 1 ? '基态最稳定。射入光子或电子，或点能级图上的能级线，让电子跃迁。' : '激发态不稳定，会自发向低能级跃迁并放出光子（勾选“自发跃迁”看它自己回落）。'));
    rows([
      ['轨道半径', 'r' + n + ' = n²r1 = ' + B.sci(B.r(n)) + ' m'],
      ['动能 / 势能', 'Ek = ' + B.ek(n).toFixed(2) + ' eV，Ep = ' + B.ep(n).toFixed(2) + ' eV'],
      ['电离能', B.ionize(n).toFixed(2) + ' eV（到 n = ∞）']
    ].concat(lastRows()));
  }
  function lastRows() {
    var L = state.last;
    if (!L) return [];
    var up = L.up, lo = L.lo, e = B.dE(up, lo);
    var head = (L.emit ? '放出' : L.byE ? '碰撞交出' : '吸收') + ' n=' + B.nName(up) + (L.emit ? '→' : '←') + lo;
    if (up === Infinity && !L.emit) return [[head, e.toFixed(2) + ' eV' + (L.rest != null ? '，电子剩 ' + L.rest.toFixed(2) + ' eV' : '')]];
    if (L.byE) return [[head, 'ΔE = ' + e.toFixed(2) + ' eV，入射电子剩 ' + L.rest.toFixed(2) + ' eV']];
    return [[head, 'ΔE = ' + e.toFixed(2) + ' eV'], ['光子', lineRow(up, lo)]];
  }
  function readSpectrum() {
    var ls = B.linesFrom(state.nTop), vis = ls.filter(function (l) { return SP.visible(l.lam); }).length;
    var s = state.sel;
    setText('rName', '一群 n = ' + state.nTop + '：' + ls.length + ' 种谱线');
    setText('rKind', state.mode === 'emit' ? '发射光谱' : '吸收光谱');
    if (s) {
      var l = B.line(s.up, s.lo);
      setText('rTip', (l.seriesName ? l.seriesName + '：' : '') + '跃迁到 n = ' + s.lo + ' 的谱线' + (l.name ? '（' + l.name + '）' : '') + '。' +
        (state.mode === 'absorb' ? '吸收时方向相反：n = ' + s.lo + ' 的原子吸收这种光子跃迁到 n = ' + s.up + '。' : ''));
      rows([
        ['跃迁', 'n = ' + s.up + ' → n = ' + s.lo],
        ['光子能量', 'hν = E' + s.up + ' − E' + s.lo + ' = ' + l.ev.toFixed(2) + ' eV'],
        ['波长 / 频率', lineRow(s.up, s.lo)],
        s.lo === 2 ? ['巴耳末公式', '1/λ = R(1/2² − 1/' + s.up + '²) → λ ≈ ' + B.balmer(s.up).toFixed(0) + ' nm（R = 1.10×10⁷ m⁻¹）'] : ['', ''],
        ['可见光', '其中 ' + vis + ' 种（都属于巴耳末系）']
      ].filter(function (r) { return r[0]; }));
    } else {
      setText('rTip', state.mode === 'emit'
        ? '每条谱线对应一种跃迁：能级是分立的，所以光谱是分立的线状谱。点箭头或谱线看详情。'
        : '白光通过温度较低的氢气，与能级差相等的光子被吸收，连续谱上出现暗线，位置与发射光谱的亮线一一对应。');
      var lam = ls.map(function (l) { return l.lam; });
      rows([
        ['谱线数', 'C(' + state.nTop + ', 2) = ' + ls.length + ' 种（一个原子最多 ' + (state.nTop - 1) + ' 种）'],
        ['最短波长', lamText(Math.min.apply(null, lam)) + '（n=' + state.nTop + '→1，能量最大）'],
        ['最长波长', lamText(Math.max.apply(null, lam)) + '（n=' + state.nTop + '→' + (state.nTop - 1) + '，能量最小）'],
        ['可见光', vis + ' 种（巴耳末系，跃迁到 n = 2）']
      ]);
    }
  }
  function readQuiz() {
    var q = state.quiz;
    setText('rName', '判断练习'); setText('rKind', '');
    setText('rTip', '');
    rows(q ? [['E1～E4', '−13.6、−3.4、−1.51、−0.85 eV'], ['E5、E6', '−0.54、−0.38 eV']] : []);
  }

  // ---------- 尺寸与主循环 ----------
  function resize() { view.resize(stage.clientWidth, stage.clientHeight); }
  new ResizeObserver(resize).observe(stage);

  // 支持 ?scene=levels|spectrum|quiz
  // 能级跃迁：&n=1~6（初始能级）、&to=1~6|inf（打开后立即跃迁）、&in=photon|electron、&E=0.5~15（入射能量 eV）、&fire=1（立即射入）、&auto=1
  // 谱线系：&n=2~6（最高能级）、&series=lyman|balmer|paschen、&mode=emit|absorb、&line=4-2（选中谱线）
  // 练习：&q=group|one|longest|shortest|absorb|collide|ion|visible|photo；&t=0~10 打开时快进的秒数
  var qs = new URLSearchParams(location.search);
  function num(k, lo, hi) { var x = parseFloat(qs.get(k)); return isFinite(x) && x >= lo && x <= hi ? x : null; }
  var x;
  if (HINTS[qs.get('scene')]) state.scene = qs.get('scene');
  if (state.scene === 'spectrum') {
    if ((x = num('n', 2, B.NMAX)) != null) state.nTop = Math.round(x);
    if (B.SERIES_ID[qs.get('series')]) state.filter = qs.get('series');
    if (qs.get('mode') === 'absorb') state.mode = 'absorb';
    var lm = /^(\d)-(\d)$/.exec(qs.get('line') || '');
    if (lm && +lm[1] > +lm[2] && +lm[1] <= state.nTop) state.sel = { up: +lm[1], lo: +lm[2] };
  } else if (state.scene === 'levels') {
    if ((x = num('n', 1, B.NMAX)) != null) { state.n = state.shown = Math.round(x); state.zoom = zoomFor(state.n); }
    if (qs.get('in') === 'electron') state.inKind = 'electron';
    if ((x = num('E', 0.5, 15)) != null) state.inE = x;
    if (qs.get('auto') === '1') state.auto = true;
  }
  if (B.KINDS.indexOf(qs.get('q')) >= 0) state.qKind = qs.get('q');

  resize();
  setScene(state.scene);
  if (state.scene === 'levels') {
    var to = qs.get('to') === 'inf' ? Infinity : num('to', 1, B.NMAX);
    if (to != null) jumpTo(to === Infinity ? to : Math.round(to));
    else if (qs.get('fire') === '1') { if (state.inKind === 'photon') firePhoton(state.inE); else fireElectron(state.inE); }
  }
  var ft0 = num('t', 0, 10);
  for (var ft = 0; ft < (ft0 == null ? 0 : ft0); ft += 0.02) { if (state.scene === 'levels') stepLevels(0.02); else stepSpectrum(0.02); }

  var lastT = performance.now();
  function frame(now) {
    var dt = Math.min((now - lastT) / 1000, 0.1), sc = state.scene;
    lastT = now;
    if (state.paused) dt = 0;
    if (document.activeElement !== inE) inE.value = state.inE;
    setText('inEOut', state.inE.toFixed(2) + ' eV');
    if (sc === 'levels') {
      stepLevels(dt);
      view.drawLevels({ n: state.n, shown: state.shown, zoom: state.zoom, ang: state.ang, jump: anim.jump, photons: anim.photons, free: anim.free, arrow: anim.arrow, hover: state.hover });
      readLevels();
    } else if (sc === 'spectrum') {
      stepSpectrum(dt);
      view.drawSpectrum({ nTop: state.nTop, filter: state.filter, mode: state.mode, sel: state.sel, pulses: pulses });
      readSpectrum();
    } else {
      view.drawQuiz({ q: state.quiz, answered: state.quiz && state.quiz.answered });
      readQuiz();
    }
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // 调试用
  window.__model = {
    state: state, anim: anim, setScene: setScene, syncUI: syncUI, jumpTo: jumpTo, emit: emit, resetAtom: resetAtom, nextQuiz: nextQuiz, setTop: setTop,
    photon: function (ev) { firePhoton(ev); }, electron: function (ev) { fireElectron(ev); },
    select: function (up, lo) { state.sel = up ? { up: up, lo: lo } : null; },
    // 按固定步长推进动画 sec 秒（截图、录屏用，配合 state.paused = true）
    step: function (sec) { for (var t = 0; t < sec; t += 0.02) { if (state.scene === 'levels') stepLevels(0.02); else stepSpectrum(0.02); } }
  };
})();
