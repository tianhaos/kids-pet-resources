(function () {
  var S = window.Scope;
  var $ = function (id) { return document.getElementById(id); };
  var qa = function (sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); };
  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }

  var INIT = {
    kind: 'letter', ch: 'p', obj: 4, eye: 10, z: 40,
    mirror: 'flat', mirrorA: 26, aperture: 's', ambient: 'bright', sx: -12, sy: 6
  };
  var state = {
    kind: INIT.kind, ch: INIT.ch, spec: null,
    obj: INIT.obj, eye: INIT.eye, turret: 0, turretTo: 0, rotating: false,
    z: INIT.z, knob: { coarse: 0, fine: 0 },
    mirror: INIT.mirror, mirrorA: INIT.mirrorA, aperture: INIT.aperture, ambient: INIT.ambient,
    sx: INIT.sx, sy: INIT.sy,
    crushed: false, cracks: null,
    dirt: null, eyeRot: 0, eyeRotTo: 0, quiz: null,
    show: { labels: true }, hl: null, drag: null,
    moveArrow: { x: 0, y: 0, alpha: 0 },
    bright: 0, lightShow: 0,
    steps: [], flags: {}, warn: null
  };
  var ORDER = [4, 10, 40];

  var STEPS = [
    ['对光', '转动转换器，使低倍物镜（4×）对准通光孔；转动遮光器选较大的光圈；转动反光镜，直到看到明亮的圆形视野。'],
    ['放置玻片标本', '把玻片标本放在载物台上，用压片夹压住，标本要正对通光孔的中心。拖动俯视图中的装片。'],
    ['下降镜筒', '转动粗准焦螺旋使镜筒缓缓下降，直到物镜接近玻片（几毫米）。这时眼睛要从侧面看着物镜，以免物镜压碎玻片。'],
    ['寻找物像', '一只眼睛向目镜内看，反方向转动粗准焦螺旋，使镜筒缓缓上升，直到看清物像。'],
    ['调清晰', '再略微转动细准焦螺旋，使物像更加清晰。'],
    ['移到视野中央', '移动装片，把物像移到视野中央。物像偏向哪一方，装片就向哪一方移动。'],
    ['换高倍物镜', '转动转换器，换成 40× 高倍物镜。'],
    ['高倍镜下观察', '高倍镜下只能用细准焦螺旋调焦；视野变暗时，换用大光圈或凹面镜。']
  ];

  var stage = $('stage'), canvas = $('scope'), panel = $('panel'), fovEl = $('fov');
  var view = window.ScopeDraw(canvas);
  var field = window.ScopeField($('field'), $('fieldOver'));

  function fov() { return S.fovMm(state); }

  // ---------- 标本 ----------
  function setSpec(kind, ch) {
    state.kind = kind; if (ch) state.ch = ch;
    state.spec = S.specimen(state.kind, state.ch);
    syncUI();
  }
  qa('[data-spec]').forEach(function (b) {
    b.addEventListener('click', function () { setSpec(b.dataset.spec); Analytics.track('显微镜', '装片', b.textContent); });
  });
  qa('[data-ch]').forEach(function (b) { b.addEventListener('click', function () { setSpec('letter', b.dataset.ch); }); });

  // ---------- 物镜（转换器）与目镜 ----------
  function setObj(m) {
    if (state.rotating || m === state.obj) return;
    if (S.gap(state.z, m) < 0.2) {
      warn('镜筒太低，换上 ' + m + '× 物镜会碰到玻片。先用粗准焦螺旋把镜筒升高一些。');
      return;
    }
    state.obj = m;
    var to = ORDER.indexOf(m), d = ((to - state.turret) % 3 + 3) % 3;
    if (d > 1.5) d -= 3;
    state.turretTo = state.turret + d;
    state.rotating = true;
    state.flags.coarseHigh = false;
    syncUI();
    Analytics.track('显微镜', '换物镜', m + '×');
  }
  qa('[data-obj]').forEach(function (b) { b.addEventListener('click', function () { setObj(+b.dataset.obj); }); });
  qa('[data-eye]').forEach(function (b) { b.addEventListener('click', function () { state.eye = +b.dataset.eye; syncUI(); }); });
  function nextObj() { setObj(ORDER[(ORDER.indexOf(state.obj) + 1) % 3]); }

  // ---------- 调焦 ----------
  var RATE = { coarse: 8, fine: 0.06 };       // 按住按钮时的速度（mm/s）
  var STEP = { coarse: 0.5, fine: 0.004 };    // 点一下的步长（mm）
  function moveZ(which, dz) {
    if (state.rotating || dz === 0) return;
    if (which === 'coarse' && state.obj === 40) {
      if (!state.flags.coarseHigh) Analytics.track('显微镜', '高倍镜用粗准焦');
      state.flags.coarseHigh = true;
      warn('高倍物镜下不能用粗准焦螺旋：镜筒一下子升降太多，物像找不到，还容易压碎玻片。请用细准焦螺旋。');
    }
    var minZ = S.OBJ[state.obj].ext, z = state.z + dz;
    if (state.crushed && z < minZ) z = minZ;
    if (z < minZ) { z = minZ; crush(); }
    z = Math.min(z, S.Z_MAX);
    state.knob[which] += (z - state.z) * (which === 'coarse' ? 24 : 1800);
    state.z = z;
    if (which === 'fine' && state.steps[3]) state.flags.fineUsed = true;
  }
  function crush() {
    if (state.crushed) return;
    state.crushed = true;
    var R = S.rng(Date.now() & 0xffff), cx = -state.sx, cy = -state.sy, lines = [];
    for (var i = 0; i < 7; i++) {
      var a = i / 7 * Math.PI * 2 + R() * 0.6, x = cx, y = cy, l = [x, y], len = 1.2 + R() * 2.4;
      for (var j = 0; j < 9; j++) {
        a += (R() - 0.5) * 0.7;
        x += Math.cos(a) * len / 9; y += Math.sin(a) * len / 9;
        l.push(x, y);
      }
      lines.push(l);
    }
    state.cracks = lines;
    Analytics.track('显微镜', '压碎玻片', state.obj + '×');
  }
  $('newSlide').addEventListener('click', function () {
    state.crushed = false; state.cracks = null;
    state.z = Math.min(S.Z_MAX, state.z + 8);
    syncUI();
  });

  // ---------- 对光 ----------
  qa('[data-mirror]').forEach(function (b) { b.addEventListener('click', function () { state.mirror = b.dataset.mirror; syncUI(); }); });
  qa('[data-ap]').forEach(function (b) { b.addEventListener('click', function () { state.aperture = b.dataset.ap; syncUI(); }); });
  qa('[data-amb]').forEach(function (b) { b.addEventListener('click', function () { state.ambient = b.dataset.amb; syncUI(); }); });
  var mirEl = $('mirrorA');
  mirEl.addEventListener('input', function () { state.mirrorA = parseFloat(mirEl.value); syncMirror(); });
  function syncMirror() {
    mirEl.value = state.mirrorA;
    var a = Math.abs(state.mirrorA);
    $('mirrorOut').textContent = a < 3 ? '对准' : '偏 ' + a.toFixed(0) + '°';
  }
  function cycleAperture() { state.aperture = { s: 'm', m: 'l', l: 's' }[state.aperture]; syncUI(); }

  // ---------- 移动装片 ----------
  var arrowAcc = { x: 0, y: 0 };
  function moveSlide(dx, dy) {
    var nx = clamp(state.sx + dx, -30, 30), ny = clamp(state.sy + dy, -14, 14);
    dx = nx - state.sx; dy = ny - state.sy;
    if (!dx && !dy) return;
    state.sx = nx; state.sy = ny;
    // 箭头方向：最近一段移动的平滑方向
    arrowAcc.x = arrowAcc.x * 0.7 + dx; arrowAcc.y = arrowAcc.y * 0.7 + dy;
    var l = Math.hypot(arrowAcc.x, arrowAcc.y);
    if (l > 1e-9) { state.moveArrow.x = arrowAcc.x / l; state.moveArrow.y = arrowAcc.y / l; state.moveArrow.alpha = 1; }
    if (state.quiz) state.quiz.moved += Math.hypot(dx, dy);
  }

  // ---------- 按住重复的按钮 ----------
  var hold = null;
  qa('[data-hold]').forEach(function (b) {
    b.addEventListener('pointerdown', function (e) {
      e.preventDefault();
      var p = b.dataset.hold.split(':');
      hold = { kind: p[0], a: +p[1], b: +(p[2] || 0), t: 0 };
      tapHold(hold);
      try { b.setPointerCapture(e.pointerId); } catch (err) { /* 合成事件无法捕获指针 */ }
    });
    ['pointerup', 'pointercancel', 'lostpointercapture'].forEach(function (ev) { b.addEventListener(ev, function () { hold = null; }); });
  });
  function tapHold(h) {
    if (h.kind === 'slide') moveSlide(h.a * fov() * 0.04, h.b * fov() * 0.04);
    else moveZ(h.kind, h.a * STEP[h.kind]);
  }
  function runHold(dt) {
    if (!hold) return;
    hold.t += dt;
    if (hold.t < 0.3) return;      // 按住 0.3 s 后连续移动
    if (hold.kind === 'slide') moveSlide(hold.a * fov() * 0.5 * dt, hold.b * fov() * 0.5 * dt);
    else moveZ(hold.kind, hold.a * RATE[hold.kind] * dt);
  }

  // ---------- 画布交互：旋钮、反光镜、装片、结构名称 ----------
  var drag = null;
  function localXY(e, el) { var r = el.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; }
  canvas.addEventListener('pointerdown', function (e) {
    var p = localXY(e, canvas), h = view.hit(p[0], p[1], state);
    if (!h) return;
    drag = { h: h, x: p[0], y: p[1], moved: 0 };
    if (h.type === 'knob' || h.type === 'mirror' || h.type === 'slide') {
      state.drag = h.type === 'knob' ? h.id : h.type;
      try { canvas.setPointerCapture(e.pointerId); } catch (err) { /* 合成事件无法捕获指针 */ }
      canvas.classList.add('grabbing');
    }
  });
  canvas.addEventListener('pointermove', function (e) {
    var p = localXY(e, canvas);
    if (!drag) {
      var h = view.hit(p[0], p[1], state);
      canvas.classList.toggle('grab', !!h && (h.type === 'knob' || h.type === 'mirror' || h.type === 'slide'));
      canvas.classList.toggle('point', !!h && !(h.type === 'knob' || h.type === 'mirror' || h.type === 'slide'));
      return;
    }
    var dx = p[0] - drag.x, dy = p[1] - drag.y;
    drag.x = p[0]; drag.y = p[1]; drag.moved += Math.abs(dx) + Math.abs(dy);
    var h2 = drag.h;
    if (h2.type === 'knob') moveZ(h2.id, -dy * (h2.id === 'coarse' ? 0.1 : 0.002));
    else if (h2.type === 'mirror') { state.mirrorA = clamp(state.mirrorA + dy * 0.35, -40, 40); syncMirror(); }
    else if (h2.type === 'slide') { var sc = view.tvScale(); moveSlide(dx / sc, -dy / sc); }
  });
  function endDrag(e) {
    if (!drag) return;
    var h = drag.h, click = drag.moved < 4;
    drag = null; state.drag = null;
    canvas.classList.remove('grabbing');
    if (canvas.hasPointerCapture(e.pointerId)) canvas.releasePointerCapture(e.pointerId);
    if (!click || e.type === 'pointercancel') return;
    // 点击：显示结构说明，部分结构顺便执行操作
    var id = h.type === 'knob' ? h.id : h.type === 'part' ? h.id : h.type === 'slide' ? null : h.type;
    if (h.type === 'eyepiece') { state.eye = { 5: 10, 10: 16, 16: 5 }[state.eye]; syncUI(); }
    else if (h.type === 'nosepiece') { nextObj(); id = 'nosepiece'; }
    else if (h.type === 'diaphragm') cycleAperture();
    else if (h.type === 'mirror') { state.mirror = state.mirror === 'flat' ? 'concave' : 'flat'; syncUI(); }
    if (id) showPart(id);
  }
  canvas.addEventListener('pointerup', endDrag);
  canvas.addEventListener('pointercancel', endDrag);
  canvas.addEventListener('wheel', function (e) {
    var p = localXY(e, canvas), h = view.hit(p[0], p[1], state);
    if (!h || h.type !== 'knob') return;
    e.preventDefault();
    var d = Math.max(-120, Math.min(120, e.deltaY));
    moveZ(h.id, -d * (h.id === 'coarse' ? 0.005 : 0.00004));
  }, { passive: false });

  // 在视野上拖动 = 用手推动装片（物像向相反方向移动）
  var fdrag = null;
  fovEl.addEventListener('pointerdown', function (e) {
    fdrag = localXY(e, fovEl);
    try { fovEl.setPointerCapture(e.pointerId); } catch (err) { /* 合成事件无法捕获指针 */ }
    fovEl.classList.add('grabbing');
  });
  fovEl.addEventListener('pointermove', function (e) {
    if (!fdrag) return;
    var p = localXY(e, fovEl), k = field.size() / fov();
    moveSlide((p[0] - fdrag[0]) / k, -(p[1] - fdrag[1]) / k);
    fdrag = p;
  });
  function endF(e) {
    if (!fdrag) return;
    fdrag = null; fovEl.classList.remove('grabbing');
    if (fovEl.hasPointerCapture(e.pointerId)) fovEl.releasePointerCapture(e.pointerId);
  }
  fovEl.addEventListener('pointerup', endF);
  fovEl.addEventListener('pointercancel', endF);

  // 键盘方向键移动装片
  window.addEventListener('keydown', function (e) {
    var t = e.target && e.target.tagName;
    if (t === 'INPUT' || t === 'SELECT' || t === 'TEXTAREA') return;
    var m = { ArrowLeft: [-1, 0], ArrowRight: [1, 0], ArrowUp: [0, 1], ArrowDown: [0, -1] }[e.key];
    if (!m) return;
    e.preventDefault();
    moveSlide(m[0] * fov() * 0.03, m[1] * fov() * 0.03);
  });

  // ---------- 结构说明 ----------
  function showPart(id) {
    state.hl = id;
    var p = S.PARTS[id];
    $('partName').textContent = p[0];
    $('partInfo').textContent = p[1];
  }

  // ---------- 找污点 ----------
  $('quizNew').addEventListener('click', function () {
    var R = Math.random, where = ['eye', 'obj', 'slide'][Math.floor(R() * 3)], pts = [];
    for (var i = 0; i < 9; i++) pts.push(0.6 + R() * 0.6);
    var a = R() * Math.PI * 2, r = 0.2 + R() * 0.35, fx = Math.cos(a) * r, fy = Math.sin(a) * r, F = fov();
    state.dirt = { where: where, pts: pts, fx: fx, fy: fy, fr: 0.035, obj: state.obj, eye: state.eye,
      x: -state.sx - fx * F / 2, y: fy * F / 2 - state.sy, r: 0.035 * F };
    state.quiz = { where: where, moved: 0, rot: 0, obj0: state.obj, eye0: state.eye, done: false };
    $('quizNote').textContent = '视野中出现了一个污点。它在目镜、物镜还是装片上？先移动装片、转动目镜或换物镜试一试，再作答。';
    $('quizNote').className = 'note';
    syncUI();
    Analytics.track('显微镜', '找污点');
  });
  $('rotEye').addEventListener('click', function () {
    state.eyeRotTo += 90;
    if (state.quiz) state.quiz.rot++;
  });
  qa('[data-ans]').forEach(function (b) {
    b.addEventListener('click', function () {
      var q = state.quiz;
      if (!q) return;
      var ok = b.dataset.ans === q.where;
      var EXPL = {
        eye: '污点在目镜上：转动目镜，污点跟着转动；移动装片、换物镜，污点都不动。',
        obj: '污点在物镜上：换用另一个物镜，污点就消失了；转动目镜、移动装片，污点都不动。',
        slide: '污点在装片上：移动装片，污点跟着移动（在视野中的移动方向与装片相反）。'
      };
      var tried = (q.moved > 0.3 * fov() ? 1 : 0) + (q.rot ? 1 : 0) + (state.obj !== q.obj0 || state.eye !== q.eye0 ? 1 : 0);
      var note = (ok ? '✓ 答对了！' : '✗ 不对。') + (ok || tried >= 2 ? EXPL[q.where] : '先做实验：移动装片、转动目镜、换物镜，看污点会不会跟着动。');
      $('quizNote').textContent = note;
      $('quizNote').className = 'note ' + (ok ? 'ok' : 'bad');
      if (ok) q.done = true;
    });
  });
  $('quizClear').addEventListener('click', function () {
    state.dirt = null; state.quiz = null; $('quizNote').textContent = ''; syncUI();
  });

  // ---------- 重新开始 ----------
  function reset() {
    state.obj = INIT.obj; state.turret = state.turretTo = 0; state.rotating = false;
    state.eye = INIT.eye; state.z = INIT.z;
    state.mirror = INIT.mirror; state.mirrorA = INIT.mirrorA; state.aperture = INIT.aperture; state.ambient = INIT.ambient;
    state.sx = INIT.sx; state.sy = INIT.sy;
    state.crushed = false; state.cracks = null;
    state.steps = STEPS.map(function () { return false; });
    state.flags = {};
    state.warn = null;
    syncUI();
  }
  $('reset').addEventListener('click', function () { reset(); Analytics.track('显微镜', '重新开始'); });

  function warn(msg) { state.warn = { msg: msg, t: 4.5 }; }

  // ---------- 显示 ----------
  $('showLabels').addEventListener('change', function () { state.show.labels = $('showLabels').checked; });

  function setSeg(attr, val) { qa('[data-' + attr + ']').forEach(function (b) { b.classList.toggle('on', b.dataset[attr] === String(val)); }); }
  function syncUI() {
    setSeg('spec', state.kind); setSeg('ch', state.ch);
    $('chRow').hidden = state.kind !== 'letter';
    setSeg('obj', state.obj); setSeg('eye', state.eye);
    setSeg('mirror', state.mirror); setSeg('ap', state.aperture); setSeg('amb', state.ambient);
    syncMirror();
    $('newSlide').hidden = !state.crushed;
    $('quizOps').hidden = !state.quiz;
  }

  $('panelToggle').addEventListener('click', function () { panel.classList.toggle('collapsed'); });
  if (window.matchMedia('(max-width: 760px)').matches) panel.classList.add('collapsed');

  // ---------- 操作步骤 ----------
  var stepList = $('steps');
  STEPS.forEach(function (st, i) {
    var li = document.createElement('li');
    li.innerHTML = '<b>' + st[0] + '</b><span>' + st[1] + '</span>';
    stepList.appendChild(li);
  });
  function checkSteps(sol) {
    var s = state, f = s.flags, st = s.steps, ok = !s.rotating && !s.crushed;
    var lowGap = S.gap(s.z, 4);
    if (!st[0]) st[0] = ok && s.obj === 4 && sol.b >= 0.55;
    else if (!st[1]) st[1] = Math.hypot(s.sx, s.sy) < 2.5;
    else if (!st[2]) st[2] = ok && s.obj === 4 && lowGap < 4.5;
    else if (!st[3]) st[3] = ok && Math.abs(sol.d) < 6 && s.z > S.focusZ(4) - 1;
    else if (!st[4]) st[4] = ok && f.fineUsed && Math.abs(sol.d) < 0.4;
    else if (!st[5]) st[5] = ok && s.obj !== 40 && Math.hypot(s.sx, s.sy) < fov() * 0.12 && Math.abs(sol.d) < 1;
    else if (!st[6]) st[6] = ok && s.obj === 40;
    else if (!st[7]) {
      st[7] = ok && s.obj === 40 && Math.abs(sol.d) < 0.4 && sol.b >= 0.55;
      if (st[7]) Analytics.track('显微镜', '完成全部步骤');
    }
    var cur = st.indexOf(false);
    var lis = stepList.children;
    for (var i = 0; i < lis.length; i++) {
      var cls = st[i] ? 'done' : i === cur ? 'cur' : '';
      if (lis[i].className !== cls) lis[i].className = cls;
    }
    setText('stepsDone', cur < 0 ? '全部完成 🎉' : cur + ' / ' + STEPS.length);
    return cur;
  }

  // ---------- 读数 ----------
  var last = {};
  function setText(id, s) { if (last[id] !== s) { last[id] = s; $(id).textContent = s; } }

  var SEEN = { p: 'd', b: 'q', F: '倒转的 F', '上': '倒转的"上"' };
  function tip(sol, cur) {
    var s = state;
    if (s.crushed) return '物镜压碎了玻片！高倍物镜离玻片很近，只能用细准焦螺旋慢慢调；用粗准焦螺旋下降镜筒时，眼睛要从侧面看着物镜。点「换一块装片」。';
    if (s.warn) return s.warn.msg;
    if (s.rotating) return '正在转动转换器，换物镜……';
    if (sol.light.key === 'dark') return '视野很暗。对光：转动反光镜（拖动它或用面板滑块），光线弱时换大光圈、凹面镜。';
    var onSpec = s.spec.inside(-s.sx, -s.sy);
    if (sol.clar.key === 'none') {
      if (S.gap(s.z, s.obj) < S.OBJ[s.obj].wd) return '镜筒已经低于清晰位置。看着目镜，' + (s.obj === 40 ? '用细准焦螺旋' : '反方向转动粗准焦螺旋') + '使镜筒缓缓上升。';
      return s.obj === 40 ? '高倍镜下看不到物像：先换回低倍镜找到物像，移到视野中央，再换高倍镜。'
        : '看不到物像：先从侧面看着物镜，用粗准焦螺旋把镜筒降到接近玻片，再看着目镜让镜筒缓缓上升。';
    }
    if (!onSpec && sol.clar.key !== 'blur') return '视野里没有标本：移动装片，使标本正对通光孔。';
    if (sol.clar.key === 'blur') return '看到模糊的物像了，继续' + (s.obj === 40 ? '转动细准焦螺旋' : '缓缓转动粗准焦螺旋') + '。';
    if (sol.clar.key === 'soft') return '物像有点模糊，转动细准焦螺旋把它调清楚。';
    if (sol.light.key === 'glare') return '视野过亮：光线强时用小光圈、平面镜。颜色很浅的标本，光线暗一些反而看得更清楚。';
    if (cur === 5) return '把物像移到视野中央：物像偏向哪一方，就把装片往哪一方移。换高倍镜后视野变窄，不在中央的物像会跑出视野。';
    var sp = s.spec, more = s.obj === 40 ? '高倍镜下：物像更大，看到的细胞数目更少，视野更暗、范围更小。' : '';
    if (sp.kind === 'letter') return '装片上的"' + sp.ch + '"在视野中变成了' + (SEEN[sp.ch].length > 1 ? SEEN[sp.ch] : '"' + SEEN[sp.ch] + '"')
      + '：显微镜成的是倒像，上下、左右都颠倒（相当于旋转 180°）。' + more;
    if (sp.kind === 'onion') return '洋葱鳞片叶内表皮细胞近似长方形，排列紧密，有细胞壁；碘液把细胞核染成棕色。黑边圆圈是气泡。' + more;
    return '口腔上皮细胞形状不规则，没有细胞壁，细胞核位于中央附近，被染成蓝色。' + more;
  }

  function updateReadouts(sol, cur) {
    var s = state, big = $('rState'), str, cls;
    if (s.crushed) { str = '✗ 玻片被压碎'; cls = 'bad'; }
    else if (s.rotating) { str = '换物镜中…'; cls = ''; }
    else if (sol.light.key === 'dark') { str = '视野黑暗'; cls = 'bad'; }
    else if (sol.clar.key === 'none') { str = '看不到物像'; cls = 'bad'; }
    else if (sol.clar.key !== 'sharp') { str = '物像模糊'; cls = 'bad'; }
    else { str = '✓ 物像清晰'; cls = 'ok'; }
    setText('rState', str); big.className = cls;
    setText('rTip', tip(sol, cur));
    setText('rMag', s.eye + '× × ' + s.obj + '× = ' + S.total(s) + ' 倍');
    var F = fov();
    setText('rFov', '约 ' + (F >= 1 ? F.toFixed(1) + ' mm' : Math.round(F * 1000) + ' μm'));
    var gp = S.gap(s.z, s.obj);
    setText('rGap', s.rotating ? '—' : (gp < 1 ? gp.toFixed(2) : gp.toFixed(1)) + ' mm（清晰时约 ' + S.OBJ[s.obj].wd + ' mm）');
    setText('rLight', sol.light.name);
    setText('rClar', s.rotating ? '—' : sol.clar.name);
  }

  // ---------- 尺寸 ----------
  function resize() {
    var L = view.resize(stage.clientWidth, stage.clientHeight);
    fovEl.style.left = L.fov.x + 'px'; fovEl.style.top = L.fov.y + 'px';
    fovEl.style.width = fovEl.style.height = L.fov.d + 'px';
    field.resize(L.fov.d);
    fieldKey = '';
  }
  new ResizeObserver(resize).observe(stage);
  if (window.matchMedia('(max-width: 640px)').matches) $('hint').textContent = '拖旋钮调焦 · 拖装片看物像移动';

  // ---------- 主循环 ----------
  var fieldKey = '';
  reset();
  setSpec(state.kind, state.ch);
  resize();

  var lastT = performance.now();
  function frame(t) {
    var dt = Math.min((t - lastT) / 1000, 0.1);
    lastT = t;
    var s = state;
    runHold(dt);
    if (s.rotating) {
      var d = s.turretTo - s.turret, stepT = 2.4 * dt;
      if (Math.abs(d) <= stepT) { s.turret = ((s.turretTo % 3) + 3) % 3; s.turretTo = s.turret; s.rotating = false; }
      else s.turret += Math.sign(d) * stepT;
    }
    if (s.eyeRot !== s.eyeRotTo) {
      var de = s.eyeRotTo - s.eyeRot;
      s.eyeRot = Math.abs(de) < 1 ? s.eyeRotTo : s.eyeRot + de * (1 - Math.exp(-dt / 0.12));
    }
    if (s.warn && (s.warn.t -= dt) <= 0) s.warn = null;
    s.moveArrow.alpha = Math.max(0, s.moveArrow.alpha - dt / 1.2);

    var sol = { b: S.brightness(s), d: S.defocus(s.z, s.obj) };
    sol.light = S.lightLevel(sol.b);
    sol.clar = S.clarity(sol.d);
    s.bright = s.rotating ? 0 : sol.b;

    // 视野：亮度 / 模糊 / 过亮时对比度下降
    var b = s.rotating ? 0.03 : sol.b, disp = b <= 1.35 ? b : 1.35 + (b - 1.35) * 0.3;
    var contrast = b <= 1.35 ? 1 : Math.max(0.35, 1 - (b - 1.35) * 0.6);
    var blur = Math.min(field.size() * 0.11, Math.max(0, Math.abs(sol.d) - 0.25) * 1.6);
    s.lightShow = disp;
    field.setFilter(blur, disp, contrast);
    var key = [s.kind, s.ch, s.obj, s.eye, s.sx.toFixed(5), s.sy.toFixed(5), s.crushed, s.dirt ? s.dirt.where + s.dirt.x : '', field.size()].join('|');
    if (key !== fieldKey) { fieldKey = key; field.draw(s); }
    field.drawOver(s, s.moveArrow);

    var cur = checkSteps(sol);
    view.draw(s);
    updateReadouts(sol, cur);
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // 调试用
  window.__model = { state: state, view: view, setObj: setObj, moveZ: moveZ, moveSlide: moveSlide, reset: reset, setSpec: setSpec };
})();
