// 目镜中看到的视野：圆形视野内的物像（旋转 180°，即上下、左右都颠倒）
// 画布比圆形视野大一圈（四周各多出 15%），模糊滤镜不会在视野边缘留下暗边；亮度、模糊用 CSS filter 实现。
// 装片坐标（mm）：x 向右，y 指向远离观察者一侧（俯视载物台时的"上"）；装片移动量 (sx, sy)。
(function () {
  var S = window.Scope;
  var PAD = 0.15;
  var BG = '#f3efe4';

  function ScopeField(canvas, over) {
    var ctx = canvas.getContext('2d'), octx = over.getContext('2d');
    var D = 300, C = 0, SZ = 0, dpr = 1;
    var tex = {};

    function resize(d) {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      D = d; SZ = d * (1 + 2 * PAD); C = SZ / 2;
      canvas.width = Math.round(SZ * dpr); canvas.height = Math.round(SZ * dpr);
      canvas.style.width = SZ + 'px'; canvas.style.height = SZ + 'px';
      canvas.style.left = canvas.style.top = (-PAD * d) + 'px';
      over.width = Math.round(d * dpr); over.height = Math.round(d * dpr);
      over.style.width = over.style.height = d + 'px';
    }

    // ---------- 字母装片的纹理：纸张纤维 + 油墨 ----------
    var RES = 260;   // 纹理像素 / mm
    function letterTex(spec) {
      if (tex[spec.ch]) return tex[spec.ch];
      var N = Math.round(spec.paper * RES), cv = document.createElement('canvas');
      cv.width = cv.height = N;
      var c = cv.getContext('2d'), R = S.rng(spec.ch.charCodeAt(0) * 31 + 5);
      c.fillStyle = '#ebe4d2'; c.fillRect(0, 0, N, N);
      c.lineCap = 'round';
      for (var i = 0; i < 900; i++) {
        var x = R() * N, y = R() * N, a = R() * Math.PI * 2, l = (0.25 + R() * 0.9) * RES;
        c.strokeStyle = 'rgba(' + (120 + R() * 60 | 0) + ',' + (105 + R() * 50 | 0) + ',' + (80 + R() * 40 | 0) + ',' + (0.12 + R() * 0.2) + ')';
        c.lineWidth = (0.006 + R() * 0.016) * RES;
        c.beginPath(); c.moveTo(x, y);
        c.quadraticCurveTo(x + Math.cos(a + 0.6) * l * 0.5, y + Math.sin(a + 0.6) * l * 0.5, x + Math.cos(a) * l, y + Math.sin(a) * l);
        c.stroke();
      }
      c.fillStyle = '#16130f'; c.textAlign = 'center'; c.textBaseline = 'alphabetic';
      var cjk = /[一-龥]/.test(spec.ch);
      c.font = (cjk ? '700 ' : '700 ') + spec.h * RES * (cjk ? 0.95 : 1.25) + 'px ' + (cjk ? '"PingFang SC","Microsoft YaHei",sans-serif' : 'Georgia,"Times New Roman",serif');
      // 让字形的上下范围大致居中
      var m = c.measureText(spec.ch), asc = m.actualBoundingBoxAscent || spec.h * RES, desc = m.actualBoundingBoxDescent || 0;
      c.fillText(spec.ch, N / 2, N / 2 + (asc - desc) / 2);
      // 油墨不均匀：在字上撒一些浅色斑点
      c.globalCompositeOperation = 'source-atop';
      for (i = 0; i < 2600; i++) {
        c.fillStyle = 'rgba(90,80,64,' + (R() * 0.35) + ')';
        c.beginPath(); c.arc(R() * N, R() * N, (0.004 + R() * 0.012) * RES, 0, 7); c.fill();
      }
      c.globalCompositeOperation = 'source-over';
      tex[spec.ch] = cv;
      return cv;
    }

    function blob(c, x, y, r, pts) {
      c.beginPath();
      for (var i = 0; i < pts.length; i++) {
        var a = i / pts.length * Math.PI * 2, rr = r * pts[i];
        if (i) c.lineTo(x + Math.cos(a) * rr, y + Math.sin(a) * rr); else c.moveTo(x + rr, y);
      }
      c.closePath();
    }

    function bubble(c, b, px) {
      var g = c.createRadialGradient(b[0], b[1], 0, b[0], b[1], b[2]);
      g.addColorStop(0, 'rgba(255,255,255,0.55)');
      g.addColorStop(0.62, 'rgba(240,240,236,0.25)');
      g.addColorStop(0.8, 'rgba(60,60,60,0.55)');
      g.addColorStop(0.92, 'rgba(20,20,20,0.95)');
      g.addColorStop(1, 'rgba(40,40,40,0.6)');
      c.fillStyle = g;
      c.beginPath(); c.arc(b[0], b[1], b[2], 0, 7); c.fill();
      c.lineWidth = 1 / px;
      c.strokeStyle = 'rgba(0,0,0,0.6)'; c.stroke();
    }

    // ---------- 物像 ----------
    function draw(s) {
      var spec = s.spec, k = D / S.fovMm(s);          // k：像素 / mm
      var ox = C - s.sx * k, oy = C + s.sy * k;       // 装片原点在画布上的位置
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.fillStyle = BG; ctx.fillRect(0, 0, SZ, SZ);
      // 可见范围（装片坐标）
      var xa = (C - SZ) / k - s.sx, xb = C / k - s.sx, ya = -C / k - s.sy, yb = (SZ - C) / k - s.sy;
      ctx.setTransform(-k * dpr, 0, 0, k * dpr, ox * dpr, oy * dpr);    // 之后按 mm 绘制，自动旋转 180°

      if (spec.kind === 'letter') {
        var T = letterTex(spec), N = T.width;
        ctx.save();
        ctx.translate(-N / (2 * RES), N / (2 * RES));
        ctx.scale(1 / RES, -1 / RES);
        ctx.imageSmoothingEnabled = true;
        ctx.drawImage(T, 0, 0);
        ctx.restore();
      } else if (spec.kind === 'onion') {
        drawOnion(spec, k, xa, xb, ya, yb);
      } else {
        drawCheek(spec, k, xa, xb, ya, yb);
      }
      if (spec.bubbles) spec.bubbles.forEach(function (b) {
        if (b[0] + b[2] > xa && b[0] - b[2] < xb && b[1] + b[2] > ya && b[1] - b[2] < yb) bubble(ctx, b, k);
      });

      // 装片上的污点
      var dt = s.dirt;
      if (dt && dt.where === 'slide') {
        ctx.fillStyle = 'rgba(30,26,22,0.88)';
        blob(ctx, dt.x, dt.y, dt.r, dt.pts); ctx.fill();
      }
      // 压碎的玻片：裂纹
      if (s.cracks) {
        ctx.strokeStyle = 'rgba(30,34,40,0.85)'; ctx.lineWidth = 1.6 / k; ctx.lineJoin = 'round';
        s.cracks.forEach(function (l) {
          ctx.beginPath(); ctx.moveTo(l[0], l[1]);
          for (var i = 2; i < l.length; i += 2) ctx.lineTo(l[i], l[i + 1]);
          ctx.stroke();
        });
      }

      // 物镜上的污点：固定在视野中，换了物镜就消失
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      if (dt && dt.where === 'obj' && s.obj === dt.obj) {
        ctx.fillStyle = 'rgba(30,26,22,0.8)';
        blob(ctx, C + dt.fx * D / 2, C + dt.fy * D / 2, dt.fr * D, dt.pts); ctx.fill();
      }
    }

    function drawOnion(spec, k, xa, xb, ya, yb) {
      var px = 1 / k, wall = Math.max(0.8 * px, 0.0035), detail = k > 260, fine = k > 700;
      var cells = spec.cells;
      ctx.lineJoin = 'round';
      for (var i = 0; i < cells.length; i++) {
        var c = cells[i];
        if (c.x1 < xa || c.x0 > xb || c.y1 < ya || c.y0 > yb) continue;
        var q = c.q;
        ctx.beginPath();
        ctx.moveTo(q[0], q[1]); ctx.lineTo(q[2], q[3]); ctx.lineTo(q[4], q[5]); ctx.lineTo(q[6], q[7]); ctx.closePath();
        ctx.fillStyle = 'rgba(' + (232 - c.tone * 18 | 0) + ',' + (196 - c.tone * 22 | 0) + ',' + (120 - c.tone * 20 | 0) + ',0.42)';
        ctx.fill();
        if (detail) {   // 细胞质贴着细胞壁（中间是大液泡），显得壁内侧颜色略深
          ctx.lineWidth = 0.009; ctx.strokeStyle = 'rgba(170,120,50,0.22)'; ctx.stroke();
        }
        ctx.lineWidth = wall; ctx.strokeStyle = 'rgba(110,70,30,0.85)'; ctx.stroke();
        if (k * c.nr > 0.6) {
          ctx.beginPath(); ctx.ellipse(c.nx, c.ny, c.nr * 1.25, c.nr, 0, 0, 7);
          ctx.fillStyle = 'rgba(120,70,28,0.85)'; ctx.fill();
          if (fine) {
            ctx.lineWidth = px; ctx.strokeStyle = 'rgba(80,45,15,0.9)'; ctx.stroke();
            ctx.beginPath(); ctx.arc(c.nx + c.nr * 0.25, c.ny - c.nr * 0.2, c.nr * 0.28, 0, 7);
            ctx.fillStyle = 'rgba(70,38,12,0.9)'; ctx.fill();
          }
        }
      }
    }

    function drawCheek(spec, k, xa, xb, ya, yb) {
      var px = 1 / k, cells = spec.cells, fine = k > 700;
      ctx.lineJoin = 'round';
      for (var i = 0; i < cells.length; i++) {
        var c = cells[i];
        if (c.x + c.r < xa || c.x - c.r > xb || c.y + c.r < ya || c.y - c.r > yb) continue;
        var p = c.p;
        ctx.beginPath(); ctx.moveTo(p[0], p[1]);
        for (var j = 2; j < p.length; j += 2) ctx.lineTo(p[j], p[j + 1]);
        ctx.closePath();
        ctx.fillStyle = 'rgba(' + (120 + c.tone * 30 | 0) + ',' + (138 + c.tone * 20 | 0) + ',225,' + (0.2 + c.tone * 0.1) + ')';
        ctx.fill();
        ctx.lineWidth = Math.max(0.7 * px, 0.0012); ctx.strokeStyle = 'rgba(70,84,170,0.55)'; ctx.stroke();
        if (k * c.nr > 0.5) {
          ctx.beginPath(); ctx.ellipse(c.nx, c.ny, c.nr * 1.15, c.nr, c.tone * 3, 0, 7);
          ctx.fillStyle = 'rgba(52,56,150,0.85)'; ctx.fill();
          if (fine) { ctx.lineWidth = px; ctx.strokeStyle = 'rgba(30,32,100,0.9)'; ctx.stroke(); }
        }
      }
    }

    // ---------- 叠加层（不受调焦模糊影响）：目镜上的污点、物像移动方向 ----------
    function drawOver(s, arrow) {
      octx.setTransform(dpr, 0, 0, dpr, 0, 0);
      octx.clearRect(0, 0, D, D);
      var dt = s.dirt, R = D / 2;
      if (dt && dt.where === 'eye' && s.eye === dt.eye) {
        var a = s.eyeRot * Math.PI / 180, fx = dt.fx * Math.cos(a) - dt.fy * Math.sin(a), fy = dt.fx * Math.sin(a) + dt.fy * Math.cos(a);
        octx.fillStyle = 'rgba(25,22,20,' + (0.85 * Math.min(1, s.lightShow * 1.4)) + ')';
        blob(octx, R + fx * R, R + fy * R, dt.fr * D, dt.pts); octx.fill();
      }
      if (arrow && arrow.alpha > 0.02) {
        // 物像移动方向与装片移动方向相反
        var len = Math.hypot(arrow.x, arrow.y);
        if (len > 1e-6) {
          var ux = -arrow.x / len, uy = arrow.y / len, L = R * 0.42;
          octx.save();
          octx.globalAlpha = arrow.alpha;
          octx.translate(R, R);
          octx.strokeStyle = '#c9a7ff'; octx.fillStyle = '#c9a7ff'; octx.lineWidth = 4; octx.lineCap = 'round';
          octx.beginPath(); octx.moveTo(-ux * L * 0.4, -uy * L * 0.4); octx.lineTo(ux * L, uy * L); octx.stroke();
          var ang = Math.atan2(uy, ux);
          octx.translate(ux * L, uy * L); octx.rotate(ang);
          octx.beginPath(); octx.moveTo(10, 0); octx.lineTo(-8, -9); octx.lineTo(-8, 9); octx.closePath(); octx.fill();
          octx.restore();
          octx.globalAlpha = arrow.alpha;
          octx.font = '600 13px -apple-system, "PingFang SC", "Microsoft YaHei", sans-serif';
          octx.textAlign = 'center'; octx.textBaseline = 'middle';
          var tx = R + ux * L * 0.35 - uy * 16, ty = R + uy * L * 0.35 + ux * 16;
          octx.lineWidth = 3; octx.strokeStyle = 'rgba(5,7,13,0.75)';
          octx.strokeText('物像移动', tx, ty);
          octx.fillStyle = '#c9a7ff'; octx.fillText('物像移动', tx, ty);
          octx.globalAlpha = 1;
        }
      }
    }

    function setFilter(blurPx, bright, contrast) {
      var f = (blurPx > 0.15 ? 'blur(' + blurPx.toFixed(2) + 'px) ' : '') + 'brightness(' + bright.toFixed(3) + ')'
        + (contrast < 0.99 ? ' contrast(' + contrast.toFixed(3) + ')' : '');
      if (canvas.style.filter !== f) canvas.style.filter = f;
    }

    return { resize: resize, draw: draw, drawOver: drawOver, setFilter: setFilter, size: function () { return D; } };
  }

  window.ScopeField = ScopeField;
})();
