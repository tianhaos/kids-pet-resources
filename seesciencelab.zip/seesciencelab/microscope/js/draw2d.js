// 显微镜侧视图（左侧为观察者一侧）+ 载物台俯视图；圆形视野是单独的 DOM 元素，这里只负责算出它的位置
// 侧视图以"单位"绘制，1 单位 ≈ 3 mm；光轴 x = 0，载物台上表面 y = 0，y 向下。
(function () {
  var S = window.Scope;
  var UNIT_MM = 3;
  var SLIDE_T = 0.4, COVER_T = 0.12;    // 玻片、盖玻片厚度（单位）
  var MIRROR_Y = 46, STAGE_H = 4, DIAPH_Y = 6.6;
  var ORDER = [4, 10, 40];              // 转换器上物镜的顺序

  var C = {
    body: '#1b2536', bodyHi: '#26324a', edge: '#5d7090', metal: '#a7b6cc', dark: '#0b0f18',
    text: '#c9d2df', muted: '#8d99ab', accent: '#ffc94a', glass: 'rgba(170,215,255,0.35)', glassEdge: 'rgba(190,225,255,0.8)',
    light: '#ffe08a', lineLbl: 'rgba(141,153,171,0.55)', move: '#ffc94a', image: '#c9a7ff'
  };

  function ScopeDraw(canvas) {
    var ctx = canvas.getContext('2d');
    var W = 1, H = 1, dpr = 1, u = 3, ox = 0, oy = 0, narrow = false;
    var L = { fov: { x: 0, y: 0, d: 200 }, tv: { x: 0, y: 0, w: 200, h: 120 } };
    var geo = null, labels = [];

    function resize(w, h) {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      W = w; H = h;
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
      canvas.style.width = w + 'px'; canvas.style.height = h + 'px';
      narrow = w < 640;
      var reg, d, tvW;
      if (!narrow) {
        var half = w * 0.5;
        d = Math.min(half * 0.8, h * 0.56, 460);
        L.fov = { x: half + (half - d) / 2, y: Math.max(72, h * 0.09), d: d };
        tvW = Math.min(half * 0.82, 320);
        var tvTop = L.fov.y + d + 40, tvH = Math.min(tvW * 0.6, h - tvTop - 44);
        L.tv = { x: half + (half - tvW) / 2, y: tvTop, w: tvW, h: Math.max(tvH, 60) };
        reg = { x: 0, y: 40, w: half, h: h - 70 };
      } else {
        d = Math.min(w * 0.5, h * 0.32);
        L.fov = { x: w - d - 12, y: 106, d: d };
        tvW = w - d - 40;
        L.tv = { x: 12, y: 126, w: tvW, h: Math.min(tvW * 0.62, d - 20) };
        var top = L.fov.y + d + 24;
        reg = { x: 0, y: top, w: w, h: h - top - 40 };
      }
      // 侧视图：x 方向 [-50, 62]（含两侧标注），y 方向 [-92, 102]
      u = Math.min(reg.w / 116, reg.h / 194);
      ox = reg.x + reg.w / 2 - 6 * u;
      oy = reg.y + reg.h - 102 * u;
      return L;
    }

    function X(x) { return ox + x * u; }
    function Y(y) { return oy + y * u; }

    // ---------- 几何（随镜筒位置、转换器转动变化） ----------
    function geometry(s) {
      var slideTop = -SLIDE_T - COVER_T;
      var yC = slideTop - s.z / UNIT_MM - 13.5;            // 转换器上沿
      return {
        slideTop: slideTop, yC: yC, tubeTop: yC - 46, eyeTop: yC - 55.5,
        slideX: s.sy / UNIT_MM,                              // 装片前后移动在侧视图里是左右移动
        objLen: function (m) { return 10 + S.OBJ[m].ext / UNIT_MM; },
        coarse: { x: 24, y: -12, r: 7.5 }, fine: { x: 24, y: 16, r: 4.4 },
        mirror: { x: 0, y: MIRROR_Y, r: 7.5 }
      };
    }

    // ---------- 基本绘图 ----------
    function font(size, weight) {
      ctx.font = (weight || '') + ' ' + size + 'px -apple-system, "PingFang SC", "Microsoft YaHei", sans-serif';
    }
    function rr(x, y, w, h, r) {
      ctx.beginPath();
      if (ctx.roundRect) ctx.roundRect(x, y, w, h, r); else ctx.rect(x, y, w, h);
    }
    function boxU(x0, y0, x1, y1, r, fill, stroke) {
      rr(X(x0), Y(y0), (x1 - x0) * u, (y1 - y0) * u, (r || 0) * u);
      if (fill) { ctx.fillStyle = fill; ctx.fill(); }
      if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = 1; ctx.stroke(); }
    }
    function polyU(pts, fill, stroke) {
      ctx.beginPath();
      for (var i = 0; i < pts.length; i += 2) { if (i) ctx.lineTo(X(pts[i]), Y(pts[i + 1])); else ctx.moveTo(X(pts[i]), Y(pts[i + 1])); }
      ctx.closePath();
      if (fill) { ctx.fillStyle = fill; ctx.fill(); }
      if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = 1; ctx.stroke(); }
    }
    function arrow(x1, y1, x2, y2, color, w) {
      ctx.strokeStyle = color; ctx.fillStyle = color; ctx.lineWidth = w || 2; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
      var a = Math.atan2(y2 - y1, x2 - x1), h = 4 + (w || 2) * 2;
      ctx.beginPath(); ctx.moveTo(x2 + Math.cos(a) * 2, y2 + Math.sin(a) * 2);
      ctx.lineTo(x2 - Math.cos(a - 0.5) * h, y2 - Math.sin(a - 0.5) * h);
      ctx.lineTo(x2 - Math.cos(a + 0.5) * h, y2 - Math.sin(a + 0.5) * h);
      ctx.closePath(); ctx.fill();
    }

    // ---------- 光路：窗外的光 → 反光镜 → 遮光器光圈 → 通光孔 → 物镜 → 目镜 ----------
    function mirrorNormal(s) {
      var a = (-45 + s.mirrorA / 2) * Math.PI / 180;      // 镜面倾角（屏幕坐标，y 向下）；偏转 δ 时反射光偏 δ
      return { a: a, nx: Math.sin(a), ny: -Math.cos(a) };
    }
    function drawBeam(s, g) {
      var m = mirrorNormal(s), xL = (0 - ox) / u, my = MIRROR_Y, hw = 2.4;
      // 入射光（从左侧窗户射来）
      var grd = ctx.createLinearGradient(X(xL), 0, X(0), 0);
      grd.addColorStop(0, 'rgba(255,224,138,0)'); grd.addColorStop(1, 'rgba(255,224,138,0.22)');
      ctx.fillStyle = grd;
      ctx.fillRect(X(xL), Y(my - hw), (0 - xL) * u, hw * 2 * u);
      font(Math.max(10, u * 3.2));
      ctx.fillStyle = 'rgba(255,224,138,0.75)'; ctx.textAlign = 'left'; ctx.textBaseline = 'bottom';
      ctx.fillText('光线 →', X(xL) + 6, Y(my - hw) - 2);
      // 反射光：入射方向 (1, 0)，r = v − 2(v·n)n
      var vn = m.nx, rx = 1 - 2 * vn * m.nx, ry = -2 * vn * m.ny;
      var t = (DIAPH_Y - my) / ry, hx = rx * t;            // 到遮光器所在高度时的横向偏移
      var conc = s.mirror === 'concave', hw2 = conc ? 1.1 : hw;
      var apR = { s: 0.7, m: 1.25, l: 2 }[s.aperture];
      var a = conc ? 0.34 : 0.24;
      ctx.fillStyle = 'rgba(255,224,138,' + a + ')';
      ctx.beginPath();
      ctx.moveTo(X(-hw * 0.7), Y(my - hw * 0.4)); ctx.lineTo(X(hw * 0.7), Y(my + hw * 0.4));
      ctx.lineTo(X(hx + hw2), Y(DIAPH_Y)); ctx.lineTo(X(hx - hw2), Y(DIAPH_Y));
      ctx.closePath(); ctx.fill();
      // 穿过光圈的部分：沿光轴向上
      var pass = Math.max(0, Math.min(1, (apR + hw2 - Math.abs(hx)) / (2 * hw2)));
      if (pass > 0.02 && !s.rotating) {
        var top = s.crushed ? g.slideTop : g.eyeTop, w2 = Math.min(apR, 1.6);
        var al = Math.min(0.42, 0.12 + s.bright * 0.2) * pass;
        var gr = ctx.createLinearGradient(0, Y(DIAPH_Y), 0, Y(top));
        gr.addColorStop(0, 'rgba(255,224,138,' + al + ')'); gr.addColorStop(1, 'rgba(255,224,138,' + al * 0.5 + ')');
        ctx.fillStyle = gr;
        ctx.fillRect(X(-w2), Y(top), w2 * 2 * u, (DIAPH_Y - top) * u);
      }
    }

    // ---------- 镜身 ----------
    function drawBody(s, g) {
      var hl = s.hl;
      function hi(id) { return hl === id ? C.accent : C.edge; }
      // 镜座
      polyU([-24, 90, 30, 90, 33, 100, -27, 100], C.body, hi('base'));
      boxU(-24, 90, 30, 91.2, 0, C.bodyHi);
      // 镜柱
      boxU(14, 60, 26, 90, 1, C.body, hi('pillar'));
      // 反光镜支架
      ctx.strokeStyle = C.edge; ctx.lineWidth = Math.max(2, u * 0.9);
      ctx.beginPath(); ctx.moveTo(X(15), Y(64)); ctx.lineTo(X(6), Y(MIRROR_Y + 3)); ctx.lineTo(X(1), Y(MIRROR_Y)); ctx.stroke();
      // 镜臂（C 形）
      ctx.beginPath();
      ctx.moveTo(X(8), Y(-53)); ctx.lineTo(X(17), Y(-56));
      ctx.quadraticCurveTo(X(31), Y(-52), X(30), Y(-30));
      ctx.lineTo(X(28), Y(40)); ctx.lineTo(X(26), Y(62)); ctx.lineTo(X(14), Y(62));
      ctx.lineTo(X(17), Y(40)); ctx.lineTo(X(18), Y(-26));
      ctx.quadraticCurveTo(X(18), Y(-36), X(8), Y(-36));
      ctx.closePath();
      ctx.fillStyle = C.body; ctx.fill(); ctx.strokeStyle = hi('arm'); ctx.lineWidth = 1; ctx.stroke();
      // 倾斜关节
      ctx.beginPath(); ctx.arc(X(20), Y(61), 3.2 * u, 0, 7); ctx.fillStyle = C.bodyHi; ctx.fill(); ctx.strokeStyle = C.edge; ctx.stroke();
      // 镜筒支座
      boxU(4.5, -52, 9, -36, 0.6, C.bodyHi, C.edge);
    }

    function drawMirror(s, g) {
      var m = mirrorNormal(s), rx = g.mirror.r;
      ctx.save();
      ctx.translate(X(0), Y(MIRROR_Y)); ctx.rotate(m.a);
      // 镜框
      rr(-rx * u, -1.1 * u, 2 * rx * u, 2.2 * u, 1.1 * u);
      ctx.fillStyle = C.bodyHi; ctx.fill(); ctx.strokeStyle = s.hl === 'mirror' ? C.accent : C.edge; ctx.lineWidth = 1; ctx.stroke();
      // 镜面（朝向左上方）
      ctx.beginPath();
      if (s.mirror === 'concave') {
        ctx.moveTo(-rx * 0.92 * u, -1.1 * u);
        ctx.quadraticCurveTo(0, 0.3 * u, rx * 0.92 * u, -1.1 * u);
      } else {
        ctx.moveTo(-rx * 0.92 * u, -1.1 * u); ctx.lineTo(rx * 0.92 * u, -1.1 * u);
      }
      ctx.strokeStyle = '#e8f1ff'; ctx.lineWidth = Math.max(1.5, u * 0.6); ctx.stroke();
      ctx.restore();
    }

    function drawStage(s, g) {
      // 遮光器（载物台下面的圆盘）
      ctx.save();
      ctx.translate(X(-3), Y(DIAPH_Y)); ctx.rotate(-0.05);
      ctx.beginPath(); ctx.ellipse(0, 0, 14 * u, 1.7 * u, 0, 0, 7);
      ctx.fillStyle = C.bodyHi; ctx.fill(); ctx.strokeStyle = s.hl === 'diaphragm' ? C.accent : C.edge; ctx.lineWidth = 1; ctx.stroke();
      ctx.restore();
      var apR = { s: 0.7, m: 1.25, l: 2 }[s.aperture];
      ctx.beginPath(); ctx.ellipse(X(0), Y(DIAPH_Y - 0.1), apR * u, 0.7 * u, 0, 0, 7);
      ctx.fillStyle = s.bright > 0.15 ? 'rgba(255,224,138,0.55)' : C.dark; ctx.fill();
      // 载物台
      boxU(-28, 0, 20, STAGE_H, 0.5, C.body, s.hl === 'stage' ? C.accent : C.edge);
      boxU(-28, 0, 20, 0.8, 0, C.bodyHi);
      // 通光孔
      boxU(-2.2, 0, 2.2, STAGE_H, 0, s.bright > 0.15 ? 'rgba(255,224,138,0.3)' : C.dark, s.hl === 'hole' ? C.accent : null);
      // 玻片与盖玻片
      var sx = g.slideX;
      boxU(sx - 4.2, -SLIDE_T, sx + 4.2, 0, 0, C.glass, C.glassEdge);
      boxU(sx - 2.4, -SLIDE_T - COVER_T, sx + 2.4, -SLIDE_T, 0, 'rgba(200,230,255,0.5)');
      var specCol = s.spec.kind === 'cheek' ? '#7f8ce6' : s.spec.kind === 'onion' ? '#d6a65a' : '#222';
      boxU(sx - 0.9, -SLIDE_T - 0.05, sx + 0.9, -SLIDE_T, 0, specCol);
      if (s.crushed) {
        ctx.strokeStyle = '#e6ebf2'; ctx.lineWidth = 1.2;
        ctx.beginPath();
        ctx.moveTo(X(-2.6), Y(-0.5)); ctx.lineTo(X(-1), Y(-0.05)); ctx.lineTo(X(0.2), Y(-0.45)); ctx.lineTo(X(1.4), Y(0)); ctx.lineTo(X(2.6), Y(-0.5));
        ctx.stroke();
      }
      // 压片夹
      boxU(13, -2.3, 15, 0, 0.3, C.bodyHi, s.hl === 'clip' ? C.accent : C.edge);
      ctx.strokeStyle = s.hl === 'clip' ? C.accent : C.metal; ctx.lineWidth = Math.max(1.5, u * 0.5);
      ctx.beginPath(); ctx.moveTo(X(14), Y(-1.9)); ctx.lineTo(X(Math.max(sx + 4.6, 4.8)), Y(-SLIDE_T - 0.15)); ctx.stroke();
    }

    function drawTube(s, g) {
      var yC = g.yC;
      // 镜筒
      boxU(-4.5, g.tubeTop, 4.5, yC + 0.8, 0.4, C.body, s.hl === 'tube' ? C.accent : C.edge);
      boxU(-4.5, g.tubeTop, -3.2, yC + 0.8, 0, 'rgba(255,255,255,0.05)');
      // 目镜
      boxU(-3.6, g.eyeTop + 1.6, 3.6, g.tubeTop + 0.6, 0.3, C.bodyHi, s.hl === 'eyepiece' ? C.accent : C.edge);
      boxU(-4.4, g.eyeTop, 4.4, g.eyeTop + 1.8, 0.5, C.body, s.hl === 'eyepiece' ? C.accent : C.edge);
      if (u > 2.2) {
        font(Math.max(9, u * 2.5), '600'); ctx.fillStyle = C.text; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText(s.eye + '×', X(0), Y((g.eyeTop + g.tubeTop) / 2 + 1));
      }
      // 物镜（按前后顺序画：背后的先画）
      var piv = yC + 2.2, list = [];
      ORDER.forEach(function (m, i) {
        var a = (i - s.turret) * 2 * Math.PI / 3;
        list.push({ m: m, lean: Math.sin(a) * 0.62, depth: Math.cos(a) });
      });
      list.sort(function (p, q) { return p.depth - q.depth; });
      list.forEach(function (o) { if (o.depth < 0.5) drawObjective(s, g, o, piv); });
      // 转换器
      polyU([-8.5, yC, 8.5, yC, 6.5, yC + 3.6, -6.5, yC + 3.6], C.bodyHi, s.hl === 'nosepiece' ? C.accent : C.edge);
      list.forEach(function (o) { if (o.depth >= 0.5) drawObjective(s, g, o, piv); });
    }

    function drawObjective(s, g, o, piv) {
      var len = g.objLen(o.m), col = S.OBJ[o.m].color, a0 = 1.4;
      ctx.save();
      ctx.translate(X(0), Y(piv)); ctx.rotate(-o.lean);
      ctx.globalAlpha = 0.45 + 0.55 * Math.max(0, o.depth);
      var p = [-2.9, a0, 2.9, a0, 2.9, a0 + len * 0.62, 1.8, len + a0 - 0.6, 1.8, len + a0, -1.8, len + a0, -1.8, len + a0 - 0.6, -2.9, a0 + len * 0.62];
      ctx.beginPath();
      for (var i = 0; i < p.length; i += 2) { if (i) ctx.lineTo(p[i] * u, p[i + 1] * u); else ctx.moveTo(p[i] * u, p[i + 1] * u); }
      ctx.closePath();
      ctx.fillStyle = C.body; ctx.fill();
      ctx.strokeStyle = s.hl === 'objective' && o.depth > 0.9 ? C.accent : C.edge; ctx.lineWidth = 1; ctx.stroke();
      ctx.fillStyle = col; ctx.fillRect(-2.9 * u, (a0 + 2.2) * u, 5.8 * u, Math.max(1.5, 0.9 * u));
      ctx.fillStyle = 'rgba(170,215,255,0.8)'; ctx.fillRect(-1.1 * u, (len + a0) * u - 1.5, 2.2 * u, 1.5);
      if (o.depth > 0.9 && u > 2.4) {
        font(Math.max(8, u * 2.2), '600'); ctx.fillStyle = C.text; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText(o.m + '×', 0, (a0 + len * 0.42) * u);
      }
      ctx.restore();
    }

    function drawKnob(k, ang, id, s) {
      var x = X(k.x), y = Y(k.y), r = k.r * u;
      var gr = ctx.createRadialGradient(x - r * 0.3, y - r * 0.3, r * 0.1, x, y, r);
      gr.addColorStop(0, '#3a4862'); gr.addColorStop(1, '#151c2a');
      ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.fillStyle = gr; ctx.fill();
      ctx.strokeStyle = s.hl === id || s.drag === id ? C.accent : C.edge; ctx.lineWidth = s.drag === id ? 2 : 1; ctx.stroke();
      // 防滑纹，随转动角度旋转
      ctx.strokeStyle = 'rgba(167,182,204,0.45)'; ctx.lineWidth = 1;
      var n = id === 'coarse' ? 16 : 12;
      for (var i = 0; i < n; i++) {
        var a = ang * Math.PI / 180 + i / n * Math.PI * 2;
        ctx.beginPath(); ctx.moveTo(x + Math.cos(a) * r * 0.72, y + Math.sin(a) * r * 0.72);
        ctx.lineTo(x + Math.cos(a) * r * 0.96, y + Math.sin(a) * r * 0.96); ctx.stroke();
      }
      ctx.beginPath(); ctx.arc(x, y, r * 0.3, 0, 7); ctx.fillStyle = '#2a3446'; ctx.fill();
      // 标记点
      var am = ang * Math.PI / 180 - Math.PI / 2;
      ctx.beginPath(); ctx.arc(x + Math.cos(am) * r * 0.55, y + Math.sin(am) * r * 0.55, Math.max(1.5, r * 0.09), 0, 7);
      ctx.fillStyle = C.accent; ctx.fill();
    }

    // ---------- 放大看：物镜下端与玻片的距离 ----------
    function drawLoupe(s, g) {
      var cx = X(-40), cy = Y(25), R = 10 * u;
      var gap = S.gap(s.z, s.obj), m = R * 2 / 5;           // 窗口纵向约 5 mm
      var base = cy + R * 0.25;                               // 玻片（含盖玻片）上表面
      ctx.save();
      ctx.beginPath(); ctx.arc(cx, cy, R, 0, 7);
      ctx.fillStyle = '#080c15'; ctx.fill();
      ctx.clip();
      // 玻片
      ctx.fillStyle = C.glass; ctx.fillRect(cx - R, base + 0.17 * m, 2 * R, 1.2 * m);
      ctx.fillStyle = 'rgba(200,230,255,0.5)'; ctx.fillRect(cx - R * 0.8, base, 1.6 * R, 0.17 * m);
      if (s.crushed) {
        ctx.strokeStyle = '#e6ebf2'; ctx.lineWidth = 1.2; ctx.beginPath();
        ctx.moveTo(cx - R * 0.6, base + 2); ctx.lineTo(cx - R * 0.2, base + 0.9 * m); ctx.lineTo(cx + R * 0.1, base + 0.3 * m); ctx.lineTo(cx + R * 0.5, base + 1.1 * m);
        ctx.stroke();
      }
      // 物镜下端
      var tip = base - gap * m;
      if (!s.rotating && tip > cy - R - 4) {
        var hw = s.obj === 4 ? R * 0.95 : s.obj === 10 ? R * 0.8 : R * 0.62;
        ctx.fillStyle = C.body; ctx.fillRect(cx - hw, tip - 3 * m, 2 * hw, 3 * m);
        ctx.strokeStyle = S.OBJ[s.obj].color; ctx.lineWidth = 1.5; ctx.strokeRect(cx - hw, tip - 3 * m, 2 * hw, 3 * m);
        ctx.fillStyle = 'rgba(170,215,255,0.85)'; ctx.fillRect(cx - hw * 0.45, tip - 2, hw * 0.9, 2);
      } else if (!s.rotating) {
        arrow(cx, cy + R * 0.15, cx, cy - R * 0.4, S.OBJ[s.obj].color, 1.5);
      }
      ctx.restore();
      ctx.beginPath(); ctx.arc(cx, cy, R, 0, 7);
      ctx.strokeStyle = C.edge; ctx.lineWidth = 1.5; ctx.stroke();
      // 引线指向通光孔上方
      ctx.strokeStyle = C.lineLbl; ctx.lineWidth = 1; ctx.setLineDash([3, 3]);
      ctx.beginPath(); ctx.moveTo(cx + R * 0.7, cy - R * 0.7); ctx.lineTo(X(-3), Y(g.slideTop)); ctx.stroke();
      ctx.setLineDash([]);
      // 读数写在圆圈顶部，宽屏时下面再加一行说明
      font(narrow ? 10 : Math.max(10, Math.min(12, u * 3)), '600');
      ctx.textAlign = 'center'; ctx.textBaseline = 'top';
      ctx.fillStyle = s.crushed ? '#ff7a59' : gap < 1 ? C.accent : C.text;
      ctx.fillText(s.crushed ? '压碎了！' : s.rotating ? '—' : (gap < 1 ? gap.toFixed(2) : gap.toFixed(1)) + ' mm', cx, cy - R + 5);
      if (!narrow) {
        font(Math.max(10, Math.min(12, u * 3)));
        ctx.fillStyle = C.muted;
        ctx.fillText('物镜距玻片', cx, cy + R + 4);
      }
    }

    // ---------- 结构名称 ----------
    function partAnchors(s, g) {
      var objMid = g.yC + 3.6 + g.objLen(s.obj) * 0.5;
      return [
        ['eyepiece', -4.4, g.eyeTop + 3, 'L'], ['tube', -4.5, g.yC - 24, 'L'], ['nosepiece', -7.5, g.yC + 1.5, 'L'],
        ['objective', -2.9, objMid, 'L'], ['stage', -27, 2, 'L'], ['diaphragm', -15, DIAPH_Y + 0.5, 'L'],
        ['mirror', -5, MIRROR_Y + 3, 'L'], ['base', -22, 95, 'L'],
        ['arm', 30, -36, 'R'], ['coarse', 31.5, -12, 'R'], ['clip', 14, -2, 'R'], ['hole', 1.5, 2.5, 'R'],
        ['fine', 28.4, 16, 'R'], ['pillar', 26, 76, 'R']
      ];
    }
    function drawLabels(s, g) {
      labels = [];
      var fs = Math.max(10, Math.min(13, u * 3.3)), gapY = fs + 4;
      font(fs);
      var sides = { L: [], R: [] };
      partAnchors(s, g).forEach(function (a) { sides[a[3]].push({ id: a[0], ax: X(a[1]), ay: Y(a[2]), y: Y(a[2]) }); });
      ['L', 'R'].forEach(function (side) {
        var arr = sides[side].sort(function (p, q) { return p.ay - q.ay; });
        for (var it = 0; it < 30; it++) {      // 简单的上下推开，避免文字重叠
          for (var i = 1; i < arr.length; i++) {
            var d = arr[i].y - arr[i - 1].y;
            if (d < gapY) { arr[i].y += (gapY - d) / 2; arr[i - 1].y -= (gapY - d) / 2; }
          }
        }
        var tx = side === 'L' ? X(-31) : X(35);
        arr.forEach(function (p) {
          var name = S.PARTS[p.id][0], on = s.hl === p.id;
          ctx.strokeStyle = on ? C.accent : C.lineLbl; ctx.lineWidth = 1;
          ctx.beginPath(); ctx.moveTo(p.ax, p.ay);
          ctx.lineTo(tx + (side === 'L' ? 4 : -4), p.y); ctx.stroke();
          ctx.beginPath(); ctx.arc(p.ax, p.ay, 1.8, 0, 7); ctx.fillStyle = on ? C.accent : C.muted; ctx.fill();
          ctx.fillStyle = on ? C.accent : C.text;
          ctx.textAlign = side === 'L' ? 'right' : 'left'; ctx.textBaseline = 'middle';
          ctx.fillText(name, tx, p.y);
          var w = ctx.measureText(name).width;
          labels.push({ id: p.id, x0: side === 'L' ? tx - w - 3 : tx - 3, x1: side === 'L' ? tx + 3 : tx + w + 3, y0: p.y - fs / 2 - 3, y1: p.y + fs / 2 + 3 });
        });
      });
    }

    // ---------- 载物台俯视图 ----------
    function tvScale() { return L.tv.w / 112; }
    function tvCenter() { return { x: L.tv.x + L.tv.w / 2, y: L.tv.y + L.tv.h / 2 + 4 }; }
    function drawTop(s) {
      var tv = L.tv, sc = tvScale(), c = tvCenter();
      font(12, '600'); ctx.fillStyle = C.muted; ctx.textAlign = 'left'; ctx.textBaseline = 'bottom';
      ctx.fillText('载物台（俯视）', tv.x, tv.y - 6);
      ctx.textAlign = 'right'; font(11);
      ctx.fillText(narrow ? '拖动装片' : '拖动装片，或在视野里拖动', tv.x + tv.w, tv.y - 6);
      // 台面
      rr(tv.x, tv.y, tv.w, tv.h, 8); ctx.fillStyle = '#0d1320'; ctx.fill(); ctx.strokeStyle = C.edge; ctx.lineWidth = 1; ctx.stroke();
      ctx.save();
      rr(tv.x, tv.y, tv.w, tv.h, 8); ctx.clip();
      // 通光孔与十字线
      ctx.beginPath(); ctx.arc(c.x, c.y, 5 * sc, 0, 7);
      ctx.fillStyle = s.bright > 0.15 ? 'rgba(255,224,138,' + Math.min(0.7, 0.2 + s.bright * 0.4) + ')' : '#05070d'; ctx.fill();
      ctx.setLineDash([3, 4]); ctx.strokeStyle = 'rgba(141,153,171,0.35)';
      ctx.beginPath(); ctx.moveTo(tv.x, c.y); ctx.lineTo(tv.x + tv.w, c.y); ctx.moveTo(c.x, tv.y); ctx.lineTo(c.x, tv.y + tv.h); ctx.stroke();
      ctx.setLineDash([]);
      // 装片
      var px = c.x + s.sx * sc, py = c.y - s.sy * sc;
      rr(px - 37.5 * sc, py - 12.5 * sc, 75 * sc, 25 * sc, 2);
      ctx.fillStyle = 'rgba(170,215,255,0.16)'; ctx.fill();
      ctx.strokeStyle = s.drag === 'slide' ? C.accent : C.glassEdge; ctx.lineWidth = s.drag === 'slide' ? 2 : 1; ctx.stroke();
      rr(px - 11 * sc, py - 11 * sc, 22 * sc, 22 * sc, 1);
      ctx.fillStyle = 'rgba(200,230,255,0.14)'; ctx.fill();
      // 标本（字放大画出，便于看清方向）
      var sp = s.spec;
      if (sp.kind === 'letter') {
        var fs = Math.max(14, sc * 6);
        ctx.font = '700 ' + fs + 'px ' + (/[一-龥]/.test(sp.ch) ? '"PingFang SC","Microsoft YaHei",sans-serif' : 'Georgia,serif');
        ctx.fillStyle = '#e6ebf2'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText(sp.ch, px, py);
      } else {
        ctx.beginPath(); ctx.ellipse(px, py, sp.size[0] / 2 * sc * 1.6, sp.size[1] / 2 * sc * 1.6, 0, 0, 7);
        ctx.fillStyle = sp.kind === 'onion' ? 'rgba(214,166,90,0.55)' : 'rgba(127,140,230,0.55)'; ctx.fill();
      }
      if (s.dirt && s.dirt.where === 'slide') {
        ctx.beginPath(); ctx.arc(px + s.dirt.x * sc * 1.6, py - s.dirt.y * sc * 1.6, 2, 0, 7); ctx.fillStyle = '#111'; ctx.fill();
      }
      // 压片夹
      ctx.fillStyle = C.metal;
      [-1, 1].forEach(function (sg) {
        ctx.fillRect(c.x + sg * 30 * sc - (sg > 0 ? 0 : 10 * sc), c.y - 2.2 * sc, 10 * sc, 4.4 * sc);
        ctx.beginPath(); ctx.arc(c.x + sg * 42 * sc, c.y, 2.6 * sc, 0, 7); ctx.fill();
      });
      ctx.restore();
      // 装片移动方向
      var mv = s.moveArrow;
      if (mv && mv.alpha > 0.02) {
        var len = Math.hypot(mv.x, mv.y);
        if (len > 1e-6) {
          ctx.globalAlpha = mv.alpha;
          var ux = mv.x / len, uy = -mv.y / len, A = Math.min(tv.w, tv.h) * 0.3;
          arrow(px - ux * A * 0.2, py - uy * A * 0.2, px + ux * A, py + uy * A, C.move, 3);
          font(12, '600'); ctx.fillStyle = C.move; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
          ctx.fillText('装片移动', px + ux * A * 0.4 - uy * 15, py + uy * A * 0.4 + ux * 15);
          ctx.globalAlpha = 1;
        }
      }
      font(11); ctx.fillStyle = C.muted; ctx.textAlign = 'center'; ctx.textBaseline = 'top';
      ctx.fillText('↓ 观察者（你）坐在这一侧', c.x, tv.y + tv.h + 5);
    }

    function drawFovTitle(s) {
      var f = L.fov;
      font(12, '600'); ctx.fillStyle = C.muted; ctx.textAlign = 'left'; ctx.textBaseline = 'bottom';
      ctx.fillText(narrow ? '视野' : '视野（目镜中看到的）', f.x, f.y - 12);
      ctx.textAlign = 'right'; ctx.fillStyle = C.accent;
      ctx.fillText(s.eye + '× × ' + s.obj + '× = ' + S.total(s) + ' 倍', f.x + f.d, f.y - 12);
    }

    // ---------- 主绘制 ----------
    function draw(s) {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, W, H);
      var g = geo = geometry(s);
      drawBeam(s, g);
      drawBody(s, g);
      drawMirror(s, g);
      drawTube(s, g);
      drawStage(s, g);
      drawKnob(g.coarse, s.knob.coarse, 'coarse', s);
      drawKnob(g.fine, s.knob.fine, 'fine', s);
      drawLoupe(s, g);
      if (s.show.labels) drawLabels(s, g); else labels = [];
      drawTop(s);
      drawFovTitle(s);
    }

    // ---------- 命中测试 ----------
    function hit(px, py, s) {
      var g = geo || geometry(s);
      var x = (px - ox) / u, y = (py - oy) / u;
      // 俯视图中的装片
      var tv = L.tv;
      if (px >= tv.x && px <= tv.x + tv.w && py >= tv.y && py <= tv.y + tv.h) {
        var sc = tvScale(), c = tvCenter(), sx = c.x + s.sx * sc, sy = c.y - s.sy * sc;
        if (Math.abs(px - sx) <= 37.5 * sc + 6 && Math.abs(py - sy) <= 12.5 * sc + 6) return { type: 'slide' };
        return null;
      }
      function near(k, pad) { return Math.hypot(x - k.x, y - k.y) <= k.r + pad; }
      if (near(g.coarse, 1.5)) return { type: 'knob', id: 'coarse' };
      if (near(g.fine, 2)) return { type: 'knob', id: 'fine' };
      if (Math.hypot(x, y - MIRROR_Y) <= g.mirror.r + 1.5) return { type: 'mirror' };
      for (var i = 0; i < labels.length; i++) {
        var b = labels[i];
        if (px >= b.x0 && px <= b.x1 && py >= b.y0 && py <= b.y1) return { type: 'part', id: b.id };
      }
      if (Math.abs(x) <= 4.6 && y >= g.eyeTop && y <= g.tubeTop + 0.6) return { type: 'eyepiece' };
      if (Math.abs(x) <= 8.5 && y >= g.yC - 1 && y <= g.yC + 3.6 + g.objLen(s.obj)) return { type: 'nosepiece' };
      if (y >= DIAPH_Y - 2 && y <= DIAPH_Y + 2 && x >= -17 && x <= 11) return { type: 'diaphragm' };
      if (Math.abs(x) <= 4.5 && y >= g.tubeTop && y <= g.yC) return { type: 'part', id: 'tube' };
      if (y >= 0 && y <= STAGE_H && x >= -28 && x <= 20) return { type: 'part', id: Math.abs(x) <= 2.2 ? 'hole' : 'stage' };
      if (x >= 12 && x <= 31 && y >= -56 && y <= 62) return { type: 'part', id: 'arm' };
      if (x >= 14 && x <= 26 && y >= 62 && y <= 90) return { type: 'part', id: 'pillar' };
      if (x >= -27 && x <= 33 && y >= 90 && y <= 100) return { type: 'part', id: 'base' };
      return null;
    }

    return {
      resize: resize, draw: draw, hit: hit, layout: function () { return L; },
      tvScale: tvScale, unitPx: function () { return u; }
    };
  }

  window.ScopeDraw = ScopeDraw;
})();
