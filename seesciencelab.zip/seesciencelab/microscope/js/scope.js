// 显微镜的计算：放大倍数、视野、调焦、亮度，以及装片标本的生成（长度单位 mm）
// 调焦用"镜筒位置 z"描述：z = 4× 物镜下端到玻片上表面的距离；物镜越长，下端越低（ext）。
(function () {
  // 物镜：ext 比 4× 物镜长出的长度，wd 工作距离（物像清晰时物镜下端到玻片），dof 景深（示意值，已放大便于操作），light 进光系数
  // 三个物镜"齐焦"：清晰位置 z = ext + wd 几乎相同，换物镜后只需用细准焦螺旋微调
  var OBJ = {
    4:  { mag: 4,  ext: 0,     wd: 17.6, dof: 0.25,  light: 1,    color: '#ff7a59' },
    10: { mag: 10, ext: 10.8,  wd: 6.85, dof: 0.07,  light: 0.72, color: '#ffd166' },
    40: { mag: 40, ext: 16.95, wd: 0.62, dof: 0.018, light: 0.4,  color: '#4fc3f7' }
  };
  var EYE = { 5: { light: 1.1 }, 10: { light: 1 }, 16: { light: 0.85 } };
  var FIELD_K = 180;            // 视野直径（mm）≈ FIELD_K / 总放大倍数（目镜视场数约 18 mm）
  var Z_MAX = 45;               // 镜筒最高位置
  var APERTURE = { s: 0.35, m: 0.65, l: 1 };     // 遮光器：小、中、大光圈
  var MIRROR = { flat: 0.6, concave: 1 };        // 反光镜：平面镜、凹面镜（会聚光线）
  var AMBIENT = { bright: 1, dim: 0.55 };        // 环境光
  var ALIGN_W = 8;              // 反光镜偏离对光角度的容差（°）

  function total(s) { return s.obj * s.eye; }
  function fovMm(s) { return FIELD_K / total(s); }
  function focusZ(obj) { return OBJ[obj].ext + OBJ[obj].wd; }
  function gap(z, obj) { return z - OBJ[obj].ext; }
  // 离焦量：以景深为单位，带符号（正 = 镜筒偏高）
  function defocus(z, obj) { return (z - focusZ(obj)) / OBJ[obj].dof; }

  function align(mirrorA) { return Math.exp(-0.5 * Math.pow(mirrorA / ALIGN_W, 2)); }
  function brightness(s) {
    return 1.9 * align(s.mirrorA) * MIRROR[s.mirror] * APERTURE[s.aperture] * AMBIENT[s.ambient]
      * OBJ[s.obj].light * EYE[s.eye].light;
  }
  function lightLevel(b) {
    if (b < 0.25) return { key: 'dark', name: '很暗' };
    if (b < 0.55) return { key: 'dim', name: '偏暗' };
    if (b <= 1.35) return { key: 'ok', name: '明亮' };
    return { key: 'glare', name: '过亮' };
  }
  function clarity(d) {
    var a = Math.abs(d);
    if (a < 0.4) return { key: 'sharp', name: '清晰' };
    if (a < 3) return { key: 'soft', name: '稍模糊' };
    if (a < 14) return { key: 'blur', name: '模糊' };
    return { key: 'none', name: '看不到物像' };
  }

  // ---------- 装片标本 ----------
  function rng(seed) {
    return function () {
      seed |= 0; seed = seed + 0x6D2B79F5 | 0;
      var t = Math.imul(seed ^ seed >>> 15, 1 | seed);
      t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
      return ((t ^ t >>> 14) >>> 0) / 4294967296;
    };
  }

  // 洋葱鳞片叶内表皮：砖块状排列的长方形细胞，碘液染色后细胞核呈棕色；撕下的表皮边缘不规则，夹带几个气泡
  function onion() {
    var R = rng(7), cells = [], W = 2.3, H = 1.7;
    function inside(x, y) {
      var a = Math.atan2(y / H, x / W), r = Math.hypot(x / W, y / H);
      return r < 1 + 0.12 * Math.sin(3 * a + 1.3) + 0.07 * Math.sin(7 * a + 0.4) + 0.04 * Math.sin(13 * a + 2);
    }
    for (var y = -H * 1.3; y < H * 1.3;) {
      var h = 0.05 + R() * 0.022;
      var x = -W * 1.35 - R() * 0.3, prev = { t: x, b: x };
      while (x < W * 1.35) {
        var len = 0.17 + R() * 0.17, s = (R() - 0.5) * 0.045;
        var b = { t: x + len + s, b: x + len - s };
        var cx = x + len / 2, cy = y + h / 2;
        if (inside(cx, cy)) {
          cells.push({
            q: [prev.t, y, b.t, y, b.b, y + h, prev.b, y + h],
            x0: Math.min(prev.t, prev.b), x1: Math.max(b.t, b.b), y0: y, y1: y + h,
            nx: cx + (R() - 0.5) * len * 0.55, ny: cy + (R() - 0.5) * h * 0.3,
            nr: 0.0075 + R() * 0.003, tone: R()
          });
        }
        prev = b; x += len;
      }
      y += h;
    }
    var bubbles = [[-1.1, 0.55, 0.32], [0.9, -0.7, 0.16], [1.5, 0.6, 0.09], [-0.3, -1.05, 0.06], [0.25, 0.85, 0.045]];
    return { kind: 'onion', cells: cells, bubbles: bubbles, inside: inside, size: [W * 2, H * 2], name: '洋葱鳞片叶内表皮细胞' };
  }

  // 人的口腔上皮细胞：扁平、不规则的多边形，散在或成团，亚甲蓝（或碘液）染色，细胞核位于中央
  function cheek() {
    var R = rng(11), cells = [];
    for (var k = 0; k < 16; k++) {
      var a = R() * Math.PI * 2, d = Math.sqrt(R()) * 1.2;
      var cx = Math.cos(a) * d, cy = Math.sin(a) * d * 0.8;
      var n = 2 + Math.floor(R() * (k < 4 ? 22 : 9)), spread = 0.05 + R() * 0.07;
      for (var i = 0; i < n; i++) {
        var r = 0.024 + R() * 0.013, rot = R() * Math.PI * 2, pts = [];
        var x = cx + (R() + R() - 1) * spread * 1.4, y = cy + (R() + R() - 1) * spread;
        var m = 7 + Math.floor(R() * 3);
        for (var j = 0; j < m; j++) {
          var t = rot + j / m * Math.PI * 2 + (R() - 0.5) * 0.4, rr = r * (0.72 + R() * 0.42);
          pts.push(x + Math.cos(t) * rr * 1.15, y + Math.sin(t) * rr);
        }
        cells.push({ p: pts, x: x, y: y, r: r * 1.3, nx: x + (R() - 0.5) * r * 0.35, ny: y + (R() - 0.5) * r * 0.3,
          nr: 0.0045 + R() * 0.0015, tone: R() });
      }
    }
    var bubbles = [[0.75, 0.6, 0.2], [-0.95, -0.35, 0.12], [0.2, -0.9, 0.07]];
    function inside(x, y) {
      for (var i = 0; i < cells.length; i++) if (Math.hypot(x - cells[i].x, y - cells[i].y) < 0.12) return true;
      return false;
    }
    return { kind: 'cheek', cells: cells, bubbles: bubbles, inside: inside, size: [2.6, 2.2], name: '人的口腔上皮细胞' };
  }

  // 字母装片：纸片上印的字母，字高约 2.6 mm
  function letter(ch) {
    return { kind: 'letter', ch: ch, h: 2.6, paper: 4.4, size: [4.4, 4.4], name: '写有"' + ch + '"字的装片',
      inside: function (x, y) { return Math.abs(x) < 2.2 && Math.abs(y) < 2.2; } };
  }

  var cache = {};
  function specimen(kind, ch) {
    var key = kind === 'letter' ? 'letter-' + ch : kind;
    if (!cache[key]) cache[key] = kind === 'onion' ? onion() : kind === 'cheek' ? cheek() : letter(ch);
    return cache[key];
  }

  // 显微镜各部分的名称与作用
  var PARTS = {
    eyepiece:  ['目镜', '靠近眼睛的镜头，上面刻有放大倍数（如 5×、10×、16×）。目镜没有螺纹，镜头越长，放大倍数越小。'],
    tube:      ['镜筒', '上端安装目镜，下端连着转换器。转动粗、细准焦螺旋时，镜筒上升或下降。'],
    nosepiece: ['转换器', '可以转动的圆盘，上面装有几个物镜。换物镜时要转动转换器，不能直接扳物镜。'],
    objective: ['物镜', '靠近玻片标本的镜头，有螺纹。物镜越长，放大倍数越大，物像清晰时离玻片越近。'],
    stage:     ['载物台', '放置玻片标本的平台，中央有通光孔，两旁有压片夹。'],
    hole:      ['通光孔', '载物台中央的孔，反光镜反射的光由此穿过标本进入物镜。'],
    clip:      ['压片夹', '压住玻片标本，防止它移动。'],
    diaphragm: ['遮光器', '上面有大小不同的光圈，调节进光量：光线强时用小光圈，光线弱时用大光圈。'],
    mirror:    ['反光镜', '把光线反射到通光孔。一面是平面镜，一面是凹面镜：光线强时用平面镜，光线弱时用凹面镜（会聚光线，视野更亮）。'],
    coarse:    ['粗准焦螺旋', '转动时镜筒升降的幅度大，用来寻找物像。换用高倍物镜后不能再用它。'],
    fine:      ['细准焦螺旋', '转动时镜筒升降的幅度很小，用来把物像调得更清晰。'],
    arm:       ['镜臂', '取镜和安放时握住的部位：右手握镜臂，左手托镜座。'],
    pillar:    ['镜柱', '连接镜臂与镜座，支持镜柱以上的部分。'],
    base:      ['镜座', '稳定和支持整个镜身。']
  };

  window.Scope = {
    OBJ: OBJ, EYE: EYE, Z_MAX: Z_MAX, APERTURE: APERTURE, PARTS: PARTS,
    total: total, fovMm: fovMm, focusZ: focusZ, gap: gap, defocus: defocus,
    align: align, brightness: brightness, lightLevel: lightLevel, clarity: clarity,
    specimen: specimen, rng: rng
  };
})();
