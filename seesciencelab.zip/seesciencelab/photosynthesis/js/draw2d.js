// 2D 绘制：金鱼藻气泡计数装置与“气泡数—变量”曲线、密闭玻璃罩一昼夜（天空、植物、气体进出箭头、速率曲线与 CO₂ 浓度曲线）、普利斯特利钟罩四组对照
// 装置图在虚拟坐标里画（气泡装置 580×420、钟罩 200×230），按区域等比缩放居中
(function () {
  var P = window.Photo;
  var GOLD = '#ffc94a', O2C = '#4fc3f7', CO2C = '#ff9a62', PHO = '#7ee081', RES = '#ff7a59';
  var MUTED = '#8d99ab', TEXT = '#e6ebf2', LINE = 'rgba(141,153,171,.55)', GRID = 'rgba(141,153,171,.14)';
  var GLASS = 'rgba(200,225,255,.55)', WATER = 'rgba(79,160,255,.16)', LEAF = '#4caf50', LEAF2 = '#2e7d32';
  var FONT = '-apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", sans-serif';
  var TOP = 46, BOTTOM = 46;      // 上方留给提示条、下方留给“原理讲解”按钮

  function font(px, w) { return (w ? w + ' ' : '') + px + 'px ' + FONT; }
  function label(ctx, s, x, y, o) {
    o = o || {};
    ctx.font = font(o.size || 12, o.bold ? 600 : null);
    ctx.textAlign = o.align || 'center'; ctx.textBaseline = o.base || 'middle';
    ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(5,7,13,.85)'; ctx.strokeText(s, x, y);
    ctx.fillStyle = o.color || TEXT; ctx.fillText(s, x, y);
  }
  function arrow(ctx, x1, y1, x2, y2, size, color, width) {
    var a = Math.atan2(y2 - y1, x2 - x1), len = Math.hypot(x2 - x1, y2 - y1);
    if (len < 1) return;
    size = Math.min(size, len * 0.7);
    ctx.strokeStyle = ctx.fillStyle = color; ctx.lineWidth = width || 2; ctx.setLineDash([]);
    ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2 - Math.cos(a) * size * 0.6, y2 - Math.sin(a) * size * 0.6); ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(x2, y2);
    ctx.lineTo(x2 - size * Math.cos(a - 0.45), y2 - size * Math.sin(a - 0.45));
    ctx.lineTo(x2 - size * Math.cos(a + 0.45), y2 - size * Math.sin(a + 0.45));
    ctx.closePath(); ctx.fill();
  }
  function rrect(ctx, x, y, w, h, r) {
    ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
  }
  // 区域内等比缩放：虚拟尺寸 vw×vh 放进 box，返回 { k, ox, oy }
  function fit(box, vw, vh) {
    var k = Math.min(box.w / vw, box.h / vh);
    return { k: k, ox: box.x + (box.w - vw * k) / 2, oy: box.y + (box.h - vh * k) / 2 };
  }
  function fmt(v, d) { return (+v).toFixed(d == null ? 0 : d); }
  // 时刻 → “时:分”（四舍五入到分钟，24 时写成 24:00）
  function hm(t) { var mm = Math.round(t * 60), h = Math.floor(mm / 60), m = mm % 60; return h + ':' + (m < 10 ? '0' : '') + m; }

  // ---------- 金鱼藻（一束有轮生细叶的茎） ----------
  function hornwort(ctx, x, y0, y1, lean, sway) {
    var n = 7;
    ctx.strokeStyle = LEAF2; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(x, y0);
    ctx.quadraticCurveTo(x + lean * 0.5 + sway, (y0 + y1) / 2, x + lean + sway, y1); ctx.stroke();
    for (var i = 1; i <= n; i++) {
      var f = i / (n + 0.4), cy = y0 + (y1 - y0) * f, len = 11 - f * 4;
      // 与茎的二次贝塞尔曲线同一参数处
      var cx = x + (lean * 0.5 + sway) * 2 * f * (1 - f) + (lean + sway) * f * f;
      ctx.strokeStyle = i % 2 ? LEAF : '#66bb6a'; ctx.lineWidth = 1.3;
      for (var j = 0; j < 4; j++) {
        var a = -Math.PI / 2 + (j - 1.5) * 0.75 + sway * 0.02;
        ctx.beginPath(); ctx.moveTo(cx, cy);
        ctx.quadraticCurveTo(cx + Math.cos(a) * len * 0.6 + (j < 2 ? -3 : 3), cy + Math.sin(a) * len * 0.3, cx + Math.cos(a) * len, cy + Math.sin(a) * len * 0.9);
        ctx.stroke();
      }
    }
  }

  // ---------- 盆栽植物（钟罩、玻璃罩里共用） ----------
  function pottedPlant(ctx, x, y, s, dim) {
    // 花盆
    ctx.fillStyle = dim ? '#5a3a28' : '#8d5a3b';
    ctx.beginPath(); ctx.moveTo(x - 16 * s, y - 22 * s); ctx.lineTo(x + 16 * s, y - 22 * s); ctx.lineTo(x + 12 * s, y); ctx.lineTo(x - 12 * s, y); ctx.closePath(); ctx.fill();
    ctx.fillStyle = dim ? '#3d281c' : '#6b4129'; ctx.fillRect(x - 17 * s, y - 25 * s, 34 * s, 4 * s);
    // 茎
    ctx.strokeStyle = dim ? '#2c5a2e' : LEAF2; ctx.lineWidth = 2.4 * s;
    ctx.beginPath(); ctx.moveTo(x, y - 24 * s); ctx.quadraticCurveTo(x - 3 * s, y - 50 * s, x + 1 * s, y - 72 * s); ctx.stroke();
    // 叶
    var leaves = [[-1, 34, 0.5], [1, 44, 0.45], [-1, 55, 0.4], [1, 63, 0.35], [-1, 70, 0.3], [1, 74, 0.25]];
    leaves.forEach(function (l) {
      var bx = x + (l[0] > 0 ? 0.5 : -1.5) * s, by = y - l[1] * s, len = 22 * s * (0.6 + l[2]), a = l[0] > 0 ? -0.45 : Math.PI + 0.45;
      var ex = bx + Math.cos(a) * len, ey = by + Math.sin(a) * len, mx = (bx + ex) / 2, my = (by + ey) / 2;
      var nx = -Math.sin(a) * len * 0.28, ny = Math.cos(a) * len * 0.28;
      ctx.fillStyle = dim ? '#2f6b33' : LEAF;
      ctx.beginPath(); ctx.moveTo(bx, by); ctx.quadraticCurveTo(mx + nx, my + ny, ex, ey); ctx.quadraticCurveTo(mx - nx, my - ny, bx, by); ctx.fill();
      ctx.strokeStyle = dim ? '#1f4a22' : LEAF2; ctx.lineWidth = 0.8 * s;
      ctx.beginPath(); ctx.moveTo(bx, by); ctx.lineTo(ex, ey); ctx.stroke();
    });
  }
  // 钟罩（玻璃罩）：底边中点 (x, y)，宽 w 高 h
  function bellJar(ctx, x, y, w, h, tint) {
    var r = w / 2;
    ctx.beginPath();
    ctx.moveTo(x - r, y); ctx.lineTo(x - r, y - h + r); ctx.arc(x, y - h + r, r, Math.PI, 0); ctx.lineTo(x + r, y);
    if (tint) { ctx.fillStyle = tint; ctx.fill(); }
    ctx.strokeStyle = GLASS; ctx.lineWidth = 2; ctx.stroke();
    // 顶上的把手、高光
    ctx.fillStyle = GLASS; ctx.beginPath(); ctx.arc(x, y - h - 4, 5, 0, 7); ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,.18)'; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.arc(x, y - h + r, r - 7, Math.PI * 1.1, Math.PI * 1.4); ctx.stroke();
    // 底板
    ctx.fillStyle = '#3a4558'; ctx.fillRect(x - r - 10, y, w + 20, 5);
  }
  function flame(ctx, x, y, s, t) {
    var fl = 1 + Math.sin(t * 17) * 0.06 + Math.sin(t * 29) * 0.04;
    var g = ctx.createRadialGradient(x, y - 6 * s, 0, x, y - 6 * s, 22 * s);
    g.addColorStop(0, 'rgba(255,200,80,.45)'); g.addColorStop(1, 'rgba(255,200,80,0)');
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y - 6 * s, 22 * s, 0, 7); ctx.fill();
    ctx.fillStyle = '#ffb03a';
    ctx.beginPath(); ctx.moveTo(x, y - 16 * s * fl); ctx.quadraticCurveTo(x + 5 * s, y - 4 * s, x, y); ctx.quadraticCurveTo(x - 5 * s, y - 4 * s, x, y - 16 * s * fl); ctx.fill();
    ctx.fillStyle = '#fff3c4';
    ctx.beginPath(); ctx.moveTo(x, y - 9 * s * fl); ctx.quadraticCurveTo(x + 2.4 * s, y - 2 * s, x, y); ctx.quadraticCurveTo(x - 2.4 * s, y - 2 * s, x, y - 9 * s * fl); ctx.fill();
  }
  function candle(ctx, x, y, s, lit, t, smoke) {
    ctx.fillStyle = '#f2ecdc'; ctx.fillRect(x - 5 * s, y - 34 * s, 10 * s, 34 * s);
    ctx.strokeStyle = '#333'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(x, y - 34 * s); ctx.lineTo(x, y - 39 * s); ctx.stroke();
    if (lit) flame(ctx, x, y - 38 * s, s, t);
    else if (smoke > 0) {
      ctx.strokeStyle = 'rgba(200,200,200,' + (0.5 * smoke) + ')'; ctx.lineWidth = 1.5;
      ctx.beginPath();
      for (var i = 0; i <= 12; i++) { var yy = y - 39 * s - i * 3 * s, xx = x + Math.sin(i * 0.8 + t * 3) * 3 * s; if (i) ctx.lineTo(xx, yy); else ctx.moveTo(xx, yy); }
      ctx.stroke();
    }
  }
  function mouse(ctx, x, y, s, alive, t) {
    var bob = alive ? Math.sin(t * 6) * 0.8 * s : 0;
    ctx.save(); ctx.translate(x, y + bob);
    if (!alive) { ctx.translate(0, -2 * s); }
    ctx.fillStyle = alive ? '#c9ccd3' : '#8a8d94';
    // 身体
    ctx.beginPath(); ctx.ellipse(0, -9 * s, 15 * s, alive ? 9 * s : 6 * s, 0, 0, 7); ctx.fill();
    // 头
    ctx.beginPath(); ctx.ellipse(14 * s, alive ? -12 * s : -7 * s, 7 * s, 5.5 * s, alive ? -0.3 : 0.1, 0, 7); ctx.fill();
    // 耳朵
    ctx.fillStyle = alive ? '#f0a8b8' : '#9a7c84';
    ctx.beginPath(); ctx.arc(11 * s, alive ? -18 * s : -12 * s, 3.4 * s, 0, 7); ctx.fill();
    // 眼
    ctx.strokeStyle = '#111'; ctx.fillStyle = '#111'; ctx.lineWidth = 1.2;
    if (alive) { ctx.beginPath(); ctx.arc(17 * s, -13 * s, 1.3 * s, 0, 7); ctx.fill(); }
    else { ctx.beginPath(); ctx.moveTo(15.5 * s, -9 * s); ctx.lineTo(18.5 * s, -6 * s); ctx.moveTo(18.5 * s, -9 * s); ctx.lineTo(15.5 * s, -6 * s); ctx.stroke(); }
    // 尾巴
    ctx.strokeStyle = alive ? '#d9a3b0' : '#8a7c80'; ctx.lineWidth = 1.5 * s;
    ctx.beginPath(); ctx.moveTo(-15 * s, -8 * s); ctx.quadraticCurveTo(-26 * s, -14 * s + (alive ? Math.sin(t * 4) * 3 * s : 0), -30 * s, -4 * s); ctx.stroke();
    // 脚
    if (alive) { ctx.fillStyle = '#c9ccd3'; [-8, 6].forEach(function (fx) { ctx.fillRect(fx * s, -2 * s, 3 * s, 2 * s); }); }
    ctx.restore();
  }

  // ---------- 通用曲线坐标系 ----------
  // box：区域；o：{ x0,x1,y0,y1, xTicks, yTicks, xName, yName, title }
  function axes(ctx, box, o) {
    var L = box.x + 46, R = box.x + box.w - 14, T = box.y + 24, B = box.y + box.h - 30;
    var sx = function (v) { return L + (v - o.x0) / (o.x1 - o.x0) * (R - L); };
    var sy = function (v) { return B - (v - o.y0) / (o.y1 - o.y0) * (B - T); };
    ctx.fillStyle = 'rgba(17,23,35,.55)'; rrect(ctx, box.x + 4, box.y, box.w - 8, box.h, 10); ctx.fill();
    ctx.font = font(11); ctx.textBaseline = 'top'; ctx.textAlign = 'center';
    (o.xTicks || []).forEach(function (v) {
      var x = sx(v);
      ctx.strokeStyle = GRID; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(x, T); ctx.lineTo(x, B); ctx.stroke();
      ctx.fillStyle = MUTED; ctx.fillText(o.xFmt ? o.xFmt(v) : String(v), x, B + 4);
    });
    ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
    (o.yTicks || []).forEach(function (v) {
      var y = sy(v);
      ctx.strokeStyle = GRID; ctx.beginPath(); ctx.moveTo(L, y); ctx.lineTo(R, y); ctx.stroke();
      ctx.fillStyle = MUTED; ctx.fillText(String(v), L - 5, y);
    });
    ctx.strokeStyle = LINE; ctx.lineWidth = 1.2;
    ctx.beginPath(); ctx.moveTo(L, T - 4); ctx.lineTo(L, B); ctx.lineTo(R + 4, B); ctx.stroke();
    if (o.title) label(ctx, o.title, L, box.y + 11, { align: 'left', size: 12, bold: true, color: o.titleColor || TEXT });
    if (o.yName) label(ctx, o.yName, R, box.y + 11, { align: 'right', size: 11, color: MUTED });
    if (o.xName) label(ctx, o.xName, R, B + 21, { align: 'right', size: 11, color: MUTED });
    return { L: L, R: R, T: T, B: B, sx: sx, sy: sy };
  }

  // ---------- 视图 ----------
  function View(canvas) {
    var ctx = canvas.getContext('2d'), W = 0, H = 0, dpr = 1, narrow = false, geo = {};
    function resize(w, h) {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      W = w; H = h; narrow = w < 640;
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
      canvas.style.width = w + 'px'; canvas.style.height = h + 'px';
    }
    function begin() {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, W, H);
      ctx.fillStyle = '#05070d'; ctx.fillRect(0, 0, W, H);
    }
    // 把区域切成“装置 + 图像”：宽屏左右、窄屏上下
    function split(fracA) {
      var top = narrow ? TOP + 40 : TOP, h = H - top - BOTTOM;
      if (narrow) {
        var ha = Math.round(h * fracA);
        return { a: { x: 6, y: top, w: W - 12, h: ha }, b: { x: 6, y: top + ha + 6, w: W - 12, h: h - ha - 6 } };
      }
      var wa = Math.round(W * fracA);
      return { a: { x: 10, y: top, w: wa - 10, h: h }, b: { x: wa + 6, y: top, w: W - wa - 16, h: h } };
    }

    // ===== 场景一：金鱼藻气泡 =====
    var BX = 500;                 // 金鱼藻（漏斗）中心的虚拟 x
    var CM = 5.8;                 // 灯距 1 cm 对应的虚拟长度
    var TABLE = 392, BEAK = { x0: 452, x1: 548, top: 168 }, WATER_Y = 190;
    var TUBE = { x0: 487, x1: 513, top: 52, mouth: 262 };
    function drawBubble(s) {
      begin();
      var sp = split(narrow ? 0.54 : 0.56), f = fit(sp.a, 580, 430), k = f.k;
      geo = { scene: 'bubble', f: f };
      ctx.save(); ctx.translate(f.ox, f.oy); ctx.scale(k, k);
      var L = P.lightOf(s.d, s.lamp), lampX = BX - s.d * CM;
      // 桌面、刻度尺
      ctx.fillStyle = '#1b2433'; ctx.fillRect(0, TABLE, 580, 8);
      var rY = TABLE + 14;
      ctx.strokeStyle = LINE; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(BX - 80 * CM, rY); ctx.lineTo(BX, rY); ctx.stroke();
      ctx.font = font(10); ctx.textAlign = 'center'; ctx.textBaseline = 'top'; ctx.fillStyle = MUTED;
      for (var c = 0; c <= 80; c += 5) {
        var x = BX - c * CM;
        ctx.beginPath(); ctx.moveTo(x, rY); ctx.lineTo(x, rY + (c % 10 ? 4 : 7)); ctx.stroke();
        if (c % 10 === 0 && c > 0) ctx.fillText(c, x, rY + 9);
      }
      ctx.fillText('cm', BX + 12, rY + 9);
      // 灯到金鱼藻的距离
      ctx.strokeStyle = GOLD; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(lampX, rY - 3); ctx.lineTo(BX, rY - 3); ctx.stroke();
      // 光束
      if (L > 0) {
        var a = Math.min(0.5, 0.1 + 0.32 * P.sat(L, 1.2));
        var g = ctx.createLinearGradient(lampX, 0, BX + 50, 0);
        g.addColorStop(0, 'rgba(255,230,140,' + a + ')'); g.addColorStop(1, 'rgba(255,230,140,' + (a * 0.25) + ')');
        ctx.fillStyle = g;
        ctx.beginPath(); ctx.moveTo(lampX + 18, 274); ctx.lineTo(lampX + 18, 302); ctx.lineTo(BX + 50, 380); ctx.lineTo(BX + 50, 200); ctx.closePath(); ctx.fill();
      }
      // 台灯：底座、立杆、灯罩朝右
      ctx.fillStyle = '#4a5568'; ctx.fillRect(lampX - 22, TABLE - 6, 44, 6);
      ctx.strokeStyle = '#6b7a90'; ctx.lineWidth = 4;
      ctx.beginPath(); ctx.moveTo(lampX - 10, TABLE - 6); ctx.lineTo(lampX - 10, 288); ctx.stroke();
      ctx.fillStyle = s.lamp ? '#d9a93a' : '#6b5a2f';
      ctx.beginPath(); ctx.moveTo(lampX - 14, 270); ctx.lineTo(lampX + 8, 262); ctx.lineTo(lampX + 18, 274); ctx.lineTo(lampX + 18, 302); ctx.lineTo(lampX + 8, 314); ctx.lineTo(lampX - 14, 306); ctx.closePath(); ctx.fill();
      if (s.lamp) {
        var bg = ctx.createRadialGradient(lampX + 18, 288, 0, lampX + 18, 288, 30);
        bg.addColorStop(0, 'rgba(255,245,200,.95)'); bg.addColorStop(1, 'rgba(255,245,200,0)');
        ctx.fillStyle = bg; ctx.beginPath(); ctx.arc(lampX + 18, 288, 30, 0, 7); ctx.fill();
      }
      geo.lamp = { x: f.ox + lampX * k, y: f.oy + 288 * k, r: 34 * k, x0: f.ox + (BX - 80 * CM) * k, cm: CM * k, bx: f.ox + BX * k };
      if (s.dragging || s.hoverLamp) label(ctx, '灯距 ' + fmt(s.d) + ' cm', lampX, 244, { color: GOLD, size: 13, bold: true });
      else label(ctx, '拖动台灯 ↔', lampX, 248, { color: MUTED, size: 11 });
      // 烧杯与水
      ctx.fillStyle = WATER; if (s.c > 0) ctx.fillStyle = 'rgba(120,190,255,' + (0.16 + s.c * 0.04) + ')';
      ctx.fillRect(BEAK.x0 + 2, WATER_Y, BEAK.x1 - BEAK.x0 - 4, TABLE - WATER_Y - 2);
      ctx.strokeStyle = GLASS; ctx.lineWidth = 2.2;
      ctx.beginPath(); ctx.moveTo(BEAK.x0 - 4, BEAK.top); ctx.lineTo(BEAK.x0, BEAK.top + 4); ctx.lineTo(BEAK.x0, TABLE); ctx.lineTo(BEAK.x1, TABLE); ctx.lineTo(BEAK.x1, BEAK.top); ctx.stroke();
      ctx.strokeStyle = 'rgba(160,200,255,.6)'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(BEAK.x0 + 2, WATER_Y); ctx.lineTo(BEAK.x1 - 2, WATER_Y); ctx.stroke();
      // 金鱼藻
      var sway = Math.sin(s.time * 1.3) * 1.5;
      hornwort(ctx, BX - 14, 384, 312, -6, sway); hornwort(ctx, BX, 386, 300, 2, -sway * 0.7); hornwort(ctx, BX + 13, 384, 314, 7, sway * 0.8);
      // 倒置的漏斗
      ctx.strokeStyle = GLASS; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(BEAK.x0 + 8, 372); ctx.lineTo(BX - 6, 290); ctx.lineTo(BX - 6, 246);
      ctx.moveTo(BEAK.x1 - 8, 372); ctx.lineTo(BX + 6, 290); ctx.lineTo(BX + 6, 246); ctx.stroke();
      // 倒扣的试管：上部收集的气体
      var gasH = Math.min(1, s.gas) * (TUBE.mouth - TUBE.top - 40);
      ctx.fillStyle = 'rgba(120,190,255,.28)';
      ctx.fillRect(TUBE.x0 + 2, TUBE.top + 6 + gasH, TUBE.x1 - TUBE.x0 - 4, TUBE.mouth - TUBE.top - 6 - gasH);
      if (gasH > 1) { ctx.fillStyle = 'rgba(79,195,247,.12)'; ctx.fillRect(TUBE.x0 + 2, TUBE.top + 6, TUBE.x1 - TUBE.x0 - 4, gasH); }
      ctx.strokeStyle = 'rgba(160,200,255,.7)'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(TUBE.x0 + 2, TUBE.top + 6 + gasH); ctx.lineTo(TUBE.x1 - 2, TUBE.top + 6 + gasH); ctx.stroke();
      ctx.strokeStyle = GLASS; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(TUBE.x0, TUBE.mouth); ctx.lineTo(TUBE.x0, TUBE.top + 13); ctx.arc(BX, TUBE.top + 13, 13, Math.PI, 0); ctx.lineTo(TUBE.x1, TUBE.mouth); ctx.stroke();
      if (gasH > 14) label(ctx, 'O₂', BX, TUBE.top + 6 + gasH / 2 + 2, { color: O2C, size: 11, bold: true });
      // 气泡：x、y 为虚拟坐标
      s.bubbles.forEach(function (b) {
        ctx.strokeStyle = 'rgba(220,240,255,.9)'; ctx.fillStyle = 'rgba(200,235,255,.25)'; ctx.lineWidth = 1;
        ctx.beginPath(); ctx.arc(b.x, b.y, b.r, 0, 7); ctx.fill(); ctx.stroke();
      });
      // 带火星的木条检验
      if (s.test > 0) {
        var ty = TUBE.top - 4, tx = BX;
        ctx.strokeStyle = '#a07040'; ctx.lineWidth = 4; ctx.beginPath(); ctx.moveTo(tx + 70, ty - 46); ctx.lineTo(tx + 4, ty - 6); ctx.stroke();
        if (s.testOk) flame(ctx, tx + 2, ty - 4, 1.1, s.time);
        else { ctx.fillStyle = '#ff5a2a'; ctx.beginPath(); ctx.arc(tx + 4, ty - 6, 3, 0, 7); ctx.fill(); }
        label(ctx, s.testOk ? '复燃！是氧气' : '气体太少，看不出', tx - 30, ty - 30, { color: s.testOk ? GOLD : MUTED, size: 12, bold: true, align: 'right' });
      }
      // 温度计
      var thX = BEAK.x1 - 10, thTop = 120, thBot = 372, tf = (s.T - 0) / 50;
      ctx.fillStyle = 'rgba(230,235,242,.12)'; rrect(ctx, thX - 4, thTop, 8, thBot - thTop, 4); ctx.fill();
      ctx.strokeStyle = 'rgba(230,235,242,.5)'; ctx.lineWidth = 1; rrect(ctx, thX - 4, thTop, 8, thBot - thTop, 4); ctx.stroke();
      ctx.fillStyle = '#ff5a5a'; ctx.beginPath(); ctx.arc(thX, thBot, 6, 0, 7); ctx.fill();
      ctx.fillRect(thX - 1.6, thBot - (thBot - thTop - 10) * tf, 3.2, (thBot - thTop - 10) * tf);
      label(ctx, fmt(s.T) + ' °C', thX + 2, thTop - 12, { size: 12, color: '#ff9a8a', bold: true });
      label(ctx, s.c > 0 ? (+s.c) + '% NaHCO₃ 溶液' : '清水', BEAK.x0 - 6, WATER_Y + 12, { size: 11, color: '#9cc8ff', align: 'right' });
      ctx.restore();

      // 计数牌（装置区左上）
      var cb = { x: sp.a.x + 8, y: sp.a.y + 4 }, cw = 150;
      ctx.fillStyle = 'rgba(17,23,35,.85)'; rrect(ctx, cb.x, cb.y, cw, 62, 10); ctx.fill();
      ctx.strokeStyle = 'rgba(42,52,70,1)'; ctx.lineWidth = 1; rrect(ctx, cb.x, cb.y, cw, 62, 10); ctx.stroke();
      var sec = s.minT * 60;
      label(ctx, '计时 0:' + (sec < 10 ? '0' : '') + Math.floor(sec), cb.x + 10, cb.y + 14, { align: 'left', size: 12, color: MUTED });
      label(ctx, '本分钟', cb.x + 10, cb.y + 38, { align: 'left', size: 12, color: MUTED });
      label(ctx, String(s.count), cb.x + 62, cb.y + 38, { align: 'left', size: 24, bold: true, color: TEXT });
      label(ctx, '个', cb.x + 62 + ctx.measureText(String(s.count)).width + 4, cb.y + 40, { align: 'left', size: 12, color: MUTED });
      label(ctx, s.last == null ? '' : '上一分钟 ' + s.last, cb.x + cw - 8, cb.y + 14, { align: 'right', size: 11, color: GOLD });

      // ---- 曲线 ----
      var V = P.VARS[s.xv], other = { light: s.d, co2: s.c, temp: s.T };
      var ax = axes(ctx, sp.b, {
        x0: V.lo, x1: V.hi, y0: 0, y1: 60,
        xTicks: s.xv === 'light' ? [10, 20, 30, 40, 50, 60, 70, 80] : s.xv === 'co2' ? [0, 0.5, 1, 1.5, 2] : [5, 15, 25, 35, 45],
        yTicks: [0, 10, 20, 30, 40, 50, 60],
        title: '每分钟气泡数 — ' + V.name, yName: '个/分钟', xName: V.name + ' / ' + V.unit + (s.xv === 'light' ? '（越近光越强）' : '')
      });
      geo.plot = ax;
      function rateAt(v) {
        var d = s.xv === 'light' ? v : s.d, c = s.xv === 'co2' ? v : s.c, T = s.xv === 'temp' ? v : s.T;
        return P.bubRate(d, c, T, s.lamp);
      }
      // 理论曲线（另外两个条件取当前值）
      if (s.theory) {
        ctx.strokeStyle = 'rgba(141,153,171,.75)'; ctx.lineWidth = 1.5; ctx.setLineDash([5, 4]);
        ctx.beginPath();
        for (var i = 0; i <= 120; i++) {
          var v = V.lo + (V.hi - V.lo) * i / 120, yy = ax.sy(Math.min(60, rateAt(v)));
          if (i) ctx.lineTo(ax.sx(v), yy); else ctx.moveTo(ax.sx(v), yy);
        }
        ctx.stroke(); ctx.setLineDash([]);
      }
      // 记录的点：只画另外两个条件与当前相同的那一组（控制变量）
      var pts = s.points.filter(function (p) { return p.xv === s.xv && p.match; }).sort(function (a, b) { return a.x - b.x; });
      if (pts.length > 1) {
        ctx.strokeStyle = GOLD; ctx.lineWidth = 2; ctx.beginPath();
        pts.forEach(function (p, i) { var px = ax.sx(p.x), py = ax.sy(Math.min(60, p.n)); if (i) ctx.lineTo(px, py); else ctx.moveTo(px, py); });
        ctx.stroke();
      }
      pts.forEach(function (p) {
        ctx.fillStyle = GOLD; ctx.beginPath(); ctx.arc(ax.sx(p.x), ax.sy(Math.min(60, p.n)), 4.5, 0, 7); ctx.fill();
      });
      var hidden = s.points.length - pts.length;
      // 当前位置
      var cx0 = ax.sx(other[s.xv]), cr = rateAt(other[s.xv]);
      ctx.strokeStyle = 'rgba(79,195,247,.5)'; ctx.lineWidth = 1; ctx.setLineDash([3, 3]);
      ctx.beginPath(); ctx.moveTo(cx0, ax.T); ctx.lineTo(cx0, ax.B); ctx.stroke(); ctx.setLineDash([]);
      ctx.fillStyle = O2C; ctx.beginPath(); ctx.arc(cx0, ax.sy(Math.min(60, cr)), 4, 0, 7); ctx.fill();
      var note = pts.length ? '已记录 ' + pts.length + ' 个点' + (hidden ? '（另有 ' + hidden + ' 个点条件不同，未显示）' : '') : '每数满 1 分钟自动描一个点';
      label(ctx, note, ax.L + 6, ax.T + 8, { align: 'left', size: 11, color: MUTED });
      if (s.xv === 'temp' && s.theory) label(ctx, '最适温度', ax.sx(P.T_OPT), ax.sy(Math.min(60, rateAt(P.T_OPT))) - 14, { size: 11, color: MUTED });
    }

    // ===== 场景二：一昼夜 =====
    function drawDay(s) {
      begin();
      var sp = split(narrow ? 0.4 : 0.44), A = sp.a, ser = s.series, cur = P.sampleAt(ser, s.t);
      geo = { scene: 'daynight' };
      // ---- 左：天空、钟罩、植物 ----
      var f = fit(A, 300, 330), k = f.k;
      ctx.save(); ctx.translate(f.ox, f.oy); ctx.scale(k, k);
      var day = cur.L > 0, lt = Math.min(1, cur.L / 2);
      var sky = ctx.createLinearGradient(0, 0, 0, 250);
      sky.addColorStop(0, 'rgb(' + Math.round(10 + 40 * lt) + ',' + Math.round(14 + 80 * lt) + ',' + Math.round(34 + 120 * lt) + ')');
      sky.addColorStop(1, 'rgb(' + Math.round(18 + 70 * lt) + ',' + Math.round(24 + 100 * lt) + ',' + Math.round(48 + 110 * lt) + ')');
      ctx.fillStyle = sky; rrect(ctx, 0, 0, 300, 250, 12); ctx.fill();
      // 太阳 / 月亮沿弧线运动
      var ang, isSun = s.t > P.DAY.RISE && s.t < P.DAY.SET;
      if (isSun) ang = Math.PI * (s.t - P.DAY.RISE) / (P.DAY.SET - P.DAY.RISE);
      else ang = Math.PI * (((s.t - P.DAY.SET) + 24) % 24) / 12;
      var bx = 150 - Math.cos(ang) * 125, by = 236 - Math.sin(ang) * 190;
      if (isSun) {
        var sg = ctx.createRadialGradient(bx, by, 0, bx, by, 34);
        sg.addColorStop(0, s.weather === 'cloudy' ? 'rgba(255,230,160,.5)' : 'rgba(255,230,120,.9)'); sg.addColorStop(1, 'rgba(255,230,120,0)');
        ctx.fillStyle = sg; ctx.beginPath(); ctx.arc(bx, by, 34, 0, 7); ctx.fill();
        ctx.fillStyle = s.weather === 'cloudy' ? '#d8c890' : '#ffd84a'; ctx.beginPath(); ctx.arc(bx, by, 13, 0, 7); ctx.fill();
      } else {
        ctx.fillStyle = '#dfe6f0'; ctx.beginPath(); ctx.arc(bx, by, 10, 0, 7); ctx.fill();
        ctx.fillStyle = sky; ctx.beginPath(); ctx.arc(bx + 5, by - 3, 9, 0, 7); ctx.fill();
        ctx.fillStyle = 'rgba(255,255,255,.6)';
        [[30, 30], [80, 60], [230, 40], [260, 90], [190, 20], [120, 26]].forEach(function (p) { ctx.fillRect(p[0], p[1], 1.6, 1.6); });
      }
      if (s.weather === 'cloudy') {
        ctx.fillStyle = day ? 'rgba(200,208,220,.75)' : 'rgba(90,100,120,.6)';
        [[70, 52], [190, 40], [250, 70]].forEach(function (c) {
          ctx.beginPath(); ctx.arc(c[0], c[1], 16, 0, 7); ctx.arc(c[0] + 18, c[1] - 6, 20, 0, 7); ctx.arc(c[0] + 38, c[1], 15, 0, 7); ctx.fill();
        });
      }
      // 地面
      ctx.fillStyle = '#1b2433'; ctx.fillRect(0, 246, 300, 8);
      label(ctx, hm(s.t), 16, 18, { align: 'left', size: 16, bold: true });
      label(ctx, (s.weather === 'cloudy' ? '阴天 ' : '晴天 ') + fmt(cur.T) + ' °C', 16, 38, { align: 'left', size: 11, color: MUTED });
      // 钟罩 + 植物
      bellJar(ctx, 150, 246, 120, 170, 'rgba(255,154,98,' + Math.min(0.22, cur.C / 3000) + ')');
      pottedPlant(ctx, 150, 245, 1.25, !day);
      label(ctx, '罩内 CO₂ ' + fmt(cur.C) + ' ppm', 150, 64, { size: 12, color: CO2C, bold: true });
      // 气体进出箭头：粗细与净速率成正比
      var net = cur.P - cur.R, mag = Math.min(1, Math.abs(net) / 40), w = 2 + mag * 5;
      var inCO2 = net > 0;
      // CO₂ 在左侧，O₂ 在右侧；白天净吸收 CO₂、净放出 O₂，夜里反过来
      if (Math.abs(net) > 0.3) {
        if (inCO2) arrow(ctx, 96, 150, 128, 168, 9 + mag * 4, CO2C, w); else arrow(ctx, 128, 168, 96, 150, 9 + mag * 4, CO2C, w);
        if (inCO2) arrow(ctx, 172, 168, 204, 150, 9 + mag * 4, O2C, w); else arrow(ctx, 204, 150, 172, 168, 9 + mag * 4, O2C, w);
        label(ctx, 'CO₂', 100, 136, { color: CO2C, size: 12, bold: true });
        label(ctx, 'O₂', 202, 136, { color: O2C, size: 12, bold: true });
      }
      ctx.restore();
      // 状态与反应式（左区下方）
      var eqY = f.oy + 262 * k, eqX = A.x + A.w / 2, fs = Math.max(10, Math.min(13, 12 * k));
      var st = cur.P < 0.3 ? '只进行呼吸作用（无光）' : net > 0.3 ? '光合作用 > 呼吸作用' : net < -0.3 ? '光合作用 < 呼吸作用' : '光合作用 = 呼吸作用';
      label(ctx, st, eqX, eqY + 6, { size: fs + 2, bold: true, color: cur.P < 0.3 ? RES : net > 0.3 ? PHO : GOLD });
      ctx.globalAlpha = cur.P > 0.3 ? 1 : 0.35;
      label(ctx, '光合：二氧化碳 + 水 → 有机物 + 氧气（光，叶绿体）', eqX, eqY + 28, { size: fs, color: PHO });
      ctx.globalAlpha = 1;
      label(ctx, '呼吸：有机物 + 氧气 → 二氧化碳 + 水 + 能量（线粒体）', eqX, eqY + 46, { size: fs, color: RES });

      // ---- 右：两张图 ----
      var B = sp.b, h1 = Math.round(B.h * 0.5);
      var box1 = { x: B.x, y: B.y, w: B.w, h: h1 - 4 }, box2 = { x: B.x, y: B.y + h1 + 4, w: B.w, h: B.h - h1 - 4 };
      var xt = [0, 6, 12, 18, 24], xf = function (v) { return v + '时'; };
      var pMax = 60;
      var a1 = axes(ctx, box1, { x0: 0, x1: 24, y0: 0, y1: pMax, xTicks: xt, xFmt: xf, yTicks: [0, 20, 40, 60], title: '光合作用与呼吸作用的速率', yName: 'ppm/时' });
      var Cmax = 600;
      var a2 = axes(ctx, box2, { x0: 0, x1: 24, y0: 0, y1: Cmax, xTicks: xt, xFmt: xf, yTicks: [0, 200, 400, 600], title: '密闭玻璃罩内 CO₂ 浓度', titleColor: CO2C, yName: 'ppm' });
      geo.plots = [a1, a2];
      // 夜间阴影
      [a1, a2].forEach(function (a) {
        ctx.fillStyle = 'rgba(0,0,0,.28)';
        ctx.fillRect(a.sx(0), a.T, a.sx(P.DAY.RISE) - a.sx(0), a.B - a.T);
        ctx.fillRect(a.sx(P.DAY.SET), a.T, a.sx(24) - a.sx(P.DAY.SET), a.B - a.T);
      });
      function line(a, key, color, width, upto, dash, maxV) {
        ctx.strokeStyle = color; ctx.lineWidth = width; ctx.setLineDash(dash || []);
        ctx.beginPath();
        var first = true;
        for (var i = 0; i < ser.length; i++) {
          var p = ser[i];
          if (p.t > upto + 1e-9) break;
          var x = a.sx(p.t), y = a.sy(Math.min(maxV, p[key]));
          if (first) { ctx.moveTo(x, y); first = false; } else ctx.lineTo(x, y);
        }
        ctx.stroke(); ctx.setLineDash([]);
      }
      // 未走到的部分画成淡色（全天预览）
      ctx.globalAlpha = 0.22;
      line(a1, 'P', PHO, 1.5, 24, null, pMax); line(a1, 'R', RES, 1.5, 24, null, pMax); line(a2, 'C', CO2C, 1.5, 24, null, Cmax);
      ctx.globalAlpha = 1;
      line(a1, 'P', PHO, 2.4, s.t, null, pMax); line(a1, 'R', RES, 2.4, s.t, null, pMax); line(a2, 'C', CO2C, 2.4, s.t, null, Cmax);
      // 0 时浓度的参考线
      ctx.strokeStyle = 'rgba(255,154,98,.45)'; ctx.setLineDash([4, 4]); ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(a2.sx(0), a2.sy(ser[0].C)); ctx.lineTo(a2.sx(24), a2.sy(ser[0].C)); ctx.stroke(); ctx.setLineDash([]);
      // 图例
      label(ctx, '— 光合', a1.R - 64, a1.T + 8, { color: PHO, size: 11, align: 'right' });
      label(ctx, '— 呼吸', a1.R - 6, a1.T + 8, { color: RES, size: 11, align: 'right' });
      // 关键点：光合 = 呼吸
      s.keys.forEach(function (kp, i) {
        if (kp.t > s.t) return;
        var x = a1.sx(kp.t), pr = P.sampleAt(ser, kp.t);
        ctx.fillStyle = GOLD;
        ctx.beginPath(); ctx.arc(x, a1.sy(pr.P), 4, 0, 7); ctx.fill();
        ctx.beginPath(); ctx.arc(x, a2.sy(kp.C), 4.5, 0, 7); ctx.fill();
        ctx.strokeStyle = 'rgba(255,201,74,.45)'; ctx.setLineDash([3, 3]); ctx.lineWidth = 1;
        ctx.beginPath(); ctx.moveTo(x, a1.sy(pr.P)); ctx.lineTo(x, a2.sy(kp.C)); ctx.stroke(); ctx.setLineDash([]);
        var right = i === 0;
        label(ctx, (kp.up ? '最高 ' : '最低 ') + fmt(kp.C) + '（' + hm(kp.t) + '）', x + (right ? 8 : -8), a2.sy(kp.C) + (kp.up ? -12 : 13), { color: GOLD, size: 11, align: right ? 'left' : 'right' });
        label(ctx, '光合 = 呼吸', x + (right ? 6 : -6), a1.sy(pr.P) - 11, { color: GOLD, size: 11, align: right ? 'left' : 'right' });
      });
      if (s.t >= 24 - 1e-6) {
        var end = ser[ser.length - 1].C;
        label(ctx, '24 时 ' + fmt(end) + (end < ser[0].C ? ' < 0 时 → 有机物有积累' : ' ≥ 0 时 → 没有积累'), a2.R - 4, a2.T + 8, { color: GOLD, size: 11, align: 'right' });
      }
      // 时间指针
      [a1, a2].forEach(function (a) {
        var x = a.sx(s.t);
        ctx.strokeStyle = 'rgba(230,235,242,.55)'; ctx.lineWidth = 1;
        ctx.beginPath(); ctx.moveTo(x, a.T - 4); ctx.lineTo(x, a.B); ctx.stroke();
      });
      ctx.fillStyle = PHO; ctx.beginPath(); ctx.arc(a1.sx(s.t), a1.sy(Math.min(pMax, cur.P)), 3.5, 0, 7); ctx.fill();
      ctx.fillStyle = RES; ctx.beginPath(); ctx.arc(a1.sx(s.t), a1.sy(Math.min(pMax, cur.R)), 3.5, 0, 7); ctx.fill();
      ctx.fillStyle = CO2C; ctx.beginPath(); ctx.arc(a2.sx(s.t), a2.sy(Math.min(Cmax, cur.C)), 4, 0, 7); ctx.fill();
    }

    // ===== 场景三：普利斯特利钟罩 =====
    var JAR_NAMES = { candle: '蜡烛', mouse: '小鼠' };
    function drawJar(s) {
      begin();
      var top = narrow ? TOP + 40 : TOP + 6, area = { x: 8, y: top, w: W - 16, h: H - top - BOTTOM };
      // 四个钟罩作为一个整体等比缩放、居中（宽屏横排一行放得更大时就排成一行）
      var c4 = Math.min(area.w / (4 * 224), area.h / 254), c2 = Math.min(area.w / (2 * 224), area.h / (2 * 254));
      var cols = c4 > c2 ? 4 : 2, rows = 4 / cols, f = fit(area, cols * 224, rows * 254), k = f.k;
      geo = { scene: 'jar' };
      s.jars.forEach(function (j, i) {
        ctx.save(); ctx.translate(f.ox + ((i % cols) * 224 + 2) * k, f.oy + (Math.floor(i / cols) * 254 + 2) * k); ctx.scale(k, k);
        // 背景：光照 / 黑暗
        ctx.fillStyle = s.light ? 'rgba(255,230,140,.07)' : 'rgba(0,0,0,.35)';
        rrect(ctx, 2, 2, 216, 246, 12); ctx.fill();
        ctx.strokeStyle = '#2a3446'; ctx.lineWidth = 1; rrect(ctx, 2, 2, 216, 246, 12); ctx.stroke();
        label(ctx, '①②③④'[i] + ' ' + JAR_NAMES[j.who] + (j.plant ? ' + 绿色植物' : ''), 12, 18, { align: 'left', size: 13, bold: true });
        label(ctx, s.light ? '☀ 光照' : '☾ 黑暗', 208, 18, { align: 'right', size: 11, color: s.light ? GOLD : MUTED });
        var jx = j.plant ? 118 : 110, base = 196;
        bellJar(ctx, jx, base, 128, 150, 'rgba(255,154,98,' + Math.min(0.12, j.co2 / 50) + ')');
        if (j.plant) pottedPlant(ctx, jx + 30, base, 0.95, !s.light);
        var ox = j.plant ? jx - 26 : jx;
        if (j.who === 'candle') candle(ctx, ox, base, 1, j.alive, s.time + i, j.alive ? 0 : Math.max(0, 1 - (j.t - j.tEnd) / 4));
        else mouse(ctx, ox - 4, base, 0.95, j.alive, s.time + i);
        // O₂ 条：0～21%，标出熄灭 / 死亡阈值
        var gx = 20, gy = 218, gw = 180, gh = 8, fr = Math.max(0, Math.min(1, j.o2 / 21));
        ctx.fillStyle = 'rgba(141,153,171,.18)'; rrect(ctx, gx, gy, gw, gh, 4); ctx.fill();
        ctx.fillStyle = j.alive ? O2C : '#5d7f90'; rrect(ctx, gx, gy, Math.max(4, gw * fr), gh, 4); ctx.fill();
        var tx = gx + gw * P.JAR.OUT[j.who] / 21;
        ctx.strokeStyle = RES; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(tx, gy - 3); ctx.lineTo(tx, gy + gh + 3); ctx.stroke();
        label(ctx, 'O₂ ' + fmt(j.o2, 1) + '%', gx, gy + 20, { align: 'left', size: 11, color: O2C });
        var msg = j.who === 'candle'
          ? (j.alive ? '燃烧中' : '熄灭（第 ' + fmt(j.tEnd, 1) + ' 分钟）')
          : (j.alive ? '正常活着' : '死亡（第 ' + fmt(j.tEnd, 1) + ' 分钟）');
        label(ctx, msg, gx + gw, gy + 20, { align: 'right', size: 12, bold: true, color: j.alive ? PHO : RES });
        label(ctx, 'CO₂ ' + fmt(j.co2, 2) + '%', 12, 38, { align: 'left', size: 11, color: CO2C });
        ctx.restore();
      });
      label(ctx, '第 ' + fmt(s.jars[0].t, 1) + ' 分钟（时间为示意）', W / 2, f.oy + rows * 254 * k + 4, { size: 11, color: MUTED });
    }

    return {
      resize: resize, drawBubble: drawBubble, drawDay: drawDay, drawJar: drawJar,
      geo: function () { return geo; }, narrow: function () { return narrow; },
      // 气泡装置的虚拟坐标常量（main.js 生成、移动气泡用）
      BUB_GEO: { BX: BX, TUBE: TUBE, WATER_Y: WATER_Y }
    };
  }

  window.PhotoDraw = { View: View, hm: hm };
})();
