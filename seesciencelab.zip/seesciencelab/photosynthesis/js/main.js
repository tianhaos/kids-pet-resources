(function () {
  var P = window.Photo, PD = window.PhotoDraw;
  var $ = function (id) { return document.getElementById(id); };
  var qa = function (sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); };
  var NAME = '光合作用与呼吸作用';

  var state = {
    scene: 'bubble', paused: false, time: 0,
    // 气泡计数：灯距 d（cm）、NaHCO₃ 浓度 c（%）、水温 T（°C）
    d: 20, c: 1, T: 25, lamp: true, xv: 'light', theory: true,
    points: [], count: 0, last: null, minT: 0, gas: 0, bubbles: [], test: 0, testOk: false, dragging: false, hoverLamp: false,
    // 一昼夜
    t: 0, weather: 'sunny', playing: true, series: null, keys: [],
    // 钟罩
    light: true, jars: [], jarRun: true
  };
  var HINTS = {
    bubble: '光照越强、CO₂ 越多、温度越适宜，金鱼藻放出的气泡越多（拖动台灯改变光照）',
    daynight: '白天光合作用强于呼吸作用，罩内 CO₂ 减少；夜里只有呼吸作用，CO₂ 增多',
    jar: '绿色植物在光下能更新被蜡烛燃烧或动物呼吸弄“坏”了的空气'
  };
  var MIN_SEC = 10;          // 气泡计数：1 分钟（模拟）= 10 秒（实际）
  var DAY_SPEED = 1.2;       // 一昼夜：每秒走 1.2 小时
  var JAR_SPEED = 1;         // 钟罩：每秒走 1 分钟（示意）
  var JAR_END = 60;

  var stage = $('stage'), panel = $('panel'), cv = $('view');
  var view = PD.View(cv), G = view.BUB_GEO;
  var em = P.Emitter(7);
  function setSeg(attr, val) { qa('[data-' + attr + ']').forEach(function (b) { b.classList.toggle('on', b.dataset[attr] === String(val)); }); }

  // ---------- 场景 ----------
  qa('[data-scene]').forEach(function (b) {
    b.addEventListener('click', function () { setScene(b.dataset.scene); Analytics.track(NAME, '场景', b.textContent); });
  });
  function setScene(sc) {
    state.scene = sc;
    if (sc === 'daynight' && !state.series) setWeather(state.weather);
    if (sc === 'jar' && !state.jars.length) resetJars();
    syncUI();
  }

  // ---------- 场景一：气泡计数 ----------
  function rate() { return P.bubRate(state.d, state.c, state.T, state.lamp); }
  function curOf(xv) { return xv === 'light' ? state.d : xv === 'co2' ? state.c : state.T; }
  // 条件改变：重新计时（这一分钟的气泡数不再代表新条件）
  function restartMinute() { state.count = 0; state.minT = 0; }
  function sameOthers(p) {
    return p.lamp === state.lamp &&
      (p.xv === 'light' || p.d === state.d) && (p.xv === 'co2' || p.c === state.c) && (p.xv === 'temp' || p.T === state.T);
  }
  function record(n) {
    var x = curOf(state.xv);
    // 同一条件下重复测量：用新的替换旧的
    state.points = state.points.filter(function (p) { return !(p.xv === state.xv && p.x === x && sameOthers(p)); });
    state.points.push({ xv: state.xv, x: x, n: n, d: state.d, c: state.c, T: state.T, lamp: state.lamp });
  }
  function setVar(key, v, track) {
    var old = curOf(key);
    if (key === 'light') state.d = v; else if (key === 'co2') state.c = v; else state.T = v;
    if (old !== v) restartMinute();
    if (state.xv !== key) { state.xv = key; syncUI(); }
    if (track) Analytics.track(NAME, '滑块', P.VARS[key].name + ' ' + v);
  }
  // 一键测一组：依次把横轴变量调到预设值，各数 1 分钟
  function sweep() {
    var V = P.VARS[state.xv], keep = curOf(state.xv);
    V.sweep.forEach(function (v, i) {
      setVarQuiet(state.xv, v);
      var e = P.Emitter(101 + i * 13), n = 0;
      for (var k = 0; k < 600; k++) n += e.step(rate(), 1 / 600);
      record(n);
    });
    setVarQuiet(state.xv, keep);
    restartMinute();
  }
  function setVarQuiet(key, v) { if (key === 'light') state.d = v; else if (key === 'co2') state.c = v; else state.T = v; }

  // 气泡在虚拟坐标里运动：从金鱼藻叶尖冒出，沿漏斗汇到中间，升进试管
  function halfW(y) {
    if (y > 290) return 6 + (y - 290) / (372 - 290) * 34;
    if (y > 246) return 5;
    return (G.TUBE.x1 - G.TUBE.x0) / 2 - 3;
  }
  function stepBubble(dt) {
    var dtMin = dt / MIN_SEC, n = em.step(rate(), dtMin);
    for (var i = 0; i < n; i++) {
      state.bubbles.push({ x: G.BX + (em.rnd() - 0.5) * 50, y: 300 + em.rnd() * 40, r: 2 + em.rnd() * 1.6, v: 55 + em.rnd() * 25, ph: em.rnd() * 6 });
      state.count++;
    }
    var surface = G.TUBE.top + 6 + Math.min(1, state.gas) * (G.TUBE.mouth - G.TUBE.top - 40);
    state.bubbles.forEach(function (b) {
      b.y -= b.v * dt;
      b.x += Math.sin(state.time * 5 + b.ph) * 6 * dt;
      var hw = halfW(b.y) - b.r;
      if (Math.abs(b.x - G.BX) > hw) b.x = G.BX + Math.sign(b.x - G.BX) * Math.max(0, hw);
      if (b.y - b.r <= surface) { b.dead = true; state.gas = Math.min(1, state.gas + 1 / 240); }
    });
    state.bubbles = state.bubbles.filter(function (b) { return !b.dead; });
    state.minT += dtMin;
    if (state.minT >= 1) {
      state.last = state.count;
      record(state.count);
      state.count = 0; state.minT -= 1;
    }
    if (state.test > 0) state.test = Math.max(0, state.test - dt);
  }

  // ---------- 场景二：一昼夜 ----------
  function setWeather(w) {
    state.weather = w === 'cloudy' ? 'cloudy' : 'sunny';
    state.series = P.simDay(state.weather);
    state.keys = P.dayKeys(state.series);
  }
  function stepDay(dt) {
    if (!state.playing) return;
    state.t = Math.min(24, state.t + dt * DAY_SPEED);
    if (state.t >= 24) { state.playing = false; syncUI(); }
  }

  // ---------- 场景三：钟罩 ----------
  function resetJars() {
    state.jars = [P.jarNew('candle', false), P.jarNew('candle', true), P.jarNew('mouse', false), P.jarNew('mouse', true)];
    state.jarRun = true;
  }
  function stepJar(dt) {
    if (!state.jarRun) return;
    var h = dt * JAR_SPEED, n = Math.max(1, Math.ceil(h / 0.02));
    for (var i = 0; i < n; i++) state.jars.forEach(function (j) { P.jarStep(j, state.light, h / n); });
    if (state.jars[0].t >= JAR_END) state.jarRun = false;
  }

  // ---------- 控件 ----------
  function bindSlider(id, key, fmt) {
    var el = $(id);
    el.addEventListener('input', function () { setVar(key, parseFloat(el.value)); });
    el.addEventListener('change', function () { Analytics.track(NAME, '滑块', P.VARS[key].name + ' ' + el.value); });
    return { el: el, key: key, fmt: fmt };
  }
  var sliders = [
    bindSlider('sD', 'light', function (v) { return v + ' cm'; }),
    bindSlider('sC', 'co2', function (v) { return v === 0 ? '清水' : v + '%'; }),
    bindSlider('sT', 'temp', function (v) { return v + ' °C'; })
  ];
  $('lamp').addEventListener('change', function () { state.lamp = $('lamp').checked; restartMinute(); Analytics.track(NAME, '开关', '台灯' + (state.lamp ? '开' : '关')); });
  $('theory').addEventListener('change', function () { state.theory = $('theory').checked; Analytics.track(NAME, '开关', '预测曲线' + (state.theory ? '开' : '关')); });
  qa('[data-xv]').forEach(function (b) { b.addEventListener('click', function () { state.xv = b.dataset.xv; restartMinute(); syncUI(); Analytics.track(NAME, '横轴', b.textContent); }); });
  $('sweep').addEventListener('click', function () { sweep(); Analytics.track(NAME, '快速测一组', P.VARS[state.xv].name); });
  $('clear').addEventListener('click', function () { state.points = []; restartMinute(); state.last = null; Analytics.track(NAME, '清空记录', ''); });
  $('testGas').addEventListener('click', function () { state.test = 3; state.testOk = state.gas >= 0.2; Analytics.track(NAME, '检验气体', state.testOk ? '复燃' : '太少'); });
  $('newTube').addEventListener('click', function () { state.gas = 0; state.test = 0; Analytics.track(NAME, '换试管', ''); });

  qa('[data-weather]').forEach(function (b) { b.addEventListener('click', function () { setWeather(b.dataset.weather); syncUI(); Analytics.track(NAME, '天气', b.textContent); }); });
  $('dayPlay').addEventListener('click', function () {
    if (state.t >= 24) state.t = 0;
    state.playing = !state.playing; syncUI();
    Analytics.track(NAME, '一昼夜', state.playing ? '播放' : '暂停');
  });
  $('dayRestart').addEventListener('click', function () { state.t = 0; state.playing = true; syncUI(); Analytics.track(NAME, '一昼夜', '从0时开始'); });
  var sTime = $('sTime');
  sTime.addEventListener('input', function () { state.t = parseFloat(sTime.value); state.playing = false; syncUI(); });
  sTime.addEventListener('change', function () { Analytics.track(NAME, '滑块', '时刻'); });

  qa('[data-light]').forEach(function (b) { b.addEventListener('click', function () { state.light = b.dataset.light === '1'; syncUI(); Analytics.track(NAME, '钟罩光照', b.textContent); }); });
  $('jarReset').addEventListener('click', function () { resetJars(); Analytics.track(NAME, '钟罩', '重新开始'); });
  qa('.pauseBtn').forEach(function (b) { b.addEventListener('click', function () { state.paused = !state.paused; syncUI(); }); });

  // ---------- 画布：拖台灯、拖时间 ----------
  function pos(e) { var r = cv.getBoundingClientRect(); return { x: e.clientX - r.left, y: e.clientY - r.top }; }
  function nearLamp(p) { var g = view.geo(); return g.scene === 'bubble' && g.lamp && Math.hypot(p.x - g.lamp.x, p.y - g.lamp.y) < Math.max(26, g.lamp.r); }
  function plotAt(p) {
    var g = view.geo();
    if (g.scene !== 'daynight' || !g.plots) return null;
    for (var i = 0; i < g.plots.length; i++) { var a = g.plots[i]; if (p.x >= a.L - 6 && p.x <= a.R + 6 && p.y >= a.T - 10 && p.y <= a.B + 10) return a; }
    return null;
  }
  var dragT = null;
  function dragLampTo(p) {
    var l = view.geo().lamp, d = Math.round(P.clamp((l.bx - p.x) / l.cm, 10, 80));
    setVar('light', d);
  }
  cv.addEventListener('pointerdown', function (e) {
    if (e.button !== 0) return;
    var p = pos(e);
    if (nearLamp(p)) { state.dragging = true; cv.setPointerCapture(e.pointerId); dragLampTo(p); e.preventDefault(); return; }
    var a = plotAt(p);
    if (a) { dragT = a; cv.setPointerCapture(e.pointerId); state.playing = false; state.t = P.clamp((p.x - a.L) / (a.R - a.L) * 24, 0, 24); syncUI(); e.preventDefault(); }
  });
  cv.addEventListener('pointermove', function (e) {
    var p = pos(e);
    if (state.dragging) { dragLampTo(p); return; }
    if (dragT) { state.t = P.clamp((p.x - dragT.L) / (dragT.R - dragT.L) * 24, 0, 24); return; }
    state.hoverLamp = nearLamp(p);
    cv.style.cursor = state.hoverLamp ? 'ew-resize' : plotAt(p) ? 'col-resize' : 'default';
  });
  function endDrag() {
    if (state.dragging) Analytics.track(NAME, '拖动台灯', state.d + ' cm');
    if (dragT) Analytics.track(NAME, '拖动时刻', '');
    state.dragging = false; dragT = null;
  }
  cv.addEventListener('pointerup', endDrag);
  cv.addEventListener('pointercancel', endDrag);
  cv.addEventListener('pointerleave', function () { state.hoverLamp = false; });

  // ---------- 面板 ----------
  $('panelToggle').addEventListener('click', function () { panel.classList.toggle('collapsed'); });
  if (window.matchMedia('(max-width: 760px)').matches) panel.classList.add('collapsed');
  window.addEventListener('keydown', function (e) {
    var tg = e.target.tagName;
    if (tg === 'INPUT' || tg === 'SELECT' || tg === 'BUTTON' || tg === 'TEXTAREA') return;
    if (e.code === 'Space') { e.preventDefault(); state.paused = !state.paused; syncUI(); }
  });

  function syncUI() {
    var sc = state.scene;
    setSeg('scene', sc);
    qa('[data-for]').forEach(function (el) { el.hidden = el.dataset.for.split(' ').indexOf(sc) < 0; });
    $('hint').textContent = HINTS[sc];
    setSeg('xv', state.xv); setSeg('weather', state.weather); setSeg('light', state.light ? '1' : '0');
    $('lamp').checked = state.lamp; $('theory').checked = state.theory;
    $('dayPlay').textContent = state.playing ? '❚❚ 暂停' : state.t >= 24 ? '↻ 再看一天' : '▶ 播放';
    qa('.pauseBtn').forEach(function (b) { b.textContent = state.paused ? '▶ 继续' : '❚❚ 暂停'; });
  }

  // ---------- 读数 ----------
  var lastText = {};
  function setText(id, s) { if (lastText[id] !== s) { lastText[id] = s; $(id).textContent = s; } }
  function rows(list) {
    for (var k = 1; k <= 5; k++) {
      var r = list[k - 1] || ['', ''];
      setText('d' + k, r[0]); setText('r' + k, r[1]);
      $('d' + k).hidden = $('r' + k).hidden = !r[0];
    }
  }
  function readBubble() {
    var L = P.lightOf(state.d, state.lamp), p = P.bubP(state.d, state.c, state.T, state.lamp), r = P.bubR(state.T), net = p - r;
    setText('rName', '每分钟约 ' + Math.round(Math.max(0, net)) + ' 个气泡');
    setText('rKind', !state.lamp ? '无光' : net > 0.5 ? '光合 > 呼吸' : '光合 ≤ 呼吸');
    // 主要限制因素：三个因素里“离饱和最远”的那个
    var f = [['光照', P.sat(L, P.BUB.KL)], ['CO₂', P.sat(P.BUB.C_WATER + state.c, P.BUB.KC)], ['温度', P.fT(state.T)]];
    f.sort(function (a, b) { return a[1] - b[1]; });
    var tip;
    if (!state.lamp) tip = '关灯后金鱼藻不进行光合作用，只进行呼吸作用，不再冒气泡。';
    else if (net <= 0.5) tip = state.T >= 38 ? '温度太高，光合作用减弱，而呼吸作用更强：产生的氧气不够自身消耗，不冒气泡。' : '光合作用太弱，放出的氧气不够自身呼吸消耗，几乎不冒气泡。';
    else if (f[0][1] > 0.85) tip = '三个条件都比较充足，气泡数接近最大值。';
    else tip = '当前主要限制因素：' + f[0][0] + '。改变它，气泡数变化最明显。';
    setText('rTip', tip);
    rows([
      ['光照强度', state.lamp ? '相对值 ' + L.toFixed(2) + '（灯距 20 cm 记为 1，与距离² 成反比）' : '0（关灯）'],
      ['光合作用', '产生 O₂ ≈ ' + p.toFixed(1) + ' 份/分钟'],
      ['呼吸作用', '消耗 O₂ ≈ ' + r.toFixed(1) + ' 份/分钟'],
      ['冒出气泡', '= 光合 − 呼吸 ≈ ' + Math.max(0, net).toFixed(1) + ' 个/分钟'],
      ['收集到的气体', Math.round(state.gas * 100) + '%（试管上部）']
    ]);
  }
  function readDay() {
    var c = P.sampleAt(state.series, state.t), net = c.P - c.R;
    setText('rName', PD.hm(state.t) + (c.L > 0 ? ' 白天' : ' 夜晚'));
    setText('rKind', c.P < 0.3 ? '只有呼吸' : net > 0.3 ? '光合 > 呼吸' : net < -0.3 ? '光合 < 呼吸' : '光合 = 呼吸');
    setText('rTip', c.P < 0.3 ? '没有光，植物只进行呼吸作用：吸收 O₂、放出 CO₂，罩内 CO₂ 浓度上升。'
      : net > 0.3 ? '光合作用强于呼吸作用：植物从罩内净吸收 CO₂、净放出 O₂，CO₂ 浓度下降，有机物积累。'
      : net < -0.3 ? '有光，但光照还弱（或罩内 CO₂ 太少），光合作用弱于呼吸作用，CO₂ 浓度仍在上升。'
      : '光合作用与呼吸作用强度相等，罩内 CO₂ 浓度不升不降——正是曲线的最高点或最低点。');
    rows([
      ['光照 / 温度', (c.L > 0 ? '相对 ' + c.L.toFixed(2) : '无光') + '，' + c.T.toFixed(1) + ' °C'],
      ['光合速率', c.P.toFixed(1) + ' ppm/时（吸收 CO₂）'],
      ['呼吸速率', c.R.toFixed(1) + ' ppm/时（放出 CO₂）'],
      ['罩内 CO₂', c.C.toFixed(0) + ' ppm（0 时 ' + P.DAY.C0 + ' ppm）'],
      ['有机物净积累', (c.org >= 0 ? '+' : '') + c.org.toFixed(0) + '（从 0 时算起，以 CO₂ ppm 计）']
    ]);
  }
  function readJar() {
    var J = state.jars;
    setText('rName', state.light ? '放在光下' : '放在黑暗处');
    setText('rKind', state.jarRun ? '进行中' : '已结束');
    setText('rTip', state.light
      ? '光下：单独的蜡烛很快熄灭、小鼠很快死去；和绿色植物放在一起，蜡烛能继续燃烧、小鼠能正常活着——植物进行光合作用放出了氧气。'
      : '黑暗中：植物不能进行光合作用，还要呼吸消耗氧气，放了植物的钟罩里蜡烛照样熄灭、小鼠照样死去，甚至更快。');
    rows(J.map(function (j, i) {
      var n = '①②③④'[i] + (j.who === 'candle' ? ' 蜡烛' : ' 小鼠') + (j.plant ? '+植物' : '');
      var st = j.who === 'candle' ? (j.alive ? '燃烧' : '熄灭') : (j.alive ? '活着' : '死亡');
      return [n, st + (j.alive ? '' : '（' + j.tEnd.toFixed(1) + ' 分）') + '，O₂ ' + j.o2.toFixed(1) + '%，CO₂ ' + j.co2.toFixed(2) + '%'];
    }));
  }

  // ---------- 尺寸与主循环 ----------
  function resize() { view.resize(stage.clientWidth, stage.clientHeight); }
  new ResizeObserver(resize).observe(stage);

  // 支持 ?scene=bubble|daynight|jar
  // 气泡：&light=10~80（灯距 cm）、&co2=0~2（NaHCO₃ %）、&temp=5~45（°C）、&lamp=0、&x=light|co2|temp（横轴）、&sweep=1（打开时快速测一组）、&theory=0
  // &t=0~120：打开时快进的秒数（实际秒，10 秒 = 模拟 1 分钟）
  // 一昼夜：&t=0~24（时刻）、&weather=sunny|cloudy、&play=0
  // 钟罩：&dark=1、&t=0~60（打开时快进的分钟数）
  var qs = new URLSearchParams(location.search);
  function num(k, lo, hi) { var x = parseFloat(qs.get(k)); return isFinite(x) && x >= lo && x <= hi ? x : null; }
  var x;
  if (HINTS[qs.get('scene')]) state.scene = qs.get('scene');
  if ((x = num('light', 10, 80)) != null) state.d = Math.round(x);
  if ((x = num('co2', 0, 2)) != null) state.c = Math.round(x * 4) / 4;
  if ((x = num('temp', 5, 45)) != null) state.T = Math.round(x);
  if (qs.get('lamp') === '0') state.lamp = false;
  if (P.VARS[qs.get('x')]) state.xv = qs.get('x');
  else if (qs.has('temp')) state.xv = 'temp';
  else if (qs.has('co2')) state.xv = 'co2';
  if (qs.get('theory') === '0') state.theory = false;
  if (qs.get('weather') === 'cloudy') state.weather = 'cloudy';
  if (qs.get('dark') === '1') state.light = false;

  resize();
  setScene(state.scene);
  if (qs.get('sweep') === '1') sweep();
  if (state.scene === 'daynight') {
    if ((x = num('t', 0, 24)) != null) state.t = x;
    if (qs.get('play') === '0' || state.t >= 24) state.playing = false;
    syncUI();
  } else if (state.scene === 'jar' && (x = num('t', 0, JAR_END)) != null) {
    for (var ft = 0; ft < x; ft += 0.05) stepJar(0.05 / JAR_SPEED);
  } else if (state.scene === 'bubble' && (x = num('t', 0, 120)) != null) {
    for (var fb = 0; fb < x; fb += 0.02) { state.time += 0.02; stepBubble(0.02); }
  }

  var sOut = { sD: 'sDOut', sC: 'sCOut', sT: 'sTOut' }, lastT = performance.now();
  function frame(now) {
    var dt = Math.min((now - lastT) / 1000, 0.1), sc = state.scene;
    lastT = now;
    if (state.paused) dt = 0;
    state.time += dt;
    sliders.forEach(function (s) {
      var v = curOf(s.key);
      if (document.activeElement !== s.el) s.el.value = v;
      setText(sOut[s.el.id], s.fmt(v));
    });
    if (document.activeElement !== sTime) sTime.value = state.t;
    setText('sTimeOut', Math.floor(state.t) + ' 时');
    if (sc === 'bubble') {
      stepBubble(dt);
      state.points.forEach(function (p) { p.match = sameOthers(p); });
      view.drawBubble(state);
      readBubble();
    } else if (sc === 'daynight') {
      stepDay(dt);
      view.drawDay(state);
      readDay();
    } else {
      stepJar(dt);
      view.drawJar(state);
      readJar();
    }
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // 调试用
  window.__model = {
    state: state, setScene: setScene, syncUI: syncUI, sweep: sweep, setWeather: setWeather, resetJars: resetJars,
    setD: function (v) { setVar('light', v); }, setC: function (v) { setVar('co2', v); }, setT: function (v) { setVar('temp', v); },
    // 按固定步长推进 sec 秒（截图、录屏用，配合 state.paused = true）
    step: function (sec) {
      for (var t = 0; t < sec; t += 0.02) {
        state.time += 0.02;
        if (state.scene === 'bubble') stepBubble(0.02); else if (state.scene === 'daynight') stepDay(0.02); else stepJar(0.02);
      }
    }
  };
})();
