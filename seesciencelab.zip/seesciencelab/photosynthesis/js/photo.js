// 光合作用与呼吸作用：计算模块（不碰 DOM）
// 速率模型是教学示意：光照、CO₂ 用饱和型曲线 1 − e^(−x/k)，温度用最适温度两侧不对称的钟形曲线，呼吸作用随温度按 Q10 = 2 增大
(function () {
  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
  function sat(x, k) { return x <= 0 ? 0 : 1 - Math.exp(-x / k); }

  // ---------- 温度：酶的活性 ----------
  var T_OPT = 28;
  function fT(T) {
    var w = T < T_OPT ? 14 : 9;
    return Math.exp(-Math.pow((T - T_OPT) / w, 2));
  }

  // ---------- 场景一：金鱼藻气泡计数 ----------
  // 单位：灯距 cm，NaHCO₃ 质量分数 %，水温 °C，速率“个气泡 / 分钟”（1 个气泡 ≈ 一份 O₂）
  var BUB = {
    D: [10, 80], C: [0, 2], T: [5, 45],
    D0: 20,          // 灯距 20 cm 时光照强度记为 1
    KL: 0.6,         // 光照饱和常数（相对光强）
    C_WATER: 0.15,   // 清水里本来溶有的少量 CO₂（折算成 NaHCO₃ %）
    KC: 0.5,
    PMAX: 60,        // 光合作用最大速率：60 份 O₂ / 分钟
    R25: 4           // 25 °C 时金鱼藻自身呼吸消耗：4 份 O₂ / 分钟
  };
  // 相对光照强度：点光源，光强与距离的平方成反比
  function lightOf(d, on) { return on === false ? 0 : Math.pow(BUB.D0 / clamp(d, BUB.D[0], BUB.D[1]), 2); }
  function bubP(d, c, T, on) {
    return BUB.PMAX * sat(lightOf(d, on), BUB.KL) * sat(BUB.C_WATER + c, BUB.KC) * fT(T);
  }
  function bubR(T) { return BUB.R25 * Math.pow(2, (T - 25) / 10); }
  // 每分钟冒出的气泡数 = 光合作用放出的 O₂ − 自身呼吸消耗的 O₂（不够时不冒气泡）
  function bubRate(d, c, T, on) { return Math.max(0, bubP(d, c, T, on) - bubR(T)); }
  // 气泡发生器：按速率累计，攒满 1 份放一个气泡（间隔带一点随机，平均速率不变）
  function Emitter(seed) {
    var s = seed || 1;
    function rnd() { s = (s * 16807) % 2147483647; return (s - 1) / 2147483646; }
    var acc = 0, need = 1;
    return {
      // 推进 dtMin 分钟，返回这段时间里放出的气泡数
      step: function (rate, dtMin) {
        acc += rate * dtMin;
        var n = 0;
        while (acc >= need) { acc -= need; n++; need = 0.75 + rnd() * 0.5; }
        return n;
      },
      reset: function () { acc = 0; need = 1; },
      rnd: rnd
    };
  }
  // 横轴变量
  var VARS = {
    light: { name: '灯距', unit: 'cm', lo: 10, hi: 80, step: 5, sweep: [10, 15, 20, 30, 40, 60, 80] },
    co2: { name: 'NaHCO₃ 浓度', unit: '%', lo: 0, hi: 2, step: 0.25, sweep: [0, 0.25, 0.5, 0.75, 1, 1.5, 2] },
    temp: { name: '水温', unit: '°C', lo: 5, hi: 45, step: 1, sweep: [5, 10, 15, 20, 25, 30, 35, 40, 45] }
  };

  // ---------- 场景二：密闭玻璃罩内的一昼夜 ----------
  // 单位：时刻 h（0～24），CO₂ 浓度 ppm，速率 ppm/h（罩内 CO₂ 浓度的变化快慢）
  var DAY = {
    RISE: 6, SET: 18,      // 日出、日落
    LMAX: { sunny: 4, cloudy: 1.1 },
    KL: 0.6,
    PMAX: 100,             // 光照、温度都最适时的光合作用速率（CO₂ 充足时）
    KC: 250,               // CO₂ 浓度的饱和常数 ppm（罩内 CO₂ 少了，光合作用就慢下来）
    R20: 12,               // 20 °C 时整株植物的呼吸作用速率
    C0: 400                // 0 时罩内 CO₂ 浓度
  };
  function dayLight(t, weather) {
    if (t <= DAY.RISE || t >= DAY.SET) return 0;
    return (DAY.LMAX[weather] || DAY.LMAX.sunny) * Math.sin(Math.PI * (t - DAY.RISE) / (DAY.SET - DAY.RISE));
  }
  function dayTemp(t, weather) {
    var amp = weather === 'cloudy' ? 4 : 8;
    return 18 + amp * Math.cos(2 * Math.PI * (t - 15) / 24);
  }
  function dayP(L, C, T) { return DAY.PMAX * sat(L, DAY.KL) * (C / (C + DAY.KC)) * fT(T); }
  function dayR(T) { return DAY.R20 * Math.pow(2, (T - 20) / 10); }
  // 预先算出一整天：每 dt 小时一个样本 { t, L, T, P, R, C, org }，org 为有机物净积累（以 CO₂ ppm 计）
  function simDay(weather, dt) {
    dt = dt || 0.05;
    var out = [], C = DAY.C0, org = 0, n = Math.round(24 / dt);
    for (var i = 0; i <= n; i++) {
      var t = i * dt, L = dayLight(t, weather), T = dayTemp(t, weather);
      var P = dayP(L, C, T), R = dayR(T);
      out.push({ t: t, L: L, T: T, P: P, R: R, C: C, org: org });
      // 半步法积分 dC/dt = R − P
      var Cm = Math.max(1, C + (R - P) * dt / 2), tm = t + dt / 2;
      var Pm = dayP(dayLight(tm, weather), Cm, dayTemp(tm, weather)), Rm = dayR(dayTemp(tm, weather));
      C = Math.max(1, C + (Rm - Pm) * dt);
      org += (Pm - Rm) * dt;
    }
    return out;
  }
  // 关键点：光合 = 呼吸的两个时刻（罩内 CO₂ 的最高点、最低点）
  function dayKeys(series) {
    var keys = [];
    for (var i = 1; i < series.length; i++) {
      var a = series[i - 1], b = series[i], da = a.P - a.R, db = b.P - b.R;
      if (da <= 0 && db > 0 || da > 0 && db <= 0) {
        var f = da / (da - db), t = a.t + (b.t - a.t) * f;
        keys.push({ t: t, C: a.C + (b.C - a.C) * f, up: db > 0 });
      }
    }
    return keys;
  }
  function sampleAt(series, t) {
    var dt = series[1].t - series[0].t, i = clamp(Math.floor(t / dt), 0, series.length - 2), f = clamp((t - series[i].t) / dt, 0, 1);
    var a = series[i], b = series[i + 1], o = {};
    Object.keys(a).forEach(function (k) { o[k] = a[k] + (b[k] - a[k]) * f; });
    return o;
  }

  // ---------- 场景三：普利斯特利钟罩 ----------
  // 单位：气体体积分数 %，时间为示意的“分钟”；蜡烛 O₂ 低于 16% 熄灭，小鼠低于 10% 死去（示意阈值）
  var JAR = {
    O2: 21, CO2: 0.04,
    CANDLE: 0.9, MOUSE: 0.35,     // 每分钟消耗的 O₂（同时放出等量 CO₂）
    PMAX: 1.6, KC: 0.3, RP: 0.05, // 绿色植物：光下按罩内 CO₂ 多少吸收 CO₂、放出 O₂；无论光暗都在呼吸
    OUT: { candle: 16, mouse: 10 }
  };
  function jarNew(who, plant) { return { who: who, plant: plant, o2: JAR.O2, co2: JAR.CO2, alive: true, t: 0, tEnd: null }; }
  function jarStep(j, light, dt) {
    j.t += dt;
    var use = j.alive ? (j.who === 'candle' ? JAR.CANDLE : JAR.MOUSE) : 0, p = 0, r = 0;
    if (j.plant) {
      r = JAR.RP;
      if (light) p = JAR.PMAX * j.co2 / (j.co2 + JAR.KC);
    }
    var dO = (p - use - r) * dt;
    j.o2 = clamp(j.o2 + dO, 0, 100);
    j.co2 = Math.max(0, j.co2 - dO);
    if (j.alive && j.o2 < JAR.OUT[j.who]) { j.alive = false; j.tEnd = j.t; }
    return j;
  }

  window.Photo = {
    clamp: clamp, sat: sat, fT: fT, T_OPT: T_OPT,
    BUB: BUB, VARS: VARS, lightOf: lightOf, bubP: bubP, bubR: bubR, bubRate: bubRate, Emitter: Emitter,
    DAY: DAY, dayLight: dayLight, dayTemp: dayTemp, dayP: dayP, dayR: dayR, simDay: simDay, dayKeys: dayKeys, sampleAt: sampleAt,
    JAR: JAR, jarNew: jarNew, jarStep: jarStep
  };
})();
