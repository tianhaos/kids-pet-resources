// 从北极上方看，日月角距与观测点沿逆时针增加。y 轴指北。
(function () {
  const T = window.Tides;
  const THREE = window.THREE;
  const RADIUS = 1.48;
  const SURFACE = 1.87;
  const AMPLIFY = 0.29;
  const ORBIT = 3.5;
  const SUN_X = 5.05;
  const V = (x, y, z) => new THREE.Vector3(x, y, z);
  const along = (radius, angle) => V(radius * Math.cos(angle), 0, -radius * Math.sin(angle));

  function create(host) {
    const scene = new THREE.Scene();
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
    renderer.outputEncoding = THREE.sRGBEncoding;
    host.prepend(renderer.domElement);
    const camera = new THREE.OrthographicCamera(-5, 5, 4, -4, 0.1, 120);
    const controls = new THREE.OrbitControls(camera, renderer.domElement);
    controls.enablePan = false;
    controls.minZoom = 0.73;
    controls.maxZoom = 2.5;
    controls.rotateSpeed = 0.7;
    controls.minPolarAngle = 0.02;
    controls.maxPolarAngle = Math.PI * 0.48;

    const sunLight = new THREE.DirectionalLight(0xffecd3, 1.65);
    sunLight.position.set(8, 3, -1);
    scene.add(sunLight, new THREE.AmbientLight(0x89b5ec, 0.9));

    function sphere(radius, material) {
      const mesh = new THREE.Mesh(new THREE.SphereGeometry(radius, 64, 40), material);
      scene.add(mesh);
      return mesh;
    }

    // 参考地球略小于平均潮面，留出可读的夸大起伏空间。
    const map = new THREE.CanvasTexture(window.makeEarthCanvas());
    map.encoding = THREE.sRGBEncoding;
    map.anisotropy = Math.min(renderer.capabilities.getMaxAnisotropy(), 8);
    const earth = sphere(RADIUS, new THREE.MeshPhongMaterial({
      map, color: 0xa5c7db, shininess: 13, specular: 0x182d48
    }));

    const moonMap = document.createElement('canvas');
    moonMap.width = 512;
    moonMap.height = 256;
    const ctx = moonMap.getContext('2d');
    ctx.fillStyle = '#a5a5ab';
    ctx.fillRect(0, 0, 512, 256);
    let seed = 13;
    function random() {
      seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
      return seed / 4294967296;
    }
    for (let i = 0; i < 210; i++) {
      const x = random() * 512, y = random() * 256, r = 1 + random() ** 3 * 17;
      const shade = ctx.createRadialGradient(x + r * .26, y, 0, x, y, r);
      shade.addColorStop(0, '#55586480');
      shade.addColorStop(.68, '#696c7790');
      shade.addColorStop(1, '#c4c3c500');
      ctx.fillStyle = shade;
      ctx.fillRect(x - r, y - r, r * 2, r * 2);
    }
    const lunarTexture = new THREE.CanvasTexture(moonMap);
    lunarTexture.encoding = THREE.sRGBEncoding;
    const moon = sphere(.34, new THREE.MeshLambertMaterial({ map: lunarTexture }));
    const sun = sphere(.55, new THREE.MeshBasicMaterial({ color: 0xffd07d }));
    sun.position.x = SUN_X;
    // 暖色日冕仅标记光源，潮面计算使用独立的太阳引潮项。
    const haloCanvas = document.createElement('canvas');
    haloCanvas.width = haloCanvas.height = 128;
    const haloInk = haloCanvas.getContext('2d');
    const halo = haloInk.createRadialGradient(64, 64, 10, 64, 64, 64);
    halo.addColorStop(0, '#ffe6b6');
    halo.addColorStop(.33, '#ffb5527d');
    halo.addColorStop(.67, '#ff9c211c');
    halo.addColorStop(1, '#ff9c2100');
    haloInk.fillStyle = halo;
    haloInk.fillRect(0, 0, 128, 128);
    const glow = new THREE.Sprite(new THREE.SpriteMaterial({
      map: new THREE.CanvasTexture(haloCanvas), depthWrite: false, blending: THREE.AdditiveBlending
    }));
    glow.position.copy(sun.position);
    glow.scale.set(2.6, 2.6, 1);
    scene.add(glow);

    function path(count, color, opacity = 1, dashed = false) {
      const geometry = new THREE.BufferGeometry();
      geometry.setAttribute('position', new THREE.BufferAttribute(new Float32Array(count * 3), 3));
      const material = dashed
        ? new THREE.LineDashedMaterial({ color, transparent: true, opacity, dashSize: .09, gapSize: .075 })
        : new THREE.LineBasicMaterial({ color, transparent: opacity < 1, opacity });
      const line = new THREE.Line(geometry, material);
      line.frustumCulled = false;
      scene.add(line);
      return line;
    }

    function updatePath(line, positionAt) {
      const positions = line.geometry.getAttribute('position');
      for (let i = 0; i < positions.count; i++) {
        const position = positionAt(i / (positions.count - 1));
        positions.setXYZ(i, position.x, position.y, position.z);
      }
      positions.needsUpdate = true;
      if (line.material.isLineDashedMaterial) line.computeLineDistances();
    }

    const orbit = path(129, 0x637795, .65, true);
    updatePath(orbit, ratio => along(ORBIT, ratio * T.TAU));

    const mean = path(129, 0xa0afc6, .64, true);
    updatePath(mean, ratio => along(SURFACE, ratio * T.TAU));
    const equator = path(129, 0x67ebff);
    const parallels = [-60, -30, 30, 60].map(latitude => ({
      latitude: latitude * Math.PI / 180, line: path(97, 0x42ade2, .31)
    }));
    const meridians = Array.from({ length: 8 }, (_, i) => ({
      angle: i * Math.PI / 8, line: path(97, 0x42ade2, .24)
    }));

    const oceanGeometry = new THREE.SphereGeometry(1, 72, 42);
    const unitVertices = oceanGeometry.getAttribute('position').array.slice();
    const surface = new THREE.Mesh(oceanGeometry, new THREE.MeshBasicMaterial({
      color: 0x229fd6, opacity: .12, transparent: true, depthWrite: false
    }));
    surface.frustumCulled = false;
    scene.add(surface);

    const majorAxis = path(2, 0x77dff4, .68, true);
    const station = sphere(.104, new THREE.MeshBasicMaterial({ color: 0xffc94a, depthTest: false }));
    station.renderOrder = 5;
    const stationGuide = path(2, 0xffc94a, .79);
    const arrows = Array.from({ length: 12 }, (_, i) => {
      const angle = i * T.TAU / 12;
      const arrow = new THREE.ArrowHelper(V(1, 0, 0), along(SURFACE, angle), 1, 0xf8ad73);
      for (const part of [arrow.line, arrow.cone]) {
        part.material.depthTest = false;
        part.renderOrder = 4;
      }
      scene.add(arrow);
      return { arrow, angle };
    });

    const labels = Object.fromEntries(['moon', 'sun', 'station'].map(name => [
      name, host.querySelector('[data-object="' + name + '"]')
    ]));
    let width, height;
    const facing = V(0, 0, 0);
    function resize() {
      width = host.clientWidth;
      height = host.clientHeight;
      const aspect = width / Math.max(height, 1);
      const halfHeight = Math.max(3.55, 5.92 / aspect);
      camera.left = -halfHeight * aspect;
      camera.right = halfHeight * aspect;
      camera.top = halfHeight;
      camera.bottom = -halfHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(width, height);
    }
    function reset(top = false) {
      controls.target.set(.55, 0, 0);
      camera.position.set(.55, 12, top ? .3 : 6.9);
      camera.zoom = 1;
      camera.updateProjectionMatrix();
      controls.update();
    }
    reset();
    resize();
    new ResizeObserver(resize).observe(host);

    function surfaceRadius(x, z, phase, solar) {
      return SURFACE + AMPLIFY * T.height(x, x * Math.cos(phase) - z * Math.sin(phase), solar);
    }

    function surfacePoint(latitude, angle, phase, solar) {
      const vec = along(Math.cos(latitude), angle);
      vec.y = Math.sin(latitude);
      return vec.multiplyScalar(surfaceRadius(vec.x, vec.z, phase, solar));
    }

    let previousGeometry = '';
    function updateOcean(phase, solar) {
      const geometryKey = phase + '/' + solar;
      if (geometryKey === previousGeometry) return;
      previousGeometry = geometryKey;
      const positions = oceanGeometry.getAttribute('position');
      for (let i = 0; i < unitVertices.length; i += 3) {
        const x = unitVertices[i], y = unitVertices[i + 1], z = unitVertices[i + 2];
        const r = surfaceRadius(x, z, phase, solar);
        positions.setXYZ(i / 3, x * r, y * r, z * r);
      }
      positions.needsUpdate = true;
      updatePath(equator, ratio => surfacePoint(0, ratio * T.TAU, phase, solar));
      parallels.forEach(({ latitude, line }) => {
        updatePath(line, ratio => surfacePoint(latitude, ratio * T.TAU, phase, solar));
      });
      meridians.forEach(({ angle, line }) => {
        updatePath(line, ratio => surfacePoint(ratio * T.TAU, angle, phase, solar));
      });
      const axis = T.harmonic(phase, solar).axis;
      updatePath(majorAxis, ratio => along(2.89 * (1 - 2 * ratio), axis));
    }

    function pixel(position) {
      const p = position.clone().project(camera);
      return { x: (p.x + 1) * width / 2, y: (1 - p.y) * height / 2 };
    }
    function placeLabel(label, position, visible) {
      const p = pixel(position);
      const inFrame = p.x > 12 && p.x < width - 12 && p.y > 12 && p.y < height - 30;
      label.hidden = !visible || !inFrame;
      p.x = Math.max(26, Math.min(width - 26, p.x));
      label.style.left = p.x + 'px';
      label.style.top = p.y + 'px';
    }

    function paint(state) {
      const { phase, hours, scene: mode } = state;
      const solar = mode !== 'force' && state.solar;
      const angle = phase + hours / T.DAY * T.TAU;
      const stationRadius = surfacePoint(0, angle, phase, solar).length();
      moon.position.copy(along(ORBIT, phase));
      moon.rotation.y = phase;
      earth.rotation.y = mode === 'day' ? angle + .3 : .3;
      const arrowView = mode === 'force';
      sun.visible = glow.visible = !arrowView;
      surface.visible = !arrowView;
      mean.visible = !arrowView;
      equator.visible = !arrowView;
      majorAxis.visible = true;
      [...parallels, ...meridians].forEach(({ line }) => { line.visible = !arrowView; });
      station.visible = stationGuide.visible = mode === 'day';
      station.position.copy(along(stationRadius, angle));
      if (station.visible) {
        updatePath(stationGuide, ratio => along(RADIUS + ratio * (stationRadius - RADIUS), angle));
      }
      updateOcean(phase, solar);
      arrows.forEach(({ arrow, angle: direction }) => {
        arrow.visible = arrowView;
        if (!arrowView) return;
        const start = along(1.62, direction);
        const [x, z] = T.force(start.x, start.z, phase);
        const vector = V(x, 0, z);
        arrow.position.copy(start);
        arrow.setLength(vector.length() * .24, .14, .085);
        arrow.setDirection(vector.normalize());
      });
      controls.update();
      renderer.render(scene, camera);
      placeLabel(labels.moon, moon.position, true);
      placeLabel(labels.sun, sun.position, sun.visible);
      if (station.visible) {
        camera.getWorldDirection(facing);
        const depth = station.position.dot(facing);
        const covered = depth > 0 && station.position.lengthSq() - depth * depth < RADIUS * RADIUS;
        labels.station.textContent = covered ? '背侧观测点' : '观测点';
      }
      placeLabel(labels.station, station.position, station.visible);
    }

    const ray = new THREE.Raycaster();
    const plane = new THREE.Plane(V(0, 1, 0), 0);
    function angleAt(x, y) {
      ray.setFromCamera(new THREE.Vector2(x / width * 2 - 1, 1 - y / height * 2), camera);
      const hit = ray.ray.intersectPlane(plane, V(0, 0, 0));
      if (hit && hit.length() > .6) return T.wrap(Math.atan2(-hit.z, hit.x), T.TAU);
      return null;
    }
    function hitTest(x, y, touch, mode) {
      const near = (object, radius) => {
        const p = pixel(object.position);
        return Math.hypot(x - p.x, y - p.y) < radius;
      };
      if (mode === 'day' && near(station, touch ? 27 : 18)) return 'station';
      if (near(moon, touch ? 29 : 24)) return 'moon';
      return '';
    }

    return { paint, reset, controls, angleAt, hitTest, pixel, moon, station, canvas: renderer.domElement };
  }

  window.TidesScene = { create };
})();
