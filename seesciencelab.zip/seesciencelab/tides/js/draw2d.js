// 两条时间轴共享月球单独作用时的赤道半潮差这个单位。
(function () {
  const T = window.Tides;
  const CURVES = {
    day: {
      ticks: ['0', '6', '12', '18', '24时'],
      limits: [-1.6, 1.6], levels: [-1, 0, 1],
      cursor: state => state.hours / T.DAY,
      point: (x, state) => T.level(x * T.TAU + state.phase, state.phase, state.solar),
      color: '#65e3ff', reference: '#8a9ab3',
      compare: x => Math.cos(2 * x * T.TAU)
    },
    month: {
      ticks: ['新月', '上弦', '满月', '下弦', '新月'],
      limits: [0, 3.2], levels: [0, 1, 2, 3],
      cursor: state => state.phase / T.TAU,
      point: (x, state) => 2 * T.harmonic(x * T.TAU, state.solar).amplitude,
      color: '#65e3ff', reference: '#8a9ab3',
      compare: () => 2
    }
  };

  function create(canvas) {
    const ctx = canvas.getContext('2d');
    let width = 0, height = 0;
    const left = 31, right = 27;
    function resize() {
      width = canvas.clientWidth;
      height = canvas.clientHeight;
      const ratio = Math.min(devicePixelRatio, 2);
      canvas.width = Math.round(width * ratio);
      canvas.height = Math.round(height * ratio);
      ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
    }
    new ResizeObserver(resize).observe(canvas);
    resize();

    function paint(state) {
      const curve = CURVES[state.scene];
      if (!curve || height < 30 || width < 80) return;
      const [min, max] = curve.limits;
      const x = ratio => left + ratio * (width - left - right);
      const y = level => 8 + (max - level) / (max - min) * (height - 32);
      ctx.clearRect(0, 0, width, height);
      ctx.font = '11px system-ui, sans-serif';
      ctx.textBaseline = 'middle';
      curve.levels.forEach(level => {
        ctx.strokeStyle = level === 0 ? '#526078' : '#243249';
        ctx.beginPath();
        ctx.moveTo(x(0), y(level));
        ctx.lineTo(x(1), y(level));
        ctx.stroke();
        ctx.fillStyle = '#aebbd2';
        ctx.textAlign = 'right';
        ctx.fillText(String(level), x(0) - 8, y(level));
      });
      curve.ticks.forEach((label, i) => {
        const ratio = state.scene === 'day' ? i * 6 / T.DAY : i / 4;
        ctx.textAlign = 'center';
        ctx.fillStyle = '#b2bed2';
        ctx.fillText(label, x(ratio), height - 10);
      });
      function plot(point, color, dash) {
        ctx.beginPath();
        ctx.strokeStyle = color;
        ctx.setLineDash(dash);
        ctx.lineWidth = dash.length ? 1.2 : 2.2;
        for (let i = 0; i <= 180; i++) {
          const ratio = i / 180;
          const level = point(ratio, state);
          if (i === 0) ctx.moveTo(x(ratio), y(level));
          else ctx.lineTo(x(ratio), y(level));
        }
        ctx.stroke();
        ctx.setLineDash([]);
        ctx.lineWidth = 1;
      }
      if (state.solar) plot(curve.compare, curve.reference, [4, 4]);
      plot(curve.point, curve.color, []);
      const cursor = curve.cursor(state);
      const level = y(curve.point(cursor, state));
      ctx.strokeStyle = '#ffc94aa6';
      ctx.beginPath();
      ctx.moveTo(x(cursor), 4);
      ctx.lineTo(x(cursor), height - 22);
      ctx.stroke();
      ctx.fillStyle = '#ffc94a';
      ctx.beginPath();
      ctx.arc(x(cursor), level, 4, 0, T.TAU);
      ctx.fill();
    }

    const fractionAt = x => Math.max(0, Math.min(1, (x - left) / (width - left - right)));
    return { paint, fractionAt };
  }

  window.TidesDraw = { create };
})();
