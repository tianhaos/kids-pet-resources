(function () {
  const T = window.Tides;
  const $ = id => document.getElementById(id);
  const host = $('space');
  const graphCanvas = $('chart');
  const query = new URLSearchParams(location.search);
  const scenes = {
    day: {
      title: '转动地球，看见一天的涨落',
      guide: '拖动金色观测点，或拖动下方曲线',
      chart: '赤道观测点潮高',
      body: '固定这个月相，观测点随地球相对日月系统转一圈，经历两次高潮和两次低潮。'
    },
    month: {
      title: '拖动月球，对照大潮与小潮',
      guide: '拖动月球，或选择新月、上弦和满月',
      chart: '一个朔望月的赤道半日潮差',
      body: '新月和满月附近，日月引潮效应沿同一轴加强。上弦和下弦附近，两者部分抵消。'
    },
    force: {
      title: '地球背向月球的一侧为何也隆起？',
      guide: '拖动月球，观察箭头怎样转向',
      body: '从各处的月球引力中减去地心受到的月球引力，得到图中的引潮加速度。'
    }
  };

  function numberParam(name, fallback, max) {
    const raw = query.get(name);
    const number = Number(raw);
    return raw?.trim() && Number.isFinite(number) ? Math.max(0, Math.min(max, number)) : fallback;
  }

  const state = {
    scene: Object.hasOwn(scenes, query.get('scene')) ? query.get('scene') : 'day',
    phase: T.wrap(numberParam('phase', 0, 360) * Math.PI / 180, T.TAU),
    hours: numberParam('h', 1.75, T.DAY),
    solar: query.get('sun') !== '0',
    running: false
  };
  const graph = window.TidesDraw.create(graphCanvas);
  let scene;
  // 保留完整的可拖动曲线与控件，供没有 WebGL 的设备使用。
  try {
    scene = window.TidesScene.create(host);
  } catch (error) {
    $('webglFallback').hidden = false;
  }

  const tabs = [...document.querySelectorAll('[data-scene]')];
  const presets = [...document.querySelectorAll('[data-phase]')];
  const panel = $('panel');
  const phaseSlider = $('phaseSlider');
  const timeSlider = $('timeSlider');
  timeSlider.max = T.DAY;
  const track = (action, label) => window.Analytics?.track('潮汐成因', action, label);

  function setRunning(running) {
    state.running = running && state.scene !== 'force';
    $('play').textContent = state.running ? '暂停' : '播放';
    $('play').setAttribute('aria-pressed', state.running);
  }

  function syncScene() {
    const mode = state.scene;
    const config = scenes[mode];
    $('app').dataset.scene = mode;
    $('sceneTitle').textContent = config.title;
    $('guide').textContent = config.guide;
    $('chartTitle').textContent = config.chart || '';
    $('mechanism').textContent = config.body;
    $('graphBox').hidden = mode === 'force';
    $('forceBox').hidden = mode !== 'force';
    $('dayControls').hidden = mode !== 'day';
    $('solarRow').hidden = mode === 'force';
    $('play').hidden = $('restart').hidden = mode === 'force';
    tabs.forEach(tab => {
      const active = tab.dataset.scene === mode;
      tab.classList.toggle('on', active);
      tab.setAttribute('aria-pressed', active);
    });
    setRunning(false);
  }

  function setScene(mode) {
    if (!Object.hasOwn(scenes, mode) || mode === state.scene) return;
    state.scene = mode;
    syncScene();
    track('切换场景', mode);
  }

  function setPhase(angle) {
    if (!Number.isFinite(angle)) return;
    state.phase = T.wrap(angle, T.TAU);
  }

  function setPanel(open) {
    panel.classList.toggle('collapsed', !open);
    $('panelToggle').setAttribute('aria-expanded', open);
    $('panelToggle').textContent = open ? '收起控制' : '展开控制';
    panel.inert = !open && matchMedia('(max-width:760px)').matches;
  }
  setPanel(false);
  matchMedia('(max-width:760px)').addEventListener('change', () => setPanel(false));

  tabs.forEach(tab => tab.addEventListener('click', () => setScene(tab.dataset.scene)));
  presets.forEach(button => button.addEventListener('click', () => {
    setRunning(false);
    setPhase(Number(button.dataset.phase) * Math.PI / 180);
    track('选择月相', button.textContent);
  }));
  phaseSlider.addEventListener('input', () => {
    setRunning(false);
    setPhase(Number(phaseSlider.value) * Math.PI / 180);
  });
  phaseSlider.addEventListener('change', () => track('调整日月角距', state.scene));
  timeSlider.addEventListener('input', () => {
    setRunning(false);
    state.hours = Number(timeSlider.value);
  });
  timeSlider.addEventListener('change', () => track('调整观测时间', '滑块'));
  $('solar').checked = state.solar;
  $('solar').addEventListener('change', () => {
    state.solar = $('solar').checked;
    track('切换太阳引潮项', state.solar ? '开启' : '关闭');
  });
  $('play').addEventListener('click', () => {
    setRunning(!state.running);
    if (state.running) track('播放', state.scene);
  });
  $('restart').addEventListener('click', () => {
    setRunning(false);
    if (state.scene === 'month') setPhase(0);
    else state.hours = 0;
  });
  $('topView').addEventListener('click', () => scene?.reset(true));
  $('viewReset').addEventListener('click', () => scene?.reset());
  $('panelToggle').addEventListener('click', () => setPanel(panel.classList.contains('collapsed')));

  function dragOn(element, pick, update, end, hover, start) {
    let active;
    function point(event) {
      const rect = element.getBoundingClientRect();
      return [event.clientX - rect.left, event.clientY - rect.top];
    }
    function release(event) {
      if (active?.id !== event.pointerId) return;
      const target = active.target;
      active = null;
      element.classList.remove('dragging');
      end(target);
    }
    element.addEventListener('pointerdown', event => {
      if (active || event.button !== 0) return;
      const target = pick(...point(event), event.pointerType !== 'mouse');
      if (!target) return;
      event.preventDefault();
      active = { id: event.pointerId, target };
      element.setPointerCapture(event.pointerId);
      element.classList.add('dragging');
      setRunning(false);
      start?.();
      update(target, ...point(event));
    }, true);
    element.addEventListener('pointermove', event => {
      const position = point(event);
      if (active?.id === event.pointerId) update(active.target, ...position);
      else if (!active && hover) element.classList.toggle('can-drag', !!pick(...position, false));
    });
    for (const name of ['pointerup', 'pointercancel', 'lostpointercapture']) {
      element.addEventListener(name, release, true);
    }
  }

  if (scene) {
    dragOn(scene.canvas,
      (x, y, touch) => scene.hitTest(x, y, touch, state.scene),
      (target, x, y) => {
        const angle = scene.angleAt(x, y);
        if (angle === null) return;
        if (target === 'moon') setPhase(angle);
        else state.hours = T.wrap(angle - state.phase, T.TAU) / T.TAU * T.DAY;
      },
      target => {
        scene.controls.enabled = true;
        track(target === 'moon' ? '拖动月球' : '拖动观测点', state.scene);
      }, true, () => { scene.controls.enabled = false; });
  } else {
    $('topView').disabled = $('viewReset').disabled = true;
  }

  dragOn(graphCanvas, () => 'chart', (_, x) => {
    const fraction = graph.fractionAt(x);
    if (state.scene === 'month') setPhase(fraction * (T.TAU - 1e-9));
    else state.hours = fraction * T.DAY;
  }, () => track('拖动曲线', state.scene));

  function updateReadouts() {
    const phase = state.phase;
    const dayAngle = phase + state.hours * T.TAU / T.DAY;
    const degrees = Math.floor(phase * 180 / Math.PI + .001) % 360;
    const minutes = Math.round(state.hours * 60);
    const time = String(Math.floor(minutes / 60)).padStart(2, '0') + ':' + String(minutes % 60).padStart(2, '0');
    const withSun = state.solar && state.scene !== 'force';
    const harmonic = T.harmonic(phase, withSun);
    const level = T.level(dayAngle, phase, withSun);
    const slope = -Math.sin(2 * (dayAngle - phase)) - (withSun ? T.SOLAR * Math.sin(2 * dayAngle) : 0);
    const flow = Math.abs(slope) < harmonic.amplitude * .06 ? (level > 0 ? '高潮' : '低潮') : (slope > 0 ? '涨潮' : '落潮');
    const phaseLabel = T.phaseName(phase);
    phaseSlider.value = degrees;
    timeSlider.value = state.hours;
    $('phaseValue').textContent = degrees + '°';
    $('timeValue').textContent = time;
    $('detailRange').textContent = (2 * harmonic.amplitude).toFixed(2);
    $('detailPhase').textContent = phaseLabel + ' · ' + degrees + '°';
    $('chartValue').textContent = state.scene === 'month'
      ? phaseLabel + ' · 潮差 ' + (2 * harmonic.amplitude).toFixed(2)
      : time + ' · ' + flow + ' ' + (level >= 0 ? '+' : '−') + Math.abs(level).toFixed(2);
    $('chartReference').hidden = !withSun;
    $('surfaceKey').hidden = state.scene === 'force';
    $('meanKey').hidden = state.scene === 'force';
    presets.forEach(button => {
      const active = Number(button.dataset.phase) === degrees;
      button.classList.toggle('on', active);
      button.setAttribute('aria-pressed', active);
    });
  }

  let previousTime, previousReadout;
  function frame(now) {
    const dt = Math.min((now - (previousTime ?? now)) / 1000, .07);
    previousTime = now;
    if (state.running && state.scene === 'day') state.hours = T.wrap(state.hours + dt * T.DAY / 13, T.DAY);
    if (state.running && state.scene === 'month') setPhase(state.phase + dt * T.TAU / 20);
    scene?.paint(state);
    graph.paint(state);
    const readoutState = [state.scene, state.phase, state.hours, state.solar].join('/');
    if (readoutState !== previousReadout) {
      previousReadout = readoutState;
      updateReadouts();
    }
    requestAnimationFrame(frame);
  }

  syncScene();
  if (query.get('view') === 'top') scene?.reset(true);
  document.documentElement.dataset.ready = 'true';
  window.__model = { state, scene, setScene, setPhase, setRunning };
  requestAnimationFrame(frame);
})();
