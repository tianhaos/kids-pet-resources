// 共面、圆轨道下的平衡潮。潮高以月球单独产生的赤道半潮差为单位。
(function () {
  const TAU = 2 * Math.PI;
  const MONTH = 29.53059;
  const DAY = 24 / (1 - 1 / MONTH);
  const SOLAR = 0.46;
  const wrap = (value, period) => ((value % period) + period) % period;

  function harmonic(phase, sun = true) {
    const x = Math.cos(2 * phase) + (sun ? SOLAR : 0);
    const y = Math.sin(2 * phase);
    return { amplitude: Math.hypot(x, y), axis: Math.atan2(y, x) / 2 };
  }

  // P₂(cos ψ) = (3 cos² ψ − 1) / 2。比例 4/3 使赤道月潮半潮差为 1。
  function height(sunDot, moonDot, sun = true) {
    const lunar = 2 * moonDot * moonDot - 2 / 3;
    return lunar + (sun ? SOLAR * (2 * sunDot * sunDot - 2 / 3) : 0);
  }

  function level(angle, phase, sun = true) {
    // 去掉固定纬度上的常数项，以赤道全天平均水位作曲线零线。
    return Math.cos(2 * (angle - phase)) + (sun ? SOLAR * Math.cos(2 * angle) : 0);
  }

  // 一阶引潮加速度场 3(n·r)n − r，省略共同的 GM/D³。
  function force(x, z, phase) {
    const nx = Math.cos(phase), nz = -Math.sin(phase);
    const projection = x * nx + z * nz;
    return [3 * projection * nx - x, 3 * projection * nz - z];
  }

  function phaseName(angle) {
    const phases = ['新月', '蛾眉月', '上弦月', '盈凸月', '满月', '亏凸月', '下弦月', '残月'];
    return phases[Math.round(wrap(angle, TAU) / TAU * 8) % 8];
  }

  window.Tides = { TAU, MONTH, DAY, SOLAR, wrap, harmonic, height, level, force, phaseName };
})();
