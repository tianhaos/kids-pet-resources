// 波的干涉和衍射的计算：两波源的叠加（光程差、加强与减弱、振幅、加强线双曲线、波峰波谷圆）、
// 平面波通过狭缝 / 绕过障碍物的衍射（惠更斯原理逐点叠加）、波场网格、练习题
// 单位：长度 cm、时间 s；水波槽中波速取 V = 24 cm/s；振幅以单列波的振幅 A 为单位
// 坐标：x 右、y 上；干涉的两个波源 S₁ 在 (−d/2, 0)、S₂ 在 (d/2, 0)；衍射的挡板在 x = 0，平面波从左向右传播
// 相位约定：波源振动 A·sin(ωt + φ)，传到 r 处为 A·sin(ωt − kr + φ)，复振幅 C = A·e^{i(φ − kr)}，位移 = Im(C·e^{iωt})
(function () {
  var V = 24;                      // 水波波速 cm/s
  var LAM_RANGE = [1.2, 4], D_RANGE = [2, 12];          // 干涉：波长、两波源间距
  var DLAM_RANGE = [0.8, 4], A_RANGE = [0.5, 12];      // 衍射：波长、缝宽 / 障碍物宽度
  var SLOW = 12;                   // 动画放慢倍数（所有场景相同）
  var F_DETUNE = 1.12;             // “频率不同”时 S₂ 的频率是 S₁ 的倍数
  var TAU = Math.PI * 2;

  function clamp(x, a, b) { return Math.max(a, Math.min(b, x)); }
  function f(x, n) { return (+x.toFixed(n == null ? 2 : n)).toString(); }
  function pick(rand, arr) { return arr[Math.floor(rand() * arr.length) % arr.length]; }
  function freq(lam) { return V / lam; }

  // ---------- 两波源干涉 ----------
  // 两列波在 P 点的相位差对应的“有效波程差”m：同相波源 m = (r₁ − r₂)/λ，反相波源再加 ½。
  // m 为整数时振动加强，为半整数时振动减弱
  function mOf(s, lam, anti) { return s / lam + (anti ? 0.5 : 0); }
  // s = r₁ − r₂（cm）。返回 { kind: 'strong'|'weak'|'mid', m, text }
  function classify(s, lam, anti) {
    var m = mOf(s, lam, anti), r = Math.round(m * 2) / 2;
    if (Math.abs(m - r) > 0.06) return { kind: 'mid', m: m, text: '介于加强与减弱之间' };
    return r % 1 === 0 ? { kind: 'strong', m: r, text: '振动加强' } : { kind: 'weak', m: r, text: '振动减弱' };
  }
  // P 点合振动的振幅：√(A₁² + A₂² + 2A₁A₂cos2πm)
  function ampAt(s, lam, anti, A1, A2) {
    var c = Math.cos(TAU * mOf(s, lam, anti));
    return Math.sqrt(Math.max(0, A1 * A1 + A2 * A2 + 2 * A1 * A2 * c));
  }
  // 两波源连线上（不含波源）振动加强点 / 减弱点的个数：|r₁ − r₂| < d 上 m 取整数 / 半整数的点
  function countOnLine(d, lam, anti, kind) {
    var n = 0, lim = d / lam;
    for (var j = -100; j <= 100; j++) {
      var m = kind === 'strong' ? j : j + 0.5, s = (m - (anti ? 0.5 : 0));   // s 以 λ 为单位
      if (Math.abs(s) < lim - 1e-9) n++;
    }
    return n;
  }
  // 满足 r₁ − r₂ = s 的点组成的双曲线（一支），焦点为两波源。返回点列 [[x, y]…]，覆盖 |y| ≤ yMax
  function hyperbola(s, d, yMax, n) {
    n = n || 80;
    var a = s / 2, c = d / 2, pts = [], i;
    if (Math.abs(a) >= c - 1e-9) return pts;
    var b = Math.sqrt(c * c - a * a), uMax = Math.asinh(yMax / b);   // a = 0 时 cosh 项为 0，即中垂线
    for (i = 0; i <= n; i++) {
      var u = -uMax + 2 * uMax * i / n;
      pts.push([a * Math.cosh(u), b * Math.sinh(u)]);   // a > 0 在右支（离 S₂ 近）
    }
    return pts;
  }
  // 加强线 / 减弱线对应的 s 值（cm），按 |s| 从小到大
  function lineValues(d, lam, anti, kind) {
    var out = [];
    for (var j = -60; j <= 60; j++) {
      var m = kind === 'strong' ? j : j + 0.5, s = (m - (anti ? 0.5 : 0)) * lam;
      if (Math.abs(s) < d - 1e-6) out.push(s);
    }
    return out.sort(function (p, q) { return Math.abs(p) - Math.abs(q); });
  }
  // 某时刻一个波源发出的波峰 / 波谷所在圆的半径（≤ rMax）。ph 为波源当前相位 ωt + φ
  function crestRadii(ph, lam, rMax, trough) {
    // 波峰：ωt − kr + φ = π/2 + 2πn → r = λ(ph − π/2)/2π − nλ；波谷再差 λ/2
    var r0 = lam * (ph - Math.PI / 2) / TAU + (trough ? lam / 2 : 0);
    r0 = ((r0 % lam) + lam) % lam;
    var out = [];
    for (var r = r0; r <= rMax; r += lam) out.push(r);
    return out;
  }
  // 以 (−d/2, 0)、(d/2, 0) 为圆心，半径 r1、r2 的两圆交点
  function circleX(r1, r2, d) {
    var x = (r1 * r1 - r2 * r2) / (2 * d), h2 = r1 * r1 - (x + d / 2) * (x + d / 2);
    if (h2 < 0) return [];
    var h = Math.sqrt(h2);
    return h < 1e-9 ? [[x, 0]] : [[x, h], [x, -h]];
  }

  // 干涉波场：spec { x0, y0（左下角，cm）, cell（cm）, cols, rows, d, srcs: [{ x, A, lam, phi }] }
  // 每个波源一份复振幅（便于两波源频率不同时分别乘各自的 e^{iωt}）
  function interfField(spec) {
    var n = spec.cols * spec.rows, comps = [];
    spec.srcs.forEach(function (s) {
      var re = new Float32Array(n), im = new Float32Array(n), k = TAU / s.lam;
      for (var j = 0; j < spec.rows; j++) {
        var y = spec.y0 + (j + 0.5) * spec.cell;
        for (var i = 0; i < spec.cols; i++) {
          var x = spec.x0 + (i + 0.5) * spec.cell, r = Math.hypot(x - s.x, y), p = s.phi - k * r, idx = j * spec.cols + i;
          re[idx] = s.A * Math.cos(p); im[idx] = s.A * Math.sin(p);
        }
      }
      comps.push({ re: re, im: im, w: TAU * freq(s.lam) });
    });
    return { cols: spec.cols, rows: spec.rows, comps: comps };
  }

  // ---------- 衍射 ----------
  // 宽 a 的缝（|y| < a/2，在 x = 0）在 (x, y)（x > 0）处产生的复振幅，入射平面波 e^{−ikx} 在缝处振幅为 1。
  // 二维瑞利—索末菲公式：U = Σ dy·e^{−i(kr − π/4)}·(x/r)/√(λr)；缝很宽时远离边缘处趋于 e^{−ikx}
  function apertureAt(x, y, a, lam, nPts) {
    var k = TAU / lam, dy = a / nPts, re = 0, im = 0;
    for (var j = 0; j < nPts; j++) {
      var yj = -a / 2 + (j + 0.5) * dy, r = Math.max(Math.hypot(x, y - yj), dy * 0.7);
      var g = dy * (x / r) / Math.sqrt(lam * r), p = -(k * r - Math.PI / 4);
      re += g * Math.cos(p); im += g * Math.sin(p);
    }
    return [re, im];
  }
  function apertureN(a, lam) { return clamp(Math.ceil(a / (lam / 5)), 6, 120); }
  // 衍射波场：spec { x0, y0, cell, cols, rows, a, lam, obj: 'slit'|'block' }
  // 缝：挡板左侧是入射波，右侧按缝内各点子波叠加；障碍物：右侧 = 入射波 − 同宽缝的子波（巴比涅原理）
  // mask：0 有水波，1 挡板 / 障碍物
  function diffrField(spec) {
    var n = spec.cols * spec.rows, re = new Float32Array(n), im = new Float32Array(n), mask = new Uint8Array(n);
    var k = TAU / spec.lam, a = spec.a, nPts = apertureN(a, spec.lam), half = spec.cell * 0.75;
    for (var j = 0; j < spec.rows; j++) {
      var y = spec.y0 + (j + 0.5) * spec.cell;
      for (var i = 0; i < spec.cols; i++) {
        var x = spec.x0 + (i + 0.5) * spec.cell, idx = j * spec.cols + i;
        var inGap = Math.abs(y) < a / 2;
        if (Math.abs(x) < half && (spec.obj === 'slit' ? !inGap : inGap)) { mask[idx] = 1; continue; }
        if (x < half) { re[idx] = Math.cos(-k * x); im[idx] = Math.sin(-k * x); continue; }
        var u = apertureAt(x, y, a, spec.lam, nPts);
        if (spec.obj === 'slit') { re[idx] = u[0]; im[idx] = u[1]; }
        else { re[idx] = Math.cos(-k * x) - u[0]; im[idx] = Math.sin(-k * x) - u[1]; }
      }
    }
    return { cols: spec.cols, rows: spec.rows, comps: [{ re: re, im: im, w: TAU * freq(spec.lam) }], mask: mask };
  }
  // 衍射明显程度（教材：缝、孔的宽度或障碍物的尺寸跟波长相差不多，或者比波长更小时，才能观察到明显的衍射现象）
  function diffrLevel(a, lam) {
    var q = a / lam;
    if (q <= 1.05) return { lv: 3, text: '衍射非常明显', tip: '尺寸比波长还小，波几乎以缝（障碍物）为中心向各个方向传播' };
    if (q <= 2.5) return { lv: 2, text: '衍射明显', tip: '尺寸跟波长相差不多，波绕过边缘传到“影子”区域' };
    if (q <= 5) return { lv: 1, text: '有衍射，不太明显', tip: '尺寸比波长大几倍，只有边缘附近的波稍稍弯进影区' };
    return { lv: 0, text: '衍射不明显', tip: '尺寸比波长大得多，波基本沿直线传播，后面留下明显的影区' };
  }

  // ---------- 练习 ----------
  function options(rand, ans, wrong) {
    var o = [ans].concat(wrong.filter(function (w) { return w !== ans; }));
    for (var i = o.length - 1; i > 0; i--) { var j = Math.floor(rand() * (i + 1)); var t = o[i]; o[i] = o[j]; o[j] = t; }
    return o;
  }

  // 波峰波谷图：λ = 1，两同相波源，某时刻波峰圆半径 n + r0、波谷圆 n + r0 + ½（n = 0, 1, 2…）。
  // 选一个交点 M：峰峰（加强，位移 2A）、谷谷（加强，−2A）、峰谷（减弱，0）、加强线上峰谷之间（加强，0）
  function quizPoint(rand) {
    var d = pick(rand, [2, 2.5, 3]), r0 = 0.25, N = 5, cand = { cc: [], tt: [], ct: [], mid: [] };
    function add(key, r1, r2) {
      circleX(r1, r2, d).forEach(function (p) { if (p[1] > 0.6 && p[1] < 4.2 && Math.abs(p[0]) < 3.6) cand[key].push({ x: p[0], y: p[1], r1: r1, r2: r2 }); });
    }
    for (var a = 0; a < N; a++) for (var b = 0; b < N; b++) {
      add('cc', a + r0, b + r0);
      add('tt', a + r0 + 0.5, b + r0 + 0.5);
      add('ct', a + r0, b + r0 + 0.5);
      add('ct', a + r0 + 0.5, b + r0);
      add('mid', a + r0 + 0.25, b + r0 + 0.25);
    }
    var key = pick(rand, ['cc', 'tt', 'ct', 'mid', 'cc', 'ct']), P = pick(rand, cand[key]);
    var strong = key !== 'ct', sub = pick(rand, ['kind', 'disp']);
    var disp = key === 'cc' ? '2A' : key === 'tt' ? '−2A' : '0';
    var where = { cc: '波峰与波峰相遇', tt: '波谷与波谷相遇', ct: '波峰与波谷相遇', mid: '在两条波峰线之间、与两波源的距离差为 ' + f(Math.abs(P.r1 - P.r2)) + 'λ' }[key];
    var q = { type: 'point', sub: sub, d: d, r0: r0, N: N, P: P, key: key, show: { d: d } };
    if (sub === 'kind') {
      q.prompt = '两个振动步调一致、振幅均为 A 的波源 S₁、S₂ 发出的水波，实线表示波峰、虚线表示波谷。图中 M 点是：';
      q.answer = strong ? '振动加强点' : '振动减弱点';
      q.options = ['振动加强点', '振动减弱点'];
      q.explain = 'M 点' + where + '，到两波源的距离差为' + (strong ? '波长的整数倍，两列波引起的振动总是同步，是振动加强点（振幅 2A）。' : '半波长的奇数倍，两列波引起的振动总是相反，是振动减弱点（振幅 0）。') +
        (key === 'mid' ? '注意：它此刻不在波峰也不在波谷，但仍在加强线上。' : '');
    } else {
      q.prompt = '两个振动步调一致、振幅均为 A 的波源 S₁、S₂ 发出的水波，实线表示波峰、虚线表示波谷。图示时刻 M 点的位移为：';
      q.answer = disp;
      q.options = options(rand, disp, ['2A', '−2A', '0', 'A']).slice(0, 4);
      q.explain = 'M 点' + where + '。' + (key === 'cc' ? '两列波都使它位于波峰，此刻位移为 A + A = 2A；它是加强点，半个周期后位移变为 −2A。'
        : key === 'tt' ? '两列波都使它位于波谷，此刻位移为 −2A；它是加强点，振幅为 2A。'
          : key === 'ct' ? '一列波使它在波峰、另一列在波谷，位移为 A − A = 0；它是减弱点，始终静止。'
            : '它在加强线上，是振动加强点（振幅 2A），但此刻两列波都使它处在平衡位置，位移为 0——加强点的位移也会周期性地变为零。');
    }
    if (q.options.length === 4 && q.options.indexOf(q.answer) < 0) q.options[0] = q.answer;
    return q;
  }

  // 由两波源到 P 的距离判断加强 / 减弱，或求振幅
  function quizCalc(rand) {
    var lam = pick(rand, [0.4, 0.5, 0.8, 1, 2]), anti = rand() < 0.35, m = pick(rand, [0, 0.5, 1, 1.5, 2, 2.5, 3]);
    var r2 = lam * pick(rand, [3, 4, 5, 6, 7.5]), r1 = r2 + m * lam, s = r1 - r2;
    var c = classify(s, lam, anti), strong = c.kind === 'strong', sub = pick(rand, ['judge', 'amp']);
    var A1 = pick(rand, [2, 3, 4]), A2 = sub === 'amp' ? pick(rand, [1, 2]) : A1;
    if (A1 === A2 && sub === 'amp') A1 = A2 + 1;
    var src = anti ? '振动步调相反' : '振动步调一致', q = { type: 'calc', sub: sub, lam: lam, anti: anti, r1: r1, r2: r2, A1: A1, A2: A2, show: { lam: lam, anti: anti } };
    var why = 'Δr = |PS₁ − PS₂| = ' + f(Math.abs(s)) + ' m = ' + f(Math.abs(s) / lam) + 'λ。' +
      (anti ? '两波源振动步调相反，结论与步调一致时恰好相反：Δr 为半波长的奇数倍时加强，为波长的整数倍时减弱。' : '两波源振动步调一致：Δr 为波长的整数倍时加强，为半波长的奇数倍时减弱。');
    if (sub === 'judge') {
      q.prompt = '两个' + src + '的波源 S₁、S₂ 发出波长为 ' + f(lam) + ' m 的波，P 点到 S₁、S₂ 的距离分别为 ' + f(r1) + ' m、' + f(r2) + ' m。P 点是：';
      q.answer = strong ? '振动加强点' : '振动减弱点';
      q.options = ['振动加强点', '振动减弱点'];
      q.explain = why + '所以 P 点是' + q.answer + '。';
    } else {
      q.prompt = '两个' + src + '的波源 S₁、S₂ 发出波长为 ' + f(lam) + ' m 的波，振幅分别为 ' + A1 + ' cm、' + A2 + ' cm。P 点到 S₁、S₂ 的距离分别为 ' + f(r1) + ' m、' + f(r2) + ' m，P 点的振幅为：';
      q.answer = (strong ? A1 + A2 : A1 - A2) + ' cm';
      q.options = options(rand, q.answer, [(A1 + A2) + ' cm', (A1 - A2) + ' cm', '0', A1 + ' cm']).slice(0, 4);
      q.explain = why + (strong ? '加强点振幅为 A₁ + A₂ = ' + (A1 + A2) + ' cm。' : '减弱点振幅为 |A₁ − A₂| = ' + (A1 - A2) + ' cm——两列波振幅不等时，减弱点并不静止。');
    }
    return q;
  }

  // 两波源连线上加强点 / 减弱点的个数
  function quizCount(rand) {
    var lam = pick(rand, [1, 2, 4]), mul = pick(rand, [1.5, 2, 2.5, 3, 3.5]), d = lam * mul, anti = rand() < 0.3, kind = rand() < 0.65 ? 'strong' : 'weak';
    var n = countOnLine(d, lam, anti, kind), name = kind === 'strong' ? '振动加强点' : '振动减弱点';
    // 以 λ 为单位列出 r₁ − r₂ 的取值，正负成对写成 ±
    var vals = [], seen = {};
    lineValues(d, lam, anti, kind).forEach(function (s) {
      var v = Math.abs(s / lam), t = v === 0 ? '0' : '±' + (v === 1 ? '' : f(v)) + 'λ';
      if (!seen[t]) { seen[t] = 1; vals.push(t); }
    });
    var wrong = [n - 2, n - 1, n + 1, n + 2].filter(function (x) { return x >= 0; }).map(String);
    var q = { type: 'count', lam: lam, d: d, anti: anti, kind: kind, show: { d: d, lam: lam, anti: anti } };
    q.prompt = '两个' + (anti ? '振动步调相反' : '振动步调一致') + '的波源 S₁、S₂ 相距 ' + f(d) + ' m，发出的波波长为 ' + f(lam) + ' m。S₁S₂ 连线上（不含 S₁、S₂）共有几个' + name + '？';
    q.answer = String(n);
    q.options = options(rand, q.answer, wrong).slice(0, 4);
    if (q.options.indexOf(q.answer) < 0) q.options[0] = q.answer;
    q.options.sort(function (a, b) { return a - b; });
    q.explain = '连线上的点到两波源的距离差 Δr 在 0 到 ' + f(d) + ' m（' + f(mul) + 'λ）之间。' +
      (kind === 'strong' ? (anti ? '步调相反时加强点满足 Δr = (2k + 1)λ/2' : '加强点满足 Δr = kλ') : (anti ? '步调相反时减弱点满足 Δr = kλ' : '减弱点满足 Δr = (2k + 1)λ/2')) +
      '，r₁ − r₂ 可取 ' + vals.join('、') + '，共 ' + n + ' 个。';
    return q;
  }

  // 哪种情况衍射最明显（四个缝宽 / 障碍物与波长的组合）
  function quizDiffr(rand) {
    var obj = rand() < 0.7 ? 'slit' : 'block', cases = [], used = {};
    var combos = [[0.5, 1], [1, 1], [1, 2], [2, 1], [4, 1], [6, 1.5], [8, 2], [3, 0.5], [6, 4], [10, 2], [2, 3]];
    while (cases.length < 4) {
      var c = pick(rand, combos), key = c.join(',');
      if (used[key]) continue;
      var ratio = c[0] / c[1];
      if (cases.some(function (o) { return Math.abs(o.a / o.lam - ratio) < 0.2; })) continue;
      used[key] = 1; cases.push({ a: c[0], lam: c[1] });
    }
    var best = 0;
    cases.forEach(function (o, i) { if (o.a / o.lam < cases[best].a / cases[best].lam) best = i; });
    var names = ['甲', '乙', '丙', '丁'], what = obj === 'slit' ? '缝宽' : '障碍物宽';
    return {
      type: 'diffr', obj: obj, cases: cases, answer: names[best], options: names.slice(),
      prompt: '水波槽中的平面波遇到' + (obj === 'slit' ? '狭缝' : '障碍物') + '，四种情况的' + what + '与波长如下图。哪种情况衍射现象最明显？',
      explain: '缝、孔的宽度或障碍物的尺寸跟波长相差不多，或者比波长更小时，才能观察到明显的衍射。比较' + what + '与波长之比：' +
        cases.map(function (o, i) { return names[i] + ' ' + f(o.a / o.lam); }).join('，') + '，' + names[best] + '最小，衍射最明显。',
      show: { a: cases[best].a, lam: cases[best].lam, obj: obj }
    };
  }

  var CONCEPTS = [
    { id: 'cond', q: '两列波相遇时能产生稳定干涉图样的条件是：', a: '频率相同、相位差恒定、振动方向相同', o: ['振幅相同', '波速相同即可', '两列波都是横波'], show: { scene: 'interf', s2: 'freq' },
      why: '只有频率相同、相位差恒定（且振动方向相同）的两列波叠加，各点的振动情况才稳定不变，形成加强区与减弱区相互间隔的干涉图样；振幅不等也能干涉，只是减弱点不完全静止。' },
    { id: 'strongdisp', q: '关于两列相干波叠加时的振动加强点，下列说法正确的是：', a: '振幅最大，但位移随时间变化，有时为零', o: ['位移始终最大', '始终处于波峰', '与减弱点的位置不断交换'], show: { scene: 'interf', view: 'wave' },
      why: '加强点的振幅等于两列波振幅之和，它仍在平衡位置附近振动，位移在 +2A 与 −2A 之间周期性变化；加强区和减弱区的位置是固定的。' },
    { id: 'super', q: '两列波相遇后又分开，下列说法正确的是：', a: '各自保持原来的波形继续传播', o: ['振幅都变小', '波速都变大', '合成一列波不再分开'], show: { scene: 'interf', view: 'crest' },
      why: '波的独立传播特性：几列波相遇后仍保持各自的运动特征（频率、波长、振幅、振动方向）继续传播；在相遇区域内，介质质点的位移等于各列波单独引起的位移的矢量和，这就是波的叠加原理。' },
    { id: 'wall', q: '“隔墙有耳”“闻其声而不见其人”说明：', a: '声波的波长较长，容易发生衍射', o: ['声波的速度比光速大', '光波不会发生衍射', '声波能在固体中传播'], show: { scene: 'diffr', a: 6, lam: 4 },
      why: '声波的波长约在 1.7 cm 到 17 m 之间，与门窗、墙的尺寸相近，容易绕过障碍物；可见光波长不到 1 μm，比日常物体小得多，衍射不明显，所以“闻其声而不见其人”。一切波都能发生衍射。' },
    { id: 'more', q: '要使水波通过狭缝时衍射现象更明显，可以：', a: '减小缝宽或减小振源频率', o: ['增大缝宽', '增大振源频率', '增大振源的振幅'], show: { scene: 'diffr', a: 2, lam: 3 },
      why: '缝宽越接近或小于波长，衍射越明显。波速一定时 λ = v/f，减小振源频率可使波长变长；振幅与衍射是否明显无关。' },
    { id: 'all', q: '关于波的衍射，下列说法正确的是：', a: '一切波都能发生衍射，只是有的不明显', o: ['只有横波能发生衍射', '障碍物越大衍射越明显', '只有声波能发生衍射'], show: { scene: 'diffr', a: 10, lam: 1.5 },
      why: '衍射是波特有的现象，横波、纵波、电磁波都能发生；只有当障碍物或缝的尺寸跟波长相差不多或比波长更小时，衍射才明显。' }
  ];
  function quizConcept(rand, avoidId) {
    var c, tries = 0;
    do { c = pick(rand, CONCEPTS); } while (c.id === avoidId && ++tries < 8);
    return { type: 'concept', cid: c.id, show: c.show, answer: c.a, options: options(rand, c.a, c.o), prompt: c.q, explain: c.why };
  }

  var TYPES = ['point', 'calc', 'count', 'diffr', 'concept'];
  function quiz(rand, avoid, only) {
    var gen = { point: quizPoint, calc: quizCalc, count: quizCount, diffr: quizDiffr, concept: quizConcept }, q, tries = 0;
    do {
      var t = only || pick(rand, TYPES);
      q = gen[t](rand, avoid && avoid.cid);
      q.id = q.type + '|' + q.prompt + '|' + (q.P ? q.P.x.toFixed(2) : '') + (q.cases ? JSON.stringify(q.cases) : '');
    } while (avoid && q.id === avoid.id && ++tries < 10);
    return q;
  }

  window.Wave = {
    V: V, LAM_RANGE: LAM_RANGE, D_RANGE: D_RANGE, DLAM_RANGE: DLAM_RANGE, A_RANGE: A_RANGE, SLOW: SLOW, F_DETUNE: F_DETUNE, TYPES: TYPES,
    clamp: clamp, f: f, freq: freq, mOf: mOf, classify: classify, ampAt: ampAt, countOnLine: countOnLine, hyperbola: hyperbola, lineValues: lineValues,
    crestRadii: crestRadii, circleX: circleX, interfField: interfField,
    apertureAt: apertureAt, apertureN: apertureN, diffrField: diffrField, diffrLevel: diffrLevel, quiz: quiz
  };
})();
