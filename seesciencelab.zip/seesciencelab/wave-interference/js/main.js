(function () {
  var Wv = window.Wave, D = window.WaveDraw, f = Wv.f;
  var $ = function (id) { return document.getElementById(id); };
  var qa = function (sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); };
  var NAME = '波的干涉和衍射';

  var state = {
    scene: 'interf',
    // 干涉：波长、波源间距（cm）、S₂ 反相、S₂ 状态、显示方式、加强线、P 点（世界坐标 cm）
    lam: 2.4, d: 8, anti: false, s2: 'same', view: 'wave', lines: false, P: { x: 3.2, y: 9 },
    // 衍射：波长、缝宽 / 障碍物宽（cm）、狭缝或障碍物、显示方式、几何影区
    dlam: 2, a: 3, obj: 'slit', dview: 'wave', shadow: true,
    t: 0, paused: false,
    quiz: null, quizOnly: null, answered: false, correct: false, choice: null, score: { n: 0, ok: 0 }
  };

  var HINTS = {
    interf: '点击或拖动水面放置 P 点；左右拖动波源 S₁、S₂ 改变间距',
    diffr: '上下拖动缝的边缘（金色圆点）改变缝宽，比较缝宽与波长',
    quiz: '波的干涉和衍射 · 判断练习'
  };
  var S2S = { same: '振幅相同', half: '振幅一半', freq: '频率不同', off: '停振' };

  var stage = $('stage'), panel = $('panel'), cv = $('view');
  var view = D.View(cv);
  function setSeg(attr, val) { qa('[data-' + attr + ']').forEach(function (b) { b.classList.toggle('on', b.dataset[attr] === String(val)); }); }

  // ---------- 场景 ----------
  qa('[data-scene]').forEach(function (b) {
    b.addEventListener('click', function () { setScene(b.dataset.scene); Analytics.track(NAME, '场景', b.textContent); });
  });
  function setScene(sc) {
    state.scene = sc;
    if (sc === 'quiz' && !state.quiz) newQuiz();
    $('rName').className = '';
    syncUI();
  }

  // ---------- 控件 ----------
  function bindSeg(attr, apply, track) {
    qa('[data-' + attr + ']').forEach(function (b) {
      b.addEventListener('click', function () { apply(b.dataset[attr]); syncUI(); Analytics.track(NAME, track, b.textContent); });
    });
  }
  bindSeg('phase', function (v) { state.anti = v === 'anti'; }, '波源步调');
  bindSeg('s2', function (v) { state.s2 = v; }, 'S₂');
  bindSeg('view', function (v) { state.view = v; }, '显示');
  bindSeg('obj', function (v) { state.obj = v; }, '障碍');
  bindSeg('dview', function (v) { state.dview = v; }, '衍射显示');
  function bindSlider(id, get, set) {
    var el = $(id);
    el.addEventListener('input', function () { set(parseFloat(el.value)); });
    el.addEventListener('change', function () { Analytics.track(NAME, '滑块', id); });
    return { el: el, get: get };
  }
  var sliders = [
    bindSlider('lam', function () { return state.lam; }, function (x) { state.lam = x; }),
    bindSlider('d', function () { return state.d; }, function (x) { state.d = x; }),
    bindSlider('dlam', function () { return state.dlam; }, function (x) { state.dlam = x; }),
    bindSlider('a', function () { return state.a; }, function (x) { state.a = x; })
  ];
  $('lines').addEventListener('change', function () { state.lines = $('lines').checked; Analytics.track(NAME, '加强线', String(state.lines)); });
  $('probeOn').addEventListener('change', function () { state.P = $('probeOn').checked ? { x: 3.2, y: 9 } : null; Analytics.track(NAME, 'P 点', String(!!state.P)); });
  $('shadow').addEventListener('change', function () { state.shadow = $('shadow').checked; Analytics.track(NAME, '几何影区', String(state.shadow)); });
  function togglePause() { state.paused = !state.paused; syncUI(); }
  qa('.pause').forEach(function (b) { b.addEventListener('click', togglePause); });

  // ---------- 画布拖动 ----------
  var drag = null;
  function local(e) { var r = cv.getBoundingClientRect(); return { x: e.clientX - r.left, y: e.clientY - r.top }; }
  function inRect(p, T) { return T && p.x >= T.x && p.x <= T.x + T.w && p.y >= T.y && p.y <= T.y + T.h; }
  function hitSource(g, p) {
    if (!g.S) return -1;
    for (var i = 0; i < g.S.length; i++) if (Math.hypot(p.x - g.S[i].x, p.y - g.S[i].y) < 16) return i;
    return -1;
  }
  function hitEdge(g, p) {
    return Math.abs(p.x - g.edges[0].x) < 22 && p.y > g.edges[0].y - 16 && p.y < g.edges[1].y + 16 &&
      (Math.abs(p.y - g.edges[0].y) < 16 || Math.abs(p.y - g.edges[1].y) < 16 || Math.abs(p.x - g.edges[0].x) < 12);
  }
  function apply(p) {
    var g = view.geo(), fr = g.fr;
    if (drag.kind === 'src') state.d = Wv.clamp(Math.round(2 * Math.abs(fr.wx(p.x)) * 10) / 10, Wv.D_RANGE[0], Wv.D_RANGE[1]);
    else if (drag.kind === 'P') {
      var x = fr.wx(Wv.clamp(p.x, g.T.x + 4, g.T.x + g.T.w - 4)), y = fr.wy(Wv.clamp(p.y, g.T.y + 4, g.T.y + g.T.h - 4));
      state.P = snapP(x, y);
    } else if (drag.kind === 'edge') state.a = Wv.clamp(Math.round(2 * Math.abs(fr.wy(p.y)) * 10) / 10, Wv.A_RANGE[0], Wv.A_RANGE[1]);
  }
  // P 点靠近加强线 / 减弱线时吸附到线上，方便读出整数倍
  function snapP(x, y) {
    var d = state.d, r1 = Math.hypot(x + d / 2, y), r2 = Math.hypot(x - d / 2, y), m = Wv.mOf(r1 - r2, state.lam, state.anti);
    var mr = Math.round(m * 2) / 2;
    if (Math.abs(m - mr) > 0.05 || state.s2 === 'freq' || state.s2 === 'off' || Math.abs(y) < 0.3) return { x: x, y: y };
    var s = (mr - (state.anti ? 0.5 : 0)) * state.lam, a = s / 2, c = d / 2;
    if (Math.abs(a) >= c) return { x: x, y: y };
    // 同一 y 处双曲线上的 x：x²/a² − y²/b² = 1
    var b2 = c * c - a * a, xs = a === 0 ? 0 : (a > 0 ? 1 : -1) * Math.abs(a) * Math.sqrt(1 + y * y / b2);
    return { x: xs, y: y };
  }
  cv.addEventListener('pointerdown', function (e) {
    if (e.button !== 0) return;
    var p = local(e), g = view.geo();
    if (!g || g.scene === 'quiz') return;
    if (g.scene === 'interf') {
      var i = hitSource(g, p);
      if (i >= 0) drag = { kind: 'src' };
      else if (inRect(p, g.T)) { drag = { kind: 'P' }; if (!state.P) state.P = { x: 0, y: 0 }; }
      else return;
    } else {
      if (hitEdge(g, p)) drag = { kind: 'edge' };
      else return;
    }
    apply(p);
    syncUI();
    try { cv.setPointerCapture(e.pointerId); } catch (err) { /* 合成事件 */ }
    Analytics.track(NAME, '拖动', drag.kind);
  });
  cv.addEventListener('pointermove', function (e) {
    var p = local(e);
    if (!drag) {
      var g = view.geo(), c = '';
      if (g && g.scene === 'interf') c = hitSource(g, p) >= 0 ? 'ew-resize' : inRect(p, g.T) ? 'crosshair' : '';
      if (g && g.scene === 'diffr' && hitEdge(g, p)) c = 'ns-resize';
      cv.style.cursor = c;
      return;
    }
    apply(p);
  });
  function endDrag(e) {
    if (!drag) return;
    drag = null;
    if (cv.hasPointerCapture(e.pointerId)) cv.releasePointerCapture(e.pointerId);
  }
  cv.addEventListener('pointerup', endDrag);
  cv.addEventListener('pointercancel', endDrag);

  // ---------- 练习 ----------
  function newQuiz() {
    state.quiz = Wv.quiz(Math.random, state.quiz, state.quizOnly);
    state.answered = false; state.choice = null;
    var box = $('quizOpts');
    box.innerHTML = '';
    state.quiz.options.forEach(function (o) {
      var b = document.createElement('button');
      b.className = 'small';
      b.textContent = o;
      b.addEventListener('click', function () { answer(o); });
      box.appendChild(b);
    });
    box.classList.toggle('one', state.quiz.options.some(function (o) { return o.length > 14; }));
    syncUI();
  }
  function answer(o) {
    if (state.answered) return;
    state.answered = true;
    state.choice = o;
    state.correct = o === state.quiz.answer;
    state.score.n++; if (state.correct) state.score.ok++;
    Analytics.track(NAME, '练习', state.quiz.type + (state.correct ? ' 对' : ' 错'));
    syncUI();
  }
  $('nextQ').addEventListener('click', newQuiz);
  // 在双曲线 r₁ − r₂ = s 上取 y 处的点
  function pointOn(s, y) {
    var a = s / 2, c = state.d / 2;
    if (Math.abs(a) >= c) return { x: 0, y: y };
    var b2 = c * c - a * a;
    return { x: a === 0 ? 0 : a * Math.sqrt(1 + y * y / b2), y: y };
  }
  // 把题目的条件搬到模型里（长度按 λ 换算到水波槽里的尺寸）
  $('showQ').addEventListener('click', function () {
    var q = state.quiz, L0 = 2.4;
    state.s2 = 'same'; state.anti = false; state.lines = true; state.lam = L0;
    if (q.type === 'point') {
      state.view = 'crest'; state.d = q.d * L0; state.P = { x: q.P.x * L0, y: q.P.y * L0 };
    } else if (q.type === 'calc') {
      state.view = 'amp'; state.d = 8; state.anti = q.anti; if (q.sub === 'amp') state.s2 = 'half';
      state.P = pointOn((q.r1 - q.r2) / q.lam * L0, 9);
    } else if (q.type === 'count') {
      state.view = 'amp'; state.d = Wv.clamp(q.d / q.lam * L0, Wv.D_RANGE[0], Wv.D_RANGE[1]); state.anti = q.anti; state.P = null;
    } else {
      var sh = q.show || {};
      if (q.type === 'diffr' || sh.scene === 'diffr') {
        state.dlam = Wv.clamp(sh.lam, Wv.DLAM_RANGE[0], Wv.DLAM_RANGE[1]); state.a = Wv.clamp(sh.a, Wv.A_RANGE[0], Wv.A_RANGE[1]);
        state.obj = sh.obj || 'slit'; state.dview = 'wave';
        setScene('diffr'); return;
      }
      state.view = sh.view || 'wave'; state.d = 8; if (sh.s2) { state.s2 = sh.s2; state.lines = false; }
    }
    setScene('interf');
  });

  // ---------- 面板 ----------
  $('panelToggle').addEventListener('click', function () { panel.classList.toggle('collapsed'); });
  if (window.matchMedia('(max-width: 760px)').matches) panel.classList.add('collapsed');
  window.addEventListener('keydown', function (e) {
    var tg = e.target.tagName;
    if (tg === 'INPUT' || tg === 'SELECT' || tg === 'BUTTON' || tg === 'TEXTAREA') return;
    if (e.code === 'Space' && state.scene !== 'quiz') { e.preventDefault(); togglePause(); }
  });

  function syncUI() {
    var sc = state.scene;
    setSeg('scene', sc);
    qa('[data-for]').forEach(function (el) { el.hidden = el.dataset.for.split(' ').indexOf(sc) < 0; });
    $('hint').textContent = HINTS[sc];
    setSeg('phase', state.anti ? 'anti' : 'same');
    setSeg('s2', state.s2);
    setSeg('view', state.view);
    setSeg('obj', state.obj);
    setSeg('dview', state.dview);
    $('lines').checked = state.lines; $('probeOn').checked = !!state.P; $('shadow').checked = state.shadow;
    qa('.pause').forEach(function (b) { b.textContent = state.paused ? '▶ 继续' : '❚❚ 暂停'; });
    var q = state.quiz;
    if (q) {
      $('quizQ').textContent = q.prompt;
      qa('#quizOpts button').forEach(function (b) {
        b.disabled = state.answered;
        b.classList.toggle('on', state.answered && b.textContent === q.answer);
        b.classList.toggle('no', state.answered && b.textContent === state.choice && !state.correct);
      });
      $('quizMsg').innerHTML = !state.answered ? ''
        : '<b class="' + (state.correct ? 'ok">✓ 答对了' : 'bad">✗ 应选「' + q.answer + '」') + '</b>' + q.explain;
      $('nextQ').textContent = state.answered ? '下一题 →' : '换一题';
      $('showQ').hidden = !state.answered;
    }
  }

  // ---------- 读数 ----------
  var lastText = {};
  function setText(id, s) { if (lastText[id] !== s) { lastText[id] = s; $(id).textContent = s; } }
  function rows(list) {
    for (var k = 1; k <= 5; k++) {
      var r = list[k - 1] || ['', ''];
      setText('d' + k, r[0]); setText('r' + k, r[1]);
      $('d' + k).hidden = $('r' + k).hidden = !r[0];
    }
  }
  function waveText(lam) { return 'λ = ' + f(lam, 1) + ' cm，f = v/λ = ' + f(Wv.freq(lam), 1) + ' Hz（v = ' + Wv.V + ' cm/s）'; }

  function readInterf() {
    var d = state.d, lam = state.lam, P = state.P, list = [], s2 = state.s2, A2 = s2 === 'half' ? 0.5 : 1;
    setText('rKind', s2 === 'off' ? '单个波源' : s2 === 'freq' ? '不相干' : state.anti ? '步调相反' : '步调一致');
    list.push(['波', waveText(lam)]);
    var nS = Wv.countOnLine(d, lam, state.anti, 'strong'), nW = Wv.countOnLine(d, lam, state.anti, 'weak');
    if (s2 === 'off') {
      setText('rName', '只有一列波');
      setText('rTip', 'S₂ 停振，水面上只有 S₁ 发出的圆形波，各点振幅相同，没有加强区和减弱区。');
    } else if (s2 === 'freq') {
      setText('rName', '没有稳定的干涉图样');
      setText('rTip', '两列波频率不同，相位差不断变化：某处一会儿加强、一会儿减弱，看不到固定的加强区和减弱区。');
    } else if (!P) {
      setText('rName', '两列相干波叠加');
      setText('rTip', '频率相同、相位差恒定的两列波叠加，加强区与减弱区相互间隔且位置固定——这就是波的干涉。');
    }
    if (P && s2 !== 'off') {
      var r1 = Math.hypot(P.x + d / 2, P.y), r2 = Math.hypot(P.x - d / 2, P.y), s = r1 - r2;
      list.push(['P 到波源', 'PS₁ = ' + f(r1, 2) + ' cm，PS₂ = ' + f(r2, 2) + ' cm']);
      list.push(['波程差', 'Δr = |PS₁ − PS₂| = ' + f(Math.abs(s), 2) + ' cm = ' + f(Math.abs(s) / lam, 2) + 'λ']);
      if (s2 !== 'freq') {
        var c = Wv.classify(s, lam, state.anti), amp = Wv.ampAt(s, lam, state.anti, 1, A2);
        setText('rName', 'P 点：' + (c.kind === 'mid' ? c.text : c.text + '点'));
        $('rName').className = c.kind === 'strong' ? 'gold' : c.kind === 'weak' ? 'violet' : '';
        var rule = state.anti ? '（步调相反：Δr = (2k + 1)λ/2 加强，Δr = kλ 减弱）' : '（Δr = kλ 加强，Δr = (2k + 1)λ/2 减弱）';
        setText('rTip', c.kind === 'strong' ? '两列波在 P 点引起的振动总是同步，振幅为两者之和；P 点的位移仍随时间变化，有时为零。' + rule
          : c.kind === 'weak' ? (A2 < 1 ? '两列波在 P 点引起的振动总是相反，振幅为两者之差；振幅不等，减弱点并不静止。' : '两列波在 P 点引起的振动总是相反，互相抵消，P 点几乎不动。') + rule
            : '波程差不是半波长的整数倍，P 点的振幅介于最大与最小之间。' + rule);
        list.push(['P 的振幅', f(amp, 2) + 'A' + (c.kind === 'strong' ? '（A₁ + A₂）' : c.kind === 'weak' ? '（|A₁ − A₂|）' : '') + '，单列波振幅 A' + (A2 < 1 ? '，S₂ 为 0.5A' : '')]);
      } else $('rName').className = '';
    } else $('rName').className = '';
    if (s2 === 'same' || s2 === 'half') list.push(['S₁S₂ 连线上', '加强点 ' + nS + ' 个，减弱点 ' + nW + ' 个（d = ' + f(d, 1) + ' cm = ' + f(d / lam, 2) + 'λ，不含波源）']);
    rows(list);
  }

  function readDiffr() {
    var lv = Wv.diffrLevel(state.a, state.dlam);
    setText('rName', lv.text);
    $('rName').className = lv.lv >= 2 ? 'gold' : '';
    setText('rKind', state.obj === 'slit' ? '狭缝' : '障碍物');
    setText('rTip', lv.tip + '。');
    rows([
      ['波', waveText(state.dlam)],
      [state.obj === 'slit' ? '缝宽' : '障碍物宽', 'a = ' + f(state.a, 1) + ' cm'],
      ['比较', 'a / λ = ' + f(state.a / state.dlam, 2) + (state.a <= state.dlam * 1.05 ? '（a ≤ λ）' : '')],
      ['条件', '缝、孔或障碍物的尺寸跟波长相差不多或比波长小，衍射明显']
    ]);
  }

  function readQuiz() {
    var q = state.quiz, sc = state.score;
    setText('rName', !state.answered ? '判断练习' : state.correct ? '✓ 答对了' : '✗ 答错了');
    $('rName').className = !state.answered ? '' : state.correct ? 'ok' : 'bad';
    setText('rKind', '得分 ' + sc.ok + ' / ' + sc.n);
    setText('rTip', state.answered ? q.explain : q.prompt);
    rows([]);
  }

  // ---------- 尺寸与主循环 ----------
  function resize() { view.resize(stage.clientWidth, stage.clientHeight); }
  new ResizeObserver(resize).observe(stage);

  // 支持 ?scene=interf|diffr|quiz；干涉 &lam=1.2~4（cm）、&d=2~12（cm）、&anti=1、&s2=same|half|freq|off、&view=wave|crest|amp、
  // &lines=1、&p=x,y（P 点 cm，none 不显示）；衍射 &lam=0.8~4、&a=0.5~12（cm）、&obj=slit|block、&view=wave|amp、&shadow=0；
  // &pause=1 暂停；练习 &q=point|calc|count|diffr|concept
  var qs = new URLSearchParams(location.search);
  function num(k, lo, hi) { var x = parseFloat(qs.get(k)); return isFinite(x) && x >= lo && x <= hi ? x : null; }
  var x;
  if (HINTS[qs.get('scene')]) state.scene = qs.get('scene');
  var dif = state.scene === 'diffr';
  if (dif) { if ((x = num('lam', Wv.DLAM_RANGE[0], Wv.DLAM_RANGE[1])) != null) state.dlam = x; }
  else if ((x = num('lam', Wv.LAM_RANGE[0], Wv.LAM_RANGE[1])) != null) state.lam = x;
  if ((x = num('d', Wv.D_RANGE[0], Wv.D_RANGE[1])) != null) state.d = x;
  if (qs.get('anti') === '1') state.anti = true;
  if (S2S[qs.get('s2')]) state.s2 = qs.get('s2');
  var vw = qs.get('view');
  if (dif && (vw === 'wave' || vw === 'amp')) state.dview = vw;
  else if (vw === 'wave' || vw === 'crest' || vw === 'amp') state.view = vw;
  if (qs.get('lines') === '1') state.lines = true;
  state.P = pointOn(state.lam, 9);   // 默认放在 Δr = λ 的加强线上
  if (qs.get('p') === 'none') state.P = null;
  else if (qs.get('p')) {
    var pp = qs.get('p').split(',').map(parseFloat);
    if (pp.length === 2 && isFinite(pp[0]) && isFinite(pp[1]) && Math.abs(pp[0]) <= 20 && pp[1] >= -8 && pp[1] <= 20) state.P = { x: pp[0], y: pp[1] };
  }
  if ((x = num('a', Wv.A_RANGE[0], Wv.A_RANGE[1])) != null) state.a = x;
  if (qs.get('obj') === 'block' || qs.get('obj') === 'slit') state.obj = qs.get('obj');
  if (qs.get('shadow') === '0') state.shadow = false;
  if (qs.get('pause') === '1') { state.paused = true; state.t = 0.37; }
  if (Wv.TYPES.indexOf(qs.get('q')) >= 0) state.quizOnly = qs.get('q');

  resize();
  setScene(state.scene);

  var lastT = performance.now();
  function frame(now) {
    var dt = Math.min((now - lastT) / 1000, 0.1);
    lastT = now;
    if (!state.paused) state.t += dt / Wv.SLOW;   // 模拟时间（真实 s），动画放慢 SLOW 倍
    var sc = state.scene;
    sliders.forEach(function (s) { if (document.activeElement !== s.el) s.el.value = s.get(); });
    setText('lamOut', f(state.lam, 1) + ' cm');
    setText('dOut', f(state.d, 1) + ' cm');
    setText('dlamOut', f(state.dlam, 1) + ' cm');
    setText('aOut', f(state.a, 1) + ' cm');

    if (sc === 'interf') {
      view.drawInterf({ lam: state.lam, d: state.d, anti: state.anti, s2: state.s2, view: state.view, lines: state.lines, P: state.P, t: state.t });
      readInterf();
    } else if (sc === 'diffr') {
      view.drawDiffr({ lam: state.dlam, a: state.a, obj: state.obj, view: state.dview, shadow: state.shadow, t: state.t });
      readDiffr();
    } else {
      view.drawQuiz(state.quiz, state.answered, { quizH: $('quizBar').offsetHeight });
      readQuiz();
    }
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // 调试用
  window.__model = {
    state: state, setScene: setScene, newQuiz: newQuiz, syncUI: syncUI,
    setP: function (px, py) { state.P = { x: px, y: py }; },
    answer: function (o) { answer(o == null ? state.quiz.answer : o); }
  };
})();
