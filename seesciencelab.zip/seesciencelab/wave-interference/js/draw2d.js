// 2D 绘制：水波槽俯视图（瞬时水面 / 波峰波谷 / 振幅分布）、加强线与减弱线、P 点与振动图像，
// 狭缝与障碍物的衍射、练习题画面
// 世界坐标 cm、y 向上；波场按网格（每格 3–4 px）预先算出复振幅，每帧只算 Im(C·e^{iωt})，网格第 0 行在最下面
(function () {
  var W = window.Wave, f = W.f;
  var MUTED = '#8d99ab', TEXT = '#e6ebf2', LINE = '#2a3446', BAR = '#5b6a85', GOLD = '#ffc94a';
  var C1 = '#4fc3f7', C2 = '#ff7a59', WEAKC = '#c9a7ff';
  var FONT = '-apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", sans-serif';
  var TAU = Math.PI * 2;

  function font(px, w) { return (w ? w + ' ' : '') + px + 'px ' + FONT; }
  function label(ctx, s, x, y, o) {
    o = o || {};
    ctx.font = font(o.size || 12, o.bold ? 600 : null);
    ctx.textAlign = o.align || 'center'; ctx.textBaseline = o.base || 'middle';
    ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(5,7,13,.85)'; ctx.strokeText(s, x, y);
    ctx.fillStyle = o.color || TEXT; ctx.fillText(s, x, y);
  }
  function line(ctx, x1, y1, x2, y2, color, o) {
    o = o || {};
    ctx.strokeStyle = color; ctx.lineWidth = o.width || 1.2; ctx.setLineDash(o.dash || []);
    ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke(); ctx.setLineDash([]);
  }
  function head(ctx, x, y, a, size, color) {
    ctx.fillStyle = color; ctx.beginPath(); ctx.moveTo(x, y);
    ctx.lineTo(x - size * Math.cos(a - 0.45), y - size * Math.sin(a - 0.45));
    ctx.lineTo(x - size * Math.cos(a + 0.45), y - size * Math.sin(a + 0.45)); ctx.closePath(); ctx.fill();
  }
  // 尺寸标注：两端带箭头的线段，文字在旁边
  function dim(ctx, x1, y1, x2, y2, text, color, o) {
    o = o || {};
    color = color || MUTED;
    var a = Math.atan2(y2 - y1, x2 - x1), len = Math.hypot(x2 - x1, y2 - y1);
    line(ctx, x1, y1, x2, y2, color);
    if (len > 12) { head(ctx, x2, y2, a, 6, color); head(ctx, x1, y1, a + Math.PI, 6, color); }
    if (text) label(ctx, text, (x1 + x2) / 2 + (o.dx || 0), (y1 + y2) / 2 + (o.dy == null ? -10 : o.dy), { color: o.tc || color, size: o.size || 12, align: o.align });
  }
  // λ 的倍数写成 0、λ/2、λ、3λ/2、2λ…
  function lamText(v) {
    v = Math.abs(v);
    var h = Math.round(v * 2);
    if (h === 0) return '0';
    if (h % 2) return (h === 1 ? '' : h) + 'λ/2';
    return (h === 2 ? '' : h / 2) + 'λ';
  }

  // ---------- 波场着色 ----------
  var LO = [2, 10, 24], MID = [22, 58, 94], HI = [178, 230, 255], ALO = [4, 8, 18], AHI = [96, 190, 240], BARC = [91, 106, 133];
  function FieldPainter() {
    var cv = document.createElement('canvas'), cx = cv.getContext('2d'), img = null;
    // F：{ cols, rows, comps: [{ re, im, w }], mask? }；mode：'wave' 瞬时位移 | 'amp' 振幅；o：{ zmax, gamma }
    function paint(F, t, mode, o) {
      if (cv.width !== F.cols || cv.height !== F.rows || !img) { cv.width = F.cols; cv.height = F.rows; img = cx.createImageData(F.cols, F.rows); }
      var d = img.data, comps = F.comps, nc = comps.length, sn = [], cs = [], c, zmax = o.zmax || 1, gm = o.gamma || 1, mask = F.mask;
      for (c = 0; c < nc; c++) { sn[c] = Math.sin(comps[c].w * t); cs[c] = Math.cos(comps[c].w * t); }
      for (var j = 0; j < F.rows; j++) {
        for (var i = 0; i < F.cols; i++) {
          var idx = j * F.cols + i, p = ((F.rows - 1 - j) * F.cols + i) * 4, col, v, k;
          if (mask && mask[idx]) { d[p] = BARC[0]; d[p + 1] = BARC[1]; d[p + 2] = BARC[2]; d[p + 3] = 255; continue; }
          if (mode === 'amp') {
            var sr = 0, si = 0;
            for (c = 0; c < nc; c++) { var re = comps[c].re[idx], im = comps[c].im[idx]; sr += re * cs[c] - im * sn[c]; si += re * sn[c] + im * cs[c]; }
            v = Math.min(1, Math.pow(Math.sqrt(sr * sr + si * si) / zmax, gm));
            for (k = 0; k < 3; k++) d[p + k] = ALO[k] + (AHI[k] - ALO[k]) * v;
          } else {
            v = 0;
            for (c = 0; c < nc; c++) v += comps[c].re[idx] * sn[c] + comps[c].im[idx] * cs[c];
            v = Math.max(-1, Math.min(1, v / zmax));
            if (gm !== 1) v = (v < 0 ? -1 : 1) * Math.pow(Math.abs(v), gm);
            col = v < 0 ? LO : HI; v = Math.abs(v);
            for (k = 0; k < 3; k++) d[p + k] = MID[k] + (col[k] - MID[k]) * v;
          }
          d[p + 3] = 255;
        }
      }
      cx.putImageData(img, 0, 0);
      return cv;
    }
    return { paint: paint };
  }

  function View(canvas) {
    var ctx = canvas.getContext('2d'), Wd = 0, H = 0, dpr = 1, narrow = false, geo = null;
    var painter = FieldPainter(), field = null, fieldKey = '', lastBuild = 0;
    var quizCache = { key: '', fields: [] }, qPainter = FieldPainter();
    function resize(w, h) {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      Wd = w; H = h; narrow = w < 640;
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
      canvas.style.width = w + 'px'; canvas.style.height = h + 'px';
      fieldKey = '';
    }
    function bg() {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      var g = ctx.createLinearGradient(0, 0, 0, H);
      g.addColorStop(0, '#04060c'); g.addColorStop(1, '#0a1120');
      ctx.fillStyle = g; ctx.fillRect(0, 0, Wd, H);
    }
    function area(bottomExtra) {
      var t0 = narrow ? 84 : 44, bottom = (narrow ? 44 : 50) + (bottomExtra || 0);
      return { x: 12, y: t0, w: Wd - 24, h: Math.max(160, H - t0 - bottom) };
    }
    // 世界坐标 ↔ 屏幕：原点在 (ox, oy)，s 像素 / cm
    function frame(T, s, ox, oy) {
      return {
        T: T, s: s, ox: ox, oy: oy,
        X: function (x) { return ox + x * s; }, Y: function (y) { return oy - y * s; },
        wx: function (px) { return (px - ox) / s; }, wy: function (py) { return (oy - py) / s; }
      };
    }
    // 按网格算波场；参数变化太频繁（拖动滑块）时 70 ms 内最多重算一次
    function ensureField(key, build) {
      if (key === fieldKey && field) return;
      var now = performance.now();
      if (field && now - lastBuild < 70) return;
      field = build(); fieldKey = key; lastBuild = performance.now();
    }
    function blit(cv, T) {
      ctx.save(); ctx.imageSmoothingEnabled = true; ctx.drawImage(cv, T.x, T.y, T.w, T.h); ctx.restore();
      ctx.strokeStyle = LINE; ctx.lineWidth = 1; ctx.strokeRect(T.x + 0.5, T.y + 0.5, T.w - 1, T.h - 1);
    }
    function clip(T) { ctx.save(); ctx.beginPath(); ctx.rect(T.x, T.y, T.w, T.h); ctx.clip(); }
    function polyline(fr, pts, color, o) {
      if (pts.length < 2) return;
      o = o || {};
      ctx.strokeStyle = color; ctx.lineWidth = o.width || 1.4; ctx.setLineDash(o.dash || []); ctx.globalAlpha = o.alpha == null ? 1 : o.alpha;
      ctx.beginPath();
      pts.forEach(function (p, i) { var x = fr.X(p[0]), y = fr.Y(p[1]); if (i) ctx.lineTo(x, y); else ctx.moveTo(x, y); });
      ctx.stroke(); ctx.setLineDash([]); ctx.globalAlpha = 1;
    }
    function circle(fr, x, y, r, color, o) {
      o = o || {};
      ctx.strokeStyle = color; ctx.lineWidth = o.width || 1.3; ctx.setLineDash(o.dash || []); ctx.globalAlpha = o.alpha == null ? 1 : o.alpha;
      ctx.beginPath(); ctx.arc(fr.X(x), fr.Y(y), r * fr.s, 0, TAU); ctx.stroke(); ctx.setLineDash([]); ctx.globalAlpha = 1;
    }
    function dot(x, y, r, fill, stroke) {
      ctx.beginPath(); ctx.arc(x, y, r, 0, TAU);
      if (fill) { ctx.fillStyle = fill; ctx.fill(); }
      if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = 1.6; ctx.stroke(); }
    }
    function source(x, y, color, name, z, below) {
      var r = 6 + 2.5 * (z || 0);
      var g = ctx.createRadialGradient(x, y, 1, x, y, 14);
      g.addColorStop(0, 'rgba(255,255,255,.9)'); g.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, 14, 0, TAU); ctx.fill();
      dot(x, y, r, color, '#fff');
      if (name) label(ctx, name, x, y + (below ? 20 : -20), { size: 13, bold: true, color: color });
    }

    // 两波源的加强线（实线）、减弱线（虚线）与上端的波程差标注
    function hyperLines(fr, d, lam, anti, yTop, yBot, labels) {
      var yMax = Math.max(Math.abs(yTop), Math.abs(yBot)) + 2;
      ['weak', 'strong'].forEach(function (kind) {
        var vals = W.lineValues(d, lam, anti, kind), lastX = {};
        vals.forEach(function (s) {
          var pts = W.hyperbola(s, d, yMax);
          polyline(fr, pts, kind === 'strong' ? '#ffffff' : WEAKC, kind === 'strong' ? { width: 1.6, alpha: 0.85 } : { width: 1.3, dash: [6, 5], alpha: 0.85 });
          if (!labels) return;
          // 在画面上端标出 r₁ − r₂（以 λ 为单位）
          var top = null;
          for (var i = pts.length - 1; i >= 0; i--) if (pts[i][1] <= yTop - 0.4) { top = pts[i]; break; }
          if (!top) return;
          var x = fr.X(top[0]), side = x < fr.T.x + 14 || x > fr.T.x + fr.T.w - 14;
          if (side) return;
          var key = Math.round(x / 22);
          if (lastX[key]) return;
          lastX[key] = 1;
          label(ctx, lamText(s / lam), x, fr.Y(top[1]) + 2, { size: kind === 'strong' ? 11 : 10, color: kind === 'strong' ? '#fff' : WEAKC });
        });
      });
    }

    // ---------- 场景一：波的干涉 ----------
    // o：{ lam, d, anti, s2: 'same'|'half'|'freq'|'off', view: 'wave'|'crest'|'amp', lines, P: {x,y}|null, t（实际秒） }
    function drawInterf(o) {
      bg();
      var R = area(), cw = narrow ? 0 : Math.min(320, Math.max(240, R.w * 0.28));
      var T = narrow ? { x: R.x, y: R.y, w: R.w, h: Math.round(R.h * 0.66) } : { x: R.x, y: R.y, w: R.w - cw - 16, h: R.h };
      var C = narrow ? { x: R.x, y: T.y + T.h + 12, w: R.w, h: R.h - T.h - 12 } : { x: T.x + T.w + 16, y: R.y + 4, w: cw, h: Math.min(R.h - 4, 330) };
      var s = Math.min(T.w / 40, T.h / 26), fr = frame(T, s, T.x + T.w / 2, T.y + T.h * 0.7);
      var srcs = [{ x: -o.d / 2, A: 1, lam: o.lam, phi: 0, color: C1, name: 'S₁' }];
      if (o.s2 !== 'off') srcs.push({ x: o.d / 2, A: o.s2 === 'half' ? 0.5 : 1, lam: o.s2 === 'freq' ? o.lam / W.F_DETUNE : o.lam, phi: o.anti ? Math.PI : 0, color: C2, name: 'S₂' });
      var coh = srcs.length === 2 && o.s2 !== 'freq', zmax = srcs.reduce(function (a, q) { return a + q.A; }, 0);
      var yTop = fr.wy(T.y), yBot = fr.wy(T.y + T.h);

      if (o.view === 'crest') {
        ctx.fillStyle = '#0b1830'; ctx.fillRect(T.x, T.y, T.w, T.h);
        ctx.strokeStyle = LINE; ctx.strokeRect(T.x + 0.5, T.y + 0.5, T.w - 1, T.h - 1);
      } else {
        var cell = 3, cols = Math.ceil(T.w / cell), rows = Math.ceil(T.h / cell);
        var key = [o.lam, o.d, o.anti, o.s2, T.w, T.h].join('|');
        ensureField(key, function () {
          return W.interfField({ x0: fr.wx(T.x), y0: yBot, cell: cell / s, cols: cols, rows: rows, srcs: srcs });
        });
        blit(painter.paint(field, o.t, o.view, { zmax: zmax, gamma: o.view === 'amp' ? 1.5 : 1 }), T);
      }

      clip(T);
      if (o.view === 'crest') {
        // 波峰实线、波谷虚线；峰峰、谷谷相遇处标加强点，峰谷相遇处标减弱点。只画离波源 7λ 以内的几圈，免得太密
        var rMax = 7 * o.lam, dr = narrow ? 2.8 : 3.6;
        var rings = srcs.map(function (q) {
          var ph = TAU * W.freq(q.lam) * o.t + q.phi;
          return { crest: W.crestRadii(ph, q.lam, rMax), trough: W.crestRadii(ph, q.lam, rMax, true) };
        });
        srcs.forEach(function (q, i) {
          rings[i].crest.forEach(function (r) { circle(fr, q.x, 0, r, q.color, { width: 1.6, alpha: 0.9 }); });
          rings[i].trough.forEach(function (r) { circle(fr, q.x, 0, r, q.color, { width: 1.1, dash: [4, 4], alpha: 0.6 }); });
        });
        if (coh) {
          var pts = function (A, B, fill, stroke) {
            A.forEach(function (a) {
              B.forEach(function (b) {
                W.circleX(a, b, o.d).forEach(function (p) { dot(fr.X(p[0]), fr.Y(p[1]), dr, fill, stroke); });
              });
            });
          };
          pts(rings[0].crest, rings[1].trough, '#0b1830', WEAKC);
          pts(rings[0].trough, rings[1].crest, '#0b1830', WEAKC);
          pts(rings[0].crest, rings[1].crest, GOLD, null);
          pts(rings[0].trough, rings[1].trough, GOLD, null);
        }
      }
      if (o.lines && coh) hyperLines(fr, o.d, o.lam, o.anti, yTop, yBot, true);
      ctx.restore();

      // 连线上的加强点
      if (o.lines && coh) {
        W.lineValues(o.d, o.lam, o.anti, 'strong').forEach(function (sv) {
          var x = fr.X(sv / 2), y = fr.Y(0);
          ctx.fillStyle = GOLD; ctx.beginPath(); ctx.moveTo(x, y - 5); ctx.lineTo(x + 4, y); ctx.lineTo(x, y + 5); ctx.lineTo(x - 4, y); ctx.closePath(); ctx.fill();
        });
      }

      // 波源（随振动轻微起伏）
      var Sx = srcs.map(function (q) { return fr.X(q.x); }), Sy = fr.Y(0);
      srcs.forEach(function (q, i) { source(Sx[i], Sy, q.color, q.name, q.A * Math.sin(TAU * W.freq(q.lam) * o.t + q.phi), true); });
      if (o.s2 === 'off') { dot(fr.X(o.d / 2), Sy, 6, '#0b1830', BAR); label(ctx, 'S₂ 停振', fr.X(o.d / 2), Sy + 20, { size: 12, color: MUTED }); }
      // d 与 λ 标尺
      dim(ctx, fr.X(-o.d / 2), Sy + 36, fr.X(o.d / 2), Sy + 36, 'd = ' + f(o.d, 1) + ' cm', MUTED, { dy: 13 });
      var lx = T.x + 14, ly = T.y + T.h - 16;
      dim(ctx, lx, ly, lx + o.lam * s, ly, '', '#cfe8ff');
      label(ctx, 'λ = ' + f(o.lam, 1) + ' cm', lx + o.lam * s + 8, ly, { size: 12, align: 'left', color: '#cfe8ff' });

      // P 点
      var Pi = null;
      if (o.P) {
        var px = fr.X(o.P.x), py = fr.Y(o.P.y), r1 = Math.hypot(o.P.x + o.d / 2, o.P.y), r2 = Math.hypot(o.P.x - o.d / 2, o.P.y);
        line(ctx, Sx[0], Sy, px, py, C1, { dash: [5, 4], width: 1.4 });
        line(ctx, fr.X(o.d / 2), Sy, px, py, C2, { dash: [5, 4], width: 1.4 });
        var cl = coh ? W.classify(r1 - r2, o.lam, o.anti) : { kind: 'mid' };
        var pc = cl.kind === 'strong' ? GOLD : cl.kind === 'weak' ? WEAKC : '#ffffff';
        dot(px, py, 7, 'rgba(5,7,13,.6)', pc); dot(px, py, 2.5, pc);
        var lft = px > T.x + T.w - 110;
        label(ctx, 'P', px + (lft ? -14 : 14), py - 12, { size: 13, bold: true, color: pc });
        if (coh) label(ctx, 'Δr = ' + f(Math.abs(r1 - r2) / o.lam, 2) + 'λ', px + (lft ? -12 : 12), py + 12, { size: 12, align: lft ? 'right' : 'left', color: pc });
        Pi = { x: px, y: py, r1: r1, r2: r2 };
      }

      // 图例
      var leg = o.view === 'crest' ? '实线：波峰　虚线：波谷　● 加强点　○ 减弱点' : o.view === 'amp' ? '亮：振幅大（加强区）　暗：振幅小（减弱区）' : '亮：波峰　暗：波谷';
      if (coh || o.view !== 'crest') label(ctx, leg, T.x + T.w - 10, T.y + T.h - 16, { size: 11, align: 'right', color: '#cfd8e6' });
      if (o.s2 === 'freq') label(ctx, 'S₂ 的频率是 S₁ 的 ' + W.F_DETUNE + ' 倍：加强区、减弱区不断移动，没有稳定的干涉图样', T.x + T.w / 2, T.y + 16, { size: 12, color: GOLD });

      // 右侧 / 下方：P 点的振动图像
      if (C.h > 70) chartP(C, o, srcs, Pi);

      geo = { scene: 'interf', fr: fr, S: srcs.map(function (q) { return { x: fr.X(q.x), y: Sy }; }), d: o.d, P: Pi, T: T };
      return geo;
    }

    // P 点的振动图像：两列波分别引起的振动与合振动，最近 2.5 个周期，右端为当前时刻
    function chartP(C, o, srcs, Pi) {
      ctx.fillStyle = 'rgba(13,19,32,.85)'; ctx.fillRect(C.x, C.y, C.w, C.h);
      ctx.strokeStyle = LINE; ctx.strokeRect(C.x + 0.5, C.y + 0.5, C.w - 1, C.h - 1);
      label(ctx, 'P 点的振动图像 y–t', C.x + 10, C.y + 14, { size: 12, align: 'left', bold: true });
      if (!Pi) { label(ctx, '点一下水面放上 P 点', C.x + C.w / 2, C.y + C.h / 2, { size: 12, color: MUTED }); return; }
      var leg = narrow ? 0 : 52, gx = C.x + 26, gw = C.w - 36, gy = C.y + 30, gh = C.h - 40 - leg;
      var zmax = srcs.reduce(function (a, q) { return a + q.A; }, 0), Tp = 1 / W.freq(o.lam), span = 2.5 * Tp;
      var mid = gy + gh / 2, ky = (gh / 2 - 4) / Math.max(zmax, 1);
      line(ctx, gx, mid, gx + gw, mid, LINE);
      line(ctx, gx, gy, gx, gy + gh, LINE);
      label(ctx, 'y', gx - 12, gy + 4, { size: 11, color: MUTED });
      label(ctx, 't', gx + gw + 4, mid - 8, { size: 11, color: MUTED });
      [1, -1].forEach(function (sg) { line(ctx, gx - 3, mid - sg * ky, gx + gw, mid - sg * ky, 'rgba(42,52,70,.6)', { dash: [2, 4] }); });
      label(ctx, 'A', gx - 10, mid - ky, { size: 10, color: MUTED });
      if (zmax > 1.01) { line(ctx, gx - 3, mid - zmax * ky, gx + gw, mid - zmax * ky, 'rgba(42,52,70,.6)', { dash: [2, 4] }); label(ctx, f(zmax) + 'A', gx - 12, mid - zmax * ky, { size: 10, color: MUTED }); }
      var rr = [Pi.r1, Pi.r2], n = 120;
      function comp(q, i, tau) { return q.A * Math.sin(TAU * W.freq(q.lam) * tau - TAU / q.lam * rr[i] + q.phi); }
      function trace(fn, color, width) {
        ctx.strokeStyle = color; ctx.lineWidth = width; ctx.beginPath();
        for (var k = 0; k <= n; k++) {
          var tau = o.t - span + span * k / n, x = gx + gw * k / n, y = mid - fn(tau) * ky;
          if (k) ctx.lineTo(x, y); else ctx.moveTo(x, y);
        }
        ctx.stroke();
      }
      srcs.forEach(function (q, i) { trace(function (tau) { return comp(q, i, tau); }, q.color, 1.2); });
      if (srcs.length > 1) trace(function (tau) { return comp(srcs[0], 0, tau) + comp(srcs[1], 1, tau); }, GOLD, 2.4);
      var yNow = srcs.reduce(function (a, q, i) { return a + comp(q, i, o.t); }, 0);
      dot(gx + gw, mid - yNow * ky, 3.5, GOLD);
      if (leg) {
        var ly = gy + gh + 18;
        line(ctx, gx, ly, gx + 18, ly, C1, { width: 2 }); label(ctx, 'S₁ 传来的波', gx + 24, ly, { size: 11, align: 'left', color: MUTED });
        if (srcs.length > 1) {
          line(ctx, gx + gw / 2, ly, gx + gw / 2 + 18, ly, C2, { width: 2 }); label(ctx, 'S₂ 传来的波', gx + gw / 2 + 24, ly, { size: 11, align: 'left', color: MUTED });
          line(ctx, gx, ly + 20, gx + 18, ly + 20, GOLD, { width: 3 }); label(ctx, '合振动（两者相加）', gx + 24, ly + 20, { size: 11, align: 'left', color: MUTED });
        }
      }
    }

    // ---------- 场景二：波的衍射 ----------
    // o：{ lam, a, obj: 'slit'|'block', view: 'wave'|'amp', shadow, t }
    function drawDiffr(o) {
      bg();
      var T = area(), s = Math.min(T.w / 46, T.h / 30), fr = frame(T, s, T.x + T.w * (narrow ? 0.24 : 0.27), T.y + T.h / 2);
      var cell = narrow ? 3 : 4, cols = Math.ceil(T.w / cell), rows = Math.ceil(T.h / cell);
      var key = [o.lam, o.a, o.obj, T.w, T.h].join('|');
      ensureField(key, function () {
        return W.diffrField({ x0: fr.wx(T.x), y0: fr.wy(T.y + T.h), cell: cell / s, cols: cols, rows: rows, a: o.a, lam: o.lam, obj: o.obj });
      });
      blit(painter.paint(field, o.t, o.view, { zmax: 1, gamma: o.view === 'amp' ? 0.6 : 0.6 }), T);

      // 挡板 / 障碍物（按当前 a 画，波场重算稍有滞后也不影响）
      var bx = fr.X(0), bw = Math.max(5, 0.3 * s), ya = fr.Y(o.a / 2), yb = fr.Y(-o.a / 2);
      ctx.fillStyle = BAR;
      if (o.obj === 'slit') { ctx.fillRect(bx - bw / 2, T.y, bw, ya - T.y); ctx.fillRect(bx - bw / 2, yb, bw, T.y + T.h - yb); }
      else ctx.fillRect(bx - bw / 2, ya, bw, yb - ya);
      clip(T);
      if (o.shadow) {
        // 若波沿直线传播，影子的边界
        line(ctx, bx, ya, T.x + T.w, ya, GOLD, { dash: [7, 5], width: 1.3 });
        line(ctx, bx, yb, T.x + T.w, yb, GOLD, { dash: [7, 5], width: 1.3 });
        var lx = bx + (T.x + T.w - bx) * 0.72;
        if (o.obj === 'slit') {
          label(ctx, '几何影区', lx, (T.y + ya) / 2, { size: 12, color: GOLD });
          label(ctx, '几何影区', lx, (yb + T.y + T.h) / 2, { size: 12, color: GOLD });
        } else if (yb - ya > 18) label(ctx, '几何影区', lx, (ya + yb) / 2, { size: 12, color: GOLD });
      }
      ctx.restore();
      // 缝边 / 障碍物两端的拖动手柄
      [ya, yb].forEach(function (y) { dot(bx, y, 6, 'rgba(5,7,13,.6)', GOLD); });
      dim(ctx, bx - 18, ya, bx - 18, yb, '', '#cfe8ff');
      label(ctx, (o.obj === 'slit' ? '缝宽 ' : '宽 ') + 'a = ' + f(o.a, 1) + ' cm', bx - 26, (ya + yb) / 2, { size: 12, align: 'right', color: '#cfe8ff' });
      // 入射波的波长与传播方向
      var ly = T.y + 22, lx0 = fr.X(-o.lam * Math.max(1, Math.round(4 / o.lam)) - o.lam);
      lx0 = Math.max(T.x + 10, lx0);
      dim(ctx, lx0, ly, lx0 + o.lam * s, ly, '', '#cfe8ff');
      label(ctx, 'λ = ' + f(o.lam, 1) + ' cm', lx0 + o.lam * s + 6, ly, { size: 12, align: 'left', color: '#cfe8ff' });
      var ay = T.y + T.h - 22;
      line(ctx, T.x + 14, ay, T.x + 70, ay, '#cfe8ff', { width: 1.6 }); head(ctx, T.x + 74, ay, 0, 8, '#cfe8ff');
      label(ctx, '平面波', T.x + 82, ay, { size: 12, align: 'left', color: '#cfe8ff' });
      var lv = W.diffrLevel(o.a, o.lam);
      label(ctx, 'a / λ = ' + f(o.a / o.lam, 2) + '　' + lv.text, T.x + T.w - 10, T.y + 14, { size: 13, align: 'right', bold: true, color: lv.lv >= 2 ? GOLD : '#cfd8e6' });
      geo = { scene: 'diffr', fr: fr, T: T, edges: [{ x: bx, y: ya }, { x: bx, y: yb }] };
      return geo;
    }

    // ---------- 练习 ----------
    function drawQuiz(q, answered, o) {
      bg();
      var R = area((o.quizH || 180) + 8);
      ctx.save(); ctx.beginPath(); ctx.rect(R.x - 6, R.y - 6, R.w + 12, R.h + 12); ctx.clip();
      if (q.type === 'point') quizPoint(R, q, answered);
      else if (q.type === 'calc') quizCalc(R, q, answered);
      else if (q.type === 'count') quizCount(R, q, answered);
      else if (q.type === 'diffr') quizDiffr(R, q, answered);
      else quizConcept(R, q);
      ctx.restore();
      geo = { scene: 'quiz' };
      return geo;
    }
    // 世界范围等比放进矩形
    function fit(R, x0, x1, y0, y1) {
      var s = Math.min(R.w / (x1 - x0), R.h / (y1 - y0));
      return frame(R, s, R.x + R.w / 2 - (x0 + x1) / 2 * s, R.y + R.h / 2 + (y0 + y1) / 2 * s);
    }
    function quizPoint(R, q, answered) {
      var fr = fit(R, -4, 4, -0.8, 4.6), d = q.d, rMax = q.N + 1;
      ctx.save(); ctx.beginPath(); ctx.rect(fr.X(-4), fr.Y(4.6), 8 * fr.s, 5.4 * fr.s); ctx.clip();
      [-d / 2, d / 2].forEach(function (x) {
        for (var n = 0; n < q.N; n++) {
          circle(fr, x, 0, q.r0 + n, '#dfe8f5', { width: 1.4, alpha: 0.85 });
          circle(fr, x, 0, q.r0 + n + 0.5, '#dfe8f5', { width: 1.1, dash: [5, 4], alpha: 0.6 });
        }
      });
      if (answered) hyperLines(fr, d, 1, false, 4.4, -0.8, false);
      ctx.restore();
      source(fr.X(-d / 2), fr.Y(0), C1, 'S₁', 0, true);
      source(fr.X(d / 2), fr.Y(0), C2, 'S₂', 0, true);
      var P = q.P, pc = answered ? (q.key === 'ct' ? WEAKC : GOLD) : '#ff5a8a';
      dot(fr.X(P.x), fr.Y(P.y), 6, pc, '#fff');
      label(ctx, 'M', fr.X(P.x) + 13, fr.Y(P.y) - 12, { size: 14, bold: true, color: pc });
      dim(ctx, fr.X(-3.6), fr.Y(-0.55), fr.X(-2.6), fr.Y(-0.55), 'λ', MUTED, { dy: -10 });
      if (answered) label(ctx, '白色实线：加强线　紫色虚线：减弱线', R.x + R.w - 6, R.y + 10, { size: 11, align: 'right', color: MUTED });
    }
    function quizCalc(R, q, answered) {
      // 示意图（不按比例）：S₁ 左下、S₂ 右下、P 在上方
      var cx = R.x + R.w / 2, by = R.y + R.h * 0.78, half = Math.min(R.w * 0.3, 200), ty = R.y + R.h * 0.18;
      var S1 = { x: cx - half, y: by }, S2 = { x: cx + half, y: by }, P = { x: cx + half * (q.r1 > q.r2 ? 0.35 : q.r1 < q.r2 ? -0.35 : 0), y: ty };
      line(ctx, S1.x, S1.y, P.x, P.y, C1, { width: 1.6 }); line(ctx, S2.x, S2.y, P.x, P.y, C2, { width: 1.6 });
      label(ctx, 'r₁ = ' + f(q.r1) + ' m', (S1.x + P.x) / 2 - 12, (S1.y + P.y) / 2, { size: 13, align: 'right', color: C1 });
      label(ctx, 'r₂ = ' + f(q.r2) + ' m', (S2.x + P.x) / 2 + 12, (S2.y + P.y) / 2, { size: 13, align: 'left', color: C2 });
      source(S1.x, S1.y, C1, 'S₁', 0, true); source(S2.x, S2.y, C2, 'S₂', 0, true);
      var c = W.classify(q.r1 - q.r2, q.lam, q.anti), pc = !answered ? '#ffffff' : c.kind === 'strong' ? GOLD : WEAKC;
      dot(P.x, P.y, 6, pc, '#fff'); label(ctx, 'P', P.x, P.y - 18, { size: 14, bold: true, color: pc });
      label(ctx, 'λ = ' + f(q.lam) + ' m　' + (q.anti ? '两波源振动步调相反' : '两波源振动步调一致') + (q.sub === 'amp' ? '　A₁ = ' + q.A1 + ' cm，A₂ = ' + q.A2 + ' cm' : ''),
        cx, by + 44, { size: 13, color: MUTED });
      label(ctx, '（示意图，不按比例）', R.x + R.w - 6, R.y + 10, { size: 11, align: 'right', color: MUTED });
      if (answered) label(ctx, 'Δr = ' + f(Math.abs(q.r1 - q.r2)) + ' m = ' + f(Math.abs(q.r1 - q.r2) / q.lam) + 'λ → ' + c.text, cx, Math.min(by + 72, R.y + R.h - 8), { size: 14, bold: true, color: pc });
    }
    function quizCount(R, q, answered) {
      var lam = q.lam, d = q.d, fr = fit(R, -d / 2 - lam * 0.8, d / 2 + lam * 0.8, -d * 0.45, d * 0.55);
      if (answered) {
        ctx.save(); ctx.beginPath(); ctx.rect(R.x, R.y, R.w, R.h); ctx.clip();
        hyperLines(fr, d, lam, q.anti, fr.wy(R.y), fr.wy(R.y + R.h), false);
        ctx.restore();
      }
      line(ctx, fr.X(-d / 2), fr.Y(0), fr.X(d / 2), fr.Y(0), MUTED, { width: 1.4 });
      // 连线上每隔 λ/2 一个刻度
      for (var x = -d / 2; x <= d / 2 + 1e-9; x += lam / 2) line(ctx, fr.X(x), fr.Y(0) - 4, fr.X(x), fr.Y(0) + 4, MUTED);
      source(fr.X(-d / 2), fr.Y(0), C1, 'S₁', 0, true); source(fr.X(d / 2), fr.Y(0), C2, 'S₂', 0, true);
      dim(ctx, fr.X(-d / 2), fr.Y(0) + 46, fr.X(d / 2), fr.Y(0) + 46, 'd = ' + f(d) + ' m', MUTED, { dy: 13 });
      dim(ctx, fr.X(-d / 2), fr.Y(0) - 30, fr.X(-d / 2 + lam), fr.Y(0) - 30, 'λ = ' + f(lam) + ' m', '#cfe8ff', { dy: -11 });
      label(ctx, '刻度间隔 λ/2', R.x + R.w - 6, R.y + 10, { size: 11, align: 'right', color: MUTED });
      if (answered) {
        W.lineValues(d, lam, q.anti, q.kind).forEach(function (sv) {
          var px = fr.X(sv / 2), py = fr.Y(0);
          if (q.kind === 'strong') dot(px, py, 5, GOLD); else dot(px, py, 5, '#0b1222', WEAKC);
        });
      }
    }
    function quizDiffr(R, q, answered) {
      var names = ['甲', '乙', '丙', '丁'], gap = 12, pw = (R.w - gap) / 2, ph = (R.h - gap) / 2;
      var key = q.id + '|' + pw + '|' + ph;
      if (answered && quizCache.key !== key) {
        quizCache.key = key;
        quizCache.fields = q.cases.map(function (c) { return null; });
      }
      // 四格用同一比例：宽 18 cm、高按格子比例
      var s = Math.min(pw / 18, (ph - 22) / 12);
      q.cases.forEach(function (c, i) {
        var P = { x: R.x + (i % 2) * (pw + gap), y: R.y + Math.floor(i / 2) * (ph + gap), w: pw, h: ph };
        var T = { x: P.x, y: P.y + 22, w: P.w, h: P.h - 22 }, fr = frame(T, s, T.x + T.w * 0.3, T.y + T.h / 2);
        label(ctx, names[i] + '：' + (q.obj === 'slit' ? '缝宽' : '障碍物宽') + ' ' + f(c.a) + ' cm，λ = ' + f(c.lam) + ' cm', P.x + 4, P.y + 10, { size: 12, align: 'left', bold: true, color: answered && q.answer === names[i] ? GOLD : TEXT });
        if (answered) {
          var cell = 3, F = quizCache.fields[i];
          if (!F) F = quizCache.fields[i] = W.diffrField({ x0: fr.wx(T.x), y0: fr.wy(T.y + T.h), cell: cell / s, cols: Math.ceil(T.w / cell), rows: Math.ceil(T.h / cell), a: c.a, lam: c.lam, obj: q.obj });
          var cv = qPainter.paint(F, 0.07, 'wave', { zmax: 1, gamma: 0.6 });
          ctx.save(); ctx.imageSmoothingEnabled = true; ctx.drawImage(cv, T.x, T.y, T.w, T.h); ctx.restore();
        } else {
          ctx.fillStyle = '#0b1830'; ctx.fillRect(T.x, T.y, T.w, T.h);
          for (var x = 0; fr.X(x) > T.x; x -= c.lam) line(ctx, fr.X(x), T.y, fr.X(x), T.y + T.h, '#9fd4ff', { width: 1.2 });
        }
        ctx.strokeStyle = LINE; ctx.strokeRect(T.x + 0.5, T.y + 0.5, T.w - 1, T.h - 1);
        var bx = fr.X(0), ya = fr.Y(c.a / 2), yb = fr.Y(-c.a / 2);
        ctx.fillStyle = BAR;
        if (q.obj === 'slit') { ctx.fillRect(bx - 2.5, T.y, 5, ya - T.y); ctx.fillRect(bx - 2.5, yb, 5, T.y + T.h - yb); }
        else ctx.fillRect(bx - 2.5, ya, 5, yb - ya);
      });
    }
    function quizConcept(R, q) {
      var sh = q.show || {}, key = 'c|' + q.cid + '|' + R.w + '|' + R.h;
      var T = { x: R.x + R.w * 0.1, y: R.y, w: R.w * 0.8, h: R.h };
      var s, fr;
      if (sh.scene === 'diffr') { s = Math.min(T.w / 40, T.h / 26); fr = frame(T, s, T.x + T.w * 0.3, T.y + T.h / 2); }
      else { s = Math.min(T.w / 36, T.h / 22); fr = frame(T, s, T.x + T.w / 2, T.y + T.h * 0.75); }
      if (quizCache.key !== key) {
        quizCache.key = key;
        var cell = 3, spec = { x0: fr.wx(T.x), y0: fr.wy(T.y + T.h), cell: cell / s, cols: Math.ceil(T.w / cell), rows: Math.ceil(T.h / cell) };
        if (sh.scene === 'diffr') { spec.a = sh.a; spec.lam = sh.lam; spec.obj = 'slit'; quizCache.fields = [W.diffrField(spec)]; }
        else { spec.srcs = [{ x: -4, A: 1, lam: 2.4, phi: 0 }, { x: 4, A: 1, lam: 2.4, phi: 0 }]; quizCache.fields = [W.interfField(spec)]; }
      }
      var cv = qPainter.paint(quizCache.fields[0], 0.05, sh.scene === 'diffr' ? 'wave' : 'amp', { zmax: sh.scene === 'diffr' ? 1 : 2, gamma: sh.scene === 'diffr' ? 0.6 : 1.5 });
      ctx.save(); ctx.globalAlpha = 0.8; ctx.imageSmoothingEnabled = true; ctx.drawImage(cv, T.x, T.y, T.w, T.h); ctx.restore();
      ctx.strokeStyle = LINE; ctx.strokeRect(T.x + 0.5, T.y + 0.5, T.w - 1, T.h - 1);
      if (sh.scene === 'diffr') {
        var bx = fr.X(0), ya = fr.Y(sh.a / 2), yb = fr.Y(-sh.a / 2);
        ctx.fillStyle = BAR; ctx.fillRect(bx - 3, T.y, 6, ya - T.y); ctx.fillRect(bx - 3, yb, 6, T.y + T.h - yb);
      } else {
        source(fr.X(-4), fr.Y(0), C1, 'S₁', 0, true); source(fr.X(4), fr.Y(0), C2, 'S₂', 0, true);
      }
    }

    return { resize: resize, drawInterf: drawInterf, drawDiffr: drawDiffr, drawQuiz: drawQuiz,
      geo: function () { return geo; }, narrow: function () { return narrow; } };
  }

  window.WaveDraw = { View: View, lamText: lamText };
})();
