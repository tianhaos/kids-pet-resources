(function () {
  'use strict';
  const E=Elevator, $=id=>document.getElementById(id), query=new URLSearchParams(location.search);
  const scene=['up','down','fall'].includes(query.get('scene'))?query.get('scene'):'up';
  function number(key,fallback,lo,hi){const raw=query.get(key);return raw!==null&&Number.isFinite(Number(raw))?E.clamp(Number(raw),lo,hi):fallback;}
  const state={scene,t:number('t',1,0,E.duration(scene)),mass:Math.round(number('mass',60,30,100)),playing:query.get('play')==='1'};
  const canvas=$('lab');let geometry,last=0,drag=null;
  function track(action,label=state.scene){if(window.Analytics)Analytics.track('超重与失重',action,label);}
  function setTime(t){state.t=E.clamp(t,0,E.duration(state.scene));state.playing=false;}
  function sync(){
    document.querySelectorAll('[data-scene]').forEach(b=>{b.classList.toggle('on',b.dataset.scene===state.scene);b.setAttribute('aria-pressed',String(b.dataset.scene===state.scene));});
    $('time').max=E.duration(state.scene);$('mass').value=state.mass;$('massValue').textContent=state.mass+' kg';
    $('subtitle').textContent=state.scene==='fall'?'人与轿厢共同自由下落 · 理想无阻力':'向上为正 · 先加速，再匀速，最后减速';
    $('scope').textContent=state.scene==='fall'?'只观察前2 s；终点暂停不表示落地。人与秤共同自由落体，不模拟真实电梯安全系统。':'起步2 s、匀速3 s、制动2 s，行程20 m。加速度分段突变，不模拟振动与人体形变。';
  }
  function setScene(s){state.scene=['up','down','fall'].includes(s)?s:'up';state.t=1;state.playing=false;sync();track('切换场景');}
  document.querySelectorAll('[data-scene]').forEach(b=>b.onclick=()=>setScene(b.dataset.scene));
  document.querySelectorAll('[data-time]').forEach(b=>b.onclick=()=>{setTime(Number(b.dataset.time)>2&&state.scene==='fall'?1:Number(b.dataset.time));track('对比阶段');});
  $('mass').oninput=e=>{state.mass=Number(e.target.value);sync();};$('mass').onchange=()=>track('调整质量');
  $('time').oninput=e=>setTime(Number(e.target.value));$('time').onchange=()=>track('回看时刻');
  function play(){if(state.t>=E.duration(state.scene))state.t=0;state.playing=!state.playing;track(state.playing?'播放':'暂停');}
  $('play').onclick=play;$('reset').onclick=()=>{setTime(0);track('回到起点');};
  $('panelToggle').onclick=()=>{const p=$('panel');p.classList.toggle('collapsed');$('panelToggle').setAttribute('aria-expanded',String(!p.classList.contains('collapsed')));};
  if(matchMedia('(max-width:760px)').matches){$('panel').classList.add('collapsed');$('panelToggle').setAttribute('aria-expanded','false');}
  document.addEventListener('keydown',e=>{if(e.code==='Space'&&!/INPUT|BUTTON|TEXTAREA|SELECT/.test(e.target.tagName)){e.preventDefault();play();}});
  function point(e){const r=canvas.getBoundingClientRect();return{x:e.clientX-r.left,y:e.clientY-r.top};}
  function move(p){if(drag.kind==='time')setTime((p.x-geometry.gx)/geometry.gw*geometry.end);else{const y=drag.height-(p.y-drag.y)/geometry.travel*24;setTime(E.timeAtHeight(state.scene,y));}}
  canvas.onpointerdown=e=>{const p=point(e),kind=ElevatorDraw.hit(p.x,p.y);if(!kind)return;
    state.dragging=kind;drag={kind,y:p.y,height:E.solve(state.scene,state.t,state.mass).y};state.playing=false;canvas.setPointerCapture(e.pointerId);if(kind==='time')move(p);e.preventDefault();};
  canvas.onpointermove=e=>{const p=point(e);if(drag)move(p);else{const hit=ElevatorDraw.hit(p.x,p.y);state.hover=hit;canvas.style.cursor=hit==='cabin'?'ns-resize':hit?'ew-resize':'default';}};
  function end(){if(drag)track('画面拖动',drag.kind);drag=null;state.dragging=null;canvas.style.cursor='default';}
  canvas.onpointerleave=()=>{state.hover=null;};
  canvas.onpointerup=end;canvas.onpointercancel=end;canvas.onlostpointercapture=end;
  $('share').onclick=async()=>{const u=new URL(location.href);u.search='';for(const k of ['scene','t','mass'])u.searchParams.set(k,state[k]);
    try{await navigator.clipboard.writeText(u.href);$('toast').textContent='已复制当前实验链接';}catch{$('shareLink').hidden=false;$('shareLink').value=u.href;$('shareLink').select();$('toast').textContent='请复制下方链接';}track('复制链接');};
  function frame(now){const dt=last?Math.min(.05,(now-last)/1000):0;last=now;
    if(state.playing){state.t=Math.min(E.duration(state.scene),state.t+dt*.65);if(state.t>=E.duration(state.scene))state.playing=false;}
    geometry=ElevatorDraw.draw(canvas,state);const s=E.solve(state.scene,state.t,state.mass);
    $('normal').textContent=s.N.toFixed(0)+' N';$('gravity').textContent=s.G.toFixed(0)+' N';
    $('result').textContent=s.status;$('law').textContent=`N − mg = ma = ${(state.mass*s.a).toFixed(0)} N`;
    $('explain').textContent=s.a>0?'加速度向上，支持力大于重力。':s.a<0?(s.N<.01?'重力仍然存在；人和秤共同自由下落，压力为零。':'加速度向下，支持力小于重力。'):'加速度为零，支持力等于重力。';
    $('clock').textContent=state.t.toFixed(2)+' s';$('time').value=state.t;$('play').textContent=state.playing?'暂停':'播放';
    document.querySelectorAll('[data-time]').forEach(b=>b.hidden=state.scene==='fall'&&Number(b.dataset.time)>2);
    requestAnimationFrame(frame);
  }
  sync();requestAnimationFrame(frame);
  window.__model={state,setScene,setTime,geometry:()=>geometry,solve:()=>E.solve(state.scene,state.t,state.mass)};
})();
