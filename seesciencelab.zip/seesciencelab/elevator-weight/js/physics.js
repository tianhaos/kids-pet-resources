// 理想电梯：竖直向上为正；支持力与人对秤的压力大小相等。
(function () {
  'use strict';
  const g = 9.8;
  const clamp = (x, lo, hi) => Math.max(lo, Math.min(hi, x));
  function duration(scene) { return scene === 'fall' ? 2 : 7; }
  function solve(scene, time, mass) {
    const t = clamp(time, 0, duration(scene));
    let y, v, a, phase;
    if (scene === 'fall') {
      y = 24 - g * t * t / 2; v = -g * t; a = -g;
      phase = '理想自由落体';
    } else {
      let s, u, b;
      if (t < 2) { s = t * t; u = 2 * t; b = 2; phase = '加速起步'; }
      else if (t < 5) { s = 4 + 4 * (t - 2); u = 4; b = 0; phase = '匀速运行'; }
      else if (t < 7) { const q = t - 5; s = 16 + 4 * q - q * q; u = 4 - 2 * q; b = -2; phase = '减速制动'; }
      else { s = 20; u = 0; b = 0; phase = '到站静止'; }
      const sign = scene === 'down' ? -1 : 1;
      y = scene === 'down' ? 20 - s : s; v = sign * u; a = sign * b;
    }
    const G = mass * g, N = mass * (g + a);
    const status = N > G + 1e-6 ? '超重' : N < 1e-6 ? '完全失重' : N < G - 1e-6 ? '失重' : '正常视重';
    return { t, y, v, a, G, N, phase, status, ratio: N / G };
  }
  function timeAtHeight(scene, height) {
    const end = duration(scene), descending = scene !== 'up';
    let lo = 0, hi = end;
    for (let i = 0; i < 45; i++) {
      const mid = (lo + hi) / 2;
      if ((solve(scene, mid, 60).y < height) !== descending) lo = mid; else hi = mid;
    }
    return (lo + hi) / 2;
  }
  window.Elevator = { g, clamp, duration, solve, timeAtHeight };
})();
