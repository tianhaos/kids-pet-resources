// 绘图使用 CSS 像素；物理高度映射到轿厢地板，人物与箭头均为示意。
(function () {
  'use strict';
  const C = { gold:'#ffc94a', blue:'#72d7ff', text:'#e6ebf2', muted:'#94a7be', line:'#2b3b50', green:'#85dfb1' };
  let ctx, geo;
  function text(s, x, y, color=C.text, size=12, align='left') {
    ctx.fillStyle=color; ctx.font=`${size}px -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif`;
    ctx.textAlign=align; ctx.textBaseline='middle'; ctx.fillText(s,x,y);
  }
  function line(x,y,u,v,color,width=1,dash=[]) {
    ctx.beginPath(); ctx.strokeStyle=color; ctx.lineWidth=width;ctx.setLineDash(dash);
    ctx.moveTo(x,y);ctx.lineTo(u,v);ctx.stroke();ctx.setLineDash([]);
  }
  function box(x,y,w,h,fill,stroke,r=8) {
    ctx.beginPath();ctx.roundRect(x,y,w,h,r);ctx.fillStyle=fill;ctx.fill();
    if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=1;ctx.stroke();}
  }
  function circle(x,y,r,fill) {ctx.beginPath();ctx.arc(x,y,r,0,Math.PI*2);ctx.fillStyle=fill;ctx.fill();}
  function arrow(x,y,len,color,label) {
    if(Math.abs(len)<1){circle(x,y,4,color);text(label,x,y-14,color,11,'center');return;}
    line(x,y,x,y+len,color,3);
    const d=Math.sign(len);
    ctx.beginPath();ctx.moveTo(x,y+len);ctx.lineTo(x-5,y+len-d*9);ctx.lineTo(x+5,y+len-d*9);ctx.closePath();ctx.fillStyle=color;ctx.fill();
    text(label,x,y+len+d*13,color,11,'center');
  }
  function person(cx,floor) {
    // 身体、衣服和双脚构成可辨认的人物，姿态固定，不暗示形变计算。
    circle(cx,floor-112,12,'#e9bda2');
    ctx.beginPath();ctx.arc(cx,floor-115,12,Math.PI,Math.PI*2);ctx.fillStyle='#303749';ctx.fill();
    line(cx-8,floor-51,cx-10,floor-15,'#8b9fb9',8);
    line(cx+8,floor-51,cx+11,floor-15,'#8b9fb9',8);
    box(cx-18,floor-93,36,43,'#397a9b',null,9);
    line(cx-17,floor-84,cx-26,floor-55,'#e9bda2',6);
    line(cx+17,floor-84,cx+26,floor-55,'#e9bda2',6);
    box(cx-17,floor-17,16,6,'#e1e7ef',null,3);box(cx+5,floor-17,16,6,'#e1e7ef',null,3);
  }
  function draw(canvas,state) {
    const w=canvas.clientWidth,h=canvas.clientHeight,dpr=Math.min(devicePixelRatio||1,2);
    if(canvas.width!==Math.round(w*dpr)||canvas.height!==Math.round(h*dpr)){canvas.width=Math.round(w*dpr);canvas.height=Math.round(h*dpr);}
    ctx=canvas.getContext('2d');ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,w,h);
    const narrow=w<650, s=Elevator.solve(state.scene,state.t,state.mass);
    const graphY=h-246, floorBottom=graphY-28, travel=Math.max(20,graphY-292);
    const cx=narrow?w*.29:w*.32, floor=floorBottom-s.y/24*travel, cw=narrow?142:184;
    const rx=narrow?w*.64:w*.64, rw=w-rx-18;
    // 井道剖面：高度刻度固定，轿厢与人共同运动。
    box(cx-cw/2-13,88,cw+26,floorBottom-68,'#0b111c','#253348',4);
    for(let y=0;y<=24;y+=(travel<100?12:travel<180?8:4)){const py=floorBottom-y/24*travel;
      line(cx-cw/2-12,py,cx+cw/2+12,py,'#29394f',1);
      text(`${y} m`,cx-cw/2-18,py,C.muted,10,'right');
    }
    line(cx-cw/2+5,92,cx-cw/2+5,floorBottom+15,'#53627b',2);
    line(cx+cw/2-5,92,cx+cw/2-5,floorBottom+15,'#53627b',2);
    if(state.scene!=='fall'){
      line(cx-5,89,cx-5,floor-157,'#7d8da4',2);line(cx+5,89,cx+5,floor-157,'#7d8da4',2);
    }
    const metal=ctx.createLinearGradient(cx-cw/2,0,cx+cw/2,0);
    metal.addColorStop(0,'#3c5066');metal.addColorStop(.08,'#182639');metal.addColorStop(.9,'#142033');metal.addColorStop(1,'#4a5d72');
    box(cx-cw/2,floor-156,cw,172,metal,(state.dragging==='cabin'||state.hover==='cabin')?C.blue:'#6a819a',6);
    box(cx-cw/2+12,floor-145,cw-24,139,'#0a1421','#263a51',3);
    line(cx-cw/2+20,floor-139,cx+cw/2-20,floor-139,'#f6dfae',3);
    // 秤面发光只表示接触读数，亮度不参与定量推算。
    box(cx-34,floor-10,68,12,'#476177','#a5bbcd',3);
    person(cx,floor);
    arrow(cx-45,floor-13,-65*s.ratio,C.blue,s.N<.01?'N = 0':'N');
    arrow(cx+45,floor-85,65,C.gold,'G');
    box(cx-30,floor+2,60,20,'#071019','#344b63',3);
    text(`${Math.round(s.N)} N`,cx,floor+12,C.blue,11,'center');
    // 空白区域保留大读数和速度/加速度方向，对比不依赖运动方向猜测。
    const ry=y=>100+(y-100)*Math.min(1,(graphY-120)/320);
    const color=s.status==='超重'?C.blue:s.status==='正常视重'?C.green:C.gold;
    text(s.status,rx,ry(123),color,narrow?16:18);
    text('秤的示数 N',rx,ry(156),C.muted,11);
    text(`${s.N.toFixed(0)} N`,rx,ry(183),C.blue,narrow?18:24);
    text(`重力 ${s.G.toFixed(0)} N`,rx,ry(211),C.gold,12);
    line(rx,ry(232),rx+rw,ry(232),C.line);
    const dir = n => Math.abs(n)<1e-8?'0':(n>0?'↑ ':'↓ ')+Math.abs(n).toFixed(1);
    text('速度 / m·s⁻¹',rx,ry(254),C.muted,11);
    text(dir(s.v),rx,ry(277),C.text,16);
    text('加速度 / m·s⁻²',rx,ry(310),C.muted,11);
    text(dir(s.a),rx,ry(333),C.text,16);
    text(s.phase,rx,ry(369),C.muted,11);
    if(!narrow){text('向上为正',rx,ry(399),C.muted,11);text('拖轿厢回看位置',rx,ry(420),C.muted,11);}
    // 两幅时间图共用横坐标；阶跃采用右连续值，t=7 为到站静止。
    const gx=narrow?40:65, gw=w-gx-26, end=Elevator.duration(state.scene);
    const gy=graphY+25, vh=45, ny=graphY+105, nh=45;
    const nmin=state.scene==='fall'?0:.6;
    box(gx-24,graphY-5,gw+36,177,'#0b111b',(state.dragging==='time'||state.hover==='time')?'#72d7ff':'#223147',8);
    const tx=t=>gx+t/end*gw;
    function valueY(value,kind){return kind==='v'?gy+vh/2-value/(state.scene==='fall'?22:5)*vh/2:ny+nh-(value-nmin)/(1.4-nmin)*nh;}
    text('v / m·s⁻¹',gx,graphY+7,C.muted,10);text('N / mg',gx,graphY+86,C.muted,10);
    for(const kind of ['v','n']){
      const y0=valueY(kind==='v'?0:nmin,kind);
      line(gx,y0,gx+gw,y0,C.line);
      if(kind==='v'){for(const value of state.scene==='fall'?[0,-20]:[4,0,-4])text(String(value),gx-8,valueY(value,'v'),C.muted,9,'right');}
      if(kind==='n'){for(const value of [nmin,1.4])text(String(value),gx-8,valueY(value,'n'),C.muted,9,'right');const y1=valueY(1,'n');line(gx,y1,gx+gw,y1,'#70745b',1,[4,4]);text('1',gx-8,y1,C.gold,10,'right');}
      ctx.beginPath();ctx.strokeStyle=kind==='v'?C.text:C.blue;ctx.lineWidth=2;
      const times=state.scene==='fall'?[0,end]:[0,2-1e-6,2,5-1e-6,5,7-1e-6,7];
      times.forEach((t,i)=>{const p=Elevator.solve(state.scene,t,state.mass);const y=valueY(kind==='v'?p.v:p.ratio,kind);if(i===0)ctx.moveTo(tx(t),y);else ctx.lineTo(tx(t),y);});ctx.stroke();
      const yy=valueY(kind==='v'?s.v:s.ratio,kind);circle(tx(state.t),yy,4,kind==='v'?C.text:C.blue);
    }
    for(const t of state.scene==='fall'?[0,1,2]:[0,2,5,7]){line(tx(t),graphY+20,tx(t),graphY+153,C.line,1,[2,5]);text(`${t} s`,tx(t),graphY+161,C.muted,10,'center');}
    line(tx(state.t),graphY+17,tx(state.t),graphY+151,'#aec3dc',1);
    circle(tx(state.t),graphY+153,6,C.blue);
    geo={cx,floor,cw,floorBottom,travel,gx,gw,graphY,end};
    return geo;
  }
  function hit(x,y){
    if(!geo)return null;
    if(y>=geo.graphY-8&&y<=geo.graphY+179&&x>=geo.gx-20&&x<=geo.gx+geo.gw+20)return 'time';
    if(Math.abs(x-geo.cx)<geo.cw/2+8&&y>geo.floor-162&&y<geo.floor+26)return 'cabin';
    return null;
  }
  window.ElevatorDraw={draw,hit};
})();
