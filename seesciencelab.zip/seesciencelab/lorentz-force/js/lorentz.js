// 带电粒子在匀强磁场中的运动：洛伦兹力、半径与周期、有界磁场中的轨迹（解析求出直线段 + 圆弧段）、练习题
// 世界坐标 x 右、y 上，单位 cm；速度单位 10⁶ m/s，磁感应强度单位 T；角度正方向为逆时针
// 磁场方向：bIn = true 为垂直纸面向里（⊗），false 为向外（⊙）
(function () {
  var E = 1.602e-19, MP = 1.673e-27, DEG = Math.PI / 180, TAU = Math.PI * 2;
  // 动画慢放倍数：质子在 0.1 T 磁场中转一圈（约 0.66 μs）在屏幕上用 4 s
  var SLOW = 4 / (TAU * MP / (E * 0.1));

  // 质量以质子质量 mp 为单位、电荷量以元电荷 e 为单位（中学按 mα = 4mp 近似）
  var PARTICLES = {
    p: { key: 'p', name: '质子', sym: '¹₁H', q: 1, m: 1 },
    d: { key: 'd', name: '氘核', sym: '²₁H', q: 1, m: 2 },
    a: { key: 'a', name: 'α 粒子', sym: '⁴₂He', q: 2, m: 4 },
    h: { key: 'h', name: '负氢离子', sym: 'H⁻', q: -1, m: 1 }
  };
  var V_RANGE = [0.2, 5], B_RANGE = [0.05, 0.5];

  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
  function mod(a, m) { return ((a % m) + m) % m; }

  // ---------- 基本公式（SI 单位换算） ----------
  function radius(P, v, B) { return P.m * MP * v * 1e6 / (Math.abs(P.q) * E * B) * 100; } // cm
  function period(P, B) { return TAU * P.m * MP / (Math.abs(P.q) * E * B); }             // s
  function force(P, v, B) { return Math.abs(P.q) * E * v * 1e6 * B; }                    // N
  function energyEV(P, v) { return 0.5 * P.m * MP * Math.pow(v * 1e6, 2) / E; }           // eV
  function speedFor(P, r, B) { return r / 100 * Math.abs(P.q) * E * B / (P.m * MP) / 1e6; } // 半径 r（cm）对应的速度
  // 偏转方向：+1 逆时针、−1 顺时针（F = qv × B，B 向里时正电荷逆时针转）
  function turn(q, bIn) { return (q > 0 ? 1 : -1) * (bIn ? 1 : -1); }
  // 屏幕上的角速度（rad/s，带正负号）
  function visOmega(P, B, bIn) { return turn(P.q, bIn) * TAU / (period(P, B) * SLOW); }

  // 粒子在 p 点以方向角 a 运动、轨迹半径 r、转向 s 时的圆心
  function center(p, a, r, s) { return { x: p.x - s * r * Math.sin(a), y: p.y + s * r * Math.cos(a) }; }
  // 洛伦兹力方向（单位向量）：指向圆心
  function forceDir(a, s) { return { x: -s * Math.sin(a), y: s * Math.cos(a) }; }

  // ---------- 磁场区域 ----------
  // all：充满整个平面；line：单边界，y > 0 有磁场；strip：0 < y < d；circle：圆心在原点、半径 R
  function inside(reg, p) {
    if (reg.type === 'all') return true;
    if (reg.type === 'line') return p.y > 0;
    if (reg.type === 'strip') return p.y > 0 && p.y < reg.d;
    return p.x * p.x + p.y * p.y < reg.R * reg.R;
  }
  // 射线 p + t·u 第一次进入磁场的 t（不进入返回 null）
  function rayEnter(reg, p, u) {
    if (inside(reg, p)) return 0;
    if (reg.type === 'line' || reg.type === 'strip') {
      if (p.y <= 0 && u.y > 1e-9) return -p.y / u.y;
      if (reg.type === 'strip' && p.y >= reg.d && u.y < -1e-9) return (reg.d - p.y) / u.y;
      return null;
    }
    var b = p.x * u.x + p.y * u.y, c = p.x * p.x + p.y * p.y - reg.R * reg.R, D = b * b - c;
    if (D <= 1e-9) return null;
    var t = -b - Math.sqrt(D);
    return t >= 0 ? t : null;
  }
  // 以 c 为圆心、半径 r 的圆与磁场边界的交点的极角
  function boundaryAngles(reg, c, r) {
    var out = [];
    function lineY(y0) {
      var s = (y0 - c.y) / r;
      if (Math.abs(s) > 1) return;
      var a = Math.asin(s);
      out.push(a, Math.PI - a);
    }
    if (reg.type === 'line') lineY(0);
    else if (reg.type === 'strip') { lineY(0); lineY(reg.d); }
    else if (reg.type === 'circle') {
      var dd = Math.hypot(c.x, c.y), R = reg.R;
      if (dd < 1e-9 || dd > R + r || dd < Math.abs(R - r)) return out;
      // 以 c 为圆心看原点方向 β，交点在 β ± γ
      var beta = Math.atan2(-c.y, -c.x);
      var cg = clamp((r * r + dd * dd - R * R) / (2 * r * dd), -1, 1), g = Math.acos(cg);
      out.push(beta + g, beta - g);
    }
    return out;
  }

  // 追踪一个粒子：从 p0 以方向角 a0 出发，先直线进入磁场，再沿圆弧运动到离开磁场，然后直线飞出 tail cm
  // 返回 { segs:[{t:'line',a,b,len}|{t:'arc',c,r,f0,sweep(带符号),len}], enter, exit, c, sweep(圆心角，正值), exitDir, closed, miss }
  function trace(reg, p0, a0, r, s, tail) {
    tail = tail == null ? 80 : tail;
    var u = { x: Math.cos(a0), y: Math.sin(a0) }, segs = [], res = { segs: segs, r: r, s: s };
    var t = rayEnter(reg, p0, u);
    if (t == null) {
      segs.push(lineSeg(p0, { x: p0.x + u.x * tail * 2, y: p0.y + u.y * tail * 2 }));
      res.miss = true;
      return finish(res);
    }
    var E0 = { x: p0.x + u.x * t, y: p0.y + u.y * t };
    if (t > 1e-9) segs.push(lineSeg(p0, E0));
    res.enter = E0;
    var c = center(E0, a0, r, s);
    res.c = c;
    var f0 = Math.atan2(E0.y - c.y, E0.x - c.x), best = TAU;
    if (reg.type !== 'all') {
      boundaryAngles(reg, c, r).forEach(function (f) {
        var th = mod(s * (f - f0), TAU);
        if (th < 1e-6 || th >= best) return;
        // 跳过只与边界相切、没有真正出去的点
        var f1 = f0 + s * (th + 1e-4);
        if (inside(reg, { x: c.x + r * Math.cos(f1), y: c.y + r * Math.sin(f1) })) return;
        best = th;
      });
    }
    segs.push({ t: 'arc', c: c, r: r, f0: f0, sweep: s * best, len: r * best, closed: best >= TAU - 1e-9 });
    res.sweep = best;
    if (best >= TAU - 1e-9) { res.closed = true; return finish(res); }
    var f = f0 + s * best, X = { x: c.x + r * Math.cos(f), y: c.y + r * Math.sin(f) }, ad = f + s * Math.PI / 2;
    res.exit = X; res.exitDir = ad;
    segs.push(lineSeg(X, { x: X.x + Math.cos(ad) * tail, y: X.y + Math.sin(ad) * tail }));
    return finish(res);
  }
  function lineSeg(a, b) { return { t: 'line', a: a, b: b, len: Math.hypot(b.x - a.x, b.y - a.y) }; }
  function finish(res) {
    res.len = res.segs.reduce(function (s, g) { return s + g.len; }, 0);
    return res;
  }
  // 沿轨迹走过路程 l 时的位置和方向角
  function pointAt(tr, l) {
    for (var i = 0; i < tr.segs.length; i++) {
      var g = tr.segs[i];
      if (l <= g.len || i === tr.segs.length - 1) {
        if (g.t === 'line') {
          var k = g.len ? clamp(l / g.len, 0, 1) : 1;
          return { x: g.a.x + (g.b.x - g.a.x) * k, y: g.a.y + (g.b.y - g.a.y) * k, a: Math.atan2(g.b.y - g.a.y, g.b.x - g.a.x), field: false };
        }
        var lc = g.closed ? l : Math.min(l, g.len), sg = g.sweep > 0 ? 1 : -1, f = g.f0 + sg * lc / g.r;
        return { x: g.c.x + g.r * Math.cos(f), y: g.c.y + g.r * Math.sin(f), a: f + sg * Math.PI / 2, field: true };
      }
      l -= g.len;
    }
  }

  // 双边界（0 < y < d）：从下边界以方向角 a 射入，恰好不从上边界射出的临界半径
  function stripCritical(d, a, s) {
    var k = 1 + s * Math.cos(a);
    return k < 1e-6 ? Infinity : d / k;
  }
  // 圆形磁场沿半径方向射入：偏转角 φ 满足 tan(φ/2) = R / r
  function radialDeflect(R, r) { return 2 * Math.atan(R / r); }

  // ---------- 数字格式 ----------
  var SUP = { '-': '⁻', 0: '⁰', 1: '¹', 2: '²', 3: '³', 4: '⁴', 5: '⁵', 6: '⁶', 7: '⁷', 8: '⁸', 9: '⁹' };
  function sci(x, digits) {
    if (!isFinite(x) || x === 0) return String(x);
    var e = Math.floor(Math.log10(Math.abs(x))), m = x / Math.pow(10, e);
    if (Math.abs(m) >= 9.995) { m /= 10; e++; }
    return m.toFixed(digits == null ? 2 : digits) + '×10' + String(e).split('').map(function (c) { return SUP[c]; }).join('');
  }
  function fmtTime(sec) {
    if (sec < 1e-7) return (sec * 1e9).toFixed(0) + ' ns';
    return (sec * 1e6).toFixed(sec < 1e-5 ? 3 : 2) + ' μs';
  }
  function fmtEnergy(ev) { return ev >= 1e6 ? (ev / 1e6).toFixed(2) + ' MeV' : (ev / 1e3).toFixed(ev < 1e4 ? 2 : 1) + ' keV'; }
  function fmtLen(cm) { return cm >= 100 ? (cm / 100).toFixed(2) + ' m' : cm.toFixed(cm < 10 ? 2 : 1) + ' cm'; }

  // ---------- 练习 ----------
  var TYPES = ['dir', 'ratio', 'angle'];
  var DIRS = [{ name: '向右', x: 1, y: 0 }, { name: '向上', x: 0, y: 1 }, { name: '向左', x: -1, y: 0 }, { name: '向下', x: 0, y: -1 }];
  var RATIOS = [['1 : 1', 1], ['1 : 2', 0.5], ['2 : 1', 2], ['1 : √2', Math.SQRT1_2], ['√2 : 1', Math.SQRT2], ['1 : 4', 0.25], ['4 : 1', 4]];
  var CONDS = [
    { key: 'v', name: '以相同的速度', r: function (P) { return P.m / P.q; } },
    { key: 'ek', name: '以相同的动能', r: function (P) { return Math.sqrt(P.m) / P.q; } },
    { key: 'mom', name: '以相同的动量', r: function (P) { return 1 / P.q; } },
    { key: 'u', name: '由静止经同一电场加速后', r: function (P) { return Math.sqrt(P.m / P.q); } }
  ];
  var PAIRS = [['p', 'a'], ['p', 'd'], ['d', 'a']];
  var FRAC = { 30: '1/12', 45: '1/8', 60: '1/6', 90: '1/4', 120: '1/3', 135: '3/8', 150: '5/12', 180: '1/2', 210: '7/12', 240: '2/3', 270: '3/4', 300: '5/6' };

  function pick(rand, arr) { return arr[Math.floor(rand() * arr.length)]; }
  function shuffle(rand, arr) {
    for (var i = arr.length - 1; i > 0; i--) { var j = Math.floor(rand() * (i + 1)), t = arr[i]; arr[i] = arr[j]; arr[j] = t; }
    return arr;
  }
  function ratioName(k) {
    for (var i = 0; i < RATIOS.length; i++) if (Math.abs(RATIOS[i][1] - k) < 1e-6) return RATIOS[i][0];
    return null;
  }
  function options(rand, answer, pool, n) {
    var rest = shuffle(rand, pool.filter(function (o) { return o !== answer; })).slice(0, (n || 4) - 1);
    return shuffle(rand, rest.concat([answer]));
  }

  function quizDir(rand) {
    var q = pick(rand, [1, -1]), v = pick(rand, DIRS), inPlane = rand() < 0.3, P = q > 0 ? '正电荷' : '负电荷';
    if (!inPlane) {
      var bIn = rand() < 0.5, s = turn(q, bIn), F = { x: -s * v.y, y: s * v.x };
      var ans = DIRS.filter(function (d) { return d.x === F.x && d.y === F.y; })[0].name;
      return { type: 'dir', q: q, v: v, bIn: bIn, inPlane: false, answer: ans, options: DIRS.map(function (d) { return d.name; }),
        prompt: '磁场垂直纸面' + (bIn ? '向里' : '向外') + '，' + P + '的速度' + v.name + '，它受到的洛伦兹力方向是？',
        explain: '左手定则：让磁感线垂直穿入掌心（' + (bIn ? '掌心朝外' : '掌心朝里') + '），四指指向' + (q > 0 ? '正电荷的运动方向' : '负电荷运动的反方向') +
          '，拇指所指就是洛伦兹力的方向——' + ans + '。洛伦兹力总与速度垂直，所以粒子向' + ans.slice(1) + '偏转。' };
    }
    // 磁场在纸面内、与速度垂直：洛伦兹力垂直纸面
    var B = pick(rand, DIRS.filter(function (d) { return d.x * v.x + d.y * v.y === 0; }));
    var z = q * (v.x * B.y - v.y * B.x), ans2 = z > 0 ? '垂直纸面向外' : '垂直纸面向里';
    return { type: 'dir', q: q, v: v, B: B, inPlane: true, answer: ans2, options: ['垂直纸面向外', '垂直纸面向里', '与速度同向', '与磁场同向'],
      prompt: '磁场' + B.name + '，' + P + '的速度' + v.name + '，它受到的洛伦兹力方向是？',
      explain: '左手定则：伸开左手，让' + B.name + '的磁感线垂直穿入掌心，四指指向' + (q > 0 ? '正电荷的运动方向（' + v.name + '）' : '负电荷运动的反方向') +
        '，拇指' + ans2.slice(2) + '。洛伦兹力既垂直于速度、又垂直于磁场，所以垂直于二者所在的平面（纸面）。' };
  }

  function mq(P) { return 'm/q = ' + P.m + 'mp/' + (P.q === 1 ? '' : P.q) + 'e'; }
  function quizRatio(rand) {
    var pr = pick(rand, PAIRS), A = PARTICLES[pr[0]], B = PARTICLES[pr[1]], cond = pick(rand, CONDS), what = rand() < 0.7 ? 'r' : 'T';
    var kr = cond.r(A) / cond.r(B), kt = (A.m / A.q) / (B.m / B.q), k = what === 'r' ? kr : kt, ans = ratioName(k);
    var why = what === 'T' ? 'T = 2πm/(qB) 与速度无关，T ∝ m/q：' + A.name + ' ' + mq(A) + '，' + B.name + ' ' + mq(B) + '。'
      : { v: 'r = mv/(qB)，v、B 相同时 r ∝ m/q。',
          ek: 'r = mv/(qB) = √(2mEk)/(qB)，Ek 相同时 r ∝ √m/q。',
          mom: 'r = mv/(qB) = p/(qB)，p 相同时 r ∝ 1/q。',
          u: 'qU = ½mv²，r = mv/(qB) = √(2mU/q)/B，所以 r ∝ √(m/q)。' }[cond.key];
    return { type: 'ratio', a: A.key, b: B.key, cond: cond.key, what: what, k: k, kr: kr, rName: ratioName(kr), tName: ratioName(kt), answer: ans,
      options: options(rand, ans, RATIOS.map(function (r) { return r[0]; })),
      prompt: A.name + '（' + A.sym + '）和' + B.name + '（' + B.sym + '）' + cond.name + '垂直射入同一匀强磁场，' + (what === 'r' ? '轨迹半径' : '运动周期') + '之比 ' +
        (what === 'r' ? 'r₁ : r₂' : 'T₁ : T₂') + ' = ？',
      explain: why + '所以 ' + (what === 'r' ? 'r₁ : r₂' : 'T₁ : T₂') + ' = ' + ans + '（' + A.name + '质量 ' + A.m + 'mp、电荷量 ' + A.q + 'e；' + B.name + ' ' + B.m + 'mp、' + B.q + 'e）。' };
  }

  function quizAngle(rand) {
    var ang = pick(rand, [30, 45, 60, 90]), a = rand() < 0.5 ? ang : 180 - ang, q = pick(rand, [1, -1]), bIn = rand() < 0.5, s = turn(q, bIn);
    var sweep = s > 0 ? 360 - 2 * a : 2 * a, ans = FRAC[sweep];
    var other = FRAC[360 - sweep];
    var pool = ['1/12', '1/8', '1/6', '1/4', '1/3', '3/8', '5/12', '1/2', '7/12', '2/3', '3/4', '5/6'];
    var extra = other !== ans ? [other] : [];
    var opts = shuffle(rand, [ans].concat(extra, shuffle(rand, pool.filter(function (f) { return f !== ans && f !== other; })).slice(0, 3 - extra.length)));
    var dirName = ang === 90 ? '垂直于边界' : '与边界成 ' + ang + '°、斜向' + (a < 90 ? '右' : '左') + '上方';
    return { type: 'angle', ang: ang, a: a, q: q, bIn: bIn, s: s, sweep: sweep, answer: ans, options: opts,
      prompt: '直线边界上方有垂直纸面' + (bIn ? '向里' : '向外') + '的匀强磁场，' + (q > 0 ? '带正电' : '带负电') + '的粒子从 O 点' + dirName + '射入，它在磁场中运动的时间是周期 T 的几分之几？',
      explain: '先用左手定则判断粒子' + (s > 0 ? '逆时针' : '顺时针') + '偏转。从直线边界射入又射出时，进、出磁场的速度与边界的夹角相等，轨迹关于过圆心的边界垂线对称。' +
        '画出圆心，圆心角 θ = ' + sweep + '°，t = θ/360° · T = ' + ans + ' T。' };
  }

  function quiz(rand, avoid, only) {
    var gen = { dir: quizDir, ratio: quizRatio, angle: quizAngle }, q;
    for (var i = 0; i < 10; i++) {
      q = gen[only && gen[only] ? only : pick(rand, TYPES)](rand);
      q.id = q.type + '|' + q.prompt;
      if (q.id !== avoid) break;
    }
    return q;
  }

  window.Lorentz = {
    E: E, MP: MP, DEG: DEG, TAU: TAU, SLOW: SLOW, PARTICLES: PARTICLES, V_RANGE: V_RANGE, B_RANGE: B_RANGE, TYPES: TYPES,
    clamp: clamp, mod: mod,
    radius: radius, period: period, force: force, energyEV: energyEV, speedFor: speedFor, turn: turn, visOmega: visOmega,
    center: center, forceDir: forceDir, inside: inside, trace: trace, pointAt: pointAt,
    stripCritical: stripCritical, radialDeflect: radialDeflect,
    sci: sci, fmtTime: fmtTime, fmtEnergy: fmtEnergy, fmtLen: fmtLen,
    quiz: quiz
  };
})();
