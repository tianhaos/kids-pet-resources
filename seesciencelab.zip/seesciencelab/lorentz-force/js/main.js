(function () {
  var L = window.Lorentz, D = window.LorentzDraw, P = L.PARTICLES, DEG = L.DEG, C = D.COLORS;
  var $ = function (id) { return document.getElementById(id); };
  var qa = function (sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); };
  var NAME = '带电粒子在磁场中的运动';

  var state = {
    scene: 'circle',
    pk: 'p', v: 1, B: 0.1, bIn: true,
    cmp: 'none', show: { arrows: true, radius: true, centers: false, angle: true, critical: true },
    shape: 'line', mode: 'single', ang: 60, d: 10, R: 10, b: 0,
    tau: 0, wait: 0, paused: false,
    quiz: null, quizOnly: null, answered: false, correct: false, choice: null, score: { n: 0, ok: 0 }
  };

  var HINTS = {
    circle: '点击画面重新发射 · 比较半径和周期',
    bound: '拖动画面改变入射方向',
    quiz: '带电粒子在磁场中的运动 · 判断练习'
  };
  var SHAPES = ['line', 'strip', 'circle'], MODES = ['single', 'rotate', 'scale', 'beam'], CMPS = ['none', '2v', 'other'];

  var stage = $('stage'), panel = $('panel'), cv = $('view');
  var view = D.View(cv);
  function setSeg(attr, val) { qa('[data-' + attr + ']').forEach(function (b) { b.classList.toggle('on', b.dataset[attr] === String(val)); }); }
  function relaunch() { state.tau = 0; state.wait = 0; }
  function particle() { return P[state.pk]; }
  function s0() { return L.turn(particle().q, state.bIn); }
  function color(P0, k) { return k == null ? D.chargeColor(P0.q) : D.mix(P0.q > 0 ? C.POS : C.NEG, P0.q > 0 ? C.F : C.ALT, k); }

  // ---------- 场景 ----------
  qa('[data-scene]').forEach(function (b) {
    b.addEventListener('click', function () { setScene(b.dataset.scene); Analytics.track(NAME, '场景', b.textContent); });
  });
  function setScene(sc) {
    state.scene = sc;
    if (sc === 'quiz' && !state.quiz) newQuiz();
    $('rName').className = '';
    relaunch();
    syncUI();
  }

  // ---------- 粒子与磁场 ----------
  qa('[data-pk]').forEach(function (b) {
    b.addEventListener('click', function () { state.pk = b.dataset.pk; relaunch(); syncUI(); Analytics.track(NAME, '粒子', P[state.pk].name); });
  });
  qa('[data-bdir]').forEach(function (b) {
    b.addEventListener('click', function () { state.bIn = b.dataset.bdir === 'in'; relaunch(); syncUI(); Analytics.track(NAME, '磁场方向', b.textContent); });
  });
  qa('[data-cmp]').forEach(function (b) {
    b.addEventListener('click', function () { state.cmp = b.dataset.cmp; relaunch(); syncUI(); Analytics.track(NAME, '对比', b.textContent); });
  });
  qa('[data-shape]').forEach(function (b) {
    b.addEventListener('click', function () {
      state.shape = b.dataset.shape;
      if (state.shape !== 'circle' && state.mode === 'beam') state.mode = 'single';
      relaunch(); syncUI(); Analytics.track(NAME, '边界', b.textContent);
    });
  });
  qa('[data-mode]').forEach(function (b) {
    b.addEventListener('click', function () { state.mode = b.dataset.mode; relaunch(); syncUI(); Analytics.track(NAME, '发射方式', b.textContent); });
  });
  function bindSlider(id, get, set, restart) {
    var el = $(id);
    el.addEventListener('input', function () { set(parseFloat(el.value)); if (restart) relaunch(); });
    el.addEventListener('change', function () { Analytics.track(NAME, '滑块', id); });
    return { el: el, get: get };
  }
  var sliders = [
    bindSlider('v', function () { return state.v; }, function (x) { state.v = x; }, true),
    bindSlider('B', function () { return state.B; }, function (x) { state.B = x; }, true),
    bindSlider('ang', function () { return state.ang; }, function (x) { state.ang = x; }, true),
    bindSlider('bOff', function () { return Math.round(state.b * 100); }, function (x) { state.b = x / 100; }, true),
    bindSlider('d', function () { return state.d; }, function (x) { state.d = x; }, true),
    bindSlider('R', function () { return state.R; }, function (x) { state.R = x; }, true)
  ];
  [['showArrows', 'arrows'], ['showRadius', 'radius'], ['showCenters', 'centers'], ['showAngle', 'angle'], ['showCritical', 'critical']].forEach(function (p) {
    $(p[0]).addEventListener('change', function () { state.show[p[1]] = $(p[0]).checked; });
  });
  $('pause').addEventListener('click', function () { state.paused = !state.paused; syncUI(); });
  $('relaunch').addEventListener('click', function () { relaunch(); state.paused = false; syncUI(); Analytics.track(NAME, '重新发射', state.scene); });
  $('relaunch2').addEventListener('click', function () { relaunch(); state.paused = false; syncUI(); });
  // 令 r 等于圆形磁场半径（磁聚焦）或取双边界的临界速度
  $('fitR').addEventListener('click', function () {
    var Pp = particle(), r;
    if (state.shape === 'circle') r = state.R;
    else {
      r = L.stripCritical(state.d, state.ang * DEG, s0());
      if (!isFinite(r)) return;
    }
    state.v = L.clamp(Math.round(L.speedFor(Pp, r, state.B) * 1000) / 1000, L.V_RANGE[0], L.V_RANGE[1]);
    relaunch();
    Analytics.track(NAME, '一键', state.shape === 'circle' ? 'r=R' : '临界速度');
  });

  // ---------- 画布：点击重新发射 / 拖动入射方向 ----------
  var drag = false;
  function local(e) { var r = cv.getBoundingClientRect(); return { x: e.clientX - r.left, y: e.clientY - r.top }; }
  function canDrag() {
    if (state.scene !== 'bound') return false;
    if (state.shape === 'circle') return state.mode === 'single' || state.mode === 'scale';
    return state.mode === 'single' || state.mode === 'scale';
  }
  function dragTo(p) {
    var g = view.geo(); if (!g || !g.fr) return;
    var w = g.fr.w(p.x, p.y);
    if (state.shape === 'circle') state.b = L.clamp(Math.round(w.y / state.R * 100) / 100, -0.95, 0.95);
    else {
      var a = Math.atan2(w.y, w.x) / DEG;
      if (a < 0) a = a < -90 ? 175 : 5;
      state.ang = L.clamp(Math.round(a), 5, 175);
    }
    relaunch();
  }
  cv.addEventListener('pointerdown', function (e) {
    if (e.button !== 0) return;
    if (state.scene === 'circle') { relaunch(); state.paused = false; syncUI(); return; }
    if (!canDrag()) { if (state.scene === 'bound') relaunch(); return; }
    drag = true;
    try { cv.setPointerCapture(e.pointerId); } catch (err) { /* 合成事件 */ }
    Analytics.track(NAME, '拖动', state.shape);
    dragTo(local(e));
  });
  cv.addEventListener('pointermove', function (e) {
    if (drag) { dragTo(local(e)); return; }
    cv.style.cursor = state.scene === 'circle' || canDrag() ? 'pointer' : '';
  });
  function endDrag(e) {
    if (!drag) return;
    drag = false;
    if (cv.hasPointerCapture(e.pointerId)) cv.releasePointerCapture(e.pointerId);
  }
  cv.addEventListener('pointerup', endDrag);
  cv.addEventListener('pointercancel', endDrag);

  // ---------- 场景一的粒子 ----------
  function circleParts() {
    var Pp = particle(), list = [{ P: Pp, v: state.v, color: color(Pp), name: '' }];
    if (state.cmp === '2v') list.push({ P: Pp, v: state.v * 2, color: C.ALT, name: '2v' });
    if (state.cmp === 'other') { var O = P[state.pk === 'a' ? 'p' : 'a']; list.push({ P: O, v: state.v, color: C.ALT, name: O.name }); }
    if (state.cmp === 'other') list[0].name = Pp.name;
    var rBig = 0;
    list.forEach(function (it) { it.r = L.radius(it.P, it.v, state.B); it.s = L.turn(it.P.q, state.bIn); if (it.s === s0()) rBig = Math.max(rBig, it.r); });
    var y0 = -s0() * Math.min(rBig, 22);
    list.forEach(function (it) {
      it.T = L.period(it.P, state.B);
      it.tr = L.trace({ type: 'all' }, { x: 0, y: y0 }, 0, it.r, it.s);
      it.q = it.P.q;
      it.l = L.TAU * it.r / (it.T * L.SLOW) * state.tau;
    });
    return list;
  }

  // ---------- 场景二的粒子 ----------
  function region() {
    return state.shape === 'line' ? { type: 'line' } : state.shape === 'strip' ? { type: 'strip', d: state.d } : { type: 'circle', R: state.R };
  }
  function boundParts() {
    var Pp = particle(), reg = region(), s = s0(), r = L.radius(Pp, state.v, state.B), T = L.period(Pp, state.B), a = state.ang * DEG;
    var circle = state.shape === 'circle', list = [], X0 = -state.R - 10, src = null, locus = null;
    function add(p0, ang, rr, k) {
      var tr = L.trace(reg, p0, ang, rr, s, 70);
      list.push({ tr: tr, r: rr, a: ang, q: Pp.q, color: color(Pp, k), l: L.TAU * rr / (T * L.SLOW) * state.tau });
    }
    var i, n;
    if (state.mode === 'single') {
      if (circle) add({ x: X0, y: state.b * state.R }, 0, r);
      else add({ x: -Math.cos(a) * 10, y: -Math.sin(a) * 10 }, a, r);
      if (!circle) src = { x: 0, y: 0, name: 'O' };
    } else if (state.mode === 'rotate') {
      if (circle) {
        for (i = -80, n = 0; i <= 80; i += 10, n++) add({ x: -state.R, y: 0 }, i * DEG, r, n / 16);
        src = { x: -state.R, y: 0, name: 'P' };
        locus = { t: 'circle', c: { x: -state.R, y: 0 }, r: r };
      } else {
        for (i = 10, n = 0; i <= 170; i += 10, n++) add({ x: 0, y: 0 }, i * DEG, r, n / 16);
        src = { x: 0, y: 0, name: 'O' };
        locus = { t: 'circle', c: { x: 0, y: 0 }, r: r };
      }
    } else if (state.mode === 'scale') {
      var ks = [];
      for (i = 0; i < 8; i++) ks.push(0.3 * Math.pow(10, i / 7));
      var p0 = circle ? { x: X0, y: state.b * state.R } : { x: 0, y: 0 }, ang0 = circle ? 0 : a;
      ks.forEach(function (k, j) { add(p0, ang0, r * k, j / 7); });
      var E = list[0].tr.enter;
      if (E) {
        var F = L.forceDir(ang0, s), m = r * ks[ks.length - 1];
        locus = { t: 'line', a: E, b: { x: E.x + F.x * m, y: E.y + F.y * m } };
      }
      if (!circle) src = { x: 0, y: 0, name: 'O' };
    } else {
      for (i = -6; i <= 6; i++) add({ x: X0, y: i * 0.15 * state.R }, 0, r, (i + 6) / 12);
      // 平行射入圆形磁场：各轨迹圆心都在以 (0, s·r) 为圆心、半径 R 的圆上
      locus = { t: 'circle', c: { x: 0, y: s * r }, r: state.R };
    }
    var critical = null;
    if (state.shape === 'strip' && state.mode !== 'rotate' && state.mode !== 'beam') {
      var rc = L.stripCritical(state.d, a, s);
      if (isFinite(rc) && rc < 400) critical = L.trace(reg, { x: 0, y: 0 }, a, rc, s, 0);
    }
    return { reg: reg, list: list, s: s, r: r, T: T, src: src, locus: locus, critical: critical };
  }

  // ---------- 练习 ----------
  function newQuiz() {
    state.quiz = L.quiz(Math.random, state.quiz && state.quiz.id, state.quizOnly);
    state.answered = false; state.choice = null;
    var box = $('quizOpts');
    box.innerHTML = '';
    state.quiz.options.forEach(function (o) {
      var b = document.createElement('button');
      b.className = 'small';
      b.textContent = o;
      b.addEventListener('click', function () { answer(o); });
      box.appendChild(b);
    });
    syncUI();
  }
  function answer(o) {
    if (state.answered) return;
    state.answered = true;
    state.choice = o;
    state.correct = o === state.quiz.answer;
    state.score.n++; if (state.correct) state.score.ok++;
    Analytics.track(NAME, '练习', state.quiz.type + (state.correct ? ' 对' : ' 错'));
    syncUI();
  }
  $('nextQ').addEventListener('click', newQuiz);
  $('showQ').addEventListener('click', function () {
    var q = state.quiz;
    state.pk = q.type === 'ratio' ? q.a : q.q > 0 ? 'p' : 'h';
    if (q.type === 'ratio') { state.cmp = 'other'; setScene('circle'); }
    else if (q.type === 'angle') { state.bIn = q.bIn; state.shape = 'line'; state.mode = 'single'; state.ang = q.a; setScene('bound'); }
    else { if (!q.inPlane) state.bIn = q.bIn; state.cmp = 'none'; setScene('circle'); }
  });

  // ---------- 面板 ----------
  $('panelToggle').addEventListener('click', function () { panel.classList.toggle('collapsed'); });
  if (window.matchMedia('(max-width: 760px)').matches) panel.classList.add('collapsed');
  window.addEventListener('keydown', function (e) {
    var tg = e.target.tagName;
    if (tg === 'INPUT' || tg === 'SELECT' || tg === 'BUTTON' || tg === 'TEXTAREA') return;
    if (e.code === 'Space' && state.scene !== 'quiz') { e.preventDefault(); state.paused = !state.paused; syncUI(); }
  });

  function syncUI() {
    var sc = state.scene, circle = state.shape === 'circle';
    setSeg('scene', sc);
    qa('[data-for]').forEach(function (el) { el.hidden = el.dataset.for.split(' ').indexOf(sc) < 0; });
    qa('[data-shape-for]').forEach(function (el) { el.hidden = el.dataset.shapeFor.split(' ').indexOf(state.shape) < 0; });
    $('hint').textContent = sc !== 'bound' ? HINTS[sc] : !canDrag() ? '点击画面重新发射' : circle ? '上下拖动画面改变入射点' : HINTS[sc];
    setSeg('pk', state.pk);
    setSeg('bdir', state.bIn ? 'in' : 'out');
    setSeg('cmp', state.cmp);
    setSeg('shape', state.shape);
    setSeg('mode', state.mode);
    $('modeBeam').hidden = !circle;
    $('angRow').hidden = circle || state.mode === 'rotate';
    $('bRow').hidden = !circle || state.mode === 'rotate' || state.mode === 'beam';
    $('fitR').hidden = state.shape === 'line' || state.mode === 'rotate';
    $('fitR').textContent = circle ? '令 r = R（磁聚焦）' : '取临界速度';
    $('critRow').hidden = state.shape !== 'strip';
    [['showArrows', 'arrows'], ['showRadius', 'radius'], ['showCenters', 'centers'], ['showAngle', 'angle'], ['showCritical', 'critical']].forEach(function (p) { $(p[0]).checked = state.show[p[1]]; });
    $('pause').textContent = state.paused ? '▶ 继续' : '❚❚ 暂停';
    var q = state.quiz;
    if (q) {
      $('quizQ').textContent = q.prompt;
      qa('#quizOpts button').forEach(function (b) {
        b.disabled = state.answered;
        b.classList.toggle('on', state.answered && b.textContent === q.answer);
        b.classList.toggle('no', state.answered && b.textContent === state.choice && !state.correct);
      });
      $('quizMsg').innerHTML = !state.answered ? ''
        : '<b class="' + (state.correct ? 'ok">✓ 答对了' : 'bad">✗ 应选「' + q.answer + '」') + '</b>' + q.explain;
      $('nextQ').textContent = state.answered ? '下一题 →' : '换一题';
      $('showQ').hidden = !state.answered;
    }
  }

  // ---------- 读数 ----------
  var lastText = {};
  function setText(id, s) { if (lastText[id] !== s) { lastText[id] = s; $(id).textContent = s; } }
  function rows(list) {
    for (var k = 1; k <= 5; k++) {
      var r = list[k - 1] || ['', ''];
      setText('d' + k, r[0]); setText('r' + k, r[1]);
      $('d' + k).hidden = $('r' + k).hidden = !r[0];
    }
  }
  function turnName(s) { return s > 0 ? '逆时针转' : '顺时针转'; }
  function deg(x) { return (x / DEG).toFixed(x / DEG < 10 ? 1 : 0) + '°'; }

  function readCircle(parts) {
    var a = parts[0], Pp = a.P, t = state.tau / L.SLOW;
    setText('rName', 'r = ' + L.fmtLen(a.r));
    setText('rKind', turnName(a.s));
    var tip;
    if (state.cmp === '2v') tip = '速度加倍，半径也加倍，但周期不变：两个粒子同时回到出发点。';
    else if (state.cmp === 'other') {
      var b = parts[1];
      tip = b.P.name + '的比荷 q/m 是' + Pp.name + '的 ' + Math.abs((b.P.q / b.P.m) / (Pp.q / Pp.m)).toFixed(1).replace('.0', '') + ' 倍：同速度时半径之比 ' +
        (a.r / b.r).toFixed(2) + '，周期之比 ' + (a.T / b.T).toFixed(2) + (a.s !== b.s ? '；电性相反，偏转方向相反。' : '。');
    } else tip = '洛伦兹力始终与速度垂直，只改变速度方向、不改变速度大小，提供向心力：qvB = mv²/r。';
    setText('rTip', tip);
    var list = [
      ['洛伦兹力', 'F = qvB = ' + L.sci(L.force(Pp, a.v, state.B)) + ' N'],
      ['半径', 'r = mv/(qB) = ' + L.fmtLen(a.r)],
      ['周期', 'T = 2πm/(qB) = ' + L.fmtTime(a.T) + '（与 v 无关）'],
      ['动能', L.fmtEnergy(L.energyEV(Pp, a.v)) + '，保持不变（洛伦兹力不做功）'],
      ['已运动', L.fmtTime(t) + '，' + (t / a.T).toFixed(2) + ' 圈']
    ];
    if (parts[1]) list[3] = ['对比粒子', parts[1].name + '：r = ' + L.fmtLen(parts[1].r) + '，T = ' + L.fmtTime(parts[1].T)];
    rows(list);
  }

  function exitName(tr) {
    if (tr.miss) return '没有进入磁场';
    if (!tr.exit) return '在磁场中做完整的圆周运动';
    if (state.shape === 'line') return '从边界射出，距 O ' + L.fmtLen(Math.hypot(tr.exit.x, tr.exit.y));
    if (state.shape === 'strip') return tr.exit.y > state.d / 2 ? '从上边界射出' : '从下边界射回，距 O ' + L.fmtLen(Math.abs(tr.exit.x));
    var ad = tr.exitDir, X = tr.exit, radial = Math.abs(X.x * Math.sin(ad) - X.y * Math.cos(ad)) < 1e-3 * state.R;
    return radial ? '沿半径方向射出' : '从圆周上射出';
  }
  function readBound(b) {
    var Pp = particle(), tr = b.list[0].tr, circle = state.shape === 'circle';
    if (state.mode === 'single') {
      setText('rName', tr.miss ? '未进入磁场' : '圆心角 θ = ' + deg(tr.sweep));
      setText('rKind', tr.miss ? '' : turnName(b.s));
      var tip;
      if (state.shape === 'line') tip = '直线边界：进、出磁场时速度与边界的夹角相等；偏转角 = 圆心角 θ。';
      else if (state.shape === 'strip') tip = '轨迹恰与上边界相切时是临界情况：r 大于临界半径就从上边界射出，否则从下边界射回。';
      else tip = Math.abs(state.b) < 0.005 ? '沿半径方向射入，必沿半径方向射出；tan(θ/2) = R/r。' : '入射方向不过圆心 O，出射方向也不沿半径。拖到正中（b = 0）试试沿半径射入。';
      setText('rTip', tip);
      var list = [
        ['半径', 'r = mv/(qB) = ' + L.fmtLen(b.r)],
        ['在磁场中', tr.miss ? '—' : 't = θ/360° · T = ' + L.fmtTime(tr.sweep / L.TAU * b.T)],
        ['出射', exitName(tr)]
      ];
      if (state.shape === 'strip' && b.critical) {
        var vc = L.speedFor(Pp, b.critical.r, state.B);
        list.push(['临界', 'r₀ = ' + L.fmtLen(b.critical.r) + '，v₀ = ' + vc.toFixed(2) + '×10⁶ m/s']);
      }
      if (circle && !tr.miss && Math.abs(state.b) < 0.005) list.push(['验证', 'tan(θ/2) = ' + Math.tan(tr.sweep / 2).toFixed(3) + '，R/r = ' + (state.R / b.r).toFixed(3)]);
      list.push(['周期', 'T = ' + L.fmtTime(b.T)]);
      rows(list);
      return;
    }
    var sw = b.list.filter(function (p) { return !p.tr.miss && p.tr.exit; }).map(function (p) { return p.tr.sweep; });
    var mn = Math.min.apply(null, sw), mx = Math.max.apply(null, sw);
    var names = { rotate: '旋转圆：速度大小相同、方向不同', scale: '放缩圆：速度方向相同、大小不同', beam: '平行粒子束射入圆形磁场' };
    setText('rName', names[state.mode].split('：')[0]);
    setText('rKind', b.list.length + ' 个粒子');
    var tips = {
      rotate: '各轨迹半径相同，圆心都在以粒子源为圆心、半径为 r 的圆上；把轨迹圆绕粒子源旋转，就能找出临界轨迹。',
      scale: state.shape === 'line' ? '速度方向相同时，各轨迹的圆心在同一条直线上；从直线边界射出的粒子圆心角都相同，在磁场中运动的时间相等。'
        : '速度方向相同时，各轨迹的圆心在同一条直线上（与速度垂直）；速度越大半径越大、圆心角越小，在磁场中运动的时间越短。',
      beam: Math.abs(b.r - state.R) < 0.02 * state.R ? '磁聚焦：轨迹半径等于磁场半径时，平行射入的粒子都从同一点射出。'
        : '点「令 r = R」，看平行射入的粒子会聚到一点（磁聚焦）。'
    };
    setText('rTip', tips[state.mode]);
    rows([
      ['半径', state.mode === 'scale' ? L.fmtLen(b.list[0].r) + ' ~ ' + L.fmtLen(b.list[b.list.length - 1].r) : 'r = ' + L.fmtLen(b.r)],
      ['圆心角', sw.length ? deg(mn) + ' ~ ' + deg(mx) : '—'],
      ['在磁场中', sw.length ? L.fmtTime(mn / L.TAU * b.T) + ' ~ ' + L.fmtTime(mx / L.TAU * b.T) : '—'],
      ['周期', 'T = ' + L.fmtTime(b.T) + '（都相同）']
    ]);
  }

  function readQuiz() {
    var q = state.quiz, sc = state.score;
    setText('rName', !state.answered ? '判断练习' : state.correct ? '✓ 答对了' : '✗ 答错了');
    $('rName').className = !state.answered ? '' : state.correct ? 'ok' : 'bad';
    setText('rKind', '得分 ' + sc.ok + ' / ' + sc.n);
    setText('rTip', state.answered ? q.explain : q.prompt);
    rows([]);
  }

  // ---------- 尺寸与主循环 ----------
  function resize() { view.resize(stage.clientWidth, stage.clientHeight); }
  new ResizeObserver(resize).observe(stage);

  // 支持 ?scene=circle|bound|quiz；&p=p|d|a|h；&v=0.2~5（×10⁶ m/s）；&B=0.05~0.5（T）；&out=1（磁场向外）；&cmp=2v|other；
  // 有界磁场 &shape=line|strip|circle、&mode=single|rotate|scale|beam、&ang=5~175、&d=、&R=（cm）、&b=−0.95~0.95；练习 &q=dir|ratio|angle
  var qs = new URLSearchParams(location.search);
  function num(k, lo, hi) { var x = parseFloat(qs.get(k)); return isFinite(x) && x >= lo && x <= hi ? x : null; }
  var x;
  if (HINTS[qs.get('scene')]) state.scene = qs.get('scene');
  if (P[qs.get('p')]) state.pk = qs.get('p');
  if ((x = num('v', L.V_RANGE[0], L.V_RANGE[1])) != null) state.v = x;
  if ((x = num('B', L.B_RANGE[0], L.B_RANGE[1])) != null) state.B = x;
  if (qs.get('out') === '1') state.bIn = false;
  if (CMPS.indexOf(qs.get('cmp')) >= 0) state.cmp = qs.get('cmp');
  if (SHAPES.indexOf(qs.get('shape')) >= 0) state.shape = qs.get('shape');
  if (MODES.indexOf(qs.get('mode')) >= 0) state.mode = qs.get('mode');
  if (state.mode === 'beam' && state.shape !== 'circle') state.shape = 'circle';
  if ((x = num('ang', 5, 175)) != null) state.ang = x;
  if ((x = num('d', 4, 30)) != null) state.d = x;
  if ((x = num('R', 4, 20)) != null) state.R = x;
  if ((x = num('b', -0.95, 0.95)) != null) state.b = x;
  if (L.TYPES.indexOf(qs.get('q')) >= 0) state.quizOnly = qs.get('q');

  resize();
  setScene(state.scene);

  var lastT = performance.now();
  function frame(now) {
    var dt = Math.min((now - lastT) / 1000, 0.1);
    lastT = now;
    var sc = state.scene;
    if (!state.paused && sc !== 'quiz') state.tau += dt;
    sliders.forEach(function (s) { if (document.activeElement !== s.el) s.el.value = s.get(); });
    setText('vOut', state.v.toFixed(2) + '×10⁶ m/s');
    setText('BOut', state.B.toFixed(2) + ' T');
    setText('angOut', state.ang.toFixed(0) + '°');
    setText('bOffOut', (state.b * state.R).toFixed(1) + ' cm');
    setText('dOut', state.d.toFixed(0) + ' cm');
    setText('ROut', state.R.toFixed(0) + ' cm');

    if (sc === 'circle') {
      var parts = circleParts();
      view.drawCircle({ bIn: state.bIn, B: state.B, parts: parts, arrows: state.show.arrows, radius: state.show.radius });
      readCircle(parts);
    } else if (sc === 'bound') {
      var b = boundParts(), g = view.geo();
      // 所有粒子都飞出画面后停一会儿，再重新发射
      if (g && g.fr && !state.paused) {
        var v = g.fr.view, done = b.list.every(function (pt) {
          if (pt.l >= pt.tr.len) return true;
          var p = L.pointAt(pt.tr, pt.l);
          return !p.field && pt.l > pt.tr.segs[0].len && (p.x < v.x0 - 2 || p.x > v.x1 + 2 || p.y < v.y0 - 2 || p.y > v.y1 + 2);
        });
        if (done) { state.wait += dt; if (state.wait > 1) relaunch(); }
      }
      view.drawBound({ reg: b.reg, bIn: state.bIn, B: state.B, parts: b.list, src: b.src, a0: b.list[0].a,
        annotate: state.mode === 'single' && state.show.angle, centers: state.show.centers, locus: state.show.centers ? b.locus : null,
        critical: state.show.critical ? b.critical : null });
      readBound(b);
    } else {
      view.drawQuiz(state.quiz, state.answered, { quizH: $('quizBar').offsetHeight });
      readQuiz();
    }
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // 调试用
  window.__model = {
    state: state, setScene: setScene, newQuiz: newQuiz, syncUI: syncUI, relaunch: relaunch,
    setV: function (v) { state.v = L.clamp(v, L.V_RANGE[0], L.V_RANGE[1]); relaunch(); },
    setB: function (B) { state.B = L.clamp(B, L.B_RANGE[0], L.B_RANGE[1]); relaunch(); },
    setTau: function (t) { state.tau = t; }
  };
})();
