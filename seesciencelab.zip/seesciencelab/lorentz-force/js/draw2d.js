// 2D 绘制：磁场区域（⊗/⊙ 符号）、粒子轨迹（直线段 + 圆弧段）、速度与洛伦兹力箭头、圆心与圆心角标注、练习题画面
// 世界坐标同 Lorentz：x 右、y 上，单位 cm；frame(R, box) 把世界范围 box 等比放进屏幕矩形 R
(function () {
  var L = window.Lorentz, DEG = L.DEG;
  var POS = '#ff7a59', NEG = '#4fc3f7', V_COL = '#7ee081', F_COL = '#ffc94a', ALT = '#c9a7ff';
  var MUTED = '#8d99ab', TEXT = '#e6ebf2', EDGE = '#6f86c9', MARK = 'rgba(141,153,171,.3)';
  var FONT = '-apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", sans-serif';

  function font(px, w) { return (w ? w + ' ' : '') + px + 'px ' + FONT; }
  function label(ctx, s, x, y, o) {
    o = o || {};
    ctx.font = font(o.size || 12, o.bold ? 600 : null);
    ctx.textAlign = o.align || 'center'; ctx.textBaseline = o.base || 'middle';
    ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(5,7,13,.85)'; ctx.strokeText(s, x, y);
    ctx.fillStyle = o.color || TEXT; ctx.fillText(s, x, y);
  }
  function arrow(ctx, x1, y1, x2, y2, size, color, width) {
    var a = Math.atan2(y2 - y1, x2 - x1);
    ctx.strokeStyle = ctx.fillStyle = color; ctx.lineWidth = width || 2.4; ctx.setLineDash([]);
    ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2 - Math.cos(a) * size * 0.6, y2 - Math.sin(a) * size * 0.6); ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(x2, y2);
    ctx.lineTo(x2 - size * Math.cos(a - 0.42), y2 - size * Math.sin(a - 0.42));
    ctx.lineTo(x2 - size * Math.cos(a + 0.42), y2 - size * Math.sin(a + 0.42));
    ctx.closePath(); ctx.fill();
  }
  function mix(c1, c2, k) {
    var a = parseInt(c1.slice(1), 16), b = parseInt(c2.slice(1), 16);
    var r = Math.round((a >> 16) + ((b >> 16) - (a >> 16)) * k), g = Math.round((a >> 8 & 255) + ((b >> 8 & 255) - (a >> 8 & 255)) * k),
      bl = Math.round((a & 255) + ((b & 255) - (a & 255)) * k);
    return 'rgb(' + r + ',' + g + ',' + bl + ')';
  }
  function chargeColor(q) { return q > 0 ? POS : NEG; }

  // ---------- 世界 ⇄ 屏幕 ----------
  function frame(R, box) {
    var k = Math.min(R.w / (box.x1 - box.x0), R.h / (box.y1 - box.y0));
    var cx = R.x + R.w / 2, cy = R.y + R.h / 2, mx = (box.x0 + box.x1) / 2, my = (box.y0 + box.y1) / 2;
    return {
      k: k, R: R,
      p: function (x, y) { return { x: cx + (x - mx) * k, y: cy - (y - my) * k }; },
      w: function (sx, sy) { return { x: mx + (sx - cx) / k, y: my - (sy - cy) / k }; },
      // 屏幕矩形 R 对应的世界范围
      view: { x0: mx - R.w / 2 / k, x1: mx + R.w / 2 / k, y0: my - R.h / 2 / k, y1: my + R.h / 2 / k }
    };
  }

  // ---------- 磁场区域 ----------
  function regionPath(ctx, fr, reg) {
    var v = fr.view, a, b;
    ctx.beginPath();
    if (reg.type === 'circle') { var c = fr.p(0, 0); ctx.arc(c.x, c.y, reg.R * fr.k, 0, 7); return; }
    var yTop = reg.type === 'strip' ? reg.d : v.y1 + 5, yBot = reg.type === 'all' ? v.y0 - 5 : 0;
    a = fr.p(v.x0 - 5, yTop); b = fr.p(v.x1 + 5, yBot);
    ctx.rect(a.x, a.y, b.x - a.x, b.y - a.y);
  }
  function field(ctx, fr, reg, bIn, o) {
    o = o || {};
    ctx.save();
    ctx.beginPath(); ctx.rect(fr.R.x, fr.R.y, fr.R.w, fr.R.h); ctx.clip();
    if (reg.type !== 'all') {
      regionPath(ctx, fr, reg);
      ctx.fillStyle = 'rgba(111,134,201,.09)'; ctx.fill();
    }
    ctx.save();
    regionPath(ctx, fr, reg); ctx.clip();
    // 磁感线符号：每 sp 像素一个，对齐世界原点
    var sp = Math.max(26, Math.min(44, fr.k * 4)), o0 = fr.p(0, 0), R = fr.R, rr = Math.max(3.5, Math.min(5.5, sp * 0.13));
    var i0 = Math.floor((R.x - o0.x) / sp), i1 = Math.ceil((R.x + R.w - o0.x) / sp), j0 = Math.floor((R.y - o0.y) / sp), j1 = Math.ceil((R.y + R.h - o0.y) / sp);
    ctx.strokeStyle = ctx.fillStyle = o.markColor || MARK; ctx.lineWidth = 1.2; ctx.setLineDash([]);
    for (var i = i0; i <= i1; i++) for (var j = j0; j <= j1; j++) {
      var x = o0.x + (i + 0.5) * sp, y = o0.y + (j + 0.5) * sp;
      ctx.beginPath(); ctx.arc(x, y, rr, 0, 7); ctx.stroke();
      if (bIn) {
        var d = rr * 0.7;
        ctx.beginPath(); ctx.moveTo(x - d, y - d); ctx.lineTo(x + d, y + d); ctx.moveTo(x + d, y - d); ctx.lineTo(x - d, y + d); ctx.stroke();
      } else { ctx.beginPath(); ctx.arc(x, y, 1.6, 0, 7); ctx.fill(); }
    }
    ctx.restore();
    // 边界
    ctx.strokeStyle = EDGE; ctx.lineWidth = 2; ctx.setLineDash([]);
    if (reg.type === 'circle') { regionPath(ctx, fr, reg); ctx.stroke(); }
    else if (reg.type !== 'all') {
      [0].concat(reg.type === 'strip' ? [reg.d] : []).forEach(function (y) {
        var a = fr.p(fr.view.x0 - 5, y), b = fr.p(fr.view.x1 + 5, y);
        ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
      });
    }
    ctx.restore();
  }

  // ---------- 轨迹 ----------
  // 画轨迹上路程 [l0, l1] 的部分
  function trackPath(ctx, fr, tr, l0, l1) {
    var acc = 0;
    ctx.beginPath();
    tr.segs.forEach(function (g) {
      var a = Math.max(l0, acc), b = Math.min(l1, acc + g.len);
      if (b > a) {
        if (g.t === 'line') {
          var k0 = (a - acc) / g.len, k1 = (b - acc) / g.len;
          var p = fr.p(g.a.x + (g.b.x - g.a.x) * k0, g.a.y + (g.b.y - g.a.y) * k0), q = fr.p(g.a.x + (g.b.x - g.a.x) * k1, g.a.y + (g.b.y - g.a.y) * k1);
          ctx.moveTo(p.x, p.y); ctx.lineTo(q.x, q.y);
        } else {
          var sg = g.sweep > 0 ? 1 : -1, f0 = g.f0 + sg * (a - acc) / g.r, f1 = g.f0 + sg * (b - acc) / g.r, c = fr.p(g.c.x, g.c.y);
          var s0 = fr.p(g.c.x + g.r * Math.cos(f0), g.c.y + g.r * Math.sin(f0));
          ctx.moveTo(s0.x, s0.y);
          // 屏幕 y 向下：世界逆时针 = 屏幕逆时针（anticlockwise = true）
          ctx.arc(c.x, c.y, g.r * fr.k, -f0, -f1, sg > 0);
        }
      }
      acc += g.len;
    });
  }
  function track(ctx, fr, tr, l0, l1, color, o) {
    o = o || {};
    trackPath(ctx, fr, tr, l0, l1);
    ctx.strokeStyle = color; ctx.lineWidth = o.width || 2.2; ctx.globalAlpha = o.alpha == null ? 1 : o.alpha;
    ctx.setLineDash(o.dash || []); ctx.stroke(); ctx.setLineDash([]); ctx.globalAlpha = 1;
  }
  function particle(ctx, p, q, color, r) {
    r = r || 8;
    var g = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, r * 2.4);
    g.addColorStop(0, color); g.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.globalAlpha = 0.45; ctx.fillStyle = g; ctx.beginPath(); ctx.arc(p.x, p.y, r * 2.4, 0, 7); ctx.fill(); ctx.globalAlpha = 1;
    ctx.fillStyle = color; ctx.beginPath(); ctx.arc(p.x, p.y, r, 0, 7); ctx.fill();
    ctx.strokeStyle = '#111'; ctx.lineWidth = 1.8;
    var d = r * 0.5;
    ctx.beginPath(); ctx.moveTo(p.x - d, p.y); ctx.lineTo(p.x + d, p.y);
    if (q > 0) { ctx.moveTo(p.x, p.y - d); ctx.lineTo(p.x, p.y + d); }
    ctx.stroke();
  }
  // 粒子处的速度和洛伦兹力箭头
  function vfArrows(ctx, sp, a, s, field, len, labels) {
    var vx = Math.cos(a), vy = -Math.sin(a);
    arrow(ctx, sp.x, sp.y, sp.x + vx * len, sp.y + vy * len, 10, V_COL);
    if (labels) label(ctx, 'v', sp.x + vx * (len + 12), sp.y + vy * (len + 12), { color: V_COL, bold: true, size: 13 });
    if (!field) return;
    var F = L.forceDir(a, s), fx = F.x, fy = -F.y, fl = len * 0.8;
    arrow(ctx, sp.x, sp.y, sp.x + fx * fl, sp.y + fy * fl, 10, F_COL);
    if (labels) label(ctx, 'F', sp.x + fx * (fl + 12), sp.y + fy * (fl + 12), { color: F_COL, bold: true, size: 13 });
  }
  function dot(ctx, p, color, r) { ctx.fillStyle = color; ctx.beginPath(); ctx.arc(p.x, p.y, r || 3.5, 0, 7); ctx.fill(); }
  function dashLine(ctx, a, b, color, w) {
    ctx.strokeStyle = color; ctx.lineWidth = w || 1.2; ctx.setLineDash([5, 4]);
    ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke(); ctx.setLineDash([]);
  }
  // 圆心 O′、两条半径与圆心角
  function centerAngle(ctx, fr, tr, o) {
    o = o || {};
    if (!tr.c || !tr.exit) return;
    var c = fr.p(tr.c.x, tr.c.y), E = fr.p(tr.enter.x, tr.enter.y), X = fr.p(tr.exit.x, tr.exit.y);
    dashLine(ctx, c, E, 'rgba(230,235,242,.55)'); dashLine(ctx, c, X, 'rgba(230,235,242,.55)');
    dot(ctx, c, TEXT);
    var f0 = Math.atan2(tr.enter.y - tr.c.y, tr.enter.x - tr.c.x), f1 = f0 + tr.s * tr.sweep;
    var ar = Math.max(14, Math.min(34, tr.r * fr.k * 0.32));
    ctx.strokeStyle = F_COL; ctx.lineWidth = 1.6;
    ctx.beginPath(); ctx.arc(c.x, c.y, ar, -f0, -f1, tr.s > 0); ctx.stroke();
    var fm = f0 + tr.s * tr.sweep / 2, lr = ar + 16;
    label(ctx, 'θ = ' + (tr.sweep / DEG).toFixed(tr.sweep / DEG < 10 ? 1 : 0) + '°', c.x + Math.cos(fm) * (lr + 14), c.y - Math.sin(fm) * lr, { color: F_COL, size: 12, bold: true });
    // O′ 的标签放在圆心角的反方向
    label(ctx, o.cname || 'O′', c.x - Math.cos(fm) * 14, c.y + Math.sin(fm) * 14, { size: 12, color: TEXT });
  }
  function scaleBar(ctx, fr, x, y) {
    var opts = [1, 2, 5, 10, 20, 50], cm = opts[0];
    for (var i = 0; i < opts.length; i++) if (opts[i] * fr.k <= 110) cm = opts[i];
    var w = cm * fr.k;
    ctx.strokeStyle = MUTED; ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.moveTo(x, y - 4); ctx.lineTo(x, y); ctx.lineTo(x + w, y); ctx.lineTo(x + w, y - 4); ctx.stroke();
    label(ctx, cm + ' cm', x + w / 2, y - 10, { size: 11, color: MUTED });
  }
  function bLegend(ctx, x, y, bIn, B) {
    var r = 7;
    ctx.strokeStyle = TEXT; ctx.fillStyle = TEXT; ctx.lineWidth = 1.4;
    ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.stroke();
    if (bIn) { var d = r * 0.7; ctx.beginPath(); ctx.moveTo(x - d, y - d); ctx.lineTo(x + d, y + d); ctx.moveTo(x + d, y - d); ctx.lineTo(x - d, y + d); ctx.stroke(); }
    else { ctx.beginPath(); ctx.arc(x, y, 2, 0, 7); ctx.fill(); }
    label(ctx, 'B ' + (bIn ? '垂直纸面向里' : '垂直纸面向外') + (B ? '，' + B.toFixed(2) + ' T' : ''), x + r + 6, y, { align: 'left', size: 12 });
  }

  // ---------- 视图 ----------
  function View(canvas) {
    var ctx = canvas.getContext('2d'), W = 0, H = 0, dpr = 1, narrow = false, geo = null;
    function resize(w, h) {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      W = w; H = h; narrow = w < 640;
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
      canvas.style.width = w + 'px'; canvas.style.height = h + 'px';
    }
    function bg() {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      var g = ctx.createLinearGradient(0, 0, 0, H);
      g.addColorStop(0, '#04060c'); g.addColorStop(1, '#0a1120');
      ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    }
    function area(bottomExtra) {
      var t0 = narrow ? 84 : 44, bottom = (narrow ? 44 : 50) + (bottomExtra || 0);
      return { x: 12, y: t0, w: W - 24, h: Math.max(120, H - t0 - bottom) };
    }
    function corner(R, o) {
      bLegend(ctx, R.x + 14, R.y + 12, o.bIn, o.B);
      scaleBar(ctx, o.fr, R.x + 8, R.y + R.h - 6);
    }

    // 场景一：充满整个空间的匀强磁场
    // o: { bIn, B, parts:[{ tr, l, q, color, name, s }], arrows, radius }
    function drawCircle(o) {
      bg();
      var R = area(), hw = narrow ? 23 : 29, fr = frame(R, { x0: -hw, x1: hw, y0: -22, y1: 22 });
      o.fr = fr;
      field(ctx, fr, { type: 'all' }, o.bIn);
      ctx.save(); ctx.beginPath(); ctx.rect(R.x, R.y, R.w, R.h); ctx.clip();
      o.parts.forEach(function (pt, i) {
        var tr = pt.tr, circ = tr.len;
        track(ctx, fr, tr, 0, circ, pt.color, { alpha: 0.35, dash: [4, 5], width: 1.4 });
        track(ctx, fr, tr, Math.max(0, pt.l - circ), pt.l, pt.color, { width: 2.4 });
        var c = fr.p(tr.c.x, tr.c.y), ps = L.pointAt(tr, pt.l), sp = fr.p(ps.x, ps.y);
        if (o.radius) {
          dot(ctx, c, pt.color, 3);
          dashLine(ctx, c, sp, 'rgba(230,235,242,.45)');
          if (i === 0) label(ctx, 'r', (c.x + sp.x) / 2 + 8, (c.y + sp.y) / 2 - 8, { size: 13, bold: true });
        }
        // 出发点
        var s0 = fr.p(tr.enter.x, tr.enter.y);
        ctx.strokeStyle = 'rgba(230,235,242,.6)'; ctx.lineWidth = 1.2;
        ctx.beginPath(); ctx.moveTo(s0.x, s0.y - 6); ctx.lineTo(s0.x, s0.y + 6); ctx.stroke();
        if (o.arrows) vfArrows(ctx, sp, ps.a, pt.s, true, i === 0 ? 46 : 34, i === 0);
        particle(ctx, sp, pt.q, pt.color, i === 0 ? 8 : 7);
        if (pt.name) label(ctx, pt.name, sp.x, sp.y + 20, { size: 11, color: pt.color });
      });
      ctx.restore();
      corner(R, o);
      geo = { scene: 'circle', fr: fr };
      return geo;
    }

    // 场景二：有界磁场
    // o: { reg, bIn, B, mode, parts:[{tr,l,color,q}], single, critical, centers, locus, src }
    function drawBound(o) {
      bg();
      var R = area(), t = o.reg.type, my = t === 'strip' ? o.reg.d / 2 : 12;
      var hw = narrow ? 23 : t === 'circle' ? 29 : 30;
      var box = t === 'circle' ? { x0: -hw, x1: hw, y0: -22, y1: 22 } : { x0: -hw, x1: hw, y0: my - 24, y1: my + 24 };
      var fr = frame(R, box);
      o.fr = fr;
      field(ctx, fr, o.reg, o.bIn);
      ctx.save(); ctx.beginPath(); ctx.rect(R.x, R.y, R.w, R.h); ctx.clip();
      if (o.reg.type === 'circle') {
        var oc = fr.p(0, 0);
        dot(ctx, oc, EDGE, 3);
        label(ctx, 'O', oc.x + 10, oc.y + 10, { size: 12, color: EDGE });
      }
      // 临界轨迹
      if (o.critical) {
        track(ctx, fr, o.critical, 0, o.critical.len, F_COL, { alpha: 0.6, dash: [3, 4], width: 1.4 });
        var ct = o.critical.c, top = fr.p(ct.x, ct.y + o.critical.r);
        label(ctx, '临界轨迹（恰与上边界相切）', top.x, top.y - 12, { size: 11, color: F_COL });
      }
      // 圆心的轨迹
      if (o.locus) {
        ctx.strokeStyle = 'rgba(230,235,242,.4)'; ctx.lineWidth = 1.2; ctx.setLineDash([3, 5]);
        if (o.locus.t === 'circle') { var lc = fr.p(o.locus.c.x, o.locus.c.y); ctx.beginPath(); ctx.arc(lc.x, lc.y, o.locus.r * fr.k, 0, 7); ctx.stroke(); }
        else { var la = fr.p(o.locus.a.x, o.locus.a.y), lb = fr.p(o.locus.b.x, o.locus.b.y); ctx.beginPath(); ctx.moveTo(la.x, la.y); ctx.lineTo(lb.x, lb.y); ctx.stroke(); }
        ctx.setLineDash([]);
      }
      var single = o.parts.length === 1;
      o.parts.forEach(function (pt) {
        if (single) track(ctx, fr, pt.tr, 0, pt.tr.len, pt.color, { alpha: 0.35, dash: [4, 5], width: 1.4 });
        track(ctx, fr, pt.tr, 0, pt.l, pt.color, { width: single ? 2.4 : 1.8, alpha: single ? 1 : 0.9 });
        if (o.centers && pt.tr.c) dot(ctx, fr.p(pt.tr.c.x, pt.tr.c.y), pt.color, 3);
      });
      if (single && o.annotate) {
        var tr = o.parts[0].tr;
        if (tr.enter) {
          // 入射方向的延长线
          var a0 = o.a0, E = fr.p(tr.enter.x, tr.enter.y), ext = 60;
          dashLine(ctx, E, { x: E.x + Math.cos(a0) * ext, y: E.y - Math.sin(a0) * ext }, 'rgba(126,224,129,.6)');
          centerAngle(ctx, fr, tr);
          vfArrows(ctx, E, a0, tr.s, false, 36, false);
          if (tr.exit) { var X = fr.p(tr.exit.x, tr.exit.y); vfArrows(ctx, X, tr.exitDir, tr.s, false, 36, false); dot(ctx, X, TEXT, 3); }
        }
      }
      // 粒子
      o.parts.forEach(function (pt) {
        if (pt.l <= 0 || pt.l >= pt.tr.len) return;
        var ps = L.pointAt(pt.tr, pt.l), sp = fr.p(ps.x, ps.y);
        if (single) vfArrows(ctx, sp, ps.a, pt.tr.s, ps.field, 34, true);
        particle(ctx, sp, pt.q, pt.color, single ? 8 : 5.5);
      });
      // 粒子源 / 入射点
      if (o.src) {
        var s = fr.p(o.src.x, o.src.y);
        ctx.fillStyle = '#e6ebf2'; ctx.beginPath(); ctx.arc(s.x, s.y, 4, 0, 7); ctx.fill();
        label(ctx, o.src.name || 'O', s.x + (o.reg.type === 'circle' ? -12 : 0), s.y + 14, { size: 12, bold: true });
      }
      ctx.restore();
      corner(R, o);
      geo = { scene: 'bound', fr: fr };
      return geo;
    }

    // 练习
    function drawQuiz(q, answered, o) {
      bg();
      var R = area((o.quizH || 180) + 8);
      ctx.save(); ctx.beginPath(); ctx.rect(R.x, R.y - 4, R.w, R.h + 8); ctx.clip();
      if (q.type === 'dir') quizDir(R, q, answered);
      else if (q.type === 'ratio') quizRatio(R, q, answered);
      else quizAngle(R, q, answered);
      ctx.restore();
      geo = { scene: 'quiz' };
      return geo;
    }
    function quizDir(R, q, answered) {
      var fr = frame(R, { x0: -16, x1: 16, y0: -12, y1: 12 }), c = fr.p(0, 0), col = chargeColor(q.q), len = Math.min(70, R.h * 0.3);
      if (!q.inPlane) {
        field(ctx, fr, { type: 'all' }, q.bIn);
        bLegend(ctx, R.x + 14, R.y + 12, q.bIn);
        if (answered) {
          var s = L.turn(q.q, q.bIn), a = Math.atan2(q.v.y, q.v.x), r = 9, tr = L.trace({ type: 'all' }, { x: 0, y: 0 }, a, r, s);
          track(ctx, fr, tr, 0, tr.len * 0.5, col, { alpha: 0.6, dash: [4, 5], width: 1.6 });
        }
        arrow(ctx, c.x, c.y, c.x + q.v.x * len, c.y - q.v.y * len, 12, V_COL);
        label(ctx, 'v', c.x + q.v.x * (len + 14), c.y - q.v.y * (len + 14), { color: V_COL, bold: true, size: 14 });
        if (answered) {
          var F = L.forceDir(Math.atan2(q.v.y, q.v.x), L.turn(q.q, q.bIn));
          arrow(ctx, c.x, c.y, c.x + F.x * len * 0.8, c.y - F.y * len * 0.8, 12, F_COL);
          label(ctx, 'F', c.x + F.x * (len * 0.8 + 14), c.y - F.y * (len * 0.8 + 14), { color: F_COL, bold: true, size: 14 });
        }
        particle(ctx, c, q.q, col, 11);
        return;
      }
      // 磁场在纸面内：画几条平行磁感线
      ctx.strokeStyle = ctx.fillStyle = 'rgba(111,134,201,.75)'; ctx.lineWidth = 1.4;
      var B = q.B, n = 5, span = Math.min(R.w, R.h) * 0.8;
      for (var i = 0; i < n; i++) {
        var off = (i - (n - 1) / 2) * span / (n - 1), nx = -B.y, ny = B.x;
        var x0 = c.x + nx * off - B.x * span / 2, y0 = c.y - ny * off + B.y * span / 2, x1 = c.x + nx * off + B.x * span / 2, y1 = c.y - ny * off - B.y * span / 2;
        arrow(ctx, x0, y0, x1, y1, 9, 'rgba(111,134,201,.75)', 1.4);
      }
      label(ctx, 'B', c.x + B.x * (span / 2 + 14) - B.y * span * 0.4, c.y - B.y * (span / 2 + 14) - B.x * span * 0.4, { color: EDGE, bold: true, size: 14 });
      arrow(ctx, c.x, c.y, c.x + q.v.x * len, c.y - q.v.y * len, 12, V_COL);
      label(ctx, 'v', c.x + q.v.x * (len + 14) + 10, c.y - q.v.y * (len + 14), { color: V_COL, bold: true, size: 14 });
      particle(ctx, c, q.q, col, 11);
      if (answered) {
        var out = q.answer === '垂直纸面向外', bx = c.x + 50, by = c.y - 50;
        ctx.strokeStyle = ctx.fillStyle = F_COL; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.arc(bx, by, 12, 0, 7); ctx.stroke();
        if (out) { ctx.beginPath(); ctx.arc(bx, by, 3, 0, 7); ctx.fill(); }
        else { ctx.beginPath(); ctx.moveTo(bx - 8, by - 8); ctx.lineTo(bx + 8, by + 8); ctx.moveTo(bx + 8, by - 8); ctx.lineTo(bx - 8, by + 8); ctx.stroke(); }
        label(ctx, 'F ' + q.answer, bx + 18, by, { color: F_COL, align: 'left', bold: true });
      }
    }
    function quizRatio(R, q, answered) {
      var A = L.PARTICLES[q.a], Bp = L.PARTICLES[q.b];
      var reg = { type: 'line' }, fr = frame(R, { x0: -26, x1: 26, y0: -8, y1: 26 });
      field(ctx, fr, reg, true);
      bLegend(ctx, R.x + 14, R.y + 12, true);
      var O = fr.p(0, 0);
      ctx.fillStyle = TEXT; ctx.beginPath(); ctx.arc(O.x, O.y, 4, 0, 7); ctx.fill();
      label(ctx, 'O', O.x + 12, O.y + 12, { size: 12, bold: true });
      arrow(ctx, O.x, O.y + 50, O.x, O.y + 8, 10, V_COL);
      label(ctx, A.name + '、' + Bp.name + ' ' + { v: '速度相同', ek: '动能相同', mom: '动量相同', u: '经同一电压加速' }[q.cond], O.x + 12, O.y + 34, { align: 'left', size: 12, color: MUTED });
      if (!answered) return;
      // 两粒子轨迹按半径之比画，较大的直径取 22 cm
      var rA = q.kr, rB = 1, kk = 11 / Math.max(rA, rB), same = Math.abs(rA - rB) < 1e-9;
      [[A, rA, POS], [Bp, rB, ALT]].forEach(function (it, i) {
        var tr = L.trace(reg, { x: 0, y: 0 }, 90 * DEG, it[1] * kk, 1, 0);
        track(ctx, fr, tr, 0, tr.len, it[2], { width: 2.2, dash: i && same ? [6, 5] : [] });
        var top = fr.p(tr.c.x, tr.c.y + tr.r);
        label(ctx, it[0].name, top.x, top.y - 10 - (same ? i * 15 : 0), { color: it[2], size: 12, bold: true });
      });
      label(ctx, 'r₁ : r₂ = ' + q.rName + '　T₁ : T₂ = ' + q.tName, R.x + R.w / 2, R.y + R.h - 10, { size: 12, color: TEXT });
    }
    function quizAngle(R, q, answered) {
      var reg = { type: 'line' }, fr = frame(R, { x0: -24, x1: 24, y0: -8, y1: 18 }), r = 8, a = q.a * DEG;
      field(ctx, fr, reg, q.bIn);
      bLegend(ctx, R.x + 14, R.y + 12, q.bIn);
      var tr = L.trace(reg, { x: -Math.cos(a) * 7, y: -Math.sin(a) * 7 }, a, r, q.s, 10);
      var O = fr.p(0, 0), col = chargeColor(q.q);
      if (answered) {
        track(ctx, fr, tr, 0, tr.len, col, { width: 2.2 });
        centerAngle(ctx, fr, tr);
      } else track(ctx, fr, tr, 0, tr.segs[0].len, col, { width: 2.2 });
      // 入射角标注
      var ar = 26;
      ctx.strokeStyle = MUTED; ctx.lineWidth = 1.2;
      var b0 = a < Math.PI / 2 ? 0 : Math.PI, b1 = a;
      ctx.beginPath(); ctx.arc(O.x, O.y, ar, -Math.min(b0, b1), -Math.max(b0, b1), true); ctx.stroke();
      var bm = (b0 + b1) / 2;
      label(ctx, q.ang + '°', O.x + Math.cos(bm) * (ar + 14), O.y - Math.sin(bm) * (ar + 14), { size: 12, color: MUTED });
      vfArrows(ctx, O, a, q.s, false, 40, false);
      particle(ctx, fr.p(-Math.cos(a) * 7, -Math.sin(a) * 7), q.q, col, 8);
      dot(ctx, O, TEXT, 3.5);
      label(ctx, 'O', O.x + (a < Math.PI / 2 ? -12 : 12), O.y + 12, { size: 12, bold: true });
    }

    return { resize: resize, drawCircle: drawCircle, drawBound: drawBound, drawQuiz: drawQuiz, geo: function () { return geo; }, narrow: function () { return narrow; } };
  }

  window.LorentzDraw = { View: View, frame: frame, field: field, track: track, particle: particle, mix: mix, chargeColor: chargeColor, COLORS: { POS: POS, NEG: NEG, ALT: ALT, V: V_COL, F: F_COL } };
})();
