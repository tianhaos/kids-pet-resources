// 交变电流的产生与变压器：计算模块（不碰 DOM）
// 坐标：x 右、y 上、z 指向观察者，三维尺寸单位 cm（示意）；物理量用国际单位
// 发电机：N 极在右、S 极在左，磁场 B 沿 −x；线圈绕 z 轴转，θ 为线圈平面与中性面的夹角（从前方看逆时针为正），
//   θ = 0 时线圈平面竖直（与磁感线垂直，中性面），AB 边在上、CD 边在下；AB 边 A 在前（+z）、B 在后
//   Φ = BS cos θ，e = −N dΦ/dt = NBSω sin θ；e > 0 表示线圈中电流 A→B→C→D（AB 中沿 −z，从前方看 ⊗）
//   外电路：e > 0 时接 D 的电刷（右侧）为正极，电流从右电刷经外电路流回左电刷；换向器使外电路电流方向始终如此
// 变压器：理想变压器，U1/U2 = n1/n2，P1 = P2，I1/I2 = n2/n1
(function () {
  var DEG = Math.PI / 180, SQ2 = Math.SQRT2;

  var GEN = {
    // 三维尺寸（cm）
    pole: 6.2, poleW: 3, poleH: 10, poleD: 13,   // 磁极内表面在 x = ±pole
    R: 4, H: 5,                                  // 线圈两边到转轴距离、半长（沿 z）
    ringZ: 8, ringR: 1.15, ringLen: 1.6,         // 滑环 / 换向器位置与尺寸
    // 物理参数
    L1: 0.20, L2: 0.10,                          // AB 边长、AD 边长（m），S = L1·L2
    N_RANGE: [10, 200], B_RANGE: [0.1, 1], n_RANGE: [0.2, 2], R_RANGE: [1, 20],
    r: 1,                                        // 线圈内阻 Ω
    GAP: 8 * DEG                                 // 换向器绝缘缝半角
  };
  GEN.S = GEN.L1 * GEN.L2;

  var XF = {
    U_RANGE: [10, 380], n_RANGE: [50, 2200], R_RANGE: [2, 200],
    f: 50,                                       // 显示的频率（动画放慢）
    LAMP_P: 40                                   // 灯泡“正常发光”的参考功率（W），只用来定亮度
  };

  function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
  function wrap(a) { a %= 2 * Math.PI; return a < 0 ? a + 2 * Math.PI : a; }
  function round(v, d) { var k = Math.pow(10, d || 0); return Math.round(v * k) / k; }
  // 有效数字（读数显示用）
  function fmt(v, sig) {
    if (!isFinite(v)) return '—';
    if (v === 0) return '0';
    sig = sig || 3;
    var a = Math.abs(v), d = Math.max(0, sig - 1 - Math.floor(Math.log10(a)));
    return (+v.toFixed(Math.min(d, 6))).toString();
  }

  // ---------- 发电机 ----------
  // p = { N, B, n（转/秒）, R（外电阻）, out: 'ring'|'comm' }
  function omega(p) { return 2 * Math.PI * p.n; }
  function Em(p) { return p.N * p.B * GEN.S * omega(p); }
  function phiM(p) { return p.B * GEN.S; }
  // 换向器：电刷压在绝缘缝上时外电路断开（θ 在 0 或 π 附近）
  function onGap(th) { var s = Math.abs(Math.sin(th)); return s < Math.sin(GEN.GAP); }
  function gen(p, th) {
    var w = omega(p), em = Em(p), e = em * Math.sin(th), Rt = p.R + GEN.r;
    var closed = p.out !== 'comm' || !onGap(th);
    var i = closed ? e / Rt : 0;                    // 线圈中电流（A→B→C→D 为正）
    var iExt = p.out === 'comm' ? Math.abs(i) : i;  // 外电路电流（右电刷 → 外电路 → 左电刷为正）
    var Im = em / Rt, I = Im / SQ2;
    return {
      w: w, T: 1 / p.n, f: p.n, Em: em, E: em / SQ2, phiM: phiM(p),
      phi: phiM(p) * Math.cos(th), e: e, dphi: phiM(p) * w * Math.sin(th),   // 磁通量变化率 −dΦ/dt = BSω sin θ
      i: i, iExt: iExt, Im: Im, I: I, U: I * p.R, Um: Im * p.R, P: I * I * p.R
    };
  }
  // 位置描述：θ 与中性面的关系
  function posInfo(th) {
    var a = wrap(th), s = Math.abs(Math.sin(a)), c = Math.abs(Math.cos(a));
    if (s < 0.035) return { key: 'neutral', text: '中性面（线圈平面与磁感线垂直）' };
    if (c < 0.035) return { key: 'parallel', text: '线圈平面与磁感线平行' };
    var deg = Math.round(Math.asin(s) / DEG);
    return { key: 'mid', text: '线圈平面与中性面成 ' + deg + '°', deg: deg };
  }
  // 瞬时值表达式：start = 'neutral'（从中性面开始计时，sin）或 'parallel'（cos）
  function exprText(p, start, sym) {
    var em = Em(p), w = omega(p);
    return (sym || 'e') + ' = ' + fmt(em, 3) + ' ' + (start === 'parallel' ? 'cos' : 'sin') + '(' + fmt(w, 3) + 't) V';
  }

  // ---------- 变压器 ----------
  // p = { U1（有效值）, n1, n2, R, load: bool, src: 'ac'|'dc' }
  function xfmr(p) {
    var ac = p.src !== 'dc', k = p.n2 / p.n1;
    var U2 = ac ? p.U1 * k : 0, I2 = p.load && ac ? U2 / p.R : 0, P2 = U2 * I2;
    var I1 = ac ? P2 / p.U1 : 0;
    return { k: k, U2: U2, I2: I2, P2: P2, P1: P2, I1: I1, U1m: p.U1 * SQ2, U2m: U2 * SQ2,
      kind: !ac ? '直流' : p.n2 > p.n1 ? '升压变压器' : p.n2 < p.n1 ? '降压变压器' : '匝数相等',
      bright: clamp(P2 / XF.LAMP_P, 0, 1.6) };
  }

  // ---------- 判断练习 ----------
  var TYPES = ['pos', 'expr', 'eff', 'xfmr'];
  function pick(rand, a) { return a[Math.floor(rand() * a.length)]; }
  function shuffle(rand, a) {
    a = a.slice();
    for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(rand() * (i + 1)), t = a[i]; a[i] = a[j]; a[j] = t; }
    return a;
  }
  function uniq(a) { return a.filter(function (x, i) { return a.indexOf(x) === i; }); }

  var BANK = {
    pos: [
      { q: '线圈在匀强磁场中匀速转动，经过中性面时：', a: '磁通量最大，感应电动势为零',
        w: ['磁通量为零，感应电动势最大', '磁通量最大，感应电动势也最大', '磁通量为零，感应电动势也为零'],
        e: '中性面是线圈平面与磁感线垂直的位置：穿过线圈的磁通量最大，但 AB、CD 两边的速度方向与磁感线平行，不切割磁感线，磁通量的变化率为零，感应电动势为零。', show: { scene: 'gen', angle: 0 } },
      { q: '线圈转到线圈平面与磁感线平行的位置时：', a: '磁通量为零，磁通量的变化率最大',
        w: ['磁通量最大，磁通量的变化率为零', '磁通量为零，磁通量的变化率也为零', '电流方向在这个位置改变'],
        e: '线圈平面与磁感线平行时，没有磁感线穿过线圈，磁通量为零；但 AB、CD 两边的速度方向与磁感线垂直，切割最快，磁通量的变化率最大，感应电动势最大，Em = NBSω。', show: { scene: 'gen', angle: 90 } },
      { q: '交流发电机的线圈转动一周，线圈中电流的方向改变：', a: '两次',
        w: ['一次', '四次', '不改变'],
        e: '线圈每经过一次中性面，感应电流的方向就改变一次。转一周经过中性面两次，所以电流方向改变两次；50 Hz 的交流电每秒改变 100 次。', show: { scene: 'gen', angle: 0 } },
      { q: '下列关于交流发电机中滑环和换向器的说法，正确的是：', a: '用两个滑环输出交流电，用换向器输出方向不变的电流',
        w: ['用两个滑环输出方向不变的电流', '用换向器时线圈中的电流方向也不变', '滑环的作用是改变线圈中的电流方向'],
        e: '线圈中产生的始终是交变电流。两个滑环把它原样引出，外电路得到交流电；换向器在线圈经过中性面时对调两个电刷所接的线圈端，外电路电流方向不变（大小仍在变化，是脉动直流），这就是直流发电机。', show: { scene: 'gen', out: 'comm' } }
    ],
    xfmr: [
      { q: '把理想变压器的原线圈接在电压恒定的直流电源上，副线圈两端的电压：', a: '为零',
        w: ['与原线圈电压相等', '等于原线圈电压乘以 n₂/n₁', '比接交流电时更大'],
        e: '变压器靠互感工作：原线圈中变化的电流在铁芯中产生变化的磁通量，副线圈中才有感应电动势。恒定电流产生的磁通量不变，副线圈中没有感应电动势（只在接通、断开瞬间有），所以变压器不能改变直流电压。', show: { scene: 'xfmr', src: 'dc' } },
      { q: '理想变压器的输入功率由什么决定？', a: '由输出功率决定，P入 = P出',
        w: ['由原线圈匝数决定', '由输入电压单独决定，与负载无关', '输入功率总是大于输出功率'],
        e: '理想变压器没有能量损失，P入 = P出。副线圈电压由 U₁ 和匝数比决定，副线圈接的负载决定 I₂ 和输出功率，输出功率又决定输入功率和原线圈电流：负载断开时 I₂ = 0，原线圈中也几乎没有电流。', show: { scene: 'xfmr', load: 0 } },
      { q: '变压器原、副线圈中的交变电流，相同的物理量是：', a: '频率',
        w: ['电压', '电流', '匝数'],
        e: '原、副线圈绕在同一个铁芯上，穿过它们的磁通量变化完全同步，所以两侧交变电流的频率相同（周期相同）；电压与匝数成正比，电流与匝数成反比。变压器不改变频率。', show: { scene: 'xfmr' } }
    ]
  };
  function quizBank(rand, type) {
    var b = pick(rand, BANK[type]);
    return { type: type, answer: b.a, options: shuffle(rand, [b.a].concat(b.w)), prompt: b.q, explain: b.e, show: b.show };
  }

  // 写瞬时值表达式
  function quizExpr(rand) {
    var N = pick(rand, [50, 100, 200]), B = pick(rand, [0.2, 0.5, 1]), Scm = pick(rand, [100, 200, 400]);
    var n = pick(rand, [25, 50, 100 / Math.PI]), start = rand() < 0.5 ? 'neutral' : 'parallel';
    var S = Scm / 1e4, w = 2 * Math.PI * n, em = N * B * S * w;
    var nTxt = Math.abs(n - 100 / Math.PI) < 1e-6 ? '100/π r/s' : n + ' r/s';
    var wTxt = Math.abs(n - 100 / Math.PI) < 1e-6 ? '200' : round(2 * n) + 'π';
    var emTxt = function (v) { return Math.abs(n - 100 / Math.PI) < 1e-6 ? fmt(v, 4) : fmt(v / Math.PI, 4) + 'π'; };
    var fn = start === 'neutral' ? 'sin' : 'cos', fn2 = start === 'neutral' ? 'cos' : 'sin';
    var mk = function (a, f, ww) { return 'e = ' + a + ' ' + f + '(' + ww + 't) V'; };
    var ans = mk(emTxt(em), fn, wTxt);
    var opts = uniq([ans, mk(emTxt(em), fn2, wTxt), mk(emTxt(em / N), fn, wTxt), mk(emTxt(em / SQ2), fn, wTxt)]);
    return { type: 'expr', answer: ans, options: shuffle(rand, opts.slice(0, 4)),
      prompt: N + ' 匝矩形线圈面积 ' + Scm + ' cm²，在 B = ' + B + ' T 的匀强磁场中绕垂直于磁场的轴以 ' + nTxt + ' 匀速转动，从' + (start === 'neutral' ? '中性面' : '线圈平面与磁感线平行') + '开始计时，感应电动势的瞬时值表达式为：',
      explain: 'ω = 2πn = ' + wTxt + ' rad/s，Em = NBSω = ' + N + ' × ' + B + ' × ' + fmt(S, 3) + ' × ' + wTxt + ' V = ' + emTxt(em) + ' V。' +
        (start === 'neutral' ? '从中性面开始计时，t = 0 时 e = 0，所以用正弦：e = Em sin ωt。' : '从线圈平面与磁感线平行开始计时，t = 0 时 e 最大，所以用余弦：e = Em cos ωt。') +
        '注意 Em 要乘匝数 N，括号里是角速度 ω 而不是转速 n。',
      show: { scene: 'gen', start: start } };
  }

  // 有效值、电表读数
  function quizEff(rand) {
    var k = pick(rand, ['meter', 'peak', 'home']);
    if (k === 'home') {
      return { type: 'eff', answer: '311 V', options: shuffle(rand, ['311 V', '220 V', '156 V', '380 V']),
        prompt: '家庭电路的电压是 220 V（有效值），这个交流电压的峰值约为：',
        explain: '正弦式交流电的峰值与有效值的关系是 Um = √2 U = 1.414 × 220 V ≈ 311 V。平时说的 220 V、用电器铭牌上的额定电压、交流电表的读数都是有效值。',
        show: { scene: 'gen' } };
    }
    var em = pick(rand, [10, 20, 50, 100]) * SQ2, R = pick(rand, [9, 19, 4]), r = 1;
    var Im = em / (R + r), I = Im / SQ2, U = I * R;
    if (k === 'peak') {
      var ansP = fmt(I, 3) + ' A';
      return { type: 'eff', answer: ansP, options: shuffle(rand, uniq([ansP, fmt(Im, 3) + ' A', fmt(em / SQ2 / R, 3) + ' A', fmt(Im * SQ2, 3) + ' A'])),
        prompt: '发电机线圈产生的电动势 e = ' + fmt(em, 4) + ' sin(100πt) V，线圈内阻 r = ' + r + ' Ω，外接 R = ' + R + ' Ω 的电阻，交流电流表的示数为：',
        explain: 'Em = ' + fmt(em, 4) + ' V，有效值 E = Em/√2 = ' + fmt(em / SQ2, 3) + ' V。电流表示数是有效值：I = E/(R + r) = ' + fmt(em / SQ2, 3) + '/' + (R + r) + ' A = ' + fmt(I, 3) + ' A。别忘了内阻，也别用峰值。',
        show: { scene: 'gen' } };
    }
    var ans = fmt(U, 3) + ' V';
    return { type: 'eff', answer: ans, options: shuffle(rand, uniq([ans, fmt(em / SQ2, 3) + ' V', fmt(Im * R, 3) + ' V', fmt(em, 4) + ' V'])),
      prompt: '发电机线圈产生的电动势 e = ' + fmt(em, 4) + ' sin(100πt) V，线圈内阻 r = ' + r + ' Ω，外接 R = ' + R + ' Ω 的电阻，并联在 R 两端的交流电压表示数为：',
      explain: '电压表测的是 R 两端电压的有效值。E = Em/√2 = ' + fmt(em / SQ2, 3) + ' V，I = E/(R + r) = ' + fmt(I, 3) + ' A，U = IR = ' + fmt(U, 3) + ' V。电压表示数小于电动势，因为内阻上也分了电压。',
      show: { scene: 'gen' } };
  }

  // 变压器匝数比
  function quizXfmr(rand) {
    if (rand() < 0.35) return quizBank(rand, 'xfmr');
    var U1 = 220, pair = pick(rand, [[1100, 180], [2200, 110], [550, 100], [1000, 5000], [440, 24]]);
    var n1 = pair[0], n2 = pair[1], U2 = U1 * n2 / n1;
    if (rand() < 0.5) {
      var ans = fmt(U2, 4) + ' V';
      return { type: 'xfmr', answer: ans, options: shuffle(rand, uniq([ans, fmt(U1 * n1 / n2, 4) + ' V', fmt(U2 * SQ2, 4) + ' V', '0 V'])),
        prompt: '理想变压器原线圈 ' + n1 + ' 匝、副线圈 ' + n2 + ' 匝，原线圈接 220 V 的交流电，副线圈两端的电压为：',
        explain: 'U₁/U₂ = n₁/n₂，U₂ = U₁·n₂/n₁ = 220 × ' + n2 + '/' + n1 + ' V = ' + ans + '。这是' + (n2 > n1 ? '升压' : '降压') + '变压器：副线圈匝数' + (n2 > n1 ? '多' : '少') + '，电压' + (n2 > n1 ? '高' : '低') + '。',
        show: { scene: 'xfmr', n1: n1, n2: n2, U1: U1 } };
    }
    var R = pick(rand, [10, 20, 50]), I2 = U2 / R, I1 = I2 * n2 / n1;
    var a2 = fmt(I1, 3) + ' A';
    return { type: 'xfmr', answer: a2, options: shuffle(rand, uniq([a2, fmt(I2, 3) + ' A', fmt(I2 * n1 / n2, 3) + ' A', fmt(U1 / R, 3) + ' A'])),
      prompt: '理想变压器原线圈 ' + n1 + ' 匝、副线圈 ' + n2 + ' 匝，原线圈接 220 V 的交流电，副线圈接 ' + R + ' Ω 的电阻，原线圈中的电流为：',
      explain: 'U₂ = 220 × ' + n2 + '/' + n1 + ' V = ' + fmt(U2, 4) + ' V，I₂ = U₂/R = ' + fmt(I2, 3) + ' A。由 P₁ = P₂ 得 I₁/I₂ = n₂/n₁，I₁ = ' + fmt(I2, 3) + ' × ' + n2 + '/' + n1 + ' A = ' + a2 + '。电流与匝数成反比。',
      show: { scene: 'xfmr', n1: n1, n2: n2, U1: U1, R: R } };
  }

  function quiz(rand, avoid, only) {
    var q;
    for (var i = 0; i < 12; i++) {
      var t = only && TYPES.indexOf(only) >= 0 ? only : pick(rand, TYPES);
      q = t === 'pos' ? quizBank(rand, 'pos') : t === 'expr' ? quizExpr(rand) : t === 'eff' ? quizEff(rand) : quizXfmr(rand);
      q.id = q.type + '|' + q.prompt;
      if (!avoid || q.id !== avoid.id) break;
    }
    return q;
  }

  window.AC = {
    DEG: DEG, GEN: GEN, XF: XF, TYPES: TYPES,
    clamp: clamp, wrap: wrap, round: round, fmt: fmt,
    omega: omega, Em: Em, phiM: phiM, onGap: onGap, gen: gen, posInfo: posInfo, exprText: exprText,
    xfmr: xfmr, quiz: quiz
  };
})();
