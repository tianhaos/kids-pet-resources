(function () {
  var A = window.AC, Dr = window.ACDraw, G = A.GEN, X = A.XF, DEG = A.DEG;
  var $ = function (id) { return document.getElementById(id); };
  var qa = function (sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); };
  var NAME = '交变电流与变压器';
  var XF_HZ = 0.5;    // 变压器动画频率（实际 50 Hz，放慢 100 倍）
  var G_FULL = 1;     // 电流计满偏电流（A）

  var state = {
    scene: 'gen',
    N: 100, B: 0.5, n: 0.5, R: 4, out: 'ring', start: 'neutral', th: 0, th0: 0, ph: 0, run: true, qc: 0, qe: 0,
    U1: 220, n1: 1100, n2: 180, xR: 36, src: 'ac', load: true, xph: 0, q1: 0, q2: 0,
    field: true, current: true, vel: true, labels: true, end: true, slow: false,
    quiz: null, quizOnly: null, answered: false, correct: false, choice: null, score: { n: 0, ok: 0 }
  };
  var HINTS = {
    gen: '拖动旋转、滚轮或双指缩放；看线圈经过中性面时 e 为零、电流计指针换向',
    xfmr: '拖动旋转、滚轮或双指缩放；改变匝数比看 U₂，切到直流看副线圈还有没有电压',
    quiz: '交变电流与变压器 · 判断练习'
  };

  var stage = $('stage'), panel = $('panel'), ev = $('endView'), ectx = ev.getContext('2d');
  var gc = $('graph'), gctx = gc.getContext('2d');
  var sc3 = null;
  try { sc3 = window.ACScene(stage); } catch (e) { sc3 = null; }
  function setSeg(attr, val) { qa('[data-' + attr + ']').forEach(function (b) { b.classList.toggle('on', b.dataset[attr] === String(val)); }); }
  function genP() { return { N: state.N, B: state.B, n: state.n, R: state.R, out: state.out }; }
  function xfP() { return { U1: state.U1, n1: state.n1, n2: state.n2, R: state.xR, load: state.load, src: state.src }; }

  // ---------- 场景 ----------
  qa('[data-scene]').forEach(function (b) {
    b.addEventListener('click', function () { setScene(b.dataset.scene); Analytics.track(NAME, '场景', b.textContent); });
  });
  function setScene(s) {
    state.scene = s;
    if (s === 'quiz' && !state.quiz) newQuiz();
    syncUI();
    resize();
  }
  // 练习时画面显示题目对应的装置
  function view() {
    if (state.scene !== 'quiz') return state.scene;
    return state.quiz && state.quiz.show && state.quiz.show.scene === 'xfmr' ? 'xfmr' : 'gen';
  }

  // ---------- 发电机 ----------
  function slider(id, key, fmt, tag) {
    $(id).addEventListener('input', function () { state[key] = +$(id).value; syncUI(); });
    $(id).addEventListener('change', function () { Analytics.track(NAME, tag, fmt(state[key])); });
  }
  slider('gN', 'N', String, '匝数');
  slider('gB', 'B', function (v) { return v.toFixed(2); }, '磁感应强度');
  slider('gn', 'n', function (v) { return v.toFixed(1); }, '转速');
  slider('gR', 'R', String, '外电阻');
  qa('[data-out]').forEach(function (b) {
    b.addEventListener('click', function () { state.out = b.dataset.out; syncUI(); Analytics.track(NAME, '输出', b.textContent); });
  });
  // 计时起点：从中性面（θ = 0）或线圈平面与磁感线平行（θ = 90°）开始
  function restart(start) {
    if (start) state.start = start;
    state.th0 = state.start === 'parallel' ? 90 * DEG : 0;
    state.th = state.th0; state.ph = 0;
    syncUI();
  }
  qa('[data-start]').forEach(function (b) {
    b.addEventListener('click', function () { restart(b.dataset.start); Analytics.track(NAME, '计时起点', b.textContent); });
  });
  $('gRestart').addEventListener('click', function () { restart(); Analytics.track(NAME, '重新计时'); });
  function togglePause() { state.run = !state.run; syncUI(); Analytics.track(NAME, state.run ? '继续' : '暂停'); }
  // 前进到下一个 T/4 时刻并暂停
  function stepQuarter() {
    var q = Math.PI / 2, k = Math.floor(state.ph / q + 1e-6) + 1;
    state.ph = (k * q) % Dr.PH; state.th = state.th0 + state.ph; state.run = false;
    syncUI(); Analytics.track(NAME, '前进 T/4');
  }
  $('gPause').addEventListener('click', togglePause);
  $('gStep').addEventListener('click', stepQuarter);

  // ---------- 变压器 ----------
  slider('xU', 'U1', String, '原线圈电压');
  slider('xn1', 'n1', String, '原线圈匝数');
  slider('xn2', 'n2', String, '副线圈匝数');
  slider('xR', 'xR', String, '负载电阻');
  qa('[data-src]').forEach(function (b) {
    b.addEventListener('click', function () { setSrc(b.dataset.src); });
  });
  function setSrc(s) { state.src = s; syncUI(); Analytics.track(NAME, '电源', s === 'dc' ? '直流' : '交流'); }
  function toggleLoad() { state.load = !state.load; syncUI(); Analytics.track(NAME, '负载开关', state.load ? '闭合' : '断开'); }
  $('xLoad').addEventListener('click', toggleLoad);
  qa('[data-preset]').forEach(function (b) {
    b.addEventListener('click', function () {
      var p = b.dataset.preset.split(',').map(Number);
      state.U1 = p[0]; state.n1 = p[1]; state.n2 = p[2]; state.xR = p[3]; state.src = 'ac'; state.load = true;
      syncUI(); Analytics.track(NAME, '变压器示例', b.textContent);
    });
  });

  // 画面下方的快捷按钮（窄屏时面板收起也能操作）
  $('actMain').addEventListener('click', function () { if (view() === 'gen') togglePause(); else toggleLoad(); });
  $('actSub').addEventListener('click', function () { if (view() === 'gen') stepQuarter(); else setSrc(state.src === 'dc' ? 'ac' : 'dc'); });

  // ---------- 显示 ----------
  var CHECKS = ['field', 'current', 'vel', 'labels', 'end', 'slow'];
  CHECKS.forEach(function (k) {
    $(k).addEventListener('change', function () { state[k] = $(k).checked; syncUI(); Analytics.track(NAME, '显示', k + (state[k] ? ' 开' : ' 关')); });
  });
  $('homeBtn').addEventListener('click', function () { if (sc3) sc3.home(); });

  // ---------- 练习 ----------
  function newQuiz() {
    state.quiz = A.quiz(Math.random, state.quiz, state.quizOnly);
    state.answered = false; state.choice = null;
    var q = state.quiz, box = $('quizOpts');
    box.innerHTML = '';
    q.options.forEach(function (o) {
      var b = document.createElement('button');
      b.className = 'small';
      b.textContent = o;
      b.dataset.opt = o;
      b.addEventListener('click', function () { answer(o); });
      box.appendChild(b);
    });
    box.className = 'answer' + (q.options.some(function (o) { return o.length > 12; }) ? ' one' : '');
    syncUI();
  }
  function answer(o) {
    if (state.answered) return;
    state.answered = true; state.choice = o;
    state.correct = o === state.quiz.answer;
    state.score.n++; if (state.correct) state.score.ok++;
    Analytics.track(NAME, '练习', state.quiz.type + (state.correct ? ' 对' : ' 错'));
    syncUI();
  }
  $('nextQ').addEventListener('click', newQuiz);
  $('showQ').addEventListener('click', function () {
    var sh = state.quiz.show || {};
    applyShow(sh);
    Analytics.track(NAME, '练习 → 模型', state.quiz.type);
    setScene(sh.scene || 'gen');
  });
  function applyShow(sh) {
    if (sh.scene === 'xfmr') {
      state.src = sh.src || 'ac'; state.load = sh.load !== 0;
      if (sh.n1) { state.n1 = sh.n1; state.n2 = sh.n2; }
      if (sh.U1) state.U1 = sh.U1;
      if (sh.R) state.xR = sh.R;
    } else {
      if (sh.out) state.out = sh.out;
      if (sh.start) restart(sh.start);
      if (sh.angle != null) { state.th = sh.angle * DEG; state.ph = A.wrap(state.th - state.th0); state.run = false; }
      else state.run = true;
    }
  }

  // ---------- 面板 ----------
  var collapsedOnce = false;
  function autoCollapse() {
    if (collapsedOnce || !window.matchMedia('(max-width: 760px)').matches) return;
    collapsedOnce = true;
    panel.classList.add('collapsed');
  }
  $('panelToggle').addEventListener('click', function () { collapsedOnce = true; panel.classList.toggle('collapsed'); });
  autoCollapse();

  function syncUI() {
    var s = state.scene, v = view();
    readNow = true;
    setSeg('scene', s);
    qa('[data-for]').forEach(function (el) { el.hidden = el.dataset.for.split(' ').indexOf(s) < 0; });
    $('hint').textContent = !sc3 ? '此浏览器不支持 WebGL，无法显示 3D 模型；端视图、波形图和练习仍可使用' : HINTS[s];
    setSeg('out', state.out); setSeg('start', state.start); setSeg('src', state.src);
    $('gN').value = state.N; $('gNOut').textContent = state.N + ' 匝';
    $('gB').value = state.B; $('gBOut').textContent = state.B.toFixed(2) + ' T';
    $('gn').value = state.n; $('gnOut').textContent = state.n.toFixed(1) + ' r/s';
    $('gR').value = state.R; $('gROut').textContent = state.R + ' Ω';
    $('xU').value = state.U1; $('xUOut').textContent = state.U1 + ' V';
    $('xn1').value = state.n1; $('xn1Out').textContent = state.n1 + ' 匝';
    $('xn2').value = state.n2; $('xn2Out').textContent = state.n2 + ' 匝';
    $('xR').value = state.xR; $('xROut').textContent = state.xR + ' Ω';
    $('gPause').textContent = state.run ? '⏸ 暂停' : '▶ 继续';
    $('xLoad').textContent = state.load ? '断开负载开关' : '闭合负载开关';
    CHECKS.forEach(function (k) { $(k).checked = state[k]; });
    $('actBar').hidden = s === 'quiz';
    $('actMain').textContent = v === 'gen' ? (state.run ? '⏸ 暂停' : '▶ 继续') : (state.load ? '断开开关' : '闭合开关');
    $('actMain').classList.toggle('on', v === 'gen' ? !state.run : state.load);
    $('actSub').textContent = v === 'gen' ? '⏭ 前进 T/4' : (state.src === 'dc' ? '⇄ 换成交流' : '⇄ 换成直流');
    $('actSub').classList.toggle('on', v === 'xfmr' && state.src === 'dc');
    ev.hidden = v !== 'gen' || (!state.end && !!sc3);
    var q = state.quiz;
    if (q) {
      $('quizQ').textContent = q.prompt;
      qa('#quizOpts button').forEach(function (b) {
        b.disabled = state.answered;
        b.classList.toggle('on', state.answered && b.dataset.opt === q.answer);
        b.classList.toggle('no', state.answered && b.dataset.opt === state.choice && !state.correct);
      });
      $('quizMsg').innerHTML = !state.answered ? ''
        : '<b class="' + (state.correct ? 'ok">✓ 答对了' : 'bad">✗ 应选「' + q.answer + '」') + '</b>' + q.explain;
      $('nextQ').textContent = state.answered ? '下一题 →' : '换一题';
      $('showQ').hidden = !state.answered;
    }
    stage.classList.toggle('quiz', s === 'quiz');
    legend();
  }
  function legend() {
    var v = view(), html = v === 'gen'
      ? '<span><i style="background:#e0574f"></i>N 极</span><span><i style="background:#4a78d8"></i>S 极</span><span><i class="ln" style="border-color:#4fc3f7"></i>磁感线</span><span><i class="dot"></i>电流</span><span><i class="ln" style="border-color:#7ee081"></i>速度 v</span>'
      : '<span><i class="ln" style="border-color:#4fc3f7"></i>铁芯中磁通量 Φ</span><span><i class="dot"></i>电流</span>';
    $('legend').innerHTML = state.scene === 'quiz' ? '' : html;
  }

  // ---------- 读数 ----------
  var lastText = {};
  function setText(id, t, html) { if (lastText[id] !== t) { lastText[id] = t; $(id)[html ? 'innerHTML' : 'textContent'] = t; } }
  function rows(list) {
    for (var k = 1; k <= 7; k++) {
      var r = list[k - 1] || ['', ''];
      setText('d' + k, r[0]); setText('r' + k, r[1], true);
      if ($('d' + k).hidden !== !r[0]) $('d' + k).hidden = $('r' + k).hidden = !r[0];
    }
  }
  var f = A.fmt;
  function readGen() {
    var p = genP(), g = A.gen(p, state.th), pos = A.posInfo(state.th), comm = state.out === 'comm';
    setText('rName', comm ? '直流发电机（换向器）' : '交流发电机');
    $('rName').className = '';
    setText('rKind', pos.key === 'neutral' ? '中性面' : pos.key === 'parallel' ? '平行于磁感线' : state.run ? '转动中' : '已暂停');
    var cur = Math.abs(g.i) < 1e-9 ? '0' : g.i > 0 ? 'A → B（D 端流出）' : 'B → A（A 端流出）';
    rows([
      ['线圈位置', pos.text],
      ['磁通量 Φ', f(g.phi, 3) + ' Wb <small>（Φm = BS = ' + f(g.phiM, 3) + ' Wb）</small>'],
      ['电动势 e', f(g.e, 3) + ' V <small>（Em = NBSω = ' + f(g.Em, 3) + ' V）</small>'],
      ['瞬时值', A.exprText(p, state.start)],
      ['电表读数', comm ? '外电路为脉动直流，峰值 ' + f(g.Im, 3) + ' A' : 'I = ' + f(g.I, 3) + ' A，U = ' + f(g.U, 3) + ' V <small>（有效值）</small>'],
      ['周期频率', 'T = ' + f(g.T, 3) + ' s，f = ' + f(g.f, 3) + ' Hz，ω = ' + f(g.w, 3) + ' rad/s'],
      ['AB 中电流', cur + (g.Im > G_FULL ? ' <small>（超出电流计量程）</small>' : '')]
    ]);
    var tip;
    if (pos.key === 'neutral') tip = '中性面：线圈平面与磁感线垂直，Φ 最大，但 AB、CD 的速度与磁感线平行、不切割，e = 0。线圈每经过一次中性面，电流方向改变一次' + (comm ? '；换向器正在这里对调电刷，外电路电流方向不变。' : '。');
    else if (pos.key === 'parallel') tip = '线圈平面与磁感线平行：Φ = 0，但 AB、CD 垂直切割磁感线，Φ 变化最快，e 最大，Em = NBSω。';
    else if (comm) tip = '换向器：线圈中仍是交变电流，但每经过中性面，两个电刷所接的线圈端就对调一次，外电路电流方向不变（大小在变，是脉动直流）。';
    else tip = '线圈在匀强磁场中绕垂直于磁场的轴匀速转动，产生正弦式交变电流：从中性面计时 e = Em sin ωt。交流电表的读数是有效值，E = Em/√2。';
    setText('rTip', tip);
  }
  function readXf() {
    var x = A.xfmr(xfP()), dc = state.src === 'dc';
    setText('rName', '变压器');
    $('rName').className = '';
    setText('rKind', x.kind);
    rows([
      ['匝数比', 'n₁ : n₂ = ' + state.n1 + ' : ' + state.n2 + ' <small>（' + f(state.n1 / state.n2, 3) + ' : 1）</small>'],
      ['原线圈', 'U₁ = ' + state.U1 + ' V' + (dc ? '（直流）' : '（有效值，峰值 ' + f(x.U1m, 3) + ' V）')],
      ['副线圈电压', dc ? 'U₂ = 0' : 'U₂ = U₁·n₂/n₁ = ' + f(x.U2, 3) + ' V'],
      ['副线圈电流', dc ? 'I₂ = 0' : !state.load ? 'I₂ = 0（负载断开）' : 'I₂ = U₂/R = ' + f(x.I2, 3) + ' A'],
      ['原线圈电流', dc ? '恒定电流，只受线圈电阻限制（易烧坏）' : 'I₁ = I₂·n₂/n₁ = ' + f(x.I1, 3) + ' A'],
      ['功率', dc ? '不传输电能' : 'P₁ = P₂ = U₂I₂ = ' + f(x.P2, 3) + ' W'],
      ['频率', dc ? '—' : '原、副线圈都是 ' + X.f + ' Hz（动画放慢 100 倍）']
    ]);
    var tip;
    if (dc) tip = '直流电源：原线圈中电流恒定，铁芯中的磁通量不变，副线圈中没有感应电动势，灯泡不亮（只在接通、断开的瞬间有感应电流）。变压器不能改变直流电压。';
    else if (!state.load) tip = '负载断开：I₂ = 0，输出功率为零，理想变压器的输入功率也为零，原线圈中几乎没有电流——但副线圈两端仍有电压 U₂。';
    else if (state.n2 > state.n1) tip = '升压变压器：n₂ > n₁，U₂ > U₁，但 I₂ < I₁。电压与匝数成正比，电流与匝数成反比，P₁ = P₂。';
    else if (state.n2 < state.n1) tip = '降压变压器：n₂ < n₁，U₂ < U₁，副线圈电流反而更大（导线常更粗）。输出功率决定输入功率：调小 R，I₁ 也跟着变大。';
    else tip = 'n₁ = n₂ 时 U₂ = U₁，变压器只起隔离作用。';
    setText('rTip', tip);
  }
  function readQuiz() {
    var q = state.quiz, s = state.score;
    setText('rName', !state.answered ? '判断练习' : state.correct ? '✓ 答对了' : '✗ 答错了');
    $('rName').className = !state.answered ? '' : state.correct ? 'ok' : 'bad';
    setText('rKind', '得分 ' + s.ok + ' / ' + s.n);
    setText('rTip', state.answered ? q.explain : q.prompt);
    rows([]);
  }

  // ---------- 尺寸 ----------
  var EV = 200, GW = 0, GH = 0;
  function resize() {
    var w = stage.clientWidth, h = stage.clientHeight, narrow = w <= 760;
    autoCollapse();
    // 波形图在画面下方（练习时隐藏）
    var gh = state.scene === 'quiz' ? 0 : narrow ? Math.round(Math.min(150, h * 0.24)) : Math.round(Math.min(190, Math.max(140, h * 0.24)));
    var bottom = narrow ? 40 : 44;
    gc.hidden = !gh;
    var dpr = window.devicePixelRatio || 1, gw = w - 24;
    if (gh && (gw !== GW || gh !== GH || gc.width !== Math.round(gw * dpr))) {
      GW = gw; GH = gh;
      gc.width = Math.round(gw * dpr); gc.height = Math.round(gh * dpr);
      gc.style.width = gw + 'px'; gc.style.height = gh + 'px';
      gctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    }
    gc.style.bottom = bottom + 'px';
    $('actBar').style.bottom = (gh ? bottom + gh + 8 : bottom) + 'px';
    var h3 = gh ? h - gh - bottom - 4 : h;
    if (sc3) sc3.resize(w, Math.max(120, h3));
    var size = !sc3 ? Math.max(160, Math.min(440, Math.round(Math.min(w - 24, h3 - (gh ? 110 : 330)))))
      : narrow ? 124 : Math.min(200, Math.max(150, Math.round(Math.min(w, h3) * 0.28)));
    ev.classList.toggle('big', !sc3);
    // 窄屏时端视图放在 3D 画面左下角，避免挡住磁极
    ev.style.top = !sc3 ? Math.max(50, (h3 - size) / 2) + 'px' : narrow ? Math.max(86, h3 - size - 50) + 'px' : '';   // 留出下方快捷按钮的位置
    ev.style.left = sc3 && narrow ? '12px' : '';
    if (size !== EV || ev.width !== Math.round(size * dpr)) {
      EV = size;
      ev.width = ev.height = Math.round(size * dpr);
      ev.style.width = ev.style.height = size + 'px';
      ectx.setTransform(dpr, 0, 0, dpr, 0, 0);
    }
  }
  new ResizeObserver(resize).observe(stage);

  // ---------- URL 参数 ----------
  // ?scene=gen|xfmr|quiz；发电机 &N=10~200、&B=0.1~1、&n=0.2~2（r/s）、&R=1~20、&out=ring|comm、&start=neutral|parallel、
  // &angle=（θ，度，与中性面的夹角）、&pause=1、&slow=1；变压器 &U1=10~380、&n1=、&n2=（50~2200）、&xR=2~200、&src=ac|dc、&load=0；
  // 显示 &field=0、&current=0、&vel=0、&labels=0、&end=0；练习 &q=pos|expr|eff|xfmr
  var qs = new URLSearchParams(location.search);
  function num(k, r, step) {
    var v = qs.get(k);
    if (v == null || v === '' || isNaN(+v)) return null;
    return A.clamp(Math.round(+v / step) * step, r[0], r[1]);
  }
  if (HINTS[qs.get('scene')]) state.scene = qs.get('scene');
  var t;
  if ((t = num('N', G.N_RANGE, 10)) != null) state.N = t;
  if ((t = num('B', G.B_RANGE, 0.05)) != null) state.B = A.round(t, 2);
  if ((t = num('n', G.n_RANGE, 0.1)) != null) state.n = A.round(t, 1);
  if ((t = num('R', G.R_RANGE, 1)) != null) state.R = t;
  if (qs.get('out') === 'comm' || qs.get('out') === 'ring') state.out = qs.get('out');
  if (qs.get('start') === 'parallel') state.start = 'parallel';
  restart();
  if (qs.get('angle') && !isNaN(+qs.get('angle'))) { state.th = A.wrap(+qs.get('angle') * DEG); state.ph = A.wrap(state.th - state.th0); }
  if (qs.get('pause') === '1') state.run = false;
  if (qs.get('slow') === '1') state.slow = true;
  if ((t = num('U1', X.U_RANGE, 10)) != null) state.U1 = t;
  if ((t = num('n1', X.n_RANGE, 10)) != null) state.n1 = t;
  if ((t = num('n2', X.n_RANGE, 10)) != null) state.n2 = t;
  if ((t = num('xR', X.R_RANGE, 1)) != null) state.xR = t;
  if (qs.get('src') === 'dc') state.src = 'dc';
  if (qs.get('load') === '0') state.load = false;
  ['field', 'current', 'vel', 'labels', 'end'].forEach(function (k) { if (qs.get(k) === '0') state[k] = false; });
  if (A.TYPES.indexOf(qs.get('q')) >= 0) state.quizOnly = qs.get('q');
  setScene(state.scene);
  requestAnimationFrame(resize);

  // ---------- 主循环 ----------
  var last = performance.now(), lastRead = 0, readNow = true;
  function frame(now) {
    var dt = Math.min(0.05, (now - last) / 1000), v = view();
    last = now;
    var h = dt * (state.slow ? 0.25 : 1), quizStill = state.scene === 'quiz' && !state.answered;
    // 发电机
    var p = genP(), w = A.omega(p);
    if (state.run && !quizStill) {
      state.ph += w * h;
      if (state.ph >= Dr.PH) state.ph -= Dr.PH;
      state.th = state.th0 + state.ph;
    }
    var g = A.gen(p, state.th);
    if (state.run && !quizStill && g.Im > 0) { state.qc += 4 * g.i / g.Im * h; state.qe += 4 * g.iExt / g.Im * h; }
    // 变压器
    var x = A.xfmr(xfP()), dc = state.src === 'dc';
    if (!quizStill) state.xph = (state.xph + 2 * Math.PI * XF_HZ * h) % Dr.PH;
    var sn = Math.sin(state.xph), imax = Math.max(x.I1, x.I2, 1e-9);
    if (!quizStill) {
      if (dc) state.q1 += 2.2 * h;
      else { state.q1 += 5 * (x.I1 / imax) * sn * h; state.q2 += 5 * (x.I2 / imax) * sn * h; }
    }
    // 练习作答前不显示部件名称和电压标注，以免泄露答案
    var labels = state.labels && !quizStill;
    if (sc3) {
      if (v === 'gen') {
        sc3.show('gen', { th: state.th, out: state.out, i: g.i, iExt: g.iExt, Im: g.Im, Gfull: G_FULL, qc: state.qc, qe: state.qe,
          spin: w > 0 ? 1 : 0, field: state.field, current: state.current, vel: state.vel, labels: labels });
      } else {
        sc3.show('xfmr', { n1: state.n1, n2: state.n2, src: state.src, U1: state.U1, U2: x.U2, load: state.load,
          phi: dc ? 1 : -Math.cos(state.xph), q1: state.q1, q2: state.q2, i1on: dc || x.I1 > 0, i2on: x.I2 > 0,
          glow: x.bright, field: state.field, current: state.current, labels: labels });
      }
      sc3.render();
    }
    if (!ev.hidden) Dr.endView(ectx, EV, { th: state.th, i: g.i, spin: 1, v: state.vel });
    if (!gc.hidden) {
      if (v === 'gen') Dr.graph(gctx, GW, GH, { mode: 'gen', ph: state.ph, th0: state.th0, out: state.out, Em: g.Em, phiM: g.phiM });
      else Dr.graph(gctx, GW, GH, { mode: 'xfmr', ph: state.xph, src: state.src, U1: state.U1, U1m: x.U1m, U2m: x.U2m });
    }
    if (now - lastRead > 150 || readNow) {
      lastRead = now; readNow = false;
      if (state.scene === 'gen') readGen();
      else if (state.scene === 'xfmr') readXf();
      else readQuiz();
    }
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // 调试用
  window.__model = {
    state: state, A: A, scene: sc3, setScene: setScene, newQuiz: newQuiz, sync: syncUI, restart: restart, step: stepQuarter,
    answer: function (o) { answer(o == null ? state.quiz.answer : o); }
  };
})();
