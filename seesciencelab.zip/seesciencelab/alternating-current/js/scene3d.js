// 交变电流的产生与变压器：three.js 场景
// 场景一：交流发电机（S 极在左、N 极在右，线圈 ABCD 绕 z 轴转，两个滑环 K、L 或换向器，电刷接电流计 G 和电阻 R）
// 场景二：变压器（口字形铁芯，左边原线圈接电源，右边副线圈经开关接灯泡）
// 坐标与单位见 ac.js：x 右、y 上、z 指向观察者，单位 cm
(function () {
  var A = window.AC, G = A.GEN;
  var V3 = THREE.Vector3, Y = new V3(0, 1, 0);
  var COL = { N: 0xe0574f, S: 0x4a78d8, yoke: 0x6b7484, cu: 0xd98b4a, cu2: 0xe8a868, wire: 0x8a96a8, brush: 0x3a3f48,
    ins: 0x1b1f27, axle: 0x9aa3b0, field: 0x4fc3f7, I: 0xffc94a, v: 0x7ee081, core: 0x59636f, bat: 0x2f3746 };

  window.ACScene = function (container) {
    var renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    container.appendChild(renderer.domElement);
    var canvas = renderer.domElement;
    canvas.id = 'view3d';

    var labelRenderer = new THREE.CSS2DRenderer();
    var ls = labelRenderer.domElement.style;
    ls.position = 'absolute'; ls.top = '0'; ls.left = '0'; ls.pointerEvents = 'none'; ls.zIndex = '2';
    container.appendChild(labelRenderer.domElement);

    var scene = new THREE.Scene();
    scene.background = new THREE.Color('#05070d');
    var camera = new THREE.PerspectiveCamera(32, 1, 0.5, 500);
    scene.add(camera);
    scene.add(new THREE.AmbientLight(0xffffff, 0.45));
    var key = new THREE.DirectionalLight(0xffffff, 0.85);
    key.position.set(-3, 6, 8);
    camera.add(key);
    var rim = new THREE.DirectionalLight(0x9fc8ff, 0.3);
    rim.position.set(6, -3, -5);
    camera.add(rim);

    var controls = new THREE.OrbitControls(camera, canvas);
    controls.enableDamping = true;
    controls.dampingFactor = 0.08;
    controls.enablePan = false;
    var moved = false;
    controls.addEventListener('start', function () { moved = true; });

    var box = new THREE.BoxGeometry(1, 1, 1), cyl = new THREE.CylinderGeometry(1, 1, 1, 16), ball = new THREE.SphereGeometry(1, 16, 12);
    var cone = new THREE.ConeGeometry(1, 1, 14);
    function std(col, o) {
      o = o || {};
      return new THREE.MeshStandardMaterial({ color: new THREE.Color(col), roughness: o.r == null ? 0.5 : o.r, metalness: o.m || 0.1,
        transparent: !!o.op, opacity: o.op || 1, side: o.ds ? THREE.DoubleSide : THREE.FrontSide, emissive: new THREE.Color(o.em || 0),
        depthWrite: o.op ? o.op > 0.6 : true });
    }
    function mesh(geo, mat, g, pos, scl) {
      var m = new THREE.Mesh(geo, mat.isMaterial ? mat : std(mat));
      if (pos) m.position.set(pos[0], pos[1], pos[2]);
      if (scl) m.scale.set(scl[0], scl[1], scl[2]);
      g.add(m);
      return m;
    }
    function v3(p) { return p.isVector3 ? p : new V3(p[0], p[1], p[2]); }
    function stick(g, a, b, r, mat) {
      var m = mesh(cyl, mat, g);
      a = v3(a); b = v3(b);
      var d = b.clone().sub(a), len = d.length();
      m.position.copy(a).addScaledVector(d, 0.5);
      m.scale.set(r, len, r);
      if (len > 1e-6) m.quaternion.setFromUnitVectors(Y, d.normalize());
      return m;
    }
    function polyline(g, pts, r, mat) {
      for (var i = 0; i < pts.length - 1; i++) stick(g, pts[i], pts[i + 1], r, mat);
      pts.slice(1, -1).forEach(function (p) { mesh(ball, mat, g, p, [r, r, r]); });
    }
    function label(g, html, cls, pos) {
      var el = document.createElement('div');
      el.className = 'lab ' + (cls || '');
      el.innerHTML = html;
      var o = new THREE.CSS2DObject(el);
      if (pos) o.position.set(pos[0], pos[1], pos[2]);
      g.add(o);
      return o;
    }
    function setLab(o, html) { if (o.element.innerHTML !== html) o.element.innerHTML = html; }
    function arrow(g, col, r) {
      var a = new THREE.Group(), mat = std(col, { em: new THREE.Color(col).multiplyScalar(0.35), r: 0.4 });
      a.userData.shaft = mesh(cyl, mat, a);
      a.userData.head = mesh(cone, mat, a);
      a.userData.r = r || 0.16;
      g.add(a);
      return a;
    }
    function setArrow(a, from, dir, len) {
      var r = a.userData.r, hl = Math.min(len * 0.45, r * 5);
      a.visible = len > 0.05;
      if (!a.visible) return;
      a.position.copy(from);
      a.quaternion.setFromUnitVectors(Y, dir.clone().normalize());
      a.userData.shaft.scale.set(r, len - hl, r); a.userData.shaft.position.set(0, (len - hl) / 2, 0);
      a.userData.head.scale.set(r * 2.6, hl, r * 2.6); a.userData.head.position.set(0, len - hl / 2, 0);
    }
    // 电流小点：沿折线等距分布，phase 随电流推进（可正可负）
    function makeDots(g, n) {
      var mat = new THREE.MeshBasicMaterial({ color: COL.I }), arr = [];
      for (var i = 0; i < n; i++) arr.push(mesh(ball, mat, g, null, [0.13, 0.13, 0.13]));
      return arr;
    }
    function placeDots(dots, pts, phase, on, step) {
      var segs = [], tot = 0;
      for (var i = 0; i < pts.length - 1; i++) { var l = pts[i].distanceTo(pts[i + 1]); segs.push(l); tot += l; }
      step = step || 1.1;
      var n = Math.min(dots.length, Math.floor(tot / step));
      for (var k = 0; k < dots.length; k++) {
        var d = dots[k];
        d.visible = on && k < n;
        if (!d.visible) continue;
        var s = ((k * step + phase) % tot + tot) % tot, j = 0;
        while (j < segs.length - 1 && s > segs[j]) { s -= segs[j]; j++; }
        d.position.copy(pts[j]).lerp(pts[j + 1], segs[j] ? Math.min(1, s / segs[j]) : 0);
      }
    }
    function clearG(g) {
      for (var i = g.children.length - 1; i >= 0; i--) {
        var o = g.children[i];
        if (o.children && o.children.length) clearG(o);
        if (o.isCSS2DObject && o.element.parentNode) o.element.parentNode.removeChild(o.element);
        if (o.geometry && o.geometry !== box && o.geometry !== cyl && o.geometry !== ball && o.geometry !== cone) o.geometry.dispose();
        if (o.material && o.material.dispose) o.material.dispose();
        g.remove(o);
      }
    }

    // =============== 场景一：交流发电机 ===============
    var gGen = new THREE.Group();
    scene.add(gGen);
    var gn = {};
    var RZ = G.ringZ, CR = G.ringR, CL = G.ringLen, Z1 = RZ - 0.5, Z2 = RZ + 0.5;   // 滑环 K（接 A）在后、L（接 D）在前
    var XW = 4.6, YB = -9.2;   // 外电路竖直导线的 x、底边的 y
    (function buildGen() {
      var g = gGen, px = G.pole + G.poleW / 2;
      mesh(box, COL.S, g, [-px, 0, 0], [G.poleW, G.poleH, G.poleD]);
      mesh(box, COL.N, g, [px, 0, 0], [G.poleW, G.poleH, G.poleD]);
      mesh(box, COL.yoke, g, [0, -G.poleH / 2 - 0.6, 0], [2 * (G.pole + G.poleW), 1.2, G.poleD]);
      label(g, 'S', 'pole s', [-px, G.poleH / 2 + 0.9, 0]);
      label(g, 'N', 'pole n', [px, G.poleH / 2 + 0.9, 0]);
      // 磁感线：N（右）→ S（左）
      var pts = [], heads = [];
      [-3.4, -1.2, 1.2, 3.4].forEach(function (y) {
        [-4.6, -1.6, 1.6, 4.6].forEach(function (z) {
          if (Math.abs(y) < 2 && Math.abs(z) < 2) return;
          pts.push(new V3(G.pole, y, z), new V3(-G.pole, y, z));
          var h = mesh(cone, std(COL.field, { em: COL.field, op: 0.8 }), g, [2.6 * (y * z > 0 ? 1 : -1), y, z], [0.2, 0.5, 0.2]);
          h.quaternion.setFromUnitVectors(Y, new V3(-1, 0, 0));
          heads.push(h);
        });
      });
      gn.field = new THREE.LineSegments(new THREE.BufferGeometry().setFromPoints(pts),
        new THREE.LineBasicMaterial({ color: COL.field, transparent: true, opacity: 0.5 }));
      g.add(gn.field);
      gn.heads = heads;
      gn.lB = label(g, '<i>B</i>', 'bvec', [-4.8, -G.poleH / 2 + 1.2, G.poleD / 2 - 0.6]);
      // 中性面（x = 0 的竖直面，示意）
      gn.neutral = mesh(new THREE.PlaneGeometry(1, 1), std(0xe6ebf2, { op: 0.07, ds: true }), g, [0, 0, 0], [1, 2 * G.R + 1.6, 2 * G.H + 1.6]);
      gn.neutral.rotation.y = Math.PI / 2;
      gn.lNeutral = label(g, '中性面', 'part', [0, G.R + 1.3, -G.H - 0.8]);

      // 转子
      gn.rotor = new THREE.Group(); g.add(gn.rotor);
      var r = gn.rotor, R = G.R, H = G.H;
      stick(r, [0, 0, -H - 2.2], [0, 0, RZ + 1.6], 0.22, std(COL.axle, { m: 0.7, r: 0.3 }));
      var cu = std(COL.cu, { m: 0.45, r: 0.35 });
      polyline(r, [[0, R, H], [0, R, -H], [0, -R, -H], [0, -R, H]], 0.24, cu);
      [[0, R, H], [0, -R, H]].forEach(function (p) { mesh(ball, cu, r, p, [0.24, 0.24, 0.24]); });
      label(r, 'A', 'pt', [0, R + 0.6, H]);
      label(r, 'B', 'pt', [0, R + 0.6, -H]);
      label(r, 'C', 'pt', [0, -R - 0.6, -H]);
      label(r, 'D', 'pt', [0, -R - 0.6, H]);
      // 引线：滑环时 A 接后环 K、D 接前环 L；换向器时 A 接上半环、D 接下半环（转子坐标）
      gn.leadRing = new THREE.Group(); r.add(gn.leadRing);
      polyline(gn.leadRing, [[0, R, H], [0, CR * 0.85, H + 1], [0, CR * 0.85, Z1]], 0.12, cu);
      polyline(gn.leadRing, [[0, -R, H], [0, -CR * 0.85, H + 1], [0, -CR * 0.85, Z2]], 0.12, cu);
      gn.leadComm = new THREE.Group(); r.add(gn.leadComm);
      polyline(gn.leadComm, [[0, R, H], [0, CR * 0.85, H + 1], [0, CR * 0.85, RZ - CL / 2]], 0.12, cu);
      polyline(gn.leadComm, [[0, -R, H], [0, -CR * 0.85, H + 1], [0, -CR * 0.85, RZ - CL / 2]], 0.12, cu);
      // 滑环
      gn.ring = new THREE.Group(); r.add(gn.ring);
      [Z1, Z2].forEach(function (z) {
        var m = mesh(cyl, std(COL.cu2, { m: 0.6, r: 0.25 }), gn.ring, [0, 0, z], [CR, 0.62, CR]);
        m.rotation.x = Math.PI / 2;
      });
      var ins = mesh(cyl, std(COL.ins), gn.ring, [0, 0, RZ], [CR * 0.9, 1.9, CR * 0.9]);
      ins.rotation.x = Math.PI / 2;
      // 换向器：两个半环（CylinderGeometry 转到沿 z 后，几何角 θ 对应 xy 平面内 φ = θ − 90°）
      var g2 = G.GAP / Math.PI * 180, half = function (start) {
        var geo = new THREE.CylinderGeometry(CR, CR, CL, 24, 1, true, (start + g2) * Math.PI / 180, (180 - 2 * g2) * Math.PI / 180);
        geo.rotateX(Math.PI / 2);
        return geo;
      };
      gn.comm = new THREE.Group(); r.add(gn.comm);
      gn.comm.position.z = RZ;
      mesh(half(90), std(COL.cu2, { m: 0.6, r: 0.25, ds: true }), gn.comm);    // φ ∈ (0, 180°)：上半环，接 A
      mesh(half(270), std(COL.cu2, { m: 0.6, r: 0.25, ds: true }), gn.comm);   // 下半环，接 D
      var ins2 = mesh(cyl, std(COL.ins), gn.comm, null, [CR * 0.92, CL * 1.02, CR * 0.92]);
      ins2.rotation.x = Math.PI / 2;
      // 线圈两边的电流方向（转子坐标）
      gn.Iab = arrow(r, COL.I, 0.12); gn.Icd = arrow(r, COL.I, 0.12);
      gn.dotsCoil = makeDots(r, 40);
      gn.coilPath = { ring: [[0, CR * 0.85, Z1], [0, CR * 0.85, H + 1], [0, R, H], [0, R, -H], [0, -R, -H], [0, -R, H], [0, -CR * 0.85, H + 1], [0, -CR * 0.85, Z2]],
        comm: [[0, CR * 0.85, RZ - CL / 2], [0, CR * 0.85, H + 1], [0, R, H], [0, R, -H], [0, -R, -H], [0, -R, H], [0, -CR * 0.85, H + 1], [0, -CR * 0.85, RZ - CL / 2]] };
      Object.keys(gn.coilPath).forEach(function (k) { gn.coilPath[k] = gn.coilPath[k].map(v3); });
      // 速度
      gn.vAB = arrow(g, COL.v, 0.13); gn.vCD = arrow(g, COL.v, 0.13);
      gn.lvAB = label(g, '<i>v</i>', 'vlab'); gn.lvCD = label(g, '<i>v</i>', 'vlab');

      // 外电路：电流计 G（中央零刻度）与电阻 R
      var zc = RZ, wm = std(COL.wire, { m: 0.4 });
      polyline(g, [[XW, YB, zc], [3.4, YB, zc]], 0.09, wm);
      polyline(g, [[0.6, YB, zc], [-1, YB, zc]], 0.09, wm);
      polyline(g, [[-3.6, YB, zc], [-XW, YB, zc]], 0.09, wm);
      mesh(box, std(0x2b3342), g, [2, YB, zc], [2.8, 2.4, 0.7]);
      mesh(box, std(0xe8ecf2, { r: 0.9 }), g, [2, YB + 0.15, zc + 0.36], [2.4, 1.9, 0.02]);
      gn.needle = new THREE.Group(); gn.needle.position.set(2, YB - 0.6, zc + 0.39); g.add(gn.needle);
      mesh(box, std(0xc0392b, { em: 0x401010 }), gn.needle, [0, 0.8, 0], [0.07, 1.6, 0.03]);
      mesh(ball, std(0x222831), g, [2, YB - 0.6, zc + 0.4], [0.12, 0.12, 0.05]);
      // 刻度
      for (var k = -4; k <= 4; k++) {
        var a = k * 0.18, t = mesh(box, std(0x222831), g, null, [0.04, k ? 0.18 : 0.3, 0.02]);
        t.position.set(2 + Math.sin(a) * 1.55, YB - 0.6 + Math.cos(a) * 1.55, zc + 0.38);
        t.rotation.z = -a;
      }
      label(g, 'G', 'part', [2, YB - 1.75, zc + 0.4]);
      var res = mesh(cyl, std(0xc9b58a, { r: 0.6 }), g, [-2.3, YB, zc], [0.5, 2.6, 0.5]);
      res.rotation.z = Math.PI / 2;
      [-3, -2.5, -2, -1.6].forEach(function (x, i) {
        var b = mesh(cyl, std([0x8b4513, 0x111111, 0xd4a017, 0xb08d57][i]), g, [x, YB, zc], [0.52, 0.16, 0.52]);
        b.rotation.z = Math.PI / 2;
      });
      label(g, 'R', 'part', [-2.3, YB - 1, zc]);
      gn.brushes = new THREE.Group(); g.add(gn.brushes);
      gn.dotsExt = makeDots(g, 50);
      gn.lK = label(g, 'K', 'pt', [-CR - 0.3, CR + 0.5, Z1]);
      gn.lL = label(g, 'L', 'pt', [CR + 0.3, CR + 0.5, Z2]);
      gn.lRing = label(g, '滑环', 'part', [0, CR + 1.5, RZ]);
      gn.lBrush = label(g, '电刷', 'part', [XW + 1.3, 0.8, RZ]);
      gn.out = '';
    })();

    function buildBrushes(out) {
      clearG(gn.brushes);
      var g = gn.brushes, bm = std(COL.brush, { r: 0.8 }), wm = std(COL.wire, { m: 0.4 });
      var zL = out === 'comm' ? RZ : Z1, zR = out === 'comm' ? RZ : Z2;
      mesh(box, bm, g, [-CR - 0.35, 0, zL], [0.7, 0.55, 0.55]);
      mesh(box, bm, g, [CR + 0.35, 0, zR], [0.7, 0.55, 0.55]);
      var pr = [[CR + 0.7, 0, zR], [XW, 0, zR], [XW, YB, RZ]], pl = [[-XW, YB, RZ], [-XW, 0, zL], [-CR - 0.7, 0, zL]];
      polyline(g, pr, 0.09, wm); polyline(g, pl, 0.09, wm);
      // 外电路电流正方向：右电刷 → 外电路 → 左电刷
      gn.ext = pr.concat(pl).map(v3);
    }

    function showGen(o) {
      gGen.visible = true; gXf.visible = false;
      if (o.out !== gn.out) {
        gn.out = o.out; buildBrushes(o.out);
        var comm = o.out === 'comm';
        gn.comm.visible = gn.leadComm.visible = comm; gn.ring.visible = gn.leadRing.visible = !comm;
        gn.lK.visible = gn.lL.visible = !comm;
        setLab(gn.lRing, comm ? '换向器' : '滑环');
      }
      gn.rotor.rotation.z = o.th;
      gn.field.visible = o.field; gn.heads.forEach(function (h) { h.visible = o.field; }); gn.lB.visible = o.field;
      gn.neutral.visible = gn.lNeutral.visible = o.labels;
      gn.lRing.visible = gn.lBrush.visible = o.labels;
      if (gn.out !== 'comm') gn.lK.visible = gn.lL.visible = o.labels;
      var R = G.R, H = G.H, s = Math.sin(o.th), c = Math.cos(o.th);
      // 线圈中电流：i > 0 为 A→B→C→D（沿 coilPath 正向）
      var on = o.current && Math.abs(o.i) > 1e-6;
      placeDots(gn.dotsCoil, gn.coilPath[o.out], o.qc, on);
      placeDots(gn.dotsExt, gn.ext, o.qe, o.current && Math.abs(o.iExt) > 1e-6);
      var il = on ? 0.6 + 1.8 * Math.min(1, Math.abs(o.i) / Math.max(1e-9, o.Im)) : 0, sg = o.i > 0 ? 1 : -1;
      setArrow(gn.Iab, new V3(0, R + 0.5, sg * il / 2), new V3(0, 0, -sg), il);
      setArrow(gn.Icd, new V3(0, -R - 0.5, -sg * il / 2), new V3(0, 0, sg), il);
      // 速度（逆时针转动）：AB 在 (−R s, R c)，v ∝ (−c, −s)
      var vl = o.vel && o.spin ? 2.2 : 0, pab = new V3(-R * s, R * c, H + 0.3), pcd = new V3(R * s, -R * c, H + 0.3);
      var vd = new V3(-c * o.spin, -s * o.spin, 0);
      setArrow(gn.vAB, pab, vd, vl); setArrow(gn.vCD, pcd, vd.clone().negate(), vl);
      gn.lvAB.visible = gn.lvCD.visible = vl > 0;
      gn.lvAB.position.copy(pab).addScaledVector(vd, vl + 0.5);
      gn.lvCD.position.copy(pcd).addScaledVector(vd, -(vl + 0.5));
      // 电流计指针：中央零刻度，满偏约 ±0.72 rad
      gn.needle.rotation.z = -0.72 * A.clamp(o.iExt / o.Gfull, -1, 1);
    }

    // =============== 场景二：变压器 ===============
    var gXf = new THREE.Group();
    scene.add(gXf);
    var xf = {};
    var CX = 5.8, CY = 4.8, CT = 2.4, HR = 1.75, HY = 3.3, SX = -11.5, LX = 11.5;
    (function buildXf() {
      var g = gXf;
      xf.coreMat = std(COL.core, { m: 0.5, r: 0.45 });
      mesh(box, xf.coreMat, g, [-CX, 0, 0], [CT, 2 * CY + CT, CT]);
      mesh(box, xf.coreMat, g, [CX, 0, 0], [CT, 2 * CY + CT, CT]);
      mesh(box, xf.coreMat, g, [0, CY, 0], [2 * CX - CT, CT, CT]);
      mesh(box, xf.coreMat, g, [0, -CY, 0], [2 * CX - CT, CT, CT]);
      xf.lCore = label(g, '铁芯', 'part', [0, CY + 2, 0]);
      // 磁通量箭头（铁芯前表面，顺时针为正）
      xf.flux = [];
      [-2.6, 0, 2.6].forEach(function (x) {
        [[x, CY, 1], [x, -CY, -1]].forEach(function (p) {
          var h = mesh(cone, std(COL.field, { em: COL.field, op: 0.9 }), g, [p[0], p[1], CT / 2 + 0.05], [0.42, 1, 0.42]);
          h.userData.dir = p[2];
          xf.flux.push(h);
        });
      });
      xf.lPhi = label(g, 'Φ', 'bvec', [0, CY, CT / 2 + 0.6]);
      xf.coils = new THREE.Group(); g.add(xf.coils);
      // 电源
      xf.src = new THREE.Group(); g.add(xf.src);
      mesh(box, COL.bat, xf.src, [SX, 0, 0], [2.2, 3, 1.6]);
      xf.srcFace = mesh(new THREE.CircleGeometry(0.8, 24), std(0xe8ecf2, { r: 0.9 }), xf.src, [SX, 0, 0.81]);
      xf.lSrc = label(g, '交流电源', 'part', [SX, -2.5, 0]);
      xf.lSym = label(g, '~', 'sym', [SX, 0, 0.9]);
      // 灯泡（负载）
      xf.bulb = mesh(ball, std(0xfff1c2, { op: 0.75, em: 0x000000, r: 0.2 }), g, [LX, 0.6, 0], [1.1, 1.25, 1.1]);
      mesh(cyl, std(0xaab4c3, { m: 0.7, r: 0.3 }), g, [LX, -1.1, 0], [0.6, 0.9, 0.6]);
      xf.halo = mesh(ball, new THREE.MeshBasicMaterial({ color: 0xffd76a, transparent: true, opacity: 0, depthWrite: false, blending: THREE.AdditiveBlending }), g, [LX, 0.6, 0], [1.9, 1.9, 1.9]);
      xf.lLamp = label(g, '灯泡（负载 R）', 'part', [LX, -2.4, 0]);
      // 副线圈开关（上方导线上的刀闸）
      var wm = std(COL.wire, { m: 0.4 }), hx = 9.8, sx0 = 8.2;
      polyline(g, [[hx, HY + 1.2, 0], [LX, HY + 1.2, 0], [LX, 1.9, 0]], 0.09, wm);
      polyline(g, [[LX, -1.55, 0], [LX, -HY - 1.2, 0], [CX + HR + 0.1, -HY - 1.2, 0], [CX + HR + 0.1, -HY, 0]], 0.09, wm);
      polyline(g, [[CX + HR + 0.1, HY, 0], [CX + HR + 0.1, HY + 1.2, 0], [sx0, HY + 1.2, 0]], 0.09, wm);
      mesh(box, std(0x59636f), g, [hx, HY + 1, 0], [0.4, 0.3, 0.6]);
      mesh(box, std(0x59636f), g, [sx0, HY + 1, 0], [0.4, 0.3, 0.6]);
      xf.blade = new THREE.Group(); xf.blade.position.set(hx, HY + 1.25, 0); g.add(xf.blade);
      mesh(box, std(0xc9ced6, { m: 0.6, r: 0.3 }), xf.blade, [-(hx - sx0) / 2, 0, 0], [hx - sx0, 0.12, 0.3]);
      mesh(cyl, std(0x222831), xf.blade, [-(hx - sx0) + 0.1, 0.4, 0], [0.14, 0.7, 0.14]);
      xf.lSw = label(g, '开关', 'part', [(hx + sx0) / 2, HY + 2.6, 0]);
      // 原线圈导线
      polyline(g, [[-CX - HR - 0.1, HY, 0], [-CX - HR - 0.1, HY + 1.2, 0], [SX, HY + 1.2, 0], [SX, 1.5, 0]], 0.09, wm);
      polyline(g, [[SX, -1.5, 0], [SX, -HY - 1.2, 0], [-CX - HR - 0.1, -HY - 1.2, 0], [-CX - HR - 0.1, -HY, 0]], 0.09, wm);
      xf.dots1 = makeDots(g, 200); xf.dots2 = makeDots(g, 200);
      xf.lN1 = label(g, '', 'part', [-CX, -HY - 2.3, 1.6]);
      xf.lN2 = label(g, '', 'part', [CX, -HY - 2.3, 1.6]);
      xf.lU1 = label(g, '', 'uval', [SX - 3.4, 0, 0]);
      xf.lU2 = label(g, '', 'uval', [LX + 2.8, 0.6, 0]);
      xf.n = '';
    })();

    // 线圈：绕在铁芯竖直边上的螺旋线（显示圈数 = 匝数 / 100，2~22 圈）
    function helix(cx, turns, a0) {
      var pts = [], n = turns * 24;
      for (var i = 0; i <= n; i++) {
        var t = i / n, a = a0 + t * turns * 2 * Math.PI;
        pts.push(new V3(cx + HR * Math.cos(a), -HY + 2 * HY * t, HR * Math.sin(a)));
      }
      return pts;
    }
    function shownTurns(n) { return Math.max(2, Math.min(22, Math.round(n / 100))); }
    function buildCoils(n1, n2) {
      clearG(xf.coils);
      var h1 = helix(-CX, shownTurns(n1), Math.PI), h2 = helix(CX, shownTurns(n2), 0);
      [[h1, COL.cu], [h2, COL.cu2]].forEach(function (p) {
        var geo = new THREE.TubeGeometry(new THREE.CatmullRomCurve3(p[0]), p[0].length * 2, 0.16, 8, false);
        xf.coils.add(new THREE.Mesh(geo, std(p[1], { m: 0.45, r: 0.35 })));
      });
      var x1 = -CX - HR - 0.1, x2 = CX + HR + 0.1;
      // 原线圈电流正方向：电源上端 → 线圈上端 → 螺旋向下 → 电源下端
      xf.path1 = [[SX, 1.5, 0], [SX, HY + 1.2, 0], [x1, HY + 1.2, 0], [x1, HY, 0]].map(v3).concat(h1.slice().reverse())
        .concat([[x1, -HY, 0], [x1, -HY - 1.2, 0], [SX, -HY - 1.2, 0], [SX, -1.5, 0]].map(v3));
      // 副线圈：线圈上端 → 开关 → 灯泡 → 线圈下端 → 螺旋向上
      xf.path2 = [[x2, HY, 0], [x2, HY + 1.2, 0], [LX, HY + 1.2, 0], [LX, 0.6, 0], [LX, -HY - 1.2, 0], [x2, -HY - 1.2, 0], [x2, -HY, 0]].map(v3).concat(h2);
    }

    function showXf(o) {
      gGen.visible = false; gXf.visible = true;
      var nk = o.n1 + '|' + o.n2;
      if (nk !== xf.n) { xf.n = nk; buildCoils(o.n1, o.n2); }
      var dc = o.src === 'dc';
      setLab(xf.lN1, '原线圈 n₁ = ' + o.n1);
      setLab(xf.lN2, '副线圈 n₂ = ' + o.n2);
      setLab(xf.lSrc, dc ? '直流电源' : '交流电源');
      setLab(xf.lSym, dc ? '<span>+</span> <span>−</span>' : '~');
      setLab(xf.lU1, 'U₁ = ' + A.fmt(o.U1, 3) + ' V');
      setLab(xf.lU2, 'U₂ = ' + A.fmt(o.U2, 3) + ' V');
      xf.lU1.visible = xf.lU2.visible = o.labels;
      [xf.lCore, xf.lSrc, xf.lLamp, xf.lSw, xf.lN1, xf.lN2].forEach(function (l) { l.visible = o.labels; });
      // 磁通量：phi ∈ [−1, 1]
      var f = o.phi, af = Math.abs(f);
      xf.flux.forEach(function (h) {
        h.visible = o.field && af > 0.08;
        h.scale.set(0.3 + 0.2 * af, 0.5 + 0.9 * af, 0.3 + 0.2 * af);
        h.quaternion.setFromUnitVectors(Y, new V3(h.userData.dir * (f >= 0 ? 1 : -1), 0, 0));
      });
      xf.lPhi.visible = o.field;
      xf.coreMat.emissive.setRGB(0.05 * af, 0.16 * af, 0.24 * af);
      xf.blade.rotation.z = o.load ? 0 : -0.6;
      placeDots(xf.dots1, xf.path1, o.q1, o.current && o.i1on, 0.9);
      placeDots(xf.dots2, xf.path2, o.q2, o.current && o.i2on, 0.9);
      xf.bulb.material.emissive.setRGB(1 * o.glow, 0.78 * o.glow, 0.3 * o.glow);
      xf.halo.material.opacity = Math.min(0.55, 0.35 * o.glow);
    }

    // ---------- 取景 ----------
    var mode = '';
    var VIEWS = {
      gen: { dir: [0.5, 0.36, 1], box: [[-G.pole - G.poleW, YB - 1.6, -G.poleD / 2], [G.pole + G.poleW, G.poleH / 2 + 1.4, RZ + 1.6]] },
      xfmr: { dir: [0.18, 0.28, 1], box: [[SX - 4.5, -CY - 2.6, -2], [LX + 4.6, CY + 2.8, 2]] }
    };
    function fit() {
      var v = VIEWS[mode]; if (!v) return;
      var aspect = camera.aspect || 1, half = Math.tan(camera.fov * Math.PI / 360);
      var b0 = v.box[0], b1 = v.box[1], corners = [];
      for (var i = 0; i < 8; i++) corners.push(new V3(i & 1 ? b1[0] : b0[0], i & 2 ? b1[1] : b0[1], i & 4 ? b1[2] : b0[2]));
      var d = new V3(v.dir[0], v.dir[1], v.dir[2]).normalize();
      var target = new V3((b0[0] + b1[0]) / 2, (b0[1] + b1[1]) / 2, (b0[2] + b1[2]) / 2);
      var size = Math.max(b1[0] - b0[0], b1[1] - b0[1], b1[2] - b0[2]), dist = size / half;
      var right = new V3(), up = new V3(), p = new V3(), margin = 0.9;
      for (var k = 0; k < 12; k++) {
        camera.position.copy(target).addScaledVector(d, dist);
        camera.lookAt(target);
        camera.updateMatrixWorld();
        var x0 = 1e9, x1 = -1e9, y0 = 1e9, y1 = -1e9;
        corners.forEach(function (c) {
          p.copy(c).project(camera);
          x0 = Math.min(x0, p.x); x1 = Math.max(x1, p.x); y0 = Math.min(y0, p.y); y1 = Math.max(y1, p.y);
        });
        right.setFromMatrixColumn(camera.matrixWorld, 0); up.setFromMatrixColumn(camera.matrixWorld, 1);
        var hh = dist * half, ww = hh * aspect;
        target.addScaledVector(right, (x0 + x1) / 2 * ww).addScaledVector(up, (y0 + y1) / 2 * hh);
        dist *= Math.max((x1 - x0) / 2, (y1 - y0) / 2) / margin;
      }
      controls.target.copy(target);
      camera.position.copy(target).addScaledVector(d, dist);
      controls.minDistance = dist * 0.35;
      controls.maxDistance = dist * 2.2;
      controls.update();
    }
    function home() { moved = false; fit(); }
    function show(m, o) {
      if (m !== mode) { mode = m; moved = false; fit(); }
      if (m === 'gen') showGen(o); else showXf(o);
    }
    function resize(w, h) {
      camera.aspect = w / Math.max(1, h);
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
      labelRenderer.setSize(w, h);
      if (!moved) fit();
    }
    function render() {
      controls.update();
      renderer.render(scene, camera);
      labelRenderer.render(scene, camera);
      hideLabels(scene, true);
    }
    // CSS2DRenderer 只看标签自身的 visible，父级隐藏时也要把标签藏起来
    function hideLabels(o, vis) {
      vis = vis && o.visible;
      if (o.isCSS2DObject && !vis) o.element.style.display = 'none';
      for (var i = 0; i < o.children.length; i++) hideLabels(o.children[i], vis);
    }

    return { show: show, render: render, resize: resize, home: home, canvas: canvas, labels: labelRenderer.domElement, camera: camera, controls: controls };
  };
})();
