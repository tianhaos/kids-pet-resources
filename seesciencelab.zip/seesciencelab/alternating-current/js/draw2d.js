// 交变电流的产生与变压器：2D 小图（端视图、波形图）
// 端视图从前方（沿 −z）看：⊙ 表示电流流出纸面（+z），⊗ 表示流入纸面；屏幕 y 向下，画图时 y 取反
(function () {
  var A = window.AC;
  var C = { N: '#e0574f', S: '#4a78d8', field: '#4fc3f7', I: '#ffc94a', v: '#7ee081', cu: '#d98b4a', u2: '#7ee081',
    text: '#e6ebf2', muted: '#8a96a8', line: '#2a3446', grid: '#1b2333', bg: 'rgba(11,15,24,.92)' };
  var K = 1;
  function font(px, w) { return (w || '') + ' ' + Math.round(px * K) + 'px system-ui, sans-serif'; }

  function arrowLine(ctx, x0, y0, x1, y1, col, w, head) {
    var a = Math.atan2(y1 - y0, x1 - x0), h = head || 7;
    ctx.strokeStyle = ctx.fillStyle = col; ctx.lineWidth = w || 2;
    ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1 - Math.cos(a) * h * 0.6, y1 - Math.sin(a) * h * 0.6); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(x1, y1);
    ctx.lineTo(x1 - Math.cos(a - 0.45) * h, y1 - Math.sin(a - 0.45) * h);
    ctx.lineTo(x1 - Math.cos(a + 0.45) * h, y1 - Math.sin(a + 0.45) * h);
    ctx.closePath(); ctx.fill();
  }
  // 导线截面：s = +1 ⊙，−1 ⊗，0 无电流
  function wireDot(ctx, x, y, r, s) {
    ctx.fillStyle = C.cu; ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = ctx.fillStyle = '#05070d'; ctx.lineWidth = 1.6;
    if (s > 0) { ctx.beginPath(); ctx.arc(x, y, r * 0.28, 0, Math.PI * 2); ctx.fill(); }
    else if (s < 0) {
      var k = r * 0.55;
      ctx.beginPath(); ctx.moveTo(x - k, y - k); ctx.lineTo(x + k, y + k); ctx.moveTo(x + k, y - k); ctx.lineTo(x - k, y + k); ctx.stroke();
    }
  }

  // 端视图：o = { th, i（线圈电流，A→B→C→D 为正）, spin（转动方向 ±1，0 静止）, v（是否画速度） }
  function endView(ctx, S, o) {
    K = Math.min(1.45, Math.max(1, S / 260));
    ctx.clearRect(0, 0, S, S);
    ctx.fillStyle = C.bg; ctx.fillRect(0, 0, S, S);
    ctx.fillStyle = C.muted; ctx.font = font(11); ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic';
    ctx.fillText('从滑环一端看', 8 * K, 15 * K);
    var cx = S / 2, cy = S / 2 + 2 * K, R = S * 0.27, pw = S * 0.09, ph = S * 0.56, gx = R + S * 0.1;
    // 磁极：S 左、N 右
    [[-1, 'S', C.S], [1, 'N', C.N]].forEach(function (p) {
      var x = cx + p[0] * gx + (p[0] < 0 ? -pw : 0);
      ctx.fillStyle = p[2]; ctx.fillRect(x, cy - ph / 2, pw, ph);
      ctx.fillStyle = '#fff'; ctx.font = font(12, 600); ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText(p[1], x + pw / 2, cy);
    });
    ctx.textBaseline = 'alphabetic';
    // 磁感线（N → S，向左）
    ctx.globalAlpha = 0.45;
    [-0.78, -0.3, 0.3, 0.78].forEach(function (k) {
      var y = cy + k * ph / 2;
      arrowLine(ctx, cx + gx - 3, y, cx - gx + 3, y, C.field, 1.1, 6);
    });
    ctx.globalAlpha = 1;
    // 中性面（竖直虚线）
    ctx.setLineDash([4, 4]); ctx.strokeStyle = 'rgba(230,235,242,.45)'; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(cx, cy - R - 12 * K); ctx.lineTo(cx, cy + R + 12 * K); ctx.stroke();
    ctx.setLineDash([]);
    ctx.fillStyle = C.muted; ctx.font = font(10); ctx.textAlign = 'left';
    ctx.fillText('中性面', cx + 4 * K, cy - R - 4 * K);
    // 线圈平面
    var s = Math.sin(o.th), c = Math.cos(o.th);
    var ax = cx - R * s, ay = cy - R * c, dx = cx + R * s, dy = cy + R * c;
    ctx.strokeStyle = C.cu; ctx.lineWidth = 3 * K;
    ctx.beginPath(); ctx.moveTo(ax, ay); ctx.lineTo(dx, dy); ctx.stroke();
    ctx.fillStyle = '#9aa3b0'; ctx.beginPath(); ctx.arc(cx, cy, 3.5 * K, 0, Math.PI * 2); ctx.fill();
    // 夹角 θ（中性面到线圈平面）
    var a = A.wrap(o.th);
    if (a > 0.08 && a < 2 * Math.PI - 0.08) {
      ctx.strokeStyle = 'rgba(255,201,74,.6)'; ctx.lineWidth = 1.2;
      ctx.beginPath(); ctx.arc(cx, cy, R * 0.38, -Math.PI / 2 - Math.min(a, Math.PI), -Math.PI / 2, false); ctx.stroke();
    }
    // 速度（逆时针为正）
    if (o.v && o.spin) {
      var vl = R * 0.62 * o.spin, vx = -c * vl, vy = s * vl;   // 屏幕坐标下的切向
      arrowLine(ctx, ax, ay, ax + vx, ay + vy, C.v, 2, 7);
      arrowLine(ctx, dx, dy, dx - vx, dy - vy, C.v, 2, 7);
    }
    var si = Math.abs(o.i) < 1e-9 ? 0 : o.i > 0 ? 1 : -1;
    wireDot(ctx, ax, ay, 7 * K, -si);
    wireDot(ctx, dx, dy, 7 * K, si);
    ctx.fillStyle = C.text; ctx.font = font(11, 600); ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText('AB', ax - s * 16 * K, ay - c * 16 * K);
    ctx.fillText('CD', dx + s * 16 * K, dy + c * 16 * K);
    ctx.textBaseline = 'alphabetic';
    ctx.font = font(10); ctx.textAlign = 'left'; ctx.fillStyle = C.muted;
    ctx.fillText('⊙ 流出纸面  ⊗ 流入纸面', 8 * K, S - 7 * K);
    if (o.v && S >= 170) { ctx.fillStyle = C.v; ctx.textAlign = 'right'; ctx.fillText('→ v', S - 8 * K, S - 7 * K); }
  }

  // ---------- 波形图 ----------
  var PH = 4 * Math.PI;   // 横轴：两个周期
  // 一条曲线：区域 box = {x, y, w, h}，f(φ) 返回 [-1, 1]，cur 为当前相位（0~PH）
  function plot(ctx, box, f, cur, col, name, peak, opt) {
    opt = opt || {};
    var x0 = box.x, y0 = box.y + box.h / 2, hw = box.h / 2 - 4, X = function (p) { return x0 + p / PH * box.w; };
    // 网格：每 T/4 一条
    ctx.strokeStyle = C.grid; ctx.lineWidth = 1;
    for (var k = 0; k <= 8; k++) { var gx = Math.round(X(k * Math.PI / 2)) + 0.5; ctx.beginPath(); ctx.moveTo(gx, box.y); ctx.lineTo(gx, box.y + box.h); ctx.stroke(); }
    ctx.strokeStyle = '#3a465c';
    ctx.beginPath(); ctx.moveTo(x0, Math.round(y0) + 0.5); ctx.lineTo(x0 + box.w, Math.round(y0) + 0.5); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(x0 + 0.5, box.y); ctx.lineTo(x0 + 0.5, box.y + box.h); ctx.stroke();
    // 整条理论曲线（淡）+ 已走过的部分（亮）
    function path(p1, alpha, w) {
      ctx.globalAlpha = alpha; ctx.strokeStyle = col; ctx.lineWidth = w;
      if (opt.dash) ctx.setLineDash([5, 4]);
      ctx.beginPath();
      var n = Math.max(2, Math.ceil(p1 / PH * 240));
      for (var i = 0; i <= n; i++) {
        var p = p1 * i / n, y = y0 - f(p) * hw;
        if (i) ctx.lineTo(X(p), y); else ctx.moveTo(X(p), y);
      }
      ctx.stroke(); ctx.setLineDash([]); ctx.globalAlpha = 1;
    }
    path(PH, 0.22, 1.5);
    if (cur > 0) path(cur, 1, 2.2 * K);
    // 当前点
    var cy = y0 - f(cur) * hw;
    ctx.fillStyle = col; ctx.beginPath(); ctx.arc(X(cur), cy, 3.6 * K, 0, Math.PI * 2); ctx.fill();
    // 名称、峰值
    ctx.font = font(12, 700); ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.fillStyle = col;
    ctx.fillText(name, box.x - 30 * K, y0);
    ctx.font = font(10.5); ctx.fillStyle = C.muted; ctx.textBaseline = 'top'; ctx.textAlign = 'right';
    if (peak) ctx.fillText(peak, x0 + box.w - 4, box.y + 1);
    ctx.textBaseline = 'alphabetic';
  }

  // o：gen → { ph, th0, out, Em, phiM, eName }；xfmr → { ph, src, U1m, U2m }
  function graph(ctx, W, H, o) {
    K = W < 520 ? 0.92 : 1;
    ctx.clearRect(0, 0, W, H);
    ctx.fillStyle = C.bg; ctx.fillRect(0, 0, W, H);
    var left = 40 * K, right = 14, top = 8, bot = 20 * K, gap = 8;
    var h = (H - top - bot - gap) / 2, w = W - left - right;
    var cur = ((o.ph % PH) + PH) % PH;
    var b1 = { x: left, y: top, w: w, h: h }, b2 = { x: left, y: top + h + gap, w: w, h: h };
    if (o.mode === 'gen') {
      var th0 = o.th0;
      plot(ctx, b1, function (p) { return Math.cos(th0 + p); }, cur, C.field, 'Φ', 'Φm = BS = ' + A.fmt(o.phiM, 3) + ' Wb');
      var comm = o.out === 'comm';
      if (comm) plot(ctx, b2, function (p) { return Math.sin(th0 + p); }, 0, 'rgba(255,201,74,.55)', '', '', { dash: true });
      plot(ctx, b2, function (p) {
        var v = Math.sin(th0 + p);
        return comm ? (A.onGap(th0 + p) ? 0 : Math.abs(v)) : v;
      }, cur, C.I, comm ? 'u' : 'e', comm ? '外电路（虚线：线圈中的 e）Em = ' + A.fmt(o.Em, 3) + ' V' : 'Em = NBSω = ' + A.fmt(o.Em, 3) + ' V');
    } else {
      var dc = o.src === 'dc';
      plot(ctx, b1, function (p) { return dc ? 0.8 : Math.sin(p); }, cur, C.I, 'u₁', dc ? '直流 U₁ = ' + A.fmt(o.U1, 3) + ' V' : 'U₁m = ' + A.fmt(o.U1m, 3) + ' V');
      var r = o.U2m > 0 ? 1 : 0;
      plot(ctx, b2, function (p) { return dc ? 0 : r * Math.sin(p); }, cur, C.u2, 'u₂', dc ? 'U₂ = 0（磁通量不变，没有感应电动势）' : 'U₂m = ' + A.fmt(o.U2m, 3) + ' V（纵轴各自缩放）');
    }
    // 横轴刻度
    ctx.fillStyle = C.muted; ctx.font = font(10.5); ctx.textAlign = 'center'; ctx.textBaseline = 'alphabetic';
    var lab = ['', 'T/4', 'T/2', '3T/4', 'T', '5T/4', '3T/2', '7T/4', '2T'];
    for (var k = 1; k <= 8; k++) {
      if (W < 520 && k % 2) continue;
      ctx.fillText(lab[k], left + w * k / 8 - (k === 8 ? 8 : 0), H - 5);
    }
    ctx.textAlign = 'left'; ctx.fillText('t', left - 12 * K, H - 5);
  }

  window.ACDraw = { endView: endView, graph: graph, PH: PH };
})();
