(function () {
  'use strict';

  var R = window.Reflex;
  // 取景框覆盖肢体活动端点，膝跳需要留出小腿前伸的空间。
  var ARM_FRAME = { x: 75, y: 55, w: 590, h: 518 };
  var ARM_MOBILE_FRAME = { x: 90, y: 55, w: 505, h: 518 };
  var LEG_FRAME = { x: 315, y: 172, w: 455, h: 518 };
  var FONT = '-apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", sans-serif';

  var COL = {
    bg: '#05070d',
    body: '#142234', limb: '#263b50', limbLine: '#536d85',
    torsoLine: '#37516a',
    muscle: '#6b3b45', muscleOn: '#b4545f', muscleLine: '#8a4b58',
    cord: '#1b2436', cordLine: '#2c3850', center: '#c9a7ff',
    receptor: '#6fe3a0', afferent: '#58c8ff', efferent: '#ffa15c', effector: '#ff6b6b',
    impulse: '#ffc94a', brain: '#d98fa8', text: '#e6ebf2', muted: '#8d99ab', danger: '#ff5f6d'
  };

  var ARM = {
    shoulder: { x: 452, y: 232 },
    elbow: { x: 346, y: 340 },
    wrist: { x: 218, y: 410 },
    hand: { x: 205, y: 422 },
    heat: { x: 176, y: 449 },
    biceps: { x: 401, y: 281 },
    cordIn: { x: 500, y: 298 },
    cordOut: { x: 500, y: 330 },
    brain: { x: 500, y: 126 }
  };

  var LEG = {
    hip: { x: 500, y: 382 },
    knee: { x: 520, y: 512 },
    ankle: { x: 520, y: 652 },
    foot: { x: 562, y: 668 },
    tendon: { x: 540, y: 505 },
    receptor: { x: 538, y: 458 },
    quad: { x: 545, y: 438 },
    cordIn: { x: 500, y: 368 },
    cordOut: { x: 500, y: 390 },
    brain: { x: 500, y: 126 }
  };

  function clamp(v) { return v < 0 ? 0 : v > 1 ? 1 : v; }
  function dist(a, b) { return Math.hypot(a.x - b.x, a.y - b.y); }
  function lerp(a, b, t) { return a + (b - a) * t; }
  function lerpPt(a, b, t) { return { x: lerp(a.x, b.x, t), y: lerp(a.y, b.y, t) }; }
  function hexA(hex, a) {
    var n = parseInt(hex.slice(1), 16);
    return 'rgba(' + ((n >> 16) & 255) + ',' + ((n >> 8) & 255) + ',' + (n & 255) + ',' + a + ')';
  }
  function polyLen(pts) {
    var d = 0;
    for (var i = 1; i < pts.length; i++) d += dist(pts[i - 1], pts[i]);
    return d;
  }
  function pointAt(pts, t) {
    if (!pts || !pts.length) return { x: 0, y: 0 };
    if (pts.length === 1) return pts[0];
    t = clamp(t);
    var target = t * polyLen(pts), acc = 0;
    for (var i = 1; i < pts.length; i++) {
      var d = dist(pts[i - 1], pts[i]);
      if (acc + d >= target || i === pts.length - 1) {
        return lerpPt(pts[i - 1], pts[i], d ? (target - acc) / d : 0);
      }
      acc += d;
    }
    return pts[pts.length - 1];
  }
  function slicePath(pts, t) {
    if (t <= 0) return [];
    if (t >= 1) return pts;
    var target = t * polyLen(pts), acc = 0, out = [pts[0]];
    for (var i = 1; i < pts.length; i++) {
      var d = dist(pts[i - 1], pts[i]);
      if (acc + d >= target) {
        out.push(lerpPt(pts[i - 1], pts[i], d ? (target - acc) / d : 0));
        return out;
      }
      out.push(pts[i]);
      acc += d;
    }
    return out;
  }
  function distPoly(p, pts) {
    var best = 1e9;
    for (var i = 1; i < pts.length; i++) {
      var a = pts[i - 1], b = pts[i];
      var dx = b.x - a.x, dy = b.y - a.y;
      var l2 = dx * dx + dy * dy;
      var t = l2 ? ((p.x - a.x) * dx + (p.y - a.y) * dy) / l2 : 0;
      t = clamp(t);
      var q = { x: a.x + dx * t, y: a.y + dy * t };
      best = Math.min(best, dist(p, q));
    }
    return best;
  }

  function armPoints(flex) {
    var e = ARM.elbow;
    var vx = ARM.wrist.x - e.x, vy = ARM.wrist.y - e.y;
    var a = flex * 0.9;
    var c = Math.cos(a), s = Math.sin(a);
    var wx = e.x + vx * c - vy * s;
    var wy = e.y + vx * s + vy * c;
    return { elbow: e, wrist: { x: wx, y: wy }, hand: { x: wx - 14 * c - 8 * s, y: wy - 14 * s + 8 * c } };
  }

  function legPoints(kick) {
    var k = LEG.knee;
    var a = -1.22 * kick;
    var c = Math.cos(a), s = Math.sin(a);
    var vx = 0, vy = 140;
    var ax = k.x + vx * c - vy * s;
    var ay = k.y + vx * s + vy * c;
    return { knee: k, ankle: { x: ax, y: ay }, foot: { x: ax + 42, y: ay + 14 } };
  }

  window.ReflexDraw = function (canvas) {
    var ctx = canvas.getContext('2d');
    var dpr = 1, cw = 0, ch = 0, scale = 1, ox = 0, oy = 0;

    function resize(w, h) {
      cw = Math.max(1, w); ch = Math.max(1, h);
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = Math.round(cw * dpr);
      canvas.height = Math.round(ch * dpr);
      // canvas 的 CSS 尺寸必须显式钉住，否则高分屏下会被内部像素尺寸撑大、画面被裁掉
      canvas.style.width = cw + 'px';
      canvas.style.height = ch + 'px';
    }

    function frameScene(state) {
      var box = state.scene === 'knee' ? LEG_FRAME : state.narrow && !state.labels ? ARM_MOBILE_FRAME : ARM_FRAME;
      var margin = state.narrow ? 12 : 28;
      scale = Math.max(.01, Math.min((cw - margin) / box.w, (ch - margin) / box.h));
      ox = (cw - box.w * scale) / 2 - box.x * scale;
      oy = (ch - box.h * scale) / 2 - box.y * scale;
    }

    function toScreen(p) { return { x: ox + p.x * scale, y: oy + p.y * scale }; }
    function toWorld(x, y) { return { x: (x - ox) / scale, y: (y - oy) / scale }; }

    function begin() {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      var radius = Math.min(Math.hypot(cw, ch) * .5, 520 * scale);
      var g = ctx.createRadialGradient(cw / 2, ch / 2, 0, cw / 2, ch / 2, radius);
      g.addColorStop(0, '#142033');
      g.addColorStop(.72, '#0b111c');
      g.addColorStop(1, COL.bg);
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, cw, ch);
      ctx.translate(ox, oy);
      ctx.scale(scale, scale);
    }

    function strokeLine(a, b, w, color) {
      ctx.save();
      ctx.strokeStyle = color; ctx.lineWidth = w; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
      ctx.restore();
    }
    function drawLimb(a, b, upper, lower) {
      var angle = Math.atan2(b.y - a.y, b.x - a.x);
      var length = dist(a, b);
      ctx.save();
      ctx.translate(a.x, a.y);
      ctx.rotate(angle);
      var g = ctx.createLinearGradient(0, -upper, 0, upper);
      g.addColorStop(0, '#526984');
      g.addColorStop(.46, '#344b64');
      g.addColorStop(1, '#1a2739');
      ctx.fillStyle = g;
      ctx.strokeStyle = COL.limbLine;
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(0, -upper);
      ctx.bezierCurveTo(length * .36, -upper * 1.03, length * .63, -lower, length, -lower);
      ctx.quadraticCurveTo(length + lower, 0, length, lower);
      ctx.bezierCurveTo(length * .63, lower, length * .36, upper, 0, upper);
      ctx.quadraticCurveTo(-upper, 0, 0, -upper);
      ctx.closePath(); ctx.fill(); ctx.stroke();
      ctx.restore();
    }

    function strokePath(pts) {
      if (!pts || pts.length < 2) return;
      ctx.beginPath();
      ctx.moveTo(pts[0].x, pts[0].y);
      for (var i = 1; i < pts.length; i++) ctx.lineTo(pts[i].x, pts[i].y);
      ctx.stroke();
    }
    function roundRect(x, y, w, h, r) {
      r = Math.min(r, w / 2, h / 2);
      ctx.beginPath();
      ctx.moveTo(x + r, y);
      ctx.arcTo(x + w, y, x + w, y + h, r);
      ctx.arcTo(x + w, y + h, x, y + h, r);
      ctx.arcTo(x, y + h, x, y, r);
      ctx.arcTo(x, y, x + w, y, r);
      ctx.closePath();
    }
    function circle(x, y, r, fill, stroke, lw) {
      ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2);
      if (fill) { ctx.fillStyle = fill; ctx.fill(); }
      if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = lw || 2; ctx.stroke(); }
    }
    function glowDot(x, y, r, color) {
      ctx.save();
      ctx.shadowColor = color; ctx.shadowBlur = 14;
      ctx.fillStyle = color;
      ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fill();
      ctx.restore();
      ctx.fillStyle = '#fff';
      ctx.beginPath(); ctx.arc(x, y, Math.max(1.6, r * 0.38), 0, Math.PI * 2); ctx.fill();
    }

    function drawTorso(bottom) {
      ctx.save();
      var g = ctx.createLinearGradient(442, 0, 558, 0);
      g.addColorStop(0, '#253a51'); g.addColorStop(.5, '#1e3046'); g.addColorStop(1, '#111c2b');
      ctx.fillStyle = g; ctx.strokeStyle = COL.torsoLine; ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(446, 206);
      ctx.quadraticCurveTo(452, 180, 500, 180);
      ctx.quadraticCurveTo(548, 180, 554, 206);
      ctx.lineTo(558, bottom - 34);
      ctx.quadraticCurveTo(548, bottom, 500, bottom);
      ctx.quadraticCurveTo(452, bottom, 442, bottom - 34);
      ctx.closePath();
      ctx.fill(); ctx.stroke();
      ctx.strokeStyle = 'rgba(100,120,155,.22)'; ctx.lineWidth = 1.4;
      ctx.beginPath(); ctx.moveTo(468, 252); ctx.quadraticCurveTo(500, 272, 532, 252); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(466, 344); ctx.quadraticCurveTo(500, 364, 534, 344); ctx.stroke();
      ctx.restore();
    }

    function drawHead() {
      ctx.save();
      ctx.fillStyle = COL.body; ctx.strokeStyle = COL.torsoLine; ctx.lineWidth = 2;
      roundRect(488, 166, 24, 28, 8); ctx.fill(); ctx.stroke();
      circle(500, 126, 54, COL.body, COL.torsoLine, 2);
      // 大脑轮廓与脑回
      ctx.beginPath();
      ctx.moveTo(473, 134);
      ctx.bezierCurveTo(458, 129, 467, 106, 479, 105);
      ctx.bezierCurveTo(485, 95, 501, 96, 507, 102);
      ctx.bezierCurveTo(527, 97, 540, 118, 532, 130);
      ctx.bezierCurveTo(529, 142, 514, 148, 502, 141);
      ctx.bezierCurveTo(491, 148, 475, 145, 473, 134);
      ctx.fillStyle = '#583449'; ctx.fill();
      ctx.strokeStyle = '#a37189'; ctx.lineWidth = 2; ctx.stroke();
      ctx.strokeStyle = 'rgba(217,143,168,.7)'; ctx.lineWidth = 2.2;
      ctx.beginPath(); ctx.moveTo(481, 120); ctx.bezierCurveTo(490, 108, 500, 132, 510, 116); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(486, 133); ctx.bezierCurveTo(497, 124, 505, 140, 518, 129); ctx.stroke();
      ctx.strokeStyle = '#6b4558'; ctx.lineWidth = 5;
      ctx.beginPath(); ctx.moveTo(500, 148); ctx.lineTo(500, 176); ctx.stroke();
      ctx.restore();
    }

    function drawSpine(y0, y1) {
      ctx.save();
      roundRect(486, y0, 28, y1 - y0, 14);
      ctx.fillStyle = COL.cord; ctx.fill();
      ctx.strokeStyle = COL.cordLine; ctx.lineWidth = 2; ctx.stroke();
      ctx.strokeStyle = COL.cordLine; ctx.lineWidth = 1;
      for (var y = y0 + 12; y < y1 - 6; y += 24) {
        ctx.beginPath(); ctx.moveTo(491, y); ctx.lineTo(509, y); ctx.stroke();
      }
      ctx.save();
      ctx.strokeStyle = hexA(COL.center, .72); ctx.lineWidth = 5; ctx.lineCap = 'round';
      ctx.setLineDash([9, 7]);
      ctx.beginPath(); ctx.moveTo(500, y0 + 12); ctx.lineTo(500, y1 - 12); ctx.stroke();
      ctx.restore();
      ctx.restore();
    }

    function drawHeat(now) {
      ctx.save();
      ctx.translate(ARM.heat.x, ARM.heat.y);
      roundRect(-17, 23, 34, 36, 5);
      ctx.fillStyle = '#29384c'; ctx.fill();
      ctx.strokeStyle = '#536d85'; ctx.lineWidth = 1.5; ctx.stroke();
      roundRect(-31, 55, 62, 9, 4); ctx.fill(); ctx.stroke();
      strokeLine({ x: 0, y: 15 }, { x: 0, y: 24 }, 5, '#a4aebc');
      var tip = -26 + 2 * Math.sin(now * 9);
      var g = ctx.createLinearGradient(0, 18, 0, tip);
      g.addColorStop(0, '#ee7a38'); g.addColorStop(.52, '#ffcf75'); g.addColorStop(1, '#ff8a43');
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.moveTo(0, tip);
      ctx.bezierCurveTo(8, -10, 18, 9, 4, 17);
      ctx.bezierCurveTo(-12, 23, -17, 7, -9, -5);
      ctx.quadraticCurveTo(-6, 3, 0, tip);
      ctx.fill();
      ctx.beginPath();
      ctx.moveTo(0, -2); ctx.quadraticCurveTo(11, 17, 0, 16);
      ctx.quadraticCurveTo(-8, 15, 0, -2);
      ctx.fillStyle = '#fff2bb'; ctx.fill();
      ctx.restore();
    }

    function drawArmLimbs(ap) {
      ctx.save();
      // 上臂
      drawLimb(ARM.shoulder, ARM.elbow, 28, 17);
      // 前臂
      drawLimb(ARM.elbow, ap.wrist, 18, 10);
      // 肩、肘
      ctx.save();
      ctx.translate(ARM.shoulder.x, ARM.shoulder.y); ctx.rotate(-0.42);
      ctx.beginPath(); ctx.ellipse(0, 0, 34, 25, 0, 0, Math.PI * 2);
      ctx.fillStyle = COL.body; ctx.fill();
      ctx.strokeStyle = COL.torsoLine; ctx.lineWidth = 2; ctx.stroke();
      ctx.restore();
      circle(ap.elbow.x, ap.elbow.y, 14, COL.limb, COL.limbLine, 1.6);
      // 高光
      ctx.strokeStyle = 'rgba(120,145,180,.22)'; ctx.lineWidth = 3; ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.moveTo(ARM.shoulder.x - 6, ARM.shoulder.y - 8);
      ctx.lineTo(ARM.elbow.x - 4, ARM.elbow.y - 8);
      ctx.stroke();
      // 手
      var ang = Math.atan2(ap.wrist.y - ap.elbow.y, ap.wrist.x - ap.elbow.x);
      ctx.translate(ap.hand.x, ap.hand.y); ctx.rotate(ang);
      ctx.fillStyle = COL.limb; ctx.strokeStyle = COL.limbLine; ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(-19, -9);
      ctx.quadraticCurveTo(-7, -16, 3, -11);
      ctx.lineTo(15, -13);
      ctx.quadraticCurveTo(21, -13, 20, -8);
      ctx.lineTo(10, -4);
      ctx.lineTo(28, -5);
      ctx.quadraticCurveTo(36, -4, 32, 1);
      ctx.lineTo(25, 4);
      ctx.quadraticCurveTo(28, 11, 16, 13);
      ctx.quadraticCurveTo(0, 17, -17, 8);
      ctx.closePath(); ctx.fill(); ctx.stroke();
      ctx.restore();
    }

    function drawBiceps(flex) {
      var a = Math.atan2(ARM.elbow.y - ARM.shoulder.y, ARM.elbow.x - ARM.shoulder.x);
      ctx.save();
      ctx.translate(ARM.biceps.x, ARM.biceps.y); ctx.rotate(a);
      var fiber = ctx.createLinearGradient(0, -17, 0, 19);
      fiber.addColorStop(0, flex > .12 ? '#ec8588' : '#a45e6d');
      fiber.addColorStop(1, flex > .12 ? '#8d3646' : '#4d273c');
      ctx.fillStyle = fiber;
      ctx.strokeStyle = COL.muscleLine; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.ellipse(0, 0, 38 - 8 * flex, 17 + 5 * flex, 0, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
      ctx.strokeStyle = 'rgba(255,190,190,.22)'; ctx.lineWidth = 1.4;
      for (var i = -1; i <= 1; i++) {
        ctx.beginPath(); ctx.moveTo(-26 + 6 * flex, i * 7); ctx.quadraticCurveTo(0, i * 10, 26 - 6 * flex, i * 7); ctx.stroke();
      }
      ctx.restore();
    }

    function drawNerve(pts, color, progress, opts) {
      if (!pts || pts.length < 2) return;
      opts = opts || {};
      var width = opts.width || 6;
      ctx.save();
      ctx.lineCap = 'round'; ctx.lineJoin = 'round';
      ctx.strokeStyle = hexA(color, .14); ctx.lineWidth = width + 7; strokePath(pts);
      ctx.strokeStyle = hexA(color, .45); ctx.lineWidth = width + 2; strokePath(pts);
      if (opts.dashed) ctx.setLineDash([6, 7]);
      ctx.strokeStyle = color; ctx.lineWidth = width; strokePath(pts);
      ctx.setLineDash([]);
      if (progress > 0) {
        var part = slicePath(pts, Math.min(progress, 1));
        ctx.strokeStyle = hexA(color, .26); ctx.lineWidth = width + 7; strokePath(part);
        ctx.strokeStyle = 'rgba(255,255,255,.5)'; ctx.lineWidth = 1.5; strokePath(part);
        var pt = pointAt(pts, Math.min(progress, 0.999));
        if (progress < 1) glowDot(pt.x, pt.y, 6, COL.impulse);
      }
      ctx.restore();
    }

    function drawBrainPath(progress) {
      var pts = [{ x: 500, y: 302 }, { x: 500, y: 205 }, { x: 500, y: 132 }];
      drawNerve(pts, COL.center, progress, { width: 4, dashed: true });
      if (progress > .85) {
        circle(500, 126, 40, hexA(COL.brain, .12), hexA(COL.brain, .68), 2);
        glowDot(500, 132, 6, COL.brain);
      }
    }

    function centerPulse(y0, y1, p) {
      if (p <= 0 || p >= 1) return;
      glowDot(500, y0 + (y1 - y0) * clamp(p), 5.5, COL.impulse);
    }

    function label(text, anchor, target, color, align) {
      var a = toScreen(anchor), b = toScreen(target);
      ctx.save();
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.strokeStyle = 'rgba(150,168,195,.32)'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
      ctx.fillStyle = 'rgba(5,7,13,.8)';
      ctx.beginPath(); ctx.arc(a.x, a.y, 3, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = hexA(color, .55); ctx.lineWidth = 1.2; ctx.stroke();
      if (!align || align === 'auto') align = target.x < anchor.x ? 'right' : 'left';
      ctx.font = '600 12px ' + FONT;
      ctx.textBaseline = 'middle';
      ctx.textAlign = align === 'right' ? 'right' : align === 'center' ? 'center' : 'left';
      ctx.fillStyle = 'rgba(5,7,13,.66)';
      var tw = ctx.measureText(text).width;
      var x0 = align === 'right' ? b.x - tw : align === 'center' ? b.x - tw / 2 : b.x;
      // 不让标签跑出画布
      if (x0 < 4) { b.x += 4 - x0; x0 = 4; }
      else if (x0 + tw > cw - 4) { b.x -= x0 + tw - (cw - 4); x0 = cw - 4 - tw; }
      b.y = Math.max(14, Math.min(ch - 14, b.y));
      ctx.fillRect(x0 - 3, b.y - 9, tw + 6, 18);
      ctx.fillStyle = color;
      ctx.fillText(text, b.x, b.y);
      ctx.restore();
    }

    function badge(n, p, color, active, now) {
      var s = toScreen(p);
      ctx.save();
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      if (active) {
        ctx.strokeStyle = hexA(color, .8); ctx.lineWidth = 2;
        var r = 15 + 2 * Math.sin(now * 5);
        ctx.beginPath(); ctx.arc(s.x, s.y, r, 0, Math.PI * 2); ctx.stroke();
        ctx.fillStyle = hexA(color, .14);
        ctx.beginPath(); ctx.arc(s.x, s.y, 14, 0, Math.PI * 2); ctx.fill();
      }
      ctx.fillStyle = '#0a111d'; ctx.strokeStyle = color; ctx.lineWidth = 1.6;
      ctx.beginPath(); ctx.arc(s.x, s.y, 11.5, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
      ctx.fillStyle = color;
      ctx.font = '700 12px ' + FONT;
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText(String(n), s.x, s.y + 0.5);
      ctx.restore();
    }

    function drawX(p, color, r) {
      ctx.save();
      ctx.strokeStyle = color; ctx.lineWidth = 3.5; ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.moveTo(p.x - r, p.y - r); ctx.lineTo(p.x + r, p.y + r);
      ctx.moveTo(p.x + r, p.y - r); ctx.lineTo(p.x - r, p.y + r);
      ctx.stroke();
      ctx.restore();
    }

    function blockedMark(part, ap) {
      var pos;
      if (part === 'receptor') pos = ap.hand;
      else if (part === 'center') pos = { x: 500, y: 311 };
      else if (part === 'effector') pos = ARM.biceps;
      else if (part === 'afferent') pos = pointAt(armAfferent(ap), .55);
      else pos = pointAt(armEfferent(), .55);
      ctx.save();
      ctx.strokeStyle = hexA(COL.danger, .8); ctx.lineWidth = 2; ctx.setLineDash([5, 4]);
      ctx.beginPath(); ctx.arc(pos.x, pos.y, 22, 0, Math.PI * 2); ctx.stroke();
      ctx.restore();
      drawX(pos, COL.danger, 9);
      label('受损', pos, { x: pos.x + 30, y: pos.y - 28 }, COL.danger, 'left');
    }

    function armAfferent(ap) {
      return [{ x: ap.hand.x - 7, y: ap.hand.y - 7 }, { x: ap.elbow.x - 12, y: ap.elbow.y - 10 }, { x: ARM.shoulder.x - 8, y: ARM.shoulder.y - 10 }, ARM.cordIn];
    }
    function armEfferent() {
      return [ARM.cordOut, { x: 486, y: 316 }, { x: 456, y: 300 }, { x: 426, y: 288 }, ARM.biceps];
    }

    function drawArmLabels(ap, state) {
      if (!state.labels) return;
      var aff = armAfferent(ap), eff = armEfferent();
      if (state.narrow) {
        label('感受器', ap.hand, { x: 104, y: 352 }, COL.receptor, 'right');
        label('传入', pointAt(aff, .42), { x: 286, y: 300 }, COL.afferent, 'right');
        label('中枢', { x: 500, y: 320 }, { x: 566, y: 320 }, COL.center, 'left');
        label('传出', pointAt(eff, .45), { x: 424, y: 402 }, COL.efferent, 'right');
        label('效应器', ARM.biceps, { x: 398, y: 224 }, COL.effector, 'center');
        if (state.brain) label('大脑', ARM.brain, { x: 618, y: 112 }, COL.brain, 'left');
        label('热源', ARM.heat, { x: 82, y: 516 }, COL.muted, 'right');
        return;
      }
      label('感受器', ap.hand, { x: 118, y: 356 }, COL.receptor, 'right');
      label('传入神经', pointAt(aff, .43), { x: 292, y: 286 }, COL.afferent, 'right');
      label('神经中枢', { x: 500, y: 320 }, { x: 606, y: 318 }, COL.center, 'left');
      label('传出神经', pointAt(eff, .45), { x: 420, y: 398 }, COL.efferent, 'right');
      label('效应器', ARM.biceps, { x: 398, y: 224 }, COL.effector, 'center');
      if (state.brain) label('大脑', ARM.brain, { x: 610, y: 112 }, COL.brain, 'left');
      label('热源', ARM.heat, { x: 92, y: 516 }, COL.muted, 'right');
    }

    function drawArm(state) {
      var sim = state.sim || R.simulate(state.scene, state.t, state.lesion);
      var flex = state.scene === 'damage' ? 0 : (sim.response ? clamp((sim.p.effector - 0.2) / 0.8) : 0);
      var ap = armPoints(flex);

      drawTorso(560);
      drawHead();
      drawSpine(190, 546);
      drawHeat(state.now);
      drawArmLimbs(ap);
      drawBiceps(flex);

      var aff = armAfferent(ap), eff = armEfferent();
      drawNerve(aff, COL.afferent, sim.p.afferent, { width: 5 });
      drawNerve(eff, COL.efferent, sim.p.efferent, { width: 5 });
      centerPulse(298, 330, sim.p.center);
      if (state.brain) drawBrainPath(sim.brainP);

      // 感受器 / 效应器
      if (state.lesion === 'receptor') {
        circle(ap.hand.x, ap.hand.y, 7, '#4a5568', COL.limbLine, 1.5);
      } else {
        glowDot(ap.hand.x, ap.hand.y, 6, COL.receptor);
      }
      if (state.lesion === 'effector') {
        circle(ARM.biceps.x, ARM.biceps.y, 7, '#4a5568', COL.limbLine, 1.5);
      } else {
        glowDot(ARM.biceps.x, ARM.biceps.y, 5, COL.effector);
      }

      if (sim.blockedAt) blockedMark(sim.blockedAt, ap);
      drawArmLabels(ap, state);

      // 刺激闪光
      if (state.scene !== 'damage' && state.t > 0 && state.t < 0.22) {
        var k = state.t / 0.22;
        ctx.save();
        ctx.strokeStyle = hexA(COL.receptor, 1 - k); ctx.lineWidth = 3;
        ctx.beginPath(); ctx.arc(ap.hand.x, ap.hand.y, 12 + 34 * k, 0, Math.PI * 2); ctx.stroke();
        ctx.restore();
      }
    }

    /* ---------------- 膝跳反射 ---------------- */

    function drawLegLabels(state) {
      if (!state.labels) return;
      if (state.narrow) {
        label('肌梭', LEG.receptor, { x: 652, y: 430 }, COL.receptor, 'left');
        label('股四头肌', LEG.quad, { x: 625, y: 463 }, COL.effector, 'left');
        label('传入', { x: 514, y: 430 }, { x: 392, y: 464 }, COL.afferent, 'right');
        label('传出', { x: 532, y: 414 }, { x: 392, y: 394 }, COL.efferent, 'right');
        label('中枢', { x: 500, y: 379 }, { x: 584, y: 332 }, COL.center, 'left');
        label('髌韧带', LEG.tendon, { x: 414, y: 584 }, COL.muted, 'right');
        return;
      }
      label('感受器（肌梭）', LEG.receptor, { x: 650, y: 416 }, COL.receptor, 'left');
      label('效应器（股四头肌）', LEG.quad, { x: 625, y: 452 }, COL.effector, 'left');
      label('传入神经', { x: 514, y: 430 }, { x: 372, y: 470 }, COL.afferent, 'right');
      label('传出神经', { x: 532, y: 414 }, { x: 372, y: 392 }, COL.efferent, 'right');
      label('神经中枢', { x: 500, y: 379 }, { x: 620, y: 332 }, COL.center, 'left');
      label('髌韧带', LEG.tendon, { x: 402, y: 590 }, COL.muted, 'right');
    }

    function drawHammer(tapK) {
      var rest = { x: 683, y: 485 }, hit = { x: 552, y: 503 };
      var head = lerpPt(rest, hit, tapK);
      var angle = lerp(-.5, .32, tapK);
      var pivot = { x: head.x + 78 * Math.cos(angle), y: head.y + 78 * Math.sin(angle) };
      ctx.save();
      strokeLine(pivot, head, 9, '#5b4a35');
      strokeLine(pivot, head, 5, '#8a6a45');
      ctx.translate(head.x, head.y);
      ctx.rotate(Math.atan2(head.y - pivot.y, head.x - pivot.x) + Math.PI / 2);
      roundRect(-7, -16, 14, 32, 5);
      ctx.fillStyle = '#c9d3e3'; ctx.fill();
      ctx.strokeStyle = '#eef3fb'; ctx.lineWidth = 1.2; ctx.stroke();
      ctx.restore();
      if (tapK > 0.55) {
        ctx.save();
        ctx.strokeStyle = hexA(COL.impulse, (1 - tapK) * 1.6); ctx.lineWidth = 3;
        ctx.beginPath(); ctx.arc(LEG.tendon.x, LEG.tendon.y, 12 + 26 * (tapK - 0.55), 0, Math.PI * 2); ctx.stroke();
        ctx.restore();
      }
    }

    function drawLeg(state) {
      var sim = state.sim || R.simulate(state.scene, state.t, state.lesion);
      var kick = sim.response ? clamp((sim.p.effector - 0.2) / 0.8) : 0;
      var lp = legPoints(kick);

      drawTorso(410);
      drawSpine(190, 400);

      // 大腿、小腿、脚
      drawLimb(LEG.hip, LEG.knee, 29, 17);
      drawLimb(LEG.knee, lp.ankle, 19, 9);
      drawLimb(lp.ankle, lp.foot, 12, 9);
      circle(LEG.hip.x, LEG.hip.y, 24, COL.body, COL.torsoLine, 2);
      circle(LEG.knee.x, LEG.knee.y, 15, COL.limb, COL.limbLine, 1.6);

      // 股四头肌
      var a = Math.atan2(LEG.knee.y - LEG.hip.y, LEG.knee.x - LEG.hip.x);
      ctx.save();
      ctx.translate(LEG.quad.x, LEG.quad.y); ctx.rotate(a);
      ctx.fillStyle = kick > 0.12 ? COL.muscleOn : COL.muscle;
      ctx.strokeStyle = COL.muscleLine; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.ellipse(0, 0, 40, 18 + 4 * kick, 0, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
      ctx.restore();

      // 髌韧带
      strokeLine({ x: 532, y: 494 }, LEG.tendon, 5, '#a8b7c9');

      // 传入 / 传出
      var aff = [LEG.receptor, { x: 520, y: 446 }, { x: 505, y: 416 }, LEG.cordIn];
      var eff = [LEG.cordOut, { x: 526, y: 414 }, LEG.quad];
      drawNerve(aff, COL.afferent, sim.p.afferent, { width: 5 });
      drawNerve(eff, COL.efferent, sim.p.efferent, { width: 5 });
      centerPulse(368, 390, sim.p.center);
      glowDot(LEG.receptor.x, LEG.receptor.y, 5, COL.receptor);
      glowDot(LEG.quad.x, LEG.quad.y, 4, COL.effector);

      drawHammer(Math.sin(Math.PI * clamp((state.t - 0.02) / 0.4)));
      drawLegLabels(state);

      if (kick > 0.15) {
        ctx.save();
        ctx.strokeStyle = hexA(COL.impulse, .5); ctx.lineWidth = 2;
        ctx.beginPath(); ctx.arc(LEG.knee.x, LEG.knee.y, 54, Math.PI / 2 - 1.22 * kick, Math.PI / 2); ctx.stroke();
        ctx.restore();
      }
    }

    /* ---------------- 练习 ---------------- */

    function drawQuiz(state) {
      var q = R.quiz[state.quiz.i] || R.quiz[0];
      drawTorso(560);
      drawHead();
      drawSpine(190, 546);
      var ap = armPoints(0);
      drawArmLimbs(ap);
      drawBiceps(0);
      var aff = armAfferent(ap), eff = armEfferent();
      drawNerve(aff, COL.afferent, 0, { width: 5 });
      drawNerve(eff, COL.efferent, 0, { width: 5 });
      if (state.brain) drawBrainPath(0);
      glowDot(ap.hand.x, ap.hand.y, 5, COL.receptor);
      glowDot(ARM.biceps.x, ARM.biceps.y, 4, COL.effector);

      var marks = {
        receptor: { p: ap.hand, n: 1, c: COL.receptor },
        afferent: { p: pointAt(aff, .42), n: 2, c: COL.afferent },
        center: { p: { x: 500, y: 300 }, n: 3, c: COL.center },
        efferent: { p: pointAt(eff, .45), n: 4, c: COL.efferent },
        effector: { p: ARM.biceps, n: 5, c: COL.effector }
      };
      var keys = ['receptor', 'afferent', 'center', 'efferent', 'effector'];
      keys.forEach(function (k) {
        var m = marks[k];
        badge(m.n, m.p, m.c, q.highlight === k, state.now);
      });
      if (q.highlight === 'brain') badge('脑', ARM.brain, COL.brain, true, state.now);
      if (q.lesion) {
        var pos = q.lesion === 'afferent' ? pointAt(aff, .55) : q.lesion === 'efferent' ? pointAt(eff, .55) : marks[q.lesion].p;
        ctx.save();
        ctx.strokeStyle = hexA(COL.danger, .8); ctx.lineWidth = 2; ctx.setLineDash([5, 4]);
        ctx.beginPath(); ctx.arc(pos.x, pos.y, 22, 0, Math.PI * 2); ctx.stroke();
        ctx.restore();
        drawX(pos, COL.danger, 9);
      }
      if (q.arrows) {
        // 传导方向题：在路径上画箭头
        [0.3, 0.7].forEach(function (t) {
          arrowAt(aff, t, COL.impulse);
        });
        [0.3, 0.7].forEach(function (t) {
          arrowAt(eff, t, COL.impulse);
        });
      }
    }

    function arrowAt(pts, t, color) {
      var p = pointAt(pts, t);
      var q = pointAt(pts, Math.min(1, t + 0.04));
      var a = Math.atan2(q.y - p.y, q.x - p.x);
      ctx.save();
      ctx.translate(p.x, p.y); ctx.rotate(a);
      ctx.fillStyle = color;
      ctx.beginPath(); ctx.moveTo(8, 0); ctx.lineTo(-5, -5); ctx.lineTo(-5, 5); ctx.closePath(); ctx.fill();
      ctx.restore();
    }

    /* ---------------- 对外 ---------------- */

    function draw(state) {
      frameScene(state);
      begin();
      if (state.scene === 'knee') drawLeg(state);
      else if (state.scene === 'quiz') drawQuiz(state);
      else drawArm(state);
      var key = state.hover || state.focus;
      if (key && state.scene !== 'quiz') {
        var sim = state.sim;
        var movement = sim.response ? clamp((sim.p.effector - .2) / .8) : 0;
        var knee = state.scene === 'knee';
        var ap = armPoints(knee ? 0 : movement);
        var marks = knee ? {
          receptor: LEG.receptor, afferent: { x: 511, y: 428 }, center: { x: 500, y: 376 },
          efferent: { x: 526, y: 414 }, effector: LEG.quad
        } : {
          receptor: ap.hand, afferent: pointAt(armAfferent(ap), .42), center: { x: 500, y: 312 },
          efferent: pointAt(armEfferent(), .45), effector: ARM.biceps
        };
        var mark = marks[key];
        circle(mark.x, mark.y, Math.max(12, 9 / scale), null, R.PARTS[key].color, 2 / scale);
      }
    }

    function partAt(px, py, state) {
      var p = toWorld(px, py);
      if (state.scene === 'knee') {
        var receptorDistance = dist(p, LEG.receptor), effectorDistance = dist(p, LEG.quad);
        if (Math.min(receptorDistance, effectorDistance) < 28) {
          return receptorDistance < effectorDistance ? 'receptor' : 'effector';
        }
        if (p.x > 470 && p.x < 530 && p.y > 200 && p.y < 400) return 'center';
        if (distPoly(p, [LEG.receptor, { x: 520, y: 446 }, { x: 505, y: 416 }, LEG.cordIn]) < 24) return 'afferent';
        if (distPoly(p, [LEG.cordOut, { x: 526, y: 414 }, LEG.quad]) < 24) return 'efferent';
        return null;
      }
      var sim = state.sim || {};
      var flex = state.scene === 'damage' ? 0 : (sim.response ? clamp((sim.p.effector - 0.2) / 0.8) : 0);
      var ap = armPoints(flex);
      if (dist(p, ap.hand) < 48) return 'receptor';
      if (dist(p, ARM.biceps) < 52) return 'effector';
      if (p.x > 470 && p.x < 530 && p.y > 200 && p.y < 540) return 'center';
      if (distPoly(p, armAfferent(ap)) < 24) return 'afferent';
      if (distPoly(p, armEfferent()) < 24) return 'efferent';
      return null;
    }

    return { resize: resize, draw: draw, partAt: partAt };
  };
})();
