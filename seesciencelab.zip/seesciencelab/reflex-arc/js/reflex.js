(function () {
  'use strict';

  // 反射弧五部分，顺序即神经冲动的传导方向
  var ORDER = ['receptor', 'afferent', 'center', 'efferent', 'effector'];

  var PARTS = {
    receptor: { key: 'receptor', name: '感受器', color: '#6fe3a0', role: '感受刺激，产生神经冲动', example: '皮肤中的痛觉感受器' },
    afferent: { key: 'afferent', name: '传入神经', color: '#58c8ff', role: '把神经冲动传到神经中枢', example: '手臂中的传入神经' },
    center: { key: 'center', name: '神经中枢', color: '#c9a7ff', role: '分析、综合冲动，发出新的冲动', example: '脊髓（缩手反射）' },
    efferent: { key: 'efferent', name: '传出神经', color: '#ffa15c', role: '把神经冲动传到效应器', example: '手臂中的传出神经' },
    effector: { key: 'effector', name: '效应器', color: '#ff6b6b', role: '接受冲动，作出反应', example: '手臂的屈肌' }
  };

  function clamp(v) { return v < 0 ? 0 : v > 1 ? 1 : v; }

  var SCENES = {
    withdraw: {
      key: 'withdraw', title: '缩手反射', kind: '非条件反射',
      stimulus: '手指碰到热源', response: '手缩回',
      brain: true, duration: 3.1, hold: 1.2,
      segments: [
        { part: 'afferent', start: 0.15, dur: 0.55 },
        { part: 'center', start: 0.70, dur: 0.20 },
        { part: 'efferent', start: 0.90, dur: 0.55 },
        { part: 'effector', start: 1.45, dur: 0.25 }
      ],
      brainStart: 1.62, brainDur: 0.55,
      note: '冲动沿反射弧传到手臂肌肉，手先缩回；上传到大脑的冲动稍晚到达，所以后感觉痛。'
    },
    knee: {
      key: 'knee', title: '膝跳反射', kind: '非条件反射',
      stimulus: '叩击髌韧带', response: '小腿前伸',
      brain: false, duration: 2.2, hold: 1.0,
      segments: [
        { part: 'afferent', start: 0.20, dur: 0.32 },
        { part: 'center', start: 0.52, dur: 0.16 },
        { part: 'efferent', start: 0.68, dur: 0.32 },
        { part: 'effector', start: 1.00, dur: 0.18 }
      ],
      brainStart: 0, brainDur: 1,
      note: '股四头肌被牵拉，肌梭产生冲动；中枢在脊髓，小腿很快前伸。'
    }
  };

  // 受损判断复用缩手反射的时序，只是把冲动停在受损部位
  SCENES.damage = {
    key: 'damage', title: '受损判断', kind: '反射弧分析',
    stimulus: '刺激手指', response: '手缩回',
    brain: true, duration: 2.35, hold: 0,
    segments: SCENES.withdraw.segments.slice(),
    brainStart: SCENES.withdraw.brainStart, brainDur: SCENES.withdraw.brainDur,
    note: '选择受损部位，看神经冲动能走到哪一步，再判断有没有感觉、有没有反应。'
  };

  function scene(key) { return SCENES[key] || SCENES.withdraw; }

  // 传入 t（秒）与受损部位，返回每一部分的传导进度
  function simulate(sceneKey, t, lesion) {
    var sc = scene(sceneKey);
    var p = { receptor: 0, afferent: 0, center: 0, efferent: 0, effector: 0 };
    var active = null, blockedAt = null;

    if (lesion === 'receptor') {
      blockedAt = 'receptor';
    } else {
      p.receptor = t > 0 ? 1 : 0;
      for (var i = 0; i < sc.segments.length; i++) {
        var seg = sc.segments[i];
        var k = clamp((t - seg.start) / seg.dur);
        if (lesion === seg.part) {
          // 停在受损部位之前，画面上能看到冲动被截断
          var stop = seg.part === 'center' ? 0.42 : 0.55;
          p[seg.part] = Math.min(k, stop);
          blockedAt = seg.part;
          if (k < stop) active = seg.part;
          break;
        }
        p[seg.part] = k;
        if (k < 1) { active = seg.part; break; }
      }
    }

    var brainP = 0;
    if (sc.brain && p.center >= 1) brainP = clamp((t - sc.brainStart) / sc.brainDur);
    var sensory = !!sc.brain && brainP > 0.85;
    var response = lesion !== 'effector' && p.effector > 0.22;
    var phase = 'rest';
    if (blockedAt) phase = 'blocked';
    else if (p.effector >= 1) phase = 'done';
    else if (active) phase = active;

    return {
      p: p, active: active, blockedAt: blockedAt, brainP: brainP,
      sensory: sensory, response: response, phase: phase,
      done: t >= sc.duration
    };
  }

  // 受损后“刺激感受器”的结果：感觉 / 反应
  var LESION = {
    receptor: { sensory: false, motor: false, why: '感受器不能产生神经冲动，传入神经收不到信号。' },
    afferent: { sensory: false, motor: false, why: '冲动传不到神经中枢，既不能产生感觉，也不能发出指令。' },
    center: { sensory: false, motor: false, why: '神经中枢不能分析、综合冲动，也不能把冲动传向效应器或大脑。' },
    efferent: { sensory: true, motor: false, why: '传入神经和中枢正常，冲动能上传到大脑产生感觉；但传不到效应器，不能作出反应。' },
    effector: { sensory: true, motor: false, why: '冲动能传到大脑产生感觉，但效应器（肌肉）不能收缩，不能作出反应。' }
  };

  function lesionEffect(key) {
    return LESION[key] || { sensory: true, motor: true, why: '反射弧完整，刺激后能完成反射。' };
  }

  function lesionTable() {
    return ORDER.map(function (k) {
      var e = LESION[k];
      return { key: k, name: PARTS[k].name, sensory: e.sensory, motor: e.motor, why: e.why };
    });
  }

  var QUIZ = [
    {
      q: '图中 ① 是反射弧的哪一部分？',
      options: ['感受器', '传入神经', '神经中枢', '效应器'],
      answer: 0, highlight: 'receptor',
      explain: '① 是感受器。它能感受刺激并产生神经冲动。'
    },
    {
      q: '图中 ② 是反射弧的哪一部分？',
      options: ['感受器', '传入神经', '传出神经', '效应器'],
      answer: 1, highlight: 'afferent',
      explain: '② 是传入神经。它把冲动从感受器传到神经中枢。'
    },
    {
      q: '图中 ③ 是反射弧的哪一部分？',
      options: ['传入神经', '神经中枢', '传出神经', '效应器'],
      answer: 1, highlight: 'center',
      explain: '③ 是神经中枢。缩手反射的神经中枢在脊髓。'
    },
    {
      q: '图中 ④ 是反射弧的哪一部分？',
      options: ['传入神经', '神经中枢', '传出神经', '效应器'],
      answer: 2, highlight: 'efferent',
      explain: '④ 是传出神经。它把神经中枢发出的冲动传到效应器。'
    },
    {
      q: '图中 ⑤ 是反射弧的哪一部分？',
      options: ['感受器', '传入神经', '传出神经', '效应器'],
      answer: 3, highlight: 'effector',
      explain: '⑤ 是效应器。它接受冲动并作出反应，例如肌肉收缩。'
    },
    {
      q: '神经冲动在反射弧中的传导方向是？',
      options: [
        '感受器 → 传入神经 → 神经中枢 → 传出神经 → 效应器',
        '感受器 → 传出神经 → 神经中枢 → 传入神经 → 效应器',
        '效应器 → 传出神经 → 神经中枢 → 传入神经 → 感受器',
        '神经中枢 → 感受器 → 传入神经 → 传出神经 → 效应器'
      ],
      answer: 0, highlight: null, arrows: true,
      explain: '冲动从感受器开始，经传入神经到神经中枢，再经传出神经到效应器，方向不能倒过来。'
    },
    {
      q: '传出神经受损，刺激感受器后会出现什么情况？',
      options: ['有感觉，有反应', '有感觉，无反应', '无感觉，有反应', '无感觉，无反应'],
      answer: 1, highlight: 'efferent', lesion: 'efferent',
      explain: '传入神经和神经中枢正常，冲动能上传到大脑产生感觉；传出神经断了，冲动到不了效应器，所以没有反应。'
    },
    {
      q: '传入神经受损，刺激感受器后会出现什么情况？',
      options: ['有感觉，有反应', '有感觉，无反应', '无感觉，有反应', '无感觉，无反应'],
      answer: 3, highlight: 'afferent', lesion: 'afferent',
      explain: '传入神经断了，冲动传不到神经中枢，既不能产生感觉，也不能发出指令，所以无感觉、无反应。'
    },
    {
      q: '缩手反射的神经中枢位于？',
      options: ['大脑皮层', '脊髓', '小脑', '脑干'],
      answer: 1, highlight: 'center',
      explain: '缩手反射的神经中枢在脊髓。脊髓先把指令发给手臂肌肉，同时把冲动上传到大脑。'
    },
    {
      q: '缩手反射为什么先缩手、后感觉痛？',
      options: [
        '缩手反射的路径短，痛觉传到大脑的路径长',
        '手臂肌肉先受到刺激，皮肤后受到刺激',
        '大脑的反应速度比脊髓慢，所以先缩手',
        '痛觉不需要经过神经中枢'
      ],
      answer: 0, highlight: 'brain',
      explain: '缩手反射的中枢在脊髓，冲动从手到脊髓再到手臂肌肉，路径短；痛觉要沿脊髓上传到大脑皮层，路径长，所以先缩手后感觉痛。'
    },
    {
      q: '效应器是指？',
      options: [
        '传出神经末梢和它所支配的肌肉或腺体',
        '感受刺激的皮肤',
        '神经中枢所在的脊髓',
        '传入神经末梢'
      ],
      answer: 0, highlight: 'effector',
      explain: '效应器是传出神经末梢及其支配的肌肉或腺体。肌肉收缩、腺体分泌，都是效应器作出的反应。'
    },
    {
      q: '关于反射弧，下列说法正确的是？',
      options: [
        '反射弧任一环节受损，反射都不能完成',
        '只要感受器完好，反射就能完成',
        '只要效应器完好，反射就能完成',
        '神经中枢受损时，效应器能自己作出反应'
      ],
      answer: 0, highlight: null,
      explain: '反射弧必须完整。感受器、传入神经、神经中枢、传出神经、效应器任何一部分受损，反射都不能完成。'
    }
  ];

  window.Reflex = {
    ORDER: ORDER,
    PARTS: PARTS,
    SCENES: SCENES,
    scene: scene,
    simulate: simulate,
    lesionEffect: lesionEffect,
    lesionTable: lesionTable,
    quiz: QUIZ,
    clamp: clamp
  };
})();
