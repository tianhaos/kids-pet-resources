(function () {
  'use strict';

  var R = window.Reflex;
  var $ = function (id) { return document.getElementById(id); };
  var qa = function (sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); };
  var mobile = window.matchMedia('(max-width: 760px)');
  var reduced = window.matchMedia('(prefers-reduced-motion: reduce)');

  var state = {
    scene: 'withdraw', play: !reduced.matches, loop: !reduced.matches, speed: 1,
    labels: true, brain: true,
    t: reduced.matches ? 2.3 : 0, lesion: null, focus: null, now: 0,
    narrow: mobile.matches, hover: null,
    sim: null,
    quiz: { i: 0, choice: null, answered: false, score: 0 }
  };

  var specimen = $('specimen'), canvas = $('reflex'), panel = $('panel');
  var view = window.ReflexDraw(canvas);
  var lastSig = '', lastProgress = '';
  var timeInput = $('time'), timeReadout = $('timeReadout');

  function fmtPart(k) { return R.PARTS[k] ? R.PARTS[k].name : '—'; }

  function zeroSim() {
    return {
      p: { receptor: 0, afferent: 0, center: 0, efferent: 0, effector: 0 },
      active: null, blockedAt: null, brainP: 0, sensory: false, response: false, phase: 'rest', done: false
    };
  }

  function computeSim() {
    state.sim = state.scene === 'quiz' ? zeroSim() : R.simulate(state.scene, state.t, state.lesion);
    return state.sim;
  }

  var pathButtons = R.ORDER.map(function (key) {
    var part = R.PARTS[key];
    var button = document.createElement('button');
    button.type = 'button';
    button.textContent = part.name;
    button.style.setProperty('--c', part.color);
    button.addEventListener('click', function () { selectPart(key); });
    $('pathway').appendChild(button);
    return button;
  });

  function selectPart(key) {
    state.focus = state.focus === key ? null : key;
    syncReadout(true);
    if (state.focus) Analytics.track('反射弧', '点击结构', fmtPart(state.focus));
  }

  function syncReadout(force) {
    var s = state.sim || computeSim();
    var sc = R.scene(state.scene);
    var quiz = state.scene === 'quiz';
    var sig = [state.scene, state.play, state.lesion, state.focus, s.done, s.sensory, s.response, state.quiz.i].join('|');
    var progress = R.ORDER.map(function (key) { return Math.round(s.p[key] * 100); });
    var progressSig = progress.join(',') + '|' + s.active;
    var statusChanged = force || sig !== lastSig;
    if (statusChanged || progressSig !== lastProgress) {
      lastProgress = progressSig;
      R.ORDER.forEach(function (key, i) {
        var button = pathButtons[i];
        button.style.setProperty('--p', progress[i] + '%');
        button.classList.toggle('reached', s.p[key] > 0);
        button.classList.toggle('active', s.p[key] > 0 && s.active === key);
        button.classList.toggle('blocked', s.blockedAt === key);
        if (statusChanged) {
          button.setAttribute('aria-pressed', state.focus === key);
          button.setAttribute('aria-label', R.PARTS[key].name + (s.blockedAt === key ? '（受损）' : ''));
        }
      });
    }
    if (!statusChanged) return;
    lastSig = sig;

    $('stageScene').textContent = quiz ? '判读练习 · 第 ' + (state.quiz.i + 1) + ' 题' : sc.title;
    $('motionState').textContent = s.response ? sc.response : s.done ? '无反应' : '等待反应';
    $('motionState').classList.toggle('on', s.response);
    $('senseState').textContent = s.sensory ? '感到痛' : s.done ? '无痛觉' : '等待痛觉';
    $('senseState').classList.toggle('on', s.sensory);
    $('senseState').hidden = !sc.brain;
    $('partDetail').hidden = !state.focus;
    if (state.focus) {
      var part = R.PARTS[state.focus];
      $('partDetail').textContent = part.name + ' · ' + part.role;
    }
    $('rStim').textContent = sc.stimulus;
    var effect = state.scene === 'damage' ? R.lesionEffect(state.lesion) : null;
    $('rSense').textContent = state.scene === 'knee' ? '本场景未演示'
      : (effect ? effect.sensory : s.sensory) ? '有（痛觉）' : effect || s.done ? '无' : '尚未出现';
    $('rReact').textContent = (effect ? effect.motor : s.response) ? sc.response : effect || s.done ? '无' : '尚未出现';
    $('rNote').textContent = effect ? effect.why : sc.note;

    $('playBtn').textContent = state.play ? '暂停' : '播放';
    $('stimBtn').textContent = state.scene === 'knee' ? '叩击髌韧带' : state.scene === 'damage' ? '演示传导' : '施加热刺激';
  }

  function syncStructure() {
    [['scene', state.scene], ['speed', String(state.speed)], ['lesion', state.lesion]].forEach(function (entry) {
      var key = entry[0], selected = entry[1];
      qa('button[data-' + key + ']').forEach(function (button) {
        var on = button.dataset[key] === selected;
        button.classList.toggle('on', on);
        button.setAttribute('aria-pressed', on);
      });
    });
    timeInput.max = R.scene(state.scene).duration;
    qa('#lesionTable tbody tr').forEach(function (tr) { tr.classList.toggle('on', tr.dataset.lesion === state.lesion); });

    $('lesionSec').hidden = state.scene !== 'damage';
    $('quizSec').hidden = state.scene !== 'quiz';
    $('opsSec').hidden = state.scene === 'quiz';
    $('readoutTitle').textContent = state.scene === 'damage' ? '刺激后的结果' : '实验观察';
    $('brainWrap').hidden = !(state.scene === 'withdraw' || state.scene === 'damage');
    $('loopWrap').hidden = state.scene === 'damage';

    var quiz = state.scene === 'quiz';
    ['pathway', 'outcomes', 'readout', 'timeline', 'playBtn', 'stimBtn', 'reference'].forEach(function (id) {
      $(id).hidden = quiz;
    });
    $('labels').checked = state.labels;
    $('brain').checked = state.brain;
    $('loop').checked = state.loop;
  }

  function sync(force) {
    computeSim();
    syncStructure();
    syncReadout(force !== false);
  }

  /* ---------------- 场景 ---------------- */

  function resetQuiz() {
    state.quiz = { i: 0, choice: null, answered: false, score: 0 };
    renderQuiz();
  }

  function setScene(key) {
    if (!R.SCENES[key] && key !== 'quiz') return;
    var wasQuiz = state.scene === 'quiz';
    state.scene = key;
    state.t = reduced.matches && key !== 'quiz' ? R.scene(key).duration : 0;
    state.focus = null;
    state.hover = null;
    state.play = key !== 'quiz' && !reduced.matches;
    if (key === 'damage') {
      if (!state.lesion) state.lesion = 'efferent';
    } else {
      state.lesion = null;
    }
    if (key === 'quiz' && !wasQuiz) resetQuiz();
    if (mobile.matches) showPanel(key === 'quiz' || key === 'damage');
    panel.scrollTop = 0;
    lastSig = '';
    sync();
    Analytics.track('反射弧', '场景', key === 'quiz' ? '判读练习' : R.SCENES[key].title);
  }

  function stimulate() {
    if (state.scene === 'quiz') return;
    state.t = 0;
    state.play = true;
    state.focus = null;
    lastSig = '';
    sync();
    var sc = R.scene(state.scene);
    Analytics.track('反射弧', '刺激', sc.title + (state.scene === 'damage' && state.lesion ? '/' + fmtPart(state.lesion) : ''));
  }

  function setLesion(key) {
    if (state.scene !== 'damage' || !R.PARTS[key]) return;
    state.lesion = key;
    state.t = 0;
    state.play = true;
    state.focus = null;
    lastSig = '';
    sync();
    Analytics.track('反射弧', '受损', fmtPart(key));
  }

  /* ---------------- 练习 ---------------- */

  function renderQuiz() {
    var q = R.quiz[state.quiz.i];
    $('quizQ').textContent = q.q;
    $('quizScore').textContent = '第 ' + (state.quiz.i + 1) + ' / ' + R.quiz.length + ' 题 · 答对 ' + state.quiz.score;
    $('quizNext').textContent = state.quiz.i === R.quiz.length - 1 ? '重新开始' : '下一题 →';
    $('quizNext').disabled = !state.quiz.answered;
    $('quizFb').textContent = state.quiz.answered ? q.explain : '';

    var box = $('quizOpts');
    box.innerHTML = q.options.map(function (o, i) {
      var cls = '';
      if (state.quiz.answered) {
        if (i === q.answer) cls = ' ok';
        else if (i === state.quiz.choice) cls = ' bad';
      }
      return '<button type="button" data-opt="' + i + '" class="opt' + cls + '">' + o + '</button>';
    }).join('');

    qa('#quizOpts [data-opt]').forEach(function (b) {
      b.addEventListener('click', function () { answer(+b.dataset.opt); });
    });
  }

  function answer(i) {
    if (state.quiz.answered) return;
    var q = R.quiz[state.quiz.i];
    state.quiz.choice = i;
    state.quiz.answered = true;
    if (i === q.answer) state.quiz.score++;
    renderQuiz();
    lastSig = '';
    syncReadout(true);
    Analytics.track('反射弧', '答题', q.q + ' → ' + (i === q.answer ? '对' : '错'));
  }

  function nextQuiz() {
    if (!state.quiz.answered) return;
    if (state.quiz.i >= R.quiz.length - 1) {
      state.quiz.i = 0;
      state.quiz.score = 0;
    } else {
      state.quiz.i++;
    }
    state.quiz.choice = null;
    state.quiz.answered = false;
    renderQuiz();
    lastSig = '';
    syncReadout(true);
  }

  /* ---------------- 事件 ---------------- */

  qa('[data-scene]').forEach(function (b) {
    b.addEventListener('click', function () { setScene(b.dataset.scene); });
  });
  $('stimBtn').addEventListener('click', stimulate);
  timeInput.addEventListener('input', function () {
    state.play = false;
    state.t = +timeInput.value;
    syncReadoutAtTime();
  });
  $('playBtn').addEventListener('click', togglePlayback);
  function togglePlayback() {
    if (state.scene === 'quiz') return;
    if (!state.play && state.t >= R.scene(state.scene).duration) state.t = 0;
    state.play = !state.play; lastSig = ''; sync();
  }
  qa('[data-speed]').forEach(function (b) {
    b.addEventListener('click', function () {
      state.speed = +b.dataset.speed; lastSig = ''; sync();
      Analytics.track('反射弧', '速度', state.speed + '×');
    });
  });
  $('labels').addEventListener('change', function () { state.labels = $('labels').checked; lastSig = ''; });
  $('brain').addEventListener('change', function () { state.brain = $('brain').checked; lastSig = ''; });
  $('loop').addEventListener('change', function () { state.loop = $('loop').checked; });
  qa('[data-lesion]').forEach(function (b) {
    b.addEventListener('click', function () { setLesion(b.dataset.lesion); });
  });
  $('quizNext').addEventListener('click', nextQuiz);

  function hit(e) {
    if (state.scene === 'quiz') return null;
    var rect = canvas.getBoundingClientRect();
    return view.partAt(e.clientX - rect.left, e.clientY - rect.top, state);
  }
  canvas.addEventListener('pointermove', function (e) {
    if (e.pointerType !== 'mouse') return;
    state.hover = hit(e);
    canvas.style.cursor = state.hover ? 'pointer' : '';
  });
  canvas.addEventListener('pointerleave', function () { state.hover = null; });
  canvas.addEventListener('click', function (e) {
    if (state.scene !== 'quiz') selectPart(hit(e));
  });

  document.addEventListener('keydown', function (e) {
    if (e.target && /^(INPUT|TEXTAREA|SELECT|BUTTON|A|SUMMARY)$/.test(e.target.tagName)) return;
    if (e.code === 'Space') {
      e.preventDefault();
      if (state.scene === 'quiz') { if (state.quiz.answered) nextQuiz(); return; }
      togglePlayback();
    } else if (e.key === 'Escape') {
      state.focus = null; lastSig = ''; syncReadout(true);
    } else if (e.key === 'r' || e.key === 'R') {
      state.t = 0; state.play = state.scene !== 'quiz'; state.focus = null; lastSig = ''; sync();
    }
  });

  function showPanel(open) {
    panel.classList.toggle('collapsed', !open);
    $('panelToggle').setAttribute('aria-expanded', open);
    $('panelToggle').textContent = open ? '收起面板' : state.scene === 'quiz' ? '显示题目' : state.scene === 'damage' ? '受损设置' : '实验设置';
  }
  $('panelToggle').addEventListener('click', function () {
    showPanel(panel.classList.contains('collapsed'));
  });
  mobile.addEventListener('change', function () {
    state.narrow = mobile.matches;
    if (!qs.has('labels')) state.labels = !state.narrow;
    showPanel(!state.narrow || state.scene === 'quiz' || state.scene === 'damage');
    sync();
  });

  /* ---------------- 受损表格 ---------------- */

  function buildLesionTable() {
    var rows = R.lesionTable();
    $('lesionTable').innerHTML = '<thead><tr><th>受损部位</th><th>感觉</th><th>反应</th></tr></thead><tbody>' +
      rows.map(function (r) {
        return '<tr data-lesion="' + r.key + '"><td>' + r.name + '</td>' +
          '<td class="' + (r.sensory ? 'yes' : 'no') + '">' + (r.sensory ? '有' : '无') + '</td>' +
          '<td class="' + (r.motor ? 'yes' : 'no') + '">' + (r.motor ? '有' : '无') + '</td></tr>';
      }).join('') + '</tbody>';
  }

  /* ---------------- 尺寸与主循环 ---------------- */

  function resize() { view.resize(specimen.clientWidth, specimen.clientHeight); }
  new ResizeObserver(resize).observe(specimen);
  resize();

  buildLesionTable();

  // ?scene=withdraw|knee|damage|quiz、&lesion=receptor|afferent|center|efferent|effector
  // &labels=0、&brain=0、&loop=0、&play=0、&speed=0.5|1|2、&t=0~3.1
  var qs = new URLSearchParams(location.search);
  if (['withdraw', 'knee', 'damage', 'quiz'].indexOf(qs.get('scene')) >= 0) state.scene = qs.get('scene');
  if (state.scene === 'damage' && R.PARTS[qs.get('lesion')]) state.lesion = qs.get('lesion');
  if (qs.get('labels') === '0') state.labels = false;
  else if (qs.get('labels') === '1') state.labels = true;
  else if (state.narrow) state.labels = false;
  if (qs.get('brain') === '0') state.brain = false;
  if (qs.has('loop')) state.loop = qs.get('loop') !== '0';
  if (qs.get('play') === '1') { state.play = true; state.t = 0; }
  if (qs.get('speed')) {
    var sp = +qs.get('speed');
    if (sp === 0.5 || sp === 1 || sp === 2) state.speed = sp;
  }
  if (state.scene === 'quiz') { state.play = false; resetQuiz(); }
  else if (state.scene === 'damage' && !state.lesion) state.lesion = 'efferent';
  if (qs.get('play') === '0') { state.play = false; state.t = 0; }
  else if (reduced.matches && !state.play) state.t = R.scene(state.scene).duration;
  if (qs.get('t')) {
    var tt = parseFloat(qs.get('t'));
    if (isFinite(tt)) {
      state.t = Math.max(0, Math.min(R.scene(state.scene).duration, tt));
      state.play = false;
    }
  }
  if (mobile.matches) showPanel(state.scene === 'quiz' || state.scene === 'damage');
  syncStructure();
  syncReadoutAtTime();

  function syncReadoutAtTime() {
    computeSim();
    syncReadout(false);
    if (state.scene === 'quiz') return;
    var value = state.t.toFixed(2);
    if (+timeInput.value !== +value) timeInput.value = value;
    var label = value + ' / ' + Number(timeInput.max).toFixed(2) + ' s';
    if (timeReadout.textContent !== label) timeReadout.textContent = label;
  }

  var last = performance.now();
  function frame(t) {
    var dt = Math.min((t - last) / 1000, 0.05);
    last = t;
    if (!reduced.matches) state.now += dt;
    if (state.play && state.scene !== 'quiz') {
      state.t += dt * state.speed;
      var sc = R.scene(state.scene);
      if (state.t >= sc.duration) {
        if (state.loop && state.scene !== 'damage') {
          state.t = 0;
        } else {
          state.t = sc.duration;
          state.play = false;
        }
      }
    }
    syncReadoutAtTime();
    view.draw(state);
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // 调试用：__model.setScene('damage')、__model.setLesion('efferent')、__model.stimulate()
  window.__model = {
    state: state, view: view,
    setScene: setScene, stimulate: stimulate, setLesion: setLesion,
    answer: answer, nextQuiz: nextQuiz, resetQuiz: resetQuiz
  };
})();
