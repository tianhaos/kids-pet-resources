// 首页搜索框未输入时提示的热门模型：按最近访问统计定期更新
// 写模型目录名，顺序即展示顺序；找不到对应卡片的目录名会被跳过
// 首页和各模型页都引用本文件（顶栏搜索也用），改完记得递增各页 hot.js?v= 的版本号
window.HOT_MODELS = [
    'contour-map',
    'convex-lens',
    'earth-sun',
    'global-circulation',
    'eye-vision',
    'refraction',
    'lens-uses',
    'concave-lens',
    'microscope',
    'blood-circulation',
    'sun-altitude',
    'atom-structure',
    'lat-long',
    'terminator-map',
    'cell-structure',
    'plane-mirror',
    'series-parallel-circuit',
    'climate-chart',
    'dna-structure',
    'heat-engine',
    'melting',
    'moon-phase',
    'sound-wave'
];
