// 半长轴取 JPL J2000 近似值，恒星公转周期以儒略年（365.25 天）为单位。
(function () {
  const YEAR = 365.25;
  const TAU = 2 * Math.PI;
  const planets = [
    { id: 'mercury', name: '水星', kind: '类地行星', au: 0.387, period: 0.2408467, diameter: 4879, color: '#c3b8ad', size: 0.16, phase: 2.9 },
    { id: 'venus', name: '金星', kind: '类地行星', au: 0.723, period: 0.61519726, diameter: 12104, color: '#efc485', size: 0.24, phase: 1.35 },
    { id: 'earth', name: '地球', kind: '类地行星', au: 1, period: 1.0000174, diameter: 12742, color: '#74c9ff', size: 0.25, phase: 5.6 },
    { id: 'mars', name: '火星', kind: '类地行星', au: 1.524, period: 1.8808476, diameter: 6779, color: '#f28e6f', size: 0.20, phase: 3.9 },
    { id: 'jupiter', name: '木星', kind: '气态巨行星', au: 5.203, period: 11.862615, diameter: 139822, color: '#f5c8a4', size: 0.58, phase: 0.88 },
    { id: 'saturn', name: '土星', kind: '气态巨行星', au: 9.537, period: 29.447498, diameter: 116464, color: '#e3cb92', size: 0.48, phase: 4.75 },
    { id: 'uranus', name: '天王星', kind: '冰巨行星', au: 19.189, period: 84.016846, diameter: 50724, color: '#a8e4e1', size: 0.37, phase: 2.55 },
    { id: 'neptune', name: '海王星', kind: '冰巨行星', au: 30.070, period: 164.79132, diameter: 49244, color: '#85aeff', size: 0.36, phase: 0.19 },
  ];
  const earth = planets[2];
  const maxPeriod = planets[7].period;

  function radius(planet, scene, other) {
    if (scene === 'compare') {
      const inner = planet === earth ? other.au > earth.au : planet.au < earth.au;
      return inner ? 4.1 : 8.35;
    }
    if (scene === 'scale') return 10 * planet.au / planets[7].au;
    return 10 * Math.log1p(planet.au / 0.22) / Math.log1p(planets[7].au / 0.22);
  }

  function turns(planet, years) {
    return years / planet.period;
  }

  function lapFraction(count) {
    const fraction = count % 1;
    return count >= 1 && fraction < 1e-10 ? 1 : fraction;
  }

  function angle(planet, years, scene) {
    const start = scene === 'compare' ? -0.38 : planet.phase;
    return start + TAU * (turns(planet, years) % 1);
  }

  function course(planet, years, scene, other) {
    const a = angle(planet, years, scene);
    const r = radius(planet, scene, other);
    return { x: r * Math.cos(a), z: -r * Math.sin(a) };
  }

  function limit(scene, other) {
    return scene === 'compare' ? Math.max(earth.period, other.period) : maxPeriod;
  }

  window.SolarOrbits = { YEAR, TAU, planets, earth, maxPeriod, radius, turns, lapFraction, angle, course, limit };
})();
