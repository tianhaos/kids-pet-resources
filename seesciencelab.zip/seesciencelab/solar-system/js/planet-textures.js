// 教学用程序纹理，给球体保留可辨认的色带、云层和岩石表面。
(function () {
  const palettes = {
    mercury: [[82, 76, 74], [148, 139, 130], [206, 195, 182]],
    venus: [[137, 88, 49], [214, 165, 99], [250, 224, 165]],
    mars: [[99, 46, 37], [184, 88, 57], [230, 159, 109]],
    jupiter: [[135, 77, 53], [211, 160, 121], [252, 222, 177]],
    saturn: [[151, 117, 74], [219, 186, 133], [246, 225, 171]],
    uranus: [[70, 145, 164], [136, 201, 203], [198, 237, 224]],
    neptune: [[51, 78, 149], [102, 146, 219], [153, 190, 238]],
    sun: [[192, 53, 10], [255, 151, 41], [255, 230, 121]],
  };
  const clamp = value => Math.max(0, Math.min(1, value));
  const mix = (a, b, t) => a + (b - a) * t;

  function canvasTexture(id) {
    if (id === 'earth') return window.makeEarthCanvas();
    const canvas = document.createElement('canvas');
    canvas.width = 384;
    canvas.height = 192;
    const ctx = canvas.getContext('2d');
    const image = ctx.createImageData(canvas.width, canvas.height);
    const palette = palettes[id];
    const gas = ['jupiter', 'saturn', 'uranus', 'neptune'].includes(id);
    for (let y = 0; y < canvas.height; y++) {
      const v = y / canvas.height;
      for (let x = 0; x < canvas.width; x++) {
        const u = x / canvas.width * Math.PI * 2;
        const wrinkle = Math.sin(u * 3 + v * 53) + 0.43 * Math.sin(u * 9 - v * 77);
        const flecks = 0.13 * Math.sin(u * 29 + v * 224) * Math.sin(u * 17 - v * 167);
        const rock = Math.sin(u * 4 + v * 38) * Math.cos(u * 5 - v * 46) +
          0.4 * Math.sin(u * 11 + v * 118);
        let intensity = 0.54 + 0.21 * rock + flecks;
        if (id === 'sun') intensity = 0.66 + 0.17 * rock + flecks * 1.6;
        if (id === 'venus') intensity = 0.60 + 0.13 * Math.sin(v * 35 + wrinkle) + flecks * 0.30;
        if (gas) {
          const mainBand = Math.sin(v * 54 + 1.4 * Math.sin(v * 19) + wrinkle * 0.22);
          intensity = 0.53 + (id === 'jupiter' ? 0.29 : 0.13) * mainBand +
            0.07 * Math.sin(v * 106 + wrinkle * 0.42) + flecks * 0.30;
        }
        const i = (y * canvas.width + x) * 4;
        const t = clamp(intensity) * 2;
        const lo = Math.floor(Math.min(t, 1));
        for (let k = 0; k < 3; k++) image.data[i + k] = mix(palette[lo][k], palette[lo + 1][k], t - lo);
        image.data[i + 3] = 255;
      }
    }
    ctx.putImageData(image, 0, 0);
    if (id === 'mercury') {
      for (let i = 0; i < 42; i++) {
        const x = (i * 137.508) % 375 + 4;
        const y = (i * 53.867) % 181 + 4;
        const r = 2 + i % 6;
        ctx.beginPath();
        ctx.ellipse(x, y, r * 1.3, r, 0.3, 0, Math.PI * 2);
        ctx.fillStyle = '#4b403856';
        ctx.fill();
        ctx.lineWidth = 0.65;
        ctx.strokeStyle = '#d9c8b270';
        ctx.stroke();
      }
    }
    if (id === 'jupiter') {
      ctx.save();
      ctx.translate(150, 115);
      ctx.scale(1, 0.44);
      const storm = ctx.createRadialGradient(0, 0, 2, 0, 0, 28);
      storm.addColorStop(0, '#b65335');
      storm.addColorStop(0.52, '#ba6b4d');
      storm.addColorStop(0.80, '#eed9b3bb');
      storm.addColorStop(1, '#eed9b300');
      ctx.fillStyle = storm;
      ctx.fillRect(-28, -28, 56, 56);
      ctx.restore();
    }
    return canvas;
  }

  function glowTexture() {
    const canvas = document.createElement('canvas');
    canvas.width = canvas.height = 160;
    const ctx = canvas.getContext('2d');
    const gradient = ctx.createRadialGradient(80, 80, 9, 80, 80, 80);
    gradient.addColorStop(0, '#ffce86e6');
    gradient.addColorStop(0.19, '#ffb95caa');
    gradient.addColorStop(0.36, '#fc964847');
    gradient.addColorStop(0.65, '#e8793420');
    gradient.addColorStop(1, '#e8793400');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, 160, 160);
    return canvas;
  }

  window.SolarTextures = { canvasTexture, glowTexture };
})();
