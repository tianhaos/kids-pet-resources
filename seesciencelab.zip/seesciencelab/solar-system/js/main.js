(function () {
  const O = window.SolarOrbits;
  const $ = id => document.getElementById(id);
  const scenes = {
    orbit: { title: '太阳系八大行星', note: '轨道间距经过压缩，便于同时看清八颗行星。' },
    scale: { title: '太阳系到底有多空旷？', note: '轨道半径按同一比例绘制。放大内侧，看水星到火星。' },
    compare: { title: '同一段时间，各转了几圈？', note: '从同一方向起跑，按真实周期的比例公转。彩线表示当前这圈走过的弧。' },
  };
  const query = new URLSearchParams(location.search);
  const byId = id => O.planets.find(p => p.id === id);
  const sceneKey = Object.hasOwn(scenes, query.get('scene')) ? query.get('scene') : 'orbit';
  const fromQuery = byId(query.get('planet'));
  const reduced = matchMedia('(prefers-reduced-motion: reduce)');
  const state = {
    scene: sceneKey,
    selected: fromQuery || byId('saturn'),
    other: fromQuery && fromQuery !== O.earth ? fromQuery : O.planets[0],
    years: 0,
    running: sceneKey === 'orbit' && !reduced.matches && !query.has('year') && query.get('play') !== '0',
    speed: 1,
    labels: true,
  };
  if (sceneKey === 'compare') state.selected = fromQuery || state.other;
  const limit = () => O.limit(state.scene, state.other);
  const initYear = Number(query.get('year'));
  if (Number.isFinite(initYear)) state.years = Math.max(0, Math.min(limit(), initYear));

  function track(action, value) {
    window.Analytics?.track('太阳系八大行星', action, value);
  }

  let graphics;
  try {
    graphics = window.SolarScene.create($('space'), choosePlanet);
  } catch (error) {
    $('space').querySelector('.orbit-canvas')?.remove();
    $('webglFallback').hidden = false;
    document.querySelector('.view-tools').hidden = true;
  }
  if (query.get('view') === 'top' || (query.get('view') === 'inner' && state.scene === 'scale')) {
    graphics?.view(query.get('view'));
  }

  const sceneButtons = document.querySelectorAll('[data-scene]');
  const timeline = $('timeline');
  const planetButtons = new Map();
  const format = new Intl.NumberFormat('zh-CN', { maximumFractionDigits: 3 });
  const periodText = p => p.period < 2 ? format.format(Math.round(p.period * O.YEAR * 10) / 10) + ' 天' :
    format.format(Math.round(p.period * 100) / 100) + ' 年';
  const auText = p => format.format(p.au) + ' AU';

  for (const planet of O.planets) {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'planet-button';
    b.style.setProperty('--planet', planet.color);
    b.textContent = planet.name;
    b.addEventListener('click', () => choosePlanet(planet.id));
    $('planets').append(b);
    planetButtons.set(planet, b);
    if (planet !== O.earth) $('comparePlanet').add(new Option(planet.name, planet.id));
  }
  function choosePlanet(id) {
    const planet = byId(id);
    if (!planet) return;
    if (state.scene === 'compare' && planet !== O.earth && planet !== state.other) {
      state.other = planet;
      seek(0);
    }
    state.selected = planet;
    syncControls();
    track('选择行星', id);
  }

  function syncControls() {
    const { title, note } = scenes[state.scene];
    const compare = state.scene === 'compare';
    const scale = state.scene === 'scale';
    $('sceneTitle').textContent = title;
    $('guide').textContent = note;
    $('compareTools').hidden = !compare;
    $('innerView').hidden = !scale || !graphics;
    $('compareRaces').hidden = !compare;
    $('compareMoves').hidden = !compare;
    $('comparePlanet').value = state.other.id;
    $('displayNote').textContent = compare ? '两条轨道的间距为示意' : scale ? '轨道等比例 · 球体大小已放大' : '圆轨道示意 · 球体大小已放大';
    for (const button of sceneButtons) {
      const on = button.dataset.scene === state.scene;
      button.classList.toggle('on', on);
      button.setAttribute('aria-pressed', String(on));
    }
    for (const [planet, button] of planetButtons) button.setAttribute('aria-pressed', String(planet === state.selected));
    const planet = state.selected;
    $('planetName').textContent = planet.name;
    $('planetName').style.color = planet.color;
    $('planetType').textContent = planet.kind;
    $('planetDistance').textContent = auText(planet);
    $('planetPeriod').textContent = periodText(planet);
    $('planetDiameter').textContent = format.format(planet.diameter) + ' 千米';
    $('compName').textContent = state.other.name;
    $('compRow').style.setProperty('--race', state.other.color);
    $('compPeriod').textContent = periodText(state.other);
    $('oneOther').textContent = '到' + state.other.name + '一圈';
    syncTime();
  }

  function syncTime() {
    const days = state.years * O.YEAR;
    const text = state.years < 2 ? days.toFixed(1) + ' 天' : state.years.toFixed(2) + ' 年';
    $('elapsed').textContent = text;
    timeline.value = Math.round(state.years / limit() * 10000);
    timeline.setAttribute('aria-valuetext', text);
    $('play').textContent = state.running ? '暂停' : state.years >= limit() ? '重播' : '播放';
    if (state.scene === 'compare') {
      for (const [id, p] of [['earth', O.earth], ['comp', state.other]]) {
        const turns = O.turns(p, state.years);
        $(id + 'Turns').textContent = turns.toFixed(turns > 0 && turns < 0.1 ? 3 : 2) + ' 圈';
        $(id + 'Progress').style.transform = 'scaleX(' + O.lapFraction(turns) + ')';
      }
    }
  }

  function seek(value) {
    state.years = Math.max(0, Math.min(limit(), value));
    state.running = false;
    syncTime();
  }

  function setScene(key) {
    if (!Object.hasOwn(scenes, key) || key === state.scene) return;
    state.scene = key;
    if (key === 'compare') {
      state.selected = state.other;
      seek(0);
    }
    graphics?.view();
    syncControls();
    track('切换场景', key);
  }
  sceneButtons.forEach(button => button.addEventListener('click', () => setScene(button.dataset.scene)));
  $('comparePlanet').addEventListener('change', event => choosePlanet(event.target.value));
  $('play').addEventListener('click', () => {
    if (!state.running && state.years >= limit()) state.years = 0;
    state.running = !state.running;
    syncTime();
    track(state.running ? '播放' : '暂停', state.scene);
  });
  $('zero').addEventListener('click', () => seek(0));
  timeline.addEventListener('input', () => seek(Number(timeline.value) / 10000 * limit()));
  timeline.addEventListener('change', () => track('拖动时间轴', state.scene));
  $('oneEarth').addEventListener('click', () => { seek(O.earth.period); track('地球一圈', state.other.id); });
  $('oneOther').addEventListener('click', () => { seek(state.other.period); track('对照行星一圈', state.other.id); });
  $('speed').addEventListener('change', event => { state.speed = Number(event.target.value); });
  $('labels').addEventListener('change', event => { state.labels = event.target.checked; });
  $('resetView').addEventListener('click', () => graphics?.view());
  $('topView').addEventListener('click', () => graphics?.view('top'));
  $('innerView').addEventListener('click', () => { graphics?.view('inner'); track('放大内行星', state.scene); });

  const panel = $('panel');
  const panelToggle = $('panelToggle');
  const mobile = matchMedia('(max-width: 760px)');
  function drawer(open) {
    panel.classList.toggle('collapsed', !open);
    panel.inert = mobile.matches && !open;
    panelToggle.setAttribute('aria-expanded', String(open));
    panelToggle.textContent = open ? '收起设置' : '行星与设置';
  }
  drawer(!mobile.matches);
  mobile.addEventListener('change', () => drawer(!mobile.matches));
  panelToggle.addEventListener('click', () => drawer(panel.classList.contains('collapsed')));
  reduced.addEventListener('change', event => {
    if (event.matches) {
      state.running = false;
      syncTime();
    }
  });

  let last;
  function frame(now) {
    const dt = Math.min(0.10, (now - (last ?? now)) / 1000);
    last = now;
    if (state.running) {
      const rate = state.scene === 'compare' ? Math.min(limit() / 12, 0.75) : 0.48;
      state.years = Math.min(limit(), state.years + dt * rate * state.speed);
      if (state.years >= limit()) state.running = false;
      syncTime();
    }
    graphics?.render(state);
    requestAnimationFrame(frame);
  }
  syncControls();
  window.__model = { state, setScene, choosePlanet, seek, graphics };
  requestAnimationFrame(frame);
})();
