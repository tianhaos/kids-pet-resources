(function () {
  const T = window.THREE;
  const O = window.SolarOrbits;
  const textures = window.SolarTextures;
  const startView = new T.Vector3(0, 12.1, 14.2);
  const orbitSteps = 256;

  function texture(canvas) {
    const map = new T.CanvasTexture(canvas);
    map.encoding = T.sRGBEncoding;
    return map;
  }

  function starfield(canvas, width, height) {
    const ratio = Math.min(devicePixelRatio, 2);
    canvas.width = width * ratio;
    canvas.height = height * ratio;
    const ctx = canvas.getContext('2d');
    ctx.scale(ratio, ratio);
    let seed = 48331;
    const random = () => {
      seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
      return seed / 4294967296;
    };
    const colors = ['#dcedff', '#a5c6f0', '#fff1d0'];
    for (let i = 0; i < width * height / 2400; i++) {
      const x = random() * width;
      const y = random() * height;
      const light = random();
      const radius = 0.26 + light ** 6 * 1.06;
      ctx.globalAlpha = 0.10 + light * 0.48;
      ctx.fillStyle = colors[i % colors.length];
      ctx.beginPath();
      ctx.arc(x, y, radius, 0, O.TAU);
      ctx.fill();
    }
  }

  function makeOrbit() {
    const points = [];
    for (let i = 0; i < orbitSteps; i++) {
      const a = O.TAU * i / orbitSteps;
      points.push(new T.Vector3(Math.cos(a), 0, -Math.sin(a)));
    }
    return new T.LineLoop(
      new T.BufferGeometry().setFromPoints(points),
      new T.LineBasicMaterial({ color: '#577294', transparent: true, opacity: 0.51 }),
    );
  }

  function makeArc(color) {
    const g = new T.BufferGeometry();
    g.setAttribute('position', new T.BufferAttribute(new Float32Array((orbitSteps + 1) * 3), 3).setUsage(T.DynamicDrawUsage));
    const line = new T.Line(g, new T.LineBasicMaterial({ color, transparent: true, opacity: 0.92 }));
    line.frustumCulled = false;
    return line;
  }

  function updateArc(arc, radius, turns) {
    const fraction = O.lapFraction(turns);
    const count = Math.ceil(fraction * orbitSteps);
    const attr = arc.geometry.attributes.position;
    for (let i = 0; i <= count; i++) {
      const a = -0.38 + O.TAU * Math.min(fraction, i / orbitSteps);
      attr.setXYZ(i, radius * Math.cos(a), 0, -radius * Math.sin(a));
    }
    arc.geometry.setDrawRange(0, count + 1);
    attr.needsUpdate = true;
  }

  function planetMesh(planet, sphere) {
    const mesh = new T.Mesh(sphere, new T.MeshStandardMaterial({
      map: texture(textures.canvasTexture(planet.id)), roughness: 0.96,
    }));
    mesh.rotation.y = planet.id === 'earth' ? 2.4 : 1.1;
    const body = new T.Group();
    body.add(mesh);
    if (planet.id === 'saturn') {
      const rings = new T.Group();
      rings.rotation.set(-Math.PI / 2, 0.18, -0.22);
      for (const [inner, outer, color, opacity] of [
        [1.24, 1.44, '#a48d63', 0.58], [1.44, 1.78, '#dfc796', 0.86],
        [1.8, 1.92, '#99866a', 0.64], [1.95, 2.29, '#d4be92', 0.78],
      ]) {
        rings.add(new T.Mesh(new T.RingGeometry(inner, outer, 80),
          new T.MeshBasicMaterial({ color, side: T.DoubleSide, transparent: true, opacity })));
      }
      body.add(rings);
    }
    return body;
  }

  function create(host, onPick) {
    const sky = host.querySelector('.stars');
    const labelLayer = host.querySelector('.space-labels');
    const scene = new T.Scene();
    const camera = new T.OrthographicCamera(-11, 11, 11, -11, 0.05, 100);
    const renderer = new T.WebGLRenderer({ alpha: true, antialias: true });
    renderer.outputEncoding = T.sRGBEncoding;
    renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
    renderer.domElement.className = 'orbit-canvas';
    renderer.domElement.setAttribute('aria-hidden', 'true');
    host.insertBefore(renderer.domElement, labelLayer);
    const controls = new T.OrbitControls(camera, renderer.domElement);
    controls.enablePan = false;
    controls.enableDamping = true;
    controls.dampingFactor = 0.16;
    controls.rotateSpeed = 0.67;
    controls.minPolarAngle = 0.015;
    controls.maxPolarAngle = Math.PI - 0.04;
    controls.minZoom = 0.65;
    controls.maxZoom = 32;

    scene.add(new T.AmbientLight('#c3d5ff', 0.87));
    const solarLight = new T.PointLight('#fff3db', 2.15, 0, 0);
    scene.add(solarLight);
    const sphere = new T.SphereGeometry(1, 40, 28);
    const sun = new T.Mesh(sphere, new T.MeshBasicMaterial({ map: texture(textures.canvasTexture('sun')) }));
    const glow = new T.Sprite(new T.SpriteMaterial({
      map: texture(textures.glowTexture()), transparent: true, depthWrite: false,
      blending: T.AdditiveBlending,
    }));
    scene.add(sun, glow);
    function label(name) {
      const element = document.createElement('span');
      element.textContent = name;
      element.hidden = true;
      labelLayer.append(element);
      return element;
    }
    const sunLabel = label('太阳');
    sunLabel.style.color = '#ffcf86';
    const entries = O.planets.map(planet => {
      const body = planetMesh(planet, sphere);
      const orbit = makeOrbit();
      const arc = makeArc(planet.color);
      const start = new T.Mesh(sphere, new T.MeshBasicMaterial({ color: planet.color }));
      scene.add(body, orbit, arc, start);
      const tag = label(planet.name);
      tag.style.color = planet.color;
      return { planet, body, orbit, arc, start, tag, x: 0, y: 0, hit: 0 };
    });

    let width = 1;
    let height = 1;
    const projected = new T.Vector3();
    const toPixels = position => {
      projected.copy(position).project(camera);
      return { x: (projected.x + 1) * width / 2, y: (1 - projected.y) * height / 2 };
    };

    function resize() {
      width = Math.max(1, host.clientWidth);
      height = Math.max(1, host.clientHeight);
      const aspect = width / height;
      const vertical = aspect > 1.55 && height < 500 ? 7.65 : 9.5;
      const half = Math.max(vertical, 11.9 / aspect);
      camera.left = -half * aspect;
      camera.right = half * aspect;
      camera.top = half;
      camera.bottom = -half;
      camera.updateProjectionMatrix();
      renderer.setSize(width, height);
      starfield(sky, width, height);
    }
    new ResizeObserver(resize).observe(host);
    resize();

    function view(mode) {
      // 先清掉上次拖动尚未衰减完的旋转量，再放置预设视角。
      controls.enableDamping = false;
      controls.update();
      camera.position.copy(startView);
      if (width < 570 || mode === 'inner') camera.position.set(0, 15, 10.7);
      if (mode === 'top') camera.position.set(0, 18, 0.28);
      camera.zoom = mode === 'inner' ? 16 : 1;
      camera.updateProjectionMatrix();
      controls.update();
      controls.enableDamping = true;
    }
    view();

    function pick(x, y) {
      const rect = renderer.domElement.getBoundingClientRect();
      let nearest = null;
      let best = Infinity;
      for (const item of entries) {
        if (!item.body.visible) continue;
        const d = Math.hypot(x - rect.left - item.x, y - rect.top - item.y);
        if (d <= item.hit && d < best) {
          best = d;
          nearest = item;
        }
      }
      return nearest;
    }

    // 多指或移动超过阈值时交给轨道控制，单指轻触命中时选星。
    const pointers = new Set();
    let tap = null;
    const canvas = renderer.domElement;
    canvas.addEventListener('pointerdown', event => {
      pointers.add(event.pointerId);
      tap = pointers.size === 1 && event.button === 0 ? { x: event.clientX, y: event.clientY } : null;
    });
    canvas.addEventListener('pointermove', event => {
      if (tap && Math.hypot(event.clientX - tap.x, event.clientY - tap.y) > 6) tap = null;
      if (event.pointerType === 'mouse' && !pointers.size) {
        canvas.style.cursor = pick(event.clientX, event.clientY) ? 'pointer' : 'grab';
      }
    });
    canvas.addEventListener('pointerup', event => {
      if (tap) {
        const item = pick(event.clientX, event.clientY);
        if (item) onPick(item.planet.id);
      }
      tap = null;
      pointers.delete(event.pointerId);
    });
    const cancelTap = event => {
      pointers.delete(event.pointerId);
      tap = null;
    };
    canvas.addEventListener('pointercancel', cancelTap);
    canvas.addEventListener('lostpointercapture', cancelTap);

    function layoutTags(markers) {
      const used = [];
      for (const marker of markers) {
        const { tag, x, y, gap, selected } = marker;
        const w = marker.long ? 46 : 34;
        const h = 18;
        const candidates = [
          [x + gap, y - h / 2], [x - gap - w, y - h / 2],
          [x - w / 2, y - gap - h], [x - w / 2, y + gap],
        ];
        const position = candidates.find(([left, top]) =>
          left >= 1 && left + w <= width - 1 && top >= 1 && top + h <= height - 1 &&
          !used.some(b => left < b.x + b.w && left + w > b.x && top < b.y + b.h && top + h > b.y) &&
          !markers.some(m => m.x > left - m.gap * 0.65 && m.x < left + w + m.gap * 0.65 &&
            m.y > top - m.gap * 0.65 && m.y < top + h + m.gap * 0.65));
        tag.hidden = !position;
        if (!position) continue;
        tag.classList.toggle('selected', selected);
        tag.style.transform = 'translate(' + Math.round(position[0]) + 'px,' + Math.round(position[1]) + 'px)';
        used.push({ x: position[0] - 2, y: position[1], w: w + 4, h });
      }
    }

    function render(state) {
      controls.update();
      camera.updateMatrixWorld();
      const pixels = height * camera.zoom / (camera.top - camera.bottom);
      const markerScale = Math.min(1.05, 38 / pixels);
      const compare = state.scene === 'compare';
      const compact = state.scene === 'scale' && camera.zoom < 5;
      const selected = state.selected;
      const other = state.other;
      // 等比例视图中，放大的太阳也必须留在水星轨道内。
      const sunSize = state.scene === 'scale' ? Math.min(0.058, 0.40 * markerScale) : 0.59 * markerScale;
      sun.scale.setScalar(sunSize);
      glow.scale.setScalar(sunSize * 8.2);
      const center = toPixels(sun.position);
      const markers = [{ ...center, tag: sunLabel, gap: sunSize * pixels + 6, selected: false }];
      for (const item of entries) {
        const { planet, body, orbit, arc, start, tag } = item;
        const visible = !compare || planet === other || planet === O.earth;
        body.visible = orbit.visible = visible;
        arc.visible = start.visible = compare && visible;
        tag.hidden = true;
        if (!visible) continue;
        const r = O.radius(planet, state.scene, other);
        const point = O.course(planet, state.years, state.scene, other);
        const size = planet.size * markerScale * (compare ? 1.36 : compact && planet.au < 2 ? 0.38 : 1);
        body.position.set(point.x, 0, point.z);
        body.scale.setScalar(size);
        orbit.scale.setScalar(r);
        const active = planet === selected;
        orbit.material.color.set(compare || active ? planet.color : '#6682a2');
        orbit.material.opacity = active ? 0.93 : compact && planet.au < 2 ? 0.33 : 0.58;
        if (compare) {
          start.position.set(r * Math.cos(-0.38), 0, r * Math.sin(0.38));
          start.scale.setScalar(0.075 * markerScale);
          updateArc(arc, r, O.turns(planet, state.years));
        }
        const screen = toPixels(body.position);
        item.x = screen.x;
        item.y = screen.y;
        item.hit = Math.max(21, size * pixels * (planet.id === 'saturn' ? 1.8 : 1) + 5);
        if (state.labels && (!compact || planet.au > 2 || active)) {
          markers.push({ ...screen, tag, gap: Math.max(6, size * pixels * (planet.id === 'saturn' ? 1.9 : 1) + 5),
            selected: active, long: planet.name.length > 2 });
        }
      }
      sunLabel.hidden = true;
      if (state.labels) layoutTags(markers.sort((a, b) => Number(b.selected) - Number(a.selected)));
      renderer.render(scene, camera);
    }

    return { render, view, camera };
  }

  window.SolarScene = { create };
})();
