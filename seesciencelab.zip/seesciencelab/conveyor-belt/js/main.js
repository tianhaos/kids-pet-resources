(function () {
  'use strict';
  const $ = id => document.getElementById(id), P = Conveyor, q = new URLSearchParams(location.search);
  const limits = { u: [-3, 6, .25], v: [-3, 3, .25], mu: [0, .6, .05], m: [1, 3, .5], M: [2, 6, .5] };
  const state = Object.assign(P.defaults(q.get('scene')), { t: 1, playing: false, forces: q.get('forces') !== '0', hover: null, drag: null });
  function preset(name) {
    Object.assign(state, P.defaults(state.scene));
    if (state.scene === 'belt') {
      if (name === 'fast') { state.u = 5; state.v = 2; }
      if (name === 'opposite') { state.u = -2; state.v = 3; }
      if (name === 'match') { state.u = 2; state.v = 2; }
    } else {
      if (name === 'fast') { state.u = 6; state.mu = .05; }
      if (name === 'opposite') state.u = -2;
      if (name === 'match') state.u = 0;
    }
    state.t = 0; state.playing = false;
  }
  preset(q.get('preset'));
  for (const [key, [lo, hi, step]] of Object.entries(limits)) {
    if (q.has(key) && Number.isFinite(Number(q.get(key)))) state[key] = P.clamp(Number((Math.round(Number(q.get(key)) / step) * step).toFixed(2)), lo, hi);
  }
  if (state.scene === 'plank') state.v = 0;
  const initialTime = q.has('t') && Number.isFinite(Number(q.get('t'))) ? Number(q.get('t')) : 1;
  state.t = P.clamp(initialTime, 0, P.at(state, 0).end); state.playing = q.get('play') === '1';
  let geom, drag, last = 0;
  function track(action, label = state.scene) { if (window.Analytics) Analytics.track('传送带与板块模型', action, label); }
  function sync() {
    const plank = state.scene === 'plank';
    document.querySelectorAll('[data-scene]').forEach(b => {
      const on = b.dataset.scene === state.scene; b.classList.toggle('on', on); b.setAttribute('aria-pressed', String(on));
    });
    $('subtitle').textContent = plank ? '光滑地面上的自由长板 · 地面为参考系' : '电机保持水平带匀速 · 地面为参考系';
    $('row-v').hidden = plank; $('row-M').hidden = !plank;
    for (const [key, [, , step]] of Object.entries(limits)) {
      $(key).value = state[key];
      $(key + 'Value').textContent = state[key].toFixed(step < .5 ? 2 : 1) + (key === 'mu' ? '' : key === 'm' || key === 'M' ? ' kg' : ' m/s');
    }
    $('forces').checked = state.forces;
    $('time').max = P.at(state, 0).end;
    $('baseLabel').textContent = plank ? '长板速度' : '传送带速度';
    $('extraLabel').textContent = plank ? '系统总动量' : '电机功（接触作用）';
    const labels = plank ? ['滑动到共速', '低摩擦滑出', '向左滑入', '一起静止'] : ['慢物块加速', '快物块减速', '反向送入', '初始已同速'];
    document.querySelectorAll('[data-preset]').forEach((b, i) => b.textContent = labels[i]);
    $('scope').textContent = '接触面长8 m，物块质点初始距左端1.5 m。观察至4 s或质点到端点；外形不表示物块真实尺寸。g取10 m/s²。';
  }
  function setScene(next) {
    Object.assign(state, P.defaults(next)); state.t = 1; state.playing = false; sync(); track('切换场景');
  }
  function setParameter(key, value) {
    if (!limits[key] || !Number.isFinite(value)) return;
    const [lo, hi, step] = limits[key]; state[key] = P.clamp(Number((Math.round(value / step) * step).toFixed(2)), lo, hi);
    if (state.scene === 'plank') state.v = 0;
    state.t = 0; state.playing = false; sync();
  }
  function setTime(t) { state.t = P.clamp(t, 0, P.at(state, 0).end); state.playing = false; }
  function play() {
    if (state.t >= P.at(state, 0).end - .0001) state.t = 0;
    state.playing = !state.playing; track(state.playing ? '播放' : '暂停');
  }
  document.querySelectorAll('[data-scene]').forEach(b => b.onclick = () => setScene(b.dataset.scene));
  document.querySelectorAll('[data-preset]').forEach(b => b.onclick = () => { preset(b.dataset.preset); sync(); track('选择例子', b.dataset.preset); });
  for (const key of Object.keys(limits)) {
    $(key).oninput = e => setParameter(key, Number(e.target.value)); $(key).onchange = () => track('调整参数', key);
  }
  $('play').onclick = play;
  $('reset').onclick = () => { setTime(0); track('回到起点'); };
  $('sync').onclick = () => {
    const a = P.at(state, 0);
    if (a.ts <= a.end) { setTime(a.ts); $('toast').textContent = '已定位共速时刻'; }
    else $('toast').textContent = a.edge ? '到端点前尚未共速' : '观察时间内尚未共速';
    track('定位共速');
  };
  $('time').oninput = e => setTime(Number(e.target.value)); $('time').onchange = () => track('回看时间');
  $('forces').onchange = e => { state.forces = e.target.checked; track('显示摩擦力'); };
  $('panelToggle').onclick = () => {
    const collapsed = $('panel').classList.toggle('collapsed'); $('panelToggle').setAttribute('aria-expanded', String(!collapsed));
  };
  if (matchMedia('(max-width:760px)').matches) { $('panel').classList.add('collapsed'); $('panelToggle').setAttribute('aria-expanded', 'false'); }
  document.addEventListener('keydown', e => {
    if (e.code === 'Space' && !/INPUT|BUTTON|TEXTAREA|SELECT/.test(e.target.tagName)) { e.preventDefault(); play(); }
  });
  const canvas = $('lab');
  const point = e => { const r = canvas.getBoundingClientRect(); return { x: e.clientX - r.left, y: e.clientY - r.top }; };
  function scrub(x) { setTime((x - geom.graph.left) / (geom.graph.right - geom.graph.left) * P.LIMIT); }
  canvas.onpointerdown = e => {
    const p = point(e), hit = ConveyorDraw.hit(p.x, p.y); if (!hit) return;
    state.playing = false; drag = { kind: hit.kind, x: p.x, initial: state[hit.kind] }; state.drag = hit.kind;
    if (hit.kind === 'time') scrub(p.x);
    canvas.setPointerCapture(e.pointerId); e.preventDefault();
  };
  canvas.onpointermove = e => {
    const p = point(e);
    if (drag) {
      if (drag.kind === 'time') scrub(p.x);
      else setParameter(drag.kind, drag.initial + (p.x - drag.x) / geom.velocityUnit);
    } else { const hit = ConveyorDraw.hit(p.x, p.y); state.hover = hit ? hit.kind : null; }
    canvas.style.cursor = drag || state.hover ? 'ew-resize' : 'default';
  };
  function end() { if (drag) track('画面拖动', drag.kind); drag = null; state.drag = null; }
  canvas.onpointerup = end; canvas.onpointercancel = end; canvas.onlostpointercapture = end;
  canvas.onpointerleave = () => { state.hover = null; };
  $('share').onclick = async () => {
    const url = new URL(location.href); url.search = '';
    for (const key of ['scene', 'u', 'v', 'mu', 'm', 'M', 't']) url.searchParams.set(key, state[key]);
    url.searchParams.set('forces', state.forces ? 1 : 0);
    try { await navigator.clipboard.writeText(url.href); $('toast').textContent = '已复制当前实验链接'; }
    catch { $('shareLink').hidden = false; $('shareLink').value = url.href; $('shareLink').select(); $('toast').textContent = '请复制下方链接'; }
    track('分享实验');
  };
  function frame(now) {
    const dt = last ? Math.min(.05, (now - last) / 1000) : 0; last = now;
    if (state.playing) {
      const end = P.at(state, 0).end; state.t = Math.min(end, state.t + dt * .5);
      if (state.t >= end) state.playing = false;
    }
    const a = P.at(state, state.t); geom = ConveyorDraw.draw(canvas, state);
    $('clock').textContent = a.t.toFixed(2) + ' s'; $('time').value = a.t;
    $('play').textContent = state.playing ? '暂停' : state.t >= a.end - .0001 ? '重播' : '播放';
    $('phase').textContent = a.reachedEdge ? '端点 · 结束观察' : a.sliding ? '相对滑动' : '共速 · 摩擦为零';
    $('speedBlock').textContent = a.u.toFixed(2) + ' m/s'; $('speedBase').textContent = a.v.toFixed(2) + ' m/s';
    $('friction').textContent = Math.abs(a.friction).toFixed(2) + ' N' + (a.friction ? (a.friction > 0 ? ' 向右' : ' 向左') : '');
    $('slip').textContent = a.slip.toFixed(2) + ' m'; $('heat').textContent = a.Q.toFixed(2) + ' J';
    $('kinetic').textContent = a.dK.toFixed(2) + ' J';
    $('extra').textContent = a.board ? a.momentum.toFixed(2) + ' kg·m/s' : a.motor.toFixed(2) + ' J';
    $('syncTime').textContent = a.ts <= a.end ? a.ts.toFixed(2) + ' s' : a.edge ? '到端点前未共速' : '4秒内未共速';
    $('fact').textContent = a.board ? '板受大小相等、方向相反的摩擦力；系统水平动量守恒，动能减少量等于产热。'
      : '电机保持带速恒定。电机功 = 物块动能变化 + 产热；负功表示电机吸收机械能。';
    requestAnimationFrame(frame);
  }
  sync(); requestAnimationFrame(frame);
  window.__model = { state, setScene, setParameter, setTime, preset(name) { preset(name); sync(); }, solve: () => P.at(state, state.t), geometry: () => geom };
})();
