(function () {
  'use strict';
  const P = Conveyor, GOLD = '#ffc94a', BLUE = '#78d9ff', ORANGE = '#ff9876', MUTED = '#91a6be';
  let hits = [], geom;
  function text(c, str, x, y, color = MUTED, size = 12, align = 'left') {
    c.fillStyle = color; c.font = `${size}px -apple-system,BlinkMacSystemFont,"PingFang SC","Microsoft YaHei",sans-serif`;
    c.textAlign = align; c.textBaseline = 'middle'; c.fillText(str, x, y);
  }
  function line(c, x, y, xx, yy, color, width = 1, dash = []) {
    c.beginPath(); c.setLineDash(dash); c.moveTo(x, y); c.lineTo(xx, yy);
    c.strokeStyle = color; c.lineWidth = width; c.stroke(); c.setLineDash([]);
  }
  function round(c, x, y, w, h, r, fill, stroke) {
    c.beginPath(); c.roundRect(x, y, w, h, r);
    if (fill) { c.fillStyle = fill; c.fill(); }
    if (stroke) { c.strokeStyle = stroke; c.lineWidth = 1; c.stroke(); }
  }
  function arrow(c, x, y, length, color, width = 2) {
    if (Math.abs(length) < 1) { c.beginPath(); c.arc(x, y, 2, 0, 2 * Math.PI); c.fillStyle = color; c.fill(); return; }
    const end = x + length, sign = Math.sign(length);
    line(c, x, y, end, y, color, width);
    c.beginPath(); c.moveTo(end, y); c.lineTo(end - 7 * sign, y - 4); c.lineTo(end - 7 * sign, y + 4);
    c.closePath(); c.fillStyle = color; c.fill();
  }
  function knob(c, x, y, kind, s) {
    const active = s.hover === kind || s.drag === kind;
    c.beginPath(); c.arc(x, y, active ? 8 : 6, 0, Math.PI * 2);
    c.fillStyle = active ? '#e7f4ff' : '#101a29'; c.fill(); c.strokeStyle = kind === 'u' ? GOLD : BLUE;
    c.lineWidth = 2; c.stroke(); hits.push({ kind, x, y, r: 23 });
  }
  function roller(c, x, y, r, angle) {
    const gradient = c.createRadialGradient(x - r * .3, y - r * .4, 1, x, y, r);
    gradient.addColorStop(0, '#5d748d'); gradient.addColorStop(.65, '#26394d'); gradient.addColorStop(1, '#152133');
    c.beginPath(); c.arc(x, y, r, 0, Math.PI * 2); c.fillStyle = gradient; c.fill(); c.strokeStyle = '#8ba3bb'; c.stroke();
    for (let i = 0; i < 4; i++) {
      const a = angle + i * Math.PI / 2;
      line(c, x, y, x + Math.cos(a) * r * .75, y + Math.sin(a) * r * .75, '#91a6be', 2);
    }
    c.beginPath(); c.arc(x, y, 3, 0, Math.PI * 2); c.fillStyle = '#afc2d5'; c.fill();
  }
  function drawApparatus(c, s, a, g) {
    const { px, y, scale, w, small } = g;
    const baseX = a.board ? a.X : 0, left = px(baseX), right = px(baseX + P.LENGTH);
    const bx = px(a.x), boxW = small ? 39 : 60, boxH = small ? 40 : 55;
    // 地面刻度绝不跟随承载面，提供固定参考系。
    const ground = y + (g.compact ? 61 : 78);
    line(c, 24, ground, w - 24, ground, '#384b62');
    for (let world = Math.ceil(g.min); world <= g.max; world++) {
      const x = px(world);
      line(c, x, ground, x, ground + 5, '#59708b');
      if (world % (small ? 2 : 1) === 0) text(c, String(world), x, ground + 17, MUTED, 11, 'center');
    }
    text(c, '地面 x / m', w - 28, ground + 35, MUTED, 11, 'right');
    if (a.board) {
      const wood = c.createLinearGradient(0, y, 0, y + 28);
      wood.addColorStop(0, '#31546c'); wood.addColorStop(.45, '#21394b'); wood.addColorStop(1, '#102334');
      round(c, left, y, right - left, 28, 3, wood, '#6e9fbd');
      for (let k = 0; k < 7; k++) line(c, left + 3, y + 5 + k * 3, right - 3, y + 5 + k * 3, '#78d9ff18');
      for (let k = 1; k < 8; k++) line(c, px(baseX + k), y, px(baseX + k), y + 6, '#a1c4d6');
      text(c, `长板 M = ${s.M} kg`, (left + right) / 2, y + 44, BLUE, 12, 'center');
      text(c, '光滑水平地面', 28, ground + 35, MUTED, 11);
    } else {
      const r = small ? 15 : 21;
      // 带面沿闭合跑道运动，左右端圆弧保持连续。
      round(c, left - r, y, right - left + 2 * r, r * 2, r, '#182c3b', '#5c89a7');
      roller(c, left, y + r, r - 3, a.X * scale / r);
      roller(c, right, y + r, r - 3, a.X * scale / r);
      line(c, left, y + 2, right, y + 2, BLUE, 3);
      line(c, left, y + 2 * r - 2, right, y + 2 * r - 2, '#426a83', 2);
      const phase = ((a.X * scale % 22) + 22) % 22;
      c.save(); c.beginPath(); c.rect(left, y - 1, right - left, r * 2 + 2); c.clip();
      for (let x = left - 22 + phase; x <= right + 22; x += 22) line(c, x, y + 1, x - 4, y + 7, '#b4e8ff', 2);
      for (let x = left - phase; x <= right + 22; x += 22) line(c, x, y + 2 * r - 5, x - 4, y + 2 * r - 1, '#699cb7', 2);
      c.restore();
      for (const x of [left + 10, right - 10]) {
        line(c, x, y + 2 * r, x - 8, ground, '#41556d', 7);
        line(c, x - 17, ground, x + 4, ground, '#71859d', 3);
      }
      text(c, '电机保持带速不变', (left + right) / 2, g.compact ? y + r + 2 : y + 2 * r + 17, BLUE, 11, 'center');
    }
    // 淡虚线仅表示初始质点的位置。
    line(c, px(P.START), y - boxH - 4, px(P.START), ground - 4, '#91a6be50', 1, [4, 5]);
    const fill = c.createLinearGradient(bx, y - boxH, bx, y);
    fill.addColorStop(0, '#b88b3d'); fill.addColorStop(.5, '#8d6428'); fill.addColorStop(1, '#563c1f');
    round(c, bx - boxW / 2, y - boxH, boxW, boxH, 4, fill, GOLD);
    c.fillStyle = '#f4d18c50'; c.fillRect(bx - 5, y - boxH + 1, 10, boxH - 2);
    line(c, bx - boxW / 2 + 4, y - boxH + 11, bx + boxW / 2 - 4, y - boxH + 11, '#e9bb6550');
    text(c, `${s.m} kg`, bx, y - boxH / 2 + 2, '#fff0c5', small ? 11 : 13, 'center');
    c.beginPath(); c.arc(bx, y, 3, 0, Math.PI * 2); c.fillStyle = GOLD; c.fill();
    // 速度以同一箭长比例显示；箭头端点也是触摸柄。
    const unit = small ? 17 : 25, vy = y - boxH - 26;
    const speedX = P.clamp(bx, 26 + Math.max(0, -a.u * unit), w - 26 - Math.max(0, a.u * unit));
    if (Math.abs(speedX - bx) > 1) line(c, bx, y - boxH - 2, speedX, vy, '#91a6be55', 1, [3, 3]);
    arrow(c, speedX, vy, a.u * unit, GOLD);
    knob(c, speedX + a.u * unit, vy, 'u', s);
    text(c, `物块 v = ${a.u.toFixed(2)} m/s`, Math.min(w - 90, Math.max(90, speedX)), vy - 22, GOLD, 12, 'center');
    const vx = P.clamp((left + right) / 2, 26 + Math.max(0, -a.v * unit), w - 26 - Math.max(0, a.v * unit)), by = ground + (g.compact ? 45 : 61);
    arrow(c, vx, by, a.v * unit, BLUE);
    if (!a.board) knob(c, vx + a.v * unit, by, 'v', s);
    text(c, `${a.board ? '板' : '带'} v = ${a.v.toFixed(2)} m/s`, vx, by + 22, BLUE, 12, 'center');
    if (s.forces && Math.abs(a.friction) > .0001) {
      const forceLen = Math.sign(a.friction) * (small ? 30 : 45);
      arrow(c, bx, y - 9, forceLen, ORANGE, 3);
      text(c, 'f', bx + forceLen + Math.sign(forceLen) * 10, y - 10, ORANGE, 13, 'center');
      if (a.board) arrow(c, bx, y + 14, -forceLen, ORANGE, 3);
    }

    g.velocityUnit = unit;
  }
  function drawGraph(c, s, a, g) {
    const { w, h, small } = g, top = Math.max(g.y + (g.compact ? 183 : 219), h * .64), bottom = h - (g.compact ? 120 : 138);
    const left = small ? 43 : 68, right = w - (small ? 27 : 48), height = bottom - top;
    const values = [s.u, a.baseV, a.common, 0];
    const lo = Math.min(-1, Math.floor(Math.min(...values) - .5));
    const hi = Math.max(4, Math.ceil(Math.max(...values) + .5));
    const tx = t => left + t / P.LIMIT * (right - left), vy = v => bottom - (v - lo) / (hi - lo) * height;
    text(c, '速度–时间图', left, top - 20, '#d9e6f4', small ? 13 : 14);
    text(c, '金：物块    蓝：承载面', right, top - 20, MUTED, 11, 'right');
    for (let v = lo; v <= hi; v++) {
      line(c, left, vy(v), right, vy(v), v === 0 ? '#61778f' : '#203044', 1, v === 0 ? [] : [2, 4]);
      if ((hi - lo < 8 || v % 2 === 0) && height > 60) text(c, String(v), left - 11, vy(v), MUTED, 10, 'right');
    }
    for (let t = 0; t <= 4; t++) {
      line(c, tx(t), top, tx(t), bottom, '#203044');
      text(c, String(t), tx(t), bottom + 16, MUTED, 11, 'center');
    }
    text(c, 'm/s', left - 15, top - 2, MUTED, 10, 'right');
    text(c, 't / s', right + 1, bottom + 32, MUTED, 11, 'right');
    const syncVisible = Number.isFinite(a.ts) && a.ts <= a.end;
    // 速度差面积的大小即相对滑动路程；只涂已经经历的滑动阶段。
    const slipEnd = Math.min(a.t, a.ts);
    c.beginPath(); c.moveTo(tx(0), vy(s.u));
    const f = P.at(s, slipEnd);
    c.lineTo(tx(slipEnd), vy(f.u)); c.lineTo(tx(slipEnd), vy(f.v)); c.lineTo(tx(0), vy(a.baseV)); c.closePath();
    c.fillStyle = '#ff987624'; c.fill();
    for (const item of [{ key: 'u', color: GOLD }, { key: 'v', color: BLUE }]) {
      c.beginPath();
      for (let i = 0; i <= 180; i++) {
        const t = a.end * i / 180, z = P.at(s, t);
        i ? c.lineTo(tx(t), vy(z[item.key])) : c.moveTo(tx(t), vy(z[item.key]));
      }
      c.lineWidth = 2; c.strokeStyle = item.color; c.setLineDash(item.key === 'v' ? [6, 3] : []); c.stroke(); c.setLineDash([]);
    }
    if (syncVisible) {
      line(c, tx(a.ts), top, tx(a.ts), bottom, '#85dfb177', 1, [3, 4]);
      text(c, '共速', tx(a.ts) + 4, top + 12, '#85dfb1', 11);
    }
    line(c, tx(a.t), top - 4, tx(a.t), bottom, '#e9f1fc', 1);
    for (const [value, color] of [[a.u, GOLD], [a.v, BLUE]]) {
      c.beginPath(); c.arc(tx(a.t), vy(value), 4, 0, Math.PI * 2); c.fillStyle = color; c.fill();
    }
    text(c, '拖图回看 · 阴影面积 = 相对路程', left, bottom + (g.compact ? 27 : 36), MUTED, 11);
    hits.push({ kind: 'time', x: left, y: top - 8, w: right - left, h: bottom - top + 28 });
    g.graph = { left, right, top, bottom, tx, vy };
  }
  function draw(canvas, s) {
    const r = canvas.getBoundingClientRect(), w = r.width, h = r.height, dpr = Math.min(2, devicePixelRatio || 1);
    if (canvas.width !== Math.round(w * dpr) || canvas.height !== Math.round(h * dpr)) {
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
    }
    const c = canvas.getContext('2d'); c.setTransform(dpr, 0, 0, dpr, 0, 0); c.clearRect(0, 0, w, h);
    c.fillStyle = '#05070d'; c.fillRect(0, 0, w, h); hits = [];
    const a = P.at(s, s.t), end = P.at(s, a.end), small = w < 650;
    const min = Math.min(-.8, end.x - .8, end.board ? end.X - .8 : 0);
    const max = Math.max(8.8, end.x + .8, end.board ? end.X + P.LENGTH + .8 : 8.8);
    const margin = small ? 28 : 62, scale = (w - 2 * margin) / (max - min);
    const px = x => margin + (x - min) * scale;
    geom = { w, h, small, compact: h < 680, min, max, px, scale, y: Math.max(h < 680 ? 210 : 260, Math.min(h * .34, 320)) };
    // 克制的装置台照明，不作为任何力学量。
    const glow = c.createRadialGradient(w / 2, geom.y, 10, w / 2, geom.y, w * .55);
    glow.addColorStop(0, '#10233c55'); glow.addColorStop(1, '#05070d00'); c.fillStyle = glow; c.fillRect(0, 130, w, h * .5);
    const phaseY = h < 680 ? 80 : 96;
    const phase = a.reachedEdge ? '到达端点 · 观察结束' : a.sliding ? '正在相对滑动' : '已共速 · 摩擦力为零';
    text(c, phase, small ? 20 : 28, phaseY, a.reachedEdge ? ORANGE : a.sliding ? GOLD : '#85dfb1', small ? 16 : 18);
    text(c, a.sliding ? `物块相对${a.board ? '板' : '带'}向${a.u > a.v ? '右' : '左'}滑，${a.friction ? '摩擦力向' + (a.friction > 0 ? '右' : '左') : 'μ=0，无摩擦'}`
      : a.reachedEdge ? '质点到端点即暂停，不模拟离开后的运动' : '水平无其他外力，不需要摩擦力维持匀速', small ? 20 : 28, phaseY + 27, MUTED, 12);
    drawApparatus(c, s, a, geom);
    const yy = geom.y + (geom.compact ? 146 : 181);
    text(c, `相对路程 ${a.slip.toFixed(2)} m`, small ? 26 : 68, yy, ORANGE, 12);
    text(c, `产热 Q = ${a.Q.toFixed(2)} J`, w - (small ? 26 : 48), yy, ORANGE, 12, 'right');
    drawGraph(c, s, a, geom);
    return geom;
  }
  function hit(x, y) {
    return hits.find(p => p.r ? Math.hypot(x - p.x, y - p.y) <= p.r : x >= p.x && x <= p.x + p.w && y >= p.y && y <= p.y + p.h) || null;
  }
  window.ConveyorDraw = { draw, hit, hits: () => hits, geometry: () => geom };
})();
