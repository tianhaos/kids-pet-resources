(function () {
  'use strict';
  const G = 10, LENGTH = 8, START = 1.5, LIMIT = 4, EPS = 1e-9;
  const clamp = (x, lo, hi) => Math.max(lo, Math.min(hi, x));
  function defaults(scene) {
    return { scene: scene === 'plank' ? 'plank' : 'belt', u: scene === 'plank' ? 4 : 0,
      v: scene === 'plank' ? 0 : 3, mu: .2, m: 1, M: 3 };
  }
  function setup(s) {
    const board = s.scene === 'plank', baseV = board ? 0 : s.v;
    const delta = s.u - baseV, sign = Math.sign(delta), f = s.mu * s.m * G;
    const a = -sign * s.mu * G, A = board ? sign * f / s.M : 0;
    const relativeA = Math.abs(a - A);
    const ts = Math.abs(delta) < EPS ? 0 : relativeA > EPS ? Math.abs(delta) / relativeA : Infinity;
    return { board, baseV, delta, sign, f, a, A, ts, common: board ? s.m * s.u / (s.m + s.M) : baseV };
  }
  // 在滑动段和匀速段分别解接触点坐标，取最早到端点的正根。
  function firstEdge(s, p) {
    const relative = p.board;
    const v = relative ? p.delta : s.u, a = relative ? p.a - p.A : p.a;
    let end = LIMIT, edge = false;
    const split = Math.min(p.ts, LIMIT);
    for (const boundary of [0, LENGTH]) {
      const c = START - boundary;
      const roots = [];
      if (Math.abs(a) < EPS) { if (Math.abs(v) > EPS) roots.push(-c / v); }
      else {
        const d = v * v - 2 * a * c;
        if (d >= -EPS) { const root = Math.sqrt(Math.max(0, d)); roots.push((-v + root) / a, (-v - root) / a); }
      }
      for (const t of roots) if (t > EPS && t <= split + EPS && t <= end) { end = t; edge = true; }
    }
    if (p.ts < LIMIT && !relative) {
      const x = START + s.u * p.ts + .5 * p.a * p.ts * p.ts;
      if (Math.abs(p.common) > EPS) {
        const t = p.ts + ((p.common > 0 ? LENGTH : 0) - x) / p.common;
        if (t >= p.ts - EPS && t <= end) { end = t; edge = true; }
      }
    }
    return { end: Math.max(0, end), edge };
  }
  function at(s, time) {
    const p = setup(s), event = firstEdge(s, p), t = clamp(time, 0, event.end);
    const z = Math.min(t, p.ts), tail = t - z;
    const dx = s.u * z + .5 * p.a * z * z + (s.u + p.a * z) * tail;
    const dxBase = p.baseV * z + .5 * p.A * z * z + (p.baseV + p.A * z) * tail;
    const u = s.u + p.a * z, v = p.baseV + p.A * z;
    const sliding = t < p.ts - EPS && Math.abs(p.delta) > EPS;
    const slip = Math.max(0, Math.abs(p.delta) * z - .5 * Math.abs(p.a - p.A) * z * z);
    const friction = sliding ? -p.sign * p.f : 0;
    const dK = .5 * s.m * (u * u - s.u * s.u);
    const Q = p.f * slip;
    // 恒速电机抵消物块施于皮带的摩擦力，功可正可负。
    const motor = p.board ? 0 : -p.sign * p.f * p.baseV * z;
    return Object.assign({}, p, event, { t, x: START + dx, X: dxBase, u, v, dx, dxBase,
      sliding, slip, friction, reaction: -friction, Q, dK, motor,
      momentum: s.m * u + (p.board ? s.M * v : 0), reachedEdge: event.edge && t >= event.end - EPS });
  }
  window.Conveyor = { G, LENGTH, START, LIMIT, clamp, defaults, setup, firstEdge, at };
})();
