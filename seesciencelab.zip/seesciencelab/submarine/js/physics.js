/* 理想刚性潜艇：闭合外形体积不变，舱内水计入总质量。SI 单位。 */
(function () {
  'use strict';
  var P = { volume: 100, dryMass: 80000, tank: 40, radius: 2, g: 10, floor: 30, drag: 24000 };
  function clamp(x, a, b) { return Math.max(a, Math.min(b, x)); }
  // 椭球被水平面切割的体积分数，d 为中心深度（向下为正）。
  function fraction(d) {
    var q = clamp(d / P.radius, -1, 1);
    return .5 + .75 * q - .25 * q * q * q;
  }
  function neutral(rho) { return P.volume - P.dryMass / rho; }
  function solve(s) {
    var water = clamp(s.water, 0, P.tank), mass = P.dryMass + s.rho * water;
    var displaced = P.volume * fraction(s.depth), buoyancy = s.rho * P.g * displaced;
    var weight = mass * P.g, drag = -P.drag * s.velocity;
    var support = s.depth >= P.floor - P.radius - 1e-8 ? Math.max(0, weight - buoyancy + drag) : 0;
    return { mass: mass, displaced: displaced, buoyancy: buoyancy, weight: weight,
      drag: drag, support: support, net: weight - buoyancy + drag - support,
      neutral: neutral(s.rho), pressure: s.rho * P.g * Math.max(0, s.depth),
      full: s.depth >= P.radius, difference: weight - buoyancy };
  }
  function step(s, dt) {
    if (!s.play || s.held) return;
    var n = Math.max(1, Math.ceil(dt / .015)), h = dt / n;
    for (var i = 0; i < n; i++) {
      s.water = clamp(s.water + s.pump * 2 * h, 0, P.tank);
      if (s.water === 0 || s.water === P.tank) s.pump = 0;
      var f = solve(s);
      s.velocity += f.net / f.mass * h;
      s.depth += s.velocity * h;
      if (s.depth > P.floor - P.radius) { s.depth = P.floor - P.radius; s.velocity = 0; }
      if (s.depth < -P.radius) { s.depth = -P.radius; s.velocity = Math.max(0, s.velocity); }
      s.time += h;
    }
  }
  function preset(scene, rho) {
    var w = neutral(rho);
    return { scene: scene, rho: rho, water: scene === 'dive' ? w + 8 : scene === 'rise' ? w - 8 : w,
      depth: scene === 'rise' ? 18 : 10, velocity: 0, pump: 0, play: true, held: false, time: 0 };
  }
  function phase(s) {
    var f = solve(s);
    if (s.held) return '手托定位中';
    if (s.depth >= P.floor - P.radius - .001 && f.support > 0) return '沉底 · 有支持力';
    if (Math.abs(s.velocity) < .025) {
      if (Math.abs(f.difference) < 300) return f.full ? '悬浮' : '漂浮';
      return f.difference > 0 ? '即将下沉' : '即将上浮';
    }
    return s.velocity > 0 ? '正在下沉' : '正在上浮';
  }
  window.SubPhysics = { P: P, clamp: clamp, fraction: fraction, neutral: neutral, solve: solve, step: step, preset: preset, phase: phase };
})();
