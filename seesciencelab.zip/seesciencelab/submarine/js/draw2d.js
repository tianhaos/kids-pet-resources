/* 海域自适应铺满；艇体为教学放大剖面，深度轴非等比例。 */
(function () {
  'use strict';
  var canvas, ctx, W, H, scale=1, width, height, surface, floor, layout={}, hover='';
  var C={gold:'#ffce66',blue:'#7edcff',text:'#dcebf3',muted:'#8caabd'};
  function init(c){canvas=c;ctx=c.getContext('2d');}
  function text(t,x,y,color,size,align){ctx.fillStyle=color||C.text;ctx.font=(size||14)+'px -apple-system,"PingFang SC",sans-serif';ctx.textAlign=align||'left';ctx.fillText(t,x,y);}
  function line(x,y,X,Y,color,w){ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(X,Y);ctx.strokeStyle=color;ctx.lineWidth=w||1;ctx.stroke();}
  function ellipse(x,y,rx,ry,fill,stroke){ctx.beginPath();ctx.ellipse(x,y,rx,ry,0,0,Math.PI*2);if(fill){ctx.fillStyle=fill;ctx.fill();}if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=1.5;ctx.stroke();}}
  function box(x,y,w,h,fill,stroke,r){ctx.beginPath();ctx.roundRect(x,y,w,h,r||8);ctx.fillStyle=fill;ctx.fill();if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=1;ctx.stroke();}}
  // 海面附近按艇体高度映射，保证部分浸没可见；深水区压缩以展示完整海域。
  function depthY(d){return d<=2?surface+d*18:surface+36+(d-2)/26*(floor-surface-72);}
  function depthAt(y){return y<=surface+36?(y-surface)/18:2+(y-surface-36)/(floor-surface-72)*26;}
  function environment(s){
    var sky=ctx.createLinearGradient(0,0,0,surface);sky.addColorStop(0,'#060b14');sky.addColorStop(1,'#183444');ctx.fillStyle=sky;ctx.fillRect(0,0,width,surface);
    // 远处岛屿与海面提供位置参照。
    ctx.beginPath();ctx.moveTo(width*.58,surface);ctx.lineTo(width*.71,surface-22);ctx.lineTo(width*.76,surface-16);ctx.lineTo(width*.86,surface-33);ctx.lineTo(width,surface);ctx.fillStyle='#294654';ctx.fill();
    var sea=ctx.createLinearGradient(0,surface,0,floor+30);sea.addColorStop(0,'#123e53');sea.addColorStop(.35,'#0b283b');sea.addColorStop(1,'#060f1c');ctx.fillStyle=sea;ctx.fillRect(0,surface,width,height-surface);
    ctx.save();ctx.beginPath();ctx.rect(0,surface,width,floor-surface);ctx.clip();
    for(var i=0;i<4;i++){ctx.beginPath();ctx.moveTo(width*(.1+i*.28),surface);ctx.lineTo(width*(.12+i*.28),surface);ctx.lineTo(width*(.35+i*.28),floor);ctx.lineTo(width*(.15+i*.28),floor);ctx.fillStyle='#9bdcf306';ctx.fill();}
    for(var d=5;d<=25;d+=5){var y=depthY(d);ctx.setLineDash([2,8]);line(24,y,width-55,y,'#99c5dd16');ctx.setLineDash([]);}
    ctx.restore();
    ctx.beginPath();for(var x=0;x<=width+6;x+=6){var yy=surface+Math.sin(x/47+s.time*.7)*1.4;if(!x)ctx.moveTo(x,yy);else ctx.lineTo(x,yy);}ctx.strokeStyle='#7cc2d3';ctx.lineWidth=1.5;ctx.stroke();
    text('海面',24,surface-12,'#93bac9',12);
    line(width-35,surface,width-35,floor,'#6d9fb13b');
    for(d=0;d<=30;d+=5){y=d===30?floor:depthY(d);line(width-41,y,width-30,y,'#6d9fb1');text(d+' m',width-47,y+4,'#83a7b9',12,'right');}
    ctx.beginPath();ctx.moveTo(0,floor);for(x=0;x<=width+20;x+=20)ctx.lineTo(x,floor+Math.sin(x/65)*3);ctx.lineTo(width,height);ctx.lineTo(0,height);ctx.fillStyle='#15232c';ctx.fill();
    for(i=0;i<15;i++){x=15+i*width/15;ellipse(x,floor+7+Math.sin(i*6)*4,3+i%4,1.4,'#45607155');}
    for(i=0;i<5;i++){x=40+i*(width-100)/5;line(x,floor,x-4,floor-14-i%3*5,'#355962',2);line(x-2,floor-5,x+5,floor-13,'#355962',2);}
  }
  function arrow(x,y,length,color,label){
    if(Math.abs(length)<1)return;var end=y+length,dir=Math.sign(length);
    line(x,y,x,end,color,3);line(x,end,x-5,end-dir*9,color,2.5);line(x,end,x+5,end-dir*9,color,2.5);
    text(label,x,end+(dir>0?20:-12),color,13,'center');
  }
  function submarine(s,x,y){
    ctx.save();ctx.translate(x,y);
    ctx.fillStyle='#536d7a';ctx.beginPath();ctx.moveTo(-105,-10);ctx.lineTo(-142,-45);ctx.lineTo(-142,36);ctx.lineTo(-105,14);ctx.fill();
    box(-23,-63,50,39,'#6d7f7f','#a3b3a3',10);line(0,-62,0,-82,'#b4c3b9',5);line(0,-82,20,-82,'#b4c3b9',5);
    var hull=ctx.createLinearGradient(0,-36,0,36);hull.addColorStop(0,'#ffe4a0');hull.addColorStop(.35,'#d9b75f');hull.addColorStop(.7,'#a98c43');hull.addColorStop(1,'#594e32');
    ctx.save();ctx.shadowColor='#0009';ctx.shadowBlur=20;ctx.shadowOffsetY=8;ellipse(0,0,120,36,hull,hover==='body'||s.held?'#fff1b9':'#ddc37e');ctx.restore();
    line(-117,0,-145,0,'#839ca5',4);ellipse(-148,0,3,16,'#9bb8c4');
    for(var i=0;i<5;i++){ellipse(-95+i*44,28-Math.abs(i-2)*2,1.3,1.3,'#ead4a0');}
    box(-79,-23,145,46,'#0a1724','#f9de95',10);
    ctx.save();ctx.beginPath();ctx.roundRect(-76,-20,139,40,8);ctx.clip();var level=20-s.water;
    var water=ctx.createLinearGradient(0,-20,0,20);water.addColorStop(0,'#418cad');water.addColorStop(1,'#1f5677');ctx.fillStyle=water;ctx.fillRect(-76,level,139,42);line(-76,level,63,level,'#a5eaff',1.5);ctx.restore();
    text('压载水舱',-7,5,'#e0f5ff',12,'center');ellipse(91,-1,10,12,'#0a263b','#d4d8ac');ellipse(89,-4,4,4,'#73c7dc33');
    if(s.pump&&s.play){var xx=38,dir=s.pump>0?-1:1;arrow(xx,45,dir*20,C.blue,'');if(s.pump>0)for(var b=0;b<3;b++)ellipse(-42+Math.sin(b*3)*4,-43-(s.time*20+b*18)%48,2+b%2,2+b%2,null,'#85c9df77');}
    if(s.held)text('松手，从静止释放',0,-102,C.gold,13,'center');
    else if(hover==='body')text('上下拖动艇身',0,-101,'#e7f4ff',13,'center');
    ctx.restore();
  }
  function tank(s){
    var w=Math.min(width-64,440),x=(width-w)/2,y=height-195,h=48;
    text('压载水舱',x,y-13,'#d0e2eb',13);text(s.water.toFixed(1)+' / 40 m³',x+w,y-13,'#99dfff',14,'right');
    box(x,y,w,h,'#0b1b2a',hover==='tank'?'#a9eaff':'#486273',9);
    var level=y+h*(1-s.water/40);ctx.save();ctx.beginPath();ctx.roundRect(x+1,y+1,w-2,h-2,8);ctx.clip();ctx.fillStyle='#28739b';ctx.fillRect(x,level,w,h);line(x,level,x+w,level,'#b3efff',2);ctx.restore();
    var neutralY=y+h*(1-SubPhysics.neutral(s.rho)/40);ctx.setLineDash([5,5]);line(x,neutralY,x+w,neutralY,'#efc56d',1);ctx.setLineDash([]);
    box(x+w/2-17,level-3,34,6,'#d9f6ff',null,3);
    text('虚线：浸没时等重水量 · '+SubPhysics.neutral(s.rho).toFixed(1)+' m³',x,y+h+20,'#a9a78e',12);
    layout.tank={x:x,y:y,w:w,h:h};
  }
  function draw(s){
    var r=canvas.getBoundingClientRect(),dpr=Math.min(devicePixelRatio||1,2);W=r.width;H=r.height;
    if(canvas.width!==Math.round(W*dpr)||canvas.height!==Math.round(H*dpr)){canvas.width=Math.round(W*dpr);canvas.height=Math.round(H*dpr);}
    scale=W<600?W/460:1;width=W/scale;height=H/scale;surface=Math.min(245,height*.31);floor=height-270;
    // 极矮窗口仍保留海域，所有控件可通过抽屉操作。
    floor=Math.max(surface+130,floor);
    ctx.setTransform(dpr*scale,0,0,dpr*scale,0,0);ctx.clearRect(0,0,width,height);environment(s);
    var x=width*.45,y=depthY(s.depth);submarine(s,x,y);
    // 海面前景叠色清楚区分露出与浸入部分，不改变内部舱水量。
    if(s.depth<2){ctx.save();ctx.beginPath();ctx.ellipse(x,y,120,36,0,0,Math.PI*2);ctx.clip();ctx.fillStyle='#2e91b72b';ctx.fillRect(x-121,surface,242,height-surface);line(x-120,surface,x-79,surface,'#b1e3e8aa',1);line(x+66,surface,x+120,surface,'#b1e3e8aa',1);ctx.restore();}
    layout.body={x:x,y:y,rx:146,ry:82};
    if(s.forces){var f=SubPhysics.solve(s),fx=width<600?width-112:x+175,L=Math.min(72,(floor-surface-50)/2.3),fy=Math.max(surface+L+22,Math.min(floor-L*1.25-25,y));
      // 深度定位线将独立受力图与艇体相连；两力共用同一比例。
      ctx.setLineDash([3,5]);line(x+121,y,fx,y,'#a0bdcf55');ctx.setLineDash([]);
      if(Math.abs(y-fy)>2)line(fx,y,fx,fy,'#a0bdcf33');
      ellipse(fx,fy,3,3,'#cfdae2');arrow(fx,fy,-f.buoyancy/1000000*L,C.blue,'浮力');arrow(fx,fy,f.weight/1000000*L,C.gold,'重力');
      if(f.support>0)text('海底支持力 ↑',x,y-104,'#a8d9b6',13,'center');
    }
    text('艇体与深度轴非等比例 · 教学剖面',24,floor+16,'#6f889b',11);tank(s);
  }
  function point(e){var r=canvas.getBoundingClientRect();return{x:(e.clientX-r.left)/scale,y:(e.clientY-r.top)/scale};}
  function hit(p){var t=layout.tank,b=layout.body;if(t&&p.x>=t.x-12&&p.x<=t.x+t.w+12&&p.y>=t.y-10&&p.y<=t.y+t.h+10)return'tank';if(b&&Math.pow((p.x-b.x)/b.rx,2)+Math.pow((p.y-b.y)/b.ry,2)<=1)return'body';return'';}
  function waterAt(p){var t=layout.tank;return SubPhysics.clamp((t.y+t.h-p.y)/t.h*40,0,40);}
  window.SubDraw={init:init,draw:draw,point:point,hit:hit,waterAt:waterAt,depthY:depthY,depthAt:depthAt,hover:function(h){hover=h;},layout:function(){return layout;},screen:function(x,y){return{x:x*scale,y:y*scale};}};
})();
