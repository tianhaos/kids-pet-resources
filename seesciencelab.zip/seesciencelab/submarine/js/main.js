(function () {
  'use strict';
  var $ = function (id) { return document.getElementById(id); };
  var params = new URLSearchParams(location.search);
  function number(key, fallback, min, max) {
    if (!params.has(key) || !params.get(key).trim()) return fallback;
    var n = Number(params.get(key)); return Number.isFinite(n) ? SubPhysics.clamp(n, min, max) : fallback;
  }
  var scene = ['dive', 'rise', 'neutral'].includes(params.get('scene')) ? params.get('scene') : 'dive';
  var state = SubPhysics.preset(scene, number('rho', 1000, 1000, 1030));
  state.water = number('water', state.water, 0, 40);
  state.depth = number('depth', state.depth, -2, 28);
  state.velocity = number('v', 0, -20, 20);
  state.play = params.get('play') !== '0'; state.forces = params.get('forces') !== '0';
  var canvas = $('sea'), previous = 0, drag = '', offset = 0, trace = [], lastSample = -1;
  SubDraw.init(canvas);
  function track(action, label) { if (window.Analytics) Analytics.track('潜水艇浮沉', action, String(label)); }
  function setWater(w) { state.water = SubPhysics.clamp(w, 0, 40); state.pump = 0; sync(); }
  function sync() {
    $('water').value = state.water; $('waterValue').textContent = state.water.toFixed(1) + ' m³';
    $('rho').value = state.rho; $('rhoValue').textContent = state.rho + ' kg/m³';
    $('depth').value = state.depth; $('depthValue').textContent = state.depth.toFixed(1) + ' m';
    $('forces').checked = state.forces;
    $('pause').textContent = state.play ? '❚❚ 暂停演示' : '▶ 继续演示';
    $('stagePause').textContent = state.play ? '❚❚' : '▶';
    $('stagePause').setAttribute('aria-label', state.play ? '暂停演示' : '继续演示');
    document.querySelectorAll('[data-pump]').forEach(function (b) { b.classList.toggle('on', Number(b.dataset.pump) === state.pump); b.setAttribute('aria-pressed', Number(b.dataset.pump) === state.pump); });
    document.querySelectorAll('[data-scene]').forEach(function (b) { b.classList.toggle('on', b.dataset.scene === state.scene); b.setAttribute('aria-pressed', b.dataset.scene === state.scene); });
  }
  function preset(name) {
    var forces = state.forces, rho = state.rho;
    Object.assign(state, SubPhysics.preset(name, rho)); state.forces = forces;
    trace = []; lastSample = -1; sync(); track('预设', name);
    $('experimentNote').textContent = '预设从静止开始，方便比较；“调到等重”只改水量，保留当前速度。';
  }
  function readings() {
    var f = SubPhysics.solve(state), status = SubPhysics.phase(state);
    $('status').textContent = status; $('sceneStatus').textContent = status;
    $('sceneDepth').textContent = '中心深度 ' + state.depth.toFixed(1) + ' m · ' + (state.play ? '演示中' : '已暂停');
    $('mass').textContent = (f.mass / 1000).toFixed(2) + ' t';
    $('buoyancy').textContent = (f.buoyancy / 1000).toFixed(1) + ' kN';
    $('weight').textContent = (f.weight / 1000).toFixed(1) + ' kN';
    $('displaced').textContent = f.displaced.toFixed(2) + ' m³';
    $('velocity').textContent = Math.abs(state.velocity).toFixed(2) + ' m/s ' + (state.velocity > .01 ? '↓' : state.velocity < -.01 ? '↑' : '');
    $('drag').textContent = (Math.abs(f.drag) / 1000).toFixed(1) + ' kN ' + (f.drag > .01 ? '↓' : f.drag < -.01 ? '↑' : '');
    $('support').textContent = (f.support / 1000).toFixed(1) + ' kN';
    $('pressure').textContent = (f.pressure / 1000).toFixed(1) + ' kPa';
    $('neutralWater').textContent = f.neutral.toFixed(2) + ' m³';
    $('explain').textContent = f.support > 0 ? '沉底时，浮力与海底支持力共同平衡重力。排水减小重力，可使潜艇离开海底。' : !f.full ? '靠近海面时，浸入体积随位置变化，浮力也会改变。漂浮平衡时浮力等于重力。' :
      Math.abs(f.difference) < 1 ? '已调到浮力等于重力。若仍有速度，会因水阻力逐渐减速；等重不代表瞬间静止。' :
      '潜艇已完全浸没，浮力保持 ' + (f.buoyancy / 1000).toFixed(0) + ' kN。' + (f.difference > 0 ? '注水使重力大于浮力。' : '排水使重力小于浮力。') + '速度还取决于此前运动与水阻力。';
    $('dockNote').textContent = state.pump ? (state.play ? (state.pump > 0 ? '注水中 · 水量增加，重力增大' : '排水中 · 水量减少，重力减小') : '演示已暂停 · 注排水也已暂停') : '阀门关闭 · 水量保持';
    $('pumpNote').textContent = state.pump ? (state.play ? (state.pump > 0 ? '正在注水：2 m³/s' : '正在排水：2 m³/s') : '已暂停，水量保持') : '阀门已关，水量保持；关闭阀门不会立即停止运动。';
    if (state.time - lastSample > .25) {
      trace.push({t:state.time,depth:state.depth,water:state.water}); if (trace.length > 600) trace.shift(); lastSample = state.time;
    }
  }
  document.querySelectorAll('[data-scene]').forEach(function (b) { b.onclick = function () { preset(b.dataset.scene); }; });
  document.querySelectorAll('[data-pump]').forEach(function (b) {
    b.onclick = function () { state.pump = Number(b.dataset.pump); sync(); track('阀门', state.pump); };
  });
  $('water').oninput = function () { setWater(Number(this.value)); };
  $('water').onchange = function () { track('水量', state.water.toFixed(1)); };
  $('rho').oninput = function () { state.rho = Number(this.value); sync(); };
  $('rho').onchange = function () { track('液体密度', state.rho); };
  $('depth').oninput = function () { state.held = true; state.depth = Number(this.value); state.velocity = 0; sync(); };
  function releaseDepth() { state.held = false; track('定位', state.depth.toFixed(1)); }
  $('depth').onchange = releaseDepth; $('depth').onblur = function () { state.held = false; };
  $('equalize').onclick = function () { setWater(SubPhysics.neutral(state.rho)); track('调到等重', state.water); };
  $('pause').onclick = function () { state.play = !state.play; sync(); track('播放', state.play); };
  $('stagePause').onclick = function () { $('pause').click(); };
  $('reset').onclick = function () { preset(state.scene); };
  $('forces').onchange = function () { state.forces = this.checked; track('受力显示', this.checked); };
  $('record').onclick = function () {
    var f = SubPhysics.solve(state), row = document.createElement('tr');
    [state.depth.toFixed(1), state.water.toFixed(1), (f.buoyancy/1000).toFixed(1), (f.weight/1000).toFixed(1)].forEach(function (v) { var td=document.createElement('td');td.textContent=v;row.appendChild(td); });
    $('records').appendChild(row); if ($('records').children.length > 8) $('records').firstElementChild.remove(); track('记录', state.depth.toFixed(1));
  };
  $('clear').onclick = function () { $('records').replaceChildren(); };
  function shareURL() {
    var url = new URL(location.href); url.search = ''; url.hash = '';
    var p = url.searchParams;
    p.set('scene', state.scene); p.set('water', state.water.toFixed(5)); p.set('rho', state.rho);
    p.set('depth', state.depth.toFixed(5)); p.set('v',state.velocity.toFixed(5)); p.set('play','0'); p.set('forces', state.forces ? '1':'0');
    return url.href;
  }
  $('share').onclick = async function () {
    state.play = false; state.pump = 0; sync();
    var url = shareURL();
    try { await navigator.clipboard.writeText(url); $('shareStatus').textContent = '已暂停并复制当前条件链接'; }
    catch (e) { $('shareStatus').textContent = '复制下方链接'; $('shareURL').hidden = false; $('shareURL').value = url; $('shareURL').select(); }
    track('分享',state.scene);
  };
  canvas.onpointerdown = function (e) {
    var p=SubDraw.point(e); drag=SubDraw.hit(p); if (!drag) return;
    e.preventDefault(); canvas.setPointerCapture(e.pointerId);
    if (drag === 'body') { state.held=true;state.velocity=0;offset=p.y-SubDraw.depthY(state.depth); }
    else setWater(SubDraw.waterAt(p));
    canvas.style.cursor='grabbing';
  };
  canvas.onpointermove = function (e) {
    var p=SubDraw.point(e);
    if (drag === 'body') { state.depth=SubPhysics.clamp(SubDraw.depthAt(p.y-offset),-2,28); state.velocity=0; sync(); }
    else if (drag === 'tank') setWater(SubDraw.waterAt(p));
    else { var h=SubDraw.hit(p);SubDraw.hover(h);canvas.style.cursor=h?'grab':'default'; }
  };
  function release(e) {
    if (drag) track('画面拖动',drag);
    state.held=false;drag='';canvas.style.cursor='default';
    if (canvas.hasPointerCapture(e.pointerId)) canvas.releasePointerCapture(e.pointerId);
  }
  canvas.onpointerup=release;canvas.onpointercancel=release;
  $('panelToggle').onclick=function(){var collapsed=$('panel').classList.toggle('collapsed');this.setAttribute('aria-expanded',!collapsed);this.textContent=collapsed?'参数与数据':'收起面板';};
  document.onkeydown=function(e){if(e.code==='Space'&&!/INPUT|BUTTON|SELECT|TEXTAREA/.test(e.target.tagName)){e.preventDefault();$('pause').click();}};
  sync(); readings();
  function frame(t) {
    var dt=previous?Math.min((t-previous)/1000,.08):0;previous=t;
    SubPhysics.step(state,dt); readings();sync();SubDraw.draw(state);requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
  window.__model={state:state,solve:function(){return SubPhysics.solve(state);},setWater:setWater,setScene:preset,shareURL:shareURL,trace:function(){return trace;}};
})();
