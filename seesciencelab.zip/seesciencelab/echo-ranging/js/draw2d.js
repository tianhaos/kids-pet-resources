/* 声脉冲沿水平方向传播；地形与距离映射均为示意，不模拟声强。 */
(function () {
  'use strict';
  const gold='#ffc94a', blue='#68d5ff', ink='#dce8f0', muted='#94acbc';
  function layout(w,h,d){
    const small=w<600, left=w*(small?.14:.15), right=w*(.48+.37*(d-5)/495);
    const bottom=h-320, top=small?145:128;
    const ground=Math.max(top+110,bottom), cy=ground-(small?62:78);
    return {w,h,small,left,right,ground,cy,cliffTop:Math.max(top-6,cy-110)};
  }
  function draw(canvas,state){
    const rect=canvas.getBoundingClientRect(),w=rect.width,h=rect.height,r=Math.min(devicePixelRatio||1,2);
    if(canvas.width!==Math.round(w*r)||canvas.height!==Math.round(h*r)){canvas.width=Math.round(w*r);canvas.height=Math.round(h*r);}
    const c=canvas.getContext('2d');c.setTransform(r,0,0,r,0,0);
    const g=layout(w,h,state.distance),{left,right,ground,cy,cliffTop,small}=g,m=Echo.solve(state),span=right-left;
    function path(points,fill,stroke){c.beginPath();points.forEach(([x,y],i)=>i?c.lineTo(x,y):c.moveTo(x,y));if(fill){c.closePath();c.fillStyle=fill;c.fill();}if(stroke){c.strokeStyle=stroke;c.lineWidth=1;c.stroke();}}
    function line(a,b,x,y,color,width=1){c.beginPath();c.moveTo(a,b);c.lineTo(x,y);c.strokeStyle=color;c.lineWidth=width;c.stroke();}
    function text(s,x,y,color=ink,size=12,align='left'){c.fillStyle=color;c.font=`${size}px -apple-system,"PingFang SC",sans-serif`;c.textAlign=align;c.fillText(s,x,y);}
    function circle(x,y,r,fill){c.beginPath();c.arc(x,y,r,0,Math.PI*2);c.fillStyle=fill;c.fill();}
    const sky=c.createLinearGradient(0,0,0,h);sky.addColorStop(0,'#050a13');sky.addColorStop(.53,'#142a38');sky.addColorStop(1,'#080e16');c.fillStyle=sky;c.fillRect(0,0,w,h);
    // 层叠山脊与斜照岩面，保留传播区域的明暗对比。
    path([[0,ground-60],[w*.12,ground-150],[w*.22,ground-104],[w*.39,ground-225],[w*.57,ground-92],[w*.7,ground-155],[w,ground-60],[w,h],[0,h]],'#1d3545');
    path([[w*.39,ground-225],[w*.44,ground-170],[w*.415,ground-179],[w*.4,ground-162],[w*.375,ground-182],[w*.35,ground-166]],'#536775');
    path([[0,ground-20],[w*.23,ground-102],[w*.34,ground-53],[w*.55,ground-133],[w*.72,ground-35],[w,ground-85],[w,h],[0,h]],'#172c37');
    path([[0,ground+8],[w*.14,ground-4],[w*.33,ground+17],[w*.6,ground+3],[w,ground+13],[w,h],[0,h]],'#14282a');
    path([[0,ground+48],[w*.25,ground+30],[w*.5,ground+56],[w*.75,ground+36],[w,ground+62],[w,h],[0,h]],'#102023');
    // 地面碎石为固定图形，不参与物理计算。
    for(let i=0;i<28;i++){const x=((i*137+29)%997)/997*w, y=ground+18+(i*23)%68;line(x,y,x+3+(i%4)*2,y-1,'#354446');}
    const rock=c.createLinearGradient(right,0,w,0);rock.addColorStop(0,'#65787c');rock.addColorStop(.2,'#34464d');rock.addColorStop(1,'#1e303b');
    path([[right,cliffTop],[right+27,cliffTop-16],[right+60,cliffTop-7],[right+94,cliffTop-36],[w,cliffTop-24],[w,ground+82],[right,ground+35]],rock);
    path([[right,cliffTop],[right+16,cliffTop+4],[right+11,ground-50],[right+23,ground+29],[right,ground+35]],'#829190');
    for(let i=0;i<6;i++){const y=cliffTop+25+i*37;path([[right+10,y],[right+43,y+7],[right+61,y-8],[w,y-18]],null,'#22353e');}
    line(right,cliffTop,right,ground+35,state.hover==='wall'||state.dragging==='wall'?gold:'#adc6c9',state.hover==='wall'?3:2);
    // 可拖动山壁手柄，触摸命中范围在 main.js 扩大。
    c.fillStyle='#101e29';c.strokeStyle='#67838d';c.lineWidth=1;c.beginPath();c.roundRect(right-14,cy-18,28,36,8);c.fill();c.stroke();
    line(right-4,cy-6,right-4,cy+6,muted,2);line(right+3,cy-6,right+3,cy+6,muted,2);
    text('反射山壁',right,cliffTop-28,ink,small?11:12,'center');text('↔ 拖动',right,cliffTop-12,muted,10,'center');
    // 发声者：同一位置发声与接收。
    const px=left-11;
    if(state.hover==='source'){circle(px,cy+28,37,'#ffc94a14');}
    circle(px,cy+4,8,'#edc6a4');
    path([[px-7,cy+16],[px+6,cy+14],[px+12,cy+40],[px-10,cy+40]],'#e2ae43');
    line(px-3,cy+40,px-9,ground,'#a0b4c2',5);line(px+5,cy+40,px+12,ground,'#a0b4c2',5);
    line(px+6,cy+21,left+9,cy+8,'#edc6a4',4);line(px-8,cy+20,px-13,cy+34,'#d0a880',4);
    line(px-13,ground,px-5,ground,'#0a121b',4);line(px+9,ground,px+18,ground,'#0a121b',4);
    text('发声 / 接收',left,ground+24,ink,11,'center');text('点击发声',left,ground+41,muted,10,'center');
    // 上方分开的两段路程，亮线只增长到已走过的位置。
    const routeY=cy-56;
    function route(y,back){const a=back?right:left,b=back?left:right,col=back?blue:gold;line(a,y,b,y,'#607a8944');let q=back?Echo.clamp((m.time-m.oneWay)/m.oneWay,0,1):Echo.clamp(m.time/m.oneWay,0,1);if(q>0){const x=a+(b-a)*q;line(a,y,x,y,col,2);path([[x,y],[x+(back?6:-6),y-3],[x+(back?6:-6),y+3]],col);}text(back?'回程 d':'去程 d',(left+right)/2,y-9,back&&m.returning?blue:back?muted:gold,11,'center');}
    route(routeY-28,false);route(routeY+10,true);
    c.save();c.beginPath();c.rect(left,cy-46,span,100);c.clip();
    if(m.time>0&&!m.arrived){const x=left+span*m.x/state.distance,col=m.returning?blue:gold;c.shadowColor=col;c.shadowBlur=12;
      for(let i=0;i<3;i++){const fx=x+(m.returning?1:-1)*i*9;c.globalAlpha=1-i*.31;c.strokeStyle=col;c.lineWidth=i?1.5:2.5;c.beginPath();c.moveTo(fx+(m.returning?9:-9),cy-32);c.quadraticCurveTo(fx+(m.returning?-12:12),cy+4,fx+(m.returning?9:-9),cy+40);c.stroke();}
    }c.restore();
    if(m.arrived){c.strokeStyle=blue;c.lineWidth=2;c.beginPath();c.arc(left-8,cy+7,23,0,Math.PI*2);c.stroke();text('已接收',left+27,cy+13,blue,11);}
    const dy=ground+66;line(left,dy,right,dy,'#7d99aa',1);line(left,dy-4,left,dy+4,muted);line(right,dy-4,right,dy+4,muted);
    const label=`单程距离  ${state.distance} m`;c.fillStyle='#0e1d27';c.fillRect((left+right)/2-62,dy-12,124,24);text(label,(left+right)/2,dy+4,ink,12,'center');
    text(`${state.temp}°C  /  声速 ${m.v.toFixed(1)} m/s`,w-22,small?112:42,muted,11,'right');
  }
  window.EchoDraw={draw,layout};
})();
