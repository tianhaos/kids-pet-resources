/* 单位：m、s、°C。计算不依赖 DOM。 */
(function () {
  'use strict';
  const presets = {
    valley: { distance: 170, temp: 15 },
    near: { distance: 10, temp: 15 },
    cold: { distance: 170, temp: -20 }
  };
  function clamp(value, min, max) { return Math.min(max, Math.max(min, value)); }
  function speed(temp) { return Math.sqrt(1.4 * 287.05 * (273.15 + temp)); }
  function solve(state) {
    const v = speed(state.temp), oneWay = state.distance / v, total = 2 * oneWay;
    const time = clamp(state.time, 0, total * 1.1);
    const travelled = Math.min(v * time, 2 * state.distance);
    return {
      v, oneWay, total, time, travelled,
      x: travelled <= state.distance ? travelled : 2 * state.distance - travelled,
      returning: time >= oneWay,
      arrived: time >= total,
      distinct: total >= 0.1,
      phase: time >= total ? '回声已返回' : time >= oneWay ? '反射后，返回中' : time === 0 ? '准备发声' : '原声，去程中'
    };
  }
  window.Echo = { presets, clamp, speed, solve };
})();
