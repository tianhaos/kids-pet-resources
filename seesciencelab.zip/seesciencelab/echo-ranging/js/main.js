(function () {
  'use strict';
  const E=window.Echo, $=id=>document.getElementById(id), params=new URLSearchParams(location.search);
  const scene=Object.hasOwn(E.presets,params.get('scene'))?params.get('scene'):'valley';
  function number(key,fallback,min,max){const raw=params.get(key);const n=raw===null?fallback:Number(raw);return Number.isFinite(n)?E.clamp(n,min,max):fallback;}
  const state={scene,distance:number('d',E.presets[scene].distance,5,500),temp:number('temp',E.presets[scene].temp,-20,40),time:0,speed:number('speed',.25,.1,1),playing:params.get('play')==='1'};
  if(state.distance!==E.presets[scene].distance||state.temp!==E.presets[scene].temp)state.scene='custom';
  state.speed=[.1,.25,1].includes(state.speed)?state.speed:.25;
  state.time=number('t',E.solve(state).total*.7,0,E.solve(state).total*1.1);
  function track(action,label){if(window.Analytics)window.Analytics.track('回声测距与声速',action,String(label));}
  function update(){
    const m=E.solve(state);
    $('distance').value=state.distance;$('temp').value=state.temp;$('progress').value=state.time/m.total;
    $('distanceOut').textContent=state.distance+' m';$('tempOut').textContent=state.temp+' °C';
    $('rD').textContent=state.distance+' m';$('rV').textContent=m.v.toFixed(1)+' m/s';$('rT').textContent=m.total.toFixed(3)+' s';$('phase').textContent=m.phase;
    $('result').textContent=m.distinct?'往返路程 '+(2*state.distance)+' m；单程 d = vt/2。':'仍有反射；往返不足约0.1 s，原声与反射声可能混在一起。';
    $('pauseStage').textContent=state.playing?'Ⅱ 暂停':'▷ 播放';
    $('stagePhase').textContent=m.phase;$('stageTime').textContent=m.time.toFixed(3);$('oneWay').textContent=m.oneWay.toFixed(3)+' s';$('totalTime').textContent=m.total.toFixed(3)+' s';
    $('stagePhase').style.color=m.returning?'#68d5ff':'#ffc94a';
    document.querySelectorAll('[data-scene]').forEach(b=>{b.classList.toggle('on',b.dataset.scene===state.scene);b.setAttribute('aria-pressed',b.dataset.scene===state.scene);});
    window.EchoDraw.draw($('echo'),state);
  }
  function fire(){state.time=0;state.playing=true;track('发声',state.scene);update();}
  function toggle(){if(!state.playing&&E.solve(state).arrived)state.time=0;state.playing=!state.playing;track('播放',state.playing);update();}
  function setScene(name){if(!E.presets[name])return;Object.assign(state,E.presets[name],{scene:name,time:0,playing:false});track('切换场景',name);update();}
  document.querySelectorAll('[data-scene]').forEach(b=>b.onclick=()=>setScene(b.dataset.scene));
  ['distance','temp'].forEach(id=>{$(id).oninput=()=>{state[id]=Number($(id).value);state.scene='custom';state.time=0;state.playing=false;update();};$(id).onchange=()=>track('改变条件',id+':'+state[id]);});
  $('progress').oninput=()=>{state.time=Number($('progress').value)*E.solve(state).total;state.playing=false;update();};
  $('progress').onchange=()=>track('进度',state.time.toFixed(3));
  $('speed').value=String(state.speed);$('speed').onchange=()=>{state.speed=Number($('speed').value);track('慢放',state.speed);};
  $('fireStage').onclick=fire;$('pauseStage').onclick=toggle;
  $('arrive').onclick=()=>{state.time=E.solve(state).total;state.playing=false;track('返回时刻',state.distance);update();};
  $('double').onclick=()=>{state.distance=Math.min(500,state.distance*2);state.scene='custom';fire();};
  $('share').onclick=async()=>{const url=new URL(location.href);url.search=new URLSearchParams({scene:state.scene,d:state.distance,temp:state.temp,t:state.time.toFixed(4),play:0,speed:state.speed}).toString();try{await navigator.clipboard.writeText(url.href);$('shareStatus').textContent='链接已复制';track('复制链接',state.scene);}catch{$('shareStatus').textContent=url.href;}};
  if(innerWidth<=760)$('panel').classList.add('collapsed');
  function panelToggle(){const closed=$('panel').classList.toggle('collapsed');$('panelToggle').setAttribute('aria-expanded',!closed);$('panelToggle').textContent=closed?'调节实验':'收起面板';}
  $('panelToggle').onclick=$('panelClose').onclick=panelToggle;
  document.addEventListener('keydown',e=>{if(e.code==='Space'&&!/INPUT|SELECT|BUTTON|TEXTAREA/.test(e.target.tagName)){e.preventDefault();toggle();}});
  const canvas=$('echo');let drag=null;
  function point(e){const r=canvas.getBoundingClientRect();return {x:e.clientX-r.left,y:e.clientY-r.top};}
  function hit(p){const g=EchoDraw.layout(canvas.clientWidth,canvas.clientHeight,state.distance);if(Math.abs(p.x-g.right)<27&&p.y>g.cliffTop-12&&p.y<g.ground+40)return 'wall';if(Math.abs(p.x-g.left)<34&&Math.abs(p.y-g.cy-22)<48)return 'source';return null;}
  canvas.onpointerdown=e=>{const p=point(e),target=hit(p);if(!target)return;canvas.setPointerCapture(e.pointerId);drag={target,x:p.x,d:state.distance};state.dragging=target;};
  canvas.onpointermove=e=>{const p=point(e);if(drag&&drag.target==='wall'){state.distance=E.clamp(Math.round(drag.d+(p.x-drag.x)/canvas.clientWidth/.37*495),5,500);state.scene='custom';state.time=0;state.playing=false;}state.hover=drag?drag.target:hit(p);canvas.style.cursor=state.hover==='wall'?(drag?'grabbing':'ew-resize'):state.hover==='source'?'pointer':'default';};
  canvas.onpointerup=e=>{if(drag?.target==='source'&&hit(point(e))==='source')fire();if(drag?.target==='wall')track('拖动山壁',state.distance);drag=null;state.dragging=null;if(canvas.hasPointerCapture(e.pointerId))canvas.releasePointerCapture(e.pointerId);};
  canvas.onpointercancel=()=>{drag=null;state.dragging=null;};canvas.onpointerleave=()=>{if(!drag)state.hover=null;};
  window.__model={state,update,setScene,fire,solve:()=>E.solve(state)};
  let last=0;
  function frame(now){const dt=last?Math.min((now-last)/1000,.05):0;last=now;if(state.playing){const total=E.solve(state).total;state.time=Math.min(total,state.time+dt*state.speed);if(state.time>=total)state.playing=false;}update();requestAnimationFrame(frame);}
  requestAnimationFrame(frame);
})();
