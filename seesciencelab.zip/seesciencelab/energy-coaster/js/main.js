(function () {
  'use strict';
  const $ = id => document.getElementById(id), query = new URLSearchParams(location.search);
  function num(key, fallback, min, max) { const raw = query.get(key); const v = raw === null || raw.trim() === '' ? fallback : Number(raw); return Number.isFinite(v) ? Math.max(min, Math.min(max, v)) : fallback; }
  const scene = query.get('scene') === 'damped' ? 'damped' : 'ideal';
  const state = Energy.create(scene, num('m', 2, 1, 5), num('x', -3.4, -3.8, 3.8));
  const ui = { velocity: true, height: true, dragging: false, hover: false, speed: num('rate', .6, .2, 1) };
  let play = false, last = 0, drawing, records = [], pointer = null;
  const initialTime = num('t', 0, 0, 120);
  for (let t = 0; t < initialTime; t += .02) Energy.step(state, Math.min(.02, initialTime - t));
  play = query.get('play') === '1';
  function track(action, label) { if (window.Analytics) Analytics.track('动能与势能：轨道小车', action, String(label)); }
  function reset(x = state.release) {
    Object.assign(state, Energy.create(state.scene, state.mass, x)); play = false; update();
  }
  function setScene(value) { state.scene = value === 'damped' ? 'damped' : 'ideal'; reset(); track('场景', state.scene); }
  function update() {
    const e = Energy.values(state);
    $('mass').value = state.mass; $('massOut').textContent = `${state.mass.toFixed(1)} kg`;
    $('release').value = state.release; $('releaseOut').textContent = `${Energy.height(state.release).toFixed(2)} m`;
    $('speed').value = ui.speed; $('speedOut').textContent = `${ui.speed.toFixed(1)}×`;
    $('play').textContent = play ? '暂停' : state.t > 0 ? '继续运动' : '释放小车';
    $('stageTime').textContent = `${state.t.toFixed(1)} s`;
    $('rHeight').textContent = `${e.h.toFixed(3)} m`; $('rSpeed').textContent = `${e.speed.toFixed(3)} m/s`;
    $('rK').textContent = `${e.ek.toFixed(3)} J`; $('rP').textContent = `${e.ep.toFixed(3)} J`;
    $('rM').textContent = `${e.em.toFixed(3)} J`; $('rQ').textContent = `${e.q.toFixed(3)} J`;
    $('rTotal').textContent = `${(e.em + e.q).toFixed(3)} J`;
    $('status').textContent = state.scene === 'ideal' ? '无阻力：动能与重力势能相互转化，机械能保持不变。' : '有阻力：机械能减少，耗散能量增加；把内能计入后总能量保持不变。';
    document.querySelectorAll('[data-scene]').forEach(b => { b.classList.toggle('on', b.dataset.scene === state.scene); b.setAttribute('aria-pressed', b.dataset.scene === state.scene); });
    drawing = EnergyDraw.draw($('coaster'), state, ui);
  }
  document.querySelectorAll('[data-scene]').forEach(b => b.addEventListener('click', () => setScene(b.dataset.scene)));
  $('play').onclick = () => { play = !play; track('播放', play); update(); };
  $('reset').onclick = () => { reset(); track('重置', state.scene); };
  $('mass').oninput = () => { state.mass = Number($('mass').value); reset(); };
  $('mass').onchange = () => track('质量', state.mass);
  $('release').oninput = () => reset(Number($('release').value));
  $('release').onchange = () => track('释放点', state.release);
  $('speed').oninput = () => { ui.speed = Number($('speed').value); update(); };
  $('speed').onchange = () => track('慢放', ui.speed);
  for (const key of ['velocity', 'height']) $(key).onchange = () => { ui[key] = $(key).checked; track('显示', key + ':' + ui[key]); update(); };
  if (matchMedia('(max-width:760px)').matches) $('panel').classList.add('collapsed');
  $('panelToggle').setAttribute('aria-expanded', String(!$('panel').classList.contains('collapsed')));
  $('panelToggle').onclick = () => $('panelToggle').setAttribute('aria-expanded', String(!$('panel').classList.toggle('collapsed')));
  $('record').onclick = () => {
    const e = Energy.values(state);
    records.unshift({ scene: state.scene, t: state.t, mass: state.mass, ...e }); records = records.slice(0, 6);
    $('records').replaceChildren(...records.map(r => {
      const p = document.createElement('p'); p.textContent = `${r.scene === 'ideal' ? '无阻' : '有阻'} · ${r.mass.toFixed(1)} kg · ${r.t.toFixed(1)} s｜h ${r.h.toFixed(2)} m，v ${r.speed.toFixed(2)} m/s｜动 ${r.ek.toFixed(2)} / 势 ${r.ep.toFixed(2)} / 内 ${r.q.toFixed(2)} J`; return p;
    })); track('记录', records.length);
  };
  $('clear').onclick = () => { records = []; $('records').replaceChildren(); track('清空记录', ''); };
  function shareURL() {
    const url = new URL(location.href); url.search = '';
    // 从相同释放点积分到相同时间，恢复全部运动与耗散状态。
    const params = { scene: state.scene, m: state.mass, x: state.release, t: state.t.toFixed(6), play: 0, rate: ui.speed };
    Object.entries(params).forEach(([k, v]) => url.searchParams.set(k, v)); return url.href;
  }
  $('share').onclick = async () => {
    play = false; update(); const url = shareURL();
    try { await navigator.clipboard.writeText(url); $('shareNote').textContent = '已复制当前条件与暂停时刻链接。'; }
    catch { $('shareNote').textContent = url; }
    track('分享', state.scene);
  };
  const canvas = $('coaster');
  function point(ev) { const r = canvas.getBoundingClientRect(); return { x: ev.clientX - r.left, y: ev.clientY - r.top }; }
  function hit(p) { return drawing && Math.hypot(p.x - drawing.car.x, p.y - drawing.car.y) <= 38; }
  canvas.onpointerdown = ev => {
    if (!hit(point(ev))) return;
    pointer = ev.pointerId; canvas.setPointerCapture(pointer); ui.dragging = true; canvas.style.cursor = 'grabbing'; play = false; ev.preventDefault(); update();
  };
  canvas.onpointermove = ev => {
    const p = point(ev);
    if (ui.dragging && pointer === ev.pointerId) {
      const l = drawing.layout, x = Math.max(-3.8, Math.min(3.8, (p.x - l.cx) / l.sx));
      reset(x);
    } else { ui.hover = hit(p); canvas.style.cursor = ui.hover ? 'grab' : 'default'; }
  };
  function end(ev) {
    if (pointer !== ev.pointerId) return;
    ui.dragging = false; pointer = null; canvas.style.cursor = 'grab'; track('拖动小车', state.release.toFixed(2)); update();
  }
  canvas.onpointerup = end; canvas.onpointercancel = end;
  canvas.onpointerleave = () => { ui.hover = false; };
  window.addEventListener('keydown', ev => {
    if (ev.code !== 'Space' || /INPUT|BUTTON|TEXTAREA|SELECT/.test(ev.target.tagName) || ev.target.isContentEditable) return;
    ev.preventDefault(); $('play').click();
  });
  function frame(now) {
    if (play && !ui.dragging) {
      Energy.step(state, Math.min(120 - state.t, Math.min((now - (last || now)) / 1000, .05) * ui.speed));
      if (state.t >= 120 - 1e-8) { state.t = 120; play = false; }
    }
    last = now; update(); requestAnimationFrame(frame);
  }
  window.__model = { state, ui, update, reset, setScene, values: () => Energy.values(state), advance: seconds => { play = false; Energy.step(state, Math.max(0, Math.min(120, seconds))); update(); }, setPlay: value => { play = !!value; }, shareURL, getDrawing: () => drawing, getRecords: () => records.slice() };
  update(); requestAnimationFrame(frame);
})();
