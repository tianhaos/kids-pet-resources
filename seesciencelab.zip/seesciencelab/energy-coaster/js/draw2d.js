/* 轨道、车体和能量账本；世界坐标不依赖屏幕比例。 */
(function () {
  'use strict';
  const C = { gold: '#ffc94a', blue: '#63cafa', heat: '#fb9672', text: '#e4edf4', muted: '#96b2c2' };
  function layout(w, h) {
    const compact = w < 600, top = h < 560 ? 115 : 158;
    const trackBottom = Math.max(top + 80, h - 302), plotY = h - 240;
    const sx = (w - (compact ? 86 : 150)) / 8;
    const sy = (trackBottom - top) / 2.4;
    return { w, h, compact, top, plotY, sx, sy, cx: w / 2, bottom: trackBottom,
      point(x) { return { x: w / 2 + x * sx, y: trackBottom - Energy.height(x) * sy }; } };
  }
  function text(c, str, x, y, size = 14, color = C.text, align = 'left') {
    c.fillStyle = color; c.font = `${size}px -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif`;
    c.textAlign = align; c.fillText(str, x, y);
  }
  function line(c, x1, y1, x2, y2, color, width = 1, dash = []) {
    c.beginPath(); c.setLineDash(dash); c.strokeStyle = color; c.lineWidth = width;
    c.moveTo(x1, y1); c.lineTo(x2, y2); c.stroke(); c.setLineDash([]);
  }
  function arrow(c, x, y, dx, dy, color) {
    const len = Math.hypot(dx, dy); if (len < 2) return;
    line(c, x, y, x + dx, y + dy, color, 3);
    const t = Math.atan2(dy, dx);
    c.beginPath(); c.moveTo(x + dx, y + dy);
    c.lineTo(x + dx - 9 * Math.cos(t - .5), y + dy - 9 * Math.sin(t - .5));
    c.lineTo(x + dx - 9 * Math.cos(t + .5), y + dy - 9 * Math.sin(t + .5)); c.closePath(); c.fillStyle = color; c.fill();
  }
  function cart(c, p, angle, t, active) {
    c.save(); c.translate(p.x, p.y); c.rotate(angle);
    // 两轮与轨道接触，车厢底部随轨道切线倾斜。
    c.shadowColor = active ? '#ffc94a' : '#14202a'; c.shadowBlur = active ? 22 : 8;
    const body = c.createLinearGradient(0, -30, 0, -9); body.addColorStop(0, '#ffe195'); body.addColorStop(1, '#d59b2c');
    c.fillStyle = body; c.strokeStyle = '#ffe4a0'; c.lineWidth = 1.5;
    c.beginPath(); c.roundRect(-23, -30, 46, 21, [4, 4, 8, 8]); c.fill(); c.stroke(); c.shadowBlur = 0;
    c.fillStyle = '#163744'; c.fillRect(-12, -27, 10, 9); c.fillRect(4, -27, 10, 9);
    for (const x of [-14, 14]) {
      c.beginPath(); c.arc(x, -6, 6, 0, Math.PI * 2); c.fillStyle = '#182b38'; c.fill(); c.strokeStyle = '#c7e3e9'; c.stroke();
      line(c, x - 4 * Math.cos(t), -6 - 4 * Math.sin(t), x + 4 * Math.cos(t), -6 + 4 * Math.sin(t), '#879da6', 1.2);
    }
    c.restore();
  }
  function draw(canvas, st, ui) {
    const w = canvas.clientWidth, h = canvas.clientHeight, dpr = window.devicePixelRatio || 1;
    if (canvas.width !== Math.round(w * dpr) || canvas.height !== Math.round(h * dpr)) { canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr); }
    const c = canvas.getContext('2d'); c.setTransform(dpr, 0, 0, dpr, 0, 0);
    const l = layout(w, h), e = Energy.values(st), p = l.point(e.x), start = l.point(st.release);
    c.fillStyle = '#05070d'; c.fillRect(0, 0, w, h);
    const glow = c.createRadialGradient(l.cx, l.bottom, 0, l.cx, l.bottom, w * .62);
    glow.addColorStop(0, '#152b3d88'); glow.addColorStop(1, '#05070d00');
    c.fillStyle = glow; c.fillRect(0, 80, w, l.bottom + 30);
    text(c, '动能与势能的接力', 24, 37, l.compact ? 16 : 18);
    text(c, st.scene === 'ideal' ? '无阻力 / 机械能保持不变' : '有阻力 / 机械能逐渐转化为内能', 24, 62, 11, C.muted);
    const phase = ui.dragging ? '正在设置释放点' : e.speed < .08 ? (st.t < .01 ? '准备就绪 · 点击释放' : Math.abs(e.x) < .08 ? '最低点附近 · 接近静止' : '转向附近 · 速率接近零') : Math.abs(e.x) < .04 ? '最低点附近 · 势能接近零' : e.x * st.v < 0 ? '下坡 · 势能转化为动能' : '上坡 · 动能转化为势能';
    text(c, phase, l.cx, 105, 12, e.speed < .08 ? C.muted : C.gold, 'center');
    // 低对比度的刻度与桁架表达真实装置，避免背景抢夺运动焦点。
    for (let ht = .5; ht <= 2; ht += .5) {
      const y = l.bottom - ht * l.sy;
      line(c, 32, y, w - 32, y, '#7eabc215', 1);
      text(c, `${ht.toFixed(1)}`, 17, y + 4, 10, '#567082');
    }
    line(c, 32, l.bottom, w - 32, l.bottom, '#aacdd33b', 1, [4, 5]);
    text(c, '最低点 · h = 0', l.cx, l.bottom + 41, 11, C.muted, 'center');
    const floor = l.bottom + 23;
    line(c, 35, floor, w - 35, floor, '#44607266', 2);
    for (let x = -3.6; x <= 3.7; x += .6) {
      const p1 = l.point(x), next = l.point(Math.min(x + .6, 3.8));
      line(c, p1.x, p1.y + 10, p1.x, floor, '#365063', 2);
      line(c, p1.x, floor, next.x, next.y + 10, '#23394c', 1);
      line(c, p1.x - 7, floor, p1.x + 7, floor, '#6d899d', 2);
    }
    for (const [offset, col, width] of [[9, '#182b3d', 10], [5, '#58748a', 4], [0, '#c4dce8', 2.5]]) {
      c.beginPath(); for (let x = -4; x <= 4.001; x += .025) { const z = l.point(x); x === -4 ? c.moveTo(z.x, z.y + offset) : c.lineTo(z.x, z.y + offset); }
      c.strokeStyle = col; c.lineWidth = width; c.stroke();
    }
    line(c, 32, start.y, w - 32, start.y, '#63cafa65', 1, [5, 5]);
    // 中心标注与两侧转向的小车分开；低释放点时标签上移。
    text(c, `释放高度 ${Energy.height(st.release).toFixed(2)} m`, l.cx, start.y - (Math.abs(st.release) < 1.6 ? 65 : 14), 11, C.blue, 'center');
    c.beginPath(); c.arc(start.x, start.y, 4, 0, 7); c.fillStyle = C.blue; c.fill();
    if (ui.height) {
      const hx = p.x + (e.x > 0 ? -1 : 1) * (l.compact ? 54 : 46);
      line(c, hx, p.y, hx, l.bottom, C.blue, 1, [3, 3]);
      line(c, hx - 4, p.y, hx + 4, p.y, C.blue); line(c, hx - 4, l.bottom, hx + 4, l.bottom, C.blue);
      if (e.h > .15) text(c, `${e.h.toFixed(2)} m`, hx + (e.x > 0 ? -7 : 7), (p.y + l.bottom) / 2, 11, C.blue, e.x > 0 ? 'right' : 'left');
    }
    const slopeScreen = -2 * .15 * e.x * l.sy / l.sx;
    cart(c, p, Math.atan(slopeScreen), st.s * 8, ui.dragging || ui.hover);
    if (ui.velocity && e.speed > .08) {
      const sign = Math.sign(st.v), angle = Math.atan(slopeScreen), len = 18 + Math.min(e.speed * 9, 55);
      arrow(c, p.x, p.y - 48, sign * len * Math.cos(angle), sign * len * Math.sin(angle), C.blue);
    }
    text(c, `速率 ${e.speed.toFixed(2)} m/s`, 24, l.plotY + 4, l.compact ? 13 : 15, C.text);
    text(c, ui.dragging ? '松手后点击释放' : '↔ 拖动小车设置高度', w - 24, l.plotY + 4, 11, C.muted, 'right');
    const boxX = 18, boxY = l.plotY + 20, bw = w - 36;
    c.fillStyle = '#0d1521'; c.strokeStyle = '#263346'; c.lineWidth = 1;
    c.beginPath(); c.roundRect(boxX, boxY, bw, 140, 12); c.fill(); c.stroke();
    const rowH = 25, left = boxX + (l.compact ? 91 : 110), usable = bw - (l.compact ? 170 : 205);
    const max = Math.max(e.e0, 0.01);
    const rows = [['动能 Eₖ', e.ek, C.gold], ['重力势能 Eₚ', e.ep, C.blue], ['耗散 → 内能', e.q, C.heat]];
    rows.forEach(([name, val, col], i) => {
      const yy = boxY + 27 + i * rowH;
      text(c, name, boxX + 14, yy, 11, col);
      c.fillStyle = '#202c3b'; c.beginPath(); c.roundRect(left, yy - 9, usable, 8, 4); c.fill();
      const bar = usable * Math.max(0, Math.min(1, val / max));
      if (bar > .1) { c.fillStyle = col; c.beginPath(); c.roundRect(left, yy - 9, bar, 8, Math.min(4, bar / 2)); c.fill(); }
      text(c, `${val.toFixed(2)} J`, boxX + bw - 14, yy, 11, '#d8e5f3', 'right');
    });
    line(c, boxX + 14, boxY + 91, boxX + bw - 14, boxY + 91, '#263346');
    text(c, `机械能 ${e.em.toFixed(2)} J`, boxX + 14, boxY + 112, 11, C.text);
    text(c, `合计 ${(e.em + e.q).toFixed(2)} J`, boxX + bw - 14, boxY + 112, 11, C.text, 'right');
    text(c, '共用刻度 · 上限为本次初始能量', boxX + 14, boxY + 130, 10, '#7489a2');
    return { layout: l, car: { x: p.x, y: p.y - 17 }, values: e };
  }
  window.EnergyDraw = { draw, layout };
})();
