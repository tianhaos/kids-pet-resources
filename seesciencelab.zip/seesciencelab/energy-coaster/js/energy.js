/* 弧形轨道上的质点：SI单位，s为从最低点起向右的有符号弧长。 */
(function () {
  'use strict';
  const g = 10, a = 0.15;
  function height(x) { return a * x * x; }
  function arc(x) {
    const z = 2 * a * x;
    return (z * Math.sqrt(1 + z * z) + Math.asinh(z)) / (4 * a);
  }
  function xAt(s) {
    let x = s / 1.2;
    for (let i = 0; i < 8; i++) x -= (arc(x) - s) / Math.sqrt(1 + 4 * a * a * x * x);
    return x;
  }
  function create(scene, mass, release) {
    return { scene, mass, release, s: arc(release), v: 0, q: 0, t: 0 };
  }
  function values(st) {
    const x = xAt(st.s), h = height(x), ep = st.mass * g * h;
    const ek = 0.5 * st.mass * st.v * st.v, e0 = st.mass * g * height(st.release);
    return { x, h, ep, ek, em: ep + ek, q: st.q, e0, speed: Math.abs(st.v), error: ep + ek + st.q - e0 };
  }
  function deriv(y, mass, gamma) {
    const x = xAt(y[0]), slope = 2 * a * x;
    return [y[1], -g * slope / Math.sqrt(1 + slope * slope) - gamma * y[1], mass * gamma * y[1] * y[1]];
  }
  function step(st, dt) {
    // 四阶RK；固定不大于1/240秒的子步，热量独立积分，不用总能量倒算掩盖误差。
    const n = Math.ceil(dt * 240), h = dt / n, gamma = st.scene === 'damped' ? 0.32 : 0;
    for (let i = 0; i < n; i++) {
      const y = [st.s, st.v, st.q], k1 = deriv(y, st.mass, gamma);
      const shifted = (k, factor) => y.map((v, j) => v + h * factor * k[j]);
      const k2 = deriv(shifted(k1, 0.5), st.mass, gamma);
      const k3 = deriv(shifted(k2, 0.5), st.mass, gamma);
      const k4 = deriv(shifted(k3, 1), st.mass, gamma);
      const out = y.map((v, j) => v + h * (k1[j] + 2 * k2[j] + 2 * k3[j] + k4[j]) / 6);
      [st.s, st.v, st.q] = out;
      st.t += h;
    }
    return st;
  }
  window.Energy = { g, height, arc, xAt, create, values, step };
})();
