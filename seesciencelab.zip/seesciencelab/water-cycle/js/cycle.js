(function () {
  'use strict';

  const processes = {
    evaporation: { title: '蒸发', color: '#f4c782' },
    condensation: { title: '凝结', color: '#d6ecf8' },
    transport: { title: '水汽输送', color: '#b3daf8' },
    rain: { title: '降水', color: '#87d7ff' },
    runoff: { title: '地表径流', color: '#43cafa' },
    infiltration: { title: '下渗', color: '#84e5c3' },
    groundwater: { title: '地下径流', color: '#84e5c3' },
  };

  const landReturn = ['rain', 'runoff', 'infiltration', 'groundwater'];
  const scenes = {
    coast: {
      title: '海陆间循环',
      source: '海洋',
      destination: '陆地',
      summary: '海洋蒸发，水汽输送到陆地。部分陆地降水经河流或地下途径回到海洋。',
      steps: ['evaporation', 'transport', 'condensation', ...landReturn],
    },
    sea: {
      title: '海上内循环',
      source: '海洋',
      destination: '海洋',
      summary: '水从海洋进入大气，又以降水回到海洋。这条路径只经过海洋和上方大气。',
      steps: ['evaporation', 'condensation', 'rain'],
    },
    inland: {
      title: '陆地内循环',
      source: '内陆湖',
      destination: '陆地',
      summary: '内陆湖蒸发的水在陆地上空凝结并降回流域，地表和地下水可汇入湖泊。',
      steps: ['evaporation', 'transport', 'condensation', ...landReturn],
    },
  };

  const rainfall = 40;
  const tiling = { permeable: 26, paved: 3 };

  function partition(pavedPercent) {
    const percent = Math.min(100, Math.max(0, Number(pavedPercent) || 0));
    const fraction = percent / 100;
    const infiltration = Math.round((tiling.permeable * (1 - fraction) + tiling.paved * fraction) * 100) / 100;
    return { rain: rainfall, infiltration, runoff: Math.round((rainfall - infiltration) * 100) / 100 };
  }

  function explain(id, scene) {
    const { source, destination } = scenes[scene];
    return {
      evaporation: `${source}表面的液态水变成水汽进入空气。画面上升的光点代表看不见的水汽。`,
      transport: '气流把水汽带向流域上空。沿亮蓝色虚线看水汽移动，观察下雨地点和蒸发地点的位置。',
      condensation: '湿空气冷却，部分水汽凝结成小水滴，云就会形成。云中也可以有冰晶。',
      rain: `云中的水滴或冰晶长到足够大，就可能以雨雪等形式落下。画面的雨落向${destination}。`,
      runoff: `部分雨水沿坡面汇进河道，再流向${source}。试着增加硬化地面，比较河道和地下的分流。`,
      infiltration: '一部分雨水穿过地面进入土壤。硬化面积越大，本实验中进入土壤的水越少；下渗水可以先留在土壤里。',
      groundwater: `补给地下水的那部分下渗水可沿含水层缓慢流动，排入河湖或海洋。图中示意向${source}排泄的路径。`,
    }[id];
  }

  function sceneKey(value) {
    return Object.hasOwn(scenes, value) ? value : 'coast';
  }

  window.WaterCycle = { processes, scenes, partition, explain, sceneKey };
})();
