(function () {
  'use strict';

  const { processes, partition } = window.WaterCycle;
  const width = 800;
  const height = 500;
  const tau = 2 * Math.PI;

  // 单段三次曲线，按弧长采样后让示踪点保持均匀间距。
  function route(controls) {
    let distance = 0;
    const samples = [];
    for (let i = 0; i <= 60; i++) {
      const t = i / 60;
      const weights = [(1 - t) ** 3, 3 * (1 - t) ** 2 * t, 3 * (1 - t) * t * t, t ** 3];
      const x = controls.reduce((sum, point, index) => sum + point[0] * weights[index], 0);
      const y = controls.reduce((sum, point, index) => sum + point[1] * weights[index], 0);
      if (i) distance += Math.hypot(x - samples[i - 1].x, y - samples[i - 1].y);
      samples.push({ x, y, distance });
    }
    const at = fraction => {
      const d = distance * fraction;
      const index = samples.findIndex((p, i) => i > 0 && p.distance >= d);
      const a = samples[index > 0 ? index - 1 : 59];
      const b = samples[index > 0 ? index : 60];
      const f = (d - a.distance) / (b.distance - a.distance);
      return { x: a.x + (b.x - a.x) * f, y: a.y + (b.y - a.y) * f, angle: Math.atan2(b.y - a.y, b.x - a.x) };
    };
    const path = new Path2D();
    path.moveTo(...controls[0]);
    path.bezierCurveTo(...controls[1], ...controls[2], ...controls[3]);
    return { at, path, distance };
  }

  const paths = {
    evaporation: route([[178, 346], [155, 251], [140, 180], [228, 153]]),
    marineEvaporation: route([[119, 346], [96, 222], [126, 141], [247, 149]]),
    transport: route([[229, 153], [302, 92], [433, 93], [532, 128]]),
    rain: route([[591, 166], [594, 202], [585, 249], [575, 292]]),
    marineRain: route([[287, 168], [301, 223], [291, 294], [282, 347]]),
    infiltration: route([[609, 309], [604, 345], [605, 387], [587, 425]]),
    groundwater: route([[591, 426], [509, 437], [419, 455], [305, 432]]),
  };

  // 河流折线与底图的河床中心线对齐，示踪点沿真实示意河道前进。
  const river = [
    [[639, 274], [610, 286], [595, 294], [583, 307]],
    [[583, 307], [565, 326], [532, 311], [516, 324]],
    [[516, 324], [496, 340], [494, 347], [472, 345]],
    [[472, 345], [450, 343], [422, 339], [401, 349]],
    [[401, 349], [380, 359], [341, 360], [315, 366]],
  ].map(route);
  const riverLength = river.reduce((length, segment) => length + segment.distance, 0);
  const riverPath = new Path2D();
  river.forEach(segment => riverPath.addPath(segment.path));
  function riverAt(fraction) {
    let distance = fraction * riverLength;
    for (const segment of river) {
      if (distance <= segment.distance) return segment.at(distance / segment.distance);
      distance -= segment.distance;
    }
    return river[river.length - 1].at(1);
  }

  const labels = {
    coast: {
      evaporation: [108, 225],
      transport: [369, 74],
      condensation: [581, 91],
      rain: [661, 176],
      runoff: [455, 298],
      infiltration: [659, 359],
      groundwater: [476, 471],
    },
    sea: {
      evaporation: [70, 222],
      condensation: [276, 93],
      rain: [352, 229],
    },
  };
  labels.inland = labels.coast;

  function arrow(ctx, { x, y, angle }, size) {
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(angle);
    ctx.beginPath();
    ctx.moveTo(-size * .81, -size * .53);
    ctx.lineTo(0, 0);
    ctx.lineTo(-size * .81, size * .53);
    ctx.stroke();
    ctx.restore();
  }

  function flow(ctx, id, channel, state, { speed, count, arrows, size = 2.5, dash = [] }) {
    const { color } = processes[id];
    const focused = state.focus === id;
    ctx.save();
    ctx.strokeStyle = color;
    ctx.fillStyle = color;
    ctx.globalAlpha = focused ? .92 : .55;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.lineWidth = focused ? 2.8 : 1.7;
    ctx.setLineDash(dash);
    ctx.stroke(channel.path);
    ctx.setLineDash([]);
    for (const fraction of arrows) arrow(ctx, channel.at(fraction), 11);
    ctx.globalAlpha = focused ? 1 : .9;
    for (let i = 0; i < count; i++) {
      const t = (state.time * speed + (i + .45) / count) % 1;
      const { x, y } = channel.at(t);
      ctx.globalAlpha = Math.min(t * 16, (1 - t) * 16, 1) * (focused ? 1 : .82);
      ctx.beginPath();
      ctx.arc(x, y, focused ? size + .5 : size, 0, tau);
      ctx.fill();
    }
    ctx.restore();
  }

  const cloudPuffs = [
    [-49, 8, 20], [-28, -2, 25], [-4, -12, 33], [27, -3, 28], [50, 9, 19],
  ];

  function cloud(ctx, x, y, state) {
    ctx.save();
    ctx.translate(x, y);
    const glow = ctx.createRadialGradient(0, 0, 12, 0, 0, 93);
    glow.addColorStop(0, 'rgba(146,194,224,.33)');
    glow.addColorStop(1, 'rgba(146,194,224,0)');
    ctx.fillStyle = glow;
    ctx.fillRect(-95, -95, 190, 190);
    if (state.focus === 'condensation') {
      ctx.shadowColor = '#d6ecf8';
      ctx.shadowBlur = 16;
    }
    const base = ctx.createLinearGradient(0, -40, 0, 24);
    base.addColorStop(0, '#e5f0f3');
    base.addColorStop(.6, '#aec6d9');
    base.addColorStop(1, '#66849d');
    ctx.fillStyle = base;
    ctx.beginPath();
    ctx.moveTo(-66, 16);
    ctx.bezierCurveTo(-76, 4, -68, -11, -50, -11);
    ctx.bezierCurveTo(-45, -29, -31, -33, -17, -29);
    ctx.bezierCurveTo(-4, -56, 25, -49, 35, -26);
    ctx.bezierCurveTo(54, -31, 66, -18, 65, -6);
    ctx.bezierCurveTo(86, 7, 70, 28, 49, 26);
    ctx.lineTo(-41, 26);
    ctx.quadraticCurveTo(-61, 25, -66, 16);
    ctx.fill();
    ctx.shadowBlur = 0;
    for (const [px, py, radius] of cloudPuffs) {
      const light = ctx.createRadialGradient(px - 5, py - 7, 1, px, py, radius);
      light.addColorStop(0, 'rgba(247,251,249,.64)');
      light.addColorStop(1, 'rgba(230,244,248,0)');
      ctx.fillStyle = light;
      ctx.fillRect(px - radius, py - radius, radius * 2, radius * 2);
    }
    ctx.restore();
  }

  function showers(ctx, x, sea, state) {
    ctx.save();
    ctx.strokeStyle = '#9be0fc';
    ctx.lineWidth = state.focus === 'rain' ? 2.2 : 1.55;
    ctx.lineCap = 'round';
    for (let i = 0; i < 36; i++) {
      const column = (i * 31 % 37) / 36;
      const t = (i * .271 + state.time * (.64 + i % 4 * .054)) % 1;
      const length = 8 + i % 5;
      const start = sea ? 168 : 154;
      const bottom = sea ? 347 : 295 - 18 * column;
      const px = x + (column - .5) * 104 + t * 13;
      const py = start + t * (bottom - start - length);
      ctx.globalAlpha = Math.min(t * 10, (1 - t) * 10, .28 + (i % 5) * .12);
      ctx.beginPath();
      ctx.moveTo(px - 2, py);
      ctx.lineTo(px + 2, py + length);
      ctx.stroke();
    }
    ctx.restore();
  }

  function lakeshore(ctx) {
    const bank = new Path2D('M0 315 Q52 312 78 335 Q104 353 126 369 Q143 389 173 410 Q200 435 246 440 Q284 443 329 428 L355 500 H0Z');
    const soil = ctx.createLinearGradient(0, 320, 0, 500);
    soil.addColorStop(0, '#44684c');
    soil.addColorStop(.33, '#38352e');
    soil.addColorStop(1, '#1a212b');
    ctx.fillStyle = soil;
    ctx.fill(bank);
    ctx.strokeStyle = '#7d9472';
    ctx.lineWidth = 2;
    ctx.stroke(new Path2D('M0 315Q52 312 78 335Q104 353 126 369Q143 389 173 410Q200 435 246 440Q284 443 329 428'));
    ctx.fillStyle = '#86a886';
    ctx.globalAlpha = .36;
    for (let i = 0; i < 54; i++) {
      const x = (i * 53) % 315;
      const y = 452 + i * 23 % 44;
      ctx.fillRect(x, y, 2 + i % 4, 1);
    }
    ctx.globalAlpha = 1;
  }

  function plotSurface(ctx, paved) {
    // 下渗入口附近的整块样地随硬化比例逐步变为铺装。
    ctx.save();
    ctx.transform(1, -.23, .67, 1, 599, 300);
    ctx.fillStyle = '#477251';
    ctx.strokeStyle = '#9ab18b';
    ctx.lineWidth = 1;
    ctx.fillRect(0, 0, 98, 13);
    const cover = 98 * paved / 100;
    ctx.fillStyle = '#788b94';
    ctx.fillRect(0, 0, cover, 13);
    ctx.strokeStyle = '#526673';
    for (let x = 12; x < cover; x += 12) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, 13);
      ctx.stroke();
    }
    ctx.strokeStyle = '#91a59b';
    ctx.strokeRect(0, 0, 98, 13);
    ctx.restore();
  }

  function draw(ctx, state) {
    const sea = state.scene === 'sea';
    const { rain, infiltration, runoff } = partition(state.paved);
    ctx.clearRect(0, 0, width, height);
    if (state.scene === 'inland') lakeshore(ctx);
    if (sea) {
      const shade = ctx.createLinearGradient(348, 0, 480, 0);
      shade.addColorStop(0, 'rgba(4,9,18,0)');
      shade.addColorStop(1, 'rgba(4,9,18,.39)');
      ctx.fillStyle = shade;
      ctx.fillRect(348, 0, width - 348, height);
    }
    if (!sea) plotSurface(ctx, state.paved);
    showers(ctx, sea ? 282 : 582, sea, state);
    flow(ctx, 'evaporation', sea ? paths.marineEvaporation : paths.evaporation, state, {
      speed: .23, count: 8, arrows: [.53, .86], dash: [4, 7],
    });
    if (!sea) {
      flow(ctx, 'transport', paths.transport, state, {
        speed: .22, count: 9, arrows: [.39, .73], dash: [8, 8],
      });
    }
    cloud(ctx, sea ? 282 : 581, sea ? 148 : 136, state);
    flow(ctx, 'rain', sea ? paths.marineRain : paths.rain, state, {
      speed: .67, count: 5, arrows: [.53, .79], size: 1.8,
    });
    if (sea) return;
    flow(ctx, 'runoff', { path: riverPath, at: riverAt }, state, {
      speed: .48, count: 4 + Math.round(16 * runoff / rain), arrows: [.22, .56, .88], size: 2.7,
    });
    flow(ctx, 'infiltration', paths.infiltration, state, {
      speed: .25, count: Math.max(1, Math.round(12 * infiltration / rain)), arrows: [.44, .8], dash: [4, 5],
    });
    flow(ctx, 'groundwater', paths.groundwater, state, {
      speed: .13, count: 2, arrows: [.42, .76], dash: [8, 6],
    });
  }

  window.CycleDraw = { width, height, draw, labels };
})();
