(function () {
  'use strict';

  const { processes, scenes, explain, partition, sceneKey } = window.WaterCycle;
  const { width, height, labels, draw } = window.CycleDraw;
  const $ = id => document.getElementById(id);
  const canvas = $('section');
  const ctx = canvas.getContext('2d');
  const mobile = matchMedia('(max-width: 760px)');
  const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)');
  const params = new URLSearchParams(location.search);
  const state = {
    scene: sceneKey(params.get('scene')),
    paved: Math.round(Math.max(0, Math.min(100, Number(params.get('paved')) || 0))),
    focus: null,
    time: .9,
    playing: !reducedMotion.matches,
  };

  function track(action, value) {
    window.Analytics?.track('水循环', action, value);
  }

  const buttons = {};
  for (const [id, data] of Object.entries(processes)) {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'process-btn';
    button.style.setProperty('--tone', data.color);
    button.dataset.process = id;
    const text = document.createElement('span');
    text.textContent = data.title;
    button.append(text);
    button.addEventListener('click', () => {
      setFocus(state.focus === id ? null : id);
      if (state.focus) track('点选环节', data.title);
    });
    buttons[id] = button;
  }

  function pressed(button, active) {
    button.classList.toggle('on', active);
    button.setAttribute('aria-pressed', active);
  }

  function updateInfo() {
    const current = scenes[state.scene];
    $('processTitle').textContent = state.focus ? processes[state.focus].title : '点选画面中的环节';
    $('processText').textContent = state.focus ? explain(state.focus, state.scene) : current.summary;
    for (const id of current.steps) pressed(buttons[id], state.focus === id);
  }

  function setFocus(id) {
    state.focus = scenes[state.scene].steps.includes(id) ? id : null;
    updateInfo();
    paint();
  }

  function setScene(id) {
    state.scene = sceneKey(id);
    state.focus = null;
    const current = scenes[state.scene];
    $('sceneTitle').textContent = current.title;
    $('waterBody').textContent = current.source;
    const isSea = state.scene === 'sea';
    $('landExperiment').hidden = isSea;
    $('seaInfo').hidden = !isSea;
    for (const button of $('sceneSelect').querySelectorAll('button')) {
      pressed(button, button.dataset.scene === state.scene);
    }
    $('steps').replaceChildren(...current.steps.map(key => {
      const button = buttons[key];
      const [x, y] = labels[state.scene][key];
      button.style.left = `${100 * x / width}%`;
      button.style.top = `${100 * y / height}%`;
      return button;
    }));
    updateInfo();
    paint();
  }

  function setPaved(value) {
    state.paved = Math.round(Math.min(100, Math.max(0, Number(value) || 0)));
    $('paved').value = state.paved;
    $('pavedValue').textContent = `${state.paved}%`;
    const { rain, runoff, infiltration } = partition(state.paved);
    $('runoffBar').style.width = `${100 * runoff / rain}%`;
    $('budget').setAttribute('aria-label', `地表径流 ${runoff} 毫米，下渗 ${infiltration} 毫米`);
    $('runoffValue').textContent = `${runoff} mm`;
    $('infiltrationValue').textContent = `${infiltration} mm`;
    for (const button of $('samplePresets').querySelectorAll('button')) {
      pressed(button, Number(button.dataset.paved) === state.paved);
    }
    paint();
  }

  function setPlaying(playing) {
    state.playing = playing;
    $('play').textContent = playing ? '暂停动画' : '播放动画';
    paint();
  }

  function setPanel(open) {
    const panel = $('panel');
    if (!open && mobile.matches && panel.contains(document.activeElement)) $('panelToggle').focus();
    panel.inert = !open && mobile.matches;
    panel.classList.toggle('collapsed', !open && mobile.matches);
    $('panelToggle').setAttribute('aria-expanded', open);
    $('panelToggle').textContent = open ? '收起面板' : '实验面板';
  }

  function paint() {
    ctx.setTransform(canvas.width / width, 0, 0, canvas.height / height, 0, 0);
    draw(ctx, state);
  }

  new ResizeObserver(() => {
    const rect = canvas.getBoundingClientRect();
    const ratio = Math.min(devicePixelRatio || 1, 2.5);
    canvas.width = Math.max(1, Math.round(rect.width * ratio));
    canvas.height = Math.max(1, Math.round(rect.height * ratio));
    paint();
  }).observe(canvas);
  for (const button of $('sceneSelect').querySelectorAll('button')) {
    button.addEventListener('click', () => {
      if (state.scene === button.dataset.scene) return;
      setScene(button.dataset.scene);
      track('切换场景', scenes[state.scene].title);
    });
  }
  $('paved').addEventListener('input', event => setPaved(event.target.value));
  $('paved').addEventListener('change', () => track('调整地面硬化', String(state.paved)));
  $('samplePresets').addEventListener('click', event => {
    const button = event.target.closest('[data-paved]');
    if (!button) return;
    setPaved(button.dataset.paved);
    track('选择样地', button.textContent);
  });
  $('play').addEventListener('click', () => setPlaying(!state.playing));
  reducedMotion.addEventListener('change', event => setPlaying(!event.matches));
  $('panelToggle').addEventListener('click', () => setPanel($('panel').classList.contains('collapsed')));
  mobile.addEventListener('change', () => setPanel(!mobile.matches));
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape' && mobile.matches && !$('panel').classList.contains('collapsed')) setPanel(false);
  });

  setScene(state.scene);
  setPaved(state.paved);
  setPlaying(state.playing);
  setPanel(!mobile.matches);
  let lastTime = 0;
  function animate(now) {
    if (state.playing) {
      state.time += Math.min((now - (lastTime || now)) / 1000, .06);
      paint();
    }
    lastTime = now;
    requestAnimationFrame(animate);
  }
  requestAnimationFrame(animate);
  window.__model = { state, setScene, setPaved, setFocus, setPlaying, partition };
})();
