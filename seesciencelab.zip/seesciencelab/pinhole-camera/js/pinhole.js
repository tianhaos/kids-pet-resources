/* 小孔成像的几何计算。长度统一为 cm；孔宽的界面单位另转为 mm。 */
(function () {
  'use strict';
  const LIMITS = { obj: [-16, 8], hole: [20, 32], screen: [40, 56], diameter: [1, 12] };
  const PRESETS = {
    geometry: { obj: 0, hole: 24, screen: 40, diameter: 1, shape: 'circle', object: 'candle' },
    shape: { obj: 0, hole: 24, screen: 40, diameter: 1, shape: 'triangle', object: 'letter' },
    point: { obj: 0, hole: 24, screen: 40, diameter: 12, shape: 'triangle', object: 'point' }
  };
  function clamp(value, lo, hi) { return Math.max(lo, Math.min(hi, value)); }
  function number(value, fallback, range) {
    const n = Number(value);
    return Number.isFinite(n) ? clamp(n, range[0], range[1]) : fallback;
  }
  function normalize(state) {
    const scene = Object.hasOwn(PRESETS, state.scene) ? state.scene : 'geometry';
    const preset = PRESETS[scene], out = { scene };
    Object.keys(LIMITS).forEach(key => { out[key] = number(state[key] ?? preset[key], preset[key], LIMITS[key]); });
    out.shape = ['circle', 'square', 'triangle'].includes(state.shape) ? state.shape : preset.shape;
    out.object = ['candle', 'letter', 'point'].includes(state.object) ? state.object : preset.object;
    out.rays = state.rays !== false;
    out.play = state.play !== false;
    return out;
  }
  function solve(state) {
    const u = state.hole - state.obj, v = state.screen - state.hole, m = v / u;
    const d = state.diameter / 10;
    const area = state.shape === 'circle' ? Math.PI * d * d / 4 : state.shape === 'square' ? d * d : Math.sqrt(3) * d * d / 4;
    return { u, v, m, h: state.object === 'point' ? 0 : 8, H: state.object === 'point' ? 0 : 8 * m, blur: d * (1 + m), area };
  }
  // 物平面中的点 (x,y) 经孔内 (ax,ay) 投到屏上；前后平面正面视图用同一坐标朝向。
  function project(x, y, ax, ay, m) { return { x: -m * x + (1 + m) * ax, y: -m * y + (1 + m) * ay }; }
  // 轮廓中心采用面积质心。三角孔的宽为 d，高为 sqrt(3)d/2。
  function inside(shape, x, y) {
    if (shape === 'circle') return x * x + y * y <= .25;
    if (shape === 'square') return Math.abs(x) <= .5 && Math.abs(y) <= .5;
    const h = Math.sqrt(3) / 2;
    return y >= -h / 3 && y <= 2 * h / 3 && Math.abs(x) <= (2 * h / 3 - y) / (2 * h);
  }
  const sampleCache = {};
  function samples(shape) {
    if (sampleCache[shape]) return sampleCache[shape];
    const points = [], n = 17;
    for (let j = 0; j < n; j++) for (let i = 0; i < n; i++) {
      const x = (i + .5) / n - .5;
      const y = shape === 'triangle' ? ((j + .5) / n - 1 / 3) * Math.sqrt(3) / 2 : (j + .5) / n - .5;
      if (inside(shape, x, y)) points.push([x, y]);
    }
    sampleCache[shape] = points;
    return points;
  }
  function fromQuery(query) {
    const p = new URLSearchParams(query), input = {};
    ['scene', 'obj', 'hole', 'screen', 'diameter', 'shape', 'object'].forEach(k => { if (p.has(k)) input[k] = p.get(k); });
    input.rays = p.get('rays') !== '0'; input.play = p.get('play') !== '0';
    return normalize(input);
  }
  function toQuery(state) {
    const p = new URLSearchParams();
    ['scene', 'obj', 'hole', 'screen', 'diameter', 'shape', 'object'].forEach(k => p.set(k, state[k]));
    p.set('rays', state.rays ? '1' : '0'); p.set('play', state.play ? '1' : '0');
    return '?' + p.toString();
  }
  window.Pinhole = { LIMITS, PRESETS, clamp, normalize, solve, project, inside, samples, fromQuery, toQuery };
})();
