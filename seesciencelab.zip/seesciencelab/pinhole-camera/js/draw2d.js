/* Canvas 绘图：上方暗箱剖面，下方同朝向正面图；绘制与几何计算分离。 */
(function () {
  'use strict';
  const GOLD = '#ffc94a', BLUE = '#69cffa', TEXT = '#dce8f4', MUTED = '#92a7be';
  const source = document.createElement('canvas');
  source.width = 240; source.height = 320;
  const sc = source.getContext('2d');
  const image = document.createElement('canvas');
  image.width = 480; image.height = 480;
  const ic = image.getContext('2d');
  let imageKey = '', sourceKey = '', handles = [], bodies = [], metrics;
  function round(c, x, y, w, h, r, fill, stroke) {
    c.beginPath(); c.roundRect(x, y, w, h, r);
    if (fill) { c.fillStyle = fill; c.fill(); }
    if (stroke) { c.strokeStyle = stroke; c.lineWidth = 1; c.stroke(); }
  }
  function text(c, str, x, y, size, color, align) {
    c.fillStyle = color || TEXT; c.font = `${size || 12}px -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif`;
    c.textAlign = align || 'left'; c.textBaseline = 'middle'; c.fillText(str, x, y);
  }
  function line(c, x1, y1, x2, y2, color, width, dash) {
    c.beginPath(); c.moveTo(x1, y1); c.lineTo(x2, y2); c.strokeStyle = color;
    c.lineWidth = width || 1; c.setLineDash(dash || []); c.stroke(); c.setLineDash([]);
  }
  // 所有物体位于同一物平面；蜡烛和 F 的可见图形纵向范围均为 8 cm。
  function makeSource(object) {
    if (object === sourceKey) return;
    sourceKey = object; sc.clearRect(0, 0, 240, 320);
    if (object === 'letter') {
      sc.fillStyle = GOLD;
      sc.fillRect(45, 0, 38, 320); sc.fillRect(83, 0, 118, 38); sc.fillRect(83, 130, 90, 38);
      return;
    }
    const wax = sc.createLinearGradient(89, 0, 154, 0);
    wax.addColorStop(0, '#b66138'); wax.addColorStop(.3, '#ffdaa1'); wax.addColorStop(.75, '#e5a966'); wax.addColorStop(1, '#965431');
    sc.fillStyle = wax; sc.fillRect(89, 132, 65, 188);
    sc.fillStyle = '#ffe2aa'; sc.beginPath(); sc.ellipse(121.5, 132, 32.5, 8, 0, 0, Math.PI * 2); sc.fill();
    sc.strokeStyle = '#593b2c'; sc.lineWidth = 3; sc.beginPath(); sc.moveTo(121, 135); sc.lineTo(122, 114); sc.stroke();
    const flame = sc.createLinearGradient(0, 0, 0, 128);
    flame.addColorStop(0, '#ff943d'); flame.addColorStop(.5, '#ffcf50'); flame.addColorStop(.85, '#fff2b0'); flame.addColorStop(1, '#7abdf5');
    sc.fillStyle = flame; sc.beginPath(); sc.moveTo(130, 0);
    sc.bezierCurveTo(150, 49, 166, 72, 147, 112); sc.bezierCurveTo(136, 132, 104, 129, 96, 111);
    sc.bezierCurveTo(73, 78, 115, 36, 130, 0); sc.fill();
    sc.fillStyle = '#fff5c8'; sc.beginPath(); sc.moveTo(126, 60); sc.quadraticCurveTo(148, 119, 124, 122); sc.quadraticCurveTo(104, 119, 126, 60); sc.fill();
  }
  function aperturePath(c, shape, x, y, d) {
    c.beginPath();
    if (shape === 'circle') c.arc(x, y, d / 2, 0, Math.PI * 2);
    else if (shape === 'square') c.rect(x - d / 2, y - d / 2, d, d);
    else {
      const h = Math.sqrt(3) * d / 2;
      c.moveTo(x, y - 2 * h / 3); c.lineTo(x + d / 2, y + h / 3); c.lineTo(x - d / 2, y + h / 3); c.closePath();
    }
  }
  function makeImage(state, result) {
    const key = [state.object, state.shape, state.diameter, result.m].join('|');
    if (key === imageKey) return;
    imageKey = key; ic.clearRect(0, 0, 480, 480);
    // 自动视场至少12 cm，整幅图与刻度一起绘制。单物点直接按解析孔轮廓投影。
    const field = Math.max(12, result.H * 1.3, result.blur * 2);
    const scale = 480 / field;
    if (state.object === 'point') {
      aperturePath(ic, state.shape, 240, 240, result.blur * scale);
      ic.fillStyle = GOLD; ic.fill(); return;
    }
    makeSource(state.object);
    const samples = window.Pinhole.samples(state.shape);
    const d = state.diameter / 10, m = result.m;
    const pixels = sc.getImageData(0, 0, 240, 320).data;
    const output = ic.createImageData(480, 480), dst = output.data;
    const offsets = samples.map(([ax, ay]) => window.Pinhole.project(0, 0, ax * d, ay * d, m));
    const halfW = (3 * m + result.blur) * scale, halfH = (4 * m + result.blur) * scale;
    const x0 = Math.max(0, Math.floor(240 - halfW)), x1 = Math.min(480, Math.ceil(240 + halfW));
    const y0 = Math.max(0, Math.floor(240 - halfH)), y1 = Math.min(480, Math.ceil(240 + halfH));
    // 浮点累积预乘颜色，避免 Canvas 8位加法在很多低透明度样本下量化偏色。
    for (let y = y0; y < y1; y++) for (let x = x0; x < x1; x++) {
      const px = (x + .5 - 240) / scale, py = -(y + .5 - 240) / scale;
      let red = 0, green = 0, blue = 0, alpha = 0;
      for (let j = 0; j < offsets.length; j++) {
        const ox = (offsets[j].x - px) / m, oy = (offsets[j].y - py) / m;
        const ix = Math.floor((ox + 3) * 40), iy = Math.floor((4 - oy) * 40);
        if (ix < 0 || ix >= 240 || iy < 0 || iy >= 320) continue;
        const k = (iy * 240 + ix) * 4, a = pixels[k + 3] / 255;
        red += pixels[k] * a; green += pixels[k + 1] * a; blue += pixels[k + 2] * a; alpha += a;
      }
      if (!alpha) continue;
      const k = (y * 480 + x) * 4;
      dst[k] = red / alpha; dst[k + 1] = green / alpha; dst[k + 2] = blue / alpha;
      dst[k + 3] = 255 * alpha / offsets.length;
    }
    ic.putImageData(output, 0, 0);
  }
  function arrow(c, x, y, angle, color) {
    c.save(); c.translate(x, y); c.rotate(angle); c.fillStyle = color;
    c.beginPath(); c.moveTo(4, 0); c.lineTo(-3, -3); c.lineTo(-3, 3); c.closePath(); c.fill(); c.restore();
  }
  function ray(c, a, b, color, time, play) {
    line(c, a[0], a[1], b[0], b[1], color, 1.4);
    const dx = b[0] - a[0], dy = b[1] - a[1];
    arrow(c, a[0] + dx * .55, a[1] + dy * .55, Math.atan2(dy, dx), color);
    if (play) {
      const f = (time * .24) % 1;
      c.shadowBlur = 10; c.shadowColor = color; c.fillStyle = '#fff3cc';
      c.beginPath(); c.arc(a[0] + dx * f, a[1] + dy * f, 2.3, 0, Math.PI * 2); c.fill(); c.shadowBlur = 0;
    }
  }
  function dimension(c, x1, x2, y, label) {
    line(c, x1, y, x2, y, '#5b728c');
    line(c, x1, y - 4, x1, y + 4, '#5b728c'); line(c, x2, y - 4, x2, y + 4, '#5b728c');
    text(c, label, (x1 + x2) / 2, y + 14, 11, MUTED, 'center');
  }
  function draw(canvas, state, time, interaction) {
    const width = canvas.clientWidth, height = canvas.clientHeight, dpr = Math.min(devicePixelRatio || 1, 2);
    if (canvas.width !== Math.round(width * dpr) || canvas.height !== Math.round(height * dpr)) {
      canvas.width = Math.round(width * dpr); canvas.height = Math.round(height * dpr);
    }
    const c = canvas.getContext('2d'); c.setTransform(dpr, 0, 0, dpr, 0, 0);
    const r = window.Pinhole.solve(state), mobile = width < 600;
    const bg = c.createLinearGradient(0, 0, width, height);
    bg.addColorStop(0, '#080d16'); bg.addColorStop(.6, '#05070d'); bg.addColorStop(1, '#0a101b');
    c.fillStyle = bg; c.fillRect(0, 0, width, height);
    const margin = mobile ? 16 : 32, top = mobile ? 158 : 150;
    const boxH = Math.max(88, Math.min((height - top - 250) * .52, mobile ? 230 : 280));
    const center = top + boxH * .48;
    const left = margin + 20, right = width - margin - 20;
    const xmin = -20, xmax = 60, px = x => left + (x - xmin) / (xmax - xmin) * (right - left);
    const unit = boxH / 18;
    const ox = px(state.obj), hx = px(state.hole), sx = px(state.screen);
    const objY = center - 4 * unit, objH = 8 * unit;
    bodies = [
      { key: 'obj', x: ox, y: state.object === 'point' ? center - 22 : objY - 10,
        halfW: Math.max(22, objH * .375 + 8), h: state.object === 'point' ? 44 : objH + 20 },
      { key: 'hole', x: hx, y: top - 8, halfW: 22, h: boxH + 16 },
      { key: 'screen', x: sx, y: top - 8, halfW: 22, h: boxH + 16 }
    ];
    text(c, '光路剖面', margin, top - 24, mobile ? 12 : 13, TEXT);
    if (!mobile) text(c, '上方的光 → 屏下方    下方的光 → 屏上方', margin + 92, top - 24, 11, MUTED);
    const chamber = c.createLinearGradient(hx, top, sx, top + boxH);
    chamber.addColorStop(0, '#101b29'); chamber.addColorStop(1, '#080d15');
    round(c, hx, top, sx - hx, boxH, 4, chamber, '#475a71');
    // 暗箱顶面与底面提供可辨识装置层次；剖面轮廓不代表真实孔径。
    c.fillStyle = '#263347'; c.beginPath(); c.moveTo(hx, top); c.lineTo(hx + 8, top - 9); c.lineTo(sx + 8, top - 9); c.lineTo(sx, top); c.closePath(); c.fill();
    line(c, left - 12, center, right + 12, center, '#304155', 1, [5, 5]);
    if (state.object === 'point') {
      c.shadowColor = GOLD; c.shadowBlur = 18; c.fillStyle = GOLD; c.beginPath(); c.arc(ox, center, 4, 0, Math.PI * 2); c.fill(); c.shadowBlur = 0;
    } else {
      makeSource(state.object); c.drawImage(source, ox - objH * .375, objY, objH * .75, objH);
      line(c, ox - 9, center + objH / 2 + 3, ox + 9, center + objH / 2 + 3, '#65768c', 3);
    }
    // 光屏上以同一高度刻度画出倒立轮廓；大倍率时裁切，不越出实际光屏。
    c.save(); c.beginPath(); c.rect(sx - 10, top + 1, 20, boxH - 2); c.clip();
    c.fillStyle = '#c4d7d9'; c.fillRect(sx - 4, top, 8, boxH);
    if (state.object !== 'point') {
      c.save(); c.translate(sx, center); c.scale(-1, -1);
      c.globalAlpha = .85; c.drawImage(source, -6, -r.H * unit / 2, 12, r.H * unit); c.restore();
    } else { c.fillStyle = GOLD; const d = state.diameter / 10, factor = 1 + r.m;
      const upper = state.shape === 'triangle' ? Math.sqrt(3) * d / 3 : d / 2;
      const lower = state.shape === 'triangle' ? -Math.sqrt(3) * d / 6 : -d / 2;
      c.fillRect(sx - 4, center - upper * factor * unit, 8, (upper - lower) * factor * unit); }
    c.restore();
    const gap = Math.max(5, state.diameter * .6);
    line(c, hx, top, hx, center - gap, '#7b8b9d', 6); line(c, hx, center + gap, hx, top + boxH, '#7b8b9d', 6);
    if (state.rays) {
      if (state.object === 'point') {
        const d = state.diameter / 10;
        const edges = state.shape === 'triangle' ? [Math.sqrt(3) * d / 3, -Math.sqrt(3) * d / 6] : [d / 2, -d / 2];
        edges.forEach(y => { ray(c, [ox, center], [hx, center - y * unit], GOLD, time, state.play); ray(c, [hx, center - y * unit], [sx, center - y * (1 + r.m) * unit], GOLD, time, state.play); });
      } else {
        [1, -1].forEach((sign, i) => {
          const color = i ? BLUE : GOLD;
          ray(c, [ox, center - sign * 4 * unit], [hx, center], color, time, state.play);
          ray(c, [hx, center], [sx, center + sign * r.H * unit / 2], color, time, state.play);
        });
      }
    }
    if (sx - hx > 110) text(c, '暗箱 · 剖开示意', (hx + sx) / 2, top + boxH - 15, 10, '#7e92aa', 'center');
    const active = interaction && (interaction.dragKey || interaction.hoverKey);
    const selected = bodies.find(b => b.key === active);
    if (selected) {
      c.save(); c.setLineDash([4, 4]);
      round(c, selected.x - selected.halfW, selected.y, selected.halfW * 2, selected.h, 8,
        'rgba(255,201,74,.04)', interaction.dragKey ? GOLD : '#9badc2');
      c.restore();
      const y = selected.y - 9;
      line(c, selected.x - 13, y, selected.x + 13, y, GOLD);
      arrow(c, selected.x - 13, y, Math.PI, GOLD); arrow(c, selected.x + 13, y, 0, GOLD);
    }
    const hy = top + boxH + 20;
    handles = [{ key: 'obj', x: ox, y: hy }, { key: 'hole', x: hx, y: hy }, { key: 'screen', x: sx, y: hy }];
    const names = { obj: state.object === 'point' ? '物点' : '物体', hole: '孔板', screen: '光屏' };
    handles.forEach(h => { line(c, h.x, top + boxH, h.x, hy - 7, '#43566c'); c.fillStyle = '#15263a'; c.strokeStyle = '#88a3bc'; c.beginPath(); c.arc(h.x, h.y, 7, 0, Math.PI * 2); c.fill(); c.stroke(); text(c, names[h.key], h.x, hy + 20, 11, TEXT, 'center'); });
    dimension(c, ox, hx, hy + 38, `u = ${r.u.toFixed(0)} cm`);
    dimension(c, hx, sx, hy + 38, `v = ${r.v.toFixed(0)} cm`);
    const cardsTop = hy + 78, available = height - cardsTop - (mobile ? 114 : 76);
    const cardH = Math.max(88, available);
    const cardGap = mobile ? 10 : 18, cardW = (width - 2 * margin - cardGap) / 2;
    round(c, margin, cardsTop, cardW, cardH, 12, '#0c121d', '#263449');
    round(c, margin + cardW + cardGap, cardsTop, cardW, cardH, 12, '#0c121d', '#263449');
    text(c, '物体 · 正面', margin + 12, cardsTop + 21, 12, TEXT);
    text(c, '光屏 · 正面', margin + cardW + cardGap + 12, cardsTop + 21, 12, TEXT);
    const cy = cardsTop + cardH * .52, cx1 = margin + cardW / 2, cx2 = margin + 1.5 * cardW + cardGap;
    // 两张正面图相同厘米刻度。大孔细节不靠美术模糊，来自孔内投影叠加。
    const field = Math.max(12, r.H * 1.3, r.blur * 2);
    const previewScale = Math.min((cardW - 24) / field, (cardH - 74) / field);
    const size = field * previewScale;
    c.fillStyle = '#060c14'; c.fillRect(cx2 - size / 2, cy - size / 2, size, size);
    [cx1, cx2].forEach(cx => {
      for (let k = -Math.floor(field / 10) * 5; k <= field / 2; k += 5) {
        line(c, cx + k * previewScale, cy - size / 2, cx + k * previewScale, cy + size / 2, '#1d2a38');
        line(c, cx - size / 2, cy + k * previewScale, cx + size / 2, cy + k * previewScale, '#1d2a38');
      }
    });
    if (state.object === 'point') {
      c.shadowColor = GOLD; c.shadowBlur = 12; c.fillStyle = GOLD; c.beginPath(); c.arc(cx1, cy, 2.5, 0, Math.PI * 2); c.fill(); c.shadowBlur = 0;
    } else c.drawImage(source, cx1 - 3 * previewScale, cy - 4 * previewScale, 6 * previewScale, 8 * previewScale);
    makeImage(state, r); c.drawImage(image, cx2 - size / 2, cy - size / 2, size, size);
    text(c, '同刻度 · 每格 5 cm', cx1, cardsTop + cardH - 18, mobile ? 10 : 11, MUTED, 'center');
    text(c, state.object === 'point' ? '单物点 → 孔形光斑' : `倒立 · H ≈ ${r.H.toFixed(2)} cm`, cx2, cardsTop + cardH - 18, mobile ? 10 : 11, GOLD, 'center');
    // 点光源的孔形光斑补充局部放大，主预览仍保持同刻度。
    if (state.object === 'point') {
      const zz = mobile ? 27 : 40;
      c.save(); c.translate(cx2 + cardW * .25, cardsTop + 65);
      round(c, -zz / 2 - 5, -zz / 2 - 5, zz + 10, zz + 10, 6, '#050b13', '#475b70');
      aperturePath(c, state.shape, 0, 0, zz * .75); c.fillStyle = GOLD; c.fill();
      text(c, '光斑局部放大', 0, zz / 2 + 16, 9, MUTED, 'center'); c.restore();
    }
    text(c, '两图同刻度 · 自动曝光 · 孔板处孔径夸大', width / 2, cardsTop + cardH + 18, mobile ? 9 : 11, MUTED, 'center');
    metrics = { px, left, right, xmin, xmax };
  }
  function hit(x, y) {
    const handle = handles.find(h => Math.hypot(x - h.x, y - h.y) < 23);
    if (handle) return handle.key;
    // 手机窄屏下命中范围可能相交，选择离指针最近的装置中心。
    return bodies.filter(b => Math.abs(x - b.x) <= b.halfW && y >= b.y && y <= b.y + b.h)
      .sort((a, b) => Math.abs(x - a.x) - Math.abs(x - b.x))[0]?.key || null;
  }
  function position(x) { return metrics.xmin + (x - metrics.left) / (metrics.right - metrics.left) * (metrics.xmax - metrics.xmin); }
  window.PinholeDraw = { draw, hit, position };
})();
