/* 状态、输入、分享及分析事件。 */
(function () {
  'use strict';
  const P = window.Pinhole, D = window.PinholeDraw;
  const state = P.fromQuery(location.search), canvas = document.getElementById('view');
  const $ = id => document.getElementById(id);
  let dragKey = null, hoverKey = null, dragOffset = 0, time = 0, last = 0;
  const hint = $('hint'), defaultHint = hint.textContent;
  const dragNames = { obj: '物体', hole: '孔板', screen: '光屏' };
  function track(action, label) { if (window.Analytics) window.Analytics.track('小孔成像', action, String(label)); }
  function update() {
    Object.assign(state, P.normalize(state));
    const r = P.solve(state);
    ['obj', 'hole', 'screen', 'diameter'].forEach(key => {
      $(key).value = state[key]; $('o' + key).textContent = state[key].toFixed(key === 'diameter' ? 1 : 0) + (key === 'diameter' ? ' mm' : ' cm');
    });
    const shapeNames = { circle: '圆孔', square: '方孔', triangle: '三角孔' };
    $('apertureText').textContent = shapeNames[state.shape] + ' · ' + state.diameter.toFixed(1) + ' mm';
    $('aperture').setAttribute('aria-label', '当前' + shapeNames[state.shape] + '，点击切换孔形状');
    $('apertureShape').setAttribute('d', { circle: 'M16 6a10 10 0 1 0 0 20a10 10 0 1 0 0-20', square: 'M6 6h20v20H6Z', triangle: 'M16 4L28 25H4Z' }[state.shape]);
    $('rays').checked = state.rays; $('play').checked = state.play;
    document.querySelectorAll('[data-scene]').forEach(b => { const on = b.dataset.scene === state.scene; b.classList.toggle('on', on); b.setAttribute('aria-pressed', on); });
    ['shape', 'object'].forEach(key => document.querySelectorAll('[data-' + key + ']').forEach(b => {
      const on = b.dataset[key] === state[key]; b.classList.toggle('on', on); b.setAttribute('aria-pressed', on);
    }));
    $('ru').textContent = r.u.toFixed(0) + ' cm'; $('rv').textContent = r.v.toFixed(0) + ' cm';
    $('rm').textContent = state.object === 'point' ? '—（理想点无高度）' : r.m.toFixed(2);
    $('rh').textContent = state.object === 'point' ? '—' : r.H.toFixed(2) + ' cm';
    $('rb').textContent = (r.blur * 10).toFixed(2) + ' mm';
    $('result').textContent = state.object === 'point' ? '单物点 → 孔的光斑' : '倒立实像 · ' + (r.m > 1.001 ? '放大' : r.m < .999 ? '缩小' : '等大');
    $('fact').textContent = state.object === 'point' ? '点光源的几何光斑呈孔的轮廓；换回蜡烛，许多光斑叠加成像。' : state.diameter > 5 ? '孔变大，每个物点的光斑也变大；细节互相叠加，像变模糊。' : '上方光到屏下方，下方光到屏上方。小孔形状改变，物体的基本轮廓仍保留。';
  }
  function scene(name) {
    if (!P.PRESETS[name]) return;
    Object.assign(state, P.PRESETS[name], { scene: name }); update(); track('切换场景', name);
  }
  ['obj', 'hole', 'screen', 'diameter'].forEach(key => {
    $(key).addEventListener('input', e => { state[key] = Number(e.target.value); update(); });
    $(key).addEventListener('change', () => track('改变参数', key + '=' + state[key]));
  });
  document.querySelectorAll('[data-scene]').forEach(b => b.addEventListener('click', () => scene(b.dataset.scene)));
  ['shape', 'object'].forEach(key => document.querySelectorAll('[data-' + key + ']').forEach(b => b.addEventListener('click', () => {
    state[key] = b.dataset[key]; update(); track('切换' + key, state[key]);
  })));
  ['rays', 'play'].forEach(key => $(key).addEventListener('change', () => { state[key] = $(key).checked; update(); track('显示', key + '=' + state[key]); }));
  $('reset').addEventListener('click', () => scene(state.scene));
  $('share').addEventListener('click', async () => {
    const url = location.origin + location.pathname + P.toQuery(state);
    try { await navigator.clipboard.writeText(url); $('shareStatus').textContent = '已复制，打开链接即可复现当前实验。'; track('复制链接', state.scene); }
    catch { $('shareStatus').textContent = url; }
  });
  $('aperture').addEventListener('click', () => {
    const shapes = ['circle', 'square', 'triangle'];
    state.shape = shapes[(shapes.indexOf(state.shape) + 1) % 3]; update(); track('切换shape', state.shape);
  });
  const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)');
  const panel = $('panel');
  if (matchMedia('(max-width:760px)').matches) panel.classList.add('collapsed');
  $('panelToggle').addEventListener('click', () => {
    panel.classList.toggle('collapsed');
    const open = !panel.classList.contains('collapsed');
    $('panelToggle').setAttribute('aria-expanded', open);
    $('panelToggle').textContent = open ? '收起控制' : '调节实验';
  });
  function point(e) { const box = canvas.getBoundingClientRect(); return [e.clientX - box.left, e.clientY - box.top]; }
  canvas.addEventListener('pointerdown', e => {
    if (!e.isPrimary || e.button !== 0) return;
    const [x, y] = point(e); dragKey = D.hit(x, y);
    if (dragKey) {
      // 保留抓取位置：从装置边缘按下时不把装置中心吸到指针上。
      dragOffset = D.position(x) - state[dragKey];
      hoverKey = dragKey; canvas.setPointerCapture(e.pointerId);
      canvas.style.cursor = 'grabbing';
      hint.textContent = '正在移动' + dragNames[dragKey] + ' · 左右拖动';
      e.preventDefault();
    }
  });
  canvas.addEventListener('pointermove', e => {
    const [x, y] = point(e);
    hoverKey = D.hit(x, y);
    canvas.style.cursor = dragKey ? 'grabbing' : hoverKey ? 'grab' : 'default';
    if (!dragKey) hint.textContent = hoverKey ? '左右拖动' + dragNames[hoverKey] + '，观察像的变化' : defaultHint;
    if (!dragKey) return;
    state[dragKey] = Math.round(P.clamp(D.position(x) - dragOffset, ...P.LIMITS[dragKey])); update();
  });
  function release() {
    if (dragKey) track('拖动装置', dragKey + '=' + state[dragKey]);
    dragKey = null; hoverKey = null; canvas.style.cursor = 'default'; hint.textContent = defaultHint;
  }
  canvas.addEventListener('pointerup', release); canvas.addEventListener('pointercancel', release);
  canvas.addEventListener('lostpointercapture', release);
  canvas.addEventListener('pointerleave', () => { if (!dragKey) release(); });
  document.addEventListener('keydown', e => {
    if (e.code === 'Space' && !/INPUT|BUTTON|TEXTAREA|SELECT/.test(e.target.tagName)) {
      e.preventDefault(); state.play = !state.play; update();
    }
  });
  function frame(now) {
    const dt = last ? Math.min((now - last) / 1000, .05) : 0; last = now;
    if (state.play) time += dt;
    D.draw(canvas, reducedMotion.matches ? { ...state, play: false } : state, time, { dragKey, hoverKey }); requestAnimationFrame(frame);
  }
  window.__model = { state, update, setScene: scene, set(patch) { Object.assign(state, patch); update(); }, get result() { return P.solve(state); }, getQuery() { return P.toQuery(state); } };
  update(); requestAnimationFrame(frame);
})();
