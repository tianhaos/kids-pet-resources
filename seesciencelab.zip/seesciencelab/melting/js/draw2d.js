// 熔化与凝固绘图：水浴加热装置（铁架台、酒精灯、烧杯、试管、温度计）、微观粒子放大图、温度—时间图像
(function () {
  var M = window.Melt;
  var PI = Math.PI, TAU = PI * 2;
  var C = { text: '#e6ebf2', muted: '#8d99ab', line: '#2a3446', panel: '#111723', panel2: '#1a2231', accent: '#ffc94a',
    metal: '#7d8a9c', glass: 'rgba(200,225,255,0.55)', water: 'rgba(79,160,255,0.22)', mercury: '#ff5a5a' };
  var TUBE = ['#ffc94a', '#4fc3f7'];      // 试管 A / B 的曲线颜色
  var BATH = '#ff8a65';                    // 水温曲线
  var VW = 330, VH = 372;                  // 装置图的虚拟尺寸
  var TH_LO = -20, TH_HI = 110;            // 温度计量程

  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
  function rng(seed) {
    return function () {
      seed |= 0; seed = seed + 0x6D2B79F5 | 0;
      var t = Math.imul(seed ^ seed >>> 15, 1 | seed);
      t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
      return ((t ^ t >>> 14) >>> 0) / 4294967296;
    };
  }
  function fmtT(T) { return (T < 0 ? '−' : '') + Math.abs(T).toFixed(1) + ' °C'; }

  // ---------- 微观粒子（每支试管一组，换物质时重建） ----------
  function makeParticles(key, crystal) {
    var r = rng(key.length * 977 + key.charCodeAt(0) * 31), ps = [], sp = 0.27;
    for (var j = -4; j <= 4; j++) {
      for (var i = -4; i <= 4; i++) {
        var x = (i + (j & 1) * 0.5) * sp, y = j * sp * 0.866;
        if (!crystal) { x += (r() - 0.5) * 0.17; y += (r() - 0.5) * 0.17; }
        if (x * x + y * y > 0.8 * 0.8) continue;
        ps.push({ sx: x, sy: y, x: x, y: y, vx: 0, vy: 0, ph: r() * TAU, fq: 7 + r() * 5, d: Math.hypot(x, y), rank: 0, free: false });
      }
    }
    // 熔化从外向里：离中心远的先"自由"
    ps.slice().sort(function (a, b) { return b.d + r() * 0.25 - (a.d + r() * 0.25); }).forEach(function (p, i, arr) { p.rank = (i + 0.5) / arr.length; });
    return { key: key, crystal: crystal, ps: ps, rnd: r };
  }
  function stepParticles(g, T, f, dt) {
    var heat = clamp((T + 30) / 140, 0.05, 1);          // 温度越高振动、运动越剧烈
    var amp = 0.012 + 0.03 * heat, spd = 0.25 + 0.55 * heat, r = g.rnd;
    g.ps.forEach(function (p) {
      var free = p.rank < f;
      if (free) {
        p.vx += (r() - 0.5) * spd * 6 * dt; p.vy += (r() - 0.5) * spd * 6 * dt;
        var v = Math.hypot(p.vx, p.vy), vmax = spd * 0.6;
        if (v > vmax) { p.vx *= vmax / v; p.vy *= vmax / v; }
      } else if (p.free && !g.crystal) { p.sx = p.x; p.sy = p.y; }   // 非晶体：停在哪里就在哪里"冻住"
      p.free = free;
    });
    // 自由粒子之间互相推开（液体里粒子仍然挨得很近）
    var ps = g.ps;
    for (var a = 0; a < ps.length; a++) {
      for (var b = a + 1; b < ps.length; b++) {
        var A = ps[a], B = ps[b];
        if (!A.free && !B.free) continue;
        var dx = B.x - A.x, dy = B.y - A.y, d = Math.hypot(dx, dy) || 1e-4;
        if (d < 0.25) {
          var push = (0.25 - d) * 3 * dt / d;
          if (A.free) { A.vx -= dx * push; A.vy -= dy * push; }
          if (B.free) { B.vx += dx * push; B.vy += dy * push; }
        }
      }
    }
    ps.forEach(function (p) {
      if (p.free) {
        p.x += p.vx * dt; p.y += p.vy * dt;
        var d = Math.hypot(p.x, p.y);
        if (d > 0.84) { p.x *= 0.84 / d; p.y *= 0.84 / d; var dot = (p.vx * p.x + p.vy * p.y) / (0.84 * 0.84); p.vx -= 2 * dot * p.x; p.vy -= 2 * dot * p.y; }
      } else {
        // 被束缚的粒子回到（或待在）自己的位置附近振动
        var k = 1 - Math.exp(-dt * 6);
        p.x += (p.sx - p.x) * k; p.y += (p.sy - p.y) * k;
        p.vx = p.vy = 0;
      }
      p.ph += p.fq * dt;
      p.jx = Math.cos(p.ph) * amp; p.jy = Math.sin(p.ph * 1.3 + 1) * amp;
    });
  }

  // ---------- 试管里固体颗粒的位置（固定随机） ----------
  var grainCache = {};
  function grains(key) {
    if (grainCache[key]) return grainCache[key];
    var r = rng(key.charCodeAt(0) * 131 + key.length), gs = [];
    for (var i = 0; i < 26; i++) gs.push({ x: (r() - 0.5) * 0.8, y: r(), s: 0.7 + r() * 0.5, a: r() * PI, rank: r() });
    gs.sort(function (a, b) { return a.y - b.y; });
    return (grainCache[key] = gs);
  }

  function MeltDraw(canvas) {
    var ctx = canvas.getContext('2d');
    var W = 1, H = 1, dpr = 1, narrow = false;
    var parts = [null, null], lampX = 0, gBox = null, gMap = null;

    function resize(w, h) {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      W = w; H = h;
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
      canvas.style.width = w + 'px'; canvas.style.height = h + 'px';
      narrow = w < 640;
    }
    function font(size, weight, mono) {
      ctx.font = (weight || '') + ' ' + size + 'px ' + (mono ? '"SF Mono", Menlo, Consolas, monospace' : '-apple-system, "PingFang SC", "Microsoft YaHei", sans-serif');
    }
    function label(str, x, y, color, align, size, weight, halo, mono) {
      font(size, weight, mono);
      ctx.textAlign = align || 'center'; ctx.textBaseline = 'middle';
      if (halo !== false) { ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(5,7,13,0.85)'; ctx.strokeText(str, x, y); }
      ctx.fillStyle = color; ctx.fillText(str, x, y);
    }
    function line(x0, y0, x1, y1) { ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke(); }
    function rrect(x, y, w, h, r) { ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(x, y, w, h, r); else ctx.rect(x, y, w, h); }

    // ---------- 布局 ----------
    function layout() {
      var top = narrow ? 84 : 44, bot = 44, side = narrow ? 8 : 20;
      var a = { x: side, y: top, w: W - 2 * side, h: H - top - bot };
      if (a.w >= a.h * 1.15) {
        var aw = Math.min(a.w * 0.42, a.h * 0.95);
        return { rig: { x: a.x, y: a.y, w: aw, h: a.h }, graph: { x: a.x + aw + 16, y: a.y, w: a.w - aw - 16, h: a.h } };
      }
      var rh = a.h * 0.5;
      return { rig: { x: a.x, y: a.y, w: a.w, h: rh }, graph: { x: a.x, y: a.y + rh + 8, w: a.w, h: a.h - rh - 8 } };
    }

    // ---------- 装置 ----------
    function drawRig(box, st, dt) {
      var x = st.x, k = Math.min(box.w / VW, box.h / VH);
      var ox = box.x + (box.w - VW * k) / 2, oy = box.y + (box.h - VH * k) / 2;
      ctx.save();
      ctx.translate(ox, oy); ctx.scale(k, k);
      var lw = 1.2 / Math.min(k, 1.6) * Math.min(k, 1);       // 线宽随缩放基本不变
      var fs = function (px) { return Math.max(px, 10.5 / k); };
      var direct = x.direct, n = x.tubes.length;
      var cxs = n === 2 ? [127, 163] : [145];
      var tubeTop = direct ? 70 : 52, tubeBot = direct ? 238 : 222, tw = 22;

      // 酒精灯撤去：滑到右边
      var lampTarget = x.cooling ? 120 : 0;
      lampX += (lampTarget - lampX) * (1 - Math.exp(-dt * 4));

      // 铁架台
      ctx.fillStyle = '#252f40'; ctx.strokeStyle = '#3a4659'; ctx.lineWidth = lw;
      rrect(10, 352, 236, 10, 2); ctx.fill(); ctx.stroke();
      ctx.fillStyle = '#5b6779'; ctx.fillRect(33, 14, 6, 338);

      // 铁圈 + 陶土网 + 烧杯
      if (!direct) {
        ctx.strokeStyle = '#6b7f9e'; ctx.lineWidth = 2.4;
        line(39, 246, 95, 246);
        ctx.beginPath(); ctx.ellipse(145, 246, 52, 4, 0, 0, TAU); ctx.stroke();
        ctx.fillStyle = '#454e5c'; ctx.fillRect(90, 239, 110, 5);
        ctx.fillStyle = '#9aa1ab'; ctx.beginPath(); ctx.ellipse(145, 241.5, 26, 2.5, 0, 0, TAU); ctx.fill();
        drawBeaker(st, cxs, tubeBot, lw, fs);
      } else {
        ctx.strokeStyle = '#6b7f9e'; ctx.lineWidth = 2.4;
      }

      // 酒精灯
      drawLamp(145 + lampX, x.lamp, st.now, lw);

      // 试管夹（铁夹）
      ctx.strokeStyle = '#8693a7'; ctx.lineWidth = 3;
      var clampY = tubeTop + 30;
      line(39, clampY, cxs[n - 1] + tw / 2 + 3, clampY);
      cxs.forEach(function (cx) {
        ctx.lineWidth = 2; ctx.strokeStyle = '#a4afbf';
        rrect(cx - tw / 2 - 3, clampY - 6, tw + 6, 12, 3); ctx.stroke();
      });
      ctx.fillStyle = '#8693a7'; ctx.fillRect(33, clampY - 6, 10, 12);

      // 试管、物质、温度计
      x.tubes.forEach(function (tb, i) { drawTube(cxs[i], tubeTop, tubeBot, tw, tb, i, st, lw, fs); });

      // 标注
      if (st.labels) {
        ctx.strokeStyle = 'rgba(141,153,171,0.6)'; ctx.lineWidth = 0.8;
        var lf = fs(11);
        label('铁架台', 36, 360 - 16, C.muted, 'left', lf, '', true);
        label('温度计', cxs[0] - 30, 22, C.muted, 'right', lf);
        line(cxs[0] - 28, 22, cxs[0] + 2, 26);
        label('试管', cxs[0] - 34, tubeTop + 70, C.muted, 'right', lf);
        line(cxs[0] - 32, tubeTop + 70, cxs[0] - tw / 2, tubeTop + 76);
        if (!direct) {
          label(x.mix ? M.SUBS.ice.coolName : '水', 96, 196, C.muted, 'right', lf);
          label('陶土网', 86, 236, C.muted, 'right', lf);
          label(x.lamp || !x.cooling ? '酒精灯' : '', 96, 322, C.muted, 'right', lf);
        } else label('酒精灯', 145 + lampX - 36, 322, C.muted, 'right', lf);
      }

      // 读数标签
      x.tubes.forEach(function (tb, i) {
        var cx = cxs[i] + 4, tx = i === 0 ? cx - 8 : cx + 8;
        label(fmtT(tb.T), tx, 8, TUBE[i], i === 0 ? 'right' : 'left', fs(12.5), '600', true, true);
      });
      if (!direct) label((x.mix ? '' : '水温 ') + Math.round(x.bath) + ' °C', 99, 231, BATH, 'left', fs(11.5), '600', true, true);

      // 微观放大
      if (st.micro) {
        var spots = n === 2 ? [[286, 84, 36], [286, 226, 36]] : [[286, 128, 42]];
        x.tubes.forEach(function (tb, i) {
          var sp = spots[i], fy = tubeBot - 22;
          ctx.setLineDash([3, 3]); ctx.strokeStyle = 'rgba(141,153,171,0.55)'; ctx.lineWidth = 0.9;
          line(cxs[i] + tw / 2 + 1, fy, sp[0] - sp[2] * 0.96, sp[1] + sp[2] * 0.3);
          ctx.setLineDash([]);
          drawMicro(i, tb, sp[0], sp[1], sp[2], dt, fs, k);
        });
      }
      ctx.restore();
    }

    function drawBeaker(st, cxs, tubeBot, lw, fs) {
      var x = st.x, L = 95, R = 195, T = 126, B = 239, wy = 148;
      // 液体
      if (x.mix) {
        ctx.fillStyle = 'rgba(220,235,250,0.30)'; ctx.fillRect(L + 2, wy, R - L - 4, B - wy - 1);
        var r = rng(7);
        ctx.fillStyle = 'rgba(235,245,255,0.55)';
        for (var i = 0; i < 26; i++) { var gx = L + 6 + r() * (R - L - 12), gy = wy + 6 + r() * (B - wy - 12), s = 4 + r() * 5; ctx.fillRect(gx, gy, s, s * 0.8); }
      } else {
        var warm = clamp((x.bath - 20) / 80, 0, 1);
        ctx.fillStyle = 'rgba(' + Math.round(79 + 120 * warm) + ',' + Math.round(160 - 40 * warm) + ',' + Math.round(255 - 120 * warm) + ',0.24)';
        ctx.fillRect(L + 2, wy, R - L - 4, B - wy - 1);
        // 沸腾：气泡
        var boil = clamp((x.bath - 92) / 8, 0, 1), now = st.now;
        if (boil > 0 || (x.lamp && x.bath > 50)) {
          var nb = Math.round(4 + 14 * boil);
          ctx.fillStyle = 'rgba(255,255,255,0.5)';
          for (var j = 0; j < nb; j++) {
            var ph = (now * (0.5 + boil) + j * 0.618) % 1, bx = L + 10 + ((j * 37) % (R - L - 20));
            if (Math.abs(bx - cxs[0]) < 14 || (cxs[1] && Math.abs(bx - cxs[1]) < 14)) bx += 18;
            var by = B - 4 - ph * (B - wy - 8), br = (1 + 2.5 * boil) * (0.4 + ph);
            if (boil < 0.05 && ph > 0.35) continue;      // 没沸腾时只有底部的小气泡
            ctx.beginPath(); ctx.arc(bx, by, br, 0, TAU); ctx.fill();
          }
        }
      }
      ctx.strokeStyle = 'rgba(160,200,255,0.35)'; ctx.lineWidth = 1;
      line(L + 2, wy, R - 2, wy);
      // 杯壁
      ctx.strokeStyle = C.glass; ctx.lineWidth = 1.6;
      ctx.beginPath(); ctx.moveTo(L - 4, T - 2); ctx.lineTo(L, T + 2); ctx.lineTo(L, B - 4); ctx.quadraticCurveTo(L, B, L + 4, B);
      ctx.lineTo(R - 4, B); ctx.quadraticCurveTo(R, B, R, B - 4); ctx.lineTo(R, T); ctx.stroke();
      // 刻度
      ctx.strokeStyle = 'rgba(200,225,255,0.3)'; ctx.lineWidth = 0.8;
      for (var m = 0; m < 4; m++) line(R - 14, B - 20 - m * 22, R - 3, B - 20 - m * 22);
    }

    function drawLamp(cx, lit, now, lw) {
      // 灯体
      ctx.fillStyle = 'rgba(200,225,255,0.10)'; ctx.strokeStyle = C.glass; ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(cx - 10, 296); ctx.bezierCurveTo(cx - 34, 300, cx - 34, 318, cx - 32, 352);
      ctx.lineTo(cx + 32, 352); ctx.bezierCurveTo(cx + 34, 318, cx + 34, 300, cx + 10, 296); ctx.closePath();
      ctx.fill(); ctx.stroke();
      ctx.fillStyle = 'rgba(120,190,255,0.25)';                 // 酒精
      ctx.beginPath(); ctx.moveTo(cx - 31, 328); ctx.lineTo(cx + 31, 328); ctx.lineTo(cx + 31.5, 351); ctx.lineTo(cx - 31.5, 351); ctx.fill();
      ctx.fillStyle = '#6b7f9e'; ctx.fillRect(cx - 9, 289, 18, 8);    // 灯帽座
      ctx.strokeStyle = '#e8dcc0'; ctx.lineWidth = 2.2; line(cx, 289, cx, 281);   // 灯芯
      if (!lit) return;
      var fl = 1 + 0.06 * Math.sin(now * 17) + 0.04 * Math.sin(now * 29 + 1), top = 281 - 50 * fl;
      var g = ctx.createLinearGradient(0, 281, 0, top);
      g.addColorStop(0, 'rgba(90,150,255,0.9)'); g.addColorStop(0.25, 'rgba(255,190,80,0.9)'); g.addColorStop(1, 'rgba(255,120,40,0)');
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.moveTo(cx, top);
      ctx.bezierCurveTo(cx + 11, 281 - 26, cx + 11, 281, cx, 282);
      ctx.bezierCurveTo(cx - 11, 281, cx - 11, 281 - 26, cx, top); ctx.fill();
      ctx.fillStyle = 'rgba(120,180,255,0.75)';
      ctx.beginPath(); ctx.moveTo(cx, 281 - 16); ctx.quadraticCurveTo(cx + 4, 278, cx, 282); ctx.quadraticCurveTo(cx - 4, 278, cx, 281 - 16); ctx.fill();
    }

    function drawTube(cx, top, bot, tw, tb, i, st, lw, fs) {
      var s = tb.s, f = tb.f, fillH = 46, r = tw / 2, fy0 = bot - fillH;
      // 管内物质（先画，管壁压在上面）
      ctx.save();
      ctx.beginPath(); ctx.moveTo(cx - r, top); ctx.lineTo(cx - r, bot - r); ctx.arc(cx, bot - r, r, PI, 0, true); ctx.lineTo(cx + r, top); ctx.closePath();
      ctx.clip();
      if (s.crystal) {
        // 熔化后的液体积在下面，未熔化的颗粒堆在上面
        var liqTop = bot - fillH * (0.12 + 0.82 * f);
        if (f > 0) { ctx.fillStyle = s.liquid; ctx.fillRect(cx - r, liqTop, tw, bot - liqTop + 2); ctx.strokeStyle = 'rgba(255,255,255,0.45)'; ctx.lineWidth = 0.8; line(cx - r, liqTop, cx + r, liqTop); }
        grains(tb.key).forEach(function (g) {
          if (g.rank < f) return;
          var sz = 4.2 * g.s * clamp((g.rank - f) * 8, 0.3, 1);
          var gy = bot - 3 - g.y * (fillH - 6), gx = cx + g.x * (tw - 6);
          ctx.save(); ctx.translate(gx, gy); ctx.rotate(g.a);
          ctx.fillStyle = s.color; ctx.strokeStyle = 'rgba(0,0,0,0.25)'; ctx.lineWidth = 0.5;
          ctx.beginPath();
          if (s.shape === 'flake') { ctx.moveTo(-sz, 0); ctx.lineTo(0, -sz * 0.45); ctx.lineTo(sz, 0); ctx.lineTo(0, sz * 0.45); }
          else if (s.shape === 'cube') { ctx.rect(-sz * 0.7, -sz * 0.7, sz * 1.4, sz * 1.4); }
          else { ctx.moveTo(-sz * 0.8, -sz * 0.5); ctx.lineTo(sz * 0.6, -sz * 0.7); ctx.lineTo(sz * 0.8, sz * 0.4); ctx.lineTo(-sz * 0.3, sz * 0.7); }
          ctx.closePath(); ctx.fill(); ctx.stroke();
          ctx.restore();
        });
      } else {
        // 非晶体：一块固体逐渐变软、塌下来、铺满管底，颜色变成液体
        var S = f, pts = [], N = 14, rr = rng(tb.key.length * 17 + 3);
        var lump = [];
        for (var k = 0; k < N; k++) lump.push(0.75 + rr() * 0.25);
        var flatTop = bot - fillH * 0.82;
        for (var j = 0; j <= N; j++) {
          var u = j / N, ang = PI + u * PI;                // 上半圈轮廓
          var lx = cx + Math.cos(ang) * (r - 2) * lump[j % N], ly = bot - fillH * 0.5 + Math.sin(ang) * fillH * 0.5 * lump[(j + 3) % N];
          var tx = cx - r + u * tw, ty = flatTop;
          pts.push([lx + (tx - lx) * S, ly + (ty - ly) * S]);
        }
        ctx.beginPath(); ctx.moveTo(cx - r, bot + 2);
        pts.forEach(function (p) { ctx.lineTo(p[0], p[1]); });
        ctx.lineTo(cx + r, bot + 2); ctx.closePath();
        ctx.fillStyle = mix(s.color, s.liquid, S); ctx.fill();
        ctx.strokeStyle = 'rgba(255,255,255,' + (0.25 + 0.2 * S) + ')'; ctx.lineWidth = 0.8; ctx.stroke();
      }
      ctx.restore();
      // 管壁
      ctx.strokeStyle = C.glass; ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.moveTo(cx - r - 2, top - 3); ctx.lineTo(cx - r, top); ctx.lineTo(cx - r, bot - r); ctx.arc(cx, bot - r, r, PI, 0, true);
      ctx.lineTo(cx + r, top); ctx.lineTo(cx + r + 2, top - 3); ctx.stroke();

      // 温度计（玻璃泡插在物质中间）
      var tx0 = cx + 4, ty0 = 14, bulbY = bot - 16;
      var yOf = function (T) { return bulbY - 8 - (clamp(T, TH_LO, TH_HI) - TH_LO) / (TH_HI - TH_LO) * (bulbY - 8 - ty0 - 10); };
      ctx.fillStyle = 'rgba(230,240,255,0.10)'; ctx.strokeStyle = 'rgba(220,235,255,0.7)'; ctx.lineWidth = 1;
      rrect(tx0 - 2.6, ty0, 5.2, bulbY - ty0, 2.6); ctx.fill(); ctx.stroke();
      ctx.fillStyle = C.mercury;
      ctx.beginPath(); ctx.ellipse(tx0, bulbY, 3.4, 5, 0, 0, TAU); ctx.fill();
      ctx.fillRect(tx0 - 1.1, yOf(tb.T), 2.2, bulbY - yOf(tb.T));
      ctx.strokeStyle = 'rgba(220,235,255,0.5)'; ctx.lineWidth = 0.6;
      for (var t = 0; t <= 100; t += 10) { var yy = yOf(t); line(tx0 - (t % 50 ? 1.5 : 3), yy, tx0 - 2.6, yy); }
      // 试管 A/B 的色标
      ctx.fillStyle = TUBE[i]; ctx.fillRect(cx - r, top - 8, tw, 3);
    }

    function mix(a, b, t) {
      var pa = parse(a), pb = parse(b);
      return 'rgba(' + [0, 1, 2].map(function (i) { return Math.round(pa[i] + (pb[i] - pa[i]) * t); }).join(',') + ',' + (pa[3] + (pb[3] - pa[3]) * t).toFixed(2) + ')';
    }
    function parse(c) {
      if (c[0] === '#') return [parseInt(c.substr(1, 2), 16), parseInt(c.substr(3, 2), 16), parseInt(c.substr(5, 2), 16), 1];
      var m = c.match(/[\d.]+/g).map(Number); return [m[0], m[1], m[2], m[3] == null ? 1 : m[3]];
    }

    function drawMicro(i, tb, x, y, R, dt, fs, k) {
      var g = parts[i];
      if (!g || g.key !== tb.key) g = parts[i] = makeParticles(tb.key, tb.s.crystal);
      stepParticles(g, tb.T, tb.f, dt);
      ctx.save();
      ctx.fillStyle = 'rgba(11,15,24,0.94)'; ctx.strokeStyle = TUBE[i]; ctx.lineWidth = 1.4;
      ctx.beginPath(); ctx.arc(x, y, R, 0, TAU); ctx.fill(); ctx.stroke();
      ctx.beginPath(); ctx.arc(x, y, R - 1, 0, TAU); ctx.clip();
      var sc = R / 0.95, pr = R * 0.118;
      // 晶体：固定位置之间画出"晶格"连线，体现排列规则
      if (g.crystal) {
        ctx.strokeStyle = 'rgba(141,153,171,0.35)'; ctx.lineWidth = 0.7;
        var ps = g.ps;
        for (var a = 0; a < ps.length; a++) for (var b = a + 1; b < ps.length; b++) {
          var A = ps[a], B = ps[b];
          if (A.free || B.free) continue;
          if (Math.hypot(A.sx - B.sx, A.sy - B.sy) < 0.3) line(x + (A.x + A.jx) * sc, y + (A.y + A.jy) * sc, x + (B.x + B.jx) * sc, y + (B.y + B.jy) * sc);
        }
      }
      g.ps.forEach(function (p) {
        var px = x + (p.x + p.jx) * sc, py = y + (p.y + p.jy) * sc;
        var gg = ctx.createRadialGradient(px - pr * 0.35, py - pr * 0.35, pr * 0.1, px, py, pr);
        gg.addColorStop(0, '#ffffff'); gg.addColorStop(0.45, TUBE[i]); gg.addColorStop(1, 'rgba(0,0,0,0.6)');
        ctx.fillStyle = gg; ctx.beginPath(); ctx.arc(px, py, pr, 0, TAU); ctx.fill();
      });
      ctx.restore();
      var cap = tb.s.crystal
        ? (tb.f <= 0 ? '排列规则，原位振动' : tb.f >= 1 ? '离开原位，自由移动' : '部分粒子挣脱原位')
        : (tb.f <= 0.02 ? '排列无规则' : tb.f < 0.98 ? '无规则，渐渐能移动' : '无规则，自由移动');
      label(tb.s.name + ' · 粒子', x, y - R - fs(8), TUBE[i], 'center', fs(10.5), '600');
      label(cap, x, y + R + fs(8), C.muted, 'center', fs(10));
    }

    // ---------- 温度—时间图像 ----------
    function drawGraph(box, st) {
      var x = st.x, rec = st.rec, fsz = narrow ? 11 : 12;
      var pl = narrow ? 34 : 42, pr = 12, pt = narrow ? 34 : 40, pb = narrow ? 30 : 34;
      var gx = box.x + pl, gy = box.y + pt, gw = Math.max(40, box.w - pl - pr), gh = Math.max(40, box.h - pt - pb);
      gBox = { x: gx, y: gy, w: gw, h: gh };
      ctx.fillStyle = 'rgba(17,23,35,0.65)'; ctx.strokeStyle = C.line; ctx.lineWidth = 1;
      rrect(box.x, box.y, box.w, box.h, 10); ctx.fill(); ctx.stroke();

      // 坐标范围：横轴分钟，按 5 分钟扩展；纵轴按物质
      var tm = Math.max(10, Math.ceil((x.t / 60 + 0.5) / 5) * 5);
      var ylo = st.yRange[0], yhi = st.yRange[1];
      var X = function (t) { return gx + t / 60 / tm * gw; }, Y = function (T) { return gy + gh - (T - ylo) / (yhi - ylo) * gh; };
      gMap = { X: X, Y: Y, tm: tm, ylo: ylo, yhi: yhi };

      // 网格
      ctx.lineWidth = 1;
      var ystep = (yhi - ylo) / 10 <= 10 ? 10 : 20;
      for (var T = Math.ceil(ylo / ystep) * ystep; T <= yhi; T += ystep) {
        ctx.strokeStyle = T === 0 ? 'rgba(141,153,171,0.45)' : 'rgba(42,52,70,0.8)';
        line(gx, Y(T), gx + gw, Y(T));
        var hid = x.tubes.some(function (tb) { return tb.s.crystal && Math.abs(Y(tb.s.mp) - Y(T)) < 12; });   // 让位给熔点标记
        if (!hid) label((T < 0 ? '−' : '') + Math.abs(T), gx - 6, Y(T), C.muted, 'right', fsz - 1, '', false, true);
      }
      var xstep = tm <= 12 ? 1 : tm <= 25 ? 2 : 5;
      for (var m = 0; m <= tm; m += xstep) {
        ctx.strokeStyle = 'rgba(42,52,70,0.8)'; line(X(m * 60), gy, X(m * 60), gy + gh);
        label(String(m), X(m * 60), gy + gh + 11, C.muted, 'center', fsz - 1, '', false, true);
      }
      ctx.strokeStyle = C.muted; ctx.lineWidth = 1.2;
      line(gx, gy + gh, gx + gw + 4, gy + gh); line(gx, gy + gh, gx, gy - 6);
      label('时间 / min', gx + gw, gy + gh + 24, C.muted, 'right', fsz - 1, '', false);
      label('温度 / °C', gx - pl + 4, gy - 9, C.muted, 'left', fsz - 1, '', false);

      // 熔点线 / 软化区间
      x.tubes.forEach(function (tb, i) {
        var s = tb.s;
        if (s.crystal) {
          ctx.setLineDash([5, 4]); ctx.strokeStyle = TUBE[i]; ctx.globalAlpha = 0.5; ctx.lineWidth = 1;
          line(gx, Y(s.mp), gx + gw, Y(s.mp)); ctx.setLineDash([]); ctx.globalAlpha = 1;
          // 纵轴上标出熔点（文字说明写在图像右上角）
          var ty = Y(s.mp);
          font(fsz - 1, '700', true);
          var tw = ctx.measureText(String(s.mp)).width + 8;
          ctx.fillStyle = TUBE[i]; rrect(gx - tw - 2, ty - 8, tw, 16, 3); ctx.fill();
          label(String(s.mp), gx - 6, ty, '#111', 'right', fsz - 1, '700', false, true);
        } else {
          ctx.fillStyle = i ? 'rgba(79,195,247,0.07)' : 'rgba(255,201,74,0.07)';
          ctx.fillRect(gx, Y(s.t2), gw, Y(s.t1) - Y(s.t2));
          label('逐渐软化 · 没有固定熔点', gx + gw - 4, Y(s.t2) + 9, TUBE[i], 'right', fsz - 1, '', true);
        }
      });

      // 水温（虚线）
      var S = rec.samples;
      if (st.showBath && !x.direct && S.length) {
        ctx.setLineDash([4, 4]); ctx.strokeStyle = BATH; ctx.lineWidth = 1.4; ctx.globalAlpha = 0.8;
        ctx.beginPath(); S.forEach(function (p, j) { var px = X(p.t), py = Y(clamp(p.b, ylo, yhi)); if (j) ctx.lineTo(px, py); else ctx.moveTo(px, py); });
        ctx.lineTo(X(x.t), Y(clamp(x.bath, ylo, yhi))); ctx.stroke(); ctx.setLineDash([]); ctx.globalAlpha = 1;
      }
      // 物质温度曲线
      x.tubes.forEach(function (tb, i) {
        if (!S.length) return;
        ctx.strokeStyle = TUBE[i]; ctx.lineWidth = 2.4; ctx.lineJoin = 'round';
        ctx.beginPath(); S.forEach(function (p, j) { var px = X(p.t), py = Y(clamp(p.T[i], ylo, yhi)); if (j) ctx.lineTo(px, py); else ctx.moveTo(px, py); });
        ctx.lineTo(X(x.t), Y(clamp(tb.T, ylo, yhi))); ctx.stroke();
        // 每分钟记录一次：描点
        ctx.fillStyle = TUBE[i];
        rec.minutes.forEach(function (row) { ctx.beginPath(); ctx.arc(X(row.t), Y(clamp(row.T[i], ylo, yhi)), 2.6, 0, TAU); ctx.fill(); });
        // 当前点
        ctx.beginPath(); ctx.arc(X(x.t), Y(clamp(tb.T, ylo, yhi)), 4, 0, TAU); ctx.fillStyle = '#fff'; ctx.fill();
        ctx.lineWidth = 2; ctx.strokeStyle = TUBE[i]; ctx.stroke();
      });

      // 分段标注
      if (st.marks) drawMarks(st, X, Y, fsz);

      // 撤去酒精灯的时刻
      rec.lampOff.forEach(function (t) {
        ctx.setLineDash([2, 4]); ctx.strokeStyle = 'rgba(141,153,171,0.6)'; ctx.lineWidth = 1;
        line(X(t), gy, X(t), gy + gh); ctx.setLineDash([]);
        label(x.mix || st.mixLabel ? '放入冰盐混合物' : '撤去酒精灯', X(t) + 4, gy + 10, C.muted, 'left', fsz - 2, '', true);
      });

      // 图例
      var lx = gx + 6, ly = box.y + (narrow ? 12 : 14);
      font(fsz - 1);
      x.tubes.forEach(function (tb, i) {
        ctx.strokeStyle = TUBE[i]; ctx.lineWidth = 2.4; line(lx, ly, lx + 16, ly);
        var t = tb.s.name + (tb.s.crystal ? '（晶体）' : '（非晶体）');
        label(t, lx + 20, ly, C.text, 'left', fsz - 1, '', false);
        lx += 26 + ctx.measureText(t).width + 10;
      });
      if (st.showBath && !x.direct) {
        ctx.setLineDash([4, 3]); ctx.strokeStyle = BATH; ctx.lineWidth = 1.4; line(lx, ly, lx + 16, ly); ctx.setLineDash([]);
        label(x.mix ? '冰盐混合物' : '水温', lx + 20, ly, C.text, 'left', fsz - 1, '', false);
      }
      // 右上角：熔点（凝固点）
      var rx = gx + gw;
      x.tubes.slice().reverse().forEach(function (tb, j) {
        var i = x.tubes.length - 1 - j, s = tb.s;
        if (!s.crystal) return;
        var t = (x.tubes.every(function (u) { return u.s.crystal; }) && x.tubes.length > 1 ? s.name : '') + (st.everCooled ? '熔点 = 凝固点 = ' : '熔点 ') + s.mp + ' °C';
        label(t, rx, ly, TUBE[i], 'right', fsz - 1, '600', false);
        font(fsz - 1, '600'); rx -= ctx.measureText(t).width + 12;
      });

      if (!st.started) label('点燃酒精灯开始加热，每分钟记录一次温度', gx + gw / 2, gy + gh / 2, C.muted, 'center', fsz + 1, '', false);

      // 悬停读数
      if (st.hover != null && S.length) drawHover(st, X, Y, gx, gy, gw, gh, fsz);
    }

    function drawMarks(st, X, Y, fsz) {
      var x = st.x, ev = st.rec.events;
      x.tubes.forEach(function (tb, i) {
        if (!tb.s.crystal) return;
        var list = ev[i], pts = list.map(function (e) { return { e: e, x: X(e.t), y: Y(e.T) }; });
        // 平台段文字
        for (var j = 0; j + 1 < pts.length; j++) {
          var a = pts[j], b = pts[j + 1];
          var txt = a.e.seg;
          if (!txt) continue;
          var mx = (a.x + b.x) / 2, my = (a.y + b.y) / 2, flat = Math.abs(a.y - b.y) < 3;
          font(fsz - 2, flat ? '600' : '');
          if (ctx.measureText(txt).width > Math.hypot(b.x - a.x, b.y - a.y) + (flat ? -16 : 30)) continue;
          label(txt, mx, my + (flat ? (a.e.below ? 13 : -13) : 0) + (flat ? 0 : -12), TUBE[i], 'center', fsz - 2, flat ? '600' : '', true);
        }
        // 正在进行的一段
        var last = pts[pts.length - 1];
        if (last && last.e.seg && st.started) {
          var cx = X(x.t), cy = Y(tb.T);
          font(fsz - 2, '600');
          if (ctx.measureText(last.e.seg).width < Math.hypot(cx - last.x, cy - last.y) - 16) {
            var flat2 = Math.abs(cy - last.y) < 3;
            label(last.e.seg, (last.x + cx) / 2, (last.y + cy) / 2 + (flat2 ? (last.e.below ? 13 : -13) : -12), TUBE[i], 'center', fsz - 2, flat2 ? '600' : '', true);
          }
        }
        pts.forEach(function (p) {
          ctx.fillStyle = '#05070d'; ctx.strokeStyle = TUBE[i]; ctx.lineWidth = 1.5;
          ctx.beginPath(); ctx.arc(p.x, p.y, 3.5, 0, TAU); ctx.fill(); ctx.stroke();
          label(p.e.name, p.x + (p.e.dx || 0), p.y + (p.e.dy || -12), TUBE[i], 'center', fsz, '700', true, true);
        });
      });
    }

    function drawHover(st, X, Y, gx, gy, gw, gh, fsz) {
      var S = st.rec.samples, t = clamp(st.hover, 0, st.x.t), best = S[0];
      S.forEach(function (p) { if (Math.abs(p.t - t) < Math.abs(best.t - t)) best = p; });
      var px = X(best.t);
      ctx.strokeStyle = 'rgba(230,235,242,0.5)'; ctx.lineWidth = 1; line(px, gy, px, gy + gh);
      var lines = [(best.t / 60).toFixed(1) + ' min'];
      st.x.tubes.forEach(function (tb, i) {
        lines.push(tb.s.name + ' ' + fmtT(best.T[i]) + ' · ' + M.phase(tb.s, best.f[i]) + (tb.s.crystal && best.f[i] > 0 && best.f[i] < 1 ? '（已熔化 ' + Math.round(best.f[i] * 100) + '%）' : ''));
        ctx.fillStyle = TUBE[i]; ctx.beginPath(); ctx.arc(px, Y(clamp(best.T[i], st.yRange[0], st.yRange[1])), 4, 0, TAU); ctx.fill();
      });
      if (!st.x.direct) lines.push((st.x.mix ? '冰盐混合物 ' : '水温 ') + fmtT(best.b));
      font(fsz - 1);
      var w = Math.max.apply(null, lines.map(function (s) { return ctx.measureText(s).width; })) + 16, h = lines.length * (fsz + 5) + 8;
      var bx = px + 10 + w > gx + gw ? px - 10 - w : px + 10, by = gy + 24;
      ctx.fillStyle = 'rgba(17,23,35,0.94)'; ctx.strokeStyle = C.line; rrect(bx, by, w, h, 6); ctx.fill(); ctx.stroke();
      lines.forEach(function (s, j) { label(s, bx + 8, by + 4 + (j + 0.5) * (fsz + 5), j ? C.text : C.muted, 'left', fsz - 1, '', false); });
    }

    function draw(st, dt) {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, W, H);
      var L = layout();
      drawRig(L.rig, st, dt);
      drawGraph(L.graph, st);
    }

    // 画布坐标 → 图像上的时间（秒），不在图像内返回 null
    function graphTime(px, py) {
      if (!gBox || !gMap) return null;
      if (px < gBox.x - 6 || px > gBox.x + gBox.w + 6 || py < gBox.y - 20 || py > gBox.y + gBox.h + 6) return null;
      return clamp((px - gBox.x) / gBox.w, 0, 1) * gMap.tm * 60;
    }

    return { resize: resize, draw: draw, graphTime: graphTime, resetParticles: function () { parts = [null, null]; lampX = 0; } };
  }

  window.MeltDraw = MeltDraw;
  window.MeltDraw.TUBE = TUBE;
})();
