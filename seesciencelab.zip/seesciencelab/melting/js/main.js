(function () {
  var M = window.Melt, SUBS = M.SUBS;
  var $ = function (id) { return document.getElementById(id); };
  var qa = function (sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); };

  var state = {
    sub: 'hypo', cmp: false, direct: false, speed: 10,
    started: false, paused: false, everCooled: false,
    micro: true, showBath: true, marks: true, labels: true,
    x: null, rec: null, hover: null, now: 0, yRange: [20, 100]
  };

  var stage = $('stage'), canvas = $('melt'), panel = $('panel');
  var view = window.MeltDraw(canvas), TUBE = window.MeltDraw.TUBE;

  function setSeg(attr, val) { qa('[data-' + attr + ']').forEach(function (b) { b.classList.toggle('on', b.dataset[attr] === String(val)); }); }
  function fmtT(T) { return (T < 0 ? '−' : '') + Math.abs(T).toFixed(1) + ' °C'; }
  function cmpKey() { return SUBS[state.sub].crystal ? 'wax' : 'hypo'; }

  // ---------- 新的一次实验 ----------
  function reset() {
    var subs = [state.sub];
    if (state.cmp && !state.direct && state.sub !== 'ice') subs.push(cmpKey());
    state.x = M.create(subs, state.direct);
    state.rec = { samples: [], minutes: [], events: subs.map(function () { return []; }), lampOff: [], flags: subs.map(function () { return {}; }) };
    state.started = false; state.paused = false; state.everCooled = false; state.hover = null;
    $('procNote').textContent = '';
    sampleAcc = 0;
    // 纵轴范围
    var lo = Math.min.apply(null, subs.map(function (k) { var s = SUBS[k]; return Math.min(s.t0, s.coolEnv != null ? s.coolEnv : 99); }));
    state.yRange = [Math.floor((lo - 5) / 10) * 10, state.direct ? 110 : 100];
    view.resetParticles();
    sample();
    addMinute(0);
    state.x.tubes.forEach(function (tb, i) {
      if (tb.s.crystal) state.rec.events[i].push({ name: 'A', t: 0, T: tb.T, seg: '固态', dy: 14 });
    });
    syncPanel();
    syncTable();
  }

  function sample() {
    var x = state.x;
    state.rec.samples.push({ t: x.t, T: x.tubes.map(function (tb) { return tb.T; }), f: x.tubes.map(function (tb) { return tb.f; }), b: x.bath });
  }
  function addMinute(m) {
    var x = state.x;
    state.rec.minutes.push({ m: m, t: x.t, T: x.tubes.map(function (tb) { return tb.T; }), f: x.tubes.map(function (tb) { return tb.f; }), b: x.bath });
  }

  // ---------- 记录关键点（晶体）：开始熔化、熔化完毕、开始凝固、凝固完毕 ----------
  var LETTERS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  function addEvent(i, seg, extra) {
    var ev = state.rec.events[i], tb = state.x.tubes[i];
    var e = { name: LETTERS[ev.length] || '·', t: state.x.t, T: tb.T, seg: seg };
    for (var k in extra) e[k] = extra[k];
    ev.push(e);
  }
  function watchEvents(prevF) {
    var x = state.x;
    x.tubes.forEach(function (tb, i) {
      if (!tb.s.crystal) return;
      var p = prevF[i], f = tb.f, fl = state.rec.flags[i], sg = tb.q > 0.05 ? 1 : tb.q < -0.05 ? -1 : 0;
      // 停在熔点上时吸热、放热方向反过来：熔化变成凝固（或反过来）
      if (p > 0 && p < 1 && f > 0 && f < 1 && sg && fl.sg && sg !== fl.sg) addEvent(i, sg > 0 ? '熔化：吸热，温度不变' : '凝固：放热，温度不变', sg > 0 ? { dy: 14, below: true } : { dy: -12 });
      if (sg) fl.sg = sg;
      if (p <= 0 && f > 0) addEvent(i, '熔化：吸热，温度不变', { dx: -8, dy: -12, below: true });
      else if (p < 1 && f >= 1) addEvent(i, '液态', { dx: 9, dy: 13 });
      else if (p >= 1 && f < 1) addEvent(i, '凝固：放热，温度不变', { dy: -12 });
      else if (p > 0 && f <= 0) addEvent(i, '固态', { dx: 8, dy: -12 });
    });
  }

  // ---------- 操作 ----------
  function lampAction() {
    var x = state.x;
    if (!state.started) {
      state.started = true; x.lamp = true; state.paused = false;
      Analytics.track('熔化凝固', '开始加热', SUBS[state.sub].name);
    } else if (x.lamp) {
      M.startCooling(x);
      state.everCooled = true;
      state.rec.lampOff.push(x.t);
      // 液态时撤灯：记一个点（课本里的 D），之后是"放热降温"
      x.tubes.forEach(function (tb, i) { if (tb.s.crystal && tb.f >= 1) addEvent(i, '液态：放热降温', { dy: -12 }); });
      Analytics.track('熔化凝固', '撤去酒精灯', SUBS[state.sub].name);
    } else {
      x.lamp = true; x.cooling = false; x.mix = false;
      x.tubes.forEach(function (tb, i) { if (tb.s.crystal) addEvent(i, tb.f >= 1 ? '液态' : tb.f <= 0 ? '固态' : '熔化：吸热，温度不变', { dy: 14, below: true }); });
    }
    state.paused = false;
    syncPanel();
  }
  $('lampBtn').addEventListener('click', lampAction);
  $('pauseBtn').addEventListener('click', function () { if (state.started) { state.paused = !state.paused; syncPanel(); } });
  $('resetBtn').addEventListener('click', function () { reset(); });

  qa('[data-speed]').forEach(function (b) {
    b.addEventListener('click', function () { state.speed = +b.dataset.speed; setSeg('speed', state.speed); syncPanel(); });
  });

  // ---------- 物质与设置 ----------
  qa('[data-sub]').forEach(function (b) {
    b.addEventListener('click', function () {
      state.sub = b.dataset.sub;
      if (state.sub === 'ice') state.direct = false;
      reset();
      Analytics.track('熔化凝固', '物质', SUBS[state.sub].name);
    });
  });
  $('cmp').addEventListener('change', function () {
    state.cmp = $('cmp').checked;
    if (state.cmp) { state.direct = false; }
    reset();
    if (state.cmp) Analytics.track('熔化凝固', '对比');
  });
  $('bath').addEventListener('change', function () {
    state.direct = !$('bath').checked;
    if (state.direct) state.cmp = false;
    reset();
    if (state.direct) Analytics.track('熔化凝固', '直接加热');
  });
  $('micro').addEventListener('change', function () { state.micro = $('micro').checked; });
  $('showBath').addEventListener('change', function () { state.showBath = $('showBath').checked; });
  $('marks').addEventListener('change', function () { state.marks = $('marks').checked; });
  $('labels').addEventListener('change', function () { state.labels = $('labels').checked; });

  document.addEventListener('keydown', function (e) {
    if (/INPUT|SELECT|TEXTAREA|BUTTON/.test(e.target.tagName)) return;
    if (e.key === ' ') { e.preventDefault(); if (!state.started) lampAction(); else { state.paused = !state.paused; syncPanel(); } }
  });

  // ---------- 图像上悬停读数 ----------
  function hover(e) {
    var r = canvas.getBoundingClientRect();
    state.hover = view.graphTime(e.clientX - r.left, e.clientY - r.top);
  }
  canvas.addEventListener('pointermove', hover);
  canvas.addEventListener('pointerdown', hover);
  canvas.addEventListener('pointerleave', function () { state.hover = null; });

  // ---------- 面板 ----------
  function process(tb, x) {
    var s = tb.s, q = tb.q, f = tb.f, heat = q > 0.3, cool = q < -0.3;
    if (!state.started) return '等待加热';
    if (s.crystal) {
      if (f > 0 && f < 1) return heat ? '正在熔化：吸热，温度保持 ' + s.mp + ' °C 不变' : cool ? '正在凝固：放热，温度保持 ' + s.mp + ' °C 不变' : '温度等于熔点，但不能吸热或放热：熔化（凝固）暂停';
      var st = f >= 1 ? '液态' : '固态';
      return heat ? st + '，吸热，温度升高' : cool ? st + '，放热，温度降低' : st + '，温度几乎不变';
    }
    if (heat) return f <= 0.02 ? '固态，吸热，温度升高' : f < 0.98 ? '吸热，温度升高，同时逐渐变软、变稀' : '液态，吸热，温度升高';
    if (cool) return f <= 0.02 ? '固态，放热，温度降低' : f < 0.98 ? '放热，温度降低，同时逐渐变稠、变硬' : '液态，放热，温度降低';
    return '温度几乎不变';
  }
  function stateText(tb) {
    var p = M.phase(tb.s, tb.f);
    if (tb.s.crystal && tb.f > 0 && tb.f < 1) p += '（已熔化 ' + Math.round(tb.f * 100) + '%）';
    return p;
  }

  var lastSig = '';
  function syncPanel() {
    var x = state.x, s = SUBS[state.sub];
    setSeg('sub', state.sub);
    setSeg('speed', state.speed);
    $('cmp').checked = state.cmp && x.tubes.length > 1;
    $('cmp').disabled = state.direct || state.sub === 'ice';
    $('cmpLabel').textContent = '同时加热一支' + SUBS[cmpKey()].name + '（对比）';
    $('bath').checked = !state.direct;
    $('bath').disabled = state.sub === 'ice';
    $('showBath').disabled = state.direct;

    $('rName').textContent = s.name;
    $('rKind').textContent = s.crystal ? '晶体' : '非晶体';
    $('rKind').className = 'kind ' + (s.crystal ? 'c' : 'a');
    $('rMp').textContent = s.crystal ? s.mp + ' °C（晶体有固定的熔点）' : '没有固定的熔点（约 ' + s.t1 + '～' + s.t2 + ' °C 逐渐变软变稀）';
    $('rFact').textContent = '💡 ' + s.fact;
    $('rowB').hidden = $('rTB').hidden = x.tubes.length < 2;
    if (x.tubes.length > 1) $('rNameB').textContent = x.tubes[1].s.name + '温度';
    $('rNameA').textContent = s.name + '温度';
    $('rowBath').hidden = $('rBath').hidden = state.direct;
    $('rBathName').textContent = x.mix ? '冰盐混合物' : '水温';

    var ice = state.sub === 'ice';
    $('lampBtn').textContent = !state.started ? '🔥 点燃酒精灯，开始加热' : x.lamp ? (ice && !state.direct ? '❄ 撤去酒精灯，放入冰盐混合物' : '撤去酒精灯') : '🔥 重新点燃酒精灯';
    $('lampBtn').classList.toggle('hot', !state.started || !x.lamp);
    $('pauseBtn').disabled = !state.started;
    $('pauseBtn').textContent = state.paused ? '▶ 继续' : '❚❚ 暂停';
    $('speedNote').textContent = '实际 1 秒 = 实验 ' + state.speed + ' 秒';
    $('setNote').textContent = state.direct
      ? '直接用酒精灯加热：温度上升太快，来不及记录，而且试管受热不均匀。'
      : '水浴法：试管放在热水里，物质受热均匀，温度上升较慢，便于记录。' + (ice ? '冰的熔点低，用常温的水就能让它熔化。' : '');
    lastSig = '';
    syncLive();
  }

  // 每帧刷新的读数（只在文字变化时写 DOM）
  function syncLive() {
    var x = state.x, a = x.tubes[0], b = x.tubes[1];
    var sig = [x.t.toFixed(0), a.T.toFixed(1), stateText(a), process(a, x), b ? b.T.toFixed(1) + stateText(b) : '', x.bath.toFixed(0), state.started].join('|');
    if (sig === lastSig) return;
    lastSig = sig;
    $('rTime').textContent = (x.t / 60).toFixed(1) + ' min';
    $('rTA').textContent = fmtT(a.T);
    $('rStA').textContent = stateText(a);
    $('rProc').textContent = process(a, x);
    if (b) $('rTB').textContent = fmtT(b.T) + ' · ' + stateText(b);
    $('rBath').textContent = fmtT(x.bath);
  }

  // ---------- 记录表 ----------
  function syncTable() {
    var x = state.x, rows = state.rec.minutes, two = x.tubes.length > 1;
    var head = '<tr><th>时间/min</th><th>' + x.tubes[0].s.name + ' / °C</th>' + (two ? '<th>' + x.tubes[1].s.name + ' / °C</th>' : '') + '<th>状态</th></tr>';
    var body = rows.map(function (r) {
      return '<tr><td>' + r.m + '</td><td>' + r.T[0].toFixed(1) + '</td>' + (two ? '<td>' + r.T[1].toFixed(1) + '</td>' : '') +
        '<td>' + M.phase(x.tubes[0].s, r.f[0]) + '</td></tr>';
    }).join('');
    $('table').innerHTML = '<thead>' + head + '</thead><tbody>' + body + '</tbody>';
    var wrap = $('tableWrap');
    wrap.scrollTop = wrap.scrollHeight;
  }

  // ---------- 面板开合 ----------
  $('panelToggle').addEventListener('click', function () { panel.classList.toggle('collapsed'); });
  if (window.matchMedia('(max-width: 760px)').matches) panel.classList.add('collapsed');
  if (window.matchMedia('(max-width: 640px)').matches) $('hint').hidden = true;

  // ---------- 尺寸与主循环 ----------
  function resize() { view.resize(stage.clientWidth, stage.clientHeight); }
  new ResizeObserver(resize).observe(stage);
  resize();

  // 支持 ?sub=hypo|naph|ice|wax|rosin、&cmp=1（晶体与非晶体对比）、&direct=1（不用水浴）
  var qs = new URLSearchParams(location.search);
  if (SUBS[qs.get('sub')]) state.sub = qs.get('sub');
  if (qs.get('cmp') === '1' && state.sub !== 'ice') state.cmp = true;
  else if (qs.get('direct') === '1' && state.sub !== 'ice') state.direct = true;
  $('micro').checked = state.micro; $('showBath').checked = state.showBath; $('marks').checked = state.marks; $('labels').checked = state.labels;
  reset();

  // 推进 sim 秒模拟时间：细分步长，保证关键点和每分钟的记录不被跳过
  var MAX_T = 60 * 60, sampleAcc = 0;
  function advance(sim) {
    var x = state.x, prevF = x.tubes.map(function (tb) { return tb.f; });
    while (sim > 1e-6) {
      var h = Math.min(sim, 1, 60 - (x.t % 60) || 60);
      M.step(x, h); sim -= h;
      watchEvents(prevF);
      prevF = x.tubes.map(function (tb) { return tb.f; });
      sampleAcc += h;
      if (sampleAcc >= 3) { sampleAcc = 0; sample(); }
      var m = Math.round(x.t / 60);
      if (Math.abs(x.t - m * 60) < 1e-6 && m > state.rec.minutes[state.rec.minutes.length - 1].m) { addMinute(m); syncTable(); }
      if (x.lamp && x.tubes.some(function (tb) { return tb.T > M.RIG.tMax; })) {
        lampAction();
        $('procNote').textContent = '温度快超过温度计的量程了，已撤去酒精灯。';
      }
      if (x.t >= MAX_T) { state.paused = true; syncPanel(); break; }
    }
  }

  var lastT = performance.now();
  function frame(t) {
    var dt = Math.min((t - lastT) / 1000, 0.1);
    lastT = t;
    state.now += dt;
    if (state.started && !state.paused) advance(dt * state.speed);
    syncLive();
    view.draw(state, dt);
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // 调试用
  window.__model = { state: state, view: view, reset: reset, lamp: lampAction, advance: advance, M: M };
})();
