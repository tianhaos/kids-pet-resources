// 熔化与凝固：物质数据、焓—温度关系、水浴与试管的传热（纯计算，不涉及绘图）
// 单位：温度 °C，时间 s（模拟时间），能量 J，热容 J/°C，热导 W/°C。
// 每支试管里约 20 g 物质，用"焓 H"做状态量：晶体在熔点处 H 跨过潜热 L 而温度不变；
// 非晶体把"潜热"摊在软化区间 [t1, t2] 上，温度一直上升，只是变慢。
(function () {
  var TREF = -60;            // 焓的零点
  var ROOM = 20;             // 室温

  // cs/cl：固态/液态热容（20 g 物质），L：熔化吸收的热量
  var SUBS = {
    hypo: { name: '海波', formula: '硫代硫酸钠晶体', crystal: true, mp: 48, cs: 29, cl: 48, L: 4000, t0: 26, bath0: 34,
      color: '#eef3f6', liquid: 'rgba(214,232,240,0.55)', shape: 'grain',
      fact: '海波（大苏打）常用作照相定影剂。它的熔点 48 °C 不高，用热水就能熔化，所以课本用它做晶体熔化实验。' },
    naph: { name: '萘', formula: '卫生球的主要成分', crystal: true, mp: 80.5, cs: 26, cl: 34, L: 2950, t0: 56, bath0: 66,
      color: '#f4f4ee', liquid: 'rgba(240,238,220,0.5)', shape: 'flake',
      fact: '萘的熔点 80.5 °C，比海波高，水浴的水温要升到 80 多摄氏度它才开始熔化。萘有刺激性气味，现在家用防蛀球已改用樟脑等。' },
    ice: { name: '冰', formula: '固态的水', crystal: true, mp: 0, cs: 42, cl: 84, L: 6700, t0: -12, bath0: 6,
      color: '#cfe8ff', liquid: 'rgba(120,180,255,0.35)', shape: 'cube', coolEnv: -15, coolName: '冰盐混合物',
      fact: '冰的熔点是 0 °C。让水凝固要把试管放进约 −15 °C 的冰盐混合物里（盐使冰在更低的温度熔化，从周围吸热）。' },
    wax: { name: '石蜡', formula: '非晶体', crystal: false, t1: 46, t2: 64, cs: 44, cl: 52, L: 1300, t0: 32, bath0: 40,
      color: '#f3efe2', liquid: 'rgba(245,238,214,0.6)', shape: 'chunk',
      fact: '石蜡受热先变软、变稀，再变成液体，整个过程温度一直在上升，没有固定的熔点。蜡烛燃烧时烛芯附近的蜡就是这样熔化的。' },
    rosin: { name: '松香', formula: '非晶体', crystal: false, t1: 50, t2: 76, cs: 30, cl: 40, L: 900, t0: 36, bath0: 46,
      color: '#d99a3a', liquid: 'rgba(214,140,40,0.62)', shape: 'chunk',
      fact: '松香是松树分泌的树脂提炼而成的，拉小提琴时擦在弓毛上增大摩擦。它没有固定的熔点，加热时逐渐变软、变稀。' }
  };
  var ORDER = ['hypo', 'naph', 'ice', 'wax', 'rosin'];

  // 实验装置的参数
  var RIG = {
    cw: 630,          // 烧杯里约 150 g 水的热容
    lamp: 100,        // 酒精灯传给烧杯的有效功率
    kAir: 1.2,        // 烧杯向空气散热
    kTube: 1.0,       // 水 ↔ 试管
    kMix: 6,          // 冰盐混合物（大量）维持低温
    flame: 160,       // 直接加热：火焰外焰对试管的"等效温度"
    kFlame: 0.32,
    kTubeAir: 0.4,    // 直接加热时试管在空气中散热
    boil: 100,
    tMax: 105         // 超过它自动撤去酒精灯（温度计量程）
  };

  function smooth(u) { u = Math.max(0, Math.min(1, u)); return u * u * (3 - 2 * u); }

  // 温度 → 焓（单调递增）
  function enthalpy(s, T) {
    if (s.crystal) {
      if (T < s.mp) return s.cs * (T - TREF);
      return s.cs * (s.mp - TREF) + s.L + s.cl * (T - s.mp);
    }
    // 非晶体：热容在软化区间里由 cs 平滑过渡到 cl，同时吸收 L
    var Hs = s.cs * (T - TREF), w = s.t2 - s.t1, u = (T - s.t1) / w;
    var blend = T <= s.t1 ? 0 : T >= s.t2 ? (s.cl - s.cs) * (T - s.t2 + w / 2) : (s.cl - s.cs) * w * (u * u * u - u * u * u * u / 2);
    return Hs + blend + s.L * smooth(u);
  }

  // 焓 → { T 温度, f 已熔化（软化）比例 }
  function fromH(s, H) {
    if (s.crystal) {
      var H1 = s.cs * (s.mp - TREF);
      if (H <= H1) return { T: TREF + H / s.cs, f: 0 };
      if (H <= H1 + s.L) return { T: s.mp, f: (H - H1) / s.L };
      return { T: s.mp + (H - H1 - s.L) / s.cl, f: 1 };
    }
    var lo = TREF, hi = 300;
    for (var i = 0; i < 40; i++) {
      var mid = (lo + hi) / 2;
      if (enthalpy(s, mid) < H) lo = mid; else hi = mid;
    }
    var T = (lo + hi) / 2;
    return { T: T, f: smooth((T - s.t1) / (s.t2 - s.t1)) };
  }

  // 状态文字
  function phase(s, f) {
    if (s.crystal) return f <= 0 ? '固态' : f >= 1 ? '液态' : '固液共存';
    return f <= 0.02 ? '固态' : f < 0.35 ? '变软' : f < 0.98 ? '变稀（黏稠）' : '液态';
  }

  // 新建一次实验。subs：试管里的物质 key 数组（1～2 支），direct：直接用酒精灯加热（不用水浴）
  function create(subs, direct) {
    var s0 = SUBS[subs[0]];
    var bath = Math.max.apply(null, subs.map(function (k) { return SUBS[k].bath0; }));
    return {
      t: 0, lamp: false, cooling: false, direct: !!direct, bath: direct ? ROOM : bath, mix: false,
      tubes: subs.map(function (k) {
        var s = SUBS[k], T0 = direct ? s.t0 : s.t0;
        return { key: k, s: s, H: enthalpy(s, T0), T: T0, f: 0, q: 0 };
      }),
      coolEnv: s0.coolEnv != null ? s0.coolEnv : ROOM
    };
  }

  // 撤去酒精灯：冰要放进冰盐混合物才能凝固
  function startCooling(x) {
    x.lamp = false; x.cooling = true;
    if (x.coolEnv < ROOM && !x.direct) { x.mix = true; x.bath = x.coolEnv; }
  }

  // 推进 dt 秒（内部再细分步长保证稳定）
  function step(x, dt) {
    var n = Math.max(1, Math.ceil(dt / 0.5)), h = dt / n;
    for (var i = 0; i < n; i++) {
      var qSum = 0;
      x.tubes.forEach(function (tb) {
        var q;
        if (x.direct) q = x.lamp ? RIG.kFlame * (RIG.flame - tb.T) : RIG.kTubeAir * ((x.cooling ? x.coolEnv : ROOM) - tb.T);
        else q = RIG.kTube * (x.bath - tb.T);
        tb.q = q;
        tb.H += q * h;
        var r = fromH(tb.s, tb.H);
        tb.T = r.T; tb.f = r.f;
        qSum += q;
      });
      if (!x.direct) {
        if (x.mix) x.bath += (RIG.kMix * (x.coolEnv - x.bath) - qSum) / RIG.cw * h;
        else {
          x.bath += ((x.lamp ? RIG.lamp : 0) - RIG.kAir * (x.bath - ROOM) - qSum) / RIG.cw * h;
          if (x.bath > RIG.boil) x.bath = RIG.boil;
        }
      }
      x.t += h;
    }
  }

  window.Melt = {
    SUBS: SUBS, ORDER: ORDER, RIG: RIG, ROOM: ROOM,
    enthalpy: enthalpy, fromH: fromH, phase: phase, create: create, step: step, startCooling: startCooling, smooth: smooth
  };
})();
