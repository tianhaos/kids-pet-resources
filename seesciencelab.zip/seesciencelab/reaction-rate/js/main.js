(function () {
  'use strict';
  const $ = id => document.getElementById(id);
  const query = new URLSearchParams(location.search);
  const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)');
  const mobile = matchMedia('(max-width: 850px)');
  const clamp = (value, min, max, fallback) => value !== null && Number.isFinite(Number(value))
    ? Math.min(max, Math.max(min, Number(value))) : fallback;
  const requestedScene = query.get('scene');
  const scene = Object.hasOwn(Kinetics.presets, requestedScene) ? requestedScene : 'temperature';
  const explanations = {
    temperature: '升温使更多粒子具有足够能量，活化能保持不变。',
    concentration: 'A、B 同时加倍时，有效碰撞机会增加，初始速率变为四倍。',
    catalyst: '催化剂提供较低能垒的途径，反应热保持不变。',
    custom: '对照实验可每次只改变一个条件。'
  };
  const state = {
    scene,
    params: { ...Kinetics.presets[scene] },
    view: query.get('view') === 'energy' || (query.get('view') !== 'concentration' && scene === 'catalyst')
      ? 'energy' : 'concentration',
    t: clamp(query.get('t'), 0, 120, 0),
    playing: query.get('play') === '1' || (query.get('play') !== '0' && !reducedMotion.matches)
  };
  state.params.temperature = clamp(query.get('T'), 280, 360, state.params.temperature);
  state.params.concentration = clamp(query.get('c'), 0.5, 2, state.params.concentration);
  if (query.has('cat')) state.params.catalyst = query.get('cat') === '1';

  if (requestedScene === 'custom' || Object.keys(state.params).some(key => state.params[key] !== Kinetics.presets[scene][key])) {
    state.scene = 'custom';
  }

  const chart = $('chart'), scrub = $('scrub'), panel = $('panel'), toggle = $('panelToggle');
  const canvases = [$('baseChamber'), $('expChamber'), chart];
  const sceneButtons = document.querySelectorAll('[data-scene]');
  const viewButtons = document.querySelectorAll('[data-view]');
  const displayNumber = value => Number(value.toFixed(2));
  let probePointer = null;
  let dirty = true;

  function track(action, label) {
    if (window.Analytics) Analytics.track('反应速率与碰撞理论', action, label);
  }

  function setView(view) {
    state.view = view;
    viewButtons.forEach(button => {
      const selected = button.dataset.view === view;
      button.classList.toggle('on', selected);
      button.setAttribute('aria-pressed', String(selected));
    });
    const energy = view === 'energy';
    chart.classList.toggle('scrubbable', !energy);
    chart.setAttribute('aria-label', energy ? '两条反应路径的相对能量图'
      : '两组反应物浓度图。拖动图表探测，键盘可使用时间滑块。');
    $('probe').hidden = energy;
    $('energyNote').hidden = !energy;
    dirty = true;
  }

  function syncConditions() {
    const { temperature, concentration, catalyst } = state.params;
    $('temperature').value = temperature;
    $('concentration').value = concentration;
    $('catalyst').checked = catalyst;
    const T = displayNumber(temperature), C = concentration.toFixed(2).replace(/(\.\d)0$/, '$1');
    $('temperatureValue').textContent = T + ' K';
    $('concentrationValue').textContent = C + ' mol/L';
    $('conditions').textContent = `${T} K · ${C} mol/L`;
    $('method').textContent = catalyst ? '有催化剂' : '无催化剂';
    $('ratio').textContent = Kinetics.initialRatio(state.params).toFixed(2) + '×';
    $('barrier').textContent = `活化能 40 / ${Kinetics.energy(state.params) / 1000} kJ/mol`;
    $('explain').textContent = explanations[state.scene];
    sceneButtons.forEach(button => {
      const selected = button.dataset.scene === state.scene;
      button.classList.toggle('on', selected);
      button.setAttribute('aria-pressed', String(selected));
    });
    dirty = true;
  }

  function reset() {
    state.t = 0;
    state.playing = !reducedMotion.matches;
    $('shareStatus').textContent = '';
    dirty = true;
  }

  function preset(name) {
    if (!Object.hasOwn(Kinetics.presets, name)) return;
    state.scene = name;
    state.params = { ...Kinetics.presets[name] };
    reset();
    syncConditions();
    setView(name === 'catalyst' ? 'energy' : 'concentration');
    track('切换对照实验', name);
  }

  function seek(time) {
    state.t = Math.round(time * 10) / 10;
    state.playing = false;
    dirty = true;
  }

  sceneButtons.forEach(button => { button.onclick = () => preset(button.dataset.scene); });
  viewButtons.forEach(button => {
    button.onclick = () => {
      setView(button.dataset.view);
      track('切换图表', state.view);
    };
  });
  ['temperature', 'concentration', 'catalyst'].forEach(id => {
    const input = $(id);
    input.oninput = () => {
      state.params[id] = id === 'catalyst' ? input.checked : Number(input.value);
      state.scene = 'custom';
      reset();
      syncConditions();
    };
    input.onchange = () => track('改变条件', id + ':' + state.params[id]);
  });
  scrub.oninput = () => seek(Number(scrub.value));
  scrub.onchange = () => track('探测浓度', '时间滑块');

  function seekFromChart(event) {
    const rect = chart.getBoundingClientRect();
    seek(RateDraw.timeAt(event.clientX - rect.left, rect.width));
  }

  chart.onpointerdown = event => {
    if (state.view !== 'concentration' || probePointer !== null || event.button !== 0) return;
    probePointer = event.pointerId;
    chart.setPointerCapture(event.pointerId);
    seekFromChart(event);
    track('探测浓度', '曲线');
  };
  chart.onpointermove = event => {
    if (event.pointerId === probePointer) seekFromChart(event);
  };
  chart.onlostpointercapture = () => { probePointer = null; };

  $('play').onclick = () => {
    if (state.t === 120) state.t = 0;
    state.playing = !state.playing;
    dirty = true;
    track('播放暂停', String(state.playing));
  };
  $('reset').onclick = () => { reset(); track('重新开始', state.scene); };

  function setPanel(open, moveFocus = false) {
    const active = mobile.matches && open;
    panel.classList.toggle('collapsed', !active);
    $('stage').inert = active;
    toggle.setAttribute('aria-expanded', String(active));
    if (moveFocus) (active ? $('closePanel') : toggle).focus({ preventScroll: true });
  }

  toggle.onclick = () => setPanel(panel.classList.contains('collapsed'), true);
  $('closePanel').onclick = () => setPanel(false, true);
  panel.addEventListener('keydown', event => {
    if (event.key === 'Escape' && mobile.matches) setPanel(false, true);
  });
  panel.querySelector('.learn-link').onclick = () => setPanel(false);
  mobile.addEventListener('change', () => setPanel(false));
  reducedMotion.addEventListener('change', event => {
    if (event.matches) {
      state.playing = false;
      dirty = true;
    }
  });

  $('share').onclick = async () => {
    const url = new URL(location.href);
    url.search = new URLSearchParams({
      scene: state.scene,
      T: state.params.temperature, c: state.params.concentration, cat: state.params.catalyst ? '1' : '0',
      t: state.t.toFixed(1), play: '0', view: state.view
    });
    url.hash = '';
    try {
      await navigator.clipboard.writeText(url.href);
      $('shareStatus').textContent = '实验链接已复制，打开即停在当前时刻。';
      track('复制实验链接', state.scene);
    } catch {
      $('shareStatus').textContent = url.href;
    }
  };

  function update() {
    const a = Kinetics.sample(Kinetics.base, state.t), b = Kinetics.sample(state.params, state.t);
    const baseConversion = (a.conversion * 100).toFixed(1) + '%';
    const expConversion = (b.conversion * 100).toFixed(1) + '%';
    $('baseConversion').textContent = $('baseFill').style.width = baseConversion;
    $('conversion').textContent = $('expFill').style.width = expConversion;
    $('time').textContent = state.t.toFixed(1) + ' s';
    scrub.value = state.t.toFixed(1);
    $('baseConc').textContent = a.c.toFixed(3);
    $('expConc').textContent = b.c.toFixed(3);
    $('baseRate').textContent = a.rate.toFixed(4);
    $('expRate').textContent = b.rate.toFixed(4);
    const playLabel = state.playing ? '暂停' : (state.t === 120 ? '重新播放' : '播放');
    const play = $('play');
    if (play.title !== playLabel) {
      play.title = playLabel;
      play.setAttribute('aria-label', playLabel);
      play.firstElementChild.textContent = state.playing ? 'Ⅱ' : '▶';
    }
  }

  let last;
  function frame(now) {
    const dt = last === undefined ? 0 : Math.min(0.05, (now - last) / 1000);
    last = now;
    if (state.playing) {
      state.t = Math.min(120, state.t + dt * 3);
      if (state.t === 120) state.playing = false;
      dirty = true;
    }
    if (dirty) {
      dirty = false;
      RateDraw.chamber(canvases[0], Kinetics.base, state.t);
      RateDraw.chamber(canvases[1], state.params, state.t);
      RateDraw.chart(chart, state);
      update();
    }
    requestAnimationFrame(frame);
  }

  const watchSize = new ResizeObserver(() => { dirty = true; });
  canvases.forEach(canvas => watchSize.observe(canvas));
  window.__model = { state, preset, reset, seek, sample: () => Kinetics.sample(state.params, state.t) };
  syncConditions();
  setView(state.view);
  requestAnimationFrame(frame);
})();
