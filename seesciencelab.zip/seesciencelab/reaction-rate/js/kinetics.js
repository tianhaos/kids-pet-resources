/* 恒温恒容、等初始浓度的不可逆基元反应示意；不依赖 DOM。 */
(function () {
  'use strict';
  const R = 8.314;
  const base = Object.freeze({ temperature: 300, concentration: 1, catalyst: false });
  const presets = {
    temperature: { temperature: 330, concentration: 1, catalyst: false },
    concentration: { temperature: 300, concentration: 2, catalyst: false },
    catalyst: { temperature: 300, concentration: 1, catalyst: true }
  };
  function energy(p) { return p.catalyst ? 36000 : 40000; }
  function k(p) { return 0.025 * Math.exp((40000 / 300 - energy(p) / p.temperature) / R); }
  function sample(p, t) {
    const c0 = p.concentration;
    const c = c0 / (1 + k(p) * c0 * Math.max(0, t));
    return { c, product: c0 - c, rate: k(p) * c * c, conversion: 1 - c / c0 };
  }
  function initialRatio(p) { return sample(p, 0).rate / sample(base, 0).rate; }
  window.Kinetics = { base, presets, energy, k, sample, initialRatio };
})();
