/* 粒子轨迹为可重复的教学示意，宏观数据只取自 Kinetics。 */
(function () {
  'use strict';
  const gold = '#ffd277', blue = '#7bd9ff', muted = '#9cadc3', grid = '#263448';
  const atomColors = [
    ['#fff2bd', '#f6b943', '#995820'],
    ['#d8faff', '#55c9f7', '#275a9a']
  ];
  let c;

  function prepare(canvas) {
    const dpr = Math.min(devicePixelRatio || 1, 2);
    const w = canvas.clientWidth, h = canvas.clientHeight;
    const width = Math.round(w * dpr), height = Math.round(h * dpr);
    if (canvas.width !== width || canvas.height !== height) {
      canvas.width = width;
      canvas.height = height;
    }
    c = canvas.getContext('2d');
    c.setTransform(dpr, 0, 0, dpr, 0, 0);
    c.clearRect(0, 0, w, h);
    return { w, h };
  }

  function text(label, x, y, { color = muted, align = 'left', size = 11 } = {}) {
    c.fillStyle = color;
    c.textAlign = align;
    c.font = `${size}px -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif`;
    c.fillText(label, x, y);
  }

  function line(points, color, width = 1, dash = []) {
    c.strokeStyle = color;
    c.lineWidth = width;
    c.setLineDash(dash);
    c.beginPath();
    points.forEach(([x, y], i) => i ? c.lineTo(x, y) : c.moveTo(x, y));
    c.stroke();
    c.setLineDash([]);
  }

  function dot(x, y, radius, fill) {
    c.fillStyle = fill;
    c.beginPath();
    c.arc(x, y, radius, 0, 2 * Math.PI);
    c.fill();
  }

  function atom(x, y, radius, type) {
    const fill = c.createRadialGradient(x - radius * 0.3, y - radius * 0.35, 0, x, y, radius);
    atomColors[type].forEach((color, i) => fill.addColorStop(i === 1 ? 0.56 : i / 2, color));
    dot(x, y, radius, fill);
  }

  // 反射轨迹与反应时刻均为确定值，拖动时间可以回看同一画面。
  function bounce(position) {
    const folded = ((position % 2) + 2) % 2;
    return 1 - Math.abs(1 - folded);
  }

  function freePosition(seed, time, speed) {
    const angle = seed * 2.399963;
    return [
      bounce(seed * 0.618034 + time * speed * Math.cos(angle) * 0.115),
      bounce(seed * 0.414214 + time * speed * Math.sin(angle) * 0.16)
    ];
  }

  function chamber(canvas, params, time) {
    const { w, h } = prepare(canvas);
    if (w < 40 || h < 35) return;
    const surface = c.createLinearGradient(0, 0, 0, h);
    surface.addColorStop(0, '#0a1421');
    surface.addColorStop(0.56, '#111d2d');
    surface.addColorStop(1, '#080d16');
    c.fillStyle = surface;
    c.fillRect(0, 0, w, h);
    c.strokeStyle = '#2a4058';
    c.lineWidth = 1.5;
    c.beginPath();
    c.roundRect(6.5, 4.5, w - 13, h - 9, 9);
    c.stroke();
    line([[17, 8.5], [w - 17, 8.5]], '#253952');

    const radius = Math.min(8.5, Math.max(3.4, Math.sqrt(w * h) / 37));
    const pad = radius * 2.3 + 8;
    const toX = x => pad + x * (w - pad * 2);
    const toY = y => pad + y * (h - pad * 2);
    const count = Math.round(params.concentration * 14);
    const speed = Math.sqrt(params.temperature / 300);
    const conversionRate = Kinetics.k(params) * params.concentration;
    for (let i = 0; i < count; i++) {
      // 由解析解的等分位点安排结合，使画面里的 AB 比例接近计算读数。
      const fraction = (i + 0.5) / count;
      const joinTime = fraction / ((1 - fraction) * conversionRate);
      const approachTime = Math.min(0.9, joinTime);
      const begin = joinTime - approachTime;
      const seed = i * 2 + 1;
      if (time <= begin) {
        const [ax, ay] = freePosition(seed, time, speed);
        const [bx, by] = freePosition(seed + 1, time, speed);
        atom(toX(ax), toY(ay), radius, 0);
        atom(toX(bx), toY(by), radius, 1);
        continue;
      }
      const [ax, ay] = freePosition(seed, begin, speed);
      const [bx, by] = freePosition(seed + 1, begin, speed);
      const cx = (ax + bx) / 2, cy = (ay + by) / 2;
      const angle = Math.atan2(toY(by) - toY(ay), toX(bx) - toX(ax));
      const drift = Math.max(0, time - joinTime) * speed;
      const x = toX(bounce(cx + drift * 0.06 * Math.cos(seed)));
      const y = toY(bounce(cy + drift * 0.087 * Math.sin(seed)));
      const turn = angle + drift * 0.45;
      const dx = Math.cos(turn) * radius * 1.14, dy = Math.sin(turn) * radius * 1.14;
      const mix = Math.min(1, (time - begin) / approachTime);
      const xa = toX(ax) * (1 - mix) + (x - dx) * mix;
      const ya = toY(ay) * (1 - mix) + (y - dy) * mix;
      const xb = toX(bx) * (1 - mix) + (x + dx) * mix;
      const yb = toY(by) * (1 - mix) + (y + dy) * mix;
      if (time >= joinTime) line([[xa, ya], [xb, yb]], '#b4c8db', radius * 0.65);
      atom(xa, ya, radius, 0);
      atom(xb, yb, radius, 1);
    }
  }

  function bounds(w) {
    return { left: 45, right: w - 24 };
  }

  function frame(w, h, label, unit, values, min, max) {
    const { left, right } = bounds(w);
    const top = 30, bottom = h - 24;
    const y = value => bottom - (value - min) / (max - min) * (bottom - top);
    text(label, 12, 18, { color: '#c8d5e4' });
    text(unit, right, 18, { align: 'right' });
    for (const value of values) {
      line([[left, y(value)], [right, y(value)]], grid);
      text(String(value).replace('-', '−'), left - 7, y(value) + 4, { align: 'right' });
    }
    line([[left, top], [left, bottom]], grid);
    return { left, right, top, bottom, y };
  }

  function series(basePoints, expPoints) {
    line(expPoints, blue, 2.4);
    line(basePoints, gold, 2.1, [5, 5]);
  }

  function concentration(state, w, h) {
    const max = state.params.concentration > 1 ? 2 : 1;
    const ticks = max === 2 ? [0, 0.5, 1, 1.5, 2] : [0, 0.25, 0.5, 0.75, 1];
    const { left, right, top, bottom, y } = frame(w, h, '反应物浓度 c(A)', 'mol/L', ticks, 0, max);
    const x = time => left + time / 120 * (right - left);
    for (const time of [0, 30, 60, 90, 120]) {
      if (time) line([[x(time), top], [x(time), bottom]], grid);
      text(time === 120 ? '120 s' : String(time), x(time), bottom + 15, { align: 'center' });
    }
    const points = params => Array.from({ length: 121 }, (_, time) => [x(time), y(Kinetics.sample(params, time).c)]);
    series(points(Kinetics.base), points(state.params));
    const cursor = x(state.t);
    line([[cursor, top], [cursor, bottom]], '#c3d2e3', 1, [3, 3]);
    dot(cursor, y(Kinetics.sample(Kinetics.base, state.t).c), 5, gold);
    dot(cursor, y(Kinetics.sample(state.params, state.t).c), 3.2, blue);
  }

  function energy(state, w, h) {
    const { left, right, bottom, y } = frame(w, h, '相对能量', 'kJ/mol', [-20, 0, 20, 40], -20, 48);
    const points = peak => Array.from({ length: 101 }, (_, step) => {
      const u = step / 100;
      const wave = Math.sin(Math.PI * u) ** 2;
      const value = u < 0.5 ? peak * wave : -20 + (peak + 20) * wave;
      return [left + (right - left) * u, y(value)];
    });
    series(points(40), points(Kinetics.energy(state.params) / 1000));
    text('A + B', left + 9, y(0) + 14);
    text('AB', right - 4, y(-20) - 7, { align: 'right' });
    text('反应进程 →', (left + right) / 2, bottom + 16, { align: 'center' });
  }

  function chart(canvas, state) {
    const { w, h } = prepare(canvas);
    if (w < 120 || h < 72) return;
    if (state.view === 'energy') energy(state, w, h);
    else concentration(state, w, h);
  }

  function timeAt(x, width) {
    const { left, right } = bounds(width);
    return Math.max(0, Math.min(1, (x - left) / (right - left))) * 120;
  }

  window.RateDraw = { chamber, chart, timeAt };
})();
