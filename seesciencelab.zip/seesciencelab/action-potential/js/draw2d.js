(function () {
  'use strict';
  const gold='#ffc94a',blue='#4fc3f7',purple='#c9a7ff',muted='#8d99ab',green='#7ee081';
  function render(canvas,state){
    const box=canvas.getBoundingClientRect(),w=box.width,h=box.height,dpr=Math.min(devicePixelRatio||1,2);
    if(canvas.width!==Math.round(w*dpr)||canvas.height!==Math.round(h*dpr)){canvas.width=Math.round(w*dpr);canvas.height=Math.round(h*dpr);}
    const c=canvas.getContext('2d');c.setTransform(dpr,0,0,dpr,0,0);c.fillStyle='#05070d';c.fillRect(0,0,w,h);
    const narrow=w<600,pad=narrow?30:65,ww=w-2*pad;
    const scale=Math.max(.3,Math.min(1.1,(h-51)/590)),top=Math.max(22,(h-590*scale)/2),Y=v=>top+v*scale;
    function text(s,x,y,color='#e6ebf2',size=14,align='left'){c.fillStyle=color;c.font=`${size}px -apple-system,BlinkMacSystemFont,'PingFang SC',sans-serif`;c.textAlign=align;c.fillText(s,x,y);}
    function center(s,y,color=muted,size=14){text(s,w/2,Y(y),color,size,'center');}
    function line(x,y,xx,yy,color,width=1,dash=[]){c.strokeStyle=color;c.lineWidth=width;c.setLineDash(dash);c.beginPath();c.moveTo(x,y);c.lineTo(xx,yy);c.stroke();c.setLineDash([]);}
    function arrow(x,y,xx,yy,color){line(x,y,xx,yy,color,2);let a=Math.atan2(yy-y,xx-x);c.fillStyle=color;c.beginPath();c.moveTo(xx,yy);c.lineTo(xx-8*Math.cos(a-.5),yy-8*Math.sin(a-.5));c.lineTo(xx-8*Math.cos(a+.5),yy-8*Math.sin(a+.5));c.fill();}
    const propagation=state.scene==='propagation',s=propagation?Nerve.at(state,state.probe):Nerve.sample(state.t,state.strength);
    center(propagation?'神经冲动 · 相邻膜段依次兴奋':'动作电位 · 先看膜内相对膜外',0,gold,narrow?16:18);
    center(`${s.v>0?'+':''}${s.v.toFixed(0)} mV   ·   ${s.phase}`,31,'#e6ebf2',narrow?16:18);
    function membrane(x,y,width,height,color){
      const fill=c.createLinearGradient(0,y,0,y+height);
      fill.addColorStop(0,color);
      fill.addColorStop(.5,'#0e1827');
      fill.addColorStop(1,color);
      c.fillStyle=fill;
      c.fillRect(x,y,width,height);
    }
    function bilayer(y){
      for(let x=pad+4;x<w-pad-3;x+=8){
        line(x-1,y-4,x-1,y+4,'#34536b');
        line(x+1,y-4,x+1,y+4,'#34536b');
        c.fillStyle='#7aaec7';
        c.beginPath();
        c.arc(x,y-5,2.1,0,Math.PI*2);
        c.arc(x,y+5,2.1,0,Math.PI*2);
        c.fill();
      }
    }
    function channel(x,y,color,open,label){
      c.fillStyle='#0c1523';
      c.fillRect(x-13,y-11,26,22);
      for(const side of [-1,1]){
        const xx=x+side*(open?9:5);
        c.beginPath();
        c.roundRect(xx-4,y-15,8,30,4);
        c.fillStyle=color;
        c.fill();
      }
      text(label,x,y+29,color,12,'center');
    }
    if(propagation){
      center(state.origin===.5?'离体纤维中点刺激：向两侧传导':'左端刺激：向右侧传导',65,muted,13);
      const y1=Y(105),y2=Y(188),width=ww/21;
      for(let i=0;i<21;i++){
        const x=i/20,p=Nerve.at(state,x),xx=pad+i*ww/21,col=p.v>0?gold:p.phase==='后超极化'?purple:blue;
        membrane(xx,y1,width,y2-y1,p.v>0?'#654829':p.phase==='后超极化'?'#39294f':'#203e54');
        line(xx,y1,xx+width,y1,col,3);line(xx,y2,xx+width,y2,col,3);
        text(p.v>0?'−':'+',xx+width/2,y1-10,col,16,'center');text(p.v>0?'+':'−',xx+width/2,(y1+y2)/2+5,col,16,'center');
      }
      const ox=pad+state.origin*ww,px=pad+state.probe*ww;
      text('刺激',ox,y1-22,gold,12,'center');
      arrow(ox,y1-18,ox,y1-2,gold);
      line(px,y1-3,px,y2+5,green,2,[4,4]);text('探针',px,y2+23,green,12,'center');
      // 膜内局部电流从正电位的兴奋区流向前方静息区，膜外回流方向相反。
      if(state.strength>=15&&state.t>=2.2&&state.t<6.2){
        const front=(state.t-2.2)/4;
        [1,-1].forEach(dir=>{
          if(dir===-1&&state.origin===0)return;
          const x=state.origin+dir*front,xx=state.origin+dir*(front+.13);
          if(x>=0&&xx<=1&&xx>=0&&x<=1){arrow(pad+x*ww,Y(160),pad+xx*ww,Y(160),gold);arrow(pad+xx*ww,Y(102),pad+x*ww,Y(102),gold);}
        });
      }
      center(narrow?'金箭头：局部电流（膜内外方向相反）':'金箭头为常规电流方向：膜内由兴奋区流向邻近静息区，膜外回流',242,gold,narrow?11:13);
    }else{
      const y1=Y(110),y2=Y(190),cx=w/2;
      membrane(pad,y1,ww,y2-y1,'#203e54');
      bilayer(y1);bilayer(y2);
      text('膜外',pad,Y(95),muted,12);text('膜内',pad,Y(156),muted,12);
      [.12,.5,.88].forEach(p=>{const x=pad+p*ww;text(s.v>0?'−':'+',x,y1-12,blue,19,'center');text(s.v>0?'+':'−',x,Y(171),gold,19,'center');});
      const naX=cx-ww*.24,kX=cx+ww*.24;
      channel(naX,y1,blue,s.na==='开放','Na⁺');
      channel(kX,y1,purple,s.k!=='关闭','K⁺');
      if(s.na==='开放')arrow(naX,y1-30,naX,y1+15,blue);
      if(s.k!=='关闭')arrow(kX,y1+15,kX,y1-30,purple);
      text(`Na⁺ · ${s.na}`,naX,Y(235),blue,12,'center');
      text(`K⁺ · ${s.k}`,kX,Y(235),purple,12,'center');
    }
    const gx=pad+17,gw=ww-20,gy=Y(305),gh=170*scale;
    c.fillStyle='#0d1420';
    c.beginPath();
    c.roundRect(pad-14,Y(262),ww+28,Y(516)-Y(262),12);
    c.fill();
    text(propagation?'探针记录 / mV':'膜电位曲线 / mV',pad,Y(288),'#e6ebf2',13);
    text('拖动曲线调整时间',w-pad,Y(288),muted,11,'right');
    const tx=t=>gx+t/11*gw,vy=v=>gy+(40-v)/130*gh;
    [-70,-55,0,30].forEach(v=>{line(gx,vy(v),gx+gw,vy(v),'#263246',1,v===-55?[5,4]:[]);text(String(v),gx-6,vy(v)+4,muted,11,'right');});
    text('时间 / 示意 ms',gx+gw,gy+gh+28,muted,11,'right');
    [0,2,4,6,8,10].forEach(t=>text(String(t),tx(t),gy+gh+14,muted,11,'center'));
    text('阈值 −55',gx+gw-3,vy(-55)-6,purple,11,'right');
    function curve(strength,color,dash){c.beginPath();c.strokeStyle=color;c.lineWidth=2;c.setLineDash(dash);for(let i=0;i<=550;i++){const t=i/50,local=propagation?Nerve.localTime(t,state.probe,state.origin):t,v=propagation&&strength<15?-70:Nerve.sample(local,strength).v;i?c.lineTo(tx(t),vy(v)):c.moveTo(tx(t),vy(v));}c.stroke();c.setLineDash([]);}
    if(state.scene==='threshold')curve(25,muted,[5,4]);curve(state.strength,gold,[]);
    const t=Math.min(11,state.t);line(tx(t),gy,tx(t),gy+gh,green,1,[3,3]);c.fillStyle=gold;c.beginPath();c.arc(tx(t),vy(s.v),5,0,Math.PI*2);c.fill();
    center(`${propagation?'探针 · ':''}${s.flow}`,528,gold,narrow?12:15);
    center(state.scene==='threshold'?'灰虚线：强刺激参考；金线：当前刺激':'波形、阈值与传导延迟均为教学设定',555,muted,narrow?12:14);
    if(propagation)center('拖动纤维上的探针，比较波形到达时间',582,muted,12);
    canvas._interaction={
      plot:{left:gx,width:gw,top:Y(295),bottom:Y(507)},
      probe:{left:pad,width:ww,top:Y(90),bottom:Y(225)}
    };
  }
  window.NerveDraw={render};
})();
