// 教学分段波形：不是 Hodgkin–Huxley 电导方程，不用于预测真实神经元。
(function () {
  'use strict';
  const knots=[[0,-70],[1,-70],[1.5,-55],[2.2,30],[3.3,-70],[4,-80],[6,-70],[7,-70]];
  function mix(points,t){
    if(t<=points[0][0])return points[0][1];
    for(let i=1;i<points.length;i++)if(t<=points[i][0]){
      const a=points[i-1],b=points[i],u=(t-a[0])/(b[0]-a[0]);
      return a[1]+(b[1]-a[1])*u;
    }
    return points[points.length-1][1];
  }
  function sample(t,strength=20){
    const fired=strength>=15;
    const v=fired?mix(knots,t):mix([[0,-70],[1,-70],[1.5,-70+strength],[3,-70],[7,-70]],t);
    let phase='静息',na='关闭，可激活',k='关闭',flow='K⁺ 漏通道参与维持静息电位',refractory='可兴奋';
    if(t>=1&&t<1.5){phase='局部去极化';flow='刺激使局部膜去极化';}
    if(fired&&t>=1.5&&t<2.2){phase='快速去极化';na='开放';flow='Na⁺ 顺电化学梯度内流';refractory='绝对不应期（示意）';}
    if(fired&&t>=2.2&&t<3.3){phase='复极化';na='失活';k='开放';flow='K⁺ 外流，膜内电位下降';refractory='绝对不应期（示意）';}
    if(fired&&t>=3.3&&t<6){phase='后超极化';na='恢复可激活';k='逐渐关闭';flow='K⁺ 电导仍偏高，逐渐回到静息';refractory='相对不应期（示意）';}
    if(!fired&&t>=1.5&&t<3){phase='阈下局部电位';flow='未达阈值，局部变化衰减';}
    return {v,fired,phase,na,k,flow,refractory};
  }
  // 归一化位置0..1；刺激点origin；每单位距离延迟4示意毫秒。
  function localTime(t,x,origin){return t-4*Math.abs(x-origin);}
  function at(state,x){return state.strength<15?sample(0,state.strength):sample(localTime(state.t,x,state.origin),state.strength);}
  window.Nerve={knots,mix,sample,localTime,at};
})();
