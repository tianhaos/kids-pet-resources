(function () {
  'use strict';
  const $=id=>document.getElementById(id),q=new URLSearchParams(location.search),scenes=['wave','threshold','propagation'];
  const num=(key,def,min,max)=>{const v=q.has(key)?Number(q.get(key)):def;return Number.isFinite(v)?Math.max(min,Math.min(max,v)):def;};
  const state={scene:scenes.includes(q.get('scene'))?q.get('scene'):'wave',t:num('t',2.2,0,11),strength:num('strength',20,0,30),origin:q.get('origin')==='middle'?.5:0,probe:num('probe',.65,0,1),play:q.get('play')==='1'};
  const explain={wave:'膜电位是膜内相对膜外的电位。观察 Na⁺ 通道开放与失活，再看 K⁺ 外流推动复极化。',threshold:'本例从 −70 mV 达到 −55 mV 为阈值。15 与 25 单位单次刺激产生相同峰值；10 单位只引起局部电位。',propagation:'各膜段依次产生相同动作电位。离体纤维中点受刺激可向两侧传导；正常生理传导路径还取决于刺激来源与突触。'};
  function track(action,label=state.scene){if(window.Analytics)Analytics.track('动作电位与神经冲动传导',action,label);}
  function sample(){return state.scene==='propagation'?Nerve.at(state,state.probe):Nerve.sample(state.t,state.strength);}
  function update(){
    const s=sample();$('progress').value=state.t;$('time').textContent=state.t.toFixed(2)+' ms';$('strength').value=state.strength;$('strengthVal').textContent=state.strength.toFixed(0)+' 单位';$('probe').value=state.probe;$('probeVal').textContent=Math.round(state.probe*100)+'%';$('origin').value=state.origin===.5?'middle':'end';
    $('voltage').textContent=s.v.toFixed(1)+' mV';$('phase').textContent=s.phase;$('na').textContent=s.na;$('k').textContent=s.k;$('refractory').textContent=s.refractory;$('explain').textContent=explain[state.scene];$('play').textContent=state.play?'暂停':'播放';$('propControls').hidden=state.scene!=='propagation';
    document.querySelectorAll('[data-scene]').forEach(b=>{b.classList.toggle('on',b.dataset.scene===state.scene);b.setAttribute('aria-pressed',String(b.dataset.scene===state.scene));});
  }
  function setScene(s){if(!scenes.includes(s))return;state.scene=s;state.t=s==='propagation'?4:2.2;state.play=false;update();}
  function setT(t){state.t=Math.max(0,Math.min(11,Number(t)||0));update();}
  function setStrength(v){state.strength=Math.max(0,Math.min(30,Number(v)||0));update();}
  function advance(dt){state.t=Math.min(11,state.t+dt);if(state.t>=11)state.play=false;}
  $('scenes').onclick=e=>{if(e.target.dataset.scene){setScene(e.target.dataset.scene);track('切换');}};
  $('progress').oninput=e=>{state.play=false;setT(e.target.value);};$('progress').onchange=()=>track('进度');
  $('strength').oninput=e=>setStrength(e.target.value);$('strength').onchange=()=>track('刺激强度',String(state.strength));
  $('probe').oninput=e=>{state.probe=Number(e.target.value);update();};$('probe').onchange=()=>track('移动探针');
  $('origin').onchange=e=>{state.origin=e.target.value==='middle'?.5:0;state.t=0;update();track('刺激位置',e.target.value);};
  $('play').onclick=()=>{if(state.t>=11)state.t=0;state.play=!state.play;update();track('播放暂停');};$('reset').onclick=()=>{state.play=false;setT(0);track('重来');};
  document.querySelectorAll('[data-time]').forEach(b=>b.onclick=()=>{state.play=false;setT(Number(b.dataset.time)+(state.scene==='propagation'?4*Math.abs(state.probe-state.origin):0));track('关键时刻',b.textContent);});
  const canvas=$('nerve');
  let gesture=null;
  function locate(e){
    const bounds=canvas.getBoundingClientRect();
    return {x:e.clientX-bounds.left,y:e.clientY-bounds.top};
  }
  function targetAt(y){
    const hit=canvas._interaction;
    if(!hit)return null;
    if(y>=hit.plot.top&&y<=hit.plot.bottom)return 'time';
    if(state.scene==='propagation'&&y>=hit.probe.top&&y<=hit.probe.bottom)return 'probe';
    return null;
  }
  function dragTo(x){
    const {plot,probe}=canvas._interaction;
    if(gesture.kind==='time')setT((x-plot.left)/plot.width*11);
    else {
      state.probe=Math.max(0,Math.min(1,(x-probe.left)/probe.width));
      update();
    }
  }
  canvas.onpointerdown=e=>{
    if(gesture||e.button!==0)return;
    const {x,y}=locate(e),kind=targetAt(y);
    if(!kind)return;
    gesture={kind,id:e.pointerId};
    state.play=false;
    canvas.setPointerCapture(e.pointerId);
    dragTo(x);
  };
  canvas.onpointermove=e=>{
    const {x,y}=locate(e);
    canvas.style.cursor=gesture||targetAt(y)?'ew-resize':'default';
    if(gesture?.id===e.pointerId)dragTo(x);
  };
  function finishDrag(e){
    if(gesture?.id!==e.pointerId)return;
    track(gesture.kind==='time'?'拖动曲线':'移动探针');
    gesture=null;
  }
  canvas.onpointerup=canvas.onpointercancel=canvas.onlostpointercapture=finishDrag;
  const mobile=matchMedia('(max-width:760px)');
  function showControls(open){
    $('panel').classList.toggle('collapsed',!open);
    $('controlToggle').setAttribute('aria-expanded',String(open));
    $('controlToggle').textContent=open?'收起设置':'实验设置';
  }
  $('controlToggle').onclick=()=>showControls($('panel').classList.contains('collapsed'));
  mobile.addEventListener('change',()=>showControls(!mobile.matches));
  showControls(!mobile.matches);
  $('share').onclick=async()=>{const u=new URL(location.href);u.search=new URLSearchParams({scene:state.scene,t:state.t.toFixed(2),strength:state.strength,origin:state.origin===.5?'middle':'end',probe:state.probe.toFixed(3),play:'0'});try{await navigator.clipboard.writeText(u.href);$('shareStatus').textContent='已复制当前状态链接';}catch(e){$('shareStatus').textContent=u.href;}track('分享');};
  let last=performance.now();function frame(now){const dt=Math.min(.1,(now-last)/1000);last=now;if(state.play)advance(dt*.7);if(state.play||$('play').textContent==='暂停')update();NerveDraw.render($('nerve'),state);requestAnimationFrame(frame);}
  window.__model={state,setScene,setT,setStrength,advance,update,sample};update();requestAnimationFrame(frame);
})();
