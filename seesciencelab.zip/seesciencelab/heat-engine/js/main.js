(function () {
  var E = window.Engine;
  var $ = function (id) { return document.getElementById(id); };
  var qa = function (sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); };
  var NAME = '热机';

  var SCENES = {
    cycle: { name: '四个冲程', hint: '看活塞、气门怎样配合 · 点“下一冲程”逐个观察，或拖动曲轴转角',
      note: '单缸四冲程内燃机：吸气、压缩、做功、排气四个冲程组成一个工作循环，活塞往复两次，曲轴（飞轮）转两圈，对外做功一次。' },
    quiz: { name: '判断冲程', hint: '看气门的开闭和活塞的运动方向 · 判断是哪个冲程',
      note: '判断冲程的方法：先看气门——进气门开是吸气冲程，排气门开是排气冲程；两个气门都关闭时看活塞——向上运动是压缩冲程，向下运动是做功冲程。' },
    efficiency: { name: '热机效率', hint: '燃料放出的能量只有一小部分变成有用功 · 勾选改进措施看效率怎样变化',
      note: '热机效率 η = W有 / Q放：用来做有用功的那部分能量，与燃料完全燃烧放出的能量之比。废气带走的能量最多。' }
  };
  var DESC = {
    gasoline: [
      '进气门打开，排气门关闭，活塞由上向下运动，汽油和空气组成的燃料混合物从进气门吸入汽缸。',
      '进气门和排气门都关闭，活塞向上运动，燃料混合物被压缩，压强增大，温度升高。',
      '压缩冲程末，火花塞产生电火花，使燃料猛烈燃烧，产生高温高压的燃气，推动活塞向下运动，并通过连杆带动曲轴转动。',
      '进气门关闭，排气门打开，活塞向上运动，把废气排出汽缸。'],
    diesel: [
      '进气门打开，排气门关闭，活塞向下运动，吸入汽缸的只有空气。',
      '两个气门都关闭，活塞向上运动压缩空气。柴油机的压缩程度比汽油机更大，压缩冲程末空气的温度已经超过柴油的燃点。',
      '压缩冲程末，喷油嘴向汽缸内喷出雾状柴油，柴油遇到热空气立即燃烧，产生高温高压的燃气，推动活塞向下运动做功。',
      '进气门关闭，排气门打开，活塞向上运动，把废气排出汽缸。']
  };
  var QTYPES = { stroke: '看图判断冲程', energy: '能量转化', rpm: '转速与做功次数', diff: '汽油机与柴油机' };

  var state = {
    scene: 'cycle', engine: 'gasoline', theta: 90, playing: true, speed: 0.25, target: null,
    rpm: 1800, labels: true, particles: true, energy: true,
    m: 1, burn: false, lube: false, recover: false,
    quiz: null, qtype: '', answered: false, picked: null, score: [0, 0]
  };
  var info = { theta: 90, dt: 0 };

  var stage = $('stage'), canvas = $('eng'), panel = $('panel');
  var view = window.EngineDraw(canvas);

  function setSeg(attr, val) { qa('[data-' + attr + ']').forEach(function (b) { b.classList.toggle('on', b.dataset[attr] === String(val)); }); }
  function fmt(v, d) { return (+v.toFixed(d == null ? 2 : d)).toString(); }
  function esc(s) { return String(s).replace(/[&<>]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]; }); }
  function vtxt(v) { return v ? '打开' : '关闭'; }

  function compute() {
    var st = state;
    info.theta = E.wrap(st.theta);
    if (st.scene === 'efficiency') {
      info.flow = E.flow(st.engine, { burn: st.burn, lube: st.lube, recover: st.recover });
      info.Q = E.heat(st.engine, st.m);
    }
  }

  // ---------- 读数、提示 ----------
  function syncPanel() {
    var st = state, sc = SCENES[st.scene], big = '', dl = [], notes = [];
    compute();
    setSeg('scene', st.scene); setSeg('engine', st.engine); setSeg('qtype', st.qtype);
    qa('[data-for]').forEach(function (el) { el.hidden = el.dataset.for.split(' ').indexOf(st.scene) < 0; });
    if (st.scene === 'cycle') {
      var th = info.theta, si = E.strokeIndex(th), S = E.STROKES[si], e = E.ENGINES[st.engine];
      big = '<span class="st" style="color:' + S.color + '">' + S.name + '</span><small>第 ' + (si + 1) + ' 冲程</small>';
      dl = [['进气门', vtxt(S.iv)], ['排气门', vtxt(S.ev)], ['活塞', '向' + (S.dir === 'up' ? '上' : '下') + '运动'],
        ['能量转化', S.energy || '无（靠飞轮的惯性完成）'], ['曲轴转角', Math.round(th) + '°（第 ' + (Math.floor(th / 360) + 1) + ' 圈）'],
        ['已完成工作循环', Math.max(0, Math.floor(st.theta / 720)) + ' 个']];
      notes.push(DESC[st.engine][si]);
      if (si !== 2) notes.push('这个冲程不对外做功，靠飞轮的惯性完成；四个冲程中只有做功冲程对外做功。');
      else notes.push('做功冲程是唯一对外做功的冲程：燃料的化学能先转化为燃气的内能，燃气推动活塞，内能再转化为机械能。');
      if (si === 1 || si === 2) notes.push(e.name + '是' + e.ignite + '：' + (st.engine === 'gasoline' ? '汽缸顶部有火花塞，靠电火花点燃燃料。' : '汽缸顶部有喷油嘴，靠压缩后的高温空气点燃柴油。'));
    } else if (st.scene === 'quiz') {
      big = '<span>答对 <b>' + st.score[0] + '</b> / ' + st.score[1] + '</span>';
      dl = [['题型', st.qtype ? QTYPES[st.qtype] : '随机']];
      if (st.quiz && st.quiz.theta != null) dl.push(['图中机型', E.ENGINES[st.quiz.engine].name]);
    } else {
      var f = info.flow, en = E.ENGINES[st.engine];
      big = '<span class="eta">η = <b>' + fmt(f.useful * 100, 1) + '</b>%</span>';
      dl = [['燃料', en.fuel + '，q = ' + view.sci(en.q) + ' J/kg'], ['燃料质量 m', fmt(st.m) + ' kg'],
        ['Q放 = mq', view.sci(info.Q) + ' J'], ['W有 = ηQ放', view.sci(info.Q * f.useful) + ' J']];
      E.LOSS.forEach(function (l) { dl.push([l.name, fmt(f[l.id] * 100, 1) + '%']); });
      notes.push('η = W有 / Q放 = ' + view.sci(info.Q * f.useful) + ' J ÷ ' + view.sci(info.Q) + ' J = ' + fmt(f.useful * 100, 1) + '%。' + en.name + '的效率一般为 ' + en.eta[0] * 100 + '%～' + en.eta[1] * 100 + '%。');
      notes.push('各种损失中废气带走的能量最多，其次是汽缸散热（冷却水带走）。');
      if (!(st.burn && st.lube && st.recover)) notes.push('提高热机效率的途径：使燃料充分燃烧、尽量减少各种热量损失、机件间保持良好的润滑以减小摩擦。');
      else notes.push('措施都用上了，效率提高了，但仍远小于 100%：热机工作时总有能量损失，效率不可能达到 100%。');
    }
    $('rBig').innerHTML = big;
    $('rDl').innerHTML = dl.map(function (d) { return '<dt>' + d[0] + '</dt><dd>' + d[1] + '</dd>'; }).join('');
    $('rNotes').innerHTML = notes.map(function (t) { return '<li>' + esc(t) + '</li>'; }).join('');
    $('rNotes').hidden = !notes.length;
    $('sceneNote').textContent = sc.note;
    $('hint').textContent = sc.hint;
    $('playBtn').textContent = st.playing && st.target == null ? '⏸ 暂停' : '▶ 播放';
    $('thRange').value = Math.round(info.theta); $('thOut').textContent = Math.round(info.theta) + '°';
    $('spRange').value = Math.round(st.speed * 100); $('spOut').textContent = fmt(st.speed) + ' 圈/秒';
    $('rpmRange').value = st.rpm; $('rpmOut').textContent = st.rpm + ' r/min';
    var ps = E.perSecond(st.rpm);
    $('rpmCalc').innerHTML = '<dt>飞轮每秒转</dt><dd>' + fmt(ps.rev) + ' 圈</dd><dt>每秒完成</dt><dd>' + fmt(ps.strokes) + ' 个冲程、' + fmt(ps.cycles) + ' 个工作循环</dd><dt>每秒对外做功</dt><dd><b>' + fmt(ps.works) + '</b> 次</dd>';
    $('mRange').value = Math.round(st.m * 10); $('mOut').textContent = fmt(st.m) + ' kg';
    $('showLabels').checked = st.labels; $('showParticles').checked = st.particles; $('showEnergy').checked = st.energy;
    $('optBurn').checked = st.burn; $('optLube').checked = st.lube; $('optRecover').checked = st.recover;
  }

  // ---------- 运行控制 ----------
  function setTheta(th) { state.theta = th; state.target = null; syncPanel(); }
  function nextStroke() {
    var cur = state.theta, base = Math.floor(cur / 180) * 180, mid = base + 90;
    state.target = cur < mid - 1 ? mid : mid + 180;   // 停在下一个冲程的中间（当前冲程还没过半就停在本冲程中间）
    state.playing = true;
    syncPanel();
  }

  // ---------- 练习 ----------
  function newQuiz() {
    state.quiz = E.quiz(state.qtype || null);
    state.answered = false; state.picked = null;
    if (state.quiz.theta == null) state.engine = state.quiz.engine;
    renderQuiz(); syncPanel();
  }
  function renderQuiz() {
    var q = state.quiz;
    if (!q) return;
    $('quizQ').textContent = q.q;
    $('quizOpts').className = 'answer' + (q.opts.some(function (o) { return o.length > 9; }) ? ' one' : '');
    $('quizOpts').innerHTML = q.opts.map(function (o, i) {
      var cls = !state.answered ? '' : o === q.ans ? ' class="on"' : o === state.picked ? ' class="no"' : '';
      return '<button data-i="' + i + '"' + cls + (state.answered ? ' disabled' : '') + '>' + esc(o) + '</button>';
    }).join('');
    $('quizMsg').innerHTML = !state.answered ? '' : (state.picked === q.ans ? '<b style="color:#7ee081">✓ 正确</b>' : '<b style="color:#ff7a59">✗ 正确答案：' + esc(q.ans) + '</b>') + esc(q.explain);
    qa('#quizOpts button').forEach(function (b) {
      b.addEventListener('click', function () {
        if (state.answered) return;
        state.picked = q.opts[+b.dataset.i]; state.answered = true;
        state.score[1]++; if (state.picked === q.ans) state.score[0]++;
        Analytics.track(NAME, '答题', QTYPES[q.type] + (state.picked === q.ans ? '·对' : '·错'));
        renderQuiz(); syncPanel();
      });
    });
  }

  // ---------- 场景 ----------
  function loadScene(name) {
    state.scene = SCENES[name] ? name : 'cycle';
    if (state.scene === 'quiz' && !state.quiz) newQuiz();
    syncPanel();
  }

  // ---------- 面板控件 ----------
  qa('[data-scene]').forEach(function (b) { b.addEventListener('click', function () { loadScene(b.dataset.scene); Analytics.track(NAME, '场景', SCENES[state.scene].name); }); });
  qa('[data-engine]').forEach(function (b) { b.addEventListener('click', function () { state.engine = b.dataset.engine; syncPanel(); Analytics.track(NAME, '机型', b.textContent); }); });
  qa('[data-qtype]').forEach(function (b) { b.addEventListener('click', function () { state.qtype = b.dataset.qtype; newQuiz(); Analytics.track(NAME, '题型', b.textContent); }); });
  $('playBtn').addEventListener('click', function () {
    if (state.target != null) { state.target = null; state.playing = false; }
    else state.playing = !state.playing;
    syncPanel(); Analytics.track(NAME, state.playing ? '播放' : '暂停');
  });
  $('stepBtn').addEventListener('click', function () { nextStroke(); Analytics.track(NAME, '下一冲程', E.ENGINES[state.engine].name); });
  $('thRange').addEventListener('input', function () {
    state.playing = false;
    var cyc = Math.floor(state.theta / 720) * 720;
    setTheta(cyc + +$('thRange').value);
  });
  $('spRange').addEventListener('input', function () { state.speed = $('spRange').value / 100; syncPanel(); });
  $('rpmRange').addEventListener('input', function () { state.rpm = +$('rpmRange').value; syncPanel(); });
  $('rpmRange').addEventListener('change', function () { Analytics.track(NAME, '转速', String(state.rpm)); });
  $('mRange').addEventListener('input', function () { state.m = $('mRange').value / 10; syncPanel(); });
  $('showLabels').addEventListener('change', function () { state.labels = $('showLabels').checked; });
  $('showParticles').addEventListener('change', function () { state.particles = $('showParticles').checked; });
  $('showEnergy').addEventListener('change', function () { state.energy = $('showEnergy').checked; });
  [['optBurn', 'burn', '充分燃烧'], ['optLube', 'lube', '良好润滑'], ['optRecover', 'recover', '利用废气']].forEach(function (o) {
    $(o[0]).addEventListener('change', function () { state[o[1]] = $(o[0]).checked; syncPanel(); Analytics.track(NAME, '提高效率', o[2] + (state[o[1]] ? '·开' : '·关')); });
  });
  $('nextQ').addEventListener('click', function () { newQuiz(); Analytics.track(NAME, '换一题'); });

  // ---------- 面板开合 ----------
  $('panelToggle').addEventListener('click', function () { panel.classList.toggle('collapsed'); });
  if (window.matchMedia('(max-width: 760px)').matches) panel.classList.add('collapsed');

  function resize() { view.resize(stage.clientWidth, stage.clientHeight); }
  new ResizeObserver(resize).observe(stage);
  resize();

  // 支持 ?scene=cycle|quiz|efficiency、&engine=gasoline|diesel；
  // 四个冲程 &stroke=1~4（停在该冲程中间）、&angle=0~720（曲轴转角，停住）、&play=0、&speed=圈/秒、&rpm=、&labels=0、&particles=0；
  // 练习 &q=stroke|energy|rpm|diff；效率 &m=燃料质量（kg）、&burn=1、&lube=1、&recover=1
  var qs = new URLSearchParams(location.search);
  if (E.ENGINES[qs.get('engine')]) state.engine = qs.get('engine');
  var sk = +qs.get('stroke'), ag = qs.get('angle');
  if (sk >= 1 && sk <= 4) { state.theta = (sk - 1) * 180 + 90; state.playing = false; }
  if (ag != null && ag !== '' && isFinite(+ag)) { state.theta = E.clamp(+ag, 0, 719.9); state.playing = false; }
  if (qs.get('play') === '0') state.playing = false;
  if (qs.get('speed') && isFinite(+qs.get('speed'))) state.speed = E.clamp(+qs.get('speed'), 0.05, 1);
  if (qs.get('rpm') && isFinite(+qs.get('rpm'))) state.rpm = E.clamp(Math.round(+qs.get('rpm') / 60) * 60, 600, 6000);
  if (qs.get('labels') === '0') state.labels = false;
  if (qs.get('particles') === '0') state.particles = false;
  if (QTYPES[qs.get('q')]) state.qtype = qs.get('q');
  if (qs.get('m') && isFinite(+qs.get('m'))) state.m = E.clamp(Math.round(+qs.get('m') * 10) / 10, 0.1, 5);
  ['burn', 'lube', 'recover'].forEach(function (k) { if (qs.get(k) === '1') state[k] = true; });
  loadScene(qs.get('scene'));

  var lastT = performance.now(), syncT = 0;
  function frame(t) {
    var dt = Math.min((t - lastT) / 1000, 0.05);
    lastT = t;
    info.dt = dt;
    if (state.scene !== 'efficiency' && state.playing) {
      var before = Math.floor(state.theta / 180);
      state.theta += dt * state.speed * 360 * (state.target != null ? 1.6 : 1);
      if (state.target != null && state.theta >= state.target) { state.theta = state.target; state.target = null; state.playing = false; }
      syncT += dt;
      if (Math.floor(state.theta / 180) !== before || !state.playing || syncT > 0.2) { syncT = 0; syncPanel(); }
    }
    info.theta = E.wrap(state.theta);
    if (state.scene === 'quiz') info.quizH = $('quizBar').offsetHeight;
    view.draw(state, info);
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // 调试用
  window.__model = { state: state, info: function () { return info; }, view: view, Engine: E, load: loadScene, sync: syncPanel, setTheta: setTheta, nextStroke: nextStroke, newQuiz: newQuiz };
})();
