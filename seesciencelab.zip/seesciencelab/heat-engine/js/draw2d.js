// 热机绘图：单缸四冲程内燃机剖面（汽缸、进排气门、火花塞/喷油嘴、活塞、连杆、曲轴、飞轮、缸内气体分子）、
// 工作循环表盘与温度/压强条、能量流向图（热机效率）
// 世界坐标用 mm（y 向上，曲轴中心为原点），fit() 缩放进画面；表盘画在画面右侧（窄而高时画在下方）
(function () {
  var E = window.Engine, G = E.GEO, TAU = Math.PI * 2;
  var C = { text: '#e6ebf2', muted: '#8d99ab', line: '#2a3446', accent: '#ffc94a', metal: '#7d8899', metalHi: '#a9b4c4',
    dark: '#0d131e', wall: '#3a4558', head: '#4a5568', piston: '#9aa6b8', rod: '#b8c2d1', crank: '#c6ced9',
    useful: '#7ee081', fuel: '#ff9f43', fresh: '#4fc3f7', air: '#a9d8f5', burnt: '#8d8478' };
  var PART = ['吸气', '压缩', '做功', '排气'];

  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
  function hex2rgb(h) { var n = parseInt(h.slice(1), 16); return [n >> 16 & 255, n >> 8 & 255, n & 255]; }
  function rgba(h, a) { var c = hex2rgb(h); return 'rgba(' + c[0] + ',' + c[1] + ',' + c[2] + ',' + a + ')'; }
  function mix(a, b, t) { var x = hex2rgb(a), y = hex2rgb(b); t = clamp(t, 0, 1);
    return '#' + [0, 1, 2].map(function (i) { return ('0' + Math.round(x[i] + (y[i] - x[i]) * t).toString(16)).slice(-2); }).join(''); }
  function lerp(a, b, t) { return a + (b - a) * t; }
  // 气体颜色：新鲜充量（汽油机为混合物、柴油机为空气）随温度变暖；燃烧时橙红；废气灰褐
  function gasColor(eng, g) {
    if (g.fresh) return mix(eng === 'gasoline' ? '#5fd0b0' : C.air, '#ffb347', (g.T - 320) / 700);
    var hot = clamp((g.T - 700) / 1600, 0, 1);
    return mix(C.burnt, mix('#ff7a3d', '#ffd36a', g.burn), Math.max(hot, g.burn));
  }

  function EngineDraw(canvas) {
    var ctx = canvas.getContext('2d'), W = 0, H = 0, dpr = 1, L = {}, M = null;
    var parts = [];   // 缸内气体分子：(u, v) 为在气体区域内的相对位置
    for (var i = 0; i < 46; i++) parts.push({ u: Math.random(), v: Math.random(), a: Math.random() * TAU });

    function resize(w, h) {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      W = w; H = h;
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
      canvas.style.width = w + 'px'; canvas.style.height = h + 'px';
      L.narrow = W <= 760; L.top = L.narrow ? 84 : 46; L.bottom = L.narrow ? 46 : 58;
    }
    function fit(box, area) {
      var s = Math.min(area[2] / (box[2] - box[0]), area[3] / (box[3] - box[1]));
      M = { s: s, ox: area[0] + (area[2] - s * (box[2] - box[0])) / 2 - box[0] * s, oy: area[1] + (area[3] + s * (box[3] - box[1])) / 2 + box[1] * s };
    }
    function P(x, y) { return [M.ox + x * M.s, M.oy - y * M.s]; }
    // 有信息区的场景：宽屏信息区在右，窄屏在下
    // badge 为 true 时在图下方留出一行说明条（L.badgeY）
    function splitLayout(box, badge) {
      var top = L.top, bot = H - L.bottom, avail = bot - top, area, bh = badge ? 30 : 0;
      if (W >= 640 || W > avail * 0.9) {
        var gw = clamp(W * 0.3, 210, 300);
        area = [12, top, W - gw - 36, avail - bh];
        L.info = { x: W - gw - 16, y: top + 4, w: gw, h: avail - 8, side: true };
      } else {
        var gh = clamp(avail * 0.3, 150, 210);
        area = [12, top, W - 24, avail - gh - 10 - bh];
        L.info = { x: 12, y: bot - gh, w: W - 24, h: gh, side: false };
      }
      L.badgeY = area[1] + area[3] + bh / 2;
      fit(box, area);
    }

    function font(px, w) { ctx.font = (w || '') + ' ' + Math.round(px) + 'px -apple-system, "PingFang SC", "Microsoft YaHei", sans-serif'; }
    function text(s, x, y, col, align, px, w) { font(px, w); ctx.fillStyle = col; ctx.textAlign = align || 'center'; ctx.textBaseline = 'middle'; ctx.fillText(s, x, y); }
    function tag(s, x, y, col, px, align) {
      font(px || 13, '600'); var w = ctx.measureText(s).width + 10, h = (px || 13) + 8;
      var x0 = align === 'left' ? x : align === 'right' ? x - w : x - w / 2;
      ctx.fillStyle = 'rgba(11,15,24,0.85)'; rrect(x0, y - h / 2, w, h, 5); ctx.fill();
      text(s, x0 + w / 2, y, col, 'center', px || 13, '600');
      return w;
    }
    function line(x1, y1, x2, y2) { ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke(); }
    function rrect(x, y, w, h, r) {
      ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r);
      ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
    }
    function wrect(x0, y0, x1, y1) { var a = P(x0, y1), b = P(x1, y0); ctx.beginPath(); ctx.rect(a[0], a[1], b[0] - a[0], b[1] - a[1]); }
    function wpoly(pts) { ctx.beginPath(); pts.forEach(function (p, i) { var q = P(p[0], p[1]); if (i) ctx.lineTo(q[0], q[1]); else ctx.moveTo(q[0], q[1]); }); ctx.closePath(); }
    function arrow(x1, y1, x2, y2, col, w, head) {
      var a = Math.atan2(y2 - y1, x2 - x1), h = head || 10, l = Math.hypot(x2 - x1, y2 - y1);
      if (l < 2) return;
      if (h > l * 0.7) h = l * 0.7;
      ctx.strokeStyle = col; ctx.fillStyle = col; ctx.lineWidth = w || 3; ctx.lineCap = 'round';
      if (l > h) line(x1, y1, x2 - Math.cos(a) * h * 0.7, y2 - Math.sin(a) * h * 0.7);
      ctx.beginPath(); ctx.moveTo(x2, y2);
      ctx.lineTo(x2 - Math.cos(a - 0.42) * h, y2 - Math.sin(a - 0.42) * h);
      ctx.lineTo(x2 - Math.cos(a + 0.42) * h, y2 - Math.sin(a + 0.42) * h); ctx.closePath(); ctx.fill();
    }
    function dot(x, y, r, col) { ctx.fillStyle = col; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill(); }

    // ---------- 内燃机剖面 ----------
    // 关键高度：燃烧室顶 roof、汽缸盖顶 headTop
    function geom(eng) {
      var tdcTop = G.r + G.l + G.pinTop, roof = tdcTop + E.ENGINES[eng].clear;
      return { roof: roof, headTop: roof + 34, bore: G.bore / 2, wall: G.bore / 2 + 10, cylBot: 46 };
    }
    // 进气道（左）、排气道（右）：side = -1 / 1
    function portPoly(gm, side) {
      var R = gm.roof, s = side;
      return [[s * 34, R], [s * 10, R], [s * 14, R + 24], [s * 98, R + 24], [s * 98, R + 6], [s * 44, R + 6]];
    }
    function valve(gm, side, lift, col) {
      var R = gm.roof, d = lift * 9, s = side, x = s * 22;
      // 气门弹簧与气门杆
      var top = gm.headTop + 14 - d;
      ctx.strokeStyle = '#7f8a9b'; ctx.lineWidth = Math.max(1, 1.1 * M.s);
      ctx.beginPath();
      for (var k = 0; k <= 8; k++) { var yy = lerp(gm.headTop, top - 2, k / 8), xx = x + (k % 2 ? 7 : -7), q = P(xx, yy); if (k) ctx.lineTo(q[0], q[1]); else ctx.moveTo(q[0], q[1]); }
      ctx.stroke();
      ctx.fillStyle = col;
      wrect(x - 2.2, R - d + 4, x + 2.2, top); ctx.fill();
      wrect(x - 9, top - 2, x + 9, top + 1.5); ctx.fill();
      // 气门头（盘形）：关闭时贴在气门座上
      wpoly([[x - 12, R - d], [x + 12, R - d], [x + 12, R - d + 2], [x + 3, R - d + 7], [x - 3, R - d + 7], [x - 12, R - d + 2]]); ctx.fill();
    }
    function sparkPlug(gm, on, t) {
      var R = gm.roof, b = P(-5, gm.headTop + 40), c = P(5, R);
      ctx.fillStyle = '#e8e2d4'; ctx.fillRect(b[0], b[1], c[0] - b[0], c[1] - b[1]);
      wrect(-8, gm.headTop - 6, 8, gm.headTop + 8); ctx.fillStyle = '#8e98a8'; ctx.fill();
      wrect(-2, gm.headTop + 40, 2, gm.headTop + 48); ctx.fillStyle = '#c6ced9'; ctx.fill();
      wrect(-1.2, R - 4, 1.2, R); ctx.fillStyle = '#c6ced9'; ctx.fill();
      if (on) {
        var p = P(0, R - 6);
        ctx.fillStyle = 'rgba(255,240,170,0.9)'; ctx.beginPath(); ctx.arc(p[0], p[1], 4 * M.s, 0, TAU); ctx.fill();
        ctx.strokeStyle = '#fffbe0'; ctx.lineWidth = 2;
        for (var k = 0; k < 6; k++) { var a = k / 6 * TAU + t * 7; line(p[0], p[1], p[0] + Math.cos(a) * 8 * M.s, p[1] + Math.sin(a) * 8 * M.s); }
      }
    }
    function injector(gm, spray, t, topY) {
      var R = gm.roof, b = P(-5, gm.headTop + 40), c = P(5, R + 2);
      ctx.fillStyle = '#8fa0b6'; ctx.fillRect(b[0], b[1], c[0] - b[0], c[1] - b[1]);
      wpoly([[-3, R + 2], [3, R + 2], [1.4, R - 2], [-1.4, R - 2]]); ctx.fillStyle = '#c6ced9'; ctx.fill();
      wrect(-2, gm.headTop + 40, 2, gm.headTop + 52); ctx.fillStyle = '#d9a35f'; ctx.fill();
      if (spray) {
        // 雾状柴油：从喷嘴喷出的锥形油雾
        var len = Math.min(24, (R - 2 - topY) * 0.9);
        for (var k = 0; k < 40; k++) {
          var a = (Math.random() - 0.5) * 1.2, r = Math.random() * len, q = P(Math.sin(a) * r, R - 2 - Math.cos(a) * r);
          dot(q[0], q[1], Math.max(1, 0.7 * M.s), 'rgba(255,214,120,0.85)');
        }
      }
    }

    function drawEngine(st, eng, th, opt) {
      var gm = geom(eng), g = E.gas(eng, th), vl = E.valves(th), pinY = E.pinY(th), top = pinY + G.pinTop, cp = E.crankPin(th);
      var gcol = gasColor(eng, g), si = E.strokeIndex(th), t = performance.now() / 1000, s = M.s;
      opt = opt || {};
      // 飞轮（在曲轴后面）
      var o = P(0, 0), FR = 60;
      ctx.fillStyle = 'rgba(70,82,104,0.35)'; ctx.beginPath(); ctx.arc(o[0], o[1], FR * s, 0, TAU); ctx.fill();
      ctx.strokeStyle = '#5b6880'; ctx.lineWidth = 7 * s; ctx.beginPath(); ctx.arc(o[0], o[1], (FR - 3.5) * s, 0, TAU); ctx.stroke();
      ctx.lineWidth = 3 * s; ctx.strokeStyle = 'rgba(120,134,158,0.7)';
      for (var k = 0; k < 6; k++) { var a = (th * Math.PI / 180) + k * TAU / 6; line(o[0], o[1], o[0] + Math.sin(a) * (FR - 6) * s, o[1] - Math.cos(a) * (FR - 6) * s); }
      // 飞轮上的标记点：看它转了几圈
      var am = th * Math.PI / 180, mk = [o[0] + Math.sin(am) * (FR - 3.5) * s, o[1] - Math.cos(am) * (FR - 3.5) * s];
      dot(mk[0], mk[1], 4 * s, C.accent);
      // 曲轴箱（剖开）
      ctx.strokeStyle = 'rgba(140,155,180,0.35)'; ctx.lineWidth = 1.5; ctx.setLineDash([5, 4]);
      wpoly([[-gm.wall, gm.cylBot], [-gm.wall - 12, 20], [-gm.wall - 12, -50], [-30, -62], [30, -62], [gm.wall + 12, -50], [gm.wall + 12, 20], [gm.wall, gm.cylBot]]);
      ctx.stroke(); ctx.setLineDash([]);

      // 进排气道（先画，汽缸盖盖在上面再挖空）
      var head = [[-62, gm.roof], [62, gm.roof], [62, gm.headTop], [-62, gm.headTop]];
      wpoly(head); ctx.fillStyle = C.head; ctx.fill();
      // 气道里的气体
      [-1, 1].forEach(function (sd) {
        var open = sd < 0 ? vl.intake : vl.exhaust;
        wpoly(portPoly(gm, sd));
        ctx.fillStyle = C.dark; ctx.fill();
        if (sd < 0) { ctx.fillStyle = rgba(eng === 'gasoline' ? '#5fd0b0' : C.air, 0.35); ctx.fill(); }
        else if (open > 0 || (si === 3)) { ctx.fillStyle = rgba(C.burnt, 0.5); ctx.fill(); }
        ctx.strokeStyle = '#6b778a'; ctx.lineWidth = 1.2; ctx.stroke();
      });
      // 汽缸壁
      wrect(-gm.wall, gm.cylBot, -gm.bore, gm.roof); ctx.fillStyle = C.wall; ctx.fill();
      wrect(gm.bore, gm.cylBot, gm.wall, gm.roof); ctx.fill();
      // 冷却水套（示意）
      ctx.fillStyle = 'rgba(79,195,247,0.18)';
      wrect(-gm.wall + 2, gm.cylBot + 50, -gm.bore - 3, gm.roof - 4); ctx.fill();
      wrect(gm.bore + 3, gm.cylBot + 50, gm.wall - 2, gm.roof - 4); ctx.fill();
      // 缸内气体
      wrect(-gm.bore, top, gm.bore, gm.roof);
      ctx.fillStyle = rgba(gcol, 0.28 + 0.4 * g.burn + 0.08 * clamp((g.p - 1) / 30, 0, 1)); ctx.fill();
      if (g.burn > 0) {
        var c0 = P(0, gm.roof - 4), rg = ctx.createRadialGradient(c0[0], c0[1], 0, c0[0], c0[1], (gm.roof - top + 30) * s);
        rg.addColorStop(0, 'rgba(255,240,180,' + 0.75 * g.burn + ')'); rg.addColorStop(1, 'rgba(255,120,40,0)');
        ctx.fillStyle = rg; wrect(-gm.bore, top, gm.bore, gm.roof); ctx.fill();
      }
      // 气体分子：速率随温度增大，区域变小时自然变密
      if (opt.particles !== false) {
        var vs = Math.sqrt(g.T / 320) * 0.25, h = Math.max(1, gm.roof - top), dt = opt.dt || 0;
        parts.forEach(function (pt) {
          pt.a += (Math.random() - 0.5) * 0.6;
          pt.u += Math.cos(pt.a) * vs * dt * 1.2; pt.v += Math.sin(pt.a) * vs * dt * 1.2 * (80 / Math.max(h, 12));
          if (pt.u < 0) { pt.u = -pt.u; pt.a = Math.PI - pt.a; } if (pt.u > 1) { pt.u = 2 - pt.u; pt.a = Math.PI - pt.a; }
          if (pt.v < 0) { pt.v = -pt.v; pt.a = -pt.a; } if (pt.v > 1) { pt.v = 2 - pt.v; pt.a = -pt.a; }
          var q = P(-gm.bore + 3 + pt.u * (2 * gm.bore - 6), top + 2 + pt.v * (h - 4));
          dot(q[0], q[1], Math.max(1.4, 1.6 * s), g.fresh ? (eng === 'gasoline' ? '#8ff0d0' : '#cfeaff') : (g.burn > 0.2 ? '#ffe7a0' : '#c9beb0'));
        });
      }
      // 汽缸盖、气门
      ctx.strokeStyle = '#6b778a'; ctx.lineWidth = 1.2; wpoly(head); ctx.stroke();
      valve(gm, -1, vl.intake, vl.intake > 0 ? '#9fe0ff' : '#c6ced9');
      valve(gm, 1, vl.exhaust, vl.exhaust > 0 ? '#ffc4a8' : '#c6ced9');
      if (eng === 'gasoline') sparkPlug(gm, g.spark, t); else injector(gm, g.spray, t, top);
      // 进气、排气气流箭头
      if (vl.intake > 0.15 && opt.flow !== false) flowArrows(gm, -1, vl.intake, t, eng === 'gasoline' ? '#5fd0b0' : C.air);
      if (vl.exhaust > 0.15 && opt.flow !== false) flowArrows(gm, 1, vl.exhaust, t, '#c9beb0');

      // 活塞、活塞环、活塞销
      var pa = P(-gm.bore + 0.8, top), pb = P(gm.bore - 0.8, top - G.pistonH);
      var grd = ctx.createLinearGradient(pa[0], 0, pb[0], 0);
      grd.addColorStop(0, '#7d8899'); grd.addColorStop(0.45, '#c3ccd8'); grd.addColorStop(1, '#7d8899');
      ctx.fillStyle = grd; ctx.fillRect(pa[0], pa[1], pb[0] - pa[0], pb[1] - pa[1]);
      ctx.strokeStyle = '#4b5566'; ctx.lineWidth = Math.max(1, 0.9 * s);
      for (var r = 0; r < 3; r++) { var ry = top - 5 - r * 5; var ra = P(-gm.bore + 0.8, ry), rb = P(gm.bore - 0.8, ry); line(ra[0], ra[1], rb[0], rb[1]); }
      // 连杆、曲柄
      var pp = P(0, pinY), cq = P(cp[0], cp[1]);
      ctx.strokeStyle = C.rod; ctx.lineWidth = 9 * s; ctx.lineCap = 'round'; line(pp[0], pp[1], cq[0], cq[1]);
      ctx.strokeStyle = '#8e98a8'; ctx.lineWidth = 3 * s; line(pp[0], pp[1], cq[0], cq[1]);
      // 曲柄臂与平衡重
      ctx.fillStyle = C.crank;
      var ang = Math.atan2(cp[0], cp[1]);
      ctx.save(); ctx.translate(o[0], o[1]); ctx.rotate(ang);
      ctx.beginPath(); ctx.arc(0, 0, 14 * s, 0, TAU); ctx.fill();
      ctx.fillRect(-7 * s, -G.r * s, 14 * s, G.r * s);
      ctx.fillStyle = '#9aa6b8'; ctx.beginPath(); ctx.arc(0, 0, 30 * s, Math.PI * 0.2, Math.PI * 0.8); ctx.lineTo(0, 0); ctx.closePath(); ctx.fill();
      ctx.restore();
      dot(o[0], o[1], 4 * s, '#4b5566');
      dot(cq[0], cq[1], 5.5 * s, '#e6ebf2'); dot(cq[0], cq[1], 2.5 * s, '#4b5566');
      dot(pp[0], pp[1], 5 * s, '#e6ebf2'); dot(pp[0], pp[1], 2.2 * s, '#4b5566');

      // 活塞运动方向
      if (opt.dirArrow !== false) {
        var down = E.STROKES[si].dir === 'down', ax = P(gm.wall + 16, top - G.pistonH / 2);
        arrow(ax[0], ax[1] + (down ? -18 : 18) * s * 0.9, ax[0], ax[1] + (down ? 18 : -18) * s * 0.9, opt.dirCol || '#ffffff', 3.5, 11);
      }
      if (st.labels) labels(gm, eng, top, pinY, cp, vl);
      return { gm: gm, g: g, top: top };
    }
    function flowArrows(gm, side, lift, t, col) {
      var R = gm.roof, ph = (t * 1.6) % 1;
      // 沿气道中心线：外端 (±90, R+15) → 拐角 (±22, R+15) → 气门口 (±22, R−6)
      var path = [[side * 92, R + 15], [side * 22, R + 15], [side * 22, R - 4 - lift * 9]];
      if (side > 0) path.reverse();
      for (var k = 0; k < 2; k++) {
        var f = (ph + k * 0.5) % 1, segL = [Math.abs(path[1][0] - path[0][0]), Math.abs(path[2][1] - path[1][1])], tot = segL[0] + segL[1];
        var d = f * tot, a, b;
        if (d < segL[0]) { a = path[0]; b = path[1]; d = d / segL[0]; } else { a = path[1]; b = path[2]; d = (d - segL[0]) / segL[1]; }
        var x = lerp(a[0], b[0], d), y = lerp(a[1], b[1], d), dx = b[0] - a[0], dy = b[1] - a[1], n = Math.hypot(dx, dy);
        var q0 = P(x - dx / n * 7, y - dy / n * 7), q1 = P(x + dx / n * 7, y + dy / n * 7);
        arrow(q0[0], q0[1], q1[0], q1[1], col, 2.4, 8);
      }
    }
    function labels(gm, eng, top, pinY, cp, vl) {
      var s = M.s, px = L.narrow ? 11 : 12;
      function lead(wx, wy, lx, ly, txt, col, align) {
        var a = P(wx, wy), b = P(lx, ly);
        ctx.strokeStyle = 'rgba(200,210,225,0.45)'; ctx.lineWidth = 1; line(a[0], a[1], b[0], b[1]);
        dot(a[0], a[1], 2, 'rgba(220,228,240,0.8)');
        tag(txt, b[0], b[1], col || C.text, px, align);
      }
      lead(-22, gm.headTop + 10, -66, gm.headTop + 30, '进气门', vl.intake > 0 ? '#9fe0ff' : C.text, 'right');
      lead(22, gm.headTop + 10, 66, gm.headTop + 30, '排气门', vl.exhaust > 0 ? '#ffc4a8' : C.text, 'left');
      lead(0, gm.headTop + 44, eng === 'gasoline' ? 30 : 30, gm.headTop + 56, E.ENGINES[eng].top, C.accent, 'left');
      lead(gm.wall - 4, gm.roof - 40, 98, gm.roof - 40, '汽缸', C.text, 'left');
      lead(-gm.bore + 10, top - 30, -98, top - 30, '活塞', C.text, 'right');
      var mid = [(cp[0] + 0) / 2, (pinY + cp[1]) / 2];
      lead(mid[0] - 2, mid[1], -98, Math.max(mid[1], 40), '连杆', C.text, 'right');
      lead(-Math.sin(0.6) * 12, -Math.cos(0.6) * 12, -98, -30, '曲轴', C.text, 'right');
      lead(Math.sin(2.3) * 58, Math.cos(2.3) * 58, 92, -56, '飞轮', C.text, 'left');
    }

    // ---------- 信息区：工作循环表盘、温度和压强、能量转化 ----------
    function infoPanel(st, eng, th, g, hideStroke) {
      var I = L.info, si = E.strokeIndex(th), S = E.STROKES[si];
      var dial, bars, ih = I.h;
      if (I.side) {
        var R = Math.min(I.w * 0.36, I.h * 0.2), sh = Math.min((I.w - 20) / 4 * 1.9, I.h * 0.3);
        ih = Math.min(I.h, 42 + 2 * R + 46 + 80 + 20 + (hideStroke ? 0 : sh) + 14);
        I = { x: I.x, y: I.y, w: I.w, h: ih, side: true, sh: sh };
      }
      ctx.fillStyle = 'rgba(17,23,35,0.72)'; rrect(I.x, I.y, I.w, I.h, 10); ctx.fill();
      ctx.strokeStyle = C.line; ctx.lineWidth = 1; ctx.stroke();
      if (I.side) {
        dial = { x: I.x + I.w / 2, y: I.y + 42 + R, r: R };
        bars = { x: I.x + 14, y: dial.y + R + 46, w: I.w - 28 };
      } else {
        var R2 = Math.min(I.h * 0.34, I.w * 0.2);
        dial = { x: I.x + 16 + R2, y: I.y + I.h / 2 + 4, r: R2 };
        bars = { x: dial.x + R2 + 22, y: I.y + 34, w: I.x + I.w - (dial.x + R2 + 22) - 12 };
      }
      text('一个工作循环 = 4 个冲程 = 曲轴转 2 圈', I.side ? I.x + I.w / 2 : I.x + I.w / 2, I.side ? I.y + 14 : I.y + 11, C.muted, 'center', 11);
      // 表盘：一圈代表 720°
      var R0 = dial.r, ri = R0 * 0.55;
      for (var k = 0; k < 4; k++) {
        var a0 = -Math.PI / 2 + k * Math.PI / 2, a1 = a0 + Math.PI / 2, on = !hideStroke && k === si;
        ctx.beginPath(); ctx.arc(dial.x, dial.y, R0, a0 + 0.02, a1 - 0.02); ctx.arc(dial.x, dial.y, ri, a1 - 0.02, a0 + 0.02, true); ctx.closePath();
        ctx.fillStyle = rgba(E.STROKES[k].color, on ? 0.75 : 0.18); ctx.fill();
        var am = (a0 + a1) / 2, rr = (R0 + ri) / 2;
        text(hideStroke ? '?' : PART[k], dial.x + Math.cos(am) * rr, dial.y + Math.sin(am) * rr, on ? '#10141c' : C.text, 'center', clamp(R0 * 0.2, 10, 14), '600');
      }
      if (!hideStroke) {
        // 指针：表盘外侧的三角形 + 内圈里的短针
        var ap = -Math.PI / 2 + E.wrap(th) / 720 * TAU, ca = Math.cos(ap), sa = Math.sin(ap), tip = R0 + 2, bk = R0 + 13;
        ctx.fillStyle = '#ffffff'; ctx.beginPath(); ctx.moveTo(dial.x + ca * tip, dial.y + sa * tip);
        ctx.lineTo(dial.x + ca * bk - sa * 6, dial.y + sa * bk + ca * 6); ctx.lineTo(dial.x + ca * bk + sa * 6, dial.y + sa * bk - ca * 6); ctx.closePath(); ctx.fill();
        ctx.strokeStyle = 'rgba(255,255,255,0.85)'; ctx.lineWidth = 2; line(dial.x + ca * ri * 0.6, dial.y + sa * ri * 0.6, dial.x + ca * (ri - 3), dial.y + sa * (ri - 3));
        var rev = Math.floor(E.wrap(th) / 360) + 1;
        text(Math.round(E.wrap(th)) + '°', dial.x, dial.y - ri * 0.32, C.text, 'center', clamp(ri * 0.3, 10, 15), '600');
        text('曲轴第 ' + rev + ' 圈', dial.x, dial.y + ri * 0.4, C.muted, 'center', 10);
        // 能量转化
        var ey = I.side ? dial.y + R0 + 22 : dial.y + R0 + 12;
        var et = S.energy ? S.energy.replace('转化为', ' → ') : '靠飞轮的惯性完成';
        if (I.side) tag(S.name + '：' + et, dial.x, ey, S.energy ? S.color : C.muted, 12);
      }
      // 温度、压强条（对数刻度，示意）
      var bw = bars.w, by = bars.y, rowH = I.side ? 40 : 34;
      function bar(label, val, lo, hi, col, unit, y) {
        var f = clamp(Math.log(val / lo) / Math.log(hi / lo), 0, 1);
        text(label, bars.x, y, C.muted, 'left', 11);
        text(unit, bars.x + bw, y, col, 'right', 11, '600');
        ctx.fillStyle = '#1f2838'; rrect(bars.x, y + 8, bw, 9, 4); ctx.fill();
        ctx.fillStyle = col; rrect(bars.x, y + 8, Math.max(6, bw * f), 9, 4); ctx.fill();
      }
      var Tc = g.T - 273;
      bar('缸内气体温度', g.T, 280, 2800, mix('#4fc3f7', '#ff5a3d', clamp((g.T - 300) / 1800, 0, 1)), '约 ' + Math.round(Tc / 10) * 10 + ' °C', by);
      bar('缸内气体压强', g.p, 0.7, 60, '#ffc94a', '约 ' + (g.p < 10 ? g.p.toFixed(1) : Math.round(g.p)) + ' 个大气压', by + rowH);
      var vy = by + rowH * 2;
      if (!I.side && !hideStroke && !(st.scene === 'cycle' && st.energy !== false)) tag(S.name + '：' + (S.energy ? S.energy.replace('转化为', ' → ') : '靠飞轮惯性'), bars.x, vy + 10, S.energy ? S.color : C.muted, 11, 'left');
      if (I.side) {
        text('数值为理想化估算，只示意变化趋势', bars.x, vy + 2, '#6c788b', 'left', 10);
        if (!hideStroke) strokeStrip(st, eng, si, I.x + 10, vy + 20, I.w - 20, I.sh);
      }
    }
    // 四个冲程的小图（像教材插图那样并排），当前冲程高亮
    function strokeStrip(st, eng, si, x, y, w, h) {
      if (h < 60) return;
      var cw = w / 4, keep = M;
      for (var k = 0; k < 4; k++) {
        var cx = x + k * cw, on = k === si;
        ctx.fillStyle = on ? rgba(E.STROKES[k].color, 0.16) : 'rgba(255,255,255,0.03)'; rrect(cx + 2, y, cw - 4, h, 6); ctx.fill();
        if (on) { ctx.strokeStyle = E.STROKES[k].color; ctx.lineWidth = 1.5; ctx.stroke(); }
        mini(eng, k * 180 + (k === 2 ? 30 : 90), cx + cw / 2, y + 6, cw - 10, h - 26);
        text(E.STROKES[k].short, cx + cw / 2, y + h - 10, on ? E.STROKES[k].color : C.muted, 'center', 11, on ? '600' : '');
      }
      M = keep;
    }
    function mini(eng, th, cx, y, w, h) {
      var gm = geom(eng), box = [-58, 70, 58, gm.headTop + 6], s = Math.min(w / (box[2] - box[0]), h / (box[3] - box[1]));
      M = { s: s, ox: cx, oy: y + h + box[1] * s };
      var vl = E.valves(th), g = E.gas(eng, th), top = E.pinY(th) + G.pinTop, si = E.strokeIndex(th);
      wrect(-gm.wall + 4, box[1], -gm.bore, gm.roof); ctx.fillStyle = C.wall; ctx.fill();
      wrect(gm.bore, box[1], gm.wall - 4, gm.roof); ctx.fill();
      wrect(-gm.bore, top, gm.bore, gm.roof); ctx.fillStyle = rgba(gasColor(eng, g), 0.45 + 0.4 * g.burn); ctx.fill();
      wrect(-gm.wall + 4, gm.roof, gm.wall - 4, gm.headTop); ctx.fillStyle = C.head; ctx.fill();
      [-1, 1].forEach(function (sd) {
        var lift = sd < 0 ? vl.intake : vl.exhaust, x = sd * 22, d = lift * 9;
        ctx.fillStyle = C.dark; wrect(x - 12, gm.roof, x + 12, gm.headTop); ctx.fill();
        ctx.fillStyle = lift > 0 ? (sd < 0 ? '#9fe0ff' : '#ffc4a8') : '#c6ced9';
        wrect(x - 12, gm.roof - d, x + 12, gm.roof - d + 4); ctx.fill();
        wrect(x - 2.5, gm.roof - d + 4, x + 2.5, gm.headTop + 4); ctx.fill();
      });
      wrect(-4, gm.roof, 4, gm.headTop + 6); ctx.fillStyle = eng === 'gasoline' ? '#e8e2d4' : '#8fa0b6'; ctx.fill();
      wrect(-gm.bore + 1, Math.max(box[1], top - G.pistonH), gm.bore - 1, top); ctx.fillStyle = C.piston; ctx.fill();
      var a = P(0, top - 22), down = E.STROKES[si].dir === 'down';
      arrow(a[0], a[1] + (down ? -10 : 10), a[0], a[1] + (down ? 10 : -10), '#10141c', 2.5, 7);
    }

    // ---------- 场景 ----------
    function drawCycle(st, info) {
      var eng = st.engine, gm = geom(eng);
      splitLayout([-130, -66, 118, gm.headTop + 64], st.energy !== false);
      var r = drawEngine(st, eng, info.theta, { particles: st.particles, dt: info.dt, dirArrow: true });
      infoPanel(st, eng, info.theta, r.g, false);
      if (st.energy !== false) energyBadge(st, eng, info.theta, L.badgeY);
    }
    function energyBadge(st, eng, th, y) {
      var si = E.strokeIndex(th), S = E.STROKES[si], g = E.gas(eng, th), s;
      if (si === 0) s = eng === 'gasoline' ? '进气门打开，吸入汽油和空气的混合物' : '进气门打开，只吸入空气';
      else if (si === 1) s = '两个气门关闭，活塞压缩气体：机械能 → 内能';
      else if (si === 2) s = g.burn > 0.5 ? (eng === 'gasoline' ? '火花塞点火，燃料燃烧：化学能 → 内能，燃气推动活塞' : '喷油嘴喷出雾状柴油，遇高温空气自燃') : '高温高压燃气推动活塞做功：内能 → 机械能';
      else s = '排气门打开，排出废气';
      font(L.narrow ? 11 : 13, '600');
      var w = ctx.measureText(s).width + 10, x = clamp(M.ox, 12 + w / 2, (L.info.side ? L.info.x - 10 : W - 12) - w / 2);
      tag(s, x, y, S.energy ? S.color : C.text, L.narrow ? 11 : 13);
    }

    function drawQuiz(st, info) {
      var q = st.quiz, eng = q ? q.engine : st.engine, gm = geom(eng), frozen = q && q.theta != null, b0 = L.bottom;
      L.bottom = (info.quizH || 120) + (L.narrow ? 52 : 58);   // 给底部的题目栏留出位置
      var box = [-130, -66, 118, gm.headTop + 64], solo = W < 640;   // 窄屏不画表盘，把位置都留给剖面图
      if (solo) fit(box, [12, L.top, W - 24, H - L.bottom - L.top]); else splitLayout(box);
      L.bottom = b0;
      var th = frozen ? q.theta : info.theta;
      var r = drawEngine(st, eng, th, { particles: st.particles, dt: frozen ? info.dt * 0.4 : info.dt, dirArrow: true, flow: true });
      if (!solo) infoPanel(st, eng, th, r.g, frozen && !st.answered);
    }

    // 能量流向图：flow 方向 u，横向 v（向下为正）；宽屏从左向右流、支流向下，窄屏从上向下流、支流向右
    function drawFlow(st, info) {
      var f = info.flow, top = L.top + 10, bot = H - L.bottom - 10, horiz = W >= 640 || W > (bot - top) * 1.05;
      var U = horiz ? W - 60 : bot - top - 10, V = horiz ? bot - top : W - 40;
      var u0 = horiz ? 30 : 0, k = Math.min(V * 0.3, horiz ? 150 : 110), drop = horiz ? clamp(V - k - 150, 60, 170) : 40;
      var y0 = horiz ? top + Math.max(50, (V - (k + drop + 60)) / 2) : top + 46;   // 宽屏整体竖直居中
      function T(u, v) { return horiz ? [u0 + u, y0 + v] : [20 + v, y0 + u]; }
      var losses = E.LOSS.map(function (x) { return { id: x.id, name: x.name, color: x.color, f: f[x.id] }; });
      var startU = horiz ? 120 : 30, endU = U - (horiz ? 150 : 70), step = (endU - startU) / losses.length;
      var rem = 1, uu = 0;
      // 主干（按剩余能量逐段变细）
      var stations = losses.map(function (l, i) { return startU + step * (i + 0.35); });
      function seg(ua, ub, th, col) {
        var a = T(ua, 0), b = T(ub + 1, th * k);   // 多画 1px，避免分段之间露缝
        ctx.fillStyle = col;
        ctx.fillRect(Math.min(a[0], b[0]), Math.min(a[1], b[1]), Math.abs(b[0] - a[0]), Math.abs(b[1] - a[1]));
      }
      var grad = horiz ? ctx.createLinearGradient(T(0, 0)[0], 0, T(endU, 0)[0], 0) : ctx.createLinearGradient(0, T(0, 0)[1], 0, T(endU, 0)[1]);
      grad.addColorStop(0, rgba(C.fuel, 0.9)); grad.addColorStop(1, rgba(C.useful, 0.9));
      uu = 0;
      losses.forEach(function (l, i) { seg(uu, stations[i], rem, grad); uu = stations[i]; rem -= l.f; });
      seg(uu, endU, rem, grad);
      // 末端箭头
      var e0 = T(endU, -k * 0.08), e1 = T(endU, rem * k + k * 0.08), e2 = T(endU + 26, rem * k / 2);
      ctx.fillStyle = rgba(C.useful, 0.95); ctx.beginPath(); ctx.moveTo(e0[0], e0[1]); ctx.lineTo(e1[0], e1[1]); ctx.lineTo(e2[0], e2[1]); ctx.closePath(); ctx.fill();
      // 支流：从主干下沿弯出，宽度 ∝ 所占比例
      rem = 1;
      var px = L.narrow ? 11 : 12;
      losses.forEach(function (l, i) {
        var t = l.f * k, c = rem * k - t / 2, R0 = t / 2 + 12, us = stations[i], pts = [], vEnd = k + drop;
        for (var j = 0; j <= 16; j++) { var a = j / 16 * Math.PI / 2; pts.push([us + Math.sin(a) * R0, c + R0 - Math.cos(a) * R0]); }
        pts.push([us + R0, vEnd]);
        ctx.strokeStyle = rgba(l.color, 0.85); ctx.lineWidth = Math.max(2, t); ctx.lineCap = 'butt'; ctx.lineJoin = 'round';
        ctx.beginPath(); pts.forEach(function (p, j) { var q = T(p[0], p[1]); if (j) ctx.lineTo(q[0], q[1]); else ctx.moveTo(q[0], q[1]); }); ctx.stroke();
        var ah = T(us + R0, vEnd), dir = horiz ? [0, 1] : [1, 0], hw = Math.max(6, t / 2 + 5);
        ctx.fillStyle = rgba(l.color, 0.95); ctx.beginPath();
        ctx.moveTo(ah[0] - dir[1] * hw, ah[1] - dir[0] * hw); ctx.lineTo(ah[0] + dir[1] * hw, ah[1] + dir[0] * hw); ctx.lineTo(ah[0] + dir[0] * 14, ah[1] + dir[1] * 14); ctx.closePath(); ctx.fill();
        var lb = T(us + R0, vEnd + (horiz ? 30 : 22));
        var amt = info.Q * l.f;
        if (horiz) {
          text(l.name, lb[0], lb[1], l.color, 'center', px + 1, '600');
          text(Math.round(l.f * 100) + '% · ' + sci(amt) + ' J', lb[0], lb[1] + 18, C.text, 'center', px);
        } else {
          text(l.name + ' ' + Math.round(l.f * 100) + '%', lb[0] + 4, lb[1], l.color, 'left', px, '600');
          text(sci(amt) + ' J', lb[0] + 4, lb[1] + 15, C.text, 'left', px);
        }
        rem -= l.f;
      });
      // 起点与终点说明
      var fu = E.ENGINES[st.engine], s0 = T(0, -16), s1 = T(endU + 30, rem * k / 2);
      if (horiz) {
        text(fu.fuel + '完全燃烧放出的热量 Q放 = mq', s0[0], s0[1] - 18, C.fuel, 'left', 13, '600');
        text('= ' + fmt(st.m) + ' kg × ' + sci(fu.q) + ' J/kg = ' + sci(info.Q) + ' J（100%）', s0[0], s0[1], C.text, 'left', 12);
        text('有用机械能 W有', s1[0] + 6, s1[1] - 22, C.useful, 'left', 14, '600');
        text(sci(info.Q * f.useful) + ' J', s1[0] + 6, s1[1] - 2, C.text, 'left', 13);
        text('η = ' + (f.useful * 100).toFixed(1) + '%', s1[0] + 6, s1[1] + 20, C.useful, 'left', 18, '700');
      } else {
        var t0 = T(0, 0);
        text(fu.fuel + '完全燃烧放出 Q放 = mq = ' + sci(info.Q) + ' J', t0[0], t0[1] - 16, C.fuel, 'left', 12, '600');
        var t1 = T(endU + 34, 0);
        text('有用机械能 W有 = ' + sci(info.Q * f.useful) + ' J，η = ' + (f.useful * 100).toFixed(1) + '%', t1[0], t1[1] + 4, C.useful, 'left', 12, '600');
      }
    }
    function fmt(v) { return (+v.toFixed(2)).toString(); }
    // 科学计数法：4.6×10⁷
    function sci(v) {
      if (!v) return '0';
      var e = Math.floor(Math.log10(Math.abs(v))), m = v / Math.pow(10, e);
      if (+m.toFixed(2) >= 10) { m /= 10; e += 1; }
      var sup = String(e).split('').map(function (c) { return '⁰¹²³⁴⁵⁶⁷⁸⁹'['0123456789'.indexOf(c)] || (c === '-' ? '⁻' : c); }).join('');
      return (+m.toFixed(2)) + '×10' + sup;
    }

    function draw(st, info) {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, W, H);
      if (st.scene === 'efficiency') drawFlow(st, info);
      else if (st.scene === 'quiz') drawQuiz(st, info);
      else drawCycle(st, info);
    }

    return { resize: resize, draw: draw, sci: sci };
  }

  window.EngineDraw = EngineDraw;
})();
