// 热机计算：曲柄连杆机构的运动、四个冲程的气门与能量转化、缸内气体状态（理想化示意）、
// 转速换算、能量流向与热机效率、判断练习出题。不碰 DOM，可在 node 中单独测试。
// 角度：曲轴转角 θ 以度为单位，0° 为活塞在上止点、吸气冲程开始，一个工作循环 0°～720°（曲轴转两圈）
(function () {
  // 示意尺寸（mm）：曲柄半径 r（行程 = 2r）、连杆长 l、缸径、活塞销到活塞顶的距离、活塞高
  var GEO = { r: 36, l: 120, bore: 80, pinTop: 22, pistonH: 50 };

  // 两种内燃机：q 为燃料热值（J/kg，人教版教材数据），eps 为压缩比，clear 为画面上的燃烧室高度（mm）
  var ENGINES = {
    gasoline: { id: 'gasoline', name: '汽油机', fuel: '汽油', q: 4.6e7, eps: 8, clear: 14, top: '火花塞',
      charge: '汽油和空气的混合物', ignite: '点燃式', T0: 320, T3: 2600, Tex: 850, eta: [0.2, 0.3] },
    diesel: { id: 'diesel', name: '柴油机', fuel: '柴油', q: 4.3e7, eps: 16, clear: 9, top: '喷油嘴',
      charge: '空气', ignite: '压燃式', T0: 330, T3: 2300, Tex: 700, eta: [0.3, 0.45] }
  };

  var STROKES = [
    { id: 'intake', name: '吸气冲程', short: '吸气', iv: true, ev: false, dir: 'down', energy: '', color: '#4fc3f7' },
    { id: 'compress', name: '压缩冲程', short: '压缩', iv: false, ev: false, dir: 'up', energy: '机械能转化为内能', color: '#ffc94a' },
    { id: 'power', name: '做功冲程', short: '做功', iv: false, ev: false, dir: 'down', energy: '内能转化为机械能', color: '#ff7a59' },
    { id: 'exhaust', name: '排气冲程', short: '排气', iv: false, ev: true, dir: 'up', energy: '', color: '#9aa7ba' }
  ];

  var P0 = 1;   // 大气压，单位 atm
  var N_COMP = 1.35, N_EXP = 1.3;   // 压缩、膨胀按多变过程 pV^n = 常量（示意）

  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
  function wrap(th) { return ((th % 720) + 720) % 720; }
  function rad(d) { return d * Math.PI / 180; }
  function smooth(t) { t = clamp(t, 0, 1); return t * t * (3 - 2 * t); }

  // 活塞销到曲轴中心的距离（y 向上）
  function pinY(th) {
    var a = rad(th), r = GEO.r, l = GEO.l;
    return r * Math.cos(a) + Math.sqrt(l * l - r * r * Math.sin(a) * Math.sin(a));
  }
  // 曲柄销位置：曲轴顺时针转动
  function crankPin(th) { var a = rad(th); return [GEO.r * Math.sin(a), GEO.r * Math.cos(a)]; }
  // 活塞离上止点的位移占行程的比例：0 上止点，1 下止点
  function travel(th) { return (GEO.r + GEO.l - pinY(th)) / (2 * GEO.r); }

  function strokeIndex(th) { return Math.floor(wrap(th) / 180) % 4; }
  function stroke(th) { return STROKES[strokeIndex(th)]; }
  // 本冲程进行了多少（0～1）
  function strokeFrac(th) { return (wrap(th) % 180) / 180; }

  // 气门升程 0～1：理想化，进气门只在吸气冲程打开，排气门只在排气冲程打开
  function valves(th) {
    var i = strokeIndex(th), f = strokeFrac(th), lift = Math.pow(Math.sin(Math.PI * f), 0.6);
    return { intake: i === 0 ? lift : 0, exhaust: i === 3 ? lift : 0 };
  }

  // 缸内气体的相对体积：燃烧室容积 vc，排量 1
  function volume(eng, th) { var vc = 1 / (ENGINES[eng].eps - 1); return vc + travel(th); }

  // 柴油机：喷油燃烧时压强基本不变，体积增大到 V3 时燃烧结束
  function dieselCut(e) {
    var vc = 1 / (e.eps - 1), vmax = 1 + vc, T2 = e.T0 * Math.pow(vmax / vc, N_COMP - 1);
    var v3 = vc * e.T3 / T2, lo = 360, hi = 540;
    for (var k = 0; k < 40; k++) { var m = (lo + hi) / 2; if (volume(e.id, m) < v3) lo = m; else hi = m; }
    return lo;
  }

  // 缸内气体状态（理想化示意）：T 单位 K，p 单位 atm；burn 为火焰亮度 0～1；fresh 为新鲜充量（未燃）还是废气
  function gas(eng, th) {
    var e = ENGINES[eng], t = wrap(th), vc = 1 / (e.eps - 1), vmax = 1 + vc, V = volume(eng, t);
    var pIn = 0.9 * P0, k = pIn * vmax / e.T0;   // pV/T = k（不计进出的燃料质量）
    var T2 = e.T0 * Math.pow(vmax / vc, N_COMP - 1), p2 = pIn * Math.pow(vmax / vc, N_COMP);
    var p, T, burn = 0, fresh = t < 360, spark = 0, spray = 0;
    // 燃烧结束时的状态
    var th3, V3, p3;
    if (eng === 'gasoline') { th3 = 372; V3 = volume(eng, th3); p3 = k * e.T3 / V3; }
    else { th3 = dieselCut(e); V3 = volume(eng, th3); p3 = p2; }
    if (t < 180) { p = pIn; T = e.T0; }
    else if (t < 360) { p = pIn * Math.pow(vmax / V, N_COMP); T = e.T0 * Math.pow(vmax / V, N_COMP - 1); }
    else if (t < th3) {
      if (eng === 'gasoline') { T = T2 + (e.T3 - T2) * smooth((t - 360) / (th3 - 360)); p = k * T / V; }
      else { p = p2; T = p2 * V / k; }
      burn = 1;
    } else if (t < 540) {
      p = p3 * Math.pow(V3 / V, N_EXP); T = e.T3 * Math.pow(V3 / V, N_EXP - 1);
      burn = Math.max(0, 1 - (t - th3) / 70);
    } else {
      var p4 = p3 * Math.pow(V3 / vmax, N_EXP), T4 = e.T3 * Math.pow(V3 / vmax, N_EXP - 1), d = t - 540;
      p = 1.1 * P0 + (p4 - 1.1 * P0) * Math.exp(-d / 8);
      T = e.Tex + (T4 - e.Tex) * Math.exp(-d / 25);
    }
    if (eng === 'gasoline') spark = t > 350 && t < 368 ? 1 : 0;
    else spray = t > 352 && t < th3 ? 1 : 0;
    return { p: p, T: T, V: V, burn: burn, fresh: fresh, spark: spark, spray: spray, th3: th3,
      pMax: p3, TMax: e.T3, T2: T2, p2: p2 };
  }

  // 转速换算：单缸四冲程内燃机，一个工作循环 4 个冲程、曲轴（飞轮）转 2 圈、对外做功 1 次
  function perSecond(rpm) {
    var rev = rpm / 60;
    return { rev: rev, strokes: rev * 2, cycles: rev / 2, works: rev / 2 };
  }

  // 能量流向：按燃料质量 m 计算的总能量 mq 中各部分所占比例（示意值）
  var FLOW = {
    gasoline: { unburnt: 0.04, exhaust: 0.34, cooling: 0.32, friction: 0.07 },
    diesel: { unburnt: 0.03, exhaust: 0.30, cooling: 0.26, friction: 0.06 }
  };
  var LOSS = [
    { id: 'unburnt', name: '燃料未完全燃烧', color: '#8a6d4a' },
    { id: 'exhaust', name: '废气带走的能量', color: '#9aa7ba' },
    { id: 'cooling', name: '汽缸散热损失', color: '#4fc3f7' },
    { id: 'friction', name: '克服摩擦等机械损失', color: '#c9a7ff' }
  ];
  // opt：burn 使燃料充分燃烧，lube 良好润滑减小摩擦，recover 利用废气的能量（如废气涡轮增压）
  function flow(eng, opt) {
    var b = FLOW[eng], o = opt || {}, f = {};
    f.unburnt = o.burn ? b.unburnt * 0.25 : b.unburnt;
    f.exhaust = o.recover ? b.exhaust - 0.05 : b.exhaust;
    f.cooling = b.cooling;
    f.friction = o.lube ? b.friction * 0.6 : b.friction;
    f.useful = 1 - f.unburnt - f.exhaust - f.cooling - f.friction;
    return f;
  }
  // Q放 = mq（m 单位 kg），W有 = ηQ放
  function heat(eng, m) { return m * ENGINES[eng].q; }

  // ---------- 判断练习 ----------
  function pick(arr, rnd) { return arr[Math.floor(rnd() * arr.length) % arr.length]; }
  function shuffle(a, rnd) { for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(rnd() * (i + 1)); var t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
  function vtxt(open) { return open ? '打开' : '关闭'; }
  function why(s) {
    return '进气门' + vtxt(s.iv) + '、排气门' + vtxt(s.ev) + '，活塞向' + (s.dir === 'up' ? '上' : '下') + '运动——' + s.name + '。';
  }

  var DIFF = [
    { q: '柴油机在吸气冲程中吸入汽缸的是', opts: ['空气', '柴油和空气的混合物', '柴油', '汽油和空气的混合物'], explain: '柴油机吸气冲程只吸入空气，柴油在压缩冲程末由喷油嘴喷入汽缸。汽油机吸入的是汽油和空气的混合物。' },
    { q: '汽油机在吸气冲程中吸入汽缸的是', opts: ['汽油和空气的混合物', '空气', '汽油', '柴油和空气的混合物'], explain: '汽油机吸气冲程吸入的是汽油和空气的混合物；柴油机吸入的只有空气。' },
    { q: '汽油机汽缸顶部有', opts: ['火花塞', '喷油嘴', '火花塞和喷油嘴', '都没有'], explain: '汽油机顶部有火花塞，压缩冲程末火花塞产生电火花点燃燃料（点燃式）；柴油机顶部是喷油嘴。' },
    { q: '柴油机做功冲程中燃料被点燃的方式是', opts: ['压燃式：压缩后空气温度超过柴油的燃点', '点燃式：火花塞产生电火花', '先点燃再压缩', '由飞轮带动点燃'], explain: '柴油机压缩比大，压缩冲程末空气的温度超过柴油的燃点，喷入的雾状柴油遇到热空气立刻燃烧，叫压燃式。' },
    { q: '同样条件下，汽油机和柴油机相比', opts: ['柴油机压缩程度更大、效率更高、更笨重', '汽油机压缩程度更大、效率更高', '两者效率相同', '柴油机更轻巧，常用于小汽车、摩托车'], explain: '柴油机压缩冲程中空气被压缩得更厉害，效率一般比汽油机高，但机体笨重，多用于载重汽车、拖拉机、轮船；汽油机轻巧，多用于小汽车、摩托车。' }
  ];

  // 出一道题：type 为 stroke | energy | rpm | diff，rnd 为 [0,1) 随机数函数（便于测试）
  function quiz(type, rnd) {
    rnd = rnd || Math.random;
    type = type || pick(['stroke', 'stroke', 'energy', 'rpm', 'diff'], rnd);
    var eng = pick(['gasoline', 'diesel'], rnd), e = ENGINES[eng], q = { type: type, engine: eng };
    if (type === 'stroke') {
      var i = Math.floor(rnd() * 4) % 4, s = STROKES[i];
      q.theta = i * 180 + (i === 2 ? 40 : 90);   // 做功冲程画在刚开始的时候，看得见燃烧
      q.q = '图中' + e.name + '正处于哪个冲程？';
      q.opts = STROKES.map(function (x) { return x.name; });
      q.ans = s.name;
      q.explain = why(s) + (i === 1 ? '这个冲程把机械能转化为内能。' : i === 2 ? '这个冲程把内能转化为机械能，是唯一对外做功的冲程。' : '这个冲程靠飞轮的惯性完成。');
    } else if (type === 'energy') {
      var j = rnd() < 0.5 ? 1 : 2, st = STROKES[j];
      q.theta = j * 180 + (j === 2 ? 40 : 90);
      if (rnd() < 0.5) {
        q.q = '图中' + e.name + '的这个冲程中，能量是怎样转化的？';
        q.opts = ['机械能转化为内能', '内能转化为机械能', '化学能转化为机械能', '内能转化为化学能'];
        q.ans = st.energy;
        q.explain = why(st) + (j === 1 ? '活塞压缩气体做功，气体内能增加、温度升高：机械能转化为内能。' : '高温高压的燃气推动活塞做功，燃气内能减少、温度降低：内能转化为机械能。');
      } else {
        q.theta = null;
        q.q = e.name + '工作时，把' + (j === 1 ? '机械能转化为内能' : '内能转化为机械能') + '的是哪个冲程？';
        q.opts = STROKES.map(function (x) { return x.name; });
        q.ans = st.name;
        q.explain = j === 1 ? '压缩冲程：活塞向上压缩汽缸内的气体，机械能转化为内能。' : '做功冲程：燃料燃烧产生的高温高压燃气推动活塞向下运动，内能转化为机械能。';
      }
    } else if (type === 'rpm') {
      var rpm = pick([1200, 1800, 2400, 3000, 3600], rnd), ps = perSecond(rpm), r = ps.rev;
      q.rpm = rpm;
      q.q = '某单缸四冲程' + e.name + '的飞轮转速是 ' + rpm + ' r/min，它每秒完成几个冲程、对外做功几次？';
      var cand = [[2 * r, r / 2], [r, r / 2], [2 * r, r], [4 * r, r], [r / 2, r / 2]], seen = {};
      q.opts = [];
      cand.forEach(function (c) { var t = c[0] + ' 个冲程，做功 ' + c[1] + ' 次'; if (!seen[t] && q.opts.length < 4) { seen[t] = 1; q.opts.push(t); } });
      q.ans = q.opts[0];
      q.explain = rpm + ' r/min = ' + r + ' r/s。一个工作循环飞轮转 2 圈、完成 4 个冲程、做功 1 次，所以每秒完成 ' + 2 * r + ' 个冲程、' + r / 2 + ' 个工作循环、对外做功 ' + r / 2 + ' 次。';
    } else {
      var d = pick(DIFF, rnd);
      q.engine = /柴油/.test(d.q) ? 'diesel' : 'gasoline';
      q.q = d.q; q.opts = d.opts.slice(); q.ans = d.opts[0]; q.explain = d.explain;
    }
    q.opts = shuffle(q.opts.slice(), rnd);
    return q;
  }

  window.Engine = {
    GEO: GEO, ENGINES: ENGINES, STROKES: STROKES, LOSS: LOSS, FLOW: FLOW,
    clamp: clamp, wrap: wrap, pinY: pinY, crankPin: crankPin, travel: travel,
    strokeIndex: strokeIndex, stroke: stroke, strokeFrac: strokeFrac, valves: valves, volume: volume, gas: gas,
    perSecond: perSecond, flow: flow, heat: heat, quiz: quiz
  };
})();
