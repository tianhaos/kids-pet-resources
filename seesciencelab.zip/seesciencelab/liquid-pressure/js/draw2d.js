// 液体压强绘图：压强计（烧杯、探头、U 形管、刻度尺、p-h 图像）、容器形状（三个容器的底部压强与压力）、
// 浮力产生的原因（正方体各面的压力、F-h 图像）
// 世界坐标用 cm（y 向上，桌面 y = 0），fit() 缩放进画面；图像画在画面右侧（窄而高时画在下方）
(function () {
  var Q = window.LiqP, TAU = Math.PI * 2;
  var C = { text: '#e6ebf2', muted: '#8d99ab', line: '#2a3446', accent: '#ffc94a', glass: 'rgba(190,215,240,0.55)',
    p: '#ffc94a', up: '#4fc3f7', down: '#ff7b6b', side: '#9aa7ba', Fb: '#7ee081', G: '#ff7b6b', F: '#4fc3f7',
    table: '#2b3446', metal: '#b8c2d1', membrane: '#e8a0a8', tube: '#d9a35f' };

  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
  function hex2rgb(h) { var n = parseInt(h.slice(1), 16); return [n >> 16 & 255, n >> 8 & 255, n & 255]; }
  function rgba(h, a) { var c = hex2rgb(h); return 'rgba(' + c[0] + ',' + c[1] + ',' + c[2] + ',' + a + ')'; }
  function f2(v, d) { return (+v.toFixed(d == null ? 2 : d)).toString(); }

  function LiqDraw(canvas) {
    var ctx = canvas.getContext('2d'), W = 0, H = 0, dpr = 1, L = {}, M = null;

    function resize(w, h) {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      W = w; H = h;
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
      canvas.style.width = w + 'px'; canvas.style.height = h + 'px';
      L.narrow = W <= 760; L.top = L.narrow ? 84 : 52; L.bottom = L.narrow ? 46 : 50;
    }
    function fit(box, area) {
      var s = Math.min(area[2] / (box[2] - box[0]), area[3] / (box[3] - box[1]));
      M = { s: s, ox: area[0] + (area[2] - s * (box[2] - box[0])) / 2 - box[0] * s, oy: area[1] + (area[3] + s * (box[3] - box[1])) / 2 + box[1] * s };
    }
    function P(x, y) { return [M.ox + x * M.s, M.oy - y * M.s]; }
    function unP(x, y) { return [(x - M.ox) / M.s, (M.oy - y) / M.s]; }
    // 有图像的场景：宽屏图像在右，窄屏在下
    function splitLayout(box, gwMax) {
      var top = L.top, bot = H - L.bottom, avail = bot - top, area;
      if (W >= 640 || W > avail * 0.9) {
        var gw = clamp(W * 0.38, 200, gwMax || 400), gh = Math.min(gw * 0.85, avail * 0.62);
        area = [12, top, W - gw - 36, avail];
        L.graph = { x: W - gw - 16, y: top + 8, w: gw, h: gh };
      } else {
        var gh2 = clamp(avail * 0.3, 140, 230);
        area = [12, top, W - 24, avail - gh2 - 16];
        L.graph = { x: 16, y: bot - gh2, w: W - 32, h: gh2 };
      }
      fit(box, area);
    }

    function font(px, w) { ctx.font = (w || '') + ' ' + Math.round(px) + 'px -apple-system, "PingFang SC", "Microsoft YaHei", sans-serif'; }
    function text(s, x, y, col, align, px, w) { font(px, w); ctx.fillStyle = col; ctx.textAlign = align || 'center'; ctx.textBaseline = 'middle'; ctx.fillText(s, x, y); }
    function tag(s, x, y, col, px, align) {
      font(px || 13, '600'); var w = ctx.measureText(s).width + 10, h = (px || 13) + 8;
      var x0 = align === 'left' ? x : align === 'right' ? x - w : x - w / 2;
      ctx.fillStyle = 'rgba(11,15,24,0.82)'; rrect(x0, y - h / 2, w, h, 5); ctx.fill();
      text(s, x0 + w / 2, y, col, 'center', px || 13, '600');
    }
    function line(x1, y1, x2, y2) { ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke(); }
    function rrect(x, y, w, h, r) {
      ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r);
      ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
    }
    function wrect(x0, y0, x1, y1) { var a = P(x0, y1), b = P(x1, y0); ctx.beginPath(); ctx.rect(a[0], a[1], b[0] - a[0], b[1] - a[1]); }
    function arrow(x1, y1, x2, y2, col, w, head) {
      var a = Math.atan2(y2 - y1, x2 - x1), h = head || 10, l = Math.hypot(x2 - x1, y2 - y1);
      if (l < 2) return;
      if (h > l * 0.7) h = l * 0.7;
      ctx.strokeStyle = col; ctx.fillStyle = col; ctx.lineWidth = w || 3; ctx.lineCap = 'round';
      if (l > h) line(x1, y1, x2 - Math.cos(a) * h * 0.7, y2 - Math.sin(a) * h * 0.7);
      ctx.beginPath(); ctx.moveTo(x2, y2);
      ctx.lineTo(x2 - Math.cos(a - 0.42) * h, y2 - Math.sin(a - 0.42) * h);
      ctx.lineTo(x2 - Math.cos(a + 0.42) * h, y2 - Math.sin(a + 0.42) * h); ctx.closePath(); ctx.fill();
    }
    function dot(x, y, r, col) { ctx.fillStyle = col; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill(); }

    function table(x0, x1) {
      var a = P(x0, 0), b = P(x1, 0);
      ctx.fillStyle = C.table; ctx.fillRect(a[0], a[1], b[0] - a[0], Math.max(6, 0.8 * M.s));
      ctx.strokeStyle = '#46526a'; ctx.lineWidth = 1.5; line(a[0], a[1], b[0], b[1]);
    }
    function beaker(x0, x1, h) {
      var t = 0.35;
      ctx.strokeStyle = C.glass; ctx.lineWidth = Math.max(1.5, t * M.s); ctx.lineJoin = 'round';
      var a = P(x0 - t / 2, h), b = P(x0 - t / 2, -t / 2), c = P(x1 + t / 2, -t / 2), d = P(x1 + t / 2, h);
      ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); ctx.lineTo(c[0], c[1]); ctx.lineTo(d[0], d[1]); ctx.stroke();
    }
    function liquid(x0, x1, lv, col, a) {
      wrect(x0, 0, x1, lv); ctx.fillStyle = rgba(col, a == null ? 0.42 : a); ctx.fill();
      var p = P(x0, lv), q = P(x1, lv); ctx.strokeStyle = rgba(col, 0.95); ctx.lineWidth = 2; line(p[0], p[1], q[0], q[1]);
    }
    // 液体中某点的压强箭头：长度 ∝ 压强，kp 为 px/Pa；指向作用点（液体压向物体表面）
    function pArrow(x, y, nx, ny, p, kp, col) {
      if (p < 1) return;
      var len = Math.max(6, p * kp);
      arrow(x + nx * len, y + ny * len, x, y, col, 2, 7);
    }

    // ======================= 压强计 =======================
    // 探头：膜中心 (x, y)，n 为膜的朝向（外法线）。金属盒在膜后面，硬管从盒背面接出后折向上
    function probeGeom(st) {
      var n = Q.DIRS[st.dir].n, r = Q.PROBE.r, t = Q.PROBE.t;
      var cx = st.px - n[0] * t / 2, cy = st.py - n[1] * t / 2;   // 盒中心
      var back = [st.px - n[0] * t, st.py - n[1] * t];             // 盒背面中心
      var path;
      if (st.dir === 'down') path = [back, [back[0], Q.BEAKER.h + 4]];
      else if (st.dir === 'side') path = [back, [back[0] + 1.2, back[1]], [back[0] + 1.2, Q.BEAKER.h + 4]];
      else path = [back, [back[0], back[1] - 1.0], [back[0] + r + 0.9, back[1] - 1.0], [back[0] + r + 0.9, Q.BEAKER.h + 4]];
      return { n: n, r: r, t: t, cx: cx, cy: cy, path: path };
    }
    function drawProbe(st, info, g) {
      var s = M.s;
      // 硬管
      ctx.strokeStyle = C.metal; ctx.lineWidth = Math.max(3, 0.45 * s); ctx.lineJoin = 'round'; ctx.lineCap = 'round';
      ctx.beginPath(); g.path.forEach(function (q, i) { var p = P(q[0], q[1]); if (!i) ctx.moveTo(p[0], p[1]); else ctx.lineTo(p[0], p[1]); }); ctx.stroke();
      // 金属盒（侧视为矩形，长边沿膜面）
      var n = g.n, tx = -n[1], ty = n[0];   // 膜面方向
      var c = P(g.cx, g.cy);
      ctx.save(); ctx.translate(c[0], c[1]); ctx.rotate(-Math.atan2(ty, tx));
      var hw = g.r * s, ht = g.t * s / 2;
      ctx.fillStyle = '#8f9bad'; ctx.fillRect(-hw, -ht, 2 * hw, 2 * ht);
      ctx.strokeStyle = '#596476'; ctx.lineWidth = 1; ctx.strokeRect(-hw, -ht, 2 * hw, 2 * ht);
      ctx.restore();
      // 橡皮膜：受到液体压强向盒内凹进（凹进量 ∝ 压强）
      var bulge = clamp(info.p / 2400, 0, 1) * 0.55 * s;
      var m = P(st.px, st.py), e1 = [m[0] + tx * hw, m[1] - ty * hw], e2 = [m[0] - tx * hw, m[1] + ty * hw];
      var ctrl = [m[0] - n[0] * bulge * 2, m[1] + n[1] * bulge * 2];
      ctx.strokeStyle = C.membrane; ctx.lineWidth = Math.max(2.5, 0.22 * s); ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(e1[0], e1[1]); ctx.quadraticCurveTo(ctrl[0], ctrl[1], e2[0], e2[1]); ctx.stroke();
      if (st.hover === 'probe' || st.dragging) {
        ctx.strokeStyle = rgba('#ffc94a', 0.8); ctx.setLineDash([4, 4]); ctx.lineWidth = 1.2;
        ctx.beginPath(); ctx.arc(m[0], m[1], g.r * s + 8, 0, TAU); ctx.stroke(); ctx.setLineDash([]);
      }
    }
    function uTube(st, info) {
      var U = Q.UTUBE, xl = 16, xr = 21, yb = 2.2, rr = (xr - xl) / 2, s = M.s, wIn = 0.8;
      var col = Q.TUBE_LIQ[st.tube].color, half = info.dhShow / 2;
      var yl = U.base - half, yr = U.base + half;
      // 支架与刻度尺（每 1 cm 一小格，每 5 cm 标数字，0 在原来的液面处）
      var ra = P(xl + 1.1, U.h), rb = P(xr - 1.1, 0.6);
      ctx.fillStyle = '#d8c79c'; ctx.fillRect(ra[0], ra[1], rb[0] - ra[0], rb[1] - ra[1]);
      for (var i = -13; i <= 14; i++) {
        var y = U.base + i, p = P(xl + 1.1, y), long = i % 5 === 0;
        ctx.strokeStyle = '#4a3f28'; ctx.lineWidth = long ? 1.2 : 0.7;
        line(p[0], p[1], p[0] + (long ? 0.9 : 0.5) * s, p[1]);
        if (long && s >= 7) text(String(Math.abs(i)), (ra[0] + rb[0]) / 2 + 0.25 * s, p[1], '#4a3f28', 'center', clamp(s * 0.7, 8, 12), '600');
      }
      // 液柱（沿管的中心线描粗线）
      function tubePath(y1, y2) {
        var a = P(xl, y1), b = P(xl, yb), c = P((xl + xr) / 2, yb), d = P(xr, y2);
        ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]);
        ctx.arc(c[0], c[1], rr * s, Math.PI, 0, true); ctx.lineTo(d[0], d[1]);
      }
      ctx.lineCap = 'butt'; ctx.lineJoin = 'round';
      tubePath(U.h, U.h); ctx.strokeStyle = C.glass; ctx.lineWidth = (wIn + 0.3) * s; ctx.stroke();
      tubePath(U.h, U.h); ctx.strokeStyle = '#121a28'; ctx.lineWidth = wIn * s; ctx.stroke();
      tubePath(clamp(yl, yb, U.h), clamp(yr, yb, U.h)); ctx.strokeStyle = col; ctx.lineWidth = wIn * s; ctx.stroke();
      // 液面高度差标注
      var dh = info.dhShow;
      if (dh > 0.3) {
        var xa = xr + 0.9, pa = P(xa, yr), pb = P(xa, yl), pl = P(xl - 0.6, yl), pr = P(xr + 0.6, yr);
        ctx.strokeStyle = rgba('#ffc94a', 0.6); ctx.setLineDash([3, 3]); ctx.lineWidth = 1;
        line(pl[0], pl[1], P(xa + 0.4, yl)[0], pl[1]); line(P(xr - 0.6, yr)[0], pr[1], P(xa + 0.4, yr)[0], pr[1]); ctx.setLineDash([]);
        arrow(pa[0], (pa[1] + pb[1]) / 2, pa[0], pa[1], C.accent, 1.5, 6); arrow(pa[0], (pa[1] + pb[1]) / 2, pa[0], pb[1], C.accent, 1.5, 6);
        tag('Δh = ' + f2(info.dh, 1) + ' cm', pa[0] + 6, (pa[1] + pb[1]) / 2, C.accent, 12, 'left');
      }
      var lb = P((xl + xr) / 2, -1.4); text('U 形管压强计', lb[0], Math.min(lb[1], H - L.bottom + 14), C.muted, 'center', 11);
      if (info.over) { var ot = P((xl + xr) / 2, U.h + 1.4); tag('液体会从 U 形管溢出！', ot[0], ot[1], '#ff9b8a', 12); }
      return { top: [xl, U.h] };
    }
    function drawProbeScene(st, info) {
      splitLayout([-11.5, -2, 29.5, 33], 380);
      var BK = Q.BEAKER, x0 = -BK.w / 2, x1 = BK.w / 2, col = Q.LIQUIDS[st.liquid].color, g = probeGeom(st);
      table(-11.5, 26.5);
      liquid(x0, x1, BK.level, col, 0.36);
      // 器壁上的压强箭头：同种液体，越深压强越大
      if (st.arrows) {
        var kp = 3.2 * M.s / Q.pressure(1.2, BK.level);
        for (var d = 2; d < BK.level; d += 3) {
          var p = Q.pressure(info.rho, d), a = P(x0, BK.level - d), b = P(x1, BK.level - d);
          pArrow(a[0], a[1], 1, 0, p, kp, rgba('#ffc94a', 0.55)); pArrow(b[0], b[1], -1, 0, p, kp, rgba('#ffc94a', 0.55));
        }
        var pB = Q.pressure(info.rho, BK.level);
        for (var xx = x0 + 2; xx < x1 - 1; xx += 4) { var c = P(xx, 0); pArrow(c[0], c[1], 0, -1, pB, kp, rgba('#ffc94a', 0.55)); }
      }
      // 软管：从硬管顶端接到 U 形管左臂
      var ut = { top: [16, Q.UTUBE.h] }, tp = g.path[g.path.length - 1], s0 = P(tp[0], tp[1]), s1 = P(ut.top[0], ut.top[1]);
      ctx.strokeStyle = C.tube; ctx.lineWidth = Math.max(3, 0.5 * M.s); ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(s0[0], s0[1]);
      ctx.bezierCurveTo(s0[0], s0[1] - 5 * M.s, s1[0], s1[1] - 4 * M.s, s1[0], s1[1]); ctx.stroke();
      uTube(st, info);
      drawProbe(st, info, g);
      // 探头周围各方向的压强箭头（同一深度各个方向压强相等）
      var m = P(st.px, st.py);
      if (st.arrows && info.h > 0.3) {
        var kp2 = 2.6 * M.s / Q.pressure(1.2, BK.level), R = (g.r + 0.6) * M.s;
        for (var k = 0; k < 8; k++) {
          var an = k * TAU / 8 + TAU / 16, nx = Math.cos(an), ny = Math.sin(an);
          pArrow(m[0] + nx * R, m[1] + ny * R, nx, ny, info.pLiq, kp2, C.accent);
        }
      }
      beaker(x0, x1, BK.h);
      // 深度标注：液面到膜中心
      if (info.h > 0.2) {
        var xs = x0 + 1.2, pa = P(xs, BK.level), pb = P(xs, st.py);
        ctx.strokeStyle = rgba('#e6ebf2', 0.5); ctx.setLineDash([3, 3]); ctx.lineWidth = 1; line(pb[0], pb[1], m[0] - g.r * M.s - 4, pb[1]); ctx.setLineDash([]);
        arrow(pa[0], (pa[1] + pb[1]) / 2, pa[0], pa[1], C.text, 1.5, 6); arrow(pa[0], (pa[1] + pb[1]) / 2, pa[0], pb[1], C.text, 1.5, 6);
        tag('h = ' + f2(info.h, 1) + ' cm', pa[0] + 5, (pa[1] + pb[1]) / 2, C.text, 12, 'left');
      }
      var lt = P(x1 - 0.6, BK.level - 1.2); text(Q.LIQUIDS[st.liquid].name + '  ρ = ' + f2(info.rho) + ' g/cm³', lt[0], lt[1], '#e6ebf2', 'right', 12, '600');
      var bt = P(0, -1.4); text('烧杯', bt[0], Math.min(bt[1], H - L.bottom + 14), C.muted, 'center', 11);
      var hint = P(st.px - g.r - 0.6, st.py); text('✥ 拖动探头', hint[0] - 12, hint[1] + (st.dir === 'down' ? -16 : 18), C.muted, 'right', 11);
      if (st.leak) { var lk = P(16, Q.UTUBE.h + 2.8); tag('装置漏气', lk[0], lk[1], '#ff9b8a', 12); }
      phGraph(st, info);
    }
    // p-h 图像：三种液体的理论线 + 已记录的数据点
    function phGraph(st, info) {
      var g = L.graph, pad = { l: 46, r: 12, t: 28, b: 30 };
      var x0 = g.x + pad.l, x1 = g.x + g.w - pad.r, y0 = g.y + g.h - pad.b, y1 = g.y + pad.t;
      var hMax = 20, pMax = 2500;
      function X(h) { return x0 + (x1 - x0) * h / hMax; }
      function Y(p) { return y0 - (y0 - y1) * p / pMax; }
      panelBox(g, '液体内部压强 p 与深度 h');
      ctx.strokeStyle = '#222b3b'; ctx.lineWidth = 1;
      for (var p = 0; p <= pMax; p += 500) { line(x0, Y(p), x1, Y(p)); text(String(p), x0 - 5, Y(p), C.muted, 'right', 10); }
      for (var h = 0; h <= hMax; h += 5) { line(X(h), y0, X(h), y1); text(String(h), X(h), y0 + 10, C.muted, 'center', 10); }
      text('h/cm', x1, y0 + 22, C.muted, 'right', 10); text('p/Pa', x0 - 5, y1 - 12, C.muted, 'right', 10);
      ctx.strokeStyle = '#46526a'; line(x0, y0, x1, y0); line(x0, y0, x0, y1);
      Object.keys(Q.LIQUIDS).forEach(function (id, i) {
        var lq = Q.LIQUIDS[id], on = id === st.liquid, pe = Q.pressure(lq.rho, hMax);
        ctx.strokeStyle = rgba(lq.color, on ? 0.9 : 0.35); ctx.lineWidth = on ? 2 : 1.2; ctx.setLineDash(on ? [] : [5, 4]);
        line(X(0), Y(0), X(hMax), Y(pe)); ctx.setLineDash([]);
        text(lq.name, X(hMax) - 2, Y(pe) - 8, rgba(lq.color, on ? 1 : 0.6), 'right', 10, on ? '600' : '');
      });
      st.data.forEach(function (r) { dot(X(r.h), Y(r.p), 3.5, Q.LIQUIDS[r.lid].color); });
      if (info.h > 0) { dot(X(Math.min(info.h, hMax)), Y(info.pLiq), 5, C.accent); ctx.strokeStyle = '#111'; ctx.lineWidth = 1; ctx.stroke(); }
    }
    function panelBox(g, title) {
      ctx.fillStyle = 'rgba(17,23,35,0.88)'; rrect(g.x, g.y, g.w, g.h, 10); ctx.fill();
      ctx.strokeStyle = C.line; ctx.lineWidth = 1; ctx.stroke();
      text(title, g.x + 12, g.y + 15, C.text, 'left', 12, '600');
    }

    // ======================= 容器形状 =======================
    var VX = { cyl: -15, open: 0, narrow: 15 };
    function drawContainer(st, info) {
      var top = L.top, area = [12, top, W - 24, H - top - L.bottom];
      fit([-23, -9.5, 23, Q.VESSEL.h + 4.5], area);
      var col = Q.LIQUIDS[st.liquid].color, s = M.s, VH = Q.VESSEL.h;
      table(-23, 23);
      var kp = 4.5 * s / Q.pressure(1.2, VH), maxF = 0;
      info.vs.forEach(function (v) { maxF = Math.max(maxF, v.F, v.G); });
      info.vs.forEach(function (v) {
        var cx = VX[v.id], h = v.h;
        function edge(y, side) { return P(cx + side * Q.radius(v.id, y), y); }
        // 液体
        ctx.beginPath();
        var a = edge(0, -1), b = edge(h, -1), c = edge(h, 1), d = edge(0, 1);
        ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); ctx.lineTo(c[0], c[1]); ctx.lineTo(d[0], d[1]); ctx.closePath();
        ctx.fillStyle = rgba(col, 0.42); ctx.fill();
        ctx.strokeStyle = rgba(col, 0.95); ctx.lineWidth = 2; line(b[0], b[1], c[0], c[1]);
        // 器壁
        var t = 0.35, e1 = edge(VH, -1), e2 = edge(VH, 1);
        ctx.strokeStyle = C.glass; ctx.lineWidth = Math.max(1.5, t * s); ctx.lineJoin = 'round';
        ctx.beginPath(); ctx.moveTo(e1[0], e1[1]); ctx.lineTo(a[0], a[1] + t * s / 2); ctx.lineTo(d[0], d[1] + t * s / 2); ctx.lineTo(e2[0], e2[1]); ctx.stroke();
        // 压强箭头：器壁处垂直于器壁，底部竖直向下
        if (st.arrows && h > 0.5) {
          var slope = (Q.SHAPES[v.id].k - 1) * Q.VESSEL.r0 / VH;   // 半径随高度的变化率
          var nl = Math.hypot(1, slope);
          for (var y = h - 1.5; y > 0.8; y -= 3) {
            var p = Q.pressure(v.rho, h - y);
            [-1, 1].forEach(function (sd) {
              // 器壁外法线（世界坐标）为 (sd, −slope)，箭头从液体一侧指向器壁：屏幕坐标下取 (−sd, −slope)
              var q = edge(y, sd);
              pArrow(q[0], q[1], -sd / nl, -slope / nl, p, kp, rgba('#ffc94a', 0.75));
            });
          }
          var pB = v.p, r0 = Q.VESSEL.r0;
          for (var xx = -r0 + 0.8; xx <= r0 - 0.7; xx += (2 * r0 - 1.5) / 3) { var bp = P(cx + xx, 0); pArrow(bp[0], bp[1], 0, -1, pB, kp, C.accent); }
        }
        // 液面深度标注
        if (h > 0.4) {
          var xs = cx - Math.max(Q.radius(v.id, 0), Q.radius(v.id, h)) - 1.2, hb = P(xs, 0), ht = P(xs, h);
          ctx.strokeStyle = rgba('#e6ebf2', 0.4); ctx.setLineDash([3, 3]); ctx.lineWidth = 1; line(ht[0], ht[1], b[0], b[1]); ctx.setLineDash([]);
          arrow(hb[0], (hb[1] + ht[1]) / 2, hb[0], ht[1], C.text, 1.4, 6); arrow(hb[0], (hb[1] + ht[1]) / 2, hb[0], hb[1], C.text, 1.4, 6);
          text(f2(h, 1), hb[0] - 3, (hb[1] + ht[1]) / 2, C.text, 'right', 11, '600');
        }
        // 名称、读数、F 与 G 的对比条
        var nt = P(cx, VH + 2.2); text(Q.SHAPES[v.id].short || Q.SHAPES[v.id].name, nt[0], nt[1], C.text, 'center', 14, '600');
        var rt = P(cx, -2.2), fs = clamp(s * 0.95, 10, 13);
        text('p = ' + f2(v.p, 0) + ' Pa', rt[0], rt[1], C.accent, 'center', fs, '600');
        // 对比条：F（底部受到的压力）与 G液
        var bw = 5.6, bx = cx - bw / 2, yF = -4.2, yG = -6.0, bh = 1.0, kF = bw / Math.max(maxF, 1e-6);
        [[yF, v.F, C.F, 'F'], [yG, v.G, C.G, 'G液']].forEach(function (r) {
          var pa = P(bx, r[0] + bh / 2), w = r[1] * kF * s;
          ctx.fillStyle = 'rgba(255,255,255,0.06)'; ctx.fillRect(pa[0], pa[1], bw * s, bh * s);
          ctx.fillStyle = rgba(r[2], 0.85); ctx.fillRect(pa[0], pa[1], w, bh * s);
          text(r[3], pa[0] - 4, pa[1] + bh * s / 2, r[2], 'right', fs * 0.9, '600');
          text(f2(r[1]) + ' N', pa[0] + bw * s + 4, pa[1] + bh * s / 2, C.text, 'left', fs * 0.9);
        });
        var ct = P(cx, -7.9), cmp = v.cmp === 0 ? 'F = G液' : v.cmp > 0 ? 'F > G液' : 'F < G液';
        text(cmp, ct[0], ct[1], v.cmp === 0 ? C.Fb : v.cmp > 0 ? C.F : C.G, 'center', fs, '600');
      });
    }

    // ======================= 浮力产生的原因 =======================
    function drawCause(st, info) {
      splitLayout([-12, -2, 12, Q.CUBE.level + 6], 380);
      var BKW = 22, x0 = -BKW / 2, x1 = BKW / 2, LV = Q.CUBE.level, a = Q.CUBE.a, s = M.s;
      var f = info.f, col = Q.LIQUIDS[st.liquid].color, yb = LV - f.hb;
      table(-12, 12);
      liquid(x0, x1, LV, col, 0.32);
      // 正方体
      var ca = P(-a / 2, yb + a), cb = P(a / 2, yb);
      ctx.fillStyle = '#c8975a'; ctx.fillRect(ca[0], ca[1], cb[0] - ca[0], cb[1] - ca[1]);
      ctx.strokeStyle = 'rgba(0,0,0,0.4)'; ctx.lineWidth = 1; ctx.strokeRect(ca[0] + 0.5, ca[1] + 0.5, cb[0] - ca[0] - 1, cb[1] - ca[1] - 1);
      wrect(-a / 2, Math.max(0, yb), a / 2, Math.min(LV, yb + a)); ctx.fillStyle = rgba(col, 0.22); if (f.hb > 0) ctx.fill();
      beaker(x0, x1, LV + 4);
      if (st.hover === 'cube' || st.dragging) { ctx.strokeStyle = rgba('#ffc94a', 0.8); ctx.setLineDash([4, 4]); ctx.strokeRect(ca[0] - 4, ca[1] - 4, cb[0] - ca[0] + 8, cb[1] - ca[1] + 8); ctx.setLineDash([]); }
      if (st.stuck && yb <= 1e-6) { var sb = P(0, 0); tag('下表面与容器底紧密接触，没有液体', sb[0], sb[1] + 16, '#ff9b8a', 11); }
      // 各面的压强箭头（长度 ∝ 压强）
      var kp = 3.2 * s / Q.pressure(1.2, LV);
      if (st.arrows) {
        for (var i = 0; i < 3; i++) {
          var xx = -a / 2 + a * (i + 0.5) / 3;
          var t = P(xx, yb + a), b = P(xx, yb);
          pArrow(t[0], t[1], 0, -1, f.pDown, kp, C.down);
          pArrow(b[0], b[1], 0, 1, f.pUp, kp, C.up);
        }
        for (var y = yb + 0.6; y < yb + a; y += (a - 1.2) / 3) {
          var dp = Q.sideP(info.rho, LV - y), l = P(-a / 2, y), r = P(a / 2, y);
          pArrow(l[0], l[1], -1, 0, dp, kp, rgba('#c9d2df', 0.75)); pArrow(r[0], r[1], 1, 0, dp, kp, rgba('#c9d2df', 0.75));
        }
      }
      // 合力：F向上、F向下、F浮（画在右侧）
      var kF = 4 * s / Math.max(Q.force(Q.pressure(1.2, LV), Q.CUBE.S), 1e-6);
      var rx = P(a / 2 + 3.2, 0)[0], top = P(0, yb + a)[1], bot = P(0, yb)[1];
      if (f.Fdown > 1e-4) { arrow(rx, top - f.Fdown * kF, rx, top, C.down, 3); tag('F向下 = ' + f2(f.Fdown) + ' N', rx + 8, top - Math.max(14, f.Fdown * kF * 0.6), C.down, 12, 'left'); }
      if (f.Fup > 1e-4) { arrow(rx, bot + f.Fup * kF, rx, bot, C.up, 3); tag('F向上 = ' + f2(f.Fup) + ' N', rx + 8, bot + Math.max(14, f.Fup * kF * 0.6), C.up, 12, 'left'); }
      // 合力（浮力）画在正方体中心
      var mid = P(0, yb + a / 2);
      if (Math.abs(f.Fb) > 1e-4) {
        var l2 = f.Fb * kF, cF = f.Fb > 0 ? C.Fb : '#ff9b8a';
        arrow(mid[0], mid[1], mid[0], mid[1] - l2, cF, 3.5);
        tag((f.Fb > 0 ? 'F浮 = ' : '向下的压力差 ') + f2(Math.abs(f.Fb)) + ' N', mid[0], mid[1] + (f.Fb > 0 ? 14 : -14), cF, 12);
      }
      // 深度标注：上、下表面
      var xs = x0 + 1.0;
      [[f.hb, yb, C.up, 'h下'], [f.ht, yb + a, C.down, 'h上']].forEach(function (r, i) {
        if (r[0] <= 0.15) return;
        var xq = xs + i * 1.6, pa = P(xq, LV), pb = P(xq, r[1]);
        ctx.strokeStyle = rgba(r[2], 0.5); ctx.setLineDash([3, 3]); ctx.lineWidth = 1; line(pb[0], pb[1], ca[0] - 2, pb[1]); ctx.setLineDash([]);
        arrow(pa[0], (pa[1] + pb[1]) / 2, pa[0], pa[1], r[2], 1.4, 6); arrow(pa[0], (pa[1] + pb[1]) / 2, pa[0], pb[1], r[2], 1.4, 6);
        text(r[3], pa[0] + 4, (pa[1] + pb[1]) / 2 + (i ? -10 : 10), r[2], 'left', 11, '600');
      });
      var lt = P(x1 - 0.6, LV - 1.2); text(Q.LIQUIDS[st.liquid].name + '  ρ = ' + f2(info.rho) + ' g/cm³', lt[0], lt[1], '#e6ebf2', 'right', 12, '600');
      var hint = f.hb < a + 3.2 ? P(0, yb - 3) : P(0, yb + a + 2.8); text('↕ 拖动正方体', hint[0], hint[1], C.muted, 'center', 11);
      causeGraph(st, info);
    }
    // F-h 图像：F向上、F向下、F浮 随下表面深度的变化
    function causeGraph(st, info) {
      var g = L.graph, pad = { l: 40, r: 12, t: 28, b: 30 };
      var x0 = g.x + pad.l, x1 = g.x + g.w - pad.r, y0 = g.y + g.h - pad.b, y1 = g.y + pad.t;
      var hMax = Q.CUBE.level, fMax = Math.ceil(Q.force(Q.pressure(info.rho, hMax), Q.CUBE.S) * 2) / 2;
      function X(h) { return x0 + (x1 - x0) * h / hMax; }
      function Y(F) { return y0 - (y0 - y1) * F / fMax; }
      panelBox(g, '各表面的压力与下表面深度 h下');
      ctx.strokeStyle = '#222b3b'; ctx.lineWidth = 1;
      var step = fMax > 4 ? 1 : 0.5;
      for (var F = 0; F <= fMax + 1e-9; F += step) { line(x0, Y(F), x1, Y(F)); text(String(+F.toFixed(1)), x0 - 5, Y(F), C.muted, 'right', 10); }
      for (var h = 0; h <= hMax; h += 5) { line(X(h), y0, X(h), y1); text(String(h), X(h), y0 + 10, C.muted, 'center', 10); }
      text('h下/cm', x1, y0 + 22, C.muted, 'right', 10); text('F/N', x0 - 5, y1 - 12, C.muted, 'right', 10);
      ctx.strokeStyle = '#46526a'; line(x0, y0, x1, y0); line(x0, y0, x0, y1);
      [['Fup', C.up], ['Fdown', C.down], ['Fb', C.Fb]].forEach(function (k) {
        ctx.strokeStyle = rgba(k[1], 0.85); ctx.lineWidth = 2; ctx.beginPath();
        for (var i = 0; i <= 200; i++) { var hh = hMax * i / 200, v = Q.faces(info.rho, hh, false)[k[0]]; var px = X(hh), py = Y(v); if (!i) ctx.moveTo(px, py); else ctx.lineTo(px, py); }
        ctx.stroke();
      });
      var hx = X(Q.CUBE.a); ctx.strokeStyle = 'rgba(255,201,74,0.35)'; ctx.setLineDash([2, 3]); ctx.lineWidth = 1; line(hx, y0, hx, y1); ctx.setLineDash([]);
      text('刚好浸没', hx + 3, y1 + 6, 'rgba(255,201,74,0.8)', 'left', 10);
      var f = info.f, ch = clamp(f.hb, 0, hMax);
      if (f.hb > 0) { dot(X(ch), Y(f.Fup), 4.5, C.up); dot(X(ch), Y(f.Fdown), 4.5, C.down); dot(X(ch), Y(Math.max(0, f.Fb)), 4.5, C.Fb); }
      var lx = x1 - 4, ly = y1 + 20;
      text('— F向上', lx, ly, C.up, 'right', 11, '600'); text('— F向下', lx, ly + 15, C.down, 'right', 11, '600'); text('— F浮', lx, ly + 30, C.Fb, 'right', 11, '600');
    }

    function draw(st, info) {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, W, H);
      var bg = ctx.createLinearGradient(0, 0, 0, H); bg.addColorStop(0, '#0a0f1b'); bg.addColorStop(1, '#05070d');
      ctx.fillStyle = bg; ctx.fillRect(0, 0, W, H);
      if (st.scene === 'probe') drawProbeScene(st, info);
      else if (st.scene === 'container') drawContainer(st, info);
      else drawCause(st, info);
    }

    // 命中检测：探头 / 正方体
    function hit(st, info, x, y) {
      if (!M) return null;
      var w = unP(x, y), tol = 16 / M.s;
      if (st.scene === 'probe') return Math.hypot(w[0] - st.px, w[1] - st.py) < Q.PROBE.r + 0.8 + tol ? 'probe' : null;
      if (st.scene === 'cause') {
        var a = Q.CUBE.a, yb = Q.CUBE.level - info.f.hb;
        return Math.abs(w[0]) < a / 2 + tol && w[1] > yb - tol && w[1] < yb + a + tol ? 'cube' : null;
      }
      return null;
    }

    return { resize: resize, draw: draw, hit: hit, unP: unP };
  }

  window.LiqDraw = LiqDraw;
})();
