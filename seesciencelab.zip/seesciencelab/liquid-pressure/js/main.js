(function () {
  var Q = window.LiqP;
  var $ = function (id) { return document.getElementById(id); };
  var qa = function (sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); };
  var NAME = '液体压强';
  var MAXROWS = 10;

  var SCENES = {
    probe: { name: '探究液体内部的压强', hint: '拖动探头改变深度和位置 · 看 U 形管两侧液面的高度差',
      note: '用微小压强计探究：橡皮膜受到的压强越大，U 形管两侧液面的高度差越大。控制变量，分别改变深度、橡皮膜的朝向和液体的种类。' },
    container: { name: '容器形状与底部压强', hint: '拖动滑块改变液体深度（或液体质量）· 比较三个容器底部的压强和压力',
      note: '三个容器底面积相同、形状不同。液体对容器底的压强 p = ρgh 只看深度，压力 F = pS 却不一定等于液体的重力。' },
    cause: { name: '浮力产生的原因', hint: '上下拖动正方体 · 看各个面受到的液体压力',
      note: '浸在液体中的物体，前后、左右两侧受到的压力互相抵消；下表面比上表面深，向上的压力大于向下的压力，这个压力差就是浮力。' }
  };
  var DIRN = { down: '朝下', side: '朝侧面', up: '朝上' };

  var state = {
    scene: 'probe', arrows: true, hover: null, dragging: false,
    liquid: 'water', tube: 'water', dir: 'down', px: 0, py: 12, leak: false, press: 0, dhShow: 0, data: [],
    mode: 'depth', ch: 10, cv: 180,
    hb: 8, stuck: false
  };
  var info = {};

  var stage = $('stage'), canvas = $('liq'), panel = $('panel');
  var view = window.LiqDraw(canvas);

  function setSeg(attr, val) { qa('[data-' + attr + ']').forEach(function (b) { b.classList.toggle('on', b.dataset[attr] === String(val)); }); }
  function fmt(v, d) { return (+v.toFixed(d == null ? 2 : d)).toString(); }
  function esc(s) { return String(s).replace(/[&<>]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]; }); }

  // 探头可以到达的范围：膜中心离杯壁、杯底留出金属盒的空间，最高可以提出液面
  function probeBounds() {
    var BK = Q.BEAKER, r = Q.PROBE.r + 0.3, t = Q.PROBE.t + 0.3, d = state.dir;
    return { x0: -BK.w / 2 + (d === 'side' ? 0.3 : r), x1: BK.w / 2 - r - (d === 'side' ? 2.2 : d === 'up' ? 1.6 : 0),
      y0: d === 'down' ? 0.3 : d === 'up' ? t + 1.2 : r, y1: BK.level + 3 };
  }
  function setProbe(x, y) {
    var b = probeBounds();
    state.px = Q.clamp(x, b.x0, b.x1); state.py = Q.clamp(y, b.y0, b.y1);
    update();
  }

  function compute() {
    var st = state, lq = Q.LIQUIDS[st.liquid];
    if (st.scene === 'probe') {
      var h = Q.BEAKER.level - st.py, gg = Q.gauge(lq.rho, h, Q.TUBE_LIQ[st.tube].rho, { leak: st.leak, press: st.press > 0 });
      info = { rho: lq.rho, h: Math.max(0, h), p: gg.p, pLiq: Q.pressure(lq.rho, h), dh: gg.dh, over: gg.over, target: gg.shown, dhShow: st.dhShow };
    } else if (st.scene === 'container') {
      info = { rho: lq.rho, vs: Object.keys(Q.SHAPES).map(function (id) {
        var h = st.mode === 'depth' ? st.ch : Q.depthOf(id, st.cv), v = Q.vessel(id, lq.rho, Math.min(h, Q.VESSEL.h));
        v.rho = lq.rho; v.over = h > Q.VESSEL.h + 1e-6; return v;
      }) };
    } else {
      var hb = st.stuck ? Q.CUBE.level : st.hb;
      info = { rho: lq.rho, f: Q.faces(lq.rho, hb, st.stuck) };
    }
  }
  function update() { compute(); syncPanel(); }

  // ---------- 记录数据（压强计） ----------
  function canRecord() {
    if (state.data.length >= MAXROWS) return '最多记录 ' + MAXROWS + ' 组，先清除数据';
    if (info.h < 0.05) return '探头还没有放进液体';
    if (state.leak) return '装置漏气，U 形管液面没有高度差，先排除漏气';
    if (state.press > 0) return '正在按压橡皮膜，松开后再记录';
    return '';
  }
  function record() {
    var why = canRecord();
    if (why) { flash(why); return; }
    var d = { lid: state.liquid, liq: Q.LIQUIDS[state.liquid].name, h: +info.h.toFixed(1), dir: state.dir, dh: +info.dh.toFixed(1), p: info.pLiq, tube: state.tube };
    var last = state.data[state.data.length - 1];
    if (last && JSON.stringify(last) === JSON.stringify(d)) { flash('和上一组一样，改变深度、方向或液体再记录'); return; }
    state.data.push(d);
    Analytics.track(NAME, '记录数据', d.liq + d.h + 'cm' + DIRN[d.dir]);
    syncPanel();
  }
  var flashT = 0;
  function flash(msg) { $('recMsg').textContent = msg; clearTimeout(flashT); flashT = setTimeout(function () { $('recMsg').textContent = ''; }, 2600); }

  function summary(d) {
    var s = [], eq = function (a, b) { return Math.abs(a - b) < 0.05; };
    if (!d.length) return '';
    function pair(test) { for (var i = 0; i < d.length; i++) for (var j = i + 1; j < d.length; j++) if (test(d[i], d[j])) return [d[i], d[j]]; return null; }
    var p;
    if ((p = pair(function (a, b) { return a.lid === b.lid && a.tube === b.tube && eq(a.h, b.h) && a.dir !== b.dir; })))
      s.push('<p>同种液体、同一深度（' + p[0].h + ' cm），橡皮膜' + DIRN[p[0].dir] + '和' + DIRN[p[1].dir] + '时 Δh 都是 ' + p[0].dh + ' cm：<b>在液体内部的同一深度，向各个方向的压强都相等</b>。</p>');
    if ((p = pair(function (a, b) { return a.lid === b.lid && a.tube === b.tube && a.h !== b.h; }))) {
      var lo = p[0].h < p[1].h ? p[0] : p[1], hi = lo === p[0] ? p[1] : p[0];
      s.push('<p>同种液体中，深度 ' + lo.h + ' cm 时 Δh = ' + lo.dh + ' cm，' + hi.h + ' cm 时 Δh = ' + hi.dh + ' cm：<b>深度越深，压强越大</b>。</p>');
    }
    if ((p = pair(function (a, b) { return a.lid !== b.lid && a.tube === b.tube && eq(a.h, b.h); }))) {
      var l1 = Q.LIQUIDS[p[0].lid].rho < Q.LIQUIDS[p[1].lid].rho ? p[0] : p[1], l2 = l1 === p[0] ? p[1] : p[0];
      s.push('<p>深度相同（' + l1.h + ' cm），' + l1.liq + '中 Δh = ' + l1.dh + ' cm，' + l2.liq + '中 Δh = ' + l2.dh + ' cm：<b>深度相同时，液体的密度越大，压强越大</b>。</p>');
    }
    if ((p = pair(function (a, b) { return a.tube !== b.tube && a.lid === b.lid && eq(a.h, b.h); })))
      s.push('<p>压强相同时，U 形管里换成密度更小的液体，Δh 变大（' + p[0].dh + ' cm、' + p[1].dh + ' cm），现象更明显。</p>');
    if (!s.length) s.push('<p class="muted">控制变量：只改变深度、橡皮膜方向或液体中的一个，多记录几组再比较。</p>');
    return s.join('');
  }

  // ---------- 读数、提示 ----------
  function notes() {
    var n = [], st = state, warn = false;
    if (st.scene === 'probe') {
      var tl = Q.TUBE_LIQ[st.tube];
      if (st.leak) { warn = true; n.push('装置漏气：管内气体与外界相通，橡皮膜受到压强时 U 形管两侧液面仍然相平。用手指按压橡皮膜，液面几乎不动，说明漏气，要拆下软管重新安装。'); }
      else if (st.press > 0) n.push('用手指按压橡皮膜：U 形管液面出现明显高度差，并且松手后能恢复，说明装置不漏气。');
      if (info.h < 0.05) n.push('探头在液面以上：橡皮膜只受大气压，U 形管两侧液面相平。把探头放进液体里。');
      else {
        n.push('p = ρ液 g h = ' + fmt(info.rho * 1000, 0) + ' kg/m³ × 10 N/kg × ' + fmt(info.h / 100, 3) + ' m = ' + fmt(info.pLiq, 0) + ' Pa。');
        if (!st.leak && !(st.press > 0)) n.push('U 形管两侧液面高度差 Δh = p /（ρ管液 g）= ' + fmt(info.dh, 1) + ' cm（' + tl.name + ' ' + tl.rho + ' g/cm³）' +
          (st.tube === 'water' && st.liquid === 'water' ? '，正好等于探头的深度。' : '。'));
        n.push('橡皮膜' + DIRN[st.dir] + '。保持深度不变只转动方向，Δh 不变：同一深度各个方向的压强相等。');
      }
      if (info.over) { warn = true; n.push('压强太大，U 形管里的液体会溢出：实际使用时探头不能放得太深。'); }
    } else if (st.scene === 'container') {
      var v = info.vs;
      if (st.mode === 'depth') n.push('液体深度相同，三个容器底部受到的压强都是 p = ρgh = ' + fmt(v[0].p, 0) + ' Pa，压力都是 F = pS = ' + fmt(v[0].F) + ' N——与容器的形状、液体的多少无关。');
      else {
        n.push('液体质量相同（' + fmt(st.cv * info.rho, 0) + ' g，重 ' + fmt(v[0].G) + ' N）：缩口容器液面最高、压强最大，敞口容器液面最低、压强最小。');
        if (v.some(function (x) { return x.over; })) { warn = true; n.push('有的容器装不下这么多液体，已装满到 16 cm。'); }
      }
      n.push('柱形容器 F = G液；敞口容器侧壁向外倾斜，液体有一部分重力压在侧壁上，F < G液；缩口容器侧壁对液体有向下的压力，F > G液。');
      n.push('求液体对容器底的压力，先用 p = ρgh 求压强，再用 F = pS 求压力，不能直接用 F = G液（柱形容器除外）。');
    } else {
      var f = info.f, a = Q.CUBE.a;
      if (f.hb <= 0) n.push('正方体在液面以上，不受液体的压力。向下拖动正方体。');
      else if (st.stuck) { warn = true; n.push('下表面与容器底紧密接触，下面没有液体，不受向上的压力，只有向下的压力 ' + fmt(f.Fdown) + ' N——这时不受浮力，像桥墩、陷入淤泥的物体那样。'); }
      else if (!f.submerged) n.push('部分浸入：上表面不受液体压力，F浮 = F向上 = p下 S = ' + fmt(f.pUp, 0) + ' Pa × ' + Q.CUBE.S + ' cm² = ' + fmt(f.Fb) + ' N，浸入越深浮力越大。');
      else n.push('浸没：F浮 = F向上 − F向下 = ' + fmt(f.Fup) + ' N − ' + fmt(f.Fdown) + ' N = ' + fmt(f.Fb) + ' N。下表面总比上表面深 ' + a + ' cm，所以压力差不随深度变化。');
      if (f.hb > 0 && !st.stuck) n.push('F浮 = ρ液 g V排 = ' + fmt(info.rho * 1000, 0) + ' kg/m³ × 10 N/kg × ' + fmt(f.Vsub, 0) + '×10⁻⁶ m³ = ' + fmt(f.Fb) + ' N，与压力差算出的相同。');
      if (f.hb > 0) n.push('左右（前后）两个侧面在同一深度受到的压强相等、方向相反，压力互相抵消。');
    }
    return { list: n, warn: warn };
  }

  function syncPanel() {
    var st = state, sc = SCENES[st.scene], big = '', dl = [];
    setSeg('scene', st.scene); setSeg('liquid', st.liquid); setSeg('dir', st.dir); setSeg('tube', st.tube); setSeg('mode', st.mode);
    qa('[data-for]').forEach(function (el) { el.hidden = el.dataset.for.split(' ').indexOf(st.scene) < 0; });
    if (st.scene === 'probe') {
      big = '<span class="pp">p = <b>' + fmt(info.pLiq, 0) + '</b> Pa</span><span class="dh">Δh = <b>' + fmt(st.leak ? 0 : info.dh, 1) + '</b> cm</span>';
      dl = [['液体', Q.LIQUIDS[st.liquid].name + '（' + fmt(info.rho) + ' g/cm³）'], ['探头深度 h', fmt(info.h, 1) + ' cm'], ['橡皮膜朝向', DIRN[st.dir]],
        ['U 形管内', Q.TUBE_LIQ[st.tube].name + '（' + Q.TUBE_LIQ[st.tube].rho + ' g/cm³）']];
    } else if (st.scene === 'container') {
      var v = info.vs;
      big = '<span class="pp">S = <b>' + Q.VESSEL.S + '</b> cm²</span><span class="dh">' + (st.mode === 'depth' ? '等深度 h = <b>' + fmt(st.ch, 1) + '</b> cm' : '等质量 m = <b>' + fmt(st.cv * info.rho, 0) + '</b> g') + '</span>';
      dl = v.map(function (x) { return [Q.SHAPES[x.id].short || Q.SHAPES[x.id].name, 'h ' + fmt(x.h, 1) + ' cm · p ' + fmt(x.p, 0) + ' Pa · F ' + fmt(x.F) + ' N · G液 ' + fmt(x.G) + ' N']; });
    } else {
      var f = info.f;
      big = '<span class="fb">F浮 = <b>' + fmt(Math.max(0, f.Fb)) + '</b> N</span>';
      dl = [['下表面深度 h下', fmt(Math.max(0, f.hb), 1) + ' cm'], ['上表面深度 h上', fmt(Math.max(0, f.ht), 1) + ' cm'],
        ['向上的压力 F向上', fmt(f.pUp, 0) + ' Pa × 25 cm² = ' + fmt(f.Fup) + ' N'], ['向下的压力 F向下', fmt(f.pDown, 0) + ' Pa × 25 cm² = ' + fmt(f.Fdown) + ' N'],
        ['压力差 F向上 − F向下', fmt(f.Fb) + ' N']];
    }
    $('rBig').innerHTML = big;
    $('rDl').innerHTML = dl.map(function (d) { return '<dt>' + d[0] + '</dt><dd>' + d[1] + '</dd>'; }).join('');
    var nn = notes();
    $('rNotes').innerHTML = nn.list.map(function (t) { return '<li>' + esc(t) + '</li>'; }).join('');
    $('rNotes').hidden = !nn.list.length;
    $('rNotes').className = nn.warn ? 'warn' : '';
    $('sceneNote').textContent = sc.note;
    $('hint').textContent = sc.hint;
    $('hRange').value = Math.round(info.h ? info.h * 10 : 0); $('hOut').textContent = fmt(info.h || 0, 1) + ' cm';
    $('leak').checked = st.leak; $('showArrows').checked = st.arrows; $('stuck').checked = st.stuck;
    $('chRange').value = Math.round(st.ch * 10); $('chOut').textContent = fmt(st.ch, 1) + ' cm';
    $('cvRange').value = Math.round(st.cv); $('cvOut').textContent = fmt(st.cv, 0) + ' cm³';
    $('chRow').hidden = st.mode !== 'depth'; $('cvRow').hidden = st.mode !== 'mass';
    $('hbRange').value = Math.round(Math.max(-3, st.stuck ? Q.CUBE.level : st.hb) * 10); $('hbOut').textContent = fmt(st.stuck ? Q.CUBE.level : st.hb, 1) + ' cm';
    if (st.scene === 'probe') syncTable();
  }
  function syncTable() {
    var d = state.data;
    var head = '<th>#</th><th>液体</th><th>h/cm</th><th>朝向</th><th>Δh/cm</th><th>p/Pa</th>';
    var rows = d.map(function (r, i) {
      return '<tr><td>' + (i + 1) + '</td><td>' + r.liq + '</td><td>' + r.h + '</td><td>' + DIRN[r.dir].replace('朝', '') + '</td><td>' + r.dh + (r.tube === 'water' ? '' : '*') + '</td><td>' + fmt(r.p, 0) + '</td></tr>';
    });
    $('dataTable').innerHTML = '<thead><tr>' + head + '</tr></thead><tbody>' + (rows.length ? rows.join('') : '<tr><td colspan="6" class="muted">还没有数据</td></tr>') + '</tbody>';
    $('dataSum').innerHTML = (d.some(function (r) { return r.tube !== 'water'; }) ? '<p class="muted">* U 形管内为染色酒精</p>' : '') + summary(d);
  }

  // ---------- 场景 ----------
  function loadScene(name) {
    state.scene = SCENES[name] ? name : 'probe';
    state.hover = null; state.dragging = false;
    update();
  }
  function setDir(d) {
    var h = Q.BEAKER.level - state.py;   // 转动方向时保持膜中心的深度
    state.dir = Q.DIRS[d] ? d : 'down';
    setProbe(state.px, Q.BEAKER.level - h);
  }

  // ---------- 画布交互 ----------
  var drag = null;
  function pos(e) { var r = canvas.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; }
  canvas.addEventListener('pointerdown', function (e) {
    var p = pos(e), h = view.hit(state, info, p[0], p[1]);
    if (!h) return;
    var w = view.unP(p[0], p[1]);
    drag = h === 'probe' ? { kind: h, x0: w[0], y0: w[1], px: state.px, py: state.py } : { kind: h, y0: w[1], hb: info.f.hb };
    if (h === 'cube') state.stuck = false;
    state.dragging = true;
    try { canvas.setPointerCapture(e.pointerId); } catch (err) {}
    e.preventDefault();
  });
  canvas.addEventListener('pointermove', function (e) {
    var p = pos(e), w = view.unP(p[0], p[1]);
    if (drag) {
      if (drag.kind === 'probe') setProbe(drag.px + w[0] - drag.x0, drag.py + w[1] - drag.y0);
      else { state.hb = Q.clamp(drag.hb - (w[1] - drag.y0), -3, Q.CUBE.level); update(); }
      return;
    }
    state.hover = view.hit(state, info, p[0], p[1]);
    canvas.style.cursor = state.hover ? (state.hover === 'probe' ? 'move' : 'ns-resize') : 'default';
  });
  function up() {
    if (!drag) return;
    var k = drag.kind; drag = null; state.dragging = false;
    Analytics.track(NAME, k === 'probe' ? '拖动探头' : '拖动正方体', Q.LIQUIDS[state.liquid].name);
    update();
  }
  canvas.addEventListener('pointerup', up);
  canvas.addEventListener('pointercancel', up);
  canvas.addEventListener('pointerleave', function () { if (!drag) state.hover = null; });

  // ---------- 面板控件 ----------
  qa('[data-scene]').forEach(function (b) { b.addEventListener('click', function () { loadScene(b.dataset.scene); Analytics.track(NAME, '场景', SCENES[state.scene].name); }); });
  qa('[data-liquid]').forEach(function (b) { b.addEventListener('click', function () { state.liquid = b.dataset.liquid; update(); Analytics.track(NAME, '液体', b.textContent); }); });
  qa('[data-dir]').forEach(function (b) { b.addEventListener('click', function () { setDir(b.dataset.dir); Analytics.track(NAME, '橡皮膜朝向', b.textContent); }); });
  qa('[data-tube]').forEach(function (b) { b.addEventListener('click', function () { state.tube = b.dataset.tube; update(); Analytics.track(NAME, 'U形管液体', b.textContent); }); });
  qa('[data-mode]').forEach(function (b) { b.addEventListener('click', function () { state.mode = b.dataset.mode; update(); Analytics.track(NAME, '容器比较', b.textContent); }); });
  $('hRange').addEventListener('input', function () { setProbe(state.px, Q.BEAKER.level - $('hRange').value / 10); });
  $('leak').addEventListener('change', function () { state.leak = $('leak').checked; update(); Analytics.track(NAME, '漏气', String(state.leak)); });
  $('pressBtn').addEventListener('click', function () { state.press = 1.6; update(); Analytics.track(NAME, '按压橡皮膜'); });
  $('recBtn').addEventListener('click', record);
  $('clearBtn').addEventListener('click', function () { state.data.length = 0; syncPanel(); Analytics.track(NAME, '清除数据'); });
  $('chRange').addEventListener('input', function () { state.ch = $('chRange').value / 10; update(); });
  $('cvRange').addEventListener('input', function () { state.cv = +$('cvRange').value; update(); });
  $('hbRange').addEventListener('input', function () { state.stuck = false; state.hb = $('hbRange').value / 10; update(); });
  $('stuck').addEventListener('change', function () { state.stuck = $('stuck').checked; if (!state.stuck) state.hb = Q.CUBE.level - 0.5; update(); Analytics.track(NAME, '紧贴容器底', String(state.stuck)); });
  $('showArrows').addEventListener('change', function () { state.arrows = $('showArrows').checked; });

  // ---------- 面板开合 ----------
  $('panelToggle').addEventListener('click', function () { panel.classList.toggle('collapsed'); });
  if (window.matchMedia('(max-width: 760px)').matches) panel.classList.add('collapsed');

  function resize() { view.resize(stage.clientWidth, stage.clientHeight); }
  new ResizeObserver(resize).observe(stage);
  resize();

  // 演示数据：水中 5、10、15 cm 朝下，10 cm 朝侧面、朝上，再换盐水 10 cm
  function demo() {
    function at(lid, h, dir) { state.liquid = lid; state.dir = dir; setProbe(0, Q.BEAKER.level - h); compute(); record(); }
    at('water', 5, 'down'); at('water', 10, 'down'); at('water', 15, 'down'); at('water', 10, 'side'); at('water', 10, 'up'); at('salt', 10, 'down');
    state.liquid = 'water'; state.dir = 'down'; setProbe(0, Q.BEAKER.level - 10);
  }

  // 支持 ?scene=probe|container|cause、&liquid=alcohol|water|salt、&arrows=0；
  // 压强计 &h=深度（cm）、&dir=down|side|up、&tube=water|alcohol、&leak=1、&demo=1；
  // 容器 &mode=depth|mass、&h=深度、&v=液体体积（cm³）；浮力 &h=下表面深度、&stuck=1
  var qs = new URLSearchParams(location.search), qh = qs.get('h');
  if (Q.LIQUIDS[qs.get('liquid')]) state.liquid = qs.get('liquid');
  if (Q.TUBE_LIQ[qs.get('tube')]) state.tube = qs.get('tube');
  if (Q.DIRS[qs.get('dir')]) state.dir = qs.get('dir');
  if (qs.get('leak') === '1') state.leak = true;
  if (qs.get('arrows') === '0') state.arrows = false;
  if (qs.get('mode') === 'mass') state.mode = 'mass';
  if (qs.get('v') != null && isFinite(+qs.get('v'))) state.cv = Q.clamp(+qs.get('v'), 30, 260);
  if (qs.get('stuck') === '1') state.stuck = true;
  state.scene = SCENES[qs.get('scene')] ? qs.get('scene') : 'probe';
  var hasH = qh != null && qh !== '' && isFinite(+qh);
  if (state.scene === 'probe') {
    if (qs.get('demo') === '1') demo();
    setProbe(0, Q.BEAKER.level - (hasH ? +qh : 10));
  } else if (state.scene === 'container') { if (hasH) state.ch = Q.clamp(+qh, 0, 15); }
  else if (hasH) state.hb = Q.clamp(+qh, -3, Q.CUBE.level);
  loadScene(state.scene);
  state.dhShow = info.target || 0;

  var lastT = performance.now();
  function frame(t) {
    var dt = Math.min((t - lastT) / 1000, 0.05);
    lastT = t;
    if (state.scene === 'probe') {
      if (state.press > 0) { state.press -= dt; if (state.press <= 0) { state.press = 0; update(); } }
      var tg = info.target, d = tg - state.dhShow;
      state.dhShow = Math.abs(d) > 0.005 ? state.dhShow + d * Math.min(1, dt * 6) : tg;
      info.dhShow = state.dhShow;
    }
    view.draw(state, info);
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // 调试用
  window.__model = { state: state, info: function () { return info; }, view: view, LiqP: Q, load: loadScene, update: update, setProbe: setProbe, setDir: setDir, record: record, demo: demo };
})();
