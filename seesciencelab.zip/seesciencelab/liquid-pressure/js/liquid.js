// 液体压强计算：p = ρgh、U 形管压强计液面高度差、不同形状容器底部的压强与压力、浮力产生的原因（上下表面压力差）
// 单位：长度 cm、面积 cm²、体积 cm³、密度 g/cm³、压强 Pa、力 N，取 g = 10 N/kg
// 换算：p = ρ(×1000 kg/m³) · 10 N/kg · h(÷100 m) = 100ρh Pa；F = pS(÷10⁴ m²)；G = ρV(÷1000 kg) · 10
(function () {
  var GK = 10;

  var LIQUIDS = {
    alcohol: { name: '酒精', rho: 0.8, color: '#9fd8ff' },
    water: { name: '水', rho: 1.0, color: '#4fa8e8' },
    salt: { name: '盐水', rho: 1.2, color: '#5fc4c0' }
  };
  // U 形管里装的液体（染色），密度越小，同样的压强差对应的液面高度差越大
  var TUBE_LIQ = {
    water: { name: '红墨水', rho: 1.0, color: '#ff5a5a' },
    alcohol: { name: '染色酒精', rho: 0.8, color: '#ff8a3d' }
  };

  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
  // 液体内部深度 h（cm）处的压强（Pa）；h ≤ 0 为液面以上，压强（不计大气压）为 0
  function pressure(rho, h) { return h > 0 ? 100 * rho * GK / 10 * h : 0; }
  function force(p, S) { return p * S / 1e4; }                 // 压力 F = pS（N）
  function weight(rho, V) { return rho * V * GK / 1000; }      // 液体重 G = ρgV（N）

  // ---------- 压强计 ----------
  // 大烧杯：内宽 20 cm、深 24 cm，液面高 20 cm（探头很小，液面升高忽略）
  var BEAKER = { w: 20, h: 24, level: 20 };
  // 探头（金属盒 + 橡皮膜）：膜的半径 1.4 cm，盒厚 1 cm；深度 h 指橡皮膜中心到液面的竖直距离
  var PROBE = { r: 1.4, t: 1.0 };
  var DIRS = { down: { name: '朝下', n: [0, -1] }, side: { name: '朝侧面', n: [-1, 0] }, up: { name: '朝上', n: [0, 1] } };
  // U 形管：两臂高 30 cm，原来两侧液面在 14 cm 处，最多各升降 14 cm（超出就溢出）
  var UTUBE = { h: 30, base: 14, max: 14 };
  var PRESS_PA = 600;   // 用手指按压橡皮膜相当于增加的压强（检查气密性）

  // 压强差 → U 形管两侧液面高度差：p = ρ管液 g Δh
  function deltaH(p, rhoTube) { return p / (100 * rhoTube * GK / 10); }
  // 压强计读数：漏气时管内气体和外界相通，橡皮膜受压，U 形管液面也不出现高度差
  function gauge(rhoL, h, rhoTube, opt) {
    opt = opt || {};
    var p = pressure(rhoL, h) + (opt.press ? PRESS_PA : 0);
    var dh = opt.leak ? 0 : deltaH(p, rhoTube), over = dh / 2 > UTUBE.max;
    return { p: p, dh: dh, shown: Math.min(dh, 2 * UTUBE.max), over: over };
  }

  // ---------- 容器形状 ----------
  // 三个圆台形容器，底面积都是 S、高 16 cm；k 为口部半径与底面半径之比
  var VESSEL = { S: 30, h: 16 };
  VESSEL.r0 = Math.sqrt(VESSEL.S / Math.PI);
  var SHAPES = {
    cyl: { name: '柱形', k: 1 },
    open: { name: '敞口（上宽下窄）', short: '敞口', k: 2 },
    narrow: { name: '缩口（上窄下宽）', short: '缩口', k: 0.45 }
  };
  // 深度 y 处的半径与 0~h 的液体体积（圆台：V = πh(R₀² + R₀R + R²)/3）
  function radius(id, y) { return VESSEL.r0 * (1 + (SHAPES[id].k - 1) * y / VESSEL.h); }
  function volume(id, h) {
    var R0 = VESSEL.r0, R = radius(id, h);
    return Math.PI * h * (R0 * R0 + R0 * R + R * R) / 3;
  }
  // 给定液体体积求液面高度（二分）
  function depthOf(id, V) {
    var lo = 0, hi = VESSEL.h * 1.5;
    for (var i = 0; i < 60; i++) { var m = (lo + hi) / 2; if (volume(id, m) < V) lo = m; else hi = m; }
    return (lo + hi) / 2;
  }
  // 容器底部：压强 p = ρgh（只与深度有关），压力 F = pS；与液体重 G 比较——柱形 F = G，敞口 F < G，缩口 F > G
  function vessel(id, rho, h) {
    var p = pressure(rho, h), F = force(p, VESSEL.S), V = volume(id, h), G = weight(rho, V);
    return { id: id, h: h, p: p, F: F, V: V, G: G, cmp: Math.abs(F - G) < 1e-6 ? 0 : F > G ? 1 : -1 };
  }

  // ---------- 浮力产生的原因 ----------
  // 正方体棱长 5 cm（上下表面积 25 cm²），浸在液面高 20 cm 的大容器里（容器很大，液面升高忽略）
  var CUBE = { a: 5, level: 20 };
  CUBE.S = CUBE.a * CUBE.a; CUBE.V = CUBE.S * CUBE.a;
  // hb：下表面在液面下的深度。上表面深度 hb − a。stuck：下表面与容器底紧密接触（下表面没有液体）
  function faces(rho, hb, stuck) {
    var a = CUBE.a, ht = hb - a;
    var pUp = stuck ? 0 : pressure(rho, hb), pDown = pressure(rho, ht);
    var Fup = force(pUp, CUBE.S), Fdown = force(pDown, CUBE.S);
    return { hb: hb, ht: ht, pUp: pUp, pDown: pDown, Fup: Fup, Fdown: Fdown, Fb: Fup - Fdown,
      Vsub: CUBE.S * clamp(hb, 0, a), submerged: hb >= a };
  }
  // 侧面（左右、前后）深度 y 处的压强：两侧大小相等、方向相反，合力为零
  function sideP(rho, depth) { return pressure(rho, depth); }

  window.LiqP = {
    GK: GK, LIQUIDS: LIQUIDS, TUBE_LIQ: TUBE_LIQ, BEAKER: BEAKER, PROBE: PROBE, DIRS: DIRS, UTUBE: UTUBE, PRESS_PA: PRESS_PA,
    VESSEL: VESSEL, SHAPES: SHAPES, CUBE: CUBE,
    clamp: clamp, pressure: pressure, force: force, weight: weight, deltaH: deltaH, gauge: gauge,
    radius: radius, volume: volume, depthOf: depthOf, vessel: vessel, faces: faces, sideP: sideP
  };
})();
