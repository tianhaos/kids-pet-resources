// 等高线地形图：地形高度场生成、采样、等高线提取（marching squares）、剖面与通视（纯计算，2D/3D 共用）
// 坐标：u 向东、v 向北，均 ∈ [-1, 1]，对应实地 4 km × 4 km；高度单位 m。
(function () {
  var N = 161;                       // 每边网格点数
  var WIDTH_M = 4000;                // 地图边长（m）
  var M_PER_UNIT = WIDTH_M / 2;      // u/v 每 1 单位对应的米数
  var HMAX = 1400;                   // 堆山时的高度上限
  var D = Math.PI / 180;

  function ucoord(i) { return -1 + 2 * i / (N - 1); }

  // ---------- 造型函数 ----------
  // 低频确定性起伏，让等高线不那么"规整"
  function noise(u, v) {
    return Math.sin(2.3 * u + 1.1 * v + 0.7) * 0.5 + Math.sin(-1.7 * u + 2.9 * v + 2.1) * 0.35 +
      Math.sin(4.1 * u - 3.3 * v + 4.0) * 0.15;
  }
  function gauss(dx, dy, sx, sy) { return Math.exp(-(dx * dx) / (2 * sx * sx) - (dy * dy) / (2 * sy * sy)); }
  function step(x, w) { return 1 / (1 + Math.exp(-x / w)); }
  // 花瓣形山体：半径随方位角起伏，凸出的方向是山脊、凹进的方向是山谷
  function lobed(u, v, c) {
    var dx = u - c.x, dy = v - c.y, r2 = dx * dx + dy * dy;
    var th = Math.atan2(dy, dx);
    var s = c.s * (1 + (c.a || 0) * Math.cos((c.n || 0) * (th - (c.phi || 0))) + (c.b || 0) * Math.cos(th - (c.bphi || 0)));
    return c.H * Math.exp(-r2 / (2 * s * s));
  }
  // 点到折线的距离
  function distToLine(u, v, line) {
    var best = Infinity;
    for (var k = 0; k < line.length - 1; k++) {
      var ax = line[k][0], ay = line[k][1], bx = line[k + 1][0] - ax, by = line[k + 1][1] - ay;
      var t = Math.max(0, Math.min(1, ((u - ax) * bx + (v - ay) * by) / (bx * bx + by * by)));
      var dx = u - ax - t * bx, dy = v - ay - t * by, d = dx * dx + dy * dy;
      if (d < best) best = d;
    }
    return Math.sqrt(best);
  }
  // 从山体中心沿某方位角的一段轴线（画山脊线、山谷线用）
  function axis(c, deg, r0, r1) {
    var a = deg * D, pts = [];
    for (var k = 0; k <= 8; k++) {
      var r = r0 + (r1 - r0) * k / 8;
      pts.push([c.x + r * Math.cos(a), c.y + r * Math.sin(a)]);
    }
    return pts;
  }
  function onAxis(c, deg, r) { return [c.x + r * Math.cos(deg * D), c.y + r * Math.sin(deg * D)]; }

  // ---------- 预设地形 ----------
  // feats：地形部位。peak/basin/saddle 给出 near（在附近自动搜索精确位置），
  // ridge/valley/cliff 给出 line；q 为判读练习时的提问点。
  var PRESETS = {};

  (function () {
    var A = { x: -0.34, y: 0.24, H: 820, s: 0.30, n: 3, a: 0.3, phi: -140 * D };
    var B = { x: 0.42, y: -0.06, H: 600, s: 0.2 };
    var river = [onAxis(A, -80, 0.2), onAxis(A, -80, 0.45), [-0.2, -0.55], [-0.13, -0.8], [-0.1, -1.02]];
    PRESETS.composite = {
      name: '综合地形', desc: '两座山峰、鞍部、山脊、山谷、陡崖和河流',
      height: function (u, v) {
        var b = 115 + 40 * v - 25 * u + 12 * noise(u, v);
        var hb = 600 * gauss(u - B.x, v - B.y, B.s, B.s) * (0.12 + 0.88 * (1 - step(u - 0.55, 0.006)));
        var ch = 30 * Math.exp(-Math.pow(distToLine(u, v, river) / 0.035, 2));
        return b + lobed(u, v, A) + hb - ch;
      },
      rivers: [river],
      feats: [
        { type: 'peak', near: [A.x, A.y] },
        { type: 'peak', near: [B.x, B.y] },
        { type: 'saddle', near: [0.07, 0.08] },
        { type: 'ridge', line: axis(A, -140, 0.18, 0.78), q: onAxis(A, -140, 0.45) },
        { type: 'ridge', line: axis(A, 100, 0.18, 0.62), q: onAxis(A, 100, 0.4) },
        { type: 'valley', line: axis(A, -80, 0.16, 0.6), q: onAxis(A, -80, 0.38) },
        { type: 'valley', line: axis(A, 160, 0.16, 0.62), q: onAxis(A, 160, 0.4) },
        { type: 'cliff', line: [[0.55, -0.22], [0.55, 0.1]], q: [0.55, -0.06] }
      ]
    };
  })();

  (function () {
    var C = { x: -0.28, y: 0.05 };
    PRESETS.slope = {
      name: '山峰：陡坡与缓坡', desc: '同一座山，西坡陡、东坡缓',
      height: function (u, v) {
        var dx = u - C.x, dy = v - C.y;
        var sx = dx < 0 ? 0.2 : 0.62;
        return 60 + 20 * v + 10 * noise(u, v) + 720 * gauss(dx, dy, sx, 0.3);
      },
      rivers: [],
      feats: [
        { type: 'peak', near: [C.x, C.y] },
        { type: 'steep', q: [C.x - 0.24, C.y + 0.02], line: [[C.x - 0.13, C.y], [C.x - 0.38, C.y]] },
        { type: 'gentle', q: [C.x + 0.55, C.y + 0.02], line: [[C.x + 0.2, C.y], [C.x + 0.95, C.y]] }
      ]
    };
  })();

  (function () {
    var M = { x: -0.04, y: 0.06, H: 800, s: 0.33, n: 4, a: 0.3, phi: 45 * D, b: 0.12, bphi: -30 * D };
    var feats = [{ type: 'peak', near: [M.x, M.y] }], rivers = [];
    [45, 135, 225, 315].forEach(function (deg) {
      feats.push({ type: 'ridge', line: axis(M, deg, 0.16, 0.8), q: onAxis(M, deg, 0.48) });
    });
    [0, 90, 180, 270].forEach(function (deg) {
      feats.push({ type: 'valley', line: axis(M, deg, 0.14, 0.5), q: onAxis(M, deg, 0.34) });
      rivers.push(axis(M, deg, 0.5, 1.2));
    });
    PRESETS.spur = {
      name: '山脊与山谷', desc: '山脊向四周伸出，山脊之间是山谷',
      height: function (u, v) { return 60 + 10 * noise(u, v) + lobed(u, v, M); },
      rivers: rivers, feats: feats
    };
  })();

  (function () {
    var P1 = { x: -0.42, y: 0.1 }, P2 = { x: 0.4, y: -0.04 };
    PRESETS.saddle = {
      name: '鞍部', desc: '两座山顶之间的低洼处，形似马鞍',
      height: function (u, v) {
        return 90 + 15 * v + 10 * noise(u, v) + 760 * gauss(u - P1.x, v - P1.y, 0.26, 0.3) +
          640 * gauss(u - P2.x, v - P2.y, 0.24, 0.27);
      },
      rivers: [],
      feats: [
        { type: 'peak', near: [P1.x, P1.y] },
        { type: 'peak', near: [P2.x, P2.y] },
        { type: 'saddle', near: [0, 0.03] }
      ]
    };
  })();

  (function () {
    PRESETS.cliff = {
      name: '陡崖', desc: '台地南侧是近乎垂直的陡崖',
      height: function (u, v) {
        var top = 520 * Math.exp(-Math.pow(u / 0.5, 4)) * step(v + 0.25, 0.005) *
          (v > 0.12 ? Math.exp(-Math.pow((v - 0.12) / 0.4, 2)) : 1);
        return 60 + 20 * v + 10 * noise(u, v) + top + 180 * gauss(u + 0.05, v - 0.2, 0.16, 0.16) * step(v + 0.25, 0.005);
      },
      rivers: [[[-1.02, -0.5], [-0.5, -0.45], [0, -0.48], [0.5, -0.44], [1.02, -0.5]]],
      feats: [
        { type: 'peak', near: [-0.05, 0.2] },
        { type: 'cliff', line: [[-0.38, -0.25], [0.38, -0.25]], q: [0.08, -0.25] },
        { type: 'gentle', q: [0.1, 0.62], line: [[0.1, 0.4], [0.1, 0.85]] }
      ]
    };
  })();

  (function () {
    PRESETS.basin = {
      name: '盆地', desc: '四周高、中间低，等高线闭合',
      height: function (u, v) {
        // 圈内是平滑的碗底（中心坡度为 0），圈外向平原缓降
        var r = Math.hypot(u, v), th = Math.atan2(v, u);
        var R = 0.46 * (1 + 0.08 * Math.cos(3 * th + 1));
        var top = 650 * (1 + 0.16 * Math.cos(2 * th - 0.6)), floor = 250, x = r / R;
        var f = x < 1 ? floor + (top - floor) * x * x * (3 - 2 * x) : 60 + (top - 60) * Math.exp(-Math.pow(r - R, 2) / (2 * 0.2 * 0.2));
        return f + 10 * noise(u, v);
      },
      rivers: [],
      feats: [
        { type: 'basin', near: [0, 0], q: [0, 0] },
        { type: 'peak', near: [0.43, 0.13] }
      ]
    };
  })();

  PRESETS.blank = {
    name: '平原（自己堆山）', desc: '选「堆山」「挖谷」工具，在平面图上拖动塑造地形',
    height: function (u, v) { return 40 + 15 * v + 6 * noise(u, v); },
    rivers: [], feats: []
  };

  var ORDER = ['composite', 'slope', 'spur', 'saddle', 'cliff', 'basin', 'blank'];

  // 地形部位：名称与判读要点
  var FEAT = {
    peak:   { name: '山顶', rule: '等高线闭合，数值中间高、四周低，常用 ▲ 标出海拔。' },
    ridge:  { name: '山脊', rule: '等高线向海拔低处凸出（"凸低为高"）。山脊是两侧河流的分水岭。' },
    valley: { name: '山谷', rule: '等高线向海拔高处凸出（"凸高为低"），雨水向这里汇集，常有河流发育。' },
    saddle: { name: '鞍部', rule: '两个山顶之间相对低洼的部位，夹在两组闭合等高线之间，形似马鞍。' },
    cliff:  { name: '陡崖', rule: '几条等高线重叠在一起，坡度近乎垂直，用 ⊥⊥⊥ 符号表示。' },
    basin:  { name: '盆地', rule: '等高线闭合，数值中间低、四周高。' },
    steep:  { name: '陡坡', rule: '等高线密集，相邻等高线水平距离小，坡度陡（"密陡疏缓"）。' },
    gentle: { name: '缓坡', rule: '等高线稀疏，相邻等高线水平距离大，坡度缓（"密陡疏缓"）。' }
  };
  var FEAT_ORDER = ['peak', 'ridge', 'valley', 'saddle', 'cliff', 'basin', 'steep', 'gentle'];

  // ---------- 高度场 ----------
  function sample(h, u, v) {
    var x = (Math.max(-1, Math.min(1, u)) + 1) / 2 * (N - 1);
    var y = (Math.max(-1, Math.min(1, v)) + 1) / 2 * (N - 1);
    var i = Math.min(N - 2, Math.floor(x)), j = Math.min(N - 2, Math.floor(y));
    var fx = x - i, fy = y - j, k = j * N + i;
    return (h[k] * (1 - fx) + h[k + 1] * fx) * (1 - fy) + (h[k + N] * (1 - fx) + h[k + N + 1] * fx) * fy;
  }
  // 梯度（m / m）
  function grad(h, u, v) {
    var e = 2 / (N - 1);
    return [(sample(h, u + e, v) - sample(h, u - e, v)) / (2 * e * M_PER_UNIT),
            (sample(h, u, v + e) - sample(h, u, v - e)) / (2 * e * M_PER_UNIT)];
  }
  function slopeDeg(h, u, v) { var g = grad(h, u, v); return Math.atan(Math.hypot(g[0], g[1])) / D; }

  function stats(h) {
    var mn = Infinity, mx = -Infinity, imx = 0;
    for (var k = 0; k < h.length; k++) {
      if (h[k] < mn) mn = h[k];
      if (h[k] > mx) { mx = h[k]; imx = k; }
    }
    return { min: mn, max: mx, maxAt: [ucoord(imx % N), ucoord(Math.floor(imx / N))] };
  }

  // 在 near 附近搜索：peak 取最高点，basin 取最低点，saddle 取梯度最小且 Hessian 行列式 < 0 的点
  function locate(h, type, near, rad) {
    rad = rad || 0.2;
    var best = null, bestV = Infinity;
    var i0 = Math.round((near[0] + 1) / 2 * (N - 1)), j0 = Math.round((near[1] + 1) / 2 * (N - 1));
    var R = Math.round(rad / 2 * (N - 1));
    for (var j = Math.max(1, j0 - R); j <= Math.min(N - 2, j0 + R); j++) {
      for (var i = Math.max(1, i0 - R); i <= Math.min(N - 2, i0 + R); i++) {
        if ((i - i0) * (i - i0) + (j - j0) * (j - j0) > R * R) continue;
        var k = j * N + i, val;
        if (type === 'peak') val = -h[k];
        else if (type === 'basin') val = h[k];
        else {
          var gx = h[k + 1] - h[k - 1], gy = h[k + N] - h[k - N];
          var hxx = h[k + 1] - 2 * h[k] + h[k - 1], hyy = h[k + N] - 2 * h[k] + h[k - N];
          var hxy = (h[k + N + 1] - h[k + N - 1] - h[k - N + 1] + h[k - N - 1]) / 4;
          if (hxx * hyy - hxy * hxy >= 0) continue;
          val = gx * gx + gy * gy;
        }
        if (val < bestV) { bestV = val; best = [ucoord(i), ucoord(j)]; }
      }
    }
    return best || near;
  }

  function build(key) {
    var P = PRESETS[key];
    var h = new Float32Array(N * N);
    for (var j = 0; j < N; j++) for (var i = 0; i < N; i++) h[j * N + i] = Math.max(0, P.height(ucoord(i), ucoord(j)));
    var feats = P.feats.map(function (f) {
      var o = { type: f.type, line: f.line, q: f.q };
      if (f.near) {
        o.p = locate(h, f.type, f.near);
        if (!o.q) o.q = o.p;
      }
      return o;
    });
    feats.forEach(function (f) { f.h = sample(h, f.q ? f.q[0] : f.p[0], f.q ? f.q[1] : f.p[1]); if (f.p) f.ph = sample(h, f.p[0], f.p[1]); });
    return { key: key, name: P.name, desc: P.desc, h: h, feats: feats, rivers: P.rivers, edited: false };
  }

  // 堆山 / 挖谷：在 (u, v) 处按高斯笔刷改变高度
  function brush(h, u, v, r, dh) {
    var R = Math.ceil(3 * r / 2 * (N - 1));
    var i0 = Math.round((u + 1) / 2 * (N - 1)), j0 = Math.round((v + 1) / 2 * (N - 1));
    for (var j = Math.max(0, j0 - R); j <= Math.min(N - 1, j0 + R); j++) {
      for (var i = Math.max(0, i0 - R); i <= Math.min(N - 1, i0 + R); i++) {
        var dx = ucoord(i) - u, dy = ucoord(j) - v, k = j * N + i;
        h[k] = Math.max(0, Math.min(HMAX, h[k] + dh * Math.exp(-(dx * dx + dy * dy) / (2 * r * r))));
      }
    }
  }

  // ---------- 等高线：marching squares，返回线段数组 [u1, v1, u2, v2, ...] ----------
  function contour(h, level) {
    var L = level + 1e-3, out = [];
    function lerp(a, b, va, vb) { return a + (b - a) * (L - va) / (vb - va); }
    for (var j = 0; j < N - 1; j++) {
      var v0 = ucoord(j), v1 = ucoord(j + 1);
      for (var i = 0; i < N - 1; i++) {
        var k = j * N + i;
        var a = h[k], b = h[k + 1], c = h[k + N + 1], d = h[k + N];
        var idx = (a >= L ? 1 : 0) | (b >= L ? 2 : 0) | (c >= L ? 4 : 0) | (d >= L ? 8 : 0);
        if (idx === 0 || idx === 15) continue;
        var u0 = ucoord(i), u1 = ucoord(i + 1);
        // 四条边上的交点：e0 下（a-b）e1 右（b-c）e2 上（d-c）e3 左（a-d）
        var e = function (n) {
          switch (n) {
            case 0: return [lerp(u0, u1, a, b), v0];
            case 1: return [u1, lerp(v0, v1, b, c)];
            case 2: return [lerp(u0, u1, d, c), v1];
            default: return [u0, lerp(v0, v1, a, d)];
          }
        };
        var pairs;
        switch (idx) {
          case 1: case 14: pairs = [3, 0]; break;
          case 2: case 13: pairs = [0, 1]; break;
          case 3: case 12: pairs = [3, 1]; break;
          case 4: case 11: pairs = [1, 2]; break;
          case 6: case 9: pairs = [0, 2]; break;
          case 7: case 8: pairs = [2, 3]; break;
          case 5: pairs = (a + b + c + d) / 4 >= L ? [0, 1, 2, 3] : [0, 3, 1, 2]; break;
          case 10: pairs = (a + b + c + d) / 4 >= L ? [0, 3, 1, 2] : [0, 1, 2, 3]; break;
        }
        for (var p = 0; p < pairs.length; p += 2) {
          var P = e(pairs[p]), Q = e(pairs[p + 1]);
          out.push(P[0], P[1], Q[0], Q[1]);
        }
      }
    }
    return out;
  }
  function contours(h, interval) {
    var s = stats(h), list = [];
    for (var L = Math.max(interval, Math.ceil(s.min / interval) * interval); L <= s.max; L += interval) {
      list.push({ level: L, segs: contour(h, L) });
    }
    return list;
  }

  // ---------- 剖面与通视 ----------
  function profile(h, A, B, n) {
    n = n || 240;
    var pts = [], len = Math.hypot(B[0] - A[0], B[1] - A[1]) * M_PER_UNIT;
    for (var k = 0; k <= n; k++) {
      var t = k / n, u = A[0] + (B[0] - A[0]) * t, v = A[1] + (B[1] - A[1]) * t;
      pts.push({ t: t, d: len * t, h: sample(h, u, v) });
    }
    // 通视：A、B 两点（人眼高 2 m）连线是否被中间的地形挡住
    var eye = 2, ha = pts[0].h + eye, hb = pts[n].h + eye, block = null;
    for (k = 1; k < n; k++) {
      // 观察者脚下 60 m 以内的起伏忽略不计（人可以往前走两步）
      if (pts[k].d < 60 || len - pts[k].d < 60) continue;
      var line = ha + (hb - ha) * pts[k].t;
      if (pts[k].h > line + 0.5 && (!block || pts[k].h - line > block.over)) block = { t: pts[k].t, d: pts[k].d, h: pts[k].h, over: pts[k].h - line };
    }
    return { pts: pts, len: len, hA: pts[0].h, hB: pts[n].h, visible: !block, block: block };
  }

  // ---------- 分层设色（地形图常用配色：低处绿，往高处黄、褐，最高处白） ----------
  var RAMP = [[0, [72, 148, 86]], [200, [138, 190, 102]], [400, [214, 211, 126]], [600, [224, 176, 102]],
              [800, [194, 130, 76]], [1000, [156, 96, 62]], [1300, [236, 230, 220]]];
  var RAMP_MAX = 1300;
  function rampColor(hm) {
    if (hm <= 0) return RAMP[0][1].slice();
    for (var k = 1; k < RAMP.length; k++) {
      if (hm <= RAMP[k][0]) {
        var a = RAMP[k - 1], b = RAMP[k], t = (hm - a[0]) / (b[0] - a[0]);
        return [a[1][0] + (b[1][0] - a[1][0]) * t, a[1][1] + (b[1][1] - a[1][1]) * t, a[1][2] + (b[1][2] - a[1][2]) * t];
      }
    }
    return RAMP[RAMP.length - 1][1].slice();
  }
  // 分层：一个等高距内用同一种颜色（取该层中间高度的颜色）
  function bandColor(hm, interval) { return rampColor((Math.floor(hm / interval) + 0.5) * interval); }

  window.Terrain = {
    N: N, WIDTH_M: WIDTH_M, M_PER_UNIT: M_PER_UNIT, HMAX: HMAX,
    PRESETS: PRESETS, ORDER: ORDER, FEAT: FEAT, FEAT_ORDER: FEAT_ORDER,
    ucoord: ucoord, build: build, brush: brush, sample: sample, grad: grad, slopeDeg: slopeDeg, stats: stats,
    contour: contour, contours: contours, profile: profile,
    rampColor: rampColor, bandColor: bandColor, RAMP_MAX: RAMP_MAX
  };
})();
