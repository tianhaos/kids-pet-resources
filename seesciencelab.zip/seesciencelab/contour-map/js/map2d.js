// 等高线地形图：Canvas 平面图（分层设色、等高线、高程注记、地形部位、剖面线、指针）与剖面图
(function () {
  var T = window.Terrain;
  var C = {
    line: '#5b3a1c', lineIdx: '#4a2c12', hi: '#22e0ff', water: '#ffffff',
    ridge: '#ff7a2f', valley: '#0fb5ae', river: '#1f6fe0', prof: '#ff3d7f', label: '#3a230e'
  };

  window.Map2D = function (canvas) {
    var ctx = canvas.getContext('2d');
    var W = 1, H = 1, dpr = 1, box = { x: 0, y: 0, s: 1 };
    var RES = 320;
    var raster = document.createElement('canvas');
    raster.width = raster.height = RES;
    var rctx = raster.getContext('2d'), img = rctx.createImageData(RES, RES), rasterKey = '';
    var labelKey = '', labels = [];
    var paths = { key: '', list: [] };

    function resize(w, h) {
      W = w; H = h; dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
      var pad = w < 420 ? 10 : 24, s = Math.max(40, Math.min(w, h) - 2 * pad);
      box = { x: Math.round((w - s) / 2), y: Math.round((h - s) / 2), s: s };
      labelKey = '';
    }
    function toPx(u, v) { return [box.x + (u + 1) / 2 * box.s, box.y + (1 - v) / 2 * box.s]; }
    function toMap(px, py) {
      var u = (px - box.x) / box.s * 2 - 1, v = 1 - (py - box.y) / box.s * 2;
      return u < -1 || u > 1 || v < -1 || v > 1 ? null : [u, v];
    }
    function pxPerUnit() { return box.s / 2; }

    // ---------- 底图：分层设色 + 水面 ----------
    function updateRaster(S, terr) {
      var key = S.hVer + '|' + S.interval + '|' + S.bands + '|' + (S.waterOn ? Math.round(S.water) : '-');
      if (key === rasterKey) return;
      rasterKey = key;
      var d = img.data, h = terr.h;
      for (var y = 0; y < RES; y++) {
        var v = 1 - (y + 0.5) / RES * 2;
        for (var x = 0; x < RES; x++) {
          var u = (x + 0.5) / RES * 2 - 1, hm = T.sample(h, u, v);
          var c = S.bands ? T.bandColor(hm, S.interval) : [239, 231, 212];
          if (S.waterOn && hm < S.water) c = [c[0] * 0.35 + 40 * 0.65, c[1] * 0.35 + 130 * 0.65, c[2] * 0.35 + 215 * 0.65];
          var o = (y * RES + x) * 4;
          d[o] = c[0]; d[o + 1] = c[1]; d[o + 2] = c[2]; d[o + 3] = 255;
        }
      }
      rctx.putImageData(img, 0, 0);
    }

    // 等高线路径（按当前像素尺寸缓存）
    function contourPaths(S, cont) {
      var key = S.hVer + '|' + S.interval + '|' + box.s + '|' + box.x + '|' + box.y;
      if (paths.key === key) return paths.list;
      paths.key = key;
      paths.list = cont.map(function (c) {
        var p = new Path2D(), s = c.segs;
        for (var k = 0; k < s.length; k += 4) {
          var a = toPx(s[k], s[k + 1]), b = toPx(s[k + 2], s[k + 3]);
          p.moveTo(a[0], a[1]); p.lineTo(b[0], b[1]);
        }
        return { level: c.level, path: p };
      });
      return paths.list;
    }
    function segPath(segs) {
      var p = new Path2D();
      for (var k = 0; k < segs.length; k += 4) {
        var a = toPx(segs[k], segs[k + 1]), b = toPx(segs[k + 2], segs[k + 3]);
        p.moveTo(a[0], a[1]); p.lineTo(b[0], b[1]);
      }
      return p;
    }

    // 高程注记：每条等高线挑几段较平直、等高线不太密的位置
    function placeLabels(S, terr, cont) {
      var key = S.hVer + '|' + S.interval + '|' + box.s + '|' + box.x;
      if (key === labelKey) return labels;
      labelKey = key;
      labels = [];
      var ppu = pxPerUnit(), minGap = Math.max(56, box.s / 7);
      cont.forEach(function (c, ci) {
        var s = c.segs, n = s.length / 4, got = 0;
        if (!n) return;
        var stride = Math.max(1, Math.floor(n / 23));
        for (var m = 0; m < n && got < 3; m++) {
          var k = ((m * stride + ci * 7) % n) * 4;
          var u = (s[k] + s[k + 2]) / 2, v = (s[k + 1] + s[k + 3]) / 2;
          if (Math.abs(u) > 0.9 || Math.abs(v) > 0.9) continue;
          var g = T.grad(terr.h, u, v), gm = Math.hypot(g[0], g[1]);
          // 相邻等高线的像素间距要放得下文字
          if (gm > 0 && S.interval / (gm * T.M_PER_UNIT) * ppu < 13) continue;
          var p = toPx(u, v), ok = true;
          for (var q = 0; q < labels.length; q++) {
            if (Math.hypot(labels[q].x - p[0], labels[q].y - p[1]) < minGap) { ok = false; break; }
          }
          if (!ok) continue;
          var ang = Math.atan2(-(s[k + 3] - s[k + 1]), s[k + 2] - s[k]);
          if (ang > Math.PI / 2) ang -= Math.PI; else if (ang < -Math.PI / 2) ang += Math.PI;
          labels.push({ x: p[0], y: p[1], a: ang, text: String(c.level), level: c.level });
          got++;
        }
      });
      return labels;
    }

    function polyline(pts, color, width, dash) {
      ctx.save();
      ctx.strokeStyle = color; ctx.lineWidth = width; ctx.lineJoin = 'round'; ctx.lineCap = 'round';
      if (dash) ctx.setLineDash(dash);
      ctx.beginPath();
      pts.forEach(function (q, i) { var p = toPx(q[0], q[1]); if (i) ctx.lineTo(p[0], p[1]); else ctx.moveTo(p[0], p[1]); });
      ctx.stroke();
      ctx.restore();
    }
    function tag(text, x, y, color, opts) {
      opts = opts || {};
      ctx.save();
      ctx.font = (opts.bold === false ? '' : '600 ') + (opts.size || 12) + 'px -apple-system, "PingFang SC", "Microsoft YaHei", sans-serif';
      ctx.textAlign = opts.align || 'center'; ctx.textBaseline = 'middle';
      ctx.lineWidth = 3.5; ctx.strokeStyle = 'rgba(255,255,255,.88)'; ctx.lineJoin = 'round';
      ctx.strokeText(text, x, y);
      ctx.fillStyle = color; ctx.fillText(text, x, y);
      ctx.restore();
    }

    // 陡崖符号：沿崖线画线，短齿指向低处
    function drawCliff(terr, line) {
      ctx.save();
      ctx.strokeStyle = '#3b2410'; ctx.lineWidth = 2;
      ctx.beginPath();
      line.forEach(function (q, i) { var p = toPx(q[0], q[1]); if (i) ctx.lineTo(p[0], p[1]); else ctx.moveTo(p[0], p[1]); });
      ctx.stroke();
      var a = line[0], b = line[line.length - 1], len = Math.hypot(b[0] - a[0], b[1] - a[1]);
      var n = Math.max(3, Math.round(len * pxPerUnit() / 9));
      var mid = [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2];
      // 齿的方向：沿崖线法向，指向较低的一侧
      var nx = -(b[1] - a[1]) / len, ny = (b[0] - a[0]) / len;
      if (T.sample(terr.h, mid[0] + nx * 0.05, mid[1] + ny * 0.05) > T.sample(terr.h, mid[0] - nx * 0.05, mid[1] - ny * 0.05)) { nx = -nx; ny = -ny; }
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      for (var k = 0; k <= n; k++) {
        var t = k / n, p = toPx(a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t);
        ctx.moveTo(p[0], p[1]); ctx.lineTo(p[0] + nx * 6, p[1] - ny * 6);
      }
      ctx.stroke();
      ctx.restore();
    }

    function drawFeature(S, terr, f, emph) {
      var name = T.FEAT[f.type].name, p;
      if (f.type === 'ridge' || f.type === 'valley') {
        polyline(f.line, f.type === 'ridge' ? C.ridge : C.valley, emph ? 3.5 : 2.2, [7, 5]);
        var e = f.line[f.line.length - 1]; p = toPx(e[0], e[1]);
        tag(name + '线', p[0], p[1] + (e[1] > f.line[0][1] ? -10 : 10), f.type === 'ridge' ? '#c2410c' : '#0a7a75');
      } else if (f.type === 'steep' || f.type === 'gentle') {
        polyline(f.line, f.type === 'steep' ? '#d6336c' : '#2f9e44', emph ? 3.5 : 2.4, null);
        p = toPx(f.q[0], f.q[1]);
        tag(name, p[0], p[1] - 12, f.type === 'steep' ? '#a61e4d' : '#1b6e2e');
      } else if (f.type === 'cliff') {
        p = toPx(f.q[0], f.q[1]);
        tag('陡崖', p[0] + 14, p[1] - 14, '#3b2410', { align: 'left' });
      } else if (f.type === 'saddle') {
        p = toPx(f.p[0], f.p[1]);
        ctx.save(); ctx.strokeStyle = '#7b2cbf'; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.arc(p[0], p[1] + 6, 7, Math.PI * 1.15, Math.PI * 1.85); ctx.stroke(); ctx.restore();
        tag('鞍部', p[0], p[1] + 16, '#5a189a');
      } else if (f.type === 'peak') {
        p = toPx(f.p[0], f.p[1]);
        tag('山顶', p[0], p[1] - 22, '#7a1f1f');
      } else if (f.type === 'basin') {
        p = toPx(f.p[0], f.p[1]);
        tag('盆地', p[0], p[1] - 14, '#0b5cad');
      }
    }

    function draw(S, terr, cont, ext) {
      updateRaster(S, terr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.fillStyle = '#0b1018'; ctx.fillRect(0, 0, W, H);
      ctx.imageSmoothingEnabled = true;
      ctx.drawImage(raster, box.x, box.y, box.s, box.s);

      ctx.save();
      ctx.beginPath(); ctx.rect(box.x, box.y, box.s, box.s); ctx.clip();

      // 等高线
      var list = contourPaths(S, cont), reveal = ext.reveal;
      if (S.lines) {
        list.forEach(function (c) {
          if (c.level > reveal + 0.5) return;
          var idx = c.level % (S.interval * 5) === 0;
          ctx.strokeStyle = idx ? C.lineIdx : C.line;
          ctx.globalAlpha = S.bands ? 0.9 : 0.85;
          ctx.lineWidth = idx ? 1.8 : 1.1;
          ctx.stroke(c.path);
        });
        ctx.globalAlpha = 1;
      }
      // 指针所在等高线高亮（与 3D 同步）
      if (ext.hi != null) {
        list.forEach(function (c) {
          if (Math.abs(c.level - ext.hi) > 0.5 || c.level > reveal + 0.5) return;
          ctx.strokeStyle = C.hi; ctx.lineWidth = 3; ctx.stroke(c.path);
        });
      }
      // 水面与山体的交线
      if (S.waterOn && ext.waterSegs) {
        ctx.strokeStyle = C.water; ctx.lineWidth = 2.6; ctx.stroke(segPath(ext.waterSegs));
      }
      // 河流
      if (S.river && !ext.quiz) terr.rivers.forEach(function (r) { polyline(r, C.river, 2.6, null); });

      // 高程注记
      if (S.numbers && S.lines) {
        ctx.font = '600 11px -apple-system, "PingFang SC", sans-serif';
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        placeLabels(S, terr, cont).forEach(function (l) {
          if (l.level > reveal + 0.5) return;
          ctx.save(); ctx.translate(l.x, l.y); ctx.rotate(-l.a);
          var w = ctx.measureText(l.text).width + 4;
          var c = S.bands ? T.bandColor(l.level - 1, S.interval) : [239, 231, 212];
          ctx.fillStyle = 'rgb(' + c.map(Math.round).join(',') + ')';
          ctx.fillRect(-w / 2, -6, w, 12);
          ctx.fillStyle = C.label; ctx.fillText(l.text, 0, 0.5);
          ctx.restore();
        });
      }

      // 地图符号：山峰 ▲ 与海拔、陡崖
      if (!ext.quiz) {
        terr.feats.forEach(function (f) {
          if (f.type === 'peak') {
            var p = toPx(f.p[0], f.p[1]);
            ctx.save(); ctx.fillStyle = '#7a1f1f';
            ctx.beginPath(); ctx.moveTo(p[0], p[1] - 5); ctx.lineTo(p[0] + 5, p[1] + 4); ctx.lineTo(p[0] - 5, p[1] + 4); ctx.closePath(); ctx.fill();
            ctx.restore();
            if (S.numbers) tag(String(Math.round(f.ph)), p[0], p[1] + 13, '#7a1f1f', { size: 11 });
          }
          if (f.type === 'cliff') drawCliff(terr, f.line);
        });
      }
      // 地形部位标注
      if (S.labels && !ext.quiz) terr.feats.forEach(function (f) { drawFeature(S, terr, f, false); });
      if (ext.quiz && ext.quiz.answered) drawFeature(S, terr, ext.quiz.feat, true);

      // 剖面线
      if (ext.profile) {
        var A = ext.profile.A, B = ext.profile.B;
        polyline([A, B], C.prof, 2.4, null);
        [[A, 'A'], [B, 'B']].forEach(function (e) {
          var p = toPx(e[0][0], e[0][1]);
          ctx.save();
          ctx.fillStyle = C.prof; ctx.strokeStyle = '#fff'; ctx.lineWidth = 2;
          ctx.beginPath(); ctx.arc(p[0], p[1], 6, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
          ctx.restore();
          tag(e[1], p[0] + 12, p[1] - 10, '#c2185b', { size: 13 });
        });
        if (ext.profile.block) {
          var bp = toPx(A[0] + (B[0] - A[0]) * ext.profile.block.t, A[1] + (B[1] - A[1]) * ext.profile.block.t);
          ctx.save(); ctx.strokeStyle = '#ff2d2d'; ctx.lineWidth = 2.4;
          ctx.beginPath(); ctx.moveTo(bp[0] - 5, bp[1] - 5); ctx.lineTo(bp[0] + 5, bp[1] + 5);
          ctx.moveTo(bp[0] + 5, bp[1] - 5); ctx.lineTo(bp[0] - 5, bp[1] + 5); ctx.stroke(); ctx.restore();
        }
      }

      // 判读练习的提问点
      if (ext.quiz) {
        var qp = toPx(ext.quiz.feat.q[0], ext.quiz.feat.q[1]);
        var pulse = 0.5 + 0.5 * Math.sin(ext.time * 5);
        ctx.save();
        ctx.strokeStyle = '#ff2d55'; ctx.lineWidth = 3;
        ctx.beginPath(); ctx.arc(qp[0], qp[1], 9 + pulse * 4, 0, Math.PI * 2); ctx.stroke();
        ctx.fillStyle = '#ff2d55'; ctx.beginPath(); ctx.arc(qp[0], qp[1], 4, 0, Math.PI * 2); ctx.fill();
        ctx.restore();
        if (!ext.quiz.answered) tag('?', qp[0] + 18, qp[1] - 14, '#ff2d55', { size: 16 });
      }

      // 指针
      if (ext.probe) {
        var pp = toPx(ext.probe.u, ext.probe.v);
        ctx.save();
        ctx.strokeStyle = '#111'; ctx.lineWidth = 3;
        ctx.beginPath(); ctx.arc(pp[0], pp[1], 5, 0, Math.PI * 2); ctx.stroke();
        ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.5; ctx.stroke();
        if (ext.brushR) {
          ctx.setLineDash([4, 4]); ctx.strokeStyle = 'rgba(255,255,255,.9)';
          ctx.beginPath(); ctx.arc(pp[0], pp[1], ext.brushR * pxPerUnit() * 2, 0, Math.PI * 2); ctx.stroke();
        }
        ctx.restore();
        var txt = Math.round(ext.probe.h) + ' m';
        ctx.save();
        ctx.font = '600 12px -apple-system, "PingFang SC", sans-serif';
        var tw = ctx.measureText(txt).width + 12, tx = pp[0] + 10, ty = pp[1] - 28;
        if (tx + tw > box.x + box.s) tx = pp[0] - 10 - tw;
        if (ty < box.y) ty = pp[1] + 10;
        ctx.fillStyle = 'rgba(10,14,22,.85)'; ctx.fillRect(tx, ty, tw, 20);
        ctx.fillStyle = '#fff'; ctx.textBaseline = 'middle'; ctx.fillText(txt, tx + 6, ty + 10);
        ctx.restore();
      }
      ctx.restore();

      // 图框、指向标、比例尺
      ctx.strokeStyle = '#2a3446'; ctx.lineWidth = 1;
      ctx.strokeRect(box.x + 0.5, box.y + 0.5, box.s - 1, box.s - 1);
      var nx = box.x + box.s - 22, ny = box.y + 16;
      ctx.save();
      ctx.fillStyle = 'rgba(10,14,22,.8)';
      ctx.beginPath(); ctx.moveTo(nx, ny); ctx.lineTo(nx + 7, ny + 18); ctx.lineTo(nx, ny + 13); ctx.lineTo(nx - 7, ny + 18); ctx.closePath(); ctx.fill();
      ctx.restore();
      tag('N', nx, ny + 28, '#111', { size: 11 });
      var km = box.s / 4, sx = box.x + 12, sy = box.y + box.s - 14;
      ctx.save();
      ctx.fillStyle = 'rgba(255,255,255,.85)'; ctx.fillRect(sx - 4, sy - 16, km + 30, 22);
      ctx.fillStyle = '#111'; ctx.fillRect(sx, sy - 2, km / 2, 4);
      ctx.strokeStyle = '#111'; ctx.lineWidth = 1; ctx.strokeRect(sx + 0.5, sy - 1.5, km, 4);
      ctx.font = '10px -apple-system, sans-serif'; ctx.textBaseline = 'bottom';
      ctx.fillText('0', sx - 2, sy - 3); ctx.fillText('1 km', sx + km - 8, sy - 3);
      ctx.restore();
    }

    return { resize: resize, draw: draw, toMap: toMap, toPx: toPx, pxPerUnit: pxPerUnit };
  };

  // ---------- 地形剖面图 ----------
  window.Map2D.drawProfile = function (canvas, prof, interval) {
    var w = canvas.clientWidth, h = canvas.clientHeight, dpr = Math.min(window.devicePixelRatio || 1, 2);
    if (!w || !h) return;
    if (canvas.width !== Math.round(w * dpr)) { canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr); }
    var c = canvas.getContext('2d');
    c.setTransform(dpr, 0, 0, dpr, 0, 0);
    c.clearRect(0, 0, w, h);
    var L = 38, R = 10, Tp = 8, B = 18, pw = w - L - R, ph = h - Tp - B;
    var mn = Infinity, mx = -Infinity;
    prof.pts.forEach(function (p) { mn = Math.min(mn, p.h); mx = Math.max(mx, p.h); });
    var step = interval, lo = Math.floor(mn / step) * step, hi = Math.ceil((mx + 1) / step) * step;
    if (hi - lo < step * 2) hi = lo + step * 2;
    while ((hi - lo) / step > 6) step *= 2;
    lo = Math.floor(mn / step) * step; hi = Math.max(lo + step, Math.ceil((mx + 1) / step) * step);
    function X(d) { return L + d / (prof.len || 1) * pw; }
    function Y(m) { return Tp + (1 - (m - lo) / (hi - lo)) * ph; }

    c.font = '10px -apple-system, sans-serif'; c.fillStyle = '#8d99ab'; c.textAlign = 'right'; c.textBaseline = 'middle';
    c.strokeStyle = 'rgba(141,153,171,.25)'; c.lineWidth = 1;
    for (var m = lo; m <= hi + 0.1; m += step) {
      c.beginPath(); c.moveTo(L, Y(m) + 0.5); c.lineTo(L + pw, Y(m) + 0.5); c.stroke();
      c.fillText(m, L - 4, Y(m));
    }
    c.textAlign = 'center'; c.textBaseline = 'top';
    var kmStep = prof.len > 2500 ? 1000 : 500;
    for (var d = 0; d <= prof.len + 1; d += kmStep) {
      c.textAlign = d ? 'center' : 'left';
      c.fillText(d / 1000 + (d ? '' : ' km'), X(d) + (d ? 0 : 2), Tp + ph + 4);
    }

    // 地面
    var g = c.createLinearGradient(0, Tp, 0, Tp + ph);
    g.addColorStop(0, '#c48a52'); g.addColorStop(1, '#5d3d22');
    c.beginPath(); c.moveTo(X(0), Y(lo));
    prof.pts.forEach(function (p) { c.lineTo(X(p.d), Y(p.h)); });
    c.lineTo(X(prof.len), Y(lo)); c.closePath();
    c.fillStyle = g; c.fill();
    c.beginPath(); prof.pts.forEach(function (p, i) { if (i) c.lineTo(X(p.d), Y(p.h)); else c.moveTo(X(p.d), Y(p.h)); });
    c.strokeStyle = '#ffd6a0'; c.lineWidth = 1.6; c.stroke();

    // 视线
    c.setLineDash([5, 4]);
    c.strokeStyle = prof.visible ? '#7ee081' : '#ff7a59'; c.lineWidth = 1.5;
    c.beginPath(); c.moveTo(X(0), Y(prof.hA + 2)); c.lineTo(X(prof.len), Y(prof.hB + 2)); c.stroke();
    c.setLineDash([]);
    if (prof.block) {
      c.fillStyle = '#ff7a59';
      c.beginPath(); c.arc(X(prof.block.d), Y(prof.block.h), 3.5, 0, Math.PI * 2); c.fill();
    }
    c.font = '600 12px -apple-system, sans-serif'; c.fillStyle = '#ff6fa0'; c.textBaseline = 'bottom';
    c.textAlign = 'left'; c.fillText('A', X(0) + 3, Y(prof.hA) - 3);
    c.textAlign = 'right'; c.fillText('B', X(prof.len) - 3, Y(prof.hB) - 3);
  };
})();
