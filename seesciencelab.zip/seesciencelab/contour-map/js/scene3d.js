// 等高线地形图：three.js 3D 沙盘（分层设色与等高线在着色器里按高度绘制，压平后即成平面图）
(function () {
  var T = window.Terrain;
  var V3 = THREE.Vector3;
  var HALF = 50;                 // 地图边长 4 km → 100 个世界单位
  var MPU = T.WIDTH_M / (2 * HALF); // 1 世界单位 = 40 m（水平、竖直同比例，再乘起伏倍数）
  var BASE_M = -160;             // 沙盘底座高度（m）

  var VERT = [
    'attribute float elev;',
    'varying float vElev;',
    'varying vec3 vNormalV;',
    'varying float vFlatY;',
    'void main() {',
    '  vElev = elev;',
    '  vNormalV = normalize(normalMatrix * normal);',
    '  vFlatY = normal.y;',          // 1 倍起伏下的法线 y 分量：判断真实坡度
    '  gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);',
    '}'
  ].join('\n');

  var FRAG = [
    'uniform sampler2D uRamp;',
    'uniform float uRampMax, uInterval, uBands, uLines, uReveal, uHi, uWater;',
    'uniform vec3 uLight;',
    'varying float vElev;',
    'varying vec3 vNormalV;',
    'varying float vFlatY;',
    'void main() {',
    '  float e = vElev;',
    '  vec3 col;',
    '  if (e < 0.0) col = vec3(0.36, 0.25, 0.17);',                     // 底座：土层
    '  else if (uBands > 0.5) col = texture2D(uRamp, vec2(clamp((floor(e / uInterval) + 0.5) * uInterval / uRampMax, 0.0, 1.0), 0.5)).rgb;',
    '  else col = vec3(0.86, 0.82, 0.74);',
    '#ifndef WALL',
    '  col = mix(col, vec3(0.55, 0.52, 0.5), smoothstep(0.45, 0.3, vFlatY) * 0.7);', // 坡度很陡处露出岩石
    '#endif',
    '  float d = max(dot(normalize(vNormalV), uLight), 0.0);',
    '  col *= 0.5 + 0.62 * d;',
    // 等高线：距最近一条等高线的像素距离
    '  float x = e / uInterval;',
    '  float fw = max(fwidth(x), 1e-4);',
    '  float lvl = floor(x + 0.5) * uInterval;',
    '  float dist = abs(fract(x + 0.5) - 0.5) / fw;',
    '  if (uLines > 0.5 && e > 0.0 && lvl > 0.5 && lvl <= uReveal + 0.5) {',
    '    bool hi = abs(lvl - uHi) < 0.5;',
    '    float a = hi ? 1.0 - smoothstep(1.3, 2.3, dist) : (1.0 - smoothstep(0.55, 1.4, dist)) * 0.85;',
    '    col = mix(col, hi ? vec3(0.13, 0.88, 1.0) : vec3(0.3, 0.19, 0.09), a);',
    '  }',
    // 水面与地面的交线
    '  if (uWater > 0.0) {',
    '    float wd = abs(e - uWater) / max(fwidth(e), 1e-3);',
    '    col = mix(col, vec3(1.0), 1.0 - smoothstep(1.2, 2.4, wd));',
    '  }',
    '  gl_FragColor = vec4(col, 1.0);',
    '}'
  ].join('\n');

  window.Scene3D = function (container) {
    var N = T.N;
    var renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    container.appendChild(renderer.domElement);
    var canvas = renderer.domElement;

    var labelRenderer = new THREE.CSS2DRenderer();
    var ls = labelRenderer.domElement.style;
    ls.position = 'absolute'; ls.top = '0'; ls.left = '0'; ls.pointerEvents = 'none'; ls.zIndex = '2';
    container.appendChild(labelRenderer.domElement);

    var scene = new THREE.Scene();
    scene.background = new THREE.Color('#05070d');
    var camera = new THREE.PerspectiveCamera(40, 1, 0.5, 2000);
    var controls = new THREE.OrbitControls(camera, canvas);
    controls.enableDamping = true;
    controls.dampingFactor = 0.08;
    controls.minDistance = 25;
    controls.maxDistance = 600;
    controls.maxPolarAngle = Math.PI * 0.47;

    // ---------- 色带纹理 ----------
    var rampData = new Uint8Array(256 * 4);
    for (var r = 0; r < 256; r++) {
      var rc = T.rampColor(r / 255 * T.RAMP_MAX);
      rampData[r * 4] = rc[0]; rampData[r * 4 + 1] = rc[1]; rampData[r * 4 + 2] = rc[2]; rampData[r * 4 + 3] = 255;
    }
    var rampTex = new THREE.DataTexture(rampData, 256, 1, THREE.RGBAFormat);
    rampTex.magFilter = THREE.LinearFilter; rampTex.minFilter = THREE.LinearFilter;
    rampTex.needsUpdate = true;

    var uniforms = {
      uRamp: { value: rampTex }, uRampMax: { value: T.RAMP_MAX },
      uInterval: { value: 100 }, uBands: { value: 1 }, uLines: { value: 1 },
      uReveal: { value: 1e9 }, uHi: { value: -1 }, uWater: { value: -1 },
      uLight: { value: new V3() }
    };
    function makeMat(defines) {
      return new THREE.ShaderMaterial({
        uniforms: uniforms, vertexShader: VERT, fragmentShader: FRAG, defines: defines || {},
        extensions: { derivatives: true }, polygonOffset: true, polygonOffsetFactor: 1, polygonOffsetUnits: 1
      });
    }
    var LIGHT = new V3(-0.55, 0.75, -0.45).normalize(); // 西北方向来光（地图晕渲惯例）

    // ---------- 地形网格 ----------
    var group = new THREE.Group();
    scene.add(group);
    var pos = new Float32Array(N * N * 3), elevA = new Float32Array(N * N), idx = [];
    for (var j = 0; j < N; j++) {
      for (var i = 0; i < N; i++) {
        var k = j * N + i;
        pos[k * 3] = T.ucoord(i) * HALF; pos[k * 3 + 2] = -T.ucoord(j) * HALF;
        if (i < N - 1 && j < N - 1) idx.push(k, k + 1, k + N + 1, k, k + N + 1, k + N);
      }
    }
    var geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    geo.setAttribute('elev', new THREE.BufferAttribute(elevA, 1));
    geo.setIndex(idx);
    var terrainMesh = new THREE.Mesh(geo, makeMat());
    group.add(terrainMesh);

    // 四周侧壁（沙盘截面），能看到地层般的等高线
    var sides = [], e;
    var S0 = [], S1 = [], S2 = [], S3 = [];
    for (e = 0; e < N; e++) { S0.push(e); S1.push(e * N + N - 1); S2.push((N - 1) * N + N - 1 - e); S3.push((N - 1 - e) * N); }
    sides = [S0, S1, S2, S3];
    var wallPos = new Float32Array(4 * N * 2 * 3), wallElev = new Float32Array(4 * N * 2), wallIdx = [];
    sides.forEach(function (S, si) {
      S.forEach(function (gk, n) {
        var o = (si * N + n) * 2;
        [o, o + 1].forEach(function (q) { wallPos[q * 3] = pos[gk * 3]; wallPos[q * 3 + 2] = pos[gk * 3 + 2]; });
        wallPos[(o + 1) * 3 + 1] = BASE_M / MPU; wallElev[o + 1] = BASE_M;
        if (n < N - 1) wallIdx.push(o, o + 1, o + 3, o, o + 3, o + 2);
      });
    });
    var wallGeo = new THREE.BufferGeometry();
    wallGeo.setAttribute('position', new THREE.BufferAttribute(wallPos, 3));
    wallGeo.setAttribute('elev', new THREE.BufferAttribute(wallElev, 1));
    wallGeo.setIndex(wallIdx);
    var wallMesh = new THREE.Mesh(wallGeo, makeMat({ WALL: 1 }));
    group.add(wallMesh);

    // 水面（随起伏倍数一起缩放）
    var water = new THREE.Mesh(new THREE.PlaneGeometry(2 * HALF, 2 * HALF).rotateX(-Math.PI / 2),
      new THREE.MeshBasicMaterial({ color: 0x3a8fd8, transparent: true, opacity: 0.42, depthWrite: false }));
    water.visible = false;
    group.add(water);
    var waterEdge = new THREE.LineSegments(new THREE.EdgesGeometry(new THREE.BoxGeometry(2 * HALF, 1, 2 * HALF)),
      new THREE.LineBasicMaterial({ color: 0x8fd0ff, transparent: true, opacity: 0.5 }));
    waterEdge.visible = false;
    scene.add(waterEdge);

    var terrH = null;
    function setHeights(h) {
      terrH = h;
      for (var k = 0; k < N * N; k++) { pos[k * 3 + 1] = h[k] / MPU; elevA[k] = h[k]; }
      geo.attributes.position.needsUpdate = true;
      geo.attributes.elev.needsUpdate = true;
      geo.computeVertexNormals();
      geo.computeBoundingSphere(); geo.computeBoundingBox();
      sides.forEach(function (S, si) {
        S.forEach(function (gk, n) {
          var o = (si * N + n) * 2;
          wallPos[o * 3 + 1] = h[gk] / MPU; wallElev[o] = h[gk];
        });
      });
      wallGeo.attributes.position.needsUpdate = true;
      wallGeo.attributes.elev.needsUpdate = true;
      wallGeo.computeVertexNormals();
      wallGeo.computeBoundingSphere();
    }

    // ---------- 叠加物（世界坐标，起伏倍数变化时重建） ----------
    var K = 1;
    function wp(u, v, lift) { return new V3(u * HALF, T.sample(terrH, u, v) / MPU * K + (lift || 0), -v * HALF); }
    function densify(line, step) {
      var out = [];
      for (var a = 0; a < line.length - 1; a++) {
        var p = line[a], q = line[a + 1], n = Math.max(1, Math.ceil(Math.hypot(q[0] - p[0], q[1] - p[1]) / step));
        for (var b = 0; b < n; b++) out.push([p[0] + (q[0] - p[0]) * b / n, p[1] + (q[1] - p[1]) * b / n]);
      }
      out.push(line[line.length - 1]);
      return out.filter(function (q) { return Math.abs(q[0]) <= 1 && Math.abs(q[1]) <= 1; });
    }
    function tube(line, radius, color, lift) {
      var pts = densify(line, 0.012).map(function (q) { return wp(q[0], q[1], lift); });
      if (pts.length < 2) return null;
      var curve = new THREE.CatmullRomCurve3(pts, false, 'centripetal');
      return new THREE.Mesh(new THREE.TubeGeometry(curve, pts.length * 2, radius, 6, false),
        new THREE.MeshBasicMaterial({ color: color }));
    }
    function clearGroup(g) {
      while (g.children.length) {
        var c = g.children.pop();
        if (c.geometry) c.geometry.dispose();
        if (c.material) c.material.dispose();
        if (c.element && c.element.parentNode) c.element.parentNode.removeChild(c.element);
      }
    }
    function label(html, cls, p) {
      var el = document.createElement('div');
      el.className = 'lbl ' + (cls || '');
      el.innerHTML = html;
      var o = new THREE.CSS2DObject(el);
      o.position.copy(p);
      return o;
    }

    var gRiver = new THREE.Group(), gFeat = new THREE.Group(), gProf = new THREE.Group(), gProbe = new THREE.Group(), gQuiz = new THREE.Group();
    [gRiver, gFeat, gProf, gProbe, gQuiz].forEach(function (g) { scene.add(g); });
    var northLbl = label('↑ 北', 'lbl-n', new V3(-HALF, 1, -HALF - 3));
    scene.add(northLbl);

    var keys = {};
    function changed(name, key) { if (keys[name] === key) return false; keys[name] = key; return true; }

    var FCOL = { ridge: 0xff7a2f, valley: 0x14c8c0, steep: 0xe64980, gentle: 0x40c057 };
    function featLabelPos(f) {
      if (f.p) return f.p;
      if (f.type === 'ridge' || f.type === 'valley') return f.line[f.line.length - 1];
      return f.q;
    }
    function buildFeature(f, emph) {
      if (f.line && FCOL[f.type]) {
        var m = tube(f.line, emph ? 0.5 : 0.32, FCOL[f.type], 0.3);
        if (m) gFeat.add(m);
      }
      var p = featLabelPos(f), name = T.FEAT[f.type].name;
      if (f.type === 'ridge' || f.type === 'valley') name += '线';
      var txt = f.type === 'peak' ? '▲ 山顶 ' + Math.round(f.ph) + ' m' : name;
      gFeat.add(label(txt, 'lbl-f lbl-' + f.type, wp(p[0], p[1], 3)));
    }

    function update(S, terr, ext) {
      var k = ext.k;
      if (k !== K) { K = k; }
      group.scale.y = Math.max(K, 0.002);
      uniforms.uInterval.value = S.interval;
      uniforms.uBands.value = S.bands ? 1 : 0;
      uniforms.uLines.value = S.lines ? 1 : 0;
      uniforms.uReveal.value = ext.reveal;
      uniforms.uHi.value = ext.hi == null ? -1 : ext.hi;
      uniforms.uWater.value = S.waterOn ? S.water : -1;
      water.visible = waterEdge.visible = S.waterOn;
      water.position.y = S.water / MPU;
      var wy = S.water / MPU * K, by = BASE_M / MPU * K;
      waterEdge.scale.y = Math.max(wy - by, 0.01);
      waterEdge.position.y = (wy + by) / 2;

      var base = S.hVer + '|' + K.toFixed(3);
      if (changed('river', base + '|' + S.river + '|' + !!ext.quiz)) {
        clearGroup(gRiver);
        if (S.river && !ext.quiz) terr.rivers.forEach(function (rv) { var m = tube(rv, 0.42, 0x1f6fe0, 0.2); if (m) gRiver.add(m); });
      }
      var qa = ext.quiz && ext.quiz.answered;
      if (changed('feat', base + '|' + S.labels + '|' + !!ext.quiz + '|' + qa + '|' + terr.feats.length)) {
        clearGroup(gFeat);
        if (ext.quiz) { if (qa) buildFeature(ext.quiz.feat, true); }
        else if (S.labels) terr.feats.forEach(function (f) { buildFeature(f, false); });
      }
      var P = ext.profile;
      if (changed('prof', base + '|' + (P ? P.A.join(',') + P.B.join(',') : '-'))) {
        clearGroup(gProf);
        if (P && Math.hypot(P.B[0] - P.A[0], P.B[1] - P.A[1]) > 0.01) {
          var m = tube([P.A, P.B], 0.4, 0xff3d7f, 0.25);
          if (m) gProf.add(m);
          // 剖面"切开"的竖直面：从底座到地面
          var pts = densify([P.A, P.B], 0.01), cp = [], ci = [];
          pts.forEach(function (q, n) {
            var top = wp(q[0], q[1], 0);
            cp.push(top.x, BASE_M / MPU * K, top.z, top.x, top.y, top.z);
            if (n) ci.push(2 * n - 2, 2 * n - 1, 2 * n + 1, 2 * n - 2, 2 * n + 1, 2 * n);
          });
          var cg = new THREE.BufferGeometry();
          cg.setAttribute('position', new THREE.Float32BufferAttribute(cp, 3));
          cg.setIndex(ci);
          gProf.add(new THREE.Mesh(cg, new THREE.MeshBasicMaterial({ color: 0xff3d7f, transparent: true, opacity: 0.28, side: THREE.DoubleSide, depthWrite: false })));
          gProf.add(label('A', 'lbl-ab', wp(P.A[0], P.A[1], 3)));
          gProf.add(label('B', 'lbl-ab', wp(P.B[0], P.B[1], 3)));
        }
      }
      var pr = ext.probe;
      if (changed('probe', base + '|' + (pr ? pr.u.toFixed(4) + ',' + pr.v.toFixed(4) : '-'))) {
        clearGroup(gProbe);
        if (pr) {
          var p0 = wp(pr.u, pr.v, 0);
          var stick = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 5, 6), new THREE.MeshBasicMaterial({ color: 0xffffff }));
          stick.position.set(p0.x, p0.y + 2.5, p0.z);
          var ball = new THREE.Mesh(new THREE.SphereGeometry(0.7, 12, 8), new THREE.MeshBasicMaterial({ color: 0x22e0ff }));
          ball.position.set(p0.x, p0.y + 5, p0.z);
          gProbe.add(stick, ball);
        }
      }
      var qz = ext.quiz;
      if (changed('quiz', base + '|' + (qz ? qz.feat.q.join(',') + qz.answered : '-'))) {
        clearGroup(gQuiz);
        if (qz) {
          var q0 = wp(qz.feat.q[0], qz.feat.q[1], 0);
          var cone = new THREE.Mesh(new THREE.ConeGeometry(1.8, 5, 16).rotateX(Math.PI), new THREE.MeshBasicMaterial({ color: 0xff2d55 }));
          cone.position.set(q0.x, q0.y + 3, q0.z);
          gQuiz.add(cone);
          if (!qz.answered) gQuiz.add(label('?', 'lbl-q', new V3(q0.x, q0.y + 8, q0.z)));
        }
      }
    }

    // ---------- 视角 ----------
    var anim = null, touched = false;
    controls.addEventListener('start', function () { touched = true; anim = null; });
    // 按窗格宽高比取相机距离，保证整块沙盘都在画面里
    function homePose(top) {
      var aspect = camera.aspect || 1, t = Math.tan(camera.fov / 2 * Math.PI / 180);
      if (top) {
        var dt = Math.max(56 / t, 56 / (t * aspect)) + 10;
        return { pos: new V3(0, dt, 0.01), target: new V3(0, 0, 0) };
      }
      var d = Math.max(150, 66 / (t * aspect));
      return { pos: new V3(0, 0.6 * d, 0.8 * d), target: new V3(0, 2, 0) };
    }
    function flyTo(top, dur) {
      touched = true;
      anim = { t: 0, dur: dur || 0.9, top: top, p0: camera.position.clone(), t0: controls.target.clone() };
    }
    function stepAnim(dt) {
      if (!anim) return;
      anim.t = Math.min(1, anim.t + dt / anim.dur);
      var s = anim.t * anim.t * (3 - 2 * anim.t);
      var p = homePose(anim.top);   // 每帧重算，窗格尺寸变化时也能落到正确位置
      camera.position.lerpVectors(anim.p0, p.pos, s);
      controls.target.lerpVectors(anim.t0, p.target, s);
      if (anim.t >= 1) anim = null;
    }

    // ---------- 拾取 ----------
    var raycaster = new THREE.Raycaster(), ndc = new THREE.Vector2();
    function pick(clientX, clientY) {
      var rc = canvas.getBoundingClientRect();
      ndc.set((clientX - rc.left) / rc.width * 2 - 1, -(clientY - rc.top) / rc.height * 2 + 1);
      raycaster.setFromCamera(ndc, camera);
      var hit = raycaster.intersectObject(terrainMesh, false)[0];
      if (!hit) return null;
      return [Math.max(-1, Math.min(1, hit.point.x / HALF)), Math.max(-1, Math.min(1, -hit.point.z / HALF))];
    }

    var W = 1, H = 1;
    function resize(w, h) {
      if (w < 2 || h < 2) return;
      W = w; H = h;
      renderer.setSize(w, h);
      labelRenderer.setSize(w, h);
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      if (!touched) { var p = homePose(false); camera.position.copy(p.pos); controls.target.copy(p.target); }
    }
    function render(dt) {
      stepAnim(dt);
      controls.update();
      uniforms.uLight.value.copy(LIGHT).transformDirection(camera.matrixWorldInverse);
      renderer.render(scene, camera);
      labelRenderer.render(scene, camera);
    }

    var p0 = homePose(false);
    camera.position.copy(p0.pos); controls.target.copy(p0.target);

    return {
      canvas: canvas, camera: camera, controls: controls,
      setHeights: setHeights, update: update, render: render, resize: resize, pick: pick,
      flyTo: flyTo, isAnimating: function () { return !!anim; }
    };
  };
})();
