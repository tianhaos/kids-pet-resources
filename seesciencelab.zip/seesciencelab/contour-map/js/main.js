(function () {
  var T = window.Terrain;
  var $ = function (id) { return document.getElementById(id); };
  var qa = function (sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); };

  var state = {
    preset: 'composite', interval: 100, exag: 1.5,
    bands: true, lines: true, numbers: true, labels: true, river: true,
    view: 'split', tool: 'look', brushR: 0.12,
    waterOn: false, water: 300,
    hVer: 0
  };
  var terr = null, cont = [], contKey = '';
  var probe = null;          // 指针处 { u, v, h }
  var profile = null;        // 剖面线 { A: [u, v], B: [u, v] }
  var prof = null, profKey = '';
  var quiz = null;           // { feat, answered, ok }
  var score = { n: 0, ok: 0 };
  var demo = null;           // 演示动画 { phase, t, from }
  var reveal = 1e9;          // 只显示海拔不超过它的等高线（演示时逐条出现）

  var stage = $('stage'), pane3d = $('pane3d'), paneMap = $('paneMap'), mapCanvas = $('map'), panel = $('panel');
  var s3 = window.Scene3D(pane3d);
  var m2 = window.Map2D(mapCanvas);

  // ---------- 地形 ----------
  function loadPreset(key) {
    state.preset = key;
    terr = T.build(key);
    state.hVer++;
    s3.setHeights(terr.h);
    profile = null;
    qa('[data-preset]').forEach(function (b) { b.classList.toggle('on', b.dataset.preset === key); });
    $('presetDesc').textContent = terr.desc;
  }
  function ensureContours() {
    var key = state.hVer + '|' + state.interval;
    if (key === contKey) return;
    contKey = key;
    cont = T.contours(terr.h, state.interval);
    var s = T.stats(terr.h);
    terr.min = s.min; terr.max = s.max;
  }
  function markEdited() {
    if (!terr.edited) {
      terr.edited = true; terr.feats = []; terr.rivers = [];
      qa('[data-preset]').forEach(function (b) { b.classList.remove('on'); });
      $('presetDesc').textContent = '地形已被你修改：地形部位标注和河流已隐藏。点上面的按钮可恢复。';
    }
    state.hVer++;
    s3.setHeights(terr.h);
  }

  // ---------- 视图 ----------
  function setView(v) {
    state.view = v;
    stage.classList.remove('v-split', 'v-3d', 'v-map');
    stage.classList.add('v-' + v);
    qa('[data-view]').forEach(function (b) { b.classList.toggle('on', b.dataset.view === v); });
  }
  function layout() {
    stage.classList.toggle('portrait', stage.clientWidth < stage.clientHeight * 0.95);
  }
  new ResizeObserver(function () { layout(); }).observe(stage);
  new ResizeObserver(function () { s3.resize(pane3d.clientWidth, pane3d.clientHeight); }).observe(pane3d);
  new ResizeObserver(function () { m2.resize(mapCanvas.clientWidth, mapCanvas.clientHeight); }).observe(mapCanvas);

  // ---------- 面板控件 ----------
  qa('[data-preset]').forEach(function (b) {
    b.addEventListener('click', function () {
      stopDemo(); endQuiz();
      loadPreset(b.dataset.preset);
      Analytics.track('等高线', '选择地形', b.dataset.preset);
    });
  });
  qa('[data-view]').forEach(function (b) {
    b.addEventListener('click', function () { setView(b.dataset.view); });
  });
  qa('[data-interval]').forEach(function (b) {
    b.addEventListener('click', function () {
      state.interval = +b.dataset.interval;
      qa('[data-interval]').forEach(function (x) { x.classList.toggle('on', x === b); });
    });
  });

  var exagEl = $('exag');
  function setExag(k) {
    state.exag = k;
    exagEl.value = k;
    $('exagOut').textContent = k < 0.01 ? '压平' : '×' + k.toFixed(2).replace(/0$/, '');
  }
  exagEl.addEventListener('input', function () { stopDemo(); setExag(+exagEl.value); });

  var waterEl = $('water');
  function setWater(h) {
    state.water = h;
    waterEl.value = h;
    $('waterOut').textContent = Math.round(h) + ' m';
  }
  waterEl.addEventListener('input', function () {
    stopDemo();
    setWater(+waterEl.value);
    if (!state.waterOn) { state.waterOn = true; $('waterOn').checked = true; }
  });
  $('waterOn').addEventListener('change', function () { stopDemo(); state.waterOn = $('waterOn').checked; });

  ['bands', 'lines', 'numbers', 'labels', 'river'].forEach(function (k) {
    var el = $('show_' + k);
    el.checked = state[k];
    el.addEventListener('change', function () { state[k] = el.checked; });
  });

  var TOOL_NOTE = {
    look: '把指针移到立体图或平面图上，查看该点的海拔和坡度；同一条等高线在两边同时高亮。',
    profile: '在平面图上按住拖动，画出剖面线 AB；拖动 A、B 两端可以调整。下方会画出地形剖面图，并判断 A、B 能否互相看见（通视）。',
    raise: '在平面图上按住拖动，把地面堆高；看等高线怎样变成闭合的圈。',
    dig: '在平面图上按住拖动，把地面挖低：在山坡上挖出山谷，看等高线怎样向高处凸出。'
  };
  function setTool(t) {
    state.tool = t;
    qa('[data-tool]').forEach(function (b) { b.classList.toggle('on', b.dataset.tool === t); });
    $('brushRow').hidden = !(t === 'raise' || t === 'dig');
    $('toolNote').textContent = TOOL_NOTE[t];
    mapCanvas.style.cursor = t === 'look' ? '' : 'crosshair';
    if ((t === 'raise' || t === 'dig') && quiz) endQuiz();
  }
  qa('[data-tool]').forEach(function (b) {
    b.addEventListener('click', function () {
      setTool(b.dataset.tool);
      if (b.dataset.tool !== 'look' && state.view === '3d') setView('split');
      Analytics.track('等高线', '工具', b.dataset.tool);
    });
  });
  var brushEl = $('brush');
  brushEl.addEventListener('input', function () { state.brushR = +brushEl.value; $('brushOut').textContent = Math.round(state.brushR * T.M_PER_UNIT) + ' m'; });
  $('brushOut').textContent = Math.round(state.brushR * T.M_PER_UNIT) + ' m';

  $('topView').addEventListener('click', function () { s3.flyTo(true); });
  $('obliqueView').addEventListener('click', function () { s3.flyTo(false); });
  $('profClose').addEventListener('click', function () { profile = null; });

  $('panelToggle').addEventListener('click', function () { panel.classList.toggle('collapsed'); });
  if (window.matchMedia('(max-width: 760px)').matches) panel.classList.add('collapsed');

  // ---------- 平面图交互：指针、剖面线、堆山挖谷 ----------
  var drag = null;           // 'A' | 'B' | 'brush'
  var brushAt = null;
  function mapPt(e) {
    var r = mapCanvas.getBoundingClientRect();
    return { px: e.clientX - r.left, py: e.clientY - r.top, uv: m2.toMap(e.clientX - r.left, e.clientY - r.top) };
  }
  function setProbe(uv) {
    probe = uv ? { u: uv[0], v: uv[1], h: T.sample(terr.h, uv[0], uv[1]) } : null;
  }
  function nearEnd(px, py) {
    if (!profile) return null;
    var a = m2.toPx(profile.A[0], profile.A[1]), b = m2.toPx(profile.B[0], profile.B[1]);
    if (Math.hypot(a[0] - px, a[1] - py) < 14) return 'A';
    if (Math.hypot(b[0] - px, b[1] - py) < 14) return 'B';
    return null;
  }
  mapCanvas.addEventListener('pointerdown', function (e) {
    var p = mapPt(e);
    if (!p.uv) return;
    var end = state.tool === 'raise' || state.tool === 'dig' ? null : nearEnd(p.px, p.py);
    if (end) drag = end;
    else if (state.tool === 'profile') { profile = { A: p.uv, B: p.uv.slice() }; drag = 'B'; }
    else if (state.tool === 'raise' || state.tool === 'dig') { drag = 'brush'; brushAt = p.uv; stopDemo(); }
    else return;
    mapCanvas.setPointerCapture(e.pointerId);
    e.preventDefault();
  });
  mapCanvas.addEventListener('pointermove', function (e) {
    var p = mapPt(e);
    var uv = p.uv || (drag ? [Math.max(-1, Math.min(1, (p.px - m2.toPx(-1, 0)[0]) / m2.pxPerUnit() - 1)),
      Math.max(-1, Math.min(1, 1 - (p.py - m2.toPx(0, 1)[1]) / m2.pxPerUnit()))] : null);
    if (drag === 'A' || drag === 'B') profile[drag] = uv;
    else if (drag === 'brush') brushAt = uv;
    setProbe(uv);
    if (!drag) mapCanvas.style.cursor = nearEnd(p.px, p.py) ? 'grab' : (state.tool === 'look' ? '' : 'crosshair');
  });
  function endDrag(e) {
    if (!drag) return;
    if (profile && Math.hypot(profile.B[0] - profile.A[0], profile.B[1] - profile.A[1]) < 0.02) profile = null;
    else if (drag !== 'brush') Analytics.track('等高线', '剖面线');
    drag = null; brushAt = null;
    if (mapCanvas.hasPointerCapture(e.pointerId)) mapCanvas.releasePointerCapture(e.pointerId);
  }
  mapCanvas.addEventListener('pointerup', endDrag);
  mapCanvas.addEventListener('pointercancel', endDrag);
  mapCanvas.addEventListener('pointerleave', function () { if (!drag) probe = null; });

  // 3D：指针悬停取点
  s3.canvas.addEventListener('pointermove', function (e) {
    if (e.buttons) return;
    setProbe(s3.pick(e.clientX, e.clientY));
  });
  s3.canvas.addEventListener('pointerleave', function () { probe = null; });
  s3.canvas.addEventListener('pointerdown', function () { probe = null; });

  // ---------- 演示：等高线是怎样画出来的 ----------
  var caption = $('caption'), captionTimer = 0;
  function say(html, hold) {
    caption.innerHTML = html;
    caption.hidden = !html;
    captionTimer = hold || 0;
  }
  function startDemo() {
    endQuiz();
    if (state.view === 'map') setView('split');
    ensureContours();
    demo = { phase: 'rise', t: 0 };
    state.waterOn = true; $('waterOn').checked = true;
    setWater(Math.max(0, Math.floor(terr.min / state.interval) * state.interval));
    reveal = -1;
    setExag(1.5);
    s3.flyTo(false);
    $('demoBtn').textContent = '■ 停止演示';
    say('① 把山体模型放进水槽，慢慢注水：<b>水面与山坡的交线</b>，就是一条等高线');
    Analytics.track('等高线', '演示');
  }
  function stopDemo() {
    if (!demo) return;
    demo = null;
    reveal = 1e9;
    $('demoBtn').textContent = '▶ 等高线是怎样画出来的';
    say('');
  }
  $('demoBtn').addEventListener('click', function () { if (demo) stopDemo(); else startDemo(); });

  function stepDemo(dt) {
    if (!demo) return;
    demo.t += dt;
    if (demo.phase === 'rise') {
      var top = terr.max + state.interval * 0.5, speed = Math.max(60, (top - 0) / 8);
      var before = state.water;
      setWater(Math.min(top, state.water + speed * dt));
      var passed = Math.floor(state.water / state.interval) * state.interval;
      if (passed > Math.floor(before / state.interval) * state.interval && passed > 0) {
        say('① 水面升到 <b>' + passed + ' m</b>：沿水边画一圈，就得到 ' + passed + ' m 等高线');
      }
      reveal = state.water;
      if (state.water >= top) { demo.phase = 'pause'; demo.t = 0; state.waterOn = false; $('waterOn').checked = false; reveal = 1e9;
        say('② 每隔 ' + state.interval + ' m（等高距）画一条线，所有等高线就画好了'); }
    } else if (demo.phase === 'pause') {
      if (demo.t > 1.8) {
        demo.phase = 'flat'; demo.t = 0; demo.from = state.exag;
        s3.flyTo(true, 2.2);
        say('③ 从正上方往下看，把山体"压扁"——等高线垂直投影到平面上');
      }
    } else if (demo.phase === 'flat') {
      var s = Math.min(1, demo.t / 2.4);
      setExag(demo.from * (1 - s * s * (3 - 2 * s)));
      if (s >= 1) {
        demo = null;
        $('demoBtn').textContent = '▶ 等高线是怎样画出来的';
        say('④ 这就是<b>等高线地形图</b>。拖动「地形起伏」滑块，可以让它重新立起来', 6);
      }
    }
  }

  // ---------- 判读练习 ----------
  var pool = [];
  T.ORDER.forEach(function (key) {
    T.build(key).feats.forEach(function (f, i) { if (f.q) pool.push({ preset: key, i: i, type: f.type }); });
  });
  var lastQ = null, viewBeforeQuiz = null;
  var quizOpts = $('quizOpts');
  T.FEAT_ORDER.forEach(function (t) {
    var b = document.createElement('button');
    b.textContent = T.FEAT[t].name;
    b.dataset.ans = t;
    b.disabled = true;
    b.addEventListener('click', function () { answer(t); });
    quizOpts.appendChild(b);
  });
  function nextQuestion() {
    stopDemo();
    var cand = pool.filter(function (p) { return p !== lastQ && (!lastQ || p.type !== lastQ.type || Math.random() < 0.3); });
    var q = cand[Math.floor(Math.random() * cand.length)];
    lastQ = q;
    if (q.preset !== state.preset || terr.edited) loadPreset(q.preset);
    if (!quiz) viewBeforeQuiz = state.view;
    quiz = { feat: terr.feats[q.i], answered: false };
    if (state.tool === 'raise' || state.tool === 'dig') setTool('look');
    setView('map');
    $('quizQ').innerHTML = (q.type === 'steep' || q.type === 'gentle'
      ? '图中 <b class="qmark">?</b> 处的山坡是陡坡还是缓坡？'
      : '图中 <b class="qmark">?</b> 处是什么地形部位？') + '<br><span class="muted">先只看等高线判断，答完再看立体图验证。</span>';
    $('quizFb').textContent = '';
    qa('[data-ans]').forEach(function (b) { b.disabled = false; b.className = ''; });
    $('quizBtn').textContent = '换一题';
    $('quizEnd').hidden = false;
    if (window.matchMedia('(max-width: 760px)').matches) panel.classList.add('collapsed');
  }
  function answer(t) {
    if (!quiz || quiz.answered) return;
    var right = quiz.feat.type;
    quiz.answered = true;
    quiz.ok = t === right;
    score.n++; if (quiz.ok) score.ok++;
    qa('[data-ans]').forEach(function (b) {
      b.disabled = true;
      if (b.dataset.ans === right) b.className = 'right';
      else if (b.dataset.ans === t) b.className = 'wrong';
    });
    var F = T.FEAT[right];
    $('quizFb').innerHTML = (quiz.ok ? '<b class="ok">✓ 正确！</b>' : '<b class="bad">✗ 这里是「' + F.name + '」。</b>') +
      F.rule + '<br><span class="muted">已切到立体图对照验证。</span>';
    $('quizScore').textContent = '答对 ' + score.ok + ' / ' + score.n;
    $('quizBtn').textContent = '下一题';
    setView('split');
    Analytics.track('等高线', quiz.ok ? '答对' : '答错', right);
  }
  function endQuiz() {
    if (!quiz) return;
    quiz = null;
    if (viewBeforeQuiz) setView(viewBeforeQuiz);
    $('quizQ').textContent = '在平面图上标出一个位置，判断它是哪种地形部位。';
    $('quizFb').textContent = '';
    $('quizBtn').textContent = '开始练习';
    $('quizEnd').hidden = true;
    qa('[data-ans]').forEach(function (b) { b.disabled = true; b.className = ''; });
  }
  $('quizBtn').addEventListener('click', nextQuestion);
  $('quizEnd').addEventListener('click', endQuiz);

  // ---------- 读数 ----------
  var last = {};
  function setText(id, s) { if (last[id] !== s) { last[id] = s; $(id).textContent = s; } }
  function slopeWord(deg) {
    return deg < 5 ? '平缓' : deg < 15 ? '缓坡，等高线稀疏' : deg < 30 ? '较陡，等高线较密' : deg < 60 ? '陡坡，等高线密集' : '陡崖，等高线重叠';
  }
  function fmtKm(m) { return m >= 1000 ? (m / 1000).toFixed(2) + ' km' : Math.round(m) + ' m'; }

  function hiLevel() {
    if (!probe) return null;
    var L = Math.round(probe.h / state.interval) * state.interval;
    return L > 0 && L <= terr.max ? L : null;
  }

  function updateReadouts() {
    $('rElev').className = probe ? '' : 'muted';
    setText('rElev', probe ? '海拔 ' + Math.round(probe.h) + ' m' : '海拔 —');
    var tip;
    if (probe) {
      var lo = Math.floor(probe.h / state.interval) * state.interval;
      tip = '位于 ' + lo + ' m 与 ' + (lo + state.interval) + ' m 两条等高线之间';
    } else if (demo) tip = '演示中……';
    else if (quiz) tip = quiz.answered ? '在立体图上看看这个部位是什么样子。' : '根据等高线的形状和数值来判断。';
    else tip = '把指针移到立体图或平面图上查看海拔。';
    setText('rTip', tip);
    setText('rTerr', terr.edited ? '自己塑造的地形' : terr.name);
    setText('rInt', state.interval + ' m（相邻两条等高线的高差）');
    setText('rRange', '最高 ' + Math.round(terr.max) + ' m，最低 ' + Math.round(terr.min) + ' m，相对高度 ' + Math.round(terr.max - terr.min) + ' m');
    if (probe) {
      var d = T.slopeDeg(terr.h, probe.u, probe.v);
      setText('rSlope', Math.round(d) + '°（' + slopeWord(d) + '）');
    } else setText('rSlope', '—');
    if (prof) {
      setText('rProf', 'A ' + Math.round(prof.hA) + ' m → B ' + Math.round(prof.hB) + ' m，相对高度 ' + Math.round(Math.abs(prof.hA - prof.hB)) + ' m，水平距离 ' + fmtKm(prof.len));
      setText('rSight', prof.visible ? '✓ A、B 能互相看见' : '✗ 不能，被中间约 ' + Math.round(prof.block.h) + ' m 的高地挡住');
      $('rSight').className = prof.visible ? 'ok' : 'bad';
    } else {
      setText('rProf', '用「剖面线」工具在平面图上画一条');
      setText('rSight', '—');
      $('rSight').className = '';
    }
  }

  // ---------- 主循环 ----------
  setView(state.view);
  setTool(state.tool);
  setExag(state.exag);
  setWater(state.water);
  loadPreset(state.preset);
  layout();

  var lastT = performance.now(), time = 0, hintGone = false;
  function frame(t) {
    var dt = Math.min((t - lastT) / 1000, 0.1);
    lastT = t; time += dt;
    if (drag === 'brush' && brushAt) {
      T.brush(terr.h, brushAt[0], brushAt[1], state.brushR, (state.tool === 'raise' ? 1 : -1) * 420 * dt);
      markEdited();
      setProbe(brushAt);
    } else if (probe) probe.h = T.sample(terr.h, probe.u, probe.v);
    stepDemo(dt);
    if (captionTimer > 0) { captionTimer -= dt; if (captionTimer <= 0) say(''); }
    ensureContours();

    if (profile) {
      var pk = state.hVer + '|' + profile.A.join(',') + '|' + profile.B.join(',');
      if (pk !== profKey) { profKey = pk; prof = T.profile(terr.h, profile.A, profile.B); }
    } else { prof = null; profKey = ''; }
    var showProf = !!(prof && prof.len > 40);
    $('profBox').hidden = !showProf;
    stage.classList.toggle('has-prof', showProf);

    var ext = {
      k: state.exag, reveal: reveal, hi: hiLevel(), probe: probe, time: time, quiz: quiz,
      profile: profile && showProf ? { A: profile.A, B: profile.B, block: prof.block } : null,
      waterSegs: state.waterOn ? T.contour(terr.h, state.water) : null,
      brushR: state.tool === 'raise' || state.tool === 'dig' ? state.brushR : 0
    };
    if (state.view !== 'map') { s3.update(state, terr, ext); s3.render(dt); }
    if (state.view !== '3d') {
      m2.draw(state, terr, cont, ext);
      if (showProf) {
        window.Map2D.drawProfile($('prof'), prof, state.interval);
        setText('profInfo', prof.visible ? '· A、B 可以通视' : '· A、B 不能通视');
      }
    }
    // 用户开始操作后收起提示条
    if (!hintGone && (probe || profile || demo || quiz)) { hintGone = true; $('hint').hidden = true; }
    updateReadouts();
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // 调试用
  window.__model = {
    state: state, terr: function () { return terr; }, loadPreset: loadPreset, setView: setView, setExag: setExag,
    setProfile: function (A, B) { profile = { A: A, B: B }; }, startDemo: startDemo, stepDemo: stepDemo, nextQuestion: nextQuestion, answer: answer, s3: s3
  };
})();
