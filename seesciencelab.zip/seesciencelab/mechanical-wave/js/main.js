(function () {
  var M = window.MWave, D = window.MWaveDraw, f = M.f;
  var $ = function (id) { return document.getElementById(id); };
  var qa = function (sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); };
  var NAME = '机械波的形成与传播';

  var state = {
    scene: 'form', paused: false, dragging: false, slows: { form: 0.5, graph: 1 },
    // ① 波的形成：t 从波源起振开始计时；stepTo 为单步播放的目标时刻
    ft: 0, fT: 2, type: 'trans', start: 1, mark: 4, fvel: false, stepTo: null,
    // ② 波动图像与振动图像（x 单位 m，y 单位 cm）
    gt: 0, A: 5, lam: 4, T: 2, dir: 1, P: 3, vel: true, side: true, ghost: 0, XMAX: 12,
    // ③ 练习
    quiz: null, quizOnly: null, answered: false, correct: false, choice: null, qt: 0, score: { n: 0, ok: 0 }
  };
  var W = null;

  var HINTS = {
    form: '点一个质点做标记，看它怎样跟着前一个质点振动',
    graph: '左右拖动质点 P；改变波长、周期和传播方向',
    quiz: '看波形图作答，答完后波会动起来帮你验证'
  };

  var stage = $('stage'), panel = $('panel'), cv = $('view');
  var view = D.View(cv);
  function setSeg(attr, val) { qa('[data-' + attr + ']').forEach(function (b) { b.classList.toggle('on', b.dataset[attr] === String(val)); }); }
  function rebuild() { W = M.wave(state.A, state.lam, state.T, state.dir, 0); }

  // ---------- 控件 ----------
  qa('[data-scene]').forEach(function (b) {
    b.addEventListener('click', function () { setScene(b.dataset.scene); Analytics.track(NAME, '场景', b.textContent); });
  });
  function setScene(sc) {
    state.scene = sc; state.paused = false;
    if (sc === 'quiz' && !state.quiz) newQuiz();
    syncUI();
  }
  function seg(attr, apply, track) {
    qa('[data-' + attr + ']').forEach(function (b) {
      b.addEventListener('click', function () { apply(b.dataset[attr]); syncUI(); Analytics.track(NAME, track, b.textContent); });
    });
  }
  seg('type', function (v) { state.type = v; restartForm(); }, '波的类型');
  seg('start', function (v) { state.start = v === 'up' ? 1 : -1; restartForm(); }, '起振方向');
  seg('slow', function (v) { state.slows[state.scene] = parseFloat(v); }, '播放速度');
  seg('dir', function (v) { state.dir = v === 'right' ? 1 : -1; rebuild(); }, '传播方向');
  seg('ghost', function (v) { state.ghost = parseFloat(v); }, '平移法');
  function slider(id, read, after, track) {
    var el = $(id);
    el.addEventListener('input', function () { read(parseFloat(el.value)); after(); syncUI(); });
    el.addEventListener('change', function () { Analytics.track(NAME, '滑块', track); });
  }
  slider('fT', function (v) { state.ft *= v / state.fT; state.fT = v; state.stepTo = null; }, function () {}, '周期（形成）');
  slider('amp', function (v) { state.A = v; }, rebuild, '振幅');
  slider('lam', function (v) { state.lam = v; }, rebuild, '波长');
  slider('per', function (v) { state.T = v; }, rebuild, '周期');
  function check(id, key) {
    $(id).addEventListener('change', function () { state[key] = $(id).checked; syncUI(); Analytics.track(NAME, '开关', id + '=' + state[key]); });
  }
  check('c_fvel', 'fvel'); check('c_vel', 'vel'); check('c_side', 'side');

  function restartForm() { state.ft = 0; state.stepTo = null; state.paused = false; }
  qa('.play').forEach(function (b) { b.addEventListener('click', togglePause); });
  $('freset').addEventListener('click', function () { restartForm(); syncUI(); Analytics.track(NAME, '重新开始', ''); });
  $('fstep').addEventListener('click', function () {
    var q = state.fT / 4;
    state.stepTo = (Math.floor(state.ft / q + 1e-6) + 1) * q; state.paused = false;
    syncUI(); Analytics.track(NAME, '单步 T/4', '');
  });
  $('greset').addEventListener('click', function () { state.gt = 0; state.paused = true; syncUI(); });
  function togglePause() {
    if (state.scene === 'quiz') return;
    state.paused = !state.paused;
    if (!state.paused) state.stepTo = null;
    syncUI();
  }

  // 点上方质点做标记；拖动 P
  function pos(e) { var r = cv.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; }
  function dragP(e) {
    var h = view.lastHit();
    if (!h || h.kind !== 'P') return;
    state.P = M.clamp(Math.round(h.Xinv(pos(e)[0]) * 4) / 4, 0, state.XMAX);
    syncUI();
  }
  cv.addEventListener('pointerdown', function (e) {
    if (e.button !== 0) return;
    var p = pos(e), h = view.hitTest(p[0], p[1]);
    if (h && h.kind === 'medium') {
      var i = Math.round((p[0] - h.X0) / h.dx);
      if (i >= 0 && i < M.N) { state.mark = state.mark === i ? -1 : i; syncUI(); Analytics.track(NAME, '标记质点', String(i + 1)); return; }
    }
    if (h && h.kind === 'P') { state.dragging = true; cv.setPointerCapture(e.pointerId); dragP(e); return; }
    togglePause();
  });
  cv.addEventListener('pointermove', function (e) {
    if (state.dragging) { dragP(e); return; }
    var p = pos(e), h = view.hitTest(p[0], p[1]);
    cv.style.cursor = !h ? 'default' : h.kind === 'P' ? 'ew-resize' : 'pointer';
  });
  function endDrag(e) {
    if (!state.dragging) return;
    state.dragging = false;
    if (cv.hasPointerCapture(e.pointerId)) cv.releasePointerCapture(e.pointerId);
    Analytics.track(NAME, '拖动 P', f(state.P, 2) + ' m');
  }
  cv.addEventListener('pointerup', endDrag);
  cv.addEventListener('pointercancel', endDrag);

  // ---------- 练习 ----------
  function newQuiz() {
    state.quiz = M.quiz(Math.random, state.quiz, state.quizOnly);
    state.answered = false; state.choice = null; state.qt = 0;
    var box = $('quizOpts');
    box.innerHTML = '';
    state.quiz.options.forEach(function (o) {
      var b = document.createElement('button');
      b.className = 'small';
      b.textContent = o;
      b.addEventListener('click', function () { answer(o); });
      box.appendChild(b);
    });
    box.classList.toggle('four', state.quiz.options.length === 4 && state.quiz.options[0].length <= 2);
    syncUI();
  }
  function answer(o) {
    if (state.answered) return;
    state.answered = true; state.choice = o; state.qt = 0;
    state.correct = o === state.quiz.answer;
    state.score.n++; if (state.correct) state.score.ok++;
    Analytics.track(NAME, '练习', state.quiz.type + (state.correct ? ' 对' : ' 错'));
    syncUI();
  }
  $('nextQ').addEventListener('click', function () { newQuiz(); Analytics.track(NAME, '下一题', ''); });
  qa('[data-q]').forEach(function (b) {
    b.addEventListener('click', function () { state.quizOnly = b.dataset.q || null; newQuiz(); Analytics.track(NAME, '题型', b.textContent); });
  });

  // ---------- 面板 ----------
  $('panelToggle').addEventListener('click', function () { panel.classList.toggle('collapsed'); });
  if (window.matchMedia('(max-width: 760px)').matches) panel.classList.add('collapsed');
  window.addEventListener('keydown', function (e) {
    var tg = e.target.tagName;
    if (tg === 'INPUT' || tg === 'SELECT' || tg === 'BUTTON' || tg === 'TEXTAREA') return;
    if (e.code === 'Space') { e.preventDefault(); togglePause(); }
  });

  function syncUI() {
    var sc = state.scene;
    setSeg('scene', sc);
    qa('[data-for]').forEach(function (el) { el.hidden = el.dataset.for.split(' ').indexOf(sc) < 0; });
    $('hint').textContent = HINTS[sc];
    setSeg('type', state.type); setSeg('start', state.start > 0 ? 'up' : 'down'); setSeg('slow', state.slows[sc] || 1);
    setSeg('dir', state.dir > 0 ? 'right' : 'left'); setSeg('ghost', state.ghost); setSeg('q', state.quizOnly || '');
    $('fT').value = state.fT; $('fTOut').textContent = f(state.fT, 1) + ' s';
    $('amp').value = state.A; $('ampOut').textContent = f(state.A, 0) + ' cm';
    $('lam').value = state.lam; $('lamOut').textContent = f(state.lam, 1) + ' m';
    $('per').value = state.T; $('perOut').textContent = f(state.T, 1) + ' s';
    $('c_fvel').checked = state.fvel; $('c_vel').checked = state.vel; $('c_side').checked = state.side;
    $('c_fvel').parentNode.hidden = state.type !== 'trans';
    qa('.play').forEach(function (b) { b.textContent = state.paused ? '▶ 继续' : '❚❚ 暂停'; });
    if (sc === 'quiz' && state.quiz) {
      var q = state.quiz;
      $('quizQ').textContent = q.prompt;
      qa('#quizOpts button').forEach(function (b) {
        b.disabled = state.answered;
        b.classList.toggle('on', state.answered && b.textContent === q.answer);
        b.classList.toggle('no', state.answered && b.textContent === state.choice && !state.correct);
      });
      $('quizMsg').innerHTML = !state.answered ? ''
        : '<b class="' + (state.correct ? 'ok">✓ 答对了' : 'bad">✗ 应选「' + q.answer + '」') + '</b>' + q.explain;
      $('nextQ').textContent = state.answered ? '下一题 →' : '换一题';
    }
  }

  // ---------- 读数 ----------
  var lastText = {};
  function setText(id, s) { if (lastText[id] !== s) { lastText[id] = s; $(id).textContent = s; } }
  function list(items) {
    for (var k = 1; k <= 5; k++) {
      var r = items[k - 1] || ['', ''];
      setText('d' + k, r[0]); setText('r' + k, r[1]);
      $('d' + k).hidden = $('r' + k).hidden = !r[0];
    }
  }

  function readForm() {
    var T = state.fT, t = state.ft, fr = M.front(t, T), trans = state.type === 'trans', i = state.mark;
    var up = trans ? (state.start > 0 ? '向上' : '向下') : (state.start > 0 ? '向右' : '向左');
    setText('rName', trans ? '横波的形成' : '纵波的形成');
    setText('rKind', 't = ' + f(t / T, 2) + ' T');
    var tip;
    if (t <= 0) tip = '波源还没开始振动，所有质点都在平衡位置。';
    else if (fr < M.N - 1) tip = '波源每振动一个周期 T，振动就向前传播一个波长 λ（16 个质点间距）。新起振的质点都先' + up + '运动，与波源起振方向相同。';
    else tip = '波已传遍整排质点：每个质点都在自己的平衡位置附近做简谐运动，后一个质点比前一个落后 T/16，质点本身不随波迁移。';
    setText('rTip', tip);
    var mk = '—';
    if (i >= 0) {
      var t0 = i * T / M.LAM, v = M.formVel(i, t, T, state.start), y = M.formDisp(i, t, T, state.start);
      var st = t <= t0 ? '尚未振动（' + f(t0 / T, 3).replace(/0+$/, '').replace(/\.$/, '') + ' T 时起振）'
        : Math.abs(v) < 0.04 ? (y > 0 ? (trans ? '在波峰（最高点）' : '在最右端') : (trans ? '在波谷（最低点）' : '在最左端')) + '，速度为零'
        : (trans ? (v > 0 ? '向上' : '向下') : (v > 0 ? '向右' : '向左')) + '振动';
      mk = '质点 ' + (i + 1) + '：' + st;
    }
    list([
      ['波传到', '质点 ' + (Math.min(fr, M.N - 1) + 1) + (t > 0 ? '（传播了 ' + f(Math.min(fr, M.N - 1) / M.LAM, 2) + ' λ）' : '')],
      ['标记', mk],
      ['起振方向', '与波源相同：先' + up],
      ['周期', 'T = ' + f(T, 1) + ' s，每个质点的振动周期都等于波源的周期'],
      ['滞后', '相邻质点相差 T/16，相距 λ 的两质点步调完全一致']
    ]);
  }
  function readGraph() {
    var t = state.gt, P = state.P, y = W.y(P, t), md = M.moveDir(W, P, t), ss = M.slopeSide(W, P, t);
    setText('rName', 'v = λ/T = ' + f(W.v, 2) + ' m/s');
    setText('rKind', state.dir > 0 ? '沿 +x 传播' : '沿 −x 传播');
    var pm = md === 0 ? '质点 P 在' + (y > 0 ? '波峰' : '波谷') + '，速度为零，加速度最大、指向平衡位置。'
      : '沿传播方向看，P 在' + (ss > 0 ? '“上坡”，所以向下振动' : '“下坡”，所以向上振动') + '（上坡下、下坡上）。';
    setText('rTip', pm);
    var amax = W.w * W.w * W.A / 100;
    list([
      ['波长', 'λ = ' + f(state.lam, 1) + ' m，频率 f = ' + f(W.f, 2) + ' Hz'],
      ['波速', 'v = λf = ' + f(W.v, 2) + ' m/s，传播 ' + f(state.XMAX, 0) + ' m 用 ' + f(state.XMAX / W.v, 2) + ' s'],
      ['P 的位移', 'x = ' + f(P, 2) + ' m 处，y = ' + f(y, 2) + ' cm'],
      ['P 的速度', md === 0 ? '0' : (md > 0 ? '向上，' : '向下，') + f(Math.abs(W.vy(P, t)) / 100, 3) + ' m/s（最大 ' + f(W.A * W.w / 100, 3) + ' m/s）'],
      ['P 的加速度', Math.abs(y) < 1e-6 ? '0（在平衡位置）' : (y > 0 ? '向下' : '向上') + '，' + f(Math.abs(W.ay(P, t)) / 100, 2) + ' m/s²（最大 ' + f(amax, 2) + '）']
    ]);
  }
  function readQuiz() {
    var q = state.quiz;
    setText('rName', !state.answered ? '判断练习' : state.correct ? '✓ 答对了' : '✗ 答错了');
    $('rName').className = !state.answered ? '' : state.correct ? 'ok' : 'bad';
    setText('rKind', state.score.n ? '答对 ' + state.score.ok + ' / ' + state.score.n : '');
    setText('rTip', state.answered ? '看画面：波沿箭头方向平移，P 只上下振动。' : '题型：' + ({ dir: '判断质点振动方向', prop: '判断传播方向', calc: '读图求波速、频率', match: '选振动图像' })[q.type]);
    list([
      ['λ', state.answered || q.type !== 'calc' ? q.W.lam + ' m' : '由图读出'],
      ['T', q.type === 'calc' || state.answered ? q.W.T + ' s' : '—'],
      ['v', state.answered ? f(q.W.v, 2) + ' m/s' : '—']
    ]);
  }

  // ---------- 尺寸与主循环 ----------
  function resize() { view.resize(stage.clientWidth, stage.clientHeight); }
  new ResizeObserver(resize).observe(stage);

  // 支持 ?scene=form|graph|quiz；形成 &type=trans|long、&start=up|down、&mark=1~37（0 不标记）、&T=1~4（s）；
  // 图像 &A=1~10（cm）、&lam=1~8（m）、&per=0.5~4（s）、&dir=right|left、&P=0~12（m）、&ghost=0|0.25|0.5|0.75（×T）、&vel=0、&side=0；
  // 练习 &q=dir|prop|calc|match、&ans=1（直接显示答案）；通用 &slow=1|0.5|0.25、&t=（秒，停在该时刻）
  var qs = new URLSearchParams(location.search), x;
  if (HINTS[qs.get('scene')]) state.scene = qs.get('scene');
  if (qs.get('type') === 'long' || qs.get('type') === 'trans') state.type = qs.get('type');
  if (qs.get('start') === 'down') state.start = -1;
  x = parseInt(qs.get('mark'), 10); if (x >= 0 && x <= M.N) state.mark = x - 1;
  x = parseFloat(qs.get('T')); if (x >= 1 && x <= 4) state.fT = Math.round(x * 2) / 2;
  x = parseFloat(qs.get('A')); if (x >= 1 && x <= 10) state.A = Math.round(x);
  x = parseFloat(qs.get('lam')); if (x >= 1 && x <= 8) state.lam = Math.round(x * 2) / 2;
  x = parseFloat(qs.get('per')); if (x >= 0.5 && x <= 4) state.T = Math.round(x * 10) / 10;
  if (qs.get('dir') === 'left') state.dir = -1;
  x = parseFloat(qs.get('P')); if (x >= 0 && x <= 12) state.P = Math.round(x * 4) / 4;
  x = parseFloat(qs.get('ghost')); if ([0, 0.25, 0.5, 0.75].indexOf(x) >= 0) state.ghost = x;
  if (qs.get('vel') === '0') state.vel = false;
  if (qs.get('side') === '0') state.side = false;
  if (M.TYPES.indexOf(qs.get('q')) >= 0) state.quizOnly = qs.get('q');
  x = parseFloat(qs.get('slow')); if ([1, 0.5, 0.25].indexOf(x) >= 0 && state.scene !== 'quiz') state.slows[state.scene] = x;

  rebuild();
  resize();
  setScene(state.scene);
  if (state.scene === 'quiz' && qs.get('ans') === '1') answer(state.quiz.answer);
  x = parseFloat(qs.get('t'));
  if (x >= 0 && state.scene !== 'quiz') { if (state.scene === 'form') state.ft = x; else state.gt = x; state.paused = true; syncUI(); }

  var lastT = performance.now();
  function frame(now) {
    var raw = Math.min((now - lastT) / 1000, 0.1), sc = state.scene;
    lastT = now;
    if (sc === 'form') {
      if (!state.paused) {
        state.ft += raw * state.slows.form;
        if (state.stepTo != null && state.ft >= state.stepTo) { state.ft = state.stepTo; state.stepTo = null; state.paused = true; syncUI(); }
      }
      view.drawForm({ t: state.ft, T: state.fT, start: state.start, type: state.type, mark: state.mark, vel: state.fvel });
      readForm();
    } else if (sc === 'graph') {
      if (!state.paused && !state.dragging) state.gt += raw * state.slows.graph;
      view.drawGraph({ W: W, t: state.gt, P: state.P, vel: state.vel, side: state.side, ghost: state.ghost * state.T, xmax: state.XMAX });
      readGraph();
    } else {
      if (state.answered) state.qt += raw * 0.5;
      view.drawQuiz(state.quiz, state.answered, { t: state.qt, quizH: $('quizBar').offsetHeight });
      readQuiz();
    }
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // 调试用
  window.__model = {
    state: state, setScene: setScene, syncUI: syncUI,
    setForm: function (type, start, T) { if (type) state.type = type; if (start) state.start = start; if (T) state.fT = T; restartForm(); syncUI(); },
    setWave: function (A, lam, T, dir) { state.A = A; state.lam = lam; state.T = T; if (dir) state.dir = dir; rebuild(); syncUI(); },
    setT: function (t) { if (state.scene === 'form') state.ft = t; else state.gt = t; state.paused = true; syncUI(); },
    newQuiz: newQuiz, answer: function (o) { answer(o == null ? state.quiz.answer : o); }
  };
})();
