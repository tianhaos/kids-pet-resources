// 2D 绘制：① 波的形成（一排质点 + 每隔 T/4 的分镜，横波 / 纵波）② 波动图像 y-x 与质点 P 的振动图像 y-t ③ 判断练习
// 屏幕坐标 y 向下；稳定波的 x 单位 m、y 单位 cm，在 mwave.js 里计算，这里只做换算
(function () {
  var M = window.MWave, f = M.f;
  var MUTED = '#8d99ab', TEXT = '#e6ebf2', GRID = 'rgba(141,153,171,.14)', LINE = '#4a5670';
  var GOLD = '#ffc94a', VEL = '#4fc3f7', GREEN = '#7ee081', MARK = '#ff7a59', GHOST = 'rgba(200,210,225,.5)', IDLE = '#56627a';
  var FONT = '-apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", sans-serif';

  function font(px, w) { return (w ? w + ' ' : '') + px + 'px ' + FONT; }
  function label(ctx, s, x, y, o) {
    o = o || {};
    ctx.font = font(o.size || 12, o.bold ? 600 : null);
    ctx.textAlign = o.align || 'center'; ctx.textBaseline = o.base || 'middle';
    ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(5,7,13,.85)'; ctx.strokeText(s, x, y);
    ctx.fillStyle = o.color || TEXT; ctx.fillText(s, x, y);
  }
  function arrow(ctx, x1, y1, x2, y2, color, o) {
    o = o || {};
    var a = Math.atan2(y2 - y1, x2 - x1), len = Math.hypot(x2 - x1, y2 - y1), size = Math.min(o.size || 9, len * 0.6);
    if (len < 2) return;
    ctx.strokeStyle = ctx.fillStyle = color; ctx.lineWidth = o.width || 2.2; ctx.setLineDash(o.dash || []);
    ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2 - Math.cos(a) * size * 0.6, y2 - Math.sin(a) * size * 0.6); ctx.stroke();
    ctx.setLineDash([]);
    ctx.beginPath();
    ctx.moveTo(x2, y2);
    ctx.lineTo(x2 - size * Math.cos(a - 0.42), y2 - size * Math.sin(a - 0.42));
    ctx.lineTo(x2 - size * Math.cos(a + 0.42), y2 - size * Math.sin(a + 0.42));
    ctx.closePath(); ctx.fill();
  }
  function line(ctx, x1, y1, x2, y2, color, o) {
    o = o || {};
    ctx.strokeStyle = color; ctx.lineWidth = o.width || 1.2; ctx.setLineDash(o.dash || []);
    ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke(); ctx.setLineDash([]);
  }
  function dot(ctx, x, y, r, color) { ctx.fillStyle = color; ctx.beginPath(); ctx.arc(x, y, r, 0, 2 * Math.PI); ctx.fill(); }
  function ring(ctx, x, y, r, color) { ctx.strokeStyle = color; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(x, y, r, 0, 2 * Math.PI); ctx.stroke(); }
  // 两端带箭头的标注线，文字放在中点外侧
  function dim(ctx, x1, y1, x2, y2, color, text, nx, ny) {
    var len = Math.hypot(x2 - x1, y2 - y1);
    if (len > 16) {
      var mx = (x1 + x2) / 2, my = (y1 + y2) / 2;
      arrow(ctx, mx, my, x1, y1, color, { width: 1, size: 6 }); arrow(ctx, mx, my, x2, y2, color, { width: 1, size: 6 });
    } else line(ctx, x1, y1, x2, y2, color);
    if (text) label(ctx, text, (x1 + x2) / 2 + (nx || 0), (y1 + y2) / 2 + (ny || 0), { size: 11, color: color });
  }
  function niceStep(range, n) {
    var raw = range / n, p = Math.pow(10, Math.floor(Math.log10(raw))), m = raw / p;
    return (m < 1.5 ? 1 : m < 3.5 ? 2 : m < 7.5 ? 5 : 10) * p;
  }
  function dec(step) { return step >= 1 ? 0 : Math.min(3, Math.ceil(-Math.log10(step) - 1e-9)); }
  var FRAC = ['0', 'T/4', 'T/2', '3T/4', 'T'];

  function View(canvas) {
    var ctx = canvas.getContext('2d'), W = 0, H = 0, dpr = 1, narrow = false;
    var hit = null;   // 当前可拖动 / 可点击的对象，main.js 用来判断按下的位置
    function resize(w, h) {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      W = w; H = h; narrow = w < 640;
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
      canvas.style.width = w + 'px'; canvas.style.height = h + 'px';
    }
    function bg() {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      var g = ctx.createLinearGradient(0, 0, 0, H);
      g.addColorStop(0, '#04060c'); g.addColorStop(1, '#0a1120');
      ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
      hit = null;
    }
    function top0() { return narrow ? 50 : 44; }

    // 通用的直角坐标图：R 区域，o = { x0, x1, y0, y1, xl, yl, title, xs, ys }，返回 X(x)、Y(y) 及反算 Xinv
    function axes(R, o) {
      var pl = 40, pr = 18, pt = o.title ? 28 : 12, pb = 24;
      var X = function (v) { return R.x + pl + (v - o.x0) / (o.x1 - o.x0) * (R.w - pl - pr); };
      var Xinv = function (px) { return o.x0 + (px - R.x - pl) / (R.w - pl - pr) * (o.x1 - o.x0); };
      var Y = function (v) { return R.y + R.h - pb - (v - o.y0) / (o.y1 - o.y0) * (R.h - pt - pb); };
      ctx.fillStyle = 'rgba(17,23,35,.55)'; ctx.fillRect(R.x, R.y, R.w, R.h);
      ctx.strokeStyle = LINE; ctx.lineWidth = 1; ctx.strokeRect(R.x + .5, R.y + .5, R.w - 1, R.h - 1);
      if (o.title) label(ctx, o.title, R.x + 10, R.y + 14, { align: 'left', size: 12, color: o.titleColor || MUTED });
      var xs = o.xs || niceStep(o.x1 - o.x0, Math.max(3, Math.floor(R.w / 70))), ys = o.ys || niceStep(o.y1 - o.y0, Math.max(2, Math.floor(R.h / 40)));
      var v, y0 = o.y0 <= 0 && o.y1 >= 0 ? 0 : o.y0;
      for (v = Math.ceil(o.x0 / xs - 1e-9) * xs; v <= o.x1 + 1e-9; v += xs) {
        line(ctx, X(v), Y(o.y0), X(v), Y(o.y1), GRID);
        if (Math.abs(v) > 1e-9) label(ctx, o.xfmt ? o.xfmt(v) : f(v, dec(xs)), X(v), Y(y0) + 11, { size: 10, color: MUTED });
      }
      for (v = Math.ceil(o.y0 / ys - 1e-9) * ys; v <= o.y1 + 1e-9; v += ys) {
        line(ctx, X(o.x0), Y(v), X(o.x1), Y(v), GRID);
        label(ctx, f(v, dec(ys)), X(o.x0) - 6, Y(v), { size: 10, color: MUTED, align: 'right' });
      }
      arrow(ctx, X(o.x0), Y(y0), X(o.x1) + 12, Y(y0), MUTED, { width: 1, size: 6 });
      arrow(ctx, X(o.x0), Y(o.y0), X(o.x0), Y(o.y1) - 8, MUTED, { width: 1, size: 6 });
      if (o.xl) label(ctx, o.xl, X(o.x1) + 10, Y(y0) - 11, { size: 11, color: MUTED, align: 'right' });
      if (o.yl) label(ctx, o.yl, X(o.x0) + 6, Y(o.y1) - 2, { size: 11, color: MUTED, align: 'left' });
      return { X: X, Y: Y, Xinv: Xinv };
    }
    function curve(fn, t0, t1, n, color, o) {
      o = o || {};
      ctx.strokeStyle = color; ctx.lineWidth = o.width || 2; ctx.setLineDash(o.dash || []);
      ctx.beginPath();
      for (var i = 0; i <= n; i++) { var p = fn(t0 + (t1 - t0) * i / n); if (i) ctx.lineTo(p[0], p[1]); else ctx.moveTo(p[0], p[1]); }
      ctx.stroke(); ctx.setLineDash([]);
    }

    // ---------- ① 波的形成 ----------
    // 一排质点：R 区域，t、T、start、type、mark（标记的质点编号，−1 不标），big 为上方大图（画波源、编号、速度箭头）
    function medium(R, o, big) {
      var N = M.N, L = o.type === 'trans' ? 64 : 100, Rr = 18, dx = (R.w - L - Rr) / (N - 1), cy = R.y + R.h / 2;
      var X = function (i) { return R.x + L + i * dx; };
      var fr = M.front(o.t, o.T), started = o.t > 0;
      var i, xs = [], ys = [];
      if (o.type === 'trans') {
        var Ay = Math.min(R.h * (big ? 0.34 : 0.3), big ? 70 : 36);
        for (i = 0; i < N; i++) { xs.push(X(i)); ys.push(cy - Ay * M.formDisp(i, o.t, o.T, o.start)); }
        line(ctx, X(0) - 8, cy, X(N - 1) + 8, cy, 'rgba(141,153,171,.35)', { dash: [4, 4] });
        // 绳
        ctx.strokeStyle = 'rgba(185,195,211,.55)'; ctx.lineWidth = big ? 1.6 : 1.2; ctx.beginPath();
        for (i = 0; i < N; i++) { if (i) ctx.lineTo(xs[i], ys[i]); else ctx.moveTo(xs[i], ys[i]); }
        ctx.stroke();
        if (big && o.mark >= 0) {   // 标记质点：竖直导轨，只上下振动、不随波迁移
          line(ctx, X(o.mark), cy - Ay - 10, X(o.mark), cy + Ay + 10, 'rgba(255,122,89,.45)', { dash: [3, 3] });
        }
        if (big) {   // 手 / 振源
          var hy = ys[0];
          ctx.fillStyle = '#3a4560'; ctx.fillRect(X(0) - 30, hy - 9, 22, 18);
          line(ctx, X(0) - 8, hy, X(0), hy, '#b9c3d3', { width: 2 });
          label(ctx, '波源', X(0) - 19, cy - Ay - 14, { size: 11, color: MUTED });
          line(ctx, X(0) - 19, cy - Ay - 4, X(0) - 19, cy + Ay + 4, 'rgba(141,153,171,.4)');
        }
        for (i = 0; i < N; i++) {
          var on = o.t > i * o.T / M.LAM;
          dot(ctx, xs[i], ys[i], big ? (dx > 14 ? 4.5 : 3.5) : 2.6, on ? GOLD : IDLE);
          if (big && o.vel && on && i < N) {
            var vv = M.formVel(i, o.t, o.T, o.start);
            if (Math.abs(vv) > 0.06 && i % 2 === 0) arrow(ctx, xs[i], ys[i], xs[i], ys[i] - vv * 26, VEL, { width: 1.6, size: 6 });
          }
        }
        if (big && o.mark >= 0) ring(ctx, xs[o.mark], ys[o.mark], dx > 14 ? 9 : 7, MARK);
      } else {
        // 纵波：几排质点同步左右振动，位移按 1.8 格（最大应变约 0.7，质点不交叉）
        var Ax = dx * 1.8, rows = big ? 7 : 3, gap = Math.min(big ? 12 : 7, (R.h - 10) / rows);
        if (big) {   // 活塞
          var px = X(0) - 10 + Ax * M.formDisp(0, o.t, o.T, o.start);
          ctx.fillStyle = '#3a4560'; ctx.fillRect(px - 8, cy - rows * gap / 2 - 6, 8, rows * gap + 12);
          line(ctx, px - 8, cy, px - 26, cy, '#b9c3d3', { width: 3 });
          label(ctx, '波源', X(0) - 26, cy + rows * gap / 2 + 18, { size: 11, color: MUTED });
        }
        for (i = 0; i < N; i++) xs.push(X(i) + Ax * M.formDisp(i, o.t, o.T, o.start));
        for (var r = 0; r < rows; r++) {
          var yy = cy + (r - (rows - 1) / 2) * gap;
          for (i = 0; i < N; i++) {
            var on2 = o.t > i * o.T / M.LAM;
            dot(ctx, xs[i], yy, big ? 2.8 : 1.9, on2 ? GOLD : IDLE);
          }
        }
        if (big && o.mark >= 0) {
          line(ctx, X(o.mark), cy - rows * gap / 2 - 10, X(o.mark), cy + rows * gap / 2 + 10, 'rgba(255,122,89,.45)', { dash: [3, 3] });
          ring(ctx, xs[o.mark], cy, 6, MARK);
          dot(ctx, xs[o.mark], cy, 2.8, MARK);
        }
        // 密部、疏部：相邻质点间距的局部极小 / 极大
        if (fr >= 4) {
          var sp = [];
          for (i = 0; i < N - 1; i++) sp.push(xs[i + 1] - xs[i]);
          for (i = 1; i < Math.min(fr, N - 2); i++) {
            var lo = sp[i] <= sp[i - 1] && sp[i] < sp[i + 1] && sp[i] < dx * 0.55;
            var hi = sp[i] >= sp[i - 1] && sp[i] > sp[i + 1] && sp[i] > dx * 1.45;
            if (lo || hi) {
              var mx = (xs[i] + xs[i + 1]) / 2;
              label(ctx, lo ? '密' : '疏', mx, cy - rows * gap / 2 - (big ? 14 : 8), { size: big ? 12 : 10, color: lo ? GOLD : MUTED, bold: lo });
            }
          }
        }
      }
      // 波前与传播方向
      if (big && started && fr < N - 1) {
        var fx = X(fr) + dx * 0.5, ay = R.y + 8;
        arrow(ctx, fx - 4, ay, fx + 34, ay, GREEN, { width: 2 });
        label(ctx, '波前', fx - 8, ay, { size: 11, color: GREEN, align: 'right' });
      }
      if (big) {   // 编号（课本：质点 1、5、9、13、17…）
        var by = R.y + R.h - 8;
        for (i = 0; i < N; i += 4) label(ctx, String(i + 1), X(i), by, { size: 10, color: i === o.mark ? MARK : MUTED });
      }
      return { X: X, dx: dx, cy: cy };
    }

    // o = { t, T, start, type, mark, vel }
    function drawForm(o) {
      bg();
      var top = top0(), bottom = 40;
      var avail = H - top - bottom, Hl = Math.max(140, Math.min(avail * 0.42, 290));
      var R = { x: 10, y: top, w: W - 20, h: Hl };
      ctx.fillStyle = 'rgba(17,23,35,.35)'; ctx.fillRect(R.x, R.y, R.w, R.h);
      label(ctx, (o.type === 'trans' ? '横波：质点振动方向 ⊥ 传播方向' : '纵波：质点振动方向 ∥ 传播方向'), R.x + 10, R.y + 14, { align: 'left', size: 12, color: MUTED });
      label(ctx, 't = ' + f(o.t / o.T, 2) + ' T', R.x + R.w - 10, R.y + 14, { align: 'right', size: 12, color: TEXT });
      var g = medium({ x: R.x, y: R.y + 18, w: R.w, h: R.h - 18 }, o, true);
      hit = { kind: 'medium', X0: g.X(0), dx: g.dx, y0: R.y, y1: R.y + R.h };

      // 分镜：t = 0、T/4、T/2、3T/4、T（与课本插图一致，上下对齐）
      var sy = R.y + R.h + 12, rest = H - bottom - sy;
      if (rest < 120) return;
      var rh = rest / 5, cur = Math.round(o.t / (o.T / 4));
      var showCur = cur <= 4 && Math.abs(o.t - cur * o.T / 4) < o.T * 0.02;
      label(ctx, '每隔 T/4 的分镜（与上方质点一一对齐）', R.x + 10, sy + 2, { align: 'left', size: 11, color: MUTED });
      for (var k = 0; k <= 4; k++) {
        var rr = { x: R.x, y: sy + 8 + k * rh, w: R.w, h: rh - 4 };
        if (showCur && k === cur) { ctx.fillStyle = 'rgba(255,201,74,.08)'; ctx.fillRect(rr.x, rr.y, rr.w, rr.h); }
        var gg = medium(rr, { t: k * o.T / 4, T: o.T, start: o.start, type: o.type, mark: -1 }, false);
        label(ctx, 't = ' + FRAC[k], rr.x + 6, rr.y + rr.h / 2, { align: 'left', size: 11, color: showCur && k === cur ? GOLD : MUTED });
        if (o.mark >= 0) line(ctx, gg.X(o.mark), rr.y + 2, gg.X(o.mark), rr.y + rr.h - 2, 'rgba(255,122,89,.3)', { dash: [2, 3] });
        // 波前位置的竖线：每 T/4 前进 λ/4
        var fx = gg.X(k * M.LAM / 4);
        if (k > 0) line(ctx, fx, rr.y + 3, fx, rr.y + rr.h - 3, 'rgba(126,224,129,.4)', { dash: [2, 3] });
      }
    }

    // ---------- ② 波动图像与振动图像 ----------
    // 波形图：R 区域，Wv 波，t 时刻，xmax，opts = { P, vel, side, ghost（Δt，s，0 不画）, hideDir, dots, title, Amax }
    function waveGraph(R, Wv, t, xmax, op) {
      var Amax = op.Amax || 10;
      var g = axes(R, { x0: 0, x1: xmax, y0: -Amax * 1.25, y1: Amax * 1.25, ys: Amax >= 10 ? 5 : niceStep(Amax, 2), xl: 'x/m', yl: 'y/cm', title: op.title, titleColor: TEXT, xs: xmax <= 4 ? 0.5 : xmax <= 8 ? 1 : 2 });
      var X = g.X, Y = g.Y;
      if (op.ghost) {
        curve(function (x) { return [X(x), Y(Wv.y(x, t + op.ghost))]; }, 0, xmax, 300, GHOST, { width: 1.6, dash: [6, 5] });
      }
      curve(function (x) { return [X(x), Y(Wv.y(x, t))]; }, 0, xmax, 400, GOLD, { width: 2.2 });
      // 平移法：一个波峰随波移动 vΔt
      if (op.ghost) {
        var dX = Wv.dir * Wv.v * op.ghost, base = M.mod((Math.PI / 2 - Wv.psi) / Wv.k + Wv.dir * Wv.v * t, Wv.lam), xc = -1;
        for (var n = 0; n * Wv.lam + base <= xmax; n++) {
          var c = base + n * Wv.lam;
          if (c + dX >= 0.05 && c + dX <= xmax - 0.05) { xc = c; break; }
        }
        if (xc >= 0 && xc <= xmax) {
          var x2 = xc + Wv.dir * Wv.v * op.ghost, yy = Y(Wv.A) - 12;
          if (Math.abs(X(x2) - X(xc)) > 10) arrow(ctx, X(xc), yy, X(x2), yy, MUTED, { width: 1.4, size: 7 });
          label(ctx, 'Δx = vΔt', (X(xc) + X(x2)) / 2, yy - 10, { size: 11, color: MUTED });
        }
      }
      // 介质质点（每 λ/8 一个），速度箭头
      if (op.dots) {
        var stepX = Wv.lam / 8;
        for (var x = 0; x <= xmax + 1e-9; x += stepX) {
          var px = X(x), py = Y(Wv.y(x, t));
          dot(ctx, px, py, 2.6, '#f3d58a');
          if (op.vel) {
            var vr = Wv.vy(x, t) / (Wv.A * Wv.w);
            if (Math.abs(vr) > 0.08) arrow(ctx, px, py, px, py - vr * 24, VEL, { width: 1.5, size: 6 });
          }
        }
      }
      // λ 与 A 标注
      var xc0 = M.mod((Math.PI / 2 - Wv.psi) / Wv.k + Wv.dir * Wv.v * t, Wv.lam);
      if (xc0 + Wv.lam > xmax) xc0 -= Wv.lam;
      if (xc0 >= -1e-9 && xc0 + Wv.lam <= xmax + 1e-9 && op.marks !== false) {
        var ly = Y(Wv.A) - 8;
        line(ctx, X(xc0), Y(Wv.A), X(xc0), ly - 6, 'rgba(255,201,74,.4)', { dash: [2, 3] });
        line(ctx, X(xc0 + Wv.lam), Y(Wv.A), X(xc0 + Wv.lam), ly - 6, 'rgba(255,201,74,.4)', { dash: [2, 3] });
        if (!op.ghost) dim(ctx, X(xc0), ly - 2, X(xc0 + Wv.lam), ly - 2, GOLD, 'λ', 0, -9);
        dim(ctx, X(xc0) - 0, Y(0), X(xc0) - 0, Y(Wv.A), GOLD, 'A', 10, 0);
      }
      // 传播方向
      if (!op.hideDir) {
        var ax = X(xmax) - 60, ay = R.y + (narrow ? 44 : 14);
        arrow(ctx, ax - Wv.dir * 30, ay, ax + Wv.dir * 30, ay, GREEN, { width: 2.2 });
        label(ctx, 'v', ax + Wv.dir * 42, ay, { color: GREEN, bold: true });
      }
      // 质点 P
      if (op.P != null) {
        var Px = X(op.P), Py = Y(Wv.y(op.P, t));
        line(ctx, Px, Y(-Amax * 1.25), Px, Y(Amax * 1.25), 'rgba(255,122,89,.3)', { dash: [3, 3] });
        dot(ctx, Px, Py, 5.5, MARK);
        label(ctx, 'P', Px + 10, Py - 12, { color: MARK, bold: true, size: 13 });
        if (op.pArrow) {   // 质点 P 的振动方向
          var md = M.moveDir(Wv, op.P, t);
          if (md) {
            arrow(ctx, Px, Py, Px, Py - md * 34, VEL, { width: 2.4 });
            if (op.side) {   // 同侧法：振动方向箭头与传播方向箭头在波形同一侧
              arrow(ctx, Px, Py - md * 34, Px + Wv.dir * 34, Py - md * 34, GREEN, { width: 2, dash: [4, 3] });
              label(ctx, '同侧', Px + Wv.dir * 20, Py - md * 46, { size: 11, color: GREEN });
            }
          }
        }
      }
      return g;
    }
    function vibGraph(R, Wv, x, t, Amax, op) {
      op = op || {};
      var span = 2 * Wv.T;
      var g = axes(R, { x0: 0, x1: span, y0: -Amax * 1.25, y1: Amax * 1.25, ys: Amax >= 10 ? 5 : niceStep(Amax, 2), xl: 't/s', yl: 'y/cm', title: op.title, titleColor: op.titleColor, xs: niceStep(span, Math.max(4, Math.floor(R.w / 70))) });
      var X = g.X, Y = g.Y, tm = op.full ? span : M.mod(t, span);
      curve(function (s) { return [X(s), Y(Wv.y(x, s))]; }, 0, span, 240, op.full ? GOLD : 'rgba(255,201,74,.25)', { width: op.full ? 2 : 1.6 });
      if (!op.full) {
        curve(function (s) { return [X(s), Y(Wv.y(x, s))]; }, 0, tm, Math.max(2, Math.round(240 * tm / span)), MARK, { width: 2.2 });
        dot(ctx, X(tm), Y(Wv.y(x, tm)), 4.5, MARK);
        line(ctx, X(tm), Y(-Amax * 1.25), X(tm), Y(Amax * 1.25), 'rgba(255,122,89,.3)', { dash: [3, 3] });
      }
      // 标出周期 T
      var ly = Y(-Amax * 1.25) - 8;
      dim(ctx, X(0), ly, X(Wv.T), ly, MUTED, 'T = ' + f(Wv.T, 2) + ' s', 0, -9);
      return g;
    }

    // o = { W, t, P, vel, side, ghost, xmax }
    function drawGraph(o) {
      bg();
      var top = top0(), bottom = 40, gap = 12, avail = H - top - bottom - gap;
      var h1 = Math.round(avail * 0.56), h2 = avail - h1;
      var R1 = { x: 10, y: top, w: W - 20, h: h1 }, R2 = { x: 10, y: top + h1 + gap, w: W - 20, h: h2 };
      var g = waveGraph(R1, o.W, o.t, o.xmax, { P: o.P, vel: o.vel, side: o.side, ghost: o.ghost, dots: true, pArrow: true,
        title: (narrow ? '波动图像 y-x　t = ' + f(o.t, 2) + ' s' : '波动图像 y-x（t = ' + f(o.t, 2) + ' s 时各质点的位移）') + (o.ghost ? '　虚线：再过 Δt' : '') });
      hit = { kind: 'P', Xinv: g.Xinv, y0: R1.y, y1: R1.y + R1.h, X: g.X(o.P) };
      vibGraph(R2, o.W, o.P, o.t, 10, { title: narrow ? '质点 P 的振动图像 y-t' : '振动图像 y-t（质点 P 的位移随时间变化）', titleColor: MARK });
    }

    // ---------- ③ 练习 ----------
    // q 见 mwave.js 的 quiz()；answered 后波动起来（o.t）并显示答案
    function drawQuiz(q, answered, o) {
      bg();
      var top = top0(), bottom = (o.quizH || 120) + 56, avail = Math.max(160, H - top - bottom);
      var isMatch = q.type === 'match';
      var h1 = isMatch ? Math.round(avail * (narrow ? 0.42 : 0.5)) : Math.min(avail, 480);
      var R1 = { x: 10, y: top, w: W - 20, h: h1 };
      var t = answered ? o.t : 0;
      waveGraph(R1, q.W, t, q.xmax, {
        P: q.P, dots: false, Amax: q.W.A, hideDir: q.hideDir && !answered,
        pArrow: q.type === 'prop' || answered, side: answered && (q.type === 'dir' || q.type === 'prop'),
        marks: q.type !== 'calc' || answered,
        title: answered ? 't = ' + f(t, 2) + ' s（答完后波动起来验证）' : 't = 0 时的波形'
      });
      if (!isMatch) return;
      var y0 = top + h1 + 10, hh = avail - h1 - 10, cols = narrow ? 2 : 4, rows = 4 / cols;
      var cw = (W - 20 - (cols - 1) * 8) / cols, ch = (hh - (rows - 1) * 8) / rows;
      q.graphs.forEach(function (sh, i) {
        var R = { x: 10 + (i % cols) * (cw + 8), y: y0 + Math.floor(i / cols) * (ch + 8), w: cw, h: ch };
        var ok = answered && q.options[i] === q.answer;
        // 用一个“虚拟”的点画出 SHAPES[sh] 对应的 y-t：sin、−sin、cos、−cos
        var phi = [0, Math.PI, Math.PI / 2, 3 * Math.PI / 2][sh];
        var Wd = { A: q.W.A, T: q.W.T, y: function (x, s) { return q.W.A * Math.sin(2 * Math.PI * s / q.W.T + phi); } };
        vibGraph(R, Wd, 0, 0, q.W.A, { full: true, title: q.options[i], titleColor: ok ? GREEN : TEXT });
        if (ok) { ctx.strokeStyle = GREEN; ctx.lineWidth = 2; ctx.strokeRect(R.x + 1, R.y + 1, R.w - 2, R.h - 2); }
      });
    }

    return {
      resize: resize, drawForm: drawForm, drawGraph: drawGraph, drawQuiz: drawQuiz,
      lastHit: function () { return hit; },
      hitTest: function (x, y) { return hit && y >= hit.y0 && y <= hit.y1 ? hit : null; }
    };
  }

  window.MWaveDraw = { View: View };
})();
