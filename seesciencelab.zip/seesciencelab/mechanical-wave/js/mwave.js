// 机械波计算：波的形成（波源起振后波沿介质逐个带动质点）、稳定的简谐波（波动图像与振动图像）、判断练习
// 位移 y 向上为正（纵波里向右为正），传播方向 dir = +1 向右、−1 向左。不碰 DOM，便于 node 测试。
(function () {
  var PI = Math.PI, TAU = 2 * PI;

  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
  function f(v, d) {
    d = d == null ? 2 : d;
    var s = (Math.abs(v) < 0.5 * Math.pow(10, -d) ? 0 : v).toFixed(d);
    return s.replace('-', '−');
  }
  function mod(a, b) { return ((a % b) + b) % b; }

  // ---------- ① 波的形成 ----------
  // 一排质点，编号 i = 0…N−1，相邻间距 1 格；一个波长 LAM 格（课本：质点 1 到质点 17 恰好一个波长）。
  // 波源（质点 0）在 t = 0 开始振动，start = +1 先向上（纵波先向右）、−1 先向下；
  // 振动每经过一个周期 T 向前传播一个波长，质点 i 在 t = i·T/LAM 时开始振动，起振方向与波源相同。
  var N = 37, LAM = 16;
  function formDisp(i, t, T, start) {
    var t0 = i * T / LAM;
    if (t <= t0) return 0;
    return start * Math.sin(TAU * (t - t0) / T);
  }
  function formVel(i, t, T, start) {   // 归一化速度（振幅 1、ω = 2π/T 时 dy/dt 的 T/2π 倍）
    var t0 = i * T / LAM;
    if (t <= t0) return 0;
    return start * Math.cos(TAU * (t - t0) / T);
  }
  // 波传到的最远质点（波前）；t 之前还没开始振动的质点 y = 0
  function front(t, T) { return Math.min(N - 1, Math.floor(t / T * LAM + 1e-9)); }

  // ---------- ② 稳定的简谐波 ----------
  // w = { A（cm）, lam（m）, T（s）, dir, psi }，y(x, t) = A sin(k(x − dir·v·t) + psi)，k = 2π/λ，v = λ/T
  // t = 0 时波形为 y = A sin(kx + psi)；psi 取 0 或 π
  function wave(A, lam, T, dir, psi) {
    var k = TAU / lam, v = lam / T, w = TAU / T;
    psi = psi || 0;
    return {
      A: A, lam: lam, T: T, dir: dir, psi: psi, k: k, v: v, w: w, f: 1 / T,
      y: function (x, t) { return A * Math.sin(k * (x - dir * v * t) + psi); },
      // 质点振动速度（cm/s）与加速度（cm/s²）
      vy: function (x, t) { return -A * k * dir * v * Math.cos(k * (x - dir * v * t) + psi); },
      ay: function (x, t) { return -w * w * A * Math.sin(k * (x - dir * v * t) + psi); },
      // 波形的斜率 dy/dx（cm/m），用于“上下坡”判断
      slope: function (x, t) { return A * k * Math.cos(k * (x - dir * v * t) + psi); }
    };
  }
  // 质点振动方向：+1 向上、−1 向下、0 在最大位移处（速度为零）
  function moveDir(W, x, t) {
    var vy = W.vy(x, t), vmax = W.A * W.w;
    return Math.abs(vy) < vmax * 1e-6 ? 0 : vy > 0 ? 1 : -1;
  }
  // 沿传播方向看，质点处在“上坡”（+1）还是“下坡”（−1），上坡下、下坡上
  function slopeSide(W, x, t) {
    var s = W.dir * W.slope(x, t);
    return Math.abs(s) < W.A * W.k * 1e-6 ? 0 : s > 0 ? 1 : -1;
  }
  // y-t 的函数形式名：sin、−sin、cos、−cos（初相为 0、π、π/2、3π/2）
  var SHAPES = ['y = A sin ωt', 'y = −A sin ωt', 'y = A cos ωt', 'y = −A cos ωt'];
  function shapeOf(W, x) {
    // y(x, t) = A sin(−dir·ω·t + kx + ψ)，统一写成 A sin(ωt + φ)：
    // dir = −1 时 φ = kx + ψ；dir = +1 时 A sin(−(ωt − kx − ψ)) = A sin(ωt − kx − ψ + π)
    var phi = W.dir < 0 ? W.k * x + W.psi : PI - W.k * x - W.psi;
    phi = mod(phi, TAU);
    var q = Math.round(phi / (PI / 2)) % 4;   // 0 → sin，1 → cos，2 → −sin，3 → −cos
    if (Math.abs(phi - q * PI / 2) > 1e-6 && Math.abs(phi - TAU) > 1e-6) return -1;
    return [0, 2, 1, 3][q];
  }

  // ---------- ③ 练习 ----------
  // 四类题：dir 已知传播方向判断质点振动方向；prop 已知质点振动方向判断传播方向；
  // calc 由波动图像读波长、算波速或频率；match 选与质点对应的振动图像
  var TYPES = ['dir', 'prop', 'calc', 'match'];
  function pick(rnd, arr) { return arr[Math.floor(rnd() * arr.length) % arr.length]; }
  function quiz(rnd, prev, only) {
    var type = only && TYPES.indexOf(only) >= 0 ? only : pick(rnd, TYPES);
    if (!only && prev && prev.type === type) type = TYPES[(TYPES.indexOf(type) + 1 + Math.floor(rnd() * 3)) % 4];
    var lam = pick(rnd, [2, 4, 4, 8]), A = pick(rnd, [2, 4, 5, 10]), T = pick(rnd, [0.4, 0.5, 1, 2]);
    var dir = rnd() < 0.5 ? 1 : -1, psi = rnd() < 0.5 ? 0 : PI;
    var W = wave(A, lam, T, dir, psi), xmax = lam * 2;
    var q = { type: type, W: W, xmax: xmax, P: null, shown: true };
    var dirName = dir > 0 ? 'x 轴正方向' : 'x 轴负方向', P, md;
    // P 取在平衡位置附近的点（振动方向明确）或任意 λ/8 处的点，不取最大位移处
    function pickP() {
      var cands = [];
      for (var j = 1; j < 16; j++) {
        var x = j * lam / 8;
        if (moveDir(W, x, 0) !== 0) cands.push(x);
      }
      return pick(rnd, cands);
    }
    if (type === 'dir') {
      P = pickP(); md = moveDir(W, P, 0);
      q.P = P;
      q.prompt = '一列简谐横波沿 ' + dirName + '传播，t = 0 时的波形如图。此刻质点 P 向哪个方向振动？';
      q.options = ['向上（y 轴正方向）', '向下（y 轴负方向）'];
      q.answer = q.options[md > 0 ? 0 : 1];
      q.explain = '沿传播方向看，P 处在' + (slopeSide(W, P, 0) > 0 ? '“上坡”' : '“下坡”') + '（上坡下、下坡上），所以 P ' + (md > 0 ? '向上' : '向下')
        + '振动。也可以用平移法：把波形沿传播方向平移一小段，P 的新位置在' + (md > 0 ? '上方' : '下方') + '。';
    } else if (type === 'prop') {
      P = pickP(); md = moveDir(W, P, 0);
      q.P = P; q.hideDir = true;
      q.prompt = '一列简谐横波沿 x 轴传播，t = 0 时的波形如图，此刻质点 P 正' + (md > 0 ? '向上' : '向下') + '振动。这列波沿哪个方向传播？';
      q.options = ['沿 x 轴正方向', '沿 x 轴负方向'];
      q.answer = q.options[dir > 0 ? 0 : 1];
      q.explain = '同侧法：在 P 点，表示振动方向的竖直箭头和表示传播方向的水平箭头总在波形曲线的同一侧。P ' + (md > 0 ? '向上' : '向下')
        + '振动，所以波沿 ' + dirName + '传播。也可以想：P 总是重复它靠近波源一侧的邻近质点的振动。';
    } else if (type === 'calc') {
      var ask = rnd() < 0.5 ? 'v' : 'f';
      q.prompt = '一列简谐横波沿 ' + dirName + '传播，t = 0 时的波形如图，波源振动周期 T = ' + T + ' s。这列波的'
        + (ask === 'v' ? '波速' : '频率和波长') + '是？';
      var v = lam / T, fr = 1 / T, opts;
      var fv = function (x) { return f(x, x % 1 ? 1 : 0); };
      if (ask === 'v') {
        q.answer = fv(v) + ' m/s';
        opts = [v, v / 2, v * 2, lam * T, v * 4, v / 4].map(function (x) { return fv(x) + ' m/s'; });
        q.explain = '由图读出波长 λ = ' + lam + ' m（相邻两个波峰之间的距离），v = λ/T = ' + lam + ' m ÷ ' + T + ' s = ' + q.answer + '。';
      } else {
        var fs = function (x, l) { return 'f = ' + fv(x) + ' Hz，λ = ' + l + ' m'; };
        var fw = T === 1 ? 2 : T;   // 错把 T 当 f（T = 1 s 时换成 2 Hz）
        q.answer = fs(fr, lam);
        opts = [fs(fr, lam), fs(fr, lam / 2), fs(fw, lam), fs(fw, lam / 2)];
        q.explain = '频率 f = 1/T = ' + fv(fr) + ' Hz（由波源决定）；波长是一个完整波形的长度，图中 2 个完整波形占 ' + xmax + ' m，所以 λ = ' + lam + ' m。';
      }
      q.options = opts.filter(function (o, i) { return opts.indexOf(o) === i; }).slice(0, 4);
      q.options = shuffle(rnd, q.options);
    } else {
      // match：P 取在平衡位置或最大位移处，对应四种标准图像
      var c2 = [];
      for (var j2 = 0; j2 < 16; j2++) { var xx = j2 * lam / 4; if (xx > 0 && xx < xmax) c2.push(xx); }
      P = pick(rnd, c2);
      q.P = P;
      q.prompt = '一列简谐横波沿 ' + dirName + '传播，t = 0 时的波形如图。下面哪一个是质点 P 的振动图像？';
      q.options = ['A', 'B', 'C', 'D'];
      q.graphs = shuffle(rnd, [0, 1, 2, 3]);   // 选项 A～D 分别画哪种 y-t 图像（SHAPES 的下标）
      var sh = shapeOf(W, P);
      q.answer = q.options[q.graphs.indexOf(sh)];
      md = moveDir(W, P, 0);
      var yP = W.y(P, 0);
      q.explain = 't = 0 时 P ' + (md === 0 ? '在' + (yP > 0 ? '正' : '负') + '向最大位移处，速度为零，接下来向平衡位置运动'
        : '在平衡位置，沿传播方向看处在' + (slopeSide(W, P, 0) > 0 ? '上坡，向下' : '下坡，向上') + '振动')
        + '，所以振动图像从 ' + (md === 0 ? (yP > 0 ? 'y = A' : 'y = −A') : 'y = 0 ' + (md > 0 ? '向上' : '向下')) + ' 开始，选 ' + q.answer + '（' + SHAPES[sh] + '）。';
    }
    return q;
  }
  function shuffle(rnd, a) {
    a = a.slice();
    for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(rnd() * (i + 1)); var t = a[i]; a[i] = a[j]; a[j] = t; }
    return a;
  }

  window.MWave = {
    N: N, LAM: LAM, formDisp: formDisp, formVel: formVel, front: front,
    wave: wave, moveDir: moveDir, slopeSide: slopeSide, shapeOf: shapeOf, SHAPES: SHAPES,
    quiz: quiz, TYPES: TYPES, clamp: clamp, f: f, mod: mod
  };
})();
