// 2D 绘制：蹄形磁体与导体 AB（斜二测投影）、条形磁铁与线圈、灵敏电流计、磁通量与电流图像、练习题画面
// 世界坐标同 Induct（单位 cm，y 向上）；frame(R, box) 把世界范围 box 等比放进屏幕矩形 R
(function () {
  var M = window.Induct, CUT = M.CUT, COIL = M.COIL;
  var N_COL = '#db6258', S_COL = '#487bd2', B_COL = '#819acf', V_COL = '#7ee081', I_COL = '#ffc94a', F_COL = '#ff7a59';
  var CU = '#d89655', MUTED = '#a5b3c5', TEXT = '#e6ebf2', LINE = '#2a3446';
  var FONT = '-apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", sans-serif';
  var OX = -0.45, OY = -0.25;     // 场景一斜二测：z 轴（指向观察者）画向左下
  var CX = 0.3, CY = -0.1;        // 线圈：z 轴画向右下，圆环看成窄椭圆

  function font(px, w) { return (w ? w + ' ' : '') + px + 'px ' + FONT; }
  function label(ctx, s, x, y, o) {
    o = o || {};
    ctx.font = font(o.size || 12, o.bold ? 600 : null);
    ctx.textAlign = o.align || 'center'; ctx.textBaseline = o.base || 'middle';
    ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(5,7,13,.85)'; ctx.strokeText(s, x, y);
    ctx.fillStyle = o.color || TEXT; ctx.fillText(s, x, y);
  }
  function arrow(ctx, x1, y1, x2, y2, size, color, width) {
    var a = Math.atan2(y2 - y1, x2 - x1);
    ctx.strokeStyle = ctx.fillStyle = color; ctx.lineWidth = width || 2.4; ctx.setLineDash([]);
    ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2 - Math.cos(a) * size * 0.6, y2 - Math.sin(a) * size * 0.6); ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(x2, y2);
    ctx.lineTo(x2 - size * Math.cos(a - 0.42), y2 - size * Math.sin(a - 0.42));
    ctx.lineTo(x2 - size * Math.cos(a + 0.42), y2 - size * Math.sin(a + 0.42));
    ctx.closePath(); ctx.fill();
  }
  function head(ctx, x, y, a, size, color) {
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.moveTo(x + Math.cos(a) * size * 0.6, y + Math.sin(a) * size * 0.6);
    ctx.lineTo(x - size * Math.cos(a - 0.5) * 0.6, y - size * Math.sin(a - 0.5) * 0.6);
    ctx.lineTo(x - size * Math.cos(a + 0.5) * 0.6, y - size * Math.sin(a + 0.5) * 0.6);
    ctx.closePath(); ctx.fill();
  }
  function poly(ctx, pts, close) {
    ctx.beginPath();
    pts.forEach(function (p, i) { if (i) ctx.lineTo(p.x, p.y); else ctx.moveTo(p.x, p.y); });
    if (close) ctx.closePath();
  }
  function shade(hex, k) {
    var n = parseInt(hex.slice(1), 16), r = n >> 16, g = n >> 8 & 255, b = n & 255;
    function f(c) { return Math.round(k > 0 ? c + (255 - c) * k : c * (1 + k)); }
    return 'rgb(' + f(r) + ',' + f(g) + ',' + f(b) + ')';
  }
  function frame(R, box) {
    var k = Math.min(R.w / (box.x1 - box.x0), R.h / (box.y1 - box.y0));
    var cx = R.x + R.w / 2, cy = R.y + R.h / 2, mx = (box.x0 + box.x1) / 2, my = (box.y0 + box.y1) / 2;
    return {
      k: k, R: R,
      p: function (x, y) { return { x: cx + (x - mx) * k, y: cy - (y - my) * k }; },
      w: function (sx, sy) { return { x: mx + (sx - cx) / k, y: my - (sy - cy) / k }; }
    };
  }
  // 折线按弧长取点：沿 pts 每隔 gap 像素放一个点，offset 为整体偏移
  function polyLen(pts) { var L = 0; for (var i = 1; i < pts.length; i++) L += Math.hypot(pts[i].x - pts[i - 1].x, pts[i].y - pts[i - 1].y); return L; }
  function dotsOn(ctx, pts, s0, phase, gap, color, r) {
    var L = 0;
    ctx.fillStyle = color;
    for (var i = 1; i < pts.length; i++) {
      var a = pts[i - 1], b = pts[i], d = Math.hypot(b.x - a.x, b.y - a.y);
      if (d > 0) {
        var first = Math.ceil((s0 + L - phase) / gap) * gap + phase;
        for (var s = first; s < s0 + L + d; s += gap) {
          var t = (s - s0 - L) / d;
          ctx.beginPath(); ctx.arc(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t, r, 0, 7); ctx.fill();
        }
      }
      L += d;
    }
    return s0 + L;
  }
  function bezier(p0, p1, p2, p3, n) {
    var out = [];
    for (var i = 0; i <= n; i++) {
      var t = i / n, u = 1 - t;
      out.push({ x: u * u * u * p0.x + 3 * u * u * t * p1.x + 3 * u * t * t * p2.x + t * t * t * p3.x,
        y: u * u * u * p0.y + 3 * u * u * t * p1.y + 3 * u * t * t * p2.y + t * t * t * p3.y });
    }
    return out;
  }
  function wire(ctx, pts, w) {
    ctx.setLineDash([]); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    poly(ctx, pts); ctx.strokeStyle = '#3a2a1e'; ctx.lineWidth = w + 2; ctx.stroke();
    poly(ctx, pts); ctx.strokeStyle = '#c96f52'; ctx.lineWidth = w; ctx.stroke();
  }

  // 灵敏电流计（中央零刻度）：屏幕坐标，返回两个接线柱位置；needle ∈ [−1.15, 1.15]
  function galvo(ctx, cx, cy, w, h, needle, full) {
    var x0 = cx - w / 2, y0 = cy - h / 2;
    var casing = ctx.createLinearGradient(x0, y0, x0, y0 + h);
    casing.addColorStop(0, '#303e50'); casing.addColorStop(1, '#141b27');
    ctx.fillStyle = casing; ctx.strokeStyle = '#526076'; ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.roundRect ? ctx.roundRect(x0, y0, w, h, 8) : ctx.rect(x0, y0, w, h); ctx.fill(); ctx.stroke();
    var px = cx, py = y0 + h * 0.86, r = h * 0.62, A = 50 * Math.PI / 180;
    var dial = ctx.createLinearGradient(cx, y0 + h * 0.2, cx, py);
    dial.addColorStop(0, '#eee6d5'); dial.addColorStop(1, '#bdad94');
    ctx.fillStyle = dial;
    ctx.beginPath(); ctx.moveTo(px, py); ctx.arc(px, py, r * 1.1, -Math.PI / 2 - A - 0.12, -Math.PI / 2 + A + 0.12); ctx.closePath(); ctx.fill();
    ctx.strokeStyle = '#333'; ctx.lineWidth = 1;
    for (var i = -10; i <= 10; i++) {
      var a = -Math.PI / 2 + A * i / 10, l = i % 5 === 0 ? 0.16 : 0.08;
      ctx.beginPath(); ctx.moveTo(px + Math.cos(a) * r, py + Math.sin(a) * r); ctx.lineTo(px + Math.cos(a) * r * (1 - l), py + Math.sin(a) * r * (1 - l)); ctx.stroke();
    }
    var fs = Math.max(8, Math.min(11, h * 0.11));
    ctx.font = font(fs); ctx.fillStyle = '#333'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText('0', px, py - r * 0.72);
    ctx.fillText('G', px, py - r * 0.32);
    var na = -Math.PI / 2 + A * needle;
    ctx.strokeStyle = '#c0392b'; ctx.lineWidth = 1.8;
    ctx.beginPath(); ctx.moveTo(px, py); ctx.lineTo(px + Math.cos(na) * r * 0.96, py + Math.sin(na) * r * 0.96); ctx.stroke();
    ctx.fillStyle = '#222'; ctx.beginPath(); ctx.arc(px, py, 3, 0, 7); ctx.fill();
    var tm = { x: x0 + w * 0.12, y: y0 + h * 0.18 }, tp = { x: x0 + w * 0.88, y: y0 + h * 0.18 };
    [[tm, '−'], [tp, '+']].forEach(function (t) {
      ctx.fillStyle = '#9aa3ad'; ctx.beginPath(); ctx.arc(t[0].x, t[0].y, 4, 0, 7); ctx.fill();
      label(ctx, t[1], t[0].x, t[0].y + 11, { size: 11, bold: true, color: MUTED });
    });
    return { minus: tm, plus: tp };
  }

  // ---------- 条形磁铁、线圈 ----------
  function barMagnet(ctx, fr, xm, d, half, yc) {
    yc = yc || 0;
    var h = COIL.mag / 2, a = fr.p(xm - h, yc + half), b = fr.p(xm + h, yc - half), mid = fr.p(xm, yc);
    var right = d > 0 ? N_COL : S_COL, left = d > 0 ? S_COL : N_COL;
    function paint(x, w, color) {
      var surface = ctx.createLinearGradient(x, a.y, x, b.y);
      surface.addColorStop(0, shade(color, 0.36));
      surface.addColorStop(0.22, color);
      surface.addColorStop(1, shade(color, -0.32));
      ctx.fillStyle = surface; ctx.fillRect(x, a.y, w, b.y - a.y);
    }
    paint(a.x, mid.x - a.x, left);
    paint(mid.x, b.x - mid.x, right);
    ctx.strokeStyle = 'rgba(0,0,0,.4)'; ctx.lineWidth = 1; ctx.strokeRect(a.x, a.y, b.x - a.x, b.y - a.y);
    var fs = Math.max(11, Math.min(18, (b.y - a.y) * 0.8));
    label(ctx, d > 0 ? 'S' : 'N', a.x + (mid.x - a.x) * 0.3, mid.y, { size: fs, bold: true });
    label(ctx, d > 0 ? 'N' : 'S', b.x - (b.x - mid.x) * 0.3, mid.y, { size: fs, bold: true });
  }
  // 线圈螺旋线：从左端底部开始，正面（z > 0）向下绕；返回世界坐标点 {x, y, z}
  function helix(xc, a, len, turns) {
    var pts = [], n = turns * 24;
    for (var i = 0; i <= n; i++) {
      var t = i / n, ph = Math.PI + 2 * Math.PI * turns * t;
      pts.push({ x: xc - len / 2 + len * t, y: a * Math.cos(ph), z: a * Math.sin(ph) });
    }
    return pts;
  }
  function coilP(fr, p) { return fr.p(p.x + CX * p.z, p.y + CY * p.z); }
  // 画线圈的一半（front: 正面），w 为线宽
  function coilHalf(ctx, fr, pts, front, w) {
    ctx.lineCap = 'round'; ctx.setLineDash([]);
    ctx.strokeStyle = front ? CU : shade(CU, -0.55); ctx.lineWidth = w;
    ctx.beginPath();
    var on = false;
    for (var i = 0; i < pts.length; i++) {
      var p = pts[i], s = coilP(fr, p), f = p.z >= 0;
      if (f === front) { if (!on) { ctx.moveTo(s.x, s.y); on = true; } else ctx.lineTo(s.x, s.y); }
      else if (on) { ctx.lineTo(s.x, s.y); on = false; }
    }
    ctx.stroke();
    if (front) {   // 高光
      ctx.strokeStyle = 'rgba(255,230,190,.35)'; ctx.lineWidth = Math.max(1, w * 0.3);
      ctx.beginPath(); on = false;
      for (i = 0; i < pts.length; i++) {
        p = pts[i]; s = coilP(fr, p);
        if (p.z > 0.4 * COIL.a) { if (!on) { ctx.moveTo(s.x - w * 0.2, s.y); on = true; } else ctx.lineTo(s.x - w * 0.2, s.y); } else on = false;
      }
      ctx.stroke();
    }
  }
  // 线圈上的电流点：helix 世界点，front 只画正面/背面
  function coilDots(ctx, fr, pts, phase, front, color, gap) {
    var L = 0;
    ctx.fillStyle = color;
    for (var i = 1; i < pts.length; i++) {
      var a = pts[i - 1], b = pts[i], d = Math.hypot(b.x - a.x, b.y - a.y, b.z - a.z) * fr.k;
      var first = Math.ceil((L - phase) / gap) * gap + phase;
      for (var s = first; s < L + d; s += gap) {
        var t = (s - L) / d, z = a.z + (b.z - a.z) * t;
        if ((z >= 0) !== front) continue;
        var q = coilP(fr, { x: a.x + (b.x - a.x) * t, y: a.y + (b.y - a.y) * t, z: z });
        ctx.globalAlpha = front ? 1 : 0.4;
        ctx.beginPath(); ctx.arc(q.x, q.y, front ? 3 : 2.4, 0, 7); ctx.fill();
      }
      L += d;
    }
    ctx.globalAlpha = 1;
    return L;
  }
  function poleBadge(ctx, x, y, pole, alpha, r) {
    ctx.globalAlpha = alpha;
    ctx.fillStyle = pole === 'N' ? N_COL : S_COL;
    ctx.beginPath(); ctx.arc(x, y, r || 10, 0, 7); ctx.fill();
    ctx.globalAlpha = 1;
    if (alpha > 0.05) label(ctx, pole, x, y, { size: Math.round((r || 10) * 1.2), bold: true });
  }
  // 磁铁的磁感线（磁铁坐标系的预算结果平移、镜像）
  function magnetLines(ctx, fr, xm, d, yc, alpha) {
    var lines = M.fieldLines();
    ctx.strokeStyle = 'rgba(111,134,201,' + alpha + ')'; ctx.lineWidth = 1.1; ctx.setLineDash([]);
    lines.forEach(function (ln) {
      // 只画磁铁附近（|y| ≤ 6 cm）的部分，远处的大圈省略
      ctx.beginPath();
      var on = false;
      ln.forEach(function (p) {
        if (Math.abs(p.y) > 6) { on = false; return; }
        var s = fr.p(xm + d * p.x, (yc || 0) + p.y);
        if (on) ctx.lineTo(s.x, s.y); else { ctx.moveTo(s.x, s.y); on = true; }
      });
      ctx.stroke();
      var m = Math.floor(ln.length * 0.45), p0 = ln[m], p1 = ln[m + 1];
      if (!p1 || Math.abs(p0.y) > 6) return;
      var s0 = fr.p(xm + d * p0.x, (yc || 0) + p0.y), s1 = fr.p(xm + d * p1.x, (yc || 0) + p1.y);
      ctx.globalAlpha = Math.min(1, alpha * 2);
      head(ctx, s1.x, s1.y, Math.atan2(s1.y - s0.y, s1.x - s0.x), 9, B_COL);
      ctx.globalAlpha = 1;
    });
  }

  // ---------- 场景一：蹄形磁体 ----------
  // 斜二测投影的长方体：只画看得见的顶面、正面、右面
  function box(ctx, P, x0, x1, y0, y1, z0, z1, col) {
    var q = function (x, y, z) { return P(x, y, z); };
    poly(ctx, [q(x0, y1, z0), q(x1, y1, z0), q(x1, y1, z1), q(x0, y1, z1)], true); ctx.fillStyle = shade(col, 0.25); ctx.fill();
    poly(ctx, [q(x1, y0, z1), q(x1, y0, z0), q(x1, y1, z0), q(x1, y1, z1)], true); ctx.fillStyle = shade(col, -0.35); ctx.fill();
    var front = ctx.createLinearGradient(0, q(x0, y1, z1).y, 0, q(x0, y0, z1).y);
    front.addColorStop(0, shade(col, 0.12)); front.addColorStop(1, shade(col, -0.24));
    poly(ctx, [q(x0, y0, z1), q(x1, y0, z1), q(x1, y1, z1), q(x0, y1, z1)], true); ctx.fillStyle = front; ctx.fill();
    ctx.strokeStyle = 'rgba(0,0,0,.35)'; ctx.lineWidth = 1;
    poly(ctx, [q(x0, y0, z1), q(x1, y0, z1), q(x1, y0, z0), q(x1, y1, z0), q(x0, y1, z0), q(x0, y1, z1)], true); ctx.stroke();
  }

  // ---------- 视图 ----------
  function View(canvas) {
    var ctx = canvas.getContext('2d'), W = 0, H = 0, dpr = 1, narrow = false, geo = null;
    function resize(w, h) {
      var ratio = Math.min(window.devicePixelRatio || 1, 2);
      if (w === W && h === H && ratio === dpr) return;
      dpr = ratio;
      W = w; H = h; narrow = w < 640;
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
      canvas.style.width = w + 'px'; canvas.style.height = h + 'px';
    }
    function bg() {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      var g = ctx.createRadialGradient(W / 2, H / 2, 0, W / 2, H / 2, Math.max(1, W * 0.6, H * 0.7));
      g.addColorStop(0, '#101a29'); g.addColorStop(1, '#05070d');
      ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
      ctx.fillStyle = 'rgba(126,154,199,.15)';
      for (var y = 16; y < H; y += 24) {
        for (var x = 16; x < W; x += 24) ctx.fillRect(x, y, 1, 1);
      }
    }
    function area() {
      var top = narrow ? 65 : 76, margin = narrow ? 12 : 24;
      top = Math.min(top, H * 0.28);
      return { x: margin, y: top, w: Math.max(1, W - margin * 2), h: Math.max(1, H - top - 12) };
    }

    // 场景一：导体切割磁感线
    // o: { B, nTop, mag:{x,y}, rod:{x,y,z}, closed, res, v:{x,y}, flow, vectors, lines, needle }
    function drawCut(o) {
      if (!W || !H) return;
      bg();
      // 窄屏把电流计放到磁体左下方、画面收窄（导体向左最多到 x = −13）
      var R = area(), fr = frame(R, narrow ? { x0: -18.5, x1: 17, y0: -19.8, y1: 11 } : { x0: -25, x1: 17, y0: -15.4, y1: 10.5 }), k = fr.k;
      var LAY = narrow ? { g: [-11, -14.6], k1: [-12.6, -7.6], k2: [-9.4, -7.6], w: [-1, -13.4] } : { g: [-17.5, -10.6], k1: [-15.6, -5], k2: [-12.4, -5], w: [-4, -11.2] };
      function P(x, y, z) { return fr.p(x + OX * z, y + OY * z); }
      var mx = o.mag.x, my = o.mag.y, g = CUT.gap, t = CUT.arm, D = CUT.depth, x0 = mx + CUT.x0, x1 = mx + CUT.x1;
      var top = o.nTop ? N_COL : S_COL, bot = o.nTop ? S_COL : N_COL;
      var rx = o.rod.x, ry = o.rod.y, rz = o.rod.z, L = CUT.rod;
      var A = P(rx, ry, rz + L), B = P(rx, ry, rz - L);
      // 电流计、开关：A 端经开关接“−”，B 端导线从磁体后面绕到下方接“+”
      var gw = 10 * k, gh = 7.2 * k, gc = fr.p(LAY.g[0], LAY.g[1]);
      var gT = { minus: { x: gc.x - gw / 2 + gw * 0.12, y: gc.y - gh / 2 + gh * 0.18 }, plus: { x: gc.x + gw / 2 - gw * 0.12, y: gc.y - gh / 2 + gh * 0.18 } };
      var K1 = fr.p(LAY.k1[0], LAY.k1[1]), K2 = fr.p(LAY.k2[0], LAY.k2[1]);
      var wireBend = fr.p(LAY.w[0], LAY.w[1]);
      var bPath = bezier(B, fr.p(rx + 12, ry + 2), fr.p(15, -12), wireBend, 40)
        .concat(bezier(wireBend, fr.p(LAY.w[0] - 5, LAY.w[1]), { x: gT.plus.x + 1.5 * k, y: gT.plus.y - 3 * k }, gT.plus, 16).slice(1));
      var aPath = bezier(A, { x: A.x - 2 * k, y: A.y + 2 * k }, { x: K2.x + 3 * k, y: K2.y }, K2, 24);
      var minusPath = bezier(K1, { x: K1.x - 2 * k, y: K1.y }, { x: gT.minus.x, y: gT.minus.y - 2 * k }, gT.minus, 12);
      var rodPath = [A, B], wW = Math.max(2, k * 0.22), gap = Math.max(16, k * 1.6), ph = o.flow * k, dotR = Math.max(2.2, k * 0.17);
      var flowing = Math.abs(o.res.I) > 1 && o.closed;
      // 电流路径（I > 0）：A → B →“+”→（电流计）→“−”→ K1 → K2 → A
      var sRod = 0, sB = polyLen(rodPath), sG = sB + polyLen(bPath), sM = sG + gw * 0.76, sK = sM + polyLen(minusPath), sA = sK + polyLen([K1, K2]);
      var aRev = aPath.slice().reverse();

      wire(ctx, bPath, wW);
      if (flowing) dotsOn(ctx, bPath, sB, ph, gap, I_COL, dotR);
      // 下臂（含弯头下半）
      box(ctx, P, x0, x1, my - g - t, my - g, -D, D, bot);
      // 磁感线：两臂之间竖直
      ctx.save(); ctx.globalAlpha = o.lines ? 0.75 : 0;
      for (var i = 0; i < 6; i++) for (var j = 0; j < 3; j++) {
        var lx = x0 + 1 + i * (CUT.x1 - CUT.x0 - 2) / 5, lz = -2.6 + j * 2.6, pa = P(lx, my + g, lz), pb = P(lx, my - g, lz);
        ctx.strokeStyle = B_COL; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(pa.x, pa.y); ctx.lineTo(pb.x, pb.y); ctx.stroke();
        var mid = P(lx, my, lz);
        head(ctx, mid.x, mid.y, o.nTop ? Math.PI / 2 : -Math.PI / 2, 9, B_COL);
      }
      ctx.restore();
      // 导体 AB
      ctx.lineCap = 'round';
      ctx.strokeStyle = '#6b4a2c'; ctx.lineWidth = CUT.rodR * 2 * k + 2; ctx.beginPath(); ctx.moveTo(A.x, A.y); ctx.lineTo(B.x, B.y); ctx.stroke();
      ctx.strokeStyle = CU; ctx.lineWidth = CUT.rodR * 2 * k; ctx.beginPath(); ctx.moveTo(A.x, A.y); ctx.lineTo(B.x, B.y); ctx.stroke();
      ctx.strokeStyle = 'rgba(255,230,190,.45)'; ctx.lineWidth = Math.max(1, CUT.rodR * k * 0.5);
      ctx.beginPath(); ctx.moveTo(A.x, A.y - CUT.rodR * k * 0.4); ctx.lineTo(B.x, B.y - CUT.rodR * k * 0.4); ctx.stroke();
      if (flowing) dotsOn(ctx, rodPath, sRod, ph, gap, I_COL, dotR);
      // A 端导线与开关
      wire(ctx, aPath, wW); wire(ctx, minusPath, wW);
      if (o.closed) wire(ctx, [K1, K2], wW);
      else {
        var ang = -0.55, bl = Math.hypot(K2.x - K1.x, K2.y - K1.y);
        wire(ctx, [K1, { x: K1.x + Math.cos(ang) * bl, y: K1.y + Math.sin(ang) * bl }], wW);
      }
      [K1, K2].forEach(function (p) { ctx.fillStyle = '#9aa3ad'; ctx.beginPath(); ctx.arc(p.x, p.y, Math.max(3, wW * 1.1), 0, 7); ctx.fill(); });
      label(ctx, o.closed ? '开关 S' : '开关 S 断开', (K1.x + K2.x) / 2, K1.y + 14, { size: 11, color: o.closed ? MUTED : F_COL });
      if (flowing) { dotsOn(ctx, aRev, sA, ph, gap, I_COL, dotR); dotsOn(ctx, minusPath.slice().reverse(), sM, ph, gap, I_COL, dotR); dotsOn(ctx, [K1, K2], sK, ph, gap, I_COL, dotR); }
      // 上臂、弯头
      box(ctx, P, x0, x1, my + g, my + g + t, -D, D, top);
      box(ctx, P, x1, x1 + CUT.bend, my, my + g + t, -D, D, top);
      box(ctx, P, x1, x1 + CUT.bend, my - g - t, my, -D, D, bot);
      var fs = Math.max(12, Math.min(20, k * 1.3));
      var lt = P(x0 + 2, my + g + t / 2, D), lb = P(x0 + 2, my - g - t / 2, D);
      label(ctx, o.nTop ? 'N' : 'S', lt.x, lt.y, { size: fs, bold: true });
      label(ctx, o.nTop ? 'S' : 'N', lb.x, lb.y, { size: fs, bold: true });
      label(ctx, 'A', A.x - 10, A.y + 8, { size: 13, bold: true });
      label(ctx, 'B', B.x + 6, B.y - 12, { size: 13, bold: true });
      // 矢量：v、B、I
      var c = P(rx, ry, rz + L * 0.62);
      if (o.vectors) {
        var sp = Math.hypot(o.v.x, o.v.y);
        if (sp > 0.5) {
          var vl = Math.min(4.5, 1.2 + sp * 0.12) * k, ux = o.v.x / sp, uy = o.v.y / sp;
          arrow(ctx, c.x, c.y, c.x + ux * vl, c.y - uy * vl, 11, V_COL, 2.6);
          label(ctx, 'v', c.x + ux * (vl + 12), c.y - uy * (vl + 12), { color: V_COL, bold: true, size: 14 });
        }
        var bp = P(x0 - 1.4, my + 1.6, D);
        arrow(ctx, bp.x, bp.y - (o.nTop ? 1.4 * k : -1.4 * k), bp.x, bp.y + (o.nTop ? 1.4 * k : -1.4 * k), 10, B_COL, 2.4);
        label(ctx, 'B', bp.x - 12, bp.y, { color: B_COL, bold: true, size: 14 });
        if (Math.abs(o.res.e) > 1e-5) {
          var dirAB = o.res.e > 0, p1 = P(rx, ry, rz + 2.5), p2 = P(rx, ry, rz - 2.5), from = dirAB ? p1 : p2, to = dirAB ? p2 : p1;
          var lift = -CUT.rodR * k - 9;
          arrow(ctx, from.x, from.y + lift, to.x, to.y + lift, 11, o.closed ? I_COL : 'rgba(255,201,74,.45)', 2.6);
          label(ctx, o.closed ? 'I' : 'E', to.x + (dirAB ? 8 : -8), to.y + lift - 10, { color: I_COL, bold: true, size: 14 });
        }
      }
      // 电流计
      galvo(ctx, gc.x, gc.y, gw, gh, o.needle, String(CUT.FULL));
      label(ctx, '灵敏电流计（满偏 ±' + CUT.FULL + ' μA）', gc.x, gc.y + gh / 2 + 12, { size: 11, color: MUTED });
      geo = { scene: 'cut', fr: fr, k: k, rodC: P(rx, ry, rz), magC: P(mx + 1, my, 0) };
      return geo;
    }

    // 场景二：磁铁插入、拔出线圈
    // o: { xm, d, turns, res, flow, needle, lines, show:{ lenz, force }, hist:[{t, phi, I}], now }
    function drawCoil(o) {
      if (!W || !H) return;
      bg();
      var R = area(), plot = o.plot && R.h >= 130;
      var gh = plot ? Math.min(180, Math.max(80, R.h * 0.26)) : 0;
      var Ra = { x: R.x, y: R.y, w: R.w, h: plot ? R.h - gh - 8 : R.h };
      var Rg = { x: R.x, y: R.y + R.h - gh, w: R.w, h: gh };
      var pan = narrow ? Math.min(0, o.xm + 15) + Math.max(0, o.xm - 15) : 0;
      var box = narrow ? { x0: -20 + pan, x1: 20 + pan } : { x0: -27, x1: 25 };
      box.y0 = -14.6; box.y1 = 10.2;
      var fr = frame(Ra, box), k = fr.k;
      var a = COIL.a, len = COIL.len, res = o.res, flowing = Math.abs(res.I) > 2;
      var pts = helix(0, a, len, narrow ? 8 : 11), gap = Math.max(18, k * 1.6), ph = o.flow * k, w = Math.max(2.2, k * 0.3);
      ctx.save(); ctx.beginPath(); ctx.rect(R.x, R.y, R.w, Ra.h); ctx.clip();
      if (o.lines) magnetLines(ctx, fr, o.xm, o.d, 0, 0.32);
      // 电流计与引线
      var gw = Math.min(10 * k, 150), ghh = gw * 0.72, gc = fr.p(0, -9.6);
      var L0 = coilP(fr, pts[0]), L1 = coilP(fr, pts[pts.length - 1]);
      var gT = { minus: { x: gc.x - gw / 2 + gw * 0.12, y: gc.y - ghh / 2 + ghh * 0.18 }, plus: { x: gc.x + gw / 2 - gw * 0.12, y: gc.y - ghh / 2 + ghh * 0.18 } };
      var leadL = bezier(gT.minus, { x: gT.minus.x, y: gT.minus.y - 2 * k }, { x: L0.x - 1.5 * k, y: L0.y + 2.5 * k }, L0, 20);
      var leadR = bezier(L1, { x: L1.x + 1.5 * k, y: L1.y + 2.5 * k }, { x: gT.plus.x, y: gT.plus.y - 2 * k }, gT.plus, 20);
      wire(ctx, leadL, Math.max(1.6, w * 0.6)); wire(ctx, leadR, Math.max(1.6, w * 0.6));
      // 电流方向：“−” → 左引线 → 线圈（左到右）→ 右引线 → “+”（I > 0）
      var lL = polyLen(leadL), lC = 0;
      coilHalf(ctx, fr, pts, false, w);
      if (flowing) { dotsOn(ctx, leadL, 0, ph, gap, I_COL, 2.6); lC = coilDots(ctx, fr, pts, ph - lL, false, I_COL, gap); }
      // 磁铁（在线圈背面与正面之间）
      barMagnet(ctx, fr, o.xm, o.d, COIL.magH);
      coilHalf(ctx, fr, pts, true, w);
      if (flowing) {
        lC = coilDots(ctx, fr, pts, ph - lL, true, I_COL, gap);
        dotsOn(ctx, leadR, lL + lC, ph, gap, I_COL, 2.6);
      }
      // 正面导线上的电流方向箭头
      if (flowing) {
        var fp = coilP(fr, { x: len / 2 - len / 22, y: 0, z: a });
        arrow(ctx, fp.x + 16, fp.y + (res.I > 0 ? -16 : 16), fp.x + 16, fp.y + (res.I > 0 ? 16 : -16), 9, I_COL, 2.2);
        label(ctx, 'I', fp.x + 28, fp.y, { color: I_COL, bold: true, size: 13 });
      }
      // 感应电流使线圈两端成为磁极
      var na = Math.min(1, 0.35 + Math.abs(res.needle) * 2.5);
      if (flowing) {
        var pl = fr.p(-len / 2 - 0.2, a + 1.6), pr = fr.p(len / 2 + 0.2, a + 1.6), r0 = Math.max(9, Math.min(12, k * 0.6));
        poleBadge(ctx, pl.x, pl.y, res.I > 0 ? 'S' : 'N', na, r0);
        poleBadge(ctx, pr.x, pr.y, res.I > 0 ? 'N' : 'S', na, r0);
      }
      // 速度与线圈对磁铁的力
      var h = COIL.mag / 2, vm = o.vm;
      if (Math.abs(vm) > 0.5) {
        var vc = fr.p(o.xm, COIL.magH + 1.1), vl = Math.min(4, 1 + Math.abs(vm) * 0.1) * k * Math.sign(vm);
        arrow(ctx, vc.x - vl / 2, vc.y, vc.x + vl / 2, vc.y, 10, V_COL, 2.4);
        label(ctx, 'v', vc.x + vl / 2 + Math.sign(vm) * 10, vc.y, { color: V_COL, bold: true, size: 13 });
      }
      if (o.show.force && flowing && res.force) {
        var fx = o.xm < 0 ? o.xm + h : o.xm - h, fc = fr.p(fx, -COIL.magH - 1.1), fl = Math.min(3.2, 0.8 + na * 3) * k * res.force;
        arrow(ctx, fc.x, fc.y, fc.x + fl, fc.y, 10, F_COL, 2.4);
        label(ctx, res.near ? 'F（来拒）' : 'F（去留）', fc.x + fl + res.force * 30, fc.y, { color: F_COL, bold: true, size: 12 });
      }
      // 增反减同：线圈内原磁场与感应电流的磁场
      if (o.show.lenz) {
        var y0 = a + 3.4, y1 = y0 + Math.max(1.4, 17 / k), bx = 0, al = 2.2 * k, big = Math.abs(res.phi) > COIL.p * 0.02;
        var c0 = fr.p(bx, y0), c1 = fr.p(bx, y1);
        label(ctx, 'B原', c0.x - al / 2 - 8, c0.y, { align: 'right', color: B_COL, bold: true, size: 12 });
        if (big) arrow(ctx, c0.x - Math.sign(res.phi) * al / 2, c0.y, c0.x + Math.sign(res.phi) * al / 2, c0.y, 9, B_COL, 2.4);
        else label(ctx, '很弱', c0.x, c0.y, { color: MUTED, size: 11 });
        label(ctx, Math.abs(res.rate) < 1e-7 ? 'Φ 不变' : (Math.sign(res.rate) === Math.sign(res.phi) ? 'Φ 增大' : 'Φ 减小'), c0.x + al / 2 + 10, c0.y, { align: 'left', color: MUTED, size: 12 });
        label(ctx, 'B感', c1.x - al / 2 - 8, c1.y, { align: 'right', color: I_COL, bold: true, size: 12 });
        if (flowing) {
          arrow(ctx, c1.x - Math.sign(res.I) * al / 2, c1.y, c1.x + Math.sign(res.I) * al / 2, c1.y, 9, I_COL, 2.4);
          label(ctx, Math.sign(res.I) === Math.sign(res.phi) ? '减同' : '增反', c1.x + al / 2 + 10, c1.y, { align: 'left', color: I_COL, size: 12, bold: true });
        } else label(ctx, '无', c1.x, c1.y, { color: MUTED, size: 11 });
        label(ctx, '线圈内（向右为正）', c0.x, c1.y - 20, { color: MUTED, size: 11 });
      }
      galvo(ctx, gc.x, gc.y, gw, ghh, o.needle, String(COIL.FULL));
      label(ctx, '灵敏电流计（满偏 ±' + COIL.FULL + ' μA）', gc.x, gc.y + ghh / 2 + 12, { size: 11, color: MUTED });
      label(ctx, o.turns + ' 匝', fr.p(0, -a - 1).x, fr.p(0, -a - 1).y, { size: 11, color: MUTED });
      ctx.restore();
      if (plot) chart(Rg, o);
      geo = { scene: 'coil', fr: fr, k: k, magC: fr.p(o.xm, 0) };
      return geo;
    }

    // 左轴为每匝磁通量（μWb），右轴为电流（μA），保留最近 8 秒。
    function chart(Rg, o) {
      var x0 = Rg.x + 40, x1 = Rg.x + Rg.w - 44, yT = Rg.y + 32, yB = Rg.y + Rg.h - 19;
      if (x1 <= x0 || yB <= yT) return;
      var ym = (yT + yB) / 2, hh = (yB - yT) / 2, span = 8;
      var fluxColor = '#8fb0ff', fluxScale = 100, currentPeak = COIL.FULL;
      var hist = o.hist.filter(function (h) { return o.now - h.t <= span; });
      hist.forEach(function (h) { currentPeak = Math.max(currentPeak, Math.abs(h.I)); });
      var currentScale = Math.ceil(currentPeak / COIL.FULL) * COIL.FULL;

      ctx.fillStyle = '#0c131e'; ctx.strokeStyle = LINE; ctx.lineWidth = 1;
      ctx.beginPath();
      if (ctx.roundRect) ctx.roundRect(Rg.x + .5, Rg.y + .5, Rg.w - 1, Rg.h - 1, 8);
      else ctx.rect(Rg.x + .5, Rg.y + .5, Rg.w - 1, Rg.h - 1);
      ctx.fill(); ctx.stroke();
      label(ctx, '磁通量 Φ  μWb', Rg.x + 12, Rg.y + 14, { align: 'left', color: fluxColor, size: 11 });
      label(ctx, '感应电流 I  μA', Rg.x + Rg.w - 12, Rg.y + 14, { align: 'right', color: I_COL, size: 11 });
      [[yT, '+', 0.17], [ym, '', 0.44], [yB, '−', 0.17]].forEach(function (row) {
        var y = row[0], sign = row[1];
        ctx.strokeStyle = 'rgba(141,153,171,' + row[2] + ')';
        ctx.beginPath(); ctx.moveTo(x0, y); ctx.lineTo(x1, y); ctx.stroke();
        label(ctx, sign ? sign + fluxScale : '0', x0 - 6, y, { align: 'right', color: fluxColor, size: 10 });
        label(ctx, sign ? sign + currentScale : '0', x1 + 6, y, { align: 'left', color: I_COL, size: 10 });
      });
      for (var s = 0; s <= span; s += 2) {
        var gx = x1 - (x1 - x0) * s / span;
        ctx.strokeStyle = 'rgba(141,153,171,.19)';
        ctx.beginPath(); ctx.moveTo(gx, yT); ctx.lineTo(gx, yB); ctx.stroke();
        label(ctx, s ? '−' + s + ' s' : '现在', gx, yB + 10, { size: 10, color: MUTED });
      }

      function curve(get, scale, color) {
        ctx.strokeStyle = color; ctx.lineWidth = 2; ctx.beginPath();
        hist.forEach(function (h, i) {
          var x = x1 - (x1 - x0) * (o.now - h.t) / span;
          var y = ym - M.clamp(get(h) / scale, -1, 1) * hh;
          if (i) ctx.lineTo(x, y); else ctx.moveTo(x, y);
        });
        ctx.stroke();
      }
      curve(function (h) { return h.phi * 1e6; }, fluxScale, fluxColor);
      curve(function (h) { return h.I; }, currentScale, I_COL);
    }

    // ---------- 练习 ----------
    function drawQuiz(q, answered) {
      if (!W || !H) return;
      bg();
      var R = area();
      ctx.save(); ctx.beginPath(); ctx.rect(R.x, R.y - 4, R.w, R.h + 8); ctx.clip();
      if (q.type === 'cut') quizCut(R, q, answered);
      else if (q.type === 'lenz') quizLenz(R, q, answered);
      else quizRing(R, q, answered);
      ctx.restore();
      geo = { scene: 'quiz' };
      return geo;
    }
    function fieldMarks(fr, x0, x1, y0, y1, bIn) {
      var sp = Math.max(24, Math.min(40, fr.k * 2.6)), a = fr.p(x0, y1), b = fr.p(x1, y0), r = Math.max(3.5, sp * 0.13);
      ctx.fillStyle = 'rgba(111,134,201,.08)'; ctx.fillRect(a.x, a.y, b.x - a.x, b.y - a.y);
      ctx.strokeStyle = ctx.fillStyle = 'rgba(141,153,171,.4)'; ctx.lineWidth = 1.2;
      for (var x = a.x + sp / 2; x < b.x; x += sp) for (var y = a.y + sp / 2; y < b.y; y += sp) {
        ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.stroke();
        if (bIn) { var d = r * 0.7; ctx.beginPath(); ctx.moveTo(x - d, y - d); ctx.lineTo(x + d, y + d); ctx.moveTo(x + d, y - d); ctx.lineTo(x - d, y + d); ctx.stroke(); }
        else { ctx.beginPath(); ctx.arc(x, y, 1.6, 0, 7); ctx.fill(); }
      }
      label(ctx, 'B ' + (bIn ? '垂直纸面向里' : '垂直纸面向外'), a.x + 6, a.y - 10, { align: 'left', size: 12, color: MUTED });
    }
    function quizCut(R, q, answered) {
      var fr = frame(R, { x0: -13, x1: 13, y0: -9.5, y1: 9.5 }), k = fr.k, hRod = q.rod === 'h';
      // 以“竖直棒、水平导轨、电阻在左”布局，水平棒时整体逆时针转 90°
      function T(x, y) { return hRod ? fr.p(-y, x) : fr.p(x, y); }
      fieldMarks(fr, hRod ? -6.5 : -8, hRod ? 6.5 : 11, hRod ? -8 : -6.5, hRod ? 11 : 6.5, q.bIn);
      var rodX = 3, w = Math.max(2, k * 0.25);
      // 导轨与电阻、开关
      var rails = [[T(-10, 5), T(11, 5)], [T(-10, -5), T(11, -5)]];
      rails.forEach(function (r) { wire(ctx, r, w); });
      // 左侧：电阻 R（y 4→1）与开关 S（y −1→−3）
      wire(ctx, [T(-10, 5), T(-10, 4)], w); wire(ctx, [T(-10, 1), T(-10, -1)], w); wire(ctx, [T(-10, -3), T(-10, -5)], w);
      var c1 = T(-10, 4), c2 = T(-10, 1), rw = 0.8 * k;
      ctx.fillStyle = '#18202e'; ctx.strokeStyle = TEXT; ctx.lineWidth = 1.6;
      var rx0 = Math.min(c1.x, c2.x) - (hRod ? 0 : rw), ry0 = Math.min(c1.y, c2.y) - (hRod ? rw : 0);
      var rww = hRod ? Math.abs(c2.x - c1.x) : rw * 2, rhh = hRod ? rw * 2 : Math.abs(c2.y - c1.y);
      ctx.fillRect(rx0, ry0, rww, rhh); ctx.strokeRect(rx0, ry0, rww, rhh);
      var rc = T(-10, 2.5);
      label(ctx, 'R', rc.x, rc.y, { size: 13, bold: true });
      var s0 = T(-10, -3), s1 = q.open ? T(-10 + 1.3, -1.2) : T(-10, -1);
      wire(ctx, [s0, s1], w);
      [T(-10, -1), s0].forEach(function (p) { ctx.fillStyle = '#9aa3ad'; ctx.beginPath(); ctx.arc(p.x, p.y, Math.max(3, w), 0, 7); ctx.fill(); });
      var sl = T(-11.2, -2);
      label(ctx, 'S', sl.x, sl.y, { size: 13, bold: true, color: q.open ? F_COL : TEXT });
      // 导体棒
      var pa = T(rodX, 6), pb = T(rodX, -6);
      ctx.lineCap = 'round'; ctx.strokeStyle = CU; ctx.lineWidth = Math.max(5, k * 0.6);
      ctx.beginPath(); ctx.moveTo(pa.x, pa.y); ctx.lineTo(pb.x, pb.y); ctx.stroke();
      var la = T(rodX + 0, 7.4), lb = T(rodX, -7.4);
      label(ctx, 'a', la.x, la.y, { size: 15, bold: true }); label(ctx, 'b', lb.x, lb.y, { size: 15, bold: true });
      var c = T(rodX, 0), vl = 3.2 * k;
      arrow(ctx, c.x, c.y, c.x + q.v.x * vl, c.y - q.v.y * vl, 12, V_COL, 2.8);
      label(ctx, 'v', c.x + q.v.x * (vl + 14) + (q.v.x ? 0 : 12), c.y - q.v.y * (vl + 14), { color: V_COL, bold: true, size: 15 });
      if (answered && !q.open) {
        // 电流箭头画在速度的另一侧
        var side = (hRod ? q.v.y : q.v.x) > 0 ? -1.3 : 1.3;
        var from = T(rodX + side, q.toA ? -3 : 3), to = T(rodX + side, q.toA ? 3 : -3), li = T(rodX + side * 1.9, 0);
        arrow(ctx, from.x, from.y, to.x, to.y, 11, I_COL, 2.6);
        label(ctx, 'I', li.x, li.y, { color: I_COL, bold: true, size: 15 });
      }
    }
    function quizLenz(R, q, answered) {
      var fr = frame(R, { x0: -21, x1: 10, y0: -6.5, y1: 8 }), k = fr.k, a = COIL.a, len = COIL.len;
      var d = q.pole === 'N' ? 1 : -1, xm = q.move === 'stay' ? 0 : -12;
      var pts = helix(0, a, len, 9), w = Math.max(2.2, k * 0.3);
      magnetLines(ctx, fr, xm, d, 0, 0.22);
      coilHalf(ctx, fr, pts, false, w);
      barMagnet(ctx, fr, xm, d, COIL.magH);
      coilHalf(ctx, fr, pts, true, w);
      if (q.move !== 'stay') {
        var vc = fr.p(xm, COIL.magH + 1.3), vl = 3 * k * (q.move === 'in' ? 1 : -1);
        arrow(ctx, vc.x - vl / 2, vc.y, vc.x + vl / 2, vc.y, 11, V_COL, 2.6);
        label(ctx, q.move === 'in' ? '插入' : '拔出', vc.x, vc.y - 16, { color: V_COL, bold: true, size: 13 });
      } else label(ctx, '静止', fr.p(0, -a - 1.6).x, fr.p(0, -a - 1.6).y, { color: MUTED, size: 12 });
      // 观察者：从左向右看
      var e = fr.p(-19.5, 4.5);
      label(ctx, '从左向右看', e.x, e.y, { align: 'left', size: 12, color: MUTED });
      if (answered && q.I) {
        var fp = coilP(fr, { x: len / 2 - len / 18, y: 0, z: a });
        arrow(ctx, fp.x + 16, fp.y + (q.I > 0 ? -16 : 16), fp.x + 16, fp.y + (q.I > 0 ? 16 : -16), 10, I_COL, 2.4);
        label(ctx, 'I', fp.x + 28, fp.y, { color: I_COL, bold: true, size: 13 });
        var c0 = fr.p(1, a + 2.4), c1 = fr.p(1, a + 3.8), al = 2.6 * k;
        arrow(ctx, c0.x - q.phi * al / 2, c0.y, c0.x + q.phi * al / 2, c0.y, 9, B_COL, 2.4);
        label(ctx, 'B原', c0.x - al / 2 - 8, c0.y, { align: 'right', color: B_COL, bold: true, size: 12 });
        arrow(ctx, c1.x - Math.sign(q.I) * al / 2, c1.y, c1.x + Math.sign(q.I) * al / 2, c1.y, 9, I_COL, 2.4);
        label(ctx, 'B感', c1.x - al / 2 - 8, c1.y, { align: 'right', color: I_COL, bold: true, size: 12 });
        var pl = fr.p(-len / 2 - 0.3, -a - 1.4), pr = fr.p(len / 2 + 0.3, -a - 1.4);
        poleBadge(ctx, pl.x, pl.y, q.I > 0 ? 'S' : 'N', 1, 10);
        poleBadge(ctx, pr.x, pr.y, q.I > 0 ? 'N' : 'S', 1, 10);
        // 从左向右看的环绕方向
        var cc = fr.p(-17, -3.2), rr = Math.max(16, k * 1.2);
        circArrow(cc.x, cc.y, rr, q.I > 0);
        label(ctx, q.I > 0 ? '顺时针' : '逆时针', cc.x, cc.y + rr + 14, { color: I_COL, size: 12, bold: true });
      }
    }
    // 屏幕上的环形箭头：cw 顺时针
    function circArrow(cx, cy, r, cw) {
      var a0 = -Math.PI / 2, a1 = a0 + (cw ? 1 : -1) * Math.PI * 1.7;
      ctx.strokeStyle = I_COL; ctx.lineWidth = 2; ctx.setLineDash([]);
      ctx.beginPath(); ctx.arc(cx, cy, r, a0, a1, !cw); ctx.stroke();
      head(ctx, cx + Math.cos(a1) * r, cy + Math.sin(a1) * r, a1 + (cw ? 1 : -1) * Math.PI / 2, 12, I_COL);
    }
    function quizRing(R, q, answered) {
      var fr = frame(R, { x0: -20, x1: 12, y0: -7, y1: 9 }), k = fr.k, d = q.pole === 'N' ? 1 : -1, xm = -10;
      var ringX = 3 + (answered && !q.gap ? (q.move === 'in' ? 1.4 : -1.4) : 0);
      var top = fr.p(3, 8.2);
      ctx.strokeStyle = MUTED; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(top.x - 3 * k, top.y); ctx.lineTo(top.x + 3 * k, top.y); ctx.stroke();
      if (answered && !q.gap) {
        var t0 = fr.p(3, 2.6);
        ctx.setLineDash([4, 4]); ctx.strokeStyle = 'rgba(141,153,171,.4)'; ctx.lineWidth = 1.2;
        ctx.beginPath(); ctx.moveTo(top.x, top.y); ctx.lineTo(t0.x, t0.y); ctx.stroke();
        ctx.beginPath(); ctx.ellipse(t0.x, fr.p(3, 0).y, 2.6 * k * 0.3, 2.6 * k, 0, 0, 7); ctx.stroke();
        ctx.setLineDash([]);
      }
      var rt = fr.p(ringX, 2.6), rc = fr.p(ringX, 0);
      ctx.strokeStyle = TEXT; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(top.x, top.y); ctx.lineTo(rt.x, rt.y); ctx.stroke();
      magnetLines(ctx, fr, xm, d, 0, 0.2);
      ctx.strokeStyle = '#cfd6df'; ctx.lineWidth = Math.max(4, k * 0.45);
      ctx.beginPath();
      if (q.gap) ctx.ellipse(rc.x, rc.y, 2.6 * k * 0.3, 2.6 * k, 0, 0.35 + Math.PI / 2, Math.PI / 2 - 0.35 + Math.PI * 2);
      else ctx.ellipse(rc.x, rc.y, 2.6 * k * 0.3, 2.6 * k, 0, 0, 7);
      ctx.stroke();
      label(ctx, q.gap ? '有缺口的铝环' : '闭合铝环', rc.x, fr.p(0, -3.6).y, { size: 12, color: MUTED });
      barMagnet(ctx, fr, xm, d, COIL.magH);
      var vc = fr.p(xm, COIL.magH + 1.3), vl = 3 * k * (q.move === 'in' ? 1 : -1);
      arrow(ctx, vc.x - vl / 2, vc.y, vc.x + vl / 2, vc.y, 11, V_COL, 2.6);
      label(ctx, q.move === 'in' ? '靠近' : '远离', vc.x, vc.y - 16, { color: V_COL, bold: true, size: 13 });
      if (answered && !q.gap) {
        var s = q.move === 'in' ? 1 : -1, fc = fr.p(ringX, -4.8);
        arrow(ctx, fc.x - s * 1.2 * k, fc.y, fc.x + s * 1.6 * k, fc.y, 11, F_COL, 2.6);
        label(ctx, q.move === 'in' ? '来拒' : '去留', fc.x, fc.y + 16, { color: F_COL, bold: true, size: 13 });
      }
    }

    return { resize: resize, drawCut: drawCut, drawCoil: drawCoil, drawQuiz: drawQuiz, geo: function () { return geo; }, narrow: function () { return narrow; } };
  }

  window.InductDraw = { View: View, frame: frame, galvo: galvo, COLORS: { N: N_COL, S: S_COL, B: B_COL, V: V_COL, I: I_COL, F: F_COL } };
})();
