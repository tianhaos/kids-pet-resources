// 电磁感应的计算（不碰 DOM）
// 场景一（导体切割磁感线）：世界坐标 x 右、y 上、z 指向观察者，单位 cm；蹄形磁体两臂上下、弯头在右，两臂之间磁场竖直；
//   导体 AB 沿 z 方向（A 在前、B 在后），在 x-y 平面内运动；感应电动势 e > 0 表示导体中电流由 A 流向 B。
// 场景二（磁铁插入线圈）：线圈轴线沿 x、中心在原点，单位 cm；条形磁铁看成两端各一个磁荷，磁通量以 +x 为正；
//   感应电流 I > 0 表示它的磁场沿 +x（从左向右看顺时针，线圈右端为 N 极）。
(function () {
  var DEG = Math.PI / 180;
  function clamp(x, a, b) { return x < a ? a : x > b ? b : x; }
  function sgn(x) { return x > 0 ? 1 : x < 0 ? -1 : 0; }

  // ---------- 场景一：导体切割磁感线 ----------
  var CUT = {
    x0: -6, x1: 7, bend: 3,         // 磁极 x 范围（弯头在 x1 右侧）
    gap: 3.6, arm: 2.2, depth: 4,   // 两臂之间半间隙、臂厚、磁体前后半宽（z）
    rod: 7, rodR: 0.35,             // 导体半长、半径
    L: 0.08,                        // 处在磁场中的导体长度 = 磁体前后宽度 8 cm
    R: 40,                          // 回路总电阻 Ω（主要是灵敏电流计内阻）
    FULL: 500,                      // 电流计满偏 μA
    xMin: -20, xMax: 4.4, yMax: 1.6, zMax: 2.5,  // 导体相对磁体的活动范围
    B_RANGE: [0.1, 1]
  };
  // 导体所在 x 处的磁场占比（磁极边缘 0.6 cm 内平滑过渡，近似边缘效应）
  function fieldFrac(x) {
    var e = 0.6, a = clamp((x - (CUT.x0 - e)) / (2 * e), 0, 1), b = clamp(((CUT.x1 + e) - x) / (2 * e), 0, 1);
    var f = Math.min(a, b);
    return f * f * (3 - 2 * f);
  }
  // rel：导体相对磁体的位置 {x, y, z}；v：导体相对磁体的速度 {x, y, z}（cm/s）；nTop：N 极在上
  function cut(B, nTop, rel, v, closed) {
    var frac = fieldFrac(rel.x), s = nTop ? 1 : -1;
    // 磁场 B = −s·B·ŷ，F = qv×B 的 z 分量 = −s·B·vx：正电荷被推向 −z（由 A 到 B）
    var e = s * B * frac * CUT.L * v.x / 100;
    var cutting = frac > 0.02 && Math.abs(v.x) > 0.3;
    var I = closed ? e / CUT.R * 1e6 : 0;
    return {
      frac: frac, inField: frac > 0.5, cutting: cutting, e: e, I: I,
      dir: Math.abs(I) < 1 ? '' : I > 0 ? 'AB' : 'BA',
      // B 端接电流计“+”、A 端接“−”：电流由 A 到 B 时从“+”流入，指针右偏
      needle: clamp(I / CUT.FULL, -1.15, 1.15)
    };
  }

  // ---------- 场景二：磁铁插入、拔出线圈 ----------
  var COIL = {
    a: 3, len: 8,             // 线圈半径、长度（cm）
    mag: 8, magH: 0.9,        // 条形磁铁长度、半厚
    p: 1.2e-4,                // 磁荷强度：磁铁内部磁通量（Wb）
    R: 100,                   // 回路电阻 Ω
    FULL: 1000,               // 电流计满偏 μA
    TURNS: [100, 200, 400],
    xMin: -22, xMax: 20, home: -14, V_RANGE: [5, 40]   // 磁铁中心范围、初始位置、自动移动速度 cm/s
  };
  // 磁荷 +1 在轴线上、到圆面的有向距离 s（圆面在磁荷右侧为正），穿过半径 a 的圆面、沿 +x 的磁通量
  function poleFlux(s, a) { return 0.5 * sgn(s || 1e-9) * (1 - Math.abs(s) / Math.sqrt(s * s + a * a)); }
  // 磁铁中心 xm、d = +1 表示 N 极在右；位于 x 的一匝线圈中沿 +x 的磁通量（单位 p）
  function loopFlux(x, xm, d) {
    var h = COIL.mag / 2, xN = xm + d * h, xS = xm - d * h, a = COIL.a;
    var f = poleFlux(x - xN, a) - poleFlux(x - xS, a);
    // 磁铁内部的磁感线由 S 指向 N，穿过磁铁内部的线圈
    if (x >= Math.min(xN, xS) && x < Math.max(xN, xS)) f += d;  // s = 0 按磁荷右侧处理
    return f;
  }
  // 整个线圈的平均每匝磁通量（单位 p）
  var NS = 17;
  function coilFlux(xm, d) {
    var sum = 0;
    for (var i = 0; i < NS; i++) sum += loopFlux(-COIL.len / 2 + COIL.len * (i + 0.5) / NS, xm, d);
    return sum / NS;
  }
  // xm 磁铁中心、vm 磁铁速度（cm/s）、d 磁极方向、n 匝数
  function coil(xm, vm, d, n) {
    var h = 0.01, phi = coilFlux(xm, d), dphi = (coilFlux(xm + h, d) - coilFlux(xm - h, d)) / (2 * h);
    var rate = COIL.p * dphi * vm;          // 每匝 dΦ/dt（Wb/s），x 单位约掉
    var e = -n * rate, I = e / COIL.R * 1e6;
    var lead = xm < 0 ? (d > 0 ? 'N' : 'S') : (d > 0 ? 'S' : 'N');  // 靠近线圈的磁极
    var near = Math.abs(xm) > 1e-6 && sgn(vm) === -sgn(xm);          // 正在靠近线圈中心
    return {
      phi: phi * COIL.p, rate: rate, e: e, I: I, lead: lead, near: near,
      // 线圈对磁铁的作用力方向（+1 向右）：F = I·N·p·dφ/dxm，总与磁铁运动方向相反
      force: sgn(I * dphi),
      needle: clamp(I / COIL.FULL, -1.15, 1.15)
    };
  }
  // 楞次定律实验记录的一行：情形键 Nin/Nout/Sin/Sout
  function record(c) {
    if (Math.abs(c.I) < COIL.FULL * 0.03 || Math.abs(c.phi) < 1e-9) return null;
    var inc = sgn(c.rate) === sgn(c.phi);
    return {
      key: c.lead + (c.near ? 'in' : 'out'),
      b0: c.phi > 0 ? '向右' : '向左', change: inc ? '增大' : '减小',
      b1: c.I > 0 ? '向右' : '向左', cw: c.I > 0 ? '顺时针' : '逆时针', needle: c.I > 0 ? '右偏' : '左偏'
    };
  }

  // 磁铁周围的磁感线（磁铁中心在原点、N 极在 +x），只算磁铁外部；用于绘制时平移、镜像
  var linesCache = null;
  function fieldLines() {
    if (linesCache) return linesCache;
    var h = COIL.mag / 2, out = [];
    function B(x, y) {
      var dx1 = x - h, dx2 = x + h, r1 = Math.pow(dx1 * dx1 + y * y, 1.5), r2 = Math.pow(dx2 * dx2 + y * y, 1.5);
      return { x: dx1 / r1 - dx2 / r2, y: y / r1 - y / r2 };
    }
    [40, 58, 78, 100, 125].forEach(function (deg) {
      [1, -1].forEach(function (sy) {
        var a = deg * DEG, x = h + 0.15 + 0.9 * Math.cos(a) * 0.4, y = sy * (0.25 + 0.9 * Math.sin(a) * 0.75), pts = [{ x: x, y: y }];
        for (var i = 0; i < 1600; i++) {
          var b = B(x, y), m = Math.hypot(b.x, b.y) || 1;
          x += b.x / m * 0.12; y += b.y / m * 0.12;
          pts.push({ x: x, y: y });
          if (Math.abs(y) < COIL.magH && Math.abs(x) < h + 0.1) break;
          if (Math.abs(x) > 40 || Math.abs(y) > 24) break;
        }
        out.push(pts);
      });
    });
    linesCache = out;
    return out;
  }

  // ---------- 练习 ----------
  var TYPES = ['cut', 'lenz', 'ring'];
  function pick(rand, a) { return a[Math.floor(rand() * a.length)]; }
  function shuffle(rand, a) {
    a = a.slice();
    for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(rand() * (i + 1)), t = a[i]; a[i] = a[j]; a[j] = t; }
    return a;
  }
  // 导轨上的导体棒：rod 'v' 竖直（a 上 b 下、导轨水平）或 'h' 水平（a 左 b 右、导轨竖直）；bIn 磁场垂直纸面向里
  function quizCut(rand) {
    var rod = pick(rand, ['v', 'h']), bIn = rand() < 0.5, sv = pick(rand, [1, -1]), open = rand() < 0.18;
    var v = rod === 'v' ? { x: sv, y: 0 } : { x: 0, y: sv };
    var Bz = bIn ? -1 : 1;
    // v × B（B 沿 z）= (vy·Bz, −vx·Bz)
    var f = { x: v.y * Bz, y: -v.x * Bz };
    var toA = rod === 'v' ? f.y > 0 : f.x < 0;      // 正电荷被推向 a 端
    var ans = open ? '没有感应电流' : toA ? '由 b 到 a' : '由 a 到 b';
    var vName = rod === 'v' ? (sv > 0 ? '向右' : '向左') : (sv > 0 ? '向上' : '向下');
    var bName = bIn ? '垂直纸面向里' : '垂直纸面向外';
    var hand = '右手定则：伸开右手，让磁感线从掌心进入（磁场' + bName + '，掌心朝' + (bIn ? '外' : '里') + '），拇指指向导体运动方向（' + vName +
      '），四指所指就是感应电流方向，即 ab 中电流' + (toA ? '由 b 到 a' : '由 a 到 b') + '。';
    return { type: 'cut', rod: rod, bIn: bIn, v: v, open: open, toA: toA, answer: ans,
      options: ['由 a 到 b', '由 b 到 a', '没有感应电流'],
      prompt: '匀强磁场' + bName + '，导体棒 ab 在导轨上' + vName + '运动' + (open ? '，开关 S 断开' : '') + '，ab 中的感应电流方向是？',
      explain: open ? '开关断开，电路不闭合，没有感应电流。不过 ab 仍在切割磁感线，两端有感应电动势（' + (toA ? 'a' : 'b') + ' 端电势高），相当于一个没接用电器的电源。'
        : hand + 'ab 相当于电源，电流从电源内部的低电势端流向高电势端，' + (toA ? 'a' : 'b') + ' 端电势高。' };
  }
  // 条形磁铁在线圈左侧：pole 朝线圈的磁极，move 'in' 插入 / 'out' 拔出 / 'stay' 静止在线圈中
  function lenzCase(pole, move) {
    var phi = pole === 'N' ? 1 : -1;               // 线圈内原磁场方向（+1 向右）
    if (move === 'stay') return { phi: phi, I: 0 };
    var inc = move === 'in';
    return { phi: phi, inc: inc, I: inc ? -phi : phi };
  }
  function quizLenz(rand) {
    var pole = pick(rand, ['N', 'S']), move = rand() < 0.14 ? 'stay' : pick(rand, ['in', 'out']), c = lenzCase(pole, move);
    var ans = c.I === 0 ? '没有感应电流' : c.I > 0 ? '顺时针' : '逆时针';
    var b0 = c.phi > 0 ? '向右' : '向左', b1 = c.I > 0 ? '向右' : '向左';
    var explain = c.I === 0 ? '磁铁静止时，穿过线圈的磁通量不变，没有感应电流——不管磁铁在线圈里还是外面。'
      : '① 原磁场：' + pole + ' 极朝右，线圈内磁场' + b0 + '；② 磁铁' + (c.inc ? '插入' : '拔出') + '，磁通量' + (c.inc ? '增大' : '减小') +
        '；③ 增反减同：感应电流的磁场' + b1 + '；④ 安培定则（右手螺旋）：从左向右看电流' + ans + '，线圈左端为 ' + (c.I > 0 ? 'S' : 'N') + ' 极，' +
        (c.inc ? '与磁铁 ' + pole + ' 极相斥（来拒）' : '与磁铁 ' + pole + ' 极相吸（去留）') + '。';
    return { type: 'lenz', pole: pole, move: move, I: c.I, phi: c.phi, answer: ans,
      options: ['顺时针', '逆时针', '没有感应电流'],
      prompt: '条形磁铁的 ' + pole + ' 极朝向线圈，' + { 'in': '向右插入线圈', out: '向左拔出线圈', stay: '静止在线圈中' }[move] + '。从左向右看，线圈中的感应电流方向是？',
      explain: explain };
  }
  // 用细线悬挂的轻铝环：磁铁从左侧靠近 / 远离；gap 为开口环
  function quizRing(rand) {
    var pole = pick(rand, ['N', 'S']), move = pick(rand, ['in', 'out']), gap = rand() < 0.2;
    var ans = gap ? '基本不动' : move === 'in' ? '向右摆动' : '向左摆动';
    return { type: 'ring', pole: pole, move: move, gap: gap, answer: ans,
      options: ['向右摆动', '向左摆动', '基本不动'],
      prompt: '用细线悬挂一个' + (gap ? '有缺口的' : '闭合的') + '轻铝环，条形磁铁的 ' + pole + ' 极朝向铝环，从左侧' + (move === 'in' ? '向右靠近' : '向左远离') + '铝环，铝环将？',
      explain: gap ? '铝环有缺口，不能形成闭合回路，虽然有感应电动势却没有感应电流，也就不受磁场力，基本不动。'
        : '“来拒去留”：感应电流总要阻碍磁铁与铝环的相对运动。磁铁' + (move === 'in' ? '靠近，铝环被推开，向右摆动' : '远离，铝环被吸引，跟着向左摆动') +
          '，与哪个磁极朝向铝环无关。也可以按“增反减同”判断出电流方向，再看铝环左侧相当于什么磁极。' };
  }
  function quiz(rand, avoid, only) {
    var gen = { cut: quizCut, lenz: quizLenz, ring: quizRing }, q;
    for (var i = 0; i < 10; i++) {
      q = gen[only && gen[only] ? only : pick(rand, TYPES)](rand);
      q.id = q.type + '|' + q.prompt;
      if (q.id !== avoid) break;
    }
    return q;
  }

  function fmtI(I) { var a = Math.abs(I); return a < 0.5 ? '0' : (a < 10 ? a.toFixed(1) : a.toFixed(0)) + ' μA'; }
  function fmtV(e) { var a = Math.abs(e); return a < 1e-6 ? '0' : a < 1e-3 ? (a * 1e3).toFixed(2) + ' mV' : a < 1 ? (a * 1e3).toFixed(1) + ' mV' : a.toFixed(2) + ' V'; }
  function fmtWb(p) { var a = Math.abs(p); return a < 1e-8 ? '0' : (p < 0 ? '−' : '') + (a * 1e4).toFixed(2) + '×10⁻⁴ Wb'; }

  window.Induct = {
    DEG: DEG, CUT: CUT, COIL: COIL, TYPES: TYPES,
    clamp: clamp, sgn: sgn, shuffle: shuffle,
    fieldFrac: fieldFrac, cut: cut,
    poleFlux: poleFlux, loopFlux: loopFlux, coilFlux: coilFlux, coil: coil, record: record, fieldLines: fieldLines,
    lenzCase: lenzCase, quiz: quiz,
    fmtI: fmtI, fmtV: fmtV, fmtWb: fmtWb
  };
})();
