(function () {
  var M = window.Induct, D = window.InductDraw, CUT = M.CUT, COIL = M.COIL;
  var $ = function (id) { return document.getElementById(id); };
  var qa = function (sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); };
  var NAME = '电磁感应';

  var state = {
    scene: 'cut',
    cut: { B: 0.5, nTop: true, closed: true, move: 'rod', auto: 'lr', speed: 1, rod: { x: 0, y: 0, z: 0 }, mag: { x: 0, y: 0 },
      rel0: null, v: { x: 0, y: 0, z: 0 }, t: 0, needle: 0, flow: 0, res: null },
    coil: { xm: COIL.home, d: 1, turns: 200, target: null, speed: 15, vm: 0, needle: 0, flow: 0, hist: [], now: 0, rec: {}, res: null,
      show: { lenz: true, force: true, lines: true } },
    show: { lines: true, vectors: true },
    quiz: null, quizOnly: null, answered: false, correct: false, choice: null, score: { n: 0, ok: 0 }
  };
  var ROD_FIXED = -3;   // 磁体运动时导体固定的位置

  var HINTS = {
    cut: '拖动画面移动导体 AB，观察指针。',
    coil: '左右拖动磁铁，观察指针与电流方向。',
    quiz: ''
  };
  var AUTOS = ['off', 'lr', 'ud', 'fb'];

  var stage = $('stage'), panel = $('panel'), drawing = $('drawing'), cv = $('view');
  var phone = window.matchMedia('(max-width: 760px)');
  var showPlot = false;
  var drag = null, cutDrag = { x: 0, y: 0, z: 0 }, coilDrag = 0;
  var view = D.View(cv);
  function setSeg(attr, val) { qa('[data-' + attr + ']').forEach(function (b) {
    var selected = b.dataset[attr] === String(val);
    b.classList.toggle('on', selected);
    b.setAttribute('aria-pressed', String(selected));
  }); }

  // ---------- 场景 ----------
  qa('[data-scene]').forEach(function (b) {
    b.addEventListener('click', function () { setScene(b.dataset.scene); Analytics.track(NAME, '场景', b.textContent); });
  });
  function setScene(sc) {
    resetDrag();
    state.scene = sc;
    if (sc === 'quiz' && !state.quiz) newQuiz();
    $('rName').className = '';
    syncUI();
  }

  // ---------- 场景一：切割磁感线 ----------
  function rel() { var c = state.cut; return { x: c.rod.x - c.mag.x, y: c.rod.y - c.mag.y, z: c.rod.z }; }
  // 把导体相对磁体的位置限制在活动范围内，再写回运动的那个物体
  function setRel(r) {
    var c = state.cut;
    var xMin = c.move === 'mag' ? -7.2 : view.narrow() ? -13 : CUT.xMin;
    r = { x: M.clamp(r.x, xMin, CUT.xMax), y: M.clamp(r.y, -CUT.yMax, CUT.yMax), z: M.clamp(r.z, -CUT.zMax, CUT.zMax) };
    if (c.move === 'mag') { c.mag.x = c.rod.x - r.x; c.mag.y = c.rod.y - r.y; c.rod.z = r.z; }
    else { c.rod.x = c.mag.x + r.x; c.rod.y = c.mag.y + r.y; c.rod.z = r.z; }
  }
  function setMove(m) {
    var c = state.cut, r = rel();
    resetDrag();
    c.move = m;
    if (m === 'mag') { c.rod = { x: ROD_FIXED, y: 0, z: r.z }; c.mag = { x: ROD_FIXED - r.x, y: -r.y }; }
    else { c.mag = { x: 0, y: 0 }; c.rod = { x: r.x, y: r.y, z: r.z }; }
    setRel(r);
  }
  qa('[data-move]').forEach(function (b) {
    b.addEventListener('click', function () { setMove(b.dataset.move); syncUI(); Analytics.track(NAME, '谁运动', b.textContent); });
  });
  qa('[data-auto]').forEach(function (b) {
    b.addEventListener('click', function () { setAuto(b.dataset.auto); Analytics.track(NAME, '自动', b.textContent); });
  });
  function setAuto(a) { var c = state.cut; c.auto = a; c.t = 0; c.rel0 = rel(); if (a === 'lr') c.rel0.x = -0.5; syncUI(); }
  qa('[data-pole]').forEach(function (b) {
    b.addEventListener('click', function () { state.cut.nTop = b.dataset.pole === 'N'; syncUI(); Analytics.track(NAME, '磁极', b.textContent); });
  });
  qa('[data-sw]').forEach(function (b) {
    b.addEventListener('click', function () { state.cut.closed = b.dataset.sw === 'on'; syncUI(); Analytics.track(NAME, '开关', b.textContent); });
  });

  // ---------- 场景二：磁铁与线圈 ----------
  qa('[data-face]').forEach(function (b) {
    b.addEventListener('click', function () { state.coil.d = b.dataset.face === 'N' ? 1 : -1; syncUI(); Analytics.track(NAME, '磁铁朝向', b.textContent); });
  });
  qa('[data-turns]').forEach(function (b) {
    b.addEventListener('click', function () { state.coil.turns = +b.dataset.turns; syncUI(); Analytics.track(NAME, '匝数', b.textContent); });
  });
  qa('[data-go]').forEach(function (b) {
    b.addEventListener('click', function () { go(b.dataset.go); Analytics.track(NAME, '磁铁', b.textContent); });
  });
  function go(where) {
    var c = state.coil;
    c.target = where === 'in' ? 0 : where === 'out' ? COIL.home : where === 'through' ? -COIL.home : null;
    // “穿过”时若磁铁已在右侧，就从右往左穿回去
    if (where === 'through' && c.xm > 0) c.target = COIL.home;
    if (where === 'out' && c.xm > 0) c.target = -COIL.home;
  }
  $('clearRec').addEventListener('click', function () { state.coil.rec = {}; syncRec(); });

  // ---------- 滑块、开关 ----------
  function bindSlider(id, get, set) {
    var el = $(id);
    el.addEventListener('input', function () { set(parseFloat(el.value)); });
    el.addEventListener('change', function () { Analytics.track(NAME, '滑块', id); });
    return { el: el, get: get };
  }
  var sliders = [
    bindSlider('B', function () { return state.cut.B; }, function (x) { state.cut.B = x; }),
    bindSlider('spd', function () { return state.cut.speed; }, function (x) { state.cut.speed = x; }),
    bindSlider('vm', function () { return state.coil.speed; }, function (x) { state.coil.speed = x; })
  ];
  [['showLines', state.show, 'lines'], ['showVec', state.show, 'vectors'], ['showLenz', state.coil.show, 'lenz'], ['showForce', state.coil.show, 'force'],
    ['showMagLines', state.coil.show, 'lines']].forEach(function (p) {
    $(p[0]).addEventListener('change', function () { p[1][p[2]] = $(p[0]).checked; });
  });

  // ---------- 画布拖动 ----------
  function local(e) { var r = cv.getBoundingClientRect(); return { x: e.clientX - r.left, y: e.clientY - r.top }; }
  cv.addEventListener('pointerdown', function (e) {
    if (e.button !== 0 || drag || state.scene === 'quiz') return;
    var g = view.geo(); if (!g || !g.fr) return;
    drag = { last: local(e), id: e.pointerId };
    drawing.classList.add('dragging');
    try { cv.setPointerCapture(e.pointerId); } catch (err) { /* 合成事件 */ }
    if (state.scene === 'cut') { if (state.cut.auto !== 'off') { state.cut.auto = 'off'; syncUI(); } }
    else state.coil.target = null;
    Analytics.track(NAME, '拖动', state.scene);
  });
  cv.addEventListener('pointermove', function (e) {
    if (!drag || drag.id !== e.pointerId) return;
    var g = view.geo(), p = local(e), dx = (p.x - drag.last.x) / g.k, dy = -(p.y - drag.last.y) / g.k;
    drag.last = p;
    if (state.scene === 'cut') {
      var r = rel(), s = state.cut.move === 'mag' ? -1 : 1;
      setRel({ x: r.x + s * dx, y: r.y + s * dy, z: r.z });
      var next = rel();
      cutDrag.x += next.x - r.x;
      cutDrag.y += next.y - r.y;
    } else if (state.scene === 'coil') {
      var x0 = state.coil.xm;
      state.coil.xm = M.clamp(x0 + dx, COIL.xMin, COIL.xMax);
      coilDrag += state.coil.xm - x0;
    }
  });
  function releaseDrag() {
    if (!drag) return;
    var id = drag.id;
    drag = null;
    drawing.classList.remove('dragging');
    if (cv.hasPointerCapture(id)) cv.releasePointerCapture(id);
  }
  function resetDrag() {
    releaseDrag();
    cutDrag.x = cutDrag.y = cutDrag.z = coilDrag = 0;
  }
  ['pointerup', 'pointercancel', 'lostpointercapture'].forEach(function (name) {
    cv.addEventListener(name, function (e) {
      if (drag && drag.id === e.pointerId) releaseDrag();
    });
  });

  // ---------- 练习 ----------
  function newQuiz() {
    state.quiz = M.quiz(Math.random, state.quiz && state.quiz.id, state.quizOnly);
    state.answered = false; state.choice = null;
    var box = $('quizOpts');
    box.innerHTML = '';
    state.quiz.options.forEach(function (o) {
      var b = document.createElement('button');
      b.className = 'small';
      b.textContent = o;
      b.addEventListener('click', function () { answer(o); });
      box.appendChild(b);
    });
    syncUI();
  }
  function answer(o) {
    if (state.answered) return;
    state.answered = true;
    state.choice = o;
    state.correct = o === state.quiz.answer;
    state.score.n++; if (state.correct) state.score.ok++;
    Analytics.track(NAME, '练习', state.quiz.type + (state.correct ? ' 对' : ' 错'));
    syncUI();
  }
  $('nextQ').addEventListener('click', newQuiz);
  $('showQ').addEventListener('click', function () {
    var q = state.quiz;
    if (q.type === 'cut') { state.cut.closed = !q.open; setScene('cut'); return; }
    var c = state.coil;
    c.d = q.pole === 'N' ? 1 : -1;
    if (q.move === 'stay') { c.xm = 0; c.target = null; }
    else { c.xm = q.move === 'in' ? COIL.home : 0; go(q.move === 'in' ? 'in' : 'out'); }
    setScene('coil');
  });

  // ---------- 面板 ----------
  function setPanel(open) {
    panel.classList.toggle('collapsed', !open);
    panel.inert = !open;
    $('panelToggle').setAttribute('aria-expanded', String(open));
  }
  $('panelToggle').addEventListener('click', function () {
    var open = panel.classList.contains('collapsed');
    setPanel(open);
    if (open) $('panelClose').focus({ preventScroll: true });
  });
  function closePanel() {
    setPanel(false);
    $('panelToggle').focus({ preventScroll: true });
  }
  $('panelClose').addEventListener('click', closePanel);
  panel.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && phone.matches) closePanel();
  });
  phone.addEventListener('change', function () { setPanel(!phone.matches); });
  setPanel(!phone.matches);
  $('plotToggle').addEventListener('click', function () {
    showPlot = !showPlot;
    this.classList.toggle('on', showPlot);
    this.setAttribute('aria-pressed', String(showPlot));
  });

  function syncRec() {
    ['Nin', 'Nout', 'Sin', 'Sout'].forEach(function (k) {
      var r = state.coil.rec[k], cells = qa('#rec tr[data-k="' + k + '"] td');
      var vals = r ? [r.b0, r.change, r.b1, r.cw] : ['', '', '', ''];
      for (var i = 0; i < 4; i++) cells[i + 1].textContent = vals[i];
      $('rec').querySelector('tr[data-k="' + k + '"]').classList.toggle('done', !!r);
    });
    var n = Object.keys(state.coil.rec).length;
    $('recordCount').textContent = n + ' / 4';
    $('recNote').textContent = n < 4 ? '还差 ' + (4 - n) + ' 种情形：用「插入」「拔出」或拖动磁铁，并切换 N、S 极。' : '四种情形都记录了：感应电流的磁场总是阻碍磁通量的变化。';
  }

  function syncUI() {
    var sc = state.scene, c = state.cut, k = state.coil;
    stage.dataset.mode = sc;
    drawing.classList.toggle('draggable', sc !== 'quiz');
    setSeg('scene', sc);
    qa('[data-for]').forEach(function (el) { el.hidden = el.dataset.for.split(' ').indexOf(sc) < 0; });
    $('hint').textContent = sc === 'cut' && c.move === 'mag' ? '拖动画面移动蹄形磁体，导体保持不动。' : HINTS[sc];
    setSeg('move', c.move);
    setSeg('auto', c.auto);
    setSeg('pole', c.nTop ? 'N' : 'S');
    setSeg('sw', c.closed ? 'on' : 'off');
    setSeg('face', k.d > 0 ? 'N' : 'S');
    setSeg('turns', k.turns);
    $('spdRow').hidden = c.auto === 'off';
    [['showLines', state.show.lines], ['showVec', state.show.vectors], ['showLenz', k.show.lenz], ['showForce', k.show.force], ['showMagLines', k.show.lines]]
      .forEach(function (p) { $(p[0]).checked = p[1]; });
    var q = state.quiz;
    if (q) {
      $('quizQ').textContent = q.prompt;
      qa('#quizOpts button').forEach(function (b) {
        b.disabled = state.answered;
        b.classList.toggle('on', state.answered && b.textContent === q.answer);
        b.classList.toggle('no', state.answered && b.textContent === state.choice && !state.correct);
      });
      $('quizMsg').innerHTML = !state.answered ? ''
        : '<b class="' + (state.correct ? 'ok">✓ 答对了' : 'bad">✗ 应选「' + q.answer + '」') + '</b>' + q.explain;
      $('nextQ').textContent = state.answered ? '下一题 →' : '换一题';
      $('showQ').hidden = !state.answered;
    }
  }

  // ---------- 读数 ----------
  var lastText = {};
  function setText(id, s) { if (lastText[id] !== s) { lastText[id] = s; $(id).textContent = s; } }
  function rows(list) {
    for (var i = 1; i <= 5; i++) {
      var r = list[i - 1] || ['', ''];
      setText('d' + i, r[0]); setText('r' + i, r[1]);
      $('d' + i).hidden = $('r' + i).hidden = !r[0];
    }
  }
  function cms(v) { return Math.abs(v) < 0.05 ? '0' : (v < 0 ? '−' : '') + Math.abs(v).toFixed(1) + ' cm/s'; }

  function currentLabel(I) { return Math.abs(I) < 0.5 ? '0 μA' : M.fmtI(I); }
  function signed(value, label) { return value < 0 && label !== '0' && label !== '0 μA' ? '−' + label : label; }

  function readCut(res) {
    var c = state.cut, v = c.v, sp = Math.hypot(v.x, v.y, v.z), moving = sp > 0.8, r = rel();
    var who = c.move === 'mag' ? '磁体' : '导体';
    var name, tip;
    if (res.cutting && c.closed) name = '有感应电流';
    else if (res.cutting) name = '电路断开';
    else name = '没有感应电流';
    setText('rName', name);
    setText('liveValue', currentLabel(res.I));
    $('rName').className = res.cutting && c.closed ? 'ok' : '';
    setText('rKind', res.dir ? (res.dir === 'AB' ? '导体中 A → B' : '导体中 B → A') : '');
    if (!moving) tip = '导体与磁体相对静止，没有切割磁感线。拖动画面或点「左右」。';
    else if (!res.cutting && res.frac < 0.02) tip = '导体在磁场外，不切割磁感线，没有感应电流。';
    else if (!res.cutting) tip = Math.abs(v.y) >= Math.abs(v.z) ? '导体沿磁感线方向（上下）运动，没有切割磁感线，不产生感应电流。' : '导体沿自身方向（前后）运动，没有切割磁感线，不产生感应电流。';
    else if (!c.closed) tip = '导体在切割磁感线，两端有感应电动势，但电路断开，没有感应电流。闭合开关试试。';
    else tip = '闭合电路的一部分导体做切割磁感线运动，产生感应电流。右手定则：磁感线垂直穿入掌心，拇指指向导体运动方向，四指指向感应电流方向。' +
      (c.move === 'mag' ? '磁体运动、导体不动也一样——只看二者的相对运动。' : '');
    setText('rTip', tip);
    var Bdir = c.nTop ? '竖直向下（N 上 S 下）' : '竖直向上（S 上 N 下）';
    rows([
      [who + '速度', c.move === 'mag' ? '水平 ' + cms(-v.x) + '，竖直 ' + cms(-v.y) : '水平 ' + cms(v.x) + '，竖直 ' + cms(v.y) + (Math.abs(v.z) > 0.05 ? '，前后 ' + cms(v.z) : '')],
      ['磁场', 'B = ' + c.B.toFixed(2) + ' T，' + Bdir],
      ['电动势', '|E| = BL|v⊥| = ' + M.fmtV(res.e) + '（L = ' + (CUT.L * 100 * res.frac).toFixed(1) + ' cm 在磁场中）'],
      ['感应电流', c.closed ? '|I| = |E|/R = ' + currentLabel(res.I) + '（R = ' + CUT.R + ' Ω）' : '0（开关断开）'],
      ['相对位置', r.x < CUT.x0 - 0.6 ? '导体在磁场左侧外面' : '导体在两磁极之间']
    ]);
  }

  function readCoil(res) {
    var k = state.coil, flowing = Math.abs(res.I) > 2, moving = Math.abs(k.vm) > 0.5;
    setText('rName', flowing ? '有感应电流' : Math.abs(res.I) >= 0.5 ? '感应电流很小' : '没有感应电流');
    setText('liveValue', currentLabel(res.I));
    $('rName').className = flowing ? 'ok' : '';
    setText('rKind', flowing ? '从左看' + (res.I > 0 ? '顺时针' : '逆时针') : '');
    var tip;
    if (!moving) tip = '磁铁静止，穿过线圈的磁通量不变，没有感应电流。拖动磁铁或点「插入」「拔出」。';
    else if (!flowing) tip = '穿过线圈的磁通量变化很慢，感应电流接近零。';
    else {
      var inc = Math.sign(res.rate) === Math.sign(res.phi), b0 = res.phi > 0 ? '向右' : '向左', b1 = res.I > 0 ? '向右' : '向左';
      tip = res.lead + ' 极' + (res.near ? '插入' : '拔出') + '：线圈内' + b0 + '的磁通量' + (inc ? '增大' : '减小') + '，感应电流的磁场' + b1 + '（' + (inc ? '增反' : '减同') +
        '），线圈靠近磁铁的一端是 ' + (res.near ? res.lead : (res.lead === 'N' ? 'S' : 'N')) + ' 极，' + (res.near ? '排斥磁铁（来拒）' : '吸引磁铁（去留）') + '。';
    }
    setText('rTip', tip);
    rows([
      ['磁通量', 'Φ = ' + M.fmtWb(res.phi) + '（每匝，向右为正）'],
      ['变化率', 'ΔΦ/Δt = ' + (Math.abs(res.rate) < 1e-7 ? '0' : (res.rate < 0 ? '−' : '') + (Math.abs(res.rate) * 1e3).toFixed(2) + '×10⁻³ Wb/s')],
      ['电动势', 'E = −nΔΦ/Δt = ' + signed(res.e, M.fmtV(res.e)) + '（n = ' + k.turns + '）'],
      ['感应电流', 'I = E/R = ' + signed(res.I, currentLabel(res.I)) + '（R = ' + COIL.R + ' Ω）'],
      ['磁铁速度', cms(Math.abs(k.vm)) + (moving ? (k.vm > 0 ? '，向右' : '，向左') : '')]
    ]);
  }

  function readQuiz() {
    var sc = state.score;
    setText('rName', '得分 ' + sc.ok + ' / ' + sc.n);
    setText('liveValue', '');
    setText('rKind', '');
    $('rName').className = '';
  }

  // ---------- 推进 ----------
  function stepCut(dt) {
    var c = state.cut, before = rel();
    if (c.auto !== 'off') {
      if (!c.rel0) c.rel0 = rel();
      c.t += dt;
      var w = 2 * Math.PI / 2.4 * c.speed, s = Math.sin(w * c.t), r = { x: c.rel0.x, y: c.rel0.y, z: c.rel0.z };
      if (c.auto === 'lr') r.x = c.rel0.x + 4.5 * s;
      else if (c.auto === 'ud') r.y = 1.9 * s;
      else r.z = 3.2 * s;
      setRel(r);
    }
    var after = rel(), a = Math.min(1, dt / 0.05);
    ['x', 'y', 'z'].forEach(function (key) { c.v[key] += ((after[key] - before[key] + cutDrag[key]) / dt - c.v[key]) * a; });
    cutDrag.x = cutDrag.y = cutDrag.z = 0;
    c.res = M.cut(c.B, c.nTop, after, c.v, c.closed);
    c.needle += (c.res.needle - c.needle) * Math.min(1, dt * 10);
    c.flow += c.res.I / CUT.FULL * 4 * dt;   // 电流点的移动（单位 cm）
  }
  function stepCoil(dt) {
    var k = state.coil, x0 = k.xm;
    if (k.target != null) {
      var d = k.target - k.xm, st = k.speed * dt;
      if (Math.abs(d) <= st) { k.xm = k.target; k.target = null; } else k.xm += Math.sign(d) * st;
    }
    var a = Math.min(1, dt / 0.06);
    k.vm += ((k.xm - x0 + coilDrag) / dt - k.vm) * a;
    coilDrag = 0;
    if (Math.abs(k.vm) < 0.02) k.vm = 0;
    k.res = M.coil(k.xm, k.vm, k.d, k.turns);
    k.needle += (k.res.needle - k.needle) * Math.min(1, dt * 10);
    k.flow += k.res.I / COIL.FULL * 6 * dt;
    k.now += dt;
    k.hist.push({ t: k.now, phi: k.res.phi, I: k.res.I });
    while (k.hist.length && k.now - k.hist[0].t > 8.5) k.hist.shift();
    var r = M.record(k.res);
    if (r) { var old = k.rec[r.key]; k.rec[r.key] = r; if (!old) { syncRec(); Analytics.track(NAME, '记录', r.key); } }
  }

  // ---------- 尺寸与主循环 ----------
  function resize() { view.resize(drawing.clientWidth, drawing.clientHeight); }
  new ResizeObserver(resize).observe(drawing);

  // 支持 ?scene=cut|coil|quiz；切割 &move=rod|mag、&auto=off|lr|ud|fb、&B=0.1~1、&s=1（S 极在上）、&open=1；
  // 线圈 &pole=N|S、&n=100|200|400、&x=−22~20（磁铁中心 cm）、&go=in|out|through、&v=5~40（cm/s）；练习 &q=cut|lenz|ring
  var qs = new URLSearchParams(location.search);
  function num(key, lo, hi) { var x = parseFloat(qs.get(key)); return isFinite(x) && x >= lo && x <= hi ? x : null; }
  var x;
  if (Object.prototype.hasOwnProperty.call(HINTS, qs.get('scene'))) state.scene = qs.get('scene');
  if (qs.get('move') === 'mag') setMove('mag');
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) state.cut.auto = 'off';
  if (AUTOS.indexOf(qs.get('auto')) >= 0) state.cut.auto = qs.get('auto');
  if ((x = num('B', CUT.B_RANGE[0], CUT.B_RANGE[1])) != null) state.cut.B = x;
  if (qs.get('s') === '1') state.cut.nTop = false;
  if (qs.get('open') === '1') state.cut.closed = false;
  if (qs.get('pole') === 'S') state.coil.d = -1;
  if (COIL.TURNS.indexOf(+qs.get('n')) >= 0) state.coil.turns = +qs.get('n');
  if ((x = num('x', COIL.xMin, COIL.xMax)) != null) state.coil.xm = x;
  if ((x = num('v', COIL.V_RANGE[0], COIL.V_RANGE[1])) != null) state.coil.speed = x;
  if (['in', 'out', 'through'].indexOf(qs.get('go')) >= 0) go(qs.get('go'));
  if (M.TYPES.indexOf(qs.get('q')) >= 0) state.quizOnly = qs.get('q');
  setAuto(state.cut.auto);

  resize();
  setScene(state.scene);
  syncRec();

  var lastT = performance.now();
  function frame(now) {
    var dt = Math.min((now - lastT) / 1000, 0.1) || 1 / 60;
    lastT = now;
    var sc = state.scene;
    sliders.forEach(function (s) { if (document.activeElement !== s.el) s.el.value = s.get(); });
    setText('BOut', state.cut.B.toFixed(2) + ' T');
    setText('spdOut', state.cut.speed.toFixed(1) + '×');
    setText('vmOut', state.coil.speed.toFixed(0) + ' cm/s');
    if (sc === 'cut') {
      stepCut(dt);
      var c = state.cut;
      view.drawCut({ B: c.B, nTop: c.nTop, mag: c.mag, rod: c.rod, closed: c.closed, res: c.res, v: c.v, flow: c.flow,
        vectors: state.show.vectors, lines: state.show.lines, needle: c.needle });
      readCut(c.res);
    } else if (sc === 'coil') {
      stepCoil(dt);
      var k = state.coil;
      view.drawCoil({ xm: k.xm, d: k.d, turns: k.turns, res: k.res, vm: k.vm, flow: k.flow, needle: k.needle, lines: k.show.lines,
        show: k.show, plot: showPlot, hist: k.hist, now: k.now });
      readCoil(k.res);
    } else {
      view.drawQuiz(state.quiz, state.answered);
      readQuiz();
    }
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // 调试用
  window.__model = {
    state: state, setScene: setScene, newQuiz: newQuiz, syncUI: syncUI, go: go, setMove: setMove, setAuto: setAuto,
    setRel: function (x, y, z) { setRel({ x: x, y: y || 0, z: z || 0 }); },
    setX: function (x) { state.coil.target = null; state.coil.xm = M.clamp(x, COIL.xMin, COIL.xMax); }
  };
})();
