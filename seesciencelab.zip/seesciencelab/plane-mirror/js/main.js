(function () {
  var Mr = window.Mirror, G = Mr.GEO;
  var $ = function (id) { return document.getElementById(id); };
  var qa = function (sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); };

  var state = {
    scene: 'reflect',
    // 反射定律
    i: 40, lr: -1, surface: 'mirror', ghost: null, records: [],
    // 平面镜成像（俯视，cm）
    obj: { x: -10, y: 3 }, eye: { x: -24, y: -8 }, candleB: { x: 17, y: -6 },
    shape: 'candle', plate: 'thin', showB: true, screen: false,
    // 潜望镜（侧视，cm）
    pObj: { x: -20, y: 32 }, pH: 6, pEye: { x: 14, y: 4.5 }, botAngle: 45,
    show: { angles: true, ring: true, pulse: true, rays: true, mid: false },
    t: 0
  };

  var HINTS = {
    reflect: '拖动激光笔（或在镜面上方任意处拖动）改变入射角',
    image: '拖动蜡烛 A、蜡烛 B 或眼睛 · 让 B 与 A 的像重合',
    peri: '拖动物体或眼睛 · 看光在两块平面镜间怎样拐弯'
  };

  var stage = $('stage'), canvas = $('ray'), panel = $('panel');
  var view = window.MirrorDraw(canvas);

  function solve() {
    if (state.scene === 'reflect') return state.surface === 'diffuse' ? Mr.diffuse(state.i, state.lr, 9) : Mr.law(state.i, state.lr);
    if (state.scene === 'image') return Mr.solveImage(state);
    return Mr.solvePeri(state);
  }
  var sol = null;

  function setSeg(attr, val) { qa('[data-' + attr + ']').forEach(function (b) { b.classList.toggle('on', b.dataset[attr] === val); }); }
  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }

  // ---------- 场景 ----------
  qa('[data-scene]').forEach(function (b) {
    b.addEventListener('click', function () { setScene(b.dataset.scene); Analytics.track('平面镜', '场景', b.textContent); });
  });
  function setScene(sc) { state.scene = sc; syncUI(); }

  // ---------- 反射定律 ----------
  qa('[data-surface]').forEach(function (b) {
    b.addEventListener('click', function () { state.surface = b.dataset.surface; state.ghost = null; syncUI(); Analytics.track('平面镜', '反射面', b.textContent); });
  });
  var incEl = $('inc');
  incEl.addEventListener('input', function () { state.i = parseFloat(incEl.value); state.ghost = null; syncUI(); });
  $('reverse').addEventListener('click', function () {
    // 让光逆着原来的反射光线射回去：激光笔换到法线另一侧，入射角不变
    state.ghost = { i: state.i, lr: state.lr };
    state.lr = -state.lr;
    syncUI();
    $('lawNote').textContent = '光逆着原来的反射光线射到镜面上，反射光沿原来入射光线的反方向射出：光路可逆。';
    Analytics.track('平面镜', '光路可逆');
  });
  $('toNormal').addEventListener('click', function () { state.i = 0; state.ghost = null; syncUI(); });
  $('record').addEventListener('click', function () {
    if (state.records.length >= 6) state.records.shift();
    state.records.push(state.i);
    renderRecords();
    Analytics.track('平面镜', '记录数据');
  });
  $('clearRec').addEventListener('click', function () { state.records = []; renderRecords(); });
  function renderRecords() {
    var tb = $('recBody');
    tb.innerHTML = '';
    state.records.forEach(function (i, k) {
      var tr = document.createElement('tr');
      tr.innerHTML = '<td>' + (k + 1) + '</td><td>' + i.toFixed(1) + '°</td><td>' + i.toFixed(1) + '°</td>';
      tb.appendChild(tr);
    });
    $('recTable').hidden = !state.records.length;
    $('recNote').textContent = state.records.length >= 3 ? '多次实验，每次反射角都等于入射角——结论具有普遍性。' :
      state.records.length ? '改变入射角，再记录几组。' : '改变入射角，点「记录」测几组数据。';
  }

  // ---------- 平面镜成像 ----------
  qa('[data-shape]').forEach(function (b) {
    b.addEventListener('click', function () { state.shape = b.dataset.shape; syncUI(); Analytics.track('平面镜', '物体', b.textContent); });
  });
  qa('[data-plate]').forEach(function (b) {
    b.addEventListener('click', function () { state.plate = b.dataset.plate; syncUI(); Analytics.track('平面镜', '镜面', b.textContent); });
  });
  $('showB').addEventListener('change', function () { state.showB = $('showB').checked; });
  $('screen').addEventListener('change', function () { state.screen = $('screen').checked; if (state.screen) Analytics.track('平面镜', '光屏'); });
  $('moveB').addEventListener('click', function () {
    var I = Mr.reflectPoint(state.obj, Mr.v(0, -15), Mr.v(0, 15));
    state.candleB = { x: I.x, y: I.y };
    state.showB = true; $('showB').checked = true;
  });
  $('nearer').addEventListener('click', function () { moveObj(-1); });
  $('farther').addEventListener('click', function () { moveObj(1); });
  function moveObj(dir) {
    state.obj.x = clamp(state.obj.x - dir * 3, -24, -2);
    Analytics.track('平面镜', dir < 0 ? '靠近镜面' : '远离镜面');
  }

  // ---------- 潜望镜 ----------
  var angEl = $('botAngle');
  angEl.addEventListener('input', function () { state.botAngle = parseFloat(angEl.value); syncUI(); });
  $('to45').addEventListener('click', function () { state.botAngle = 45; syncUI(); });

  // ---------- 显示 ----------
  [['showAngles', 'angles'], ['showRing', 'ring'], ['showPulse', 'pulse'], ['showRays', 'rays'], ['showMid', 'mid']].forEach(function (p) {
    $(p[0]).addEventListener('change', function () { state.show[p[1]] = $(p[0]).checked; });
  });

  // ---------- 拖动 ----------
  var drag = null;
  function localXY(e) { var r = canvas.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; }
  function dragTo(px, py) {
    if (drag === 'laser') {
      var a = view.lawAngle(px, py);
      state.lr = a.lr; state.i = Math.round(a.i * 2) / 2; state.ghost = null;
      syncUI();
      return;
    }
    var w = view.toWorld(px, py), b = view.bounds(state.scene);
    if (state.scene === 'image') {
      if (drag === 'obj') { state.obj.x = clamp(w.x, Math.max(-24, b.x0 + 3), -2); state.obj.y = clamp(w.y, -12, 12); }
      else if (drag === 'eye') { state.eye.x = clamp(w.x, b.x0 + 2, b.x1 - 2); state.eye.y = clamp(w.y, -14, 15); }
      else if (drag === 'B') {
        state.candleB.x = clamp(w.x, 1.5, b.x1 - 2); state.candleB.y = clamp(w.y, -12, 13);
        // 很接近时吸附到像上，方便"完全重合"
        var I = Mr.reflectPoint(state.obj, Mr.v(0, -15), Mr.v(0, 15));
        if (Math.hypot(I.x - state.candleB.x, I.y - state.candleB.y) < G.image.match) state.candleB = { x: I.x, y: I.y };
      }
    } else {
      if (drag === 'obj') { state.pObj.x = clamp(w.x, -25, -12); state.pObj.y = clamp(w.y - state.pH / 2, 24, 40); }
      else if (drag === 'eye') { state.pEye.x = clamp(w.x, 8, b.x1 - 2); state.pEye.y = clamp(w.y, -1, 12); }
    }
  }
  canvas.addEventListener('pointerdown', function (e) {
    var p = localXY(e);
    drag = view.hit(p[0], p[1], state, false);
    if (!drag) return;
    try { canvas.setPointerCapture(e.pointerId); } catch (err) { /* 合成事件无法捕获指针 */ }
    canvas.classList.add('grabbing');
    if (drag === 'laser') dragTo(p[0], p[1]);
  });
  canvas.addEventListener('pointermove', function (e) {
    var p = localXY(e);
    if (!drag) { canvas.classList.toggle('grab', !!view.hit(p[0], p[1], state, true)); return; }
    dragTo(p[0], p[1]);
  });
  function endDrag(e) {
    if (!drag) return;
    if (drag === 'B' && sol && sol.matched) Analytics.track('平面镜', 'B 与像重合');
    drag = null;
    canvas.classList.remove('grabbing');
    if (canvas.hasPointerCapture(e.pointerId)) canvas.releasePointerCapture(e.pointerId);
  }
  canvas.addEventListener('pointerup', endDrag);
  canvas.addEventListener('pointercancel', endDrag);

  // ---------- 面板同步 ----------
  function syncUI() {
    var sc = state.scene;
    setSeg('scene', sc);
    qa('[data-for]').forEach(function (el) {
      var f = el.dataset.for.split(' ');
      el.hidden = f.indexOf(sc) < 0 || (f.indexOf('mirror') >= 0 && state.surface !== 'mirror') || (f.indexOf('candle') >= 0 && state.shape !== 'candle');
    });
    $('hint').textContent = sc === 'image' && state.shape === 'F' ? '拖动字母 F 或眼睛 · 看像与物左右相反'
      : sc === 'reflect' && state.surface === 'diffuse' ? '在表面上方拖动，改变平行光射来的方向' : HINTS[sc];
    setSeg('surface', state.surface); setSeg('shape', state.shape); setSeg('plate', state.plate);
    incEl.value = state.i; $('incOut').textContent = state.i.toFixed(1) + '°';
    angEl.value = state.botAngle; $('botAngleOut').textContent = state.botAngle.toFixed(0) + '°';
    if (!state.ghost) $('lawNote').textContent = '';
  }

  $('panelToggle').addEventListener('click', function () { panel.classList.toggle('collapsed'); });
  if (window.matchMedia('(max-width: 760px)').matches) panel.classList.add('collapsed');

  // ---------- 读数 ----------
  var last = {};
  function setText(id, s) { if (last[id] !== s) { last[id] = s; $(id).textContent = s; } }
  function rows(list) {
    for (var k = 1; k <= 5; k++) {
      var r = list[k - 1] || ['', ''];
      setText('d' + k, r[0]); setText('r' + k, r[1]);
      $('d' + k).hidden = $('r' + k).hidden = !r[0];
    }
  }
  function setBig(str, cls) { setText('rState', str); $('rState').className = cls || ''; }
  function deg(a) { return a.toFixed(1) + '°'; }
  function cm(a) { return a.toFixed(1) + ' cm'; }

  function readReflect(s) {
    if (state.surface === 'diffuse') {
      setBig('漫反射', 'ok');
      setText('rTip', '入射光彼此平行，但粗糙表面各处的法线方向不同，反射光射向各个方向。所以我们能从各个方向看到书本、黑板上的字。');
      var rs = s.map(function (r) { return r.r; });
      rows([
        ['入射光', '互相平行，入射角都是 ' + deg(state.i) + '（相对整体表面）'],
        ['反射光', '射向四面八方'],
        ['每条光线', '相对自己那一小块的法线：反射角 = 入射角 ✓'],
        ['反射角', rs.length ? '从 ' + deg(Math.min.apply(null, rs)) + ' 到 ' + deg(Math.max.apply(null, rs)) + ' 不等' : '—'],
        ['对比', '镜面反射：平行光反射后仍平行']
      ]);
      return;
    }
    if (state.i <= 0.4) setBig('垂直入射：原路返回', 'ok');
    else setBig('反射角 = 入射角', 'ok');
    setText('rTip', state.i <= 0.4 ? '入射角为 0°，反射角也为 0°，反射光线与入射光线重合、方向相反。'
      : '反射光线、入射光线分居法线两侧，反射角等于入射角。入射角增大，反射角也增大。');
    rows([
      ['入射角 i', deg(state.i) + '（入射光线与法线的夹角）'],
      ['反射角 r', deg(s.r)],
      ['与镜面夹角', deg(90 - state.i) + '（不是入射角！）'],
      ['两光线夹角', deg(2 * state.i)],
      ['三线', '反射光线、入射光线、法线在同一平面内']
    ]);
  }

  function readImage(s) {
    var A = state.obj;
    if (state.shape === 'candle' && state.showB && s.matched) setBig('✓ B 与 A 的像完全重合', 'ok');
    else setBig('像距 = 物距', 'ok');
    var tip;
    if (!s.seenAny) tip = state.eye.x >= 0 ? '眼睛在镜子后面，光射不进眼睛。但像仍然在那里——换个位置就能看见。' : '从这个位置，A 射到镜面上的光反射后进不了眼睛（镜子不够大）。像仍然存在。';
    else if (state.screen) tip = '像的位置上并没有光会聚，光屏上承接不到像：平面镜成的是虚像，只能透过镜子看到。';
    else if (state.plate === 'thick') tip = '厚玻璃板的前、后两个表面各成一个像，两个像错开，很难确定像的位置——实验要用薄玻璃板。';
    else if (state.shape === 'F') tip = '像和物关于镜面对称：上下不变，左右相反（"F"的横笔朝左了）。';
    else if (state.plate === 'mirror') tip = '平面镜不透明，看不到镜后的蜡烛 B，没法确定像的位置——所以实验用玻璃板代替平面镜。';
    else if (state.showB && s.matched) tip = '蜡烛 B 好像也被点燃了：B 所在的位置就是像的位置。像与物大小相等（两支蜡烛完全相同）。';
    else if (state.showB) tip = '在玻璃板后面移动未点燃的蜡烛 B，直到从前面看去它和 A 的像完全重合。';
    else tip = '眼睛逆着反射光线看去，好像光是从镜后的像点发出的。';
    setText('rTip', tip);
    var list = [
      ['物距 u', cm(s.u) + '（物体到镜面）'],
      ['像距 v', cm(s.v) + '（像到镜面）'],
      ['大小', '像与物等大；靠近或远离镜面，像的大小都不变'],
      ['连线', '物与像的连线与镜面垂直']
    ];
    if (state.shape === 'candle' && state.showB) list.push(['蜡烛 B', s.matched ? '与像重合，B 到镜面 ' + cm(state.candleB.x) : '离像 ' + cm(s.gapB)]);
    else list.push(['性质', '正立、等大的虚像']);
    rows(list);
  }

  function readPeri(s) {
    var ok = s.tip.ok && s.base.ok;
    if (!s.parallel) setBig('两镜不平行：像歪了', 'bad');
    else setBig(ok ? '看到正立的虚像' : '光进不了眼睛', ok ? 'ok' : 'bad');
    setText('rTip', !s.parallel ? '两块平面镜不平行时，光经两次反射后方向偏了，看到的像是倾斜的。两镜都与镜筒成 45° 且互相平行才合适。'
      : '物体的光射到平面镜 1 上，反射后竖直向下，再经平面镜 2 反射后水平射入眼睛。经过两次成像，像是正立的。');
    rows([
      ['平面镜 1', '与水平面成 45°'],
      ['平面镜 2', '与水平面成 ' + state.botAngle.toFixed(0) + '°' + (s.parallel ? '（两镜平行）' : '')],
      ['像的位置', '比物体低 ' + cm(-s.shift.y) + '，远 ' + cm(-s.shift.x)],
      ['像的方向', s.upright && Math.abs(s.tiltImg) < 0.5 ? '正立' : '倾斜 ' + Math.abs(s.tiltImg).toFixed(0) + '°'],
      ['光路', ok ? '光经两次反射进入眼睛' : s.tip.ok || s.base.ok ? '只有一部分光进入眼睛' : '光进不了眼睛']
    ]);
  }

  // ---------- 尺寸与主循环 ----------
  function resize() { view.resize(stage.clientWidth, stage.clientHeight); }
  new ResizeObserver(resize).observe(stage);

  // 支持 ?scene=image&shape=F&plate=thick、?scene=reflect&surface=diffuse 这样的链接
  var qs = new URLSearchParams(location.search);
  if (HINTS[qs.get('scene')]) state.scene = qs.get('scene');
  if (qs.get('shape') === 'F') state.shape = 'F';
  if (['thin', 'thick', 'mirror'].indexOf(qs.get('plate')) >= 0) state.plate = qs.get('plate');
  if (qs.get('surface') === 'diffuse') state.surface = 'diffuse';

  resize();
  renderRecords();
  syncUI();

  var lastT = performance.now();
  function frame(t) {
    var dt = Math.min((t - lastT) / 1000, 0.1);
    lastT = t;
    state.t += dt;
    sol = solve();
    view.draw(state, sol);
    if (state.scene === 'reflect') readReflect(sol);
    else if (state.scene === 'image') readImage(sol);
    else readPeri(sol);
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // 调试用
  window.__model = { state: state, setScene: setScene, solve: solve, syncUI: syncUI };
})();
