// 光的反射与平面镜成像：纯几何计算（世界坐标 y 向上，单位 cm），不碰 DOM
// 平面镜看作一条线段 A–B；像点 = 物点关于镜面所在直线的对称点。
(function () {
  var RAD = Math.PI / 180;

  // ---------- 向量 ----------
  function v(x, y) { return { x: x, y: y }; }
  function add(a, b) { return v(a.x + b.x, a.y + b.y); }
  function sub(a, b) { return v(a.x - b.x, a.y - b.y); }
  function mul(a, k) { return v(a.x * k, a.y * k); }
  function dot(a, b) { return a.x * b.x + a.y * b.y; }
  function cross(a, b) { return a.x * b.y - a.y * b.x; }
  function len(a) { return Math.hypot(a.x, a.y); }
  function lerp(a, b, t) { return v(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t); }

  // 点 P 关于直线 AB 的对称点（平面镜成像）
  function reflectPoint(P, A, B) {
    var d = sub(B, A), t = dot(sub(P, A), d) / dot(d, d);
    var F = add(A, mul(d, t));                 // 垂足
    return sub(mul(F, 2), P);
  }
  // 方向 d 被直线 AB 反射后的方向
  function reflectDir(d, A, B) {
    var u = sub(B, A), k = 2 * dot(d, u) / dot(u, u);
    return sub(mul(u, k), d);
  }
  // 点 P 到直线 AB 的有向距离（AB 左侧为正）
  function sideDist(P, A, B) { var d = sub(B, A); return cross(d, sub(P, A)) / len(d); }

  // 直线 PQ 与直线 AB 的交点；u 为交点在 AB 上的参数（0–1 之间即落在镜面上），t 为在 PQ 上的参数
  function lineCross(P, Q, A, B) {
    var r = sub(Q, P), s = sub(B, A), den = cross(r, s);
    if (Math.abs(den) < 1e-12) return null;
    var w = sub(A, P);
    var t = cross(w, s) / den, u = cross(w, r) / den;
    return { P: add(P, mul(r, t)), t: t, u: u };
  }

  // 物点 P 发出的光经镜面 AB 反射后进入眼睛 E：反射点 M 在"眼睛—像点"连线与镜面的交点上
  function viewVia(P, E, A, B) {
    var I = reflectPoint(P, A, B);
    var c = lineCross(E, I, A, B);
    var same = sideDist(P, A, B) * sideDist(E, A, B) > 0;   // 物和眼在镜子同一侧才看得见
    var ok = !!c && same && c.u >= 0 && c.u <= 1 && c.t > 0 && c.t < 1;
    return { P: P, E: E, I: I, M: c ? c.P : null, ok: ok, u: c ? c.u : NaN };
  }

  // 线段 PQ 是否在 y∈[y0, y1] 的范围内穿过竖直线 x = xw（用于潜望镜的开口）
  function through(P, Q, xw, y0, y1) {
    if ((P.x - xw) * (Q.x - xw) > 0) return false;
    if (Math.abs(Q.x - P.x) < 1e-9) return false;
    var y = P.y + (Q.y - P.y) * (xw - P.x) / (Q.x - P.x);
    return y >= y0 && y <= y1;
  }

  // ================= 场景一：反射定律 =================
  // 粗糙表面的小镜面：法线相对竖直方向的偏角（°），按固定伪随机生成，每次打开都一样
  var FACETS = (function () {
    var out = [], seed = 7;
    function rnd() { seed = (seed * 16807) % 2147483647; return seed / 2147483647; }
    for (var k = 0; k < 15; k++) out.push((rnd() * 2 - 1) * 24);
    return out;
  })();

  // 入射光与（局部）法线夹角为 i 时的反射光；lr = −1 表示光从法线左侧射来
  // 返回入射、反射光的单位方向（光传播方向，y 向上）
  function law(i, lr, tilt) {
    tilt = tilt || 0;                              // 局部法线相对竖直方向的偏角（°，向右为正）
    var n = v(Math.sin(tilt * RAD), Math.cos(tilt * RAD));
    var dIn = v(-lr * Math.sin(i * RAD), -Math.cos(i * RAD));   // 竖直法线下的入射方向
    var dOut = sub(dIn, mul(n, 2 * dot(dIn, n)));
    var r = Math.acos(Math.max(-1, Math.min(1, dot(dOut, n)))) / RAD;
    return { dIn: dIn, dOut: dOut, n: n, i: Math.acos(Math.max(-1, Math.min(1, -dot(dIn, n)))) / RAD, r: r };
  }

  // 漫反射：一束平行光照到粗糙表面，每条光线在自己的小镜面上都遵循反射定律
  // 宽度归一化：光线落点 x ∈ [−0.5, 0.5]
  function diffuse(i, lr, nRays) {
    var out = [];
    for (var k = 0; k < nRays; k++) {
      var x = -0.42 + 0.84 * k / (nRays - 1);
      var f = Math.min(FACETS.length - 1, Math.floor((x + 0.5) * FACETS.length));
      var L = law(i, lr, FACETS[f]);
      // 入射角大、小镜面又背着光时，光照不到这块小镜面——直接跳过
      // 反射光几乎贴着表面（会再打到旁边的小镜面上）的也略去
      if (dot(L.dIn, L.n) >= 0 || L.dOut.y < 0.12) continue;
      out.push({ x: x, tilt: FACETS[f], i: L.i, r: L.r, dIn: L.dIn, dOut: L.dOut, n: L.n });
    }
    return out;
  }

  // ================= 场景二：平面镜成像（俯视桌面） =================
  var GEO = {
    image: {
      mirror: { x: 0, y0: -15, y1: 15 },        // 镜面（玻璃板前表面）在 x = 0
      thick: 1.2,                                // 厚玻璃板的厚度（夸张）
      eyeHalf: 1.0,                              // 眼睛（瞳孔）半宽，夸张以便画出两条光线
      match: 0.6                                 // 蜡烛 B 与像的距离小于它算"重合"
    },
    // 潜望镜（侧视）：镜筒 x ∈ [0, w]，y ∈ [0, h]；上开口朝左，下开口朝右，两镜面都与水平成 45°
    peri: {
      w: 6, h: 40,
      top: { c: v(3, 36), a: 45 }, bot: { c: v(3, 4.5), a: 45 },
      openTop: [32, 40], openBot: [0, 9]
    }
  };

  // 字母 F 的笔画（本地坐标，cm）：用来看像与物"左右相反"
  var F_SHAPE = [
    [v(0, -3), v(0, 3)],
    [v(0, 3), v(3, 3)],
    [v(0, 0.4), v(2.2, 0.4)]
  ];

  function mirrorSeg(off) {
    var m = GEO.image.mirror;
    return [v(m.x + (off || 0), m.y0), v(m.x + (off || 0), m.y1)];
  }

  // 平面镜成像：物体 A（点或字母 F）、眼睛 E、蜡烛 B
  function solveImage(st) {
    var g = GEO.image, M = mirrorSeg(0), A = st.obj;
    var out = { u: -A.x - g.mirror.x, img: reflectPoint(A, M[0], M[1]) };
    out.v = out.img.x - g.mirror.x;
    // 厚玻璃板：后表面再成一个像
    if (st.plate === 'thick') { var M2 = mirrorSeg(g.thick); out.img2 = reflectPoint(A, M2[0], M2[1]); }
    // 物体轮廓与像的轮廓
    if (st.shape === 'F') {
      out.strokes = F_SHAPE.map(function (s) { return [add(A, s[0]), add(A, s[1])]; });
      var mirrorAll = function (m) { return out.strokes.map(function (s) { return [reflectPoint(s[0], m[0], m[1]), reflectPoint(s[1], m[0], m[1])]; }); };
      out.imgStrokes = mirrorAll(M);
      if (out.img2) out.imgStrokes2 = mirrorAll(mirrorSeg(g.thick));
      // 取两点（F 的顶端与底端）各画一条进入眼睛的光
      out.rays = [add(A, F_SHAPE[0][1]), add(A, F_SHAPE[0][0])].map(function (P) { return viewVia(P, st.eye, M[0], M[1]); });
    } else {
      // 蜡烛：从同一点射向瞳孔两边的两条光，反向延长线交于像点
      var E = st.eye, d = sub(out.img, E), n = len(d) || 1, perp = v(-d.y / n * g.eyeHalf, d.x / n * g.eyeHalf);
      out.rays = [viewVia(A, add(E, perp), M[0], M[1]), viewVia(A, sub(E, perp), M[0], M[1])];
    }
    out.seen = out.rays.every(function (r) { return r.ok; });
    out.seenAny = out.rays.some(function (r) { return r.ok; });
    out.gapB = len(sub(st.candleB, out.img));
    out.matched = out.gapB < g.match;
    return out;
  }

  // ================= 场景三：潜望镜 =================
  function periMirrors(st) {
    var p = GEO.peri, list = [];
    [[p.top, p.top.a], [p.bot, st.botAngle]].forEach(function (m) {
      var a = m[1] * RAD, c = m[0].c;
      var half = (p.w / 2) / Math.cos(a);       // 镜面两端顶到镜筒两壁
      var u = v(Math.cos(a) * half, -Math.sin(a) * half);
      list.push([sub(c, u), add(c, u)]);
    });
    return list;
  }

  // 物点 P 的光：经上镜面成像 P1，P1 再经下镜面成像 P2（眼睛看到的像）
  // 光路从眼睛倒推：E→P2 与下镜面交于 M2，M2→P1 与上镜面交于 M1，再连到 P
  function periRay(P, E, ms) {
    var p = GEO.peri, m1 = ms[0], m2 = ms[1];
    var P1 = reflectPoint(P, m1[0], m1[1]), P2 = reflectPoint(P1, m2[0], m2[1]);
    var c2 = lineCross(E, P2, m2[0], m2[1]);
    var c1 = c2 && lineCross(c2.P, P1, m1[0], m1[1]);
    var ok = !!(c1 && c2) && c2.u >= 0 && c2.u <= 1 && c1.u >= 0 && c1.u <= 1 && c2.t > 0 && c1.t > 0 &&
      through(E, c2.P, p.w, p.openBot[0], p.openBot[1]) && through(c1.P, P, 0, p.openTop[0], p.openTop[1]) &&
      c1.P.y > c2.P.y;
    return { P: P, P1: P1, P2: P2, M1: c1 ? c1.P : null, M2: c2 ? c2.P : null, ok: ok };
  }

  function solvePeri(st) {
    var ms = periMirrors(st), base = st.pObj, tip = add(base, v(0, st.pH));
    var rt = periRay(tip, st.pEye, ms), rb = periRay(base, st.pEye, ms);
    var dir = sub(rt.P2, rb.P2);
    return {
      mirrors: ms, tip: rt, base: rb,
      upright: dir.y > 0, tiltImg: Math.atan2(dir.x, dir.y) / RAD,     // 像相对竖直方向的倾斜（°）
      parallel: Math.abs(st.botAngle - GEO.peri.top.a) < 0.25,
      shift: sub(rb.P2, base)
    };
  }

  window.Mirror = {
    RAD: RAD, GEO: GEO, FACETS: FACETS, F_SHAPE: F_SHAPE,
    v: v, add: add, sub: sub, mul: mul, dot: dot, len: len, lerp: lerp,
    reflectPoint: reflectPoint, reflectDir: reflectDir, lineCross: lineCross, viewVia: viewVia, through: through,
    law: law, diffuse: diffuse, mirrorSeg: mirrorSeg, solveImage: solveImage, periMirrors: periMirrors, solvePeri: solvePeri
  };
})();
