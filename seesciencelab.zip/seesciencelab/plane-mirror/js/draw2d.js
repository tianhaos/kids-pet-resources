// 2D 绘图：反射定律（以入射点为圆心的量角盘）+ 平面镜成像（俯视桌面）+ 潜望镜（侧视），世界坐标 y 向上，单位 cm
// 视觉约定与折射、凸透镜模型一致：光线 #ffd166，反向延长线虚线，实物金色，虚像 = 半透明 + 紫色 #c9a7ff 虚线描边。
(function () {
  var Mr = window.Mirror, G = Mr.GEO, RAD = Math.PI / 180;

  var C = {
    grid: 'rgba(255,255,255,0.035)', axis: '#3c475a', text: '#c9d2df', muted: '#8d99ab', normal: 'rgba(230,235,242,0.55)',
    ray: '#ffd166', rayBack: 'rgba(255,209,102,0.6)', refl: '#7ee081', bad: '#ff7a59', obj: '#ffc94a',
    image: '#c9a7ff', imageFill: 'rgba(201,167,255,0.28)',
    mirror: '#d6deea', hatch: 'rgba(214,222,234,0.35)', glass: 'rgba(120,200,255,0.35)', glassEdge: '#8fd3ff',
    wax: '#f3e9d2', flame: '#ff9f43', tube: '#5b6578', tubeFill: 'rgba(91,101,120,0.16)'
  };

  var BOUNDS = {
    image: { x0: -32, x1: 30, y0: -18, y1: 17 },
    peri: { x0: -62, x1: 22, y0: -4, y1: 47 }
  };
  var BOUNDS_NARROW = {
    image: { x0: -27, x1: 22, y0: -18, y1: 17 },
    peri: { x0: -58, x1: 21, y0: -4, y1: 47 }
  };

  function MirrorDraw(canvas) {
    var ctx = canvas.getContext('2d');
    var W = 1, H = 1, dpr = 1, narrow = false, padT = 44, padB = 44;
    var s = 1, ox = 0, oy = 0;                 // 世界 → 像素：px = ox + x·s，py = oy − y·s
    var LO = { x: 0, y: 0, R: 100 };           // 反射定律场景：入射点与量角盘半径

    function resize(w, h) {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      W = w; H = h;
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
      canvas.style.width = w + 'px'; canvas.style.height = h + 'px';
      narrow = w < 640;
      padT = narrow ? 88 : 44; padB = 44;
    }

    function layout(scene) {
      if (scene === 'reflect') {
        var avail = H - padT - padB;
        LO.R = Math.max(60, Math.min(W * (narrow ? 0.42 : 0.34), avail * 0.72, 340));
        LO.x = W / 2; LO.y = padT + (avail + LO.R * 1.12) / 2;
        return;
      }
      var b = bounds(scene), aw = W - 32, ah = H - padT - padB;
      s = Math.min(aw / (b.x1 - b.x0), ah / (b.y1 - b.y0));
      ox = 16 + (aw - (b.x1 - b.x0) * s) / 2 - b.x0 * s;
      oy = padT + (ah - (b.y1 - b.y0) * s) / 2 + b.y1 * s;
    }
    function bounds(scene) { return (narrow ? BOUNDS_NARROW : BOUNDS)[scene]; }
    function X(x) { return ox + x * s; }
    function Y(y) { return oy - y * s; }
    function toWorld(px, py) { return { x: (px - ox) / s, y: (oy - py) / s }; }

    // ---------- 基本绘图 ----------
    function seg(x1, y1, x2, y2, color, width, dash) {
      ctx.beginPath();
      ctx.setLineDash(dash || []);
      ctx.strokeStyle = color; ctx.lineWidth = width || 1.5;
      ctx.moveTo(x1, y1); ctx.lineTo(x2, y2);
      ctx.stroke();
      ctx.setLineDash([]);
    }
    function wseg(a, b, color, width, dash) { seg(X(a.x), Y(a.y), X(b.x), Y(b.y), color, width, dash); }
    function arrowMid(x1, y1, x2, y2, color, alpha) {
      var len = Math.hypot(x2 - x1, y2 - y1);
      if (len < 34) return;
      ctx.save();
      ctx.globalAlpha = alpha === undefined ? 1 : alpha;
      ctx.translate((x1 + x2) / 2, (y1 + y2) / 2); ctx.rotate(Math.atan2(y2 - y1, x2 - x1));
      ctx.beginPath(); ctx.moveTo(6, 0); ctx.lineTo(-5, -4.5); ctx.lineTo(-5, 4.5); ctx.closePath();
      ctx.fillStyle = color; ctx.fill();
      ctx.restore();
    }
    function wray(a, b, color, width) { wseg(a, b, color, width); arrowMid(X(a.x), Y(a.y), X(b.x), Y(b.y), color); }
    function font(size, weight) {
      ctx.font = (weight || '') + ' ' + (size || 12) + 'px -apple-system, "PingFang SC", "Microsoft YaHei", sans-serif';
    }
    function text(str, x, y, color, align, size, weight) {
      font(size, weight);
      ctx.fillStyle = color || C.text;
      ctx.textAlign = align || 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(str, x, y);
    }
    // 带深色描边的文字：压在光线上也看得清
    function htext(str, x, y, color, align, size) {
      font(size);
      ctx.textAlign = align || 'center'; ctx.textBaseline = 'middle';
      if (ctx.textAlign === 'center') { var hw = ctx.measureText(str).width / 2 + 4; x = Math.max(hw, Math.min(W - hw, x)); }
      ctx.lineWidth = 4; ctx.lineJoin = 'round'; ctx.strokeStyle = 'rgba(5,7,13,0.85)';
      ctx.strokeText(str, x, y);
      ctx.fillStyle = color; ctx.fillText(str, x, y);
    }
    function roundRect(x, y, w, h, r) {
      ctx.beginPath();
      ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r);
      ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
    }
    function tag(str, x, y, color) {
      font(12);
      var w = ctx.measureText(str).width + 14;
      x = Math.max(w / 2 + 4, Math.min(W - w / 2 - 4, x));
      ctx.fillStyle = 'rgba(11,15,23,0.88)';
      ctx.strokeStyle = color; ctx.lineWidth = 1;
      roundRect(x - w / 2, y - 10, w, 20, 10);
      ctx.fill(); ctx.stroke();
      text(str, x, y, color);
    }
    function dot(x, y, r, color) { ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fillStyle = color; ctx.fill(); }

    function drawGrid(x0, y0) {
      ctx.strokeStyle = C.grid; ctx.lineWidth = 1;
      ctx.beginPath();
      var step = 32;
      for (var x = x0 % step; x < W; x += step) { ctx.moveTo(x, 0); ctx.lineTo(x, H); }
      for (var y = y0 % step; y < H; y += step) { ctx.moveTo(0, y); ctx.lineTo(W, y); }
      ctx.stroke();
    }

    // 平面镜：镜面实线 + 背面短斜线（像素坐标，背面在 (nx, ny) 一侧）
    function mirrorPx(x1, y1, x2, y2, nx, ny, color) {
      var L = Math.hypot(x2 - x1, y2 - y1), ux = (x2 - x1) / L, uy = (y2 - y1) / L;
      ctx.strokeStyle = C.hatch; ctx.lineWidth = 1;
      ctx.beginPath();
      for (var d = 4; d < L; d += 7) {
        var px = x1 + ux * d, py = y1 + uy * d;
        ctx.moveTo(px, py); ctx.lineTo(px + nx * 7 - ux * 5, py + ny * 7 - uy * 5);
      }
      ctx.stroke();
      seg(x1, y1, x2, y2, color || C.mirror, 3);
    }

    // 眼睛图标：朝向 (tx, ty)
    function drawEye(x, y, tx, ty, label) {
      var a = Math.atan2(ty - y, tx - x);
      ctx.save();
      ctx.translate(x, y); ctx.rotate(a);
      ctx.beginPath();
      ctx.moveTo(-13, 0); ctx.quadraticCurveTo(0, -11, 13, 0); ctx.quadraticCurveTo(0, 11, -13, 0); ctx.closePath();
      ctx.fillStyle = '#eef2f7'; ctx.fill();
      ctx.strokeStyle = '#8d99ab'; ctx.lineWidth = 1.2; ctx.stroke();
      dot(4, 0, 5, '#4f86c6'); dot(5, 0, 2.4, '#0b0f17');
      ctx.restore();
      if (label !== false) {
        font(12);
        var w = ctx.measureText('眼睛（可拖动）').width / 2 + 4;
        text('眼睛（可拖动）', Math.max(w, Math.min(W - w, x)), y + 22, C.muted, 'center', 12);
      }
    }

    // ================= 反射定律 =================
    function angleArc(cx, cy, r, aFrom, aTo, color) {
      var d = aTo - aFrom;
      while (d > Math.PI) d -= 2 * Math.PI;
      while (d <= -Math.PI) d += 2 * Math.PI;
      ctx.beginPath();
      ctx.arc(cx, cy, r, aFrom, aFrom + d, d < 0);
      ctx.strokeStyle = color; ctx.lineWidth = 1.4; ctx.stroke();
      return aFrom + d / 2;
    }

    function laserAt(x, y, ang) {
      ctx.save();
      ctx.translate(x, y); ctx.rotate(ang);
      roundRect(6, -7, 46, 14, 4);
      ctx.fillStyle = '#2b3446'; ctx.fill();
      ctx.strokeStyle = '#8d99ab'; ctx.lineWidth = 1; ctx.stroke();
      ctx.fillStyle = '#ff5d5d'; ctx.fillRect(30, -3, 6, 6);
      ctx.restore();
    }

    function drawReflect(st, sol) {
      var O = LO, R = LO.R;
      drawGrid(O.x, O.y);
      // 镜面以下：镜子背面
      ctx.fillStyle = 'rgba(214,222,234,0.05)'; ctx.fillRect(0, O.y, W, H - O.y);

      if (st.surface === 'diffuse') { drawDiffuse(st, sol); return; }

      // 量角盘（上半圆）
      if (st.show.ring) {
        ctx.beginPath(); ctx.arc(O.x, O.y, R, Math.PI, 0);
        ctx.strokeStyle = 'rgba(230,235,242,0.22)'; ctx.lineWidth = 1; ctx.stroke();
        for (var d = -90; d <= 90; d += 5) {
          var a = d * RAD, long = d % 30 === 0 ? 12 : d % 10 === 0 ? 7 : 4;
          var c = Math.cos(a), sn = Math.sin(a);
          seg(O.x + sn * R, O.y - c * R, O.x + sn * (R - long), O.y - c * (R - long), 'rgba(230,235,242,0.35)', 1);
          if (d % 30 === 0 && Math.abs(d) < 90) text(Math.abs(d) + '°', O.x + sn * (R - 24), O.y - c * (R - 24), 'rgba(141,153,171,0.8)', 'center', 10);
        }
      }
      mirrorPx(O.x - R * 1.25, O.y, O.x + R * 1.25, O.y, 0, 1);
      text('平面镜', Math.min(O.x + R * 1.25, W - 8), O.y + 22, C.muted, 'right', 12);
      // 法线
      seg(O.x, O.y - R * 1.12, O.x, O.y, C.normal, 1.2, [6, 5]);
      text('法线 ON', O.x + 6, O.y - R * 1.12 + 2, C.muted, 'left', 12);

      var lr = st.lr, si = Math.sin(st.i * RAD), ci = Math.cos(st.i * RAD);
      var src = { x: O.x + R * lr * si, y: O.y - R * ci }, out = { x: O.x - R * lr * si, y: O.y - R * ci };

      // 光路可逆：原来的光路淡淡地留着
      if (st.ghost) {
        var g = st.ghost, gs = Math.sin(g.i * RAD), gc = Math.cos(g.i * RAD);
        ctx.globalAlpha = 0.35;
        seg(O.x + R * g.lr * gs, O.y - R * gc, O.x, O.y, C.ray, 1.5, [3, 4]);
        seg(O.x, O.y, O.x - R * g.lr * gs, O.y - R * gc, C.ray, 1.5, [3, 4]);
        ctx.globalAlpha = 1;
        htext('原来的光路', O.x - R * g.lr * gs * 0.75, O.y - R * gc * 0.75 - 14, C.muted, 'center', 11);
      }

      seg(src.x, src.y, O.x, O.y, C.ray, 2.5);
      arrowMid(src.x, src.y, O.x, O.y, C.ray);
      seg(O.x, O.y, out.x, out.y, C.ray, 2.5);
      arrowMid(O.x, O.y, out.x, out.y, C.ray);

      // 光的传播：光点沿入射光、反射光前进
      if (st.show.pulse) {
        var T = 0.3, vv = R * 0.6, t = st.t, k0 = Math.floor(t / T);
        for (var j = 0; j < 30; j++) {
          var dd = (t - (k0 - j) * T) * vv;
          if (dd < R) dot(src.x + (O.x - src.x) * dd / R, src.y + (O.y - src.y) * dd / R, 2.6, '#fff3c4');
          else if (dd < 2 * R) dot(O.x + (out.x - O.x) * (dd - R) / R, O.y + (out.y - O.y) * (dd - R) / R, 2.6, '#fff3c4');
          else break;
        }
      }

      if (st.show.angles && st.i > 0.4) {
        // 角度文字放在光线外侧（光线与镜面之间），不压住光线
        var aN = -Math.PI / 2, aIn = Math.atan2(src.y - O.y, src.x - O.x), aOut = Math.atan2(out.y - O.y, out.x - O.x);
        angleArc(O.x, O.y, R * 0.28, aN, aIn, C.ray);
        angleArc(O.x, O.y, R * 0.34, aN, aOut, C.refl);
        var off = Math.min(16, (90 - st.i) * 0.6) * RAD, rl = R * 0.36;
        var a1 = aIn + lr * off, a2 = aOut - lr * off;
        htext('入射角 i = ' + st.i.toFixed(1) + '°', O.x + Math.cos(a1) * rl, Math.min(O.y - 12, O.y + Math.sin(a1) * rl), C.ray, lr < 0 ? 'right' : 'left', 12);
        htext('反射角 r = ' + st.i.toFixed(1) + '°', O.x + Math.cos(a2) * rl, Math.min(O.y - 12, O.y + Math.sin(a2) * rl), C.refl, lr < 0 ? 'left' : 'right', 12);
      }
      if (st.i <= 0.4) tag('垂直入射：反射光沿原路返回', O.x, O.y - R * 0.55, C.refl);

      // 光线名称
      htext('入射光线 AO', src.x + (O.x - src.x) * 0.35 + lr * 14, src.y + (O.y - src.y) * 0.35 - 12, C.ray, lr < 0 ? 'right' : 'left', 12);
      if (st.i > 0.4) htext('反射光线 OB', out.x + (O.x - out.x) * 0.35 - lr * 14, out.y + (O.y - out.y) * 0.35 - 12, C.ray, lr < 0 ? 'left' : 'right', 12);

      laserAt(src.x, src.y, Math.atan2(src.y - O.y, src.x - O.x));
      dot(src.x, src.y, 3, C.ray);
      dot(O.x, O.y, 3, '#e6ebf2');
      text('O', O.x - 10, O.y + 12, C.text, 'center', 12);
    }

    // 漫反射：一束平行光照到凹凸不平的表面，每条光线都遵循反射定律，但反射光射向四面八方
    function drawDiffuse(st, sol) {
      var O = LO, R = LO.R, S = R * 1.6, n = Mr.FACETS.length, fw = S / n;
      // 粗糙表面：每段小镜面按各自的倾角画，左右再延伸几段
      for (var k = -4; k < n + 4; k++) {
        var tilt = Mr.FACETS[((k % n) + n) % n] * RAD;
        var cx = O.x + (k + 0.5) * fw - S / 2, hx = Math.cos(tilt) * fw * 0.55, hy = Math.sin(tilt) * fw * 0.55;
        // 小镜面的切线方向：法线 (sin t, cos t) 旋转 90°
        mirrorPx(cx - hx, O.y - hy, cx + hx, O.y + hy, 0, 1, '#b8c2d2');
      }
      text('粗糙表面（放大）', O.x + S / 2 + fw * 4, O.y + 24, C.muted, 'right', 12);
      var L = R * 1.15;
      sol.forEach(function (r) {
        // 落点在所在小镜面上（小镜面过自己的中点、按倾角倾斜）
        var f = Math.min(n - 1, Math.floor((r.x + 0.5) * n)), cx = O.x + (f + 0.5) * fw - S / 2;
        var hx = O.x + r.x * S, hy = O.y + (hx - cx) * Math.tan(r.tilt * RAD);
        var x0 = hx - r.dIn.x * L, y0 = hy + r.dIn.y * L;
        seg(x0, y0, hx, hy, C.ray, 1.8);
        arrowMid(x0, y0, hx, hy, C.ray);
        var x1 = hx + r.dOut.x * R * 0.85, y1 = hy - r.dOut.y * R * 0.85;
        seg(hx, hy, x1, y1, C.ray, 1.8);
        arrowMid(hx, hy, x1, y1, C.ray);
        if (st.show.angles) seg(hx, hy, hx + r.n.x * 40, hy - r.n.y * 40, C.normal, 1, [3, 3]);
      });
      tag('每条光线都遵循反射定律，但各处法线方向不同，反射光射向四面八方', O.x, Math.max(padT + 14, O.y - R * 1.3), C.refl);
    }

    // ================= 平面镜成像（俯视） =================
    function candle(x, y, lit, alpha, dashed) {
      var r = Math.max(7, 1.1 * s);
      ctx.save();
      ctx.globalAlpha = alpha;
      ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2);
      ctx.fillStyle = dashed ? C.imageFill : C.wax; ctx.fill();
      if (dashed) { ctx.setLineDash([4, 3]); ctx.strokeStyle = C.image; ctx.lineWidth = 1.4; ctx.stroke(); ctx.setLineDash([]); }
      else { ctx.strokeStyle = '#b9ab8c'; ctx.lineWidth = 1; ctx.stroke(); }
      if (lit) {
        var g = ctx.createRadialGradient(x, y, 0, x, y, r * 2.2);
        g.addColorStop(0, dashed ? 'rgba(255,190,120,0.55)' : 'rgba(255,200,110,0.9)');
        g.addColorStop(1, 'rgba(255,160,60,0)');
        ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r * 2.2, 0, Math.PI * 2); ctx.fill();
        dot(x, y, r * 0.42, dashed ? 'rgba(255,170,90,0.7)' : C.flame);
        dot(x, y, r * 0.18, dashed ? 'rgba(255,240,200,0.7)' : '#fff3c4');
      } else dot(x, y, r * 0.15, '#3a3226');
      ctx.restore();
    }
    function strokes(list, color, width, dash) {
      ctx.lineCap = 'round';
      list.forEach(function (sg) { wseg(sg[0], sg[1], color, width, dash); });
      ctx.lineCap = 'butt';
    }

    function drawImage(st, sol) {
      var g = G.image, m = g.mirror, b = bounds('image'), E = st.eye;
      drawGrid(X(0), Y(0));
      text('俯视图：桌面上竖直放置' + (st.plate === 'mirror' ? '平面镜' : '玻璃板'), X(b.x0) + 2, Y(b.y1) + 4, C.muted, 'left', 12);

      // 刻度尺（沿桌面，垂直于镜面）
      var ry = Y(b.y0 + 1.2);
      ctx.fillStyle = 'rgba(230,200,120,0.1)'; ctx.fillRect(X(b.x0 + 1), ry - 4, (b.x1 - b.x0 - 2) * s, 18);
      for (var cm = Math.ceil(b.x0 + 1); cm <= b.x1 - 1; cm++) {
        var lg = cm % 10 === 0 ? 10 : cm % 5 === 0 ? 7 : 4;
        seg(X(cm), ry - 4, X(cm), ry - 4 + lg, 'rgba(230,200,120,0.55)', 1);
        if (cm % 10 === 0) text(Math.abs(cm) + '', X(cm), ry + 10, 'rgba(230,200,120,0.8)', 'center', 10);
      }

      // 物与像的连线、距离
      var A = st.obj, I = sol.img;
      wseg(A, I, 'rgba(230,235,242,0.4)', 1, [2, 4]);
      seg(X(A.x), ry - 8, X(A.x), Y(A.y), 'rgba(255,201,74,0.25)', 1, [2, 3]);
      seg(X(I.x), ry - 8, X(I.x), Y(I.y), 'rgba(201,167,255,0.3)', 1, [2, 3]);
      var dy = ry - 18;
      seg(X(A.x), dy, X(0), dy, C.obj, 1.5); seg(X(0), dy, X(I.x), dy, C.image, 1.5);
      [A.x, 0, I.x].forEach(function (x) { seg(X(x), dy - 4, X(x), dy + 4, C.muted, 1.2); });
      if (sol.u * s > 40) htext('物距 ' + sol.u.toFixed(1) + ' cm', X(A.x / 2), dy - 12, C.obj, 'center', 12);
      if (sol.v * s > 40) htext('像距 ' + sol.v.toFixed(1) + ' cm', X(I.x / 2), dy - 12, C.image, 'center', 12);
      // 直角符号：连线与镜面垂直
      var sq = 7;
      ctx.strokeStyle = C.muted; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(X(0) - sq, Y(A.y)); ctx.lineTo(X(0) - sq, Y(A.y) - sq); ctx.lineTo(X(0), Y(A.y) - sq); ctx.stroke();

      // 镜后的东西：平面镜不透明，蜡烛 B 和像都在镜后
      var behindAlpha = st.plate === 'mirror' ? 0.35 : 1;

      // 像
      if (st.shape === 'F') {
        strokes(sol.imgStrokes, C.imageFill, Math.max(5, 0.55 * s));
        strokes(sol.imgStrokes, C.image, 1.4, [4, 3]);
        if (sol.imgStrokes2) { ctx.globalAlpha = 0.5; strokes(sol.imgStrokes2, C.image, 1.4, [4, 3]); ctx.globalAlpha = 1; }
      } else {
        if (st.shape !== 'F' && st.showB) candle(X(st.candleB.x), Y(st.candleB.y), false, behindAlpha, false);
        candle(X(I.x), Y(I.y), true, 1, true);
        if (sol.img2) candle(X(sol.img2.x), Y(sol.img2.y), true, 0.55, true);
      }

      // 镜面 / 玻璃板
      var mt = Y(m.y1), mb = Y(m.y0);
      if (st.plate === 'mirror') mirrorPx(X(0), mt, X(0), mb, 1, 0);
      else {
        var th = (st.plate === 'thick' ? g.thick : 0.3) * s;
        ctx.fillStyle = C.glass; ctx.fillRect(X(0), mt, Math.max(3, th), mb - mt);
        seg(X(0), mt, X(0), mb, C.glassEdge, 1.5);
        if (st.plate === 'thick') seg(X(g.thick), mt, X(g.thick), mb, C.glassEdge, 1);
      }
      text(st.plate === 'mirror' ? '平面镜' : st.plate === 'thick' ? '厚玻璃板' : '薄玻璃板', X(0), mt - 12, C.glassEdge, 'center', 12);

      // 光屏
      if (st.screen) {
        seg(X(I.x), Y(I.y + 4), X(I.x), Y(I.y - 4), '#f4f6fa', 4);
        tag('光屏上承接不到像 → 虚像', X(I.x), Y(I.y - 4) + 16, C.image);
      }

      // 光路：物点 → 镜面 → 眼睛，反向延长线交于像点
      if (st.show.rays) {
        sol.rays.forEach(function (r) {
          if (!r.ok) return;
          wseg({ x: 0, y: r.M.y }, { x: -2.2, y: r.M.y }, C.normal, 1, [3, 3]);
          wray(r.P, r.M, C.ray, 1.6);
          wray(r.M, r.E, C.ray, 1.6);
          wseg(r.M, r.I, C.rayBack, 1.2, [4, 4]);
        });
      }

      // 物体
      if (st.shape === 'F') {
        strokes(sol.strokes, C.obj, Math.max(5, 0.55 * s));
        htext('物体「F」（可拖动）', X(A.x + 1.5), Y(A.y - 3) + 16, C.obj, 'center', 12);
        htext('像：左右相反的 F', X(I.x - 1.5), Y(I.y - 3) + 16, C.image, 'center', 12);
      } else {
        candle(X(A.x), Y(A.y), true, 1, false);
        htext('蜡烛 A（点燃，可拖动）', X(A.x), Y(A.y) - Math.max(7, 1.1 * s) - 14, C.obj, 'center', 12);
        var lab = sol.matched && st.showB ? 'B 与 A 的像完全重合' : 'A 的像 A′';
        htext(lab, X(I.x), Y(I.y) - Math.max(7, 1.1 * s) - 14, sol.matched && st.showB ? C.refl : C.image, 'center', 12);
        if (st.showB && !sol.matched) htext('蜡烛 B（未点燃，可拖动）', X(st.candleB.x), Y(st.candleB.y) + Math.max(7, 1.1 * s) + 14, '#d8ccb0', 'center', 12);
        if (sol.img2) htext('后表面的像', X(sol.img2.x) + 10, Y(sol.img2.y) + Math.max(7, 1.1 * s) + 14, C.image, 'left', 11);
      }

      var look = sol.rays[0].M || { x: 0, y: A.y };
      drawEye(X(E.x), Y(E.y), X(look.x), Y(look.y));
      if (!sol.seenAny) tag(E.x >= 0 ? '眼睛在镜子后面，看不到像' : '光射不到镜面上，从这里看不到像', X(E.x), Y(E.y) - 24, C.bad);
    }

    // ================= 潜望镜（侧视） =================
    function arrowObj(base, tip, color, dashed, fill) {
      var bx = X(base.x), by = Y(base.y), tx = X(tip.x), ty = Y(tip.y);
      var a = Math.atan2(ty - by, tx - bx), hw = 6, hl = 11;
      seg(bx, by, tx - Math.cos(a) * hl * 0.6, ty - Math.sin(a) * hl * 0.6, color, 3, dashed ? [5, 4] : null);
      ctx.beginPath();
      ctx.moveTo(tx, ty);
      ctx.lineTo(tx - Math.cos(a) * hl + Math.sin(a) * hw, ty - Math.sin(a) * hl - Math.cos(a) * hw);
      ctx.lineTo(tx - Math.cos(a) * hl - Math.sin(a) * hw, ty - Math.sin(a) * hl + Math.cos(a) * hw);
      ctx.closePath();
      ctx.fillStyle = fill || color; ctx.fill();
      if (dashed) { ctx.setLineDash([3, 3]); ctx.strokeStyle = color; ctx.lineWidth = 1.2; ctx.stroke(); ctx.setLineDash([]); }
    }

    function drawPeri(st, sol) {
      var p = G.peri, b = bounds('peri');
      drawGrid(X(0), Y(0));
      // 地面（眼睛那一侧低处）
      seg(X(b.x0), Y(-1.5), X(b.x1), Y(-1.5), C.axis, 1.5);
      // 墙：挡住眼睛直接看物体
      ctx.fillStyle = '#2a2620'; ctx.strokeStyle = '#4a4236'; ctx.lineWidth = 1;
      var wx0 = -9, wx1 = -3;
      ctx.fillRect(X(wx0), Y(26), (wx1 - wx0) * s, 27.5 * s); ctx.strokeRect(X(wx0), Y(26), (wx1 - wx0) * s, 27.5 * s);
      text('墙', X((wx0 + wx1) / 2), Y(13), C.muted, 'center', 12);

      // 镜筒
      ctx.fillStyle = C.tubeFill; ctx.fillRect(X(0), Y(p.h), p.w * s, p.h * s);
      ctx.lineWidth = 3; ctx.strokeStyle = C.tube; ctx.beginPath();
      ctx.moveTo(X(0), Y(p.openTop[0])); ctx.lineTo(X(0), Y(0)); ctx.lineTo(X(p.w), Y(0)); ctx.lineTo(X(p.w), Y(p.openBot[1]));
      ctx.moveTo(X(p.w), Y(p.h)); ctx.lineTo(X(p.w), Y(p.openBot[1]));
      ctx.moveTo(X(0), Y(p.h)); ctx.lineTo(X(p.w), Y(p.h));
      ctx.stroke();
      // 镜面（背面朝外）
      // 镜面（上镜背面朝右上，下镜背面朝左下）
      sol.mirrors.forEach(function (m, k) {
        var sg = k === 0 ? 1 : -1;
        mirrorPx(X(m[0].x), Y(m[0].y), X(m[1].x), Y(m[1].y), sg * 0.71, -sg * 0.71);
      });
      text('平面镜 1', X(p.w) + 8, Y(sol.mirrors[0][1].y) - 4, C.muted, 'left', 12);
      text('平面镜 2', X(0) - 8, Y(sol.mirrors[1][0].y) + 6, C.muted, 'right', 12);

      var rt = sol.tip, rb = sol.base;
      // 中间像：物体经平面镜 1 所成的像
      if (st.show.mid) {
        arrowObj(rb.P1, rt.P1, 'rgba(201,167,255,0.6)', true, 'rgba(201,167,255,0.25)');
        htext('镜 1 所成的像', X((rb.P1.x + rt.P1.x) / 2) + 14, Y((rb.P1.y + rt.P1.y) / 2), 'rgba(201,167,255,0.8)', 'left', 11);
      }
      // 光路
      if (st.show.rays) {
        [rt, rb].forEach(function (r) {
          if (!r.ok) return;
          wray(r.P, r.M1, C.ray, 1.6);
          wray(r.M1, r.M2, C.ray, 1.6);
          wray(r.M2, st.pEye, C.ray, 1.6);
          wseg(r.M2, r.P2, C.rayBack, 1.1, [4, 4]);
          if (st.show.mid) wseg(r.M1, r.P1, 'rgba(201,167,255,0.4)', 1, [2, 4]);
        });
      }
      // 最终的像
      arrowObj(rb.P2, rt.P2, C.image, true, C.imageFill);
      var lab = '看到的像（' + (sol.upright ? '正立' : '倒立') + '、虚像）';
      htext(lab, X(rb.P2.x), Y(rb.P2.y) + 16, C.image, 'center', 12);
      // 物体
      arrowObj(st.pObj, rt.P, C.obj);
      htext('物体（可拖动）', X(st.pObj.x), Y(st.pObj.y) + 14, C.obj, 'center', 12);

      drawEye(X(st.pEye.x), Y(st.pEye.y), X(p.w), Y(st.pEye.y));
      if (!rt.ok || !rb.ok) tag(!rt.ok && !rb.ok ? '光进不了眼睛：调整物体或眼睛的位置' : '只能看到物体的一部分', X(st.pEye.x) - 40, Y(st.pEye.y) - 26, C.bad);
    }

    function draw(st, sol) {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, W, H);
      layout(st.scene);
      if (st.scene === 'reflect') drawReflect(st, sol);
      else if (st.scene === 'image') drawImage(st, sol);
      else drawPeri(st, sol);
    }

    // ---------- 交互：命中测试与坐标换算 ----------
    function distSeg(px, py, ax, ay, bx, by) {
      var dx = bx - ax, dy = by - ay, t = ((px - ax) * dx + (py - ay) * dy) / (dx * dx + dy * dy || 1);
      t = Math.max(0, Math.min(1, t));
      return Math.hypot(px - ax - dx * t, py - ay - dy * t);
    }
    // 返回可拖动的对象：'laser' | 'obj' | 'eye' | 'B' | null；strict = 只认图标本身（用于鼠标指针样式）
    function hit(px, py, st, strict) {
      layout(st.scene);
      if (st.scene === 'reflect') {
        if (!strict) return py < LO.y ? 'laser' : null;
        var R = LO.R + 28, lx = LO.x + R * st.lr * Math.sin(st.i * RAD), ly = LO.y - R * Math.cos(st.i * RAD);
        return Math.hypot(px - lx, py - ly) < 30 ? 'laser' : null;
      }
      var E = st.scene === 'image' ? st.eye : st.pEye;
      if (Math.hypot(px - X(E.x), py - Y(E.y)) < 24) return 'eye';
      var r = Math.max(18, 1.6 * s);
      if (st.scene === 'image') {
        var A = st.obj;
        if (st.shape === 'F') { if (px > X(A.x) - 14 && px < X(A.x + 3) + 14 && Math.abs(py - Y(A.y)) < 3 * s + 14) return 'obj'; }
        else if (Math.hypot(px - X(A.x), py - Y(A.y)) < r) return 'obj';
        if (st.shape !== 'F' && st.showB && Math.hypot(px - X(st.candleB.x), py - Y(st.candleB.y)) < r) return 'B';
        return null;
      }
      var o = st.pObj;
      return distSeg(px, py, X(o.x), Y(o.y), X(o.x), Y(o.y + st.pH)) < 16 ? 'obj' : null;
    }
    // 反射定律场景：指针位置 → { lr, i }
    function lawAngle(px, py) {
      var dx = px - LO.x, dy = Math.min(-1e-6, py - LO.y);
      return { lr: dx < 0 ? -1 : 1, i: Math.min(89.5, Math.atan2(Math.abs(dx), -dy) / RAD) };
    }

    return { resize: resize, draw: draw, hit: hit, toWorld: toWorld, lawAngle: lawAngle, bounds: bounds };
  }

  window.MirrorDraw = MirrorDraw;
})();
