(function () {
  var P = window.Photo, PD = window.PhotoDraw, MT = P.METALS;
  var $ = function (id) { return document.getElementById(id); };
  var qa = function (sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); };
  var NAME = '光电效应';

  var state = {
    scene: 'tube', paused: false,
    // 光电管与 Ek-ν：ν 单位 10¹⁴ Hz，I 为光强 0～1，U 为 UAK（V）
    metal: 'na', nu: 7.5, I: 0.6, U: 0, on: true, traces: [], yAxis: 'ek', all: true,
    // 锌板与验电器：q 为相对电荷 −1～1
    zMetal: 'zn', src: 'uv', glass: false, zI: 0.8, zOn: true, q: 0
  };
  var HINTS = {
    zinc: '光子把电子打出金属板，板带正电，验电器张开',
    tube: '频率决定遏止电压，光强决定饱和电流',
    ek: 'Ekmax = hν − W₀：各金属的直线互相平行，斜率都是 h'
  };
  var UV_NU = P.nuOf(254);        // 紫外线灯（汞灯 254 nm）
  var KAPPA = 1.4;                // 光电管动画：电子坐标的加速度 = KAPPA·U，初速度² = 2·KAPPA·ε（ε 为 eV）
  var RATE = 14;                  // 光强为 1 时每秒入射的光子数（动画）
  var FLY = 0.42;                 // 光子从光源飞到阴极的屏幕时间（s）

  var stage = $('stage'), panel = $('panel'), cv = $('view');
  var view = PD.View(cv);
  function setSeg(attr, val) { qa('[data-' + attr + ']').forEach(function (b) { b.classList.toggle('on', b.dataset[attr] === String(val)); }); }
  function W0() { return MT[state.metal].W; }
  function Uc() { return P.stopU(W0(), state.nu); }
  function emitsNow() { return P.emits(W0(), state.nu); }
  function curNow() { return state.on ? P.current({ W: W0(), nu: state.nu, I: state.I, U: state.U }) : 0; }

  // ---------- 场景 ----------
  qa('[data-scene]').forEach(function (b) {
    b.addEventListener('click', function () { setScene(b.dataset.scene); Analytics.track(NAME, '场景', b.textContent); });
  });
  function setScene(sc) { state.scene = sc; clearParts(); syncUI(); }

  // ---------- 控件 ----------
  qa('[data-metal]').forEach(function (b) {
    b.addEventListener('click', function () {
      if (state.scene === 'zinc') { state.zMetal = b.dataset.metal; zn.electrons = []; }
      else { state.metal = b.dataset.metal; tube.electrons = []; }
      syncUI(); Analytics.track(NAME, '金属', b.textContent);
    });
  });
  qa('[data-light]').forEach(function (b) {
    b.addEventListener('click', function () { state.nu = P.nuOf(P.LIGHTS[b.dataset.light].lam); syncUI(); Analytics.track(NAME, '色光', b.textContent); });
  });
  qa('[data-src]').forEach(function (b) {
    b.addEventListener('click', function () { state.src = b.dataset.src; zn.photons = []; syncUI(); Analytics.track(NAME, '光源', b.textContent); });
  });
  qa('[data-y]').forEach(function (b) {
    b.addEventListener('click', function () { state.yAxis = b.dataset.y; syncUI(); Analytics.track(NAME, '纵轴', b.textContent); });
  });
  function bindSlider(id, get, set, after) {
    var el = $(id);
    el.addEventListener('input', function () { set(parseFloat(el.value)); if (after) after(); });
    el.addEventListener('change', function () { Analytics.track(NAME, '滑块', id); });
    return { el: el, get: get };
  }
  var sliders = [
    bindSlider('nu', function () { return state.nu; }, function (x) { state.nu = x; }, syncUI),
    bindSlider('nu2', function () { return state.nu; }, function (x) { state.nu = x; }, syncUI),
    bindSlider('I', function () { return state.I * 100; }, function (x) { state.I = x / 100; }),
    bindSlider('U', function () { return state.U; }, function (x) { state.U = x; }),
    bindSlider('zI', function () { return state.zI * 100; }, function (x) { state.zI = x / 100; })
  ];
  [['on', 'on'], ['zOn', 'zOn'], ['glass', 'glass'], ['all', 'all']].forEach(function (p) {
    $(p[0]).addEventListener('change', function () {
      state[p[1]] = $(p[0]).checked;
      if (p[0] === 'on' && !state.on) tube.photons = [];
      if (p[0] === 'zOn' && !state.zOn) zn.photons = [];
      Analytics.track(NAME, '开关', p[0] + (state[p[1]] ? ' 开' : ' 关'));
    });
  });
  $('u0').addEventListener('click', function () { state.U = 0; Analytics.track(NAME, '一键', 'U=0'); });
  $('uStop').addEventListener('click', function () { if (emitsNow()) state.U = -Math.min(5, Math.round(Uc() * 100) / 100); Analytics.track(NAME, '一键', 'U=-Uc'); });
  $('uSat').addEventListener('click', function () { state.U = 5; Analytics.track(NAME, '一键', 'U=5'); });
  $('keep').addEventListener('click', function () { keepTrace(); Analytics.track(NAME, '曲线', '保留'); });
  $('clearTr').addEventListener('click', function () { state.traces = []; Analytics.track(NAME, '曲线', '清除'); });
  qa('[data-cmp]').forEach(function (b) { b.addEventListener('click', function () { compare(b.dataset.cmp); Analytics.track(NAME, '对比', b.textContent); }); });
  $('neg').addEventListener('click', function () { state.q = -0.8; zn.electrons = []; Analytics.track(NAME, '锌板', '带负电'); });
  $('ground').addEventListener('click', function () { state.q = 0; zn.electrons = []; Analytics.track(NAME, '锌板', '接地'); });
  qa('.pauseBtn').forEach(function (b) { b.addEventListener('click', function () { state.paused = !state.paused; syncUI(); }); });

  // ---------- I-U 曲线的保留与对比 ----------
  function lightLabel(nu) { return P.colorName(nu) + ' ' + P.lamOf(nu).toFixed(0) + ' nm'; }
  function trace(metal, nu, I, lab) { return { metal: metal, W: MT[metal].W, nu: nu, I: I, label: lab }; }
  function keepTrace() {
    var t = trace(state.metal, state.nu, state.on ? state.I : 0, MT[state.metal].name + '，' + lightLabel(state.nu) + '，' + Math.round(state.I * 100) + '%');
    state.traces.push(t);
    if (state.traces.length > 4) state.traces.shift();
  }
  function compare(kind) {
    var m = state.metal, nu = state.nu;
    if (!emitsNow()) { nu = state.nu = +(P.nuC(W0()) + 1.6).toFixed(2); }
    if (kind === 'int') state.traces = [trace(m, nu, 1, P.colorName(nu) + '（强）'), trace(m, nu, 0.5, P.colorName(nu) + '（弱）')];
    else if (kind === 'freq') {
      var nu2 = nu + 2.5 <= P.NU_RANGE[1] ? nu + 2.5 : nu - 2.5;
      if (!P.emits(W0(), nu2)) nu2 = nu + 1;
      state.traces = [trace(m, nu, state.I, lightLabel(nu)), trace(m, nu2, state.I, lightLabel(nu2))];
    } else {
      state.traces = P.ORDER.filter(function (k) { return P.emits(MT[k].W, nu); }).slice(0, 4).map(function (k) { return trace(k, nu, state.I, MT[k].name); });
    }
    syncUI();
  }

  // ---------- 光电管动画 ----------
  // 光子沿光束飞向阴极；到达时若 hν > W₀ 立即打出一个光电子
  // 每个电子抽随机数 r：needU = P.reachU(r, Uc)。needU < 0 的是“正对阳极”的电子，沿电场方向的初动能 ε = −needU（eV），按 x'' = KAPPA·U 运动；
  // needU ≥ 0 的是斜着飞出的电子，只有 U > needU 时被拉到阳极，否则打到管壁
  var tube = { photons: [], electrons: [], next: 0 };
  var zn = { photons: [], electrons: [], next: 0 };
  function clearParts() { tube.photons = []; tube.electrons = []; zn.photons = []; zn.electrons = []; }
  function spawnElectron() {
    var r = Math.random(), need = P.reachU(r, Uc()), y = (Math.random() * 2 - 1) * 0.8;
    if (need < 0) tube.electrons.push({ x: 0.01, y: y, vx: Math.sqrt(2 * KAPPA * -need), vy: (Math.random() - 0.5) * 0.25, ob: false, a: 1 });
    else tube.electrons.push({ x: 0.01, y: y, vx: Math.sqrt(2 * KAPPA * 0.02), vy: (y >= 0 ? 1 : -1) * (0.9 + Math.random() * 0.6), ob: true, need: need, a: 1 });
  }
  function stepTube(dt) {
    if (state.on && state.I > 0) {
      tube.next -= dt;
      if (tube.next <= 0) {
        tube.next = 1 / (RATE * state.I) * (0.6 + Math.random() * 0.8);
        tube.photons.push({ s: 0, y: (Math.random() * 2 - 1) * 0.85 });
      }
    }
    tube.photons.forEach(function (ph) {
      ph.s += dt / FLY;
      if (ph.s >= 1 && !ph.done) { ph.done = true; if (emitsNow()) spawnElectron(); }
    });
    tube.photons = tube.photons.filter(function (ph) { return !ph.done; });
    var ax = KAPPA * state.U;
    tube.electrons.forEach(function (e) {
      if (e.dead) { e.a -= dt * 3; return; }
      var n = 4, h = dt / n;
      for (var i = 0; i < n; i++) {
        if (e.ob) {
          var pulled = state.U > e.need;
          e.vx += ax * h;
          e.vy += (pulled ? -e.vy * 3 : 0) * h;
        } else e.vx += ax * h;
        e.x += e.vx * h; e.y += e.vy * h;
      }
      if (e.x >= 1) { e.x = 1; e.dead = true; }
      else if (e.x <= 0 && e.vx < 0) { e.x = 0; e.dead = true; }
      else if (Math.abs(e.y) > 1.7) e.dead = true;
    });
    tube.electrons = tube.electrons.filter(function (e) { return e.a > 0; });
  }

  // ---------- 锌板动画 ----------
  // 设计坐标同 draw2d 的 drawZinc：灯在 x = 82，玻璃板 x = 150，金属板受光面 x = 236
  function zNu() { return state.src === 'uv' ? UV_NU : P.whiteMaxNu(); }
  function zReach() { return state.zOn && !(state.glass && state.src === 'uv'); }   // 有没有光照到金属板上
  function zEk() { return zReach() ? P.ekMax(MT[state.zMetal].W, zNu()) : 0; }
  function stepZinc(dt) {
    if (state.zOn && state.zI > 0) {
      zn.next -= dt;
      if (zn.next <= 0) {
        zn.next = 1 / (RATE * state.zI) * (0.6 + Math.random() * 0.8);
        var nu = state.src === 'uv' ? UV_NU : P.nuOf(380 + Math.random() * 370);
        zn.photons.push({ s: 0, y: 100 + Math.random() * 80, nu: nu, end: state.glass && state.src === 'uv' ? 150 : 236 });
      }
    }
    zn.photons.forEach(function (ph) {
      ph.s += dt / 0.55;
      if (ph.s >= 1 && !ph.done) {
        ph.done = true;
        var ek = ph.end === 236 ? P.ekMax(MT[state.zMetal].W, ph.nu) : 0;
        if (ek > 0) {
          var out = Math.random() < P.escapeFrac(state.q, zEk());
          var sp = 40 + 90 * Math.sqrt(Math.random() * ek / 2);
          var ang = Math.PI + (Math.random() - 0.5) * 1.6;
          zn.electrons.push({ x: 234, y: ph.y, vx: Math.cos(ang) * sp, vy: Math.sin(ang) * sp, back: !out, t: 0, a: 1 });
        }
      }
    });
    zn.photons = zn.photons.filter(function (ph) { return !ph.done; });
    zn.electrons.forEach(function (e) {
      e.t += dt;
      if (e.back) {
        // 被带正电的金属板吸回：朝板加速
        e.vx += 260 * dt; e.vy *= (1 - 1.5 * dt);
        if (e.x >= 234 && e.t > 0.05) e.a = 0;
      } else if (e.t > 1.6) e.a -= dt * 2;
      e.x += e.vx * dt; e.y += e.vy * dt;
    });
    zn.electrons = zn.electrons.filter(function (e) { return e.a > 0 && e.x > -40; });
    if (zReach()) state.q = Math.min(1, state.q + P.zincRate(state.q, zEk(), state.zI) * dt);
  }

  // ---------- 画布拖动：I-U 图上改电压，Ek-ν 图上改频率 ----------
  var dragging = false;
  function fromPointer(e) {
    var g = view.geo(), r = cv.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top;
    if (!g || !g.A) return false;
    var A = g.A;
    if (!dragging && (x < A.x - 20 || x > A.x + A.w + 20 || y < A.y - 20 || y > A.y + A.h + 30)) return false;
    var f = P.clamp((x - A.x) / A.w, 0, 1);
    if (g.scene === 'tube') state.U = Math.round((g.U0 + (g.U1 - g.U0) * f) * 100) / 100;
    else if (g.scene === 'ek') { state.nu = Math.round(P.clamp(g.N0 + (g.N1 - g.N0) * f, P.NU_RANGE[0], P.NU_RANGE[1]) * 100) / 100; syncUI(); }
    return true;
  }
  cv.addEventListener('pointerdown', function (e) {
    if (e.button !== 0) return;
    if (fromPointer(e)) { dragging = true; cv.setPointerCapture(e.pointerId); e.preventDefault(); }
  });
  cv.addEventListener('pointermove', function (e) {
    if (dragging) { fromPointer(e); return; }
    var g = view.geo(), r = cv.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top;
    cv.style.cursor = g && g.A && x > g.A.x - 20 && x < g.A.x + g.A.w + 20 && y > g.A.y - 20 && y < g.A.y + g.A.h + 30 ? 'ew-resize' : 'default';
  });
  function endDrag() { if (dragging) { dragging = false; Analytics.track(NAME, '拖动', state.scene); } }
  cv.addEventListener('pointerup', endDrag);
  cv.addEventListener('pointercancel', endDrag);

  // ---------- 面板 ----------
  $('panelToggle').addEventListener('click', function () { panel.classList.toggle('collapsed'); });
  if (window.matchMedia('(max-width: 760px)').matches) panel.classList.add('collapsed');
  window.addEventListener('keydown', function (e) {
    var tg = e.target.tagName;
    if (tg === 'INPUT' || tg === 'SELECT' || tg === 'BUTTON' || tg === 'TEXTAREA') return;
    if (e.code === 'Space') { e.preventDefault(); state.paused = !state.paused; syncUI(); }
  });

  function syncUI() {
    var sc = state.scene;
    setSeg('scene', sc);
    qa('[data-for]').forEach(function (el) { el.hidden = el.dataset.for.split(' ').indexOf(sc) < 0; });
    $('hint').textContent = HINTS[sc];
    setSeg('metal', sc === 'zinc' ? state.zMetal : state.metal);
    setSeg('src', state.src); setSeg('y', state.yAxis);
    var lam = P.lamOf(state.nu);
    qa('[data-light]').forEach(function (b) { b.classList.toggle('on', Math.abs(P.LIGHTS[b.dataset.light].lam - lam) < 1); });
    ['on', 'zOn', 'glass', 'all'].forEach(function (k) { $(k).checked = state[k]; });
    qa('.pauseBtn').forEach(function (b) { b.textContent = state.paused ? '▶ 继续' : '❚❚ 暂停'; });
  }

  // ---------- 读数 ----------
  var lastText = {};
  function setText(id, s) { if (lastText[id] !== s) { lastText[id] = s; $(id).textContent = s; } }
  function rows(list) {
    for (var k = 1; k <= 5; k++) {
      var r = list[k - 1] || ['', ''];
      setText('d' + k, r[0]); setText('r' + k, r[1]);
      $('d' + k).hidden = $('r' + k).hidden = !r[0];
    }
  }
  function nuText(nu) { return nu.toFixed(2) + '×10¹⁴ Hz'; }
  function lightRow() { return [P.colorName(state.nu), 'λ = ' + P.lamOf(state.nu).toFixed(0) + ' nm，ν = ' + nuText(state.nu)]; }

  function readTube() {
    var m = MT[state.metal], hv = P.photonEV(state.nu), ek = hv - m.W, uc = Uc(), cur = curNow(), is = P.satCurrent({ W: m.W, nu: state.nu, I: state.I });
    var col = P.collect(state.U, uc), name, kind, tip;
    setText('rName', 'I = ' + (cur < 9.95 ? cur.toFixed(2) : cur.toFixed(1)) + ' μA');
    if (!state.on) { kind = '关灯'; tip = '关灯后光电流立即消失；再开灯，光电流几乎同时出现（不超过 10⁻⁹ s），即使光很弱也一样——光电效应具有瞬时性。'; }
    else if (ek <= 0) { kind = '不发生光电效应'; tip = 'hν = ' + hv.toFixed(2) + ' eV < W₀ = ' + m.W.toFixed(2) + ' eV：入射光频率低于' + m.name + '的截止频率 νc = ' + nuText(P.nuC(m.W)) + '，光再强、照得再久也没有光电子。'; }
    else if (state.I <= 0) { kind = '光强为零'; tip = '没有光子入射，就没有光电子。'; }
    else if (col <= 0) { kind = state.U < -uc - 0.005 ? '反向电压 > Uc' : '恰好遏止'; tip = '反向电压达到遏止电压 Uc：连初动能最大的光电子也到不了阳极，eUc = Ekmax，光电流为零。'; }
    else if (state.U < 0) { kind = '反向电压'; tip = '反向电压使光电子减速，只有初动能大于 e|U| 的电子能到达阳极。反向电压越大，电流越小。'; }
    else if (col > 0.995) { kind = '饱和电流'; tip = '阴极 K 发出的光电子全部到达阳极 A，电流不再随电压增大。饱和电流只由光强（单位时间入射的光子数）决定。'; }
    else { kind = state.U > 0 ? '正向电压' : 'UAK = 0'; tip = state.U > 0 ? '正向电压增大，到达阳极的光电子增多，电流增大，最后达到饱和。' : 'U = 0 时也有光电流：光电子有初动能，一部分能自己飞到阳极。'; }
    setText('rKind', kind); setText('rTip', tip);
    rows([
      lightRow(),
      ['光子能量', 'ε = hν = ' + hv.toFixed(2) + ' eV'],
      ['逸出功', m.name + ' W₀ = ' + m.W.toFixed(2) + ' eV，νc = ' + nuText(P.nuC(m.W))],
      ['最大初动能', ek > 0 ? 'Ekmax = hν − W₀ = ' + ek.toFixed(2) + ' eV' : '—（hν < W₀）'],
      ['遏止 / 饱和', ek > 0 ? 'Uc = ' + uc.toFixed(2) + ' V，Is = ' + is.toFixed(1) + ' μA' : '—']
    ]);
  }

  function readZinc() {
    var m = MT[state.zMetal], uv = state.src === 'uv', nu = zNu(), hv = P.photonEV(nu), ek = hv - m.W, q = state.q;
    setText('rName', m.name + '板' + (q > 0.02 ? '带正电' : q < -0.02 ? '带负电' : '不带电'));
    setText('rKind', Math.abs(q) > 0.02 ? '验电器张开' : '验电器闭合');
    var tip;
    if (!state.zOn) tip = '灯已关闭。' + (q > 0.02 ? '锌板保持带正电（电荷不会自己消失），点「接地放电」恢复。' : '');
    else if (state.glass && uv) tip = '普通玻璃能挡住紫外线，锌板不再发射电子，验电器张角不变：说明起作用的是紫外线。';
    else if (ek <= 0) tip = (uv ? '紫外线' : '白光中频率最高的紫光') + '的光子能量 ' + hv.toFixed(2) + ' eV 也小于' + m.name + '的逸出功 ' + m.W.toFixed(2) + ' eV，不能打出电子。白光再强也没用。';
    else if (q < -0.02) tip = '金属板原来带负电，光电子飞出后负电荷减少，验电器张角先变小。';
    else if (q > P.qSat(ek) * 0.97) tip = '板带正电后，会把动能较小的光电子吸引回来，正电荷不再增加。';
    else tip = '光子把' + m.name + '板中的电子打出来（光电效应），板失去电子带正电，验电器的金箔带同种电荷而张开。';
    setText('rTip', tip);
    rows([
      ['光源', uv ? '紫外线灯，λ = 254 nm' : '白光（可见光 380～750 nm）'],
      ['光子能量', uv ? 'hν = ' + hv.toFixed(2) + ' eV' : '1.65～' + hv.toFixed(2) + ' eV'],
      ['逸出功', m.name + ' W₀ = ' + m.W.toFixed(2) + ' eV'],
      ['照到板上', !state.zOn ? '无（灯关）' : state.glass && uv ? '无（被玻璃挡住）' : ek > 0 ? '能打出电子，Ekmax = ' + ek.toFixed(2) + ' eV' : '打不出电子']
    ]);
  }

  function readEk() {
    var m = MT[state.metal], hv = P.photonEV(state.nu), ek = hv - m.W, nc = P.nuC(m.W), uc = state.yAxis === 'uc';
    setText('rName', ek > 0 ? (uc ? 'Uc = ' + ek.toFixed(2) + ' V' : 'Ekmax = ' + ek.toFixed(2) + ' eV') : '不发生光电效应');
    setText('rKind', m.name + ' W₀ = ' + m.W.toFixed(2) + ' eV');
    setText('rTip', ek > 0
      ? (uc ? 'eUc = Ekmax = hν − W₀，Uc = (h/e)ν − W₀/e：Uc-ν 图线的斜率 h/e 与金属无关，密立根就是这样测出普朗克常量的。'
        : '一个电子只吸收一个光子的能量 hν，用 W₀ 逸出表面后剩下的就是最大初动能。Ek 与 ν 成线性关系（不成正比），与光强无关。')
      : '光子能量小于逸出功，电子不能逸出。ν 必须大于截止频率 νc = W₀/h。');
    rows([
      lightRow(),
      ['光子能量', 'hν = ' + hv.toFixed(2) + ' eV = ' + P.sci(P.photonJ(state.nu)) + ' J'],
      ['截止频率', 'νc = W₀/h = ' + nuText(nc) + '（λc = ' + P.lamC(m.W).toFixed(0) + ' nm）'],
      ['最大初速度', ek > 0 ? 'vmax = √(2Ekmax/m) = ' + P.sci(P.vMax(ek)) + ' m/s' : '—'],
      ['图线斜率', uc ? 'h/e = ' + P.sci(P.H / P.E0) + ' V·s' : 'h = ' + P.sci(P.H) + ' J·s']
    ]);
  }

  // ---------- 尺寸与主循环 ----------
  function resize() { view.resize(stage.clientWidth, stage.clientHeight); }
  new ResizeObserver(resize).observe(stage);

  // 支持 ?scene=zinc|tube|ek
  // 光电管、Ek-ν：&metal=rb|k|na|ca|zn|w、&nu=4~16（×10¹⁴ Hz）或 &lam=188~750（nm）、&I=0~100（%）、&U=-5~5（V）、&light=0、&cmp=int|freq|metal
  // Ek-ν：&y=ek|uc、&all=0；锌板：&metal=、&src=uv|white、&glass=1、&neg=1、&I=、&t=0~30（快进秒数）
  var qs = new URLSearchParams(location.search);
  function num(k, lo, hi) { var x = parseFloat(qs.get(k)); return isFinite(x) && x >= lo && x <= hi ? x : null; }
  var x;
  if (HINTS[qs.get('scene')]) state.scene = qs.get('scene');
  if (state.scene === 'zinc') {
    if (MT[qs.get('metal')]) state.zMetal = qs.get('metal');
    if (qs.get('src') === 'white') state.src = 'white';
    if (qs.get('glass') === '1') state.glass = true;
    if (qs.get('neg') === '1') state.q = -0.8;
    if ((x = num('I', 0, 100)) != null) state.zI = x / 100;
    if (qs.get('light') === '0') state.zOn = false;
  } else {
    if (MT[qs.get('metal')]) state.metal = qs.get('metal');
    if ((x = num('nu', P.NU_RANGE[0], P.NU_RANGE[1])) != null) state.nu = x;
    else if ((x = num('lam', 188, 750)) != null) state.nu = P.nuOf(x);
    if ((x = num('I', 0, 100)) != null) state.I = x / 100;
    if ((x = num('U', -5, 5)) != null) state.U = x;
    if (qs.get('light') === '0') state.on = false;
    if (qs.get('y') === 'uc') state.yAxis = 'uc';
    if (qs.get('all') === '0') state.all = false;
    if (['int', 'freq', 'metal'].indexOf(qs.get('cmp')) >= 0) compare(qs.get('cmp'));
  }

  resize();
  setScene(state.scene);
  // &t=秒：打开时先快进一段（截图、分享时直接看到验电器张开、管中有电子）
  var ft0 = num('t', 0, 30);
  for (var ft = 0; ft < (ft0 == null ? 1.2 : ft0); ft += 0.05) { if (state.scene === 'zinc') stepZinc(0.05); else stepTube(0.05); }

  var lastT = performance.now(), phase = 0;
  function frame(now) {
    var dt = Math.min((now - lastT) / 1000, 0.1), sc = state.scene;
    lastT = now;
    if (state.paused) dt = 0;
    phase += dt;
    sliders.forEach(function (s) { if (document.activeElement !== s.el) s.el.value = s.get(); });
    setText('nuOut', nuText(state.nu));
    setText('nu2Out', nuText(state.nu));
    setText('IOut', Math.round(state.I * 100) + '%');
    setText('UOut', (state.U > 0 ? '+' : '') + state.U.toFixed(2) + ' V');
    setText('zIOut', Math.round(state.zI * 100) + '%');

    if (sc === 'zinc') {
      stepZinc(dt);
      view.drawZinc({ metal: state.zMetal, src: state.src, glass: state.glass, I: state.zI, on: state.zOn, q: state.q, photons: zn.photons, electrons: zn.electrons });
      readZinc();
    } else if (sc === 'tube') {
      stepTube(dt);
      view.drawTube({ metal: state.metal, nu: state.nu, I: state.I, U: state.U, on: state.on, cur: curNow(), emits: emitsNow(), Uc: Uc(),
        photons: tube.photons, electrons: tube.electrons, traces: state.traces });
      readTube();
    } else {
      view.drawEk({ metal: state.metal, nu: state.nu, all: state.all, yAxis: state.yAxis, phase: phase });
      readEk();
    }
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // 调试用
  window.__model = {
    state: state, setScene: setScene, syncUI: syncUI, compare: compare, keepTrace: keepTrace,
    setU: function (u) { state.U = P.clamp(u, -5, 5); },
    setNu: function (n) { state.nu = P.clamp(n, P.NU_RANGE[0], P.NU_RANGE[1]); syncUI(); },
    current: curNow
  };
})();
