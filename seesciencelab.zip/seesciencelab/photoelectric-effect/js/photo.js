// 光电效应的计算：光子能量、逸出功与截止频率、爱因斯坦光电效应方程、遏止电压、光电管 I-U 曲线、锌板带电
// 单位：频率 ν 用 10¹⁴ Hz，波长 λ 用 nm，能量用 eV，电压用 V，光电流用 μA；光强 0～1（按单位时间入射的光子数计）
// 常量取教材习题常用值 h = 6.63×10⁻³⁴ J·s、e = 1.6×10⁻¹⁹ C，截止频率由 νc = W₀/h 算出
(function () {
  var H = 6.63e-34, E0 = 1.6e-19, C = 3e8, ME = 9.1e-31;
  var NU_RANGE = [4, 16];
  // 人教版选择性必修第三册“几种金属的逸出功”表（锌为习题常用值）
  var METALS = {
    rb: { name: '铷', sym: 'Rb', W: 2.13 },
    k: { name: '钾', sym: 'K', W: 2.25 },
    na: { name: '钠', sym: 'Na', W: 2.29 },
    ca: { name: '钙', sym: 'Ca', W: 3.20 },
    zn: { name: '锌', sym: 'Zn', W: 3.34 },
    w: { name: '钨', sym: 'W', W: 4.54 }
  };
  var ORDER = ['rb', 'k', 'na', 'ca', 'zn', 'w'];
  // 常用色光的代表波长（nm）
  var LIGHTS = {
    red: { name: '红光', lam: 650 }, yellow: { name: '黄光', lam: 580 }, green: { name: '绿光', lam: 530 },
    blue: { name: '蓝光', lam: 460 }, violet: { name: '紫光', lam: 400 }, uv: { name: '紫外线', lam: 254 }
  };
  var IS_MAX = 50;     // 光强为 1 时的饱和电流（μA）
  var A_SAT = 1.2;     // I-U 曲线由 −Uc 上升到饱和的电压尺度（V），只影响曲线形状
  var VIS = window.Spectrum.VIS;

  function clamp(x, a, b) { return Math.max(a, Math.min(b, x)); }

  // ---------- 光子 ----------
  function lamOf(nu) { return C / (nu * 1e14) * 1e9; }
  function nuOf(lam) { return C / (lam * 1e-9) / 1e14; }
  function photonEV(nu) { return H * nu * 1e14 / E0; }
  function photonJ(nu) { return H * nu * 1e14; }

  // ---------- 光电效应方程 ----------
  function nuC(W) { return W * E0 / H / 1e14; }
  function lamC(W) { return lamOf(nuC(W)); }
  // Ek = hν − W₀，可能为负（不能发生光电效应）
  function ekMax(W, nu) { return photonEV(nu) - W; }
  function emits(W, nu) { return ekMax(W, nu) > 0; }
  // 遏止电压 Uc = Ekmax / e（数值上等于以 eV 为单位的 Ekmax）
  function stopU(W, nu) { return Math.max(0, ekMax(W, nu)); }
  // 光电子的最大初速度（m/s）
  function vMax(ek) { return ek > 0 ? Math.sqrt(2 * ek * E0 / ME) : 0; }

  // ---------- 光电管 ----------
  // 到达阳极的光电子占比：U = −Uc 时为 0，随 U 增大单调上升趋于 1（饱和）
  // 只是唯象的形状：反向电压下动能不够的电子被拉回，正向电压较小时斜射的电子还有一部分到不了阳极
  function collect(U, Uc) {
    var s = U + Uc;
    if (s <= 0) return 0;
    var z = s / A_SAT;
    return 1 - Math.exp(-z * z);
  }
  // 每个光电子抽一个随机数 r∈[0,1)，它能到达阳极当且仅当 collect(U, Uc) > r，即 U > reachU(r, Uc)
  // 这样动画里到达阳极的电子比例与电流表读数一致
  function reachU(r, Uc) { return A_SAT * Math.sqrt(-Math.log(1 - r)) - Uc; }
  // 光电流（μA）：o = { W, nu, I（0～1）, U }
  function current(o) {
    if (!(o.I > 0) || !emits(o.W, o.nu)) return 0;
    return IS_MAX * o.I * collect(o.U, stopU(o.W, o.nu));
  }
  function satCurrent(o) { return emits(o.W, o.nu) ? IS_MAX * o.I : 0; }
  // 曲线上取样：返回 [{U, I}]
  function curve(o, U0, U1, n) {
    var pts = [];
    for (var i = 0; i <= n; i++) {
      var U = U0 + (U1 - U0) * i / n;
      pts.push({ U: U, I: current({ W: o.W, nu: o.nu, I: o.I, U: U }) });
    }
    return pts;
  }

  // ---------- 锌板与验电器 ----------
  // q 为锌板（连同验电器）所带电荷，取 −1～1 的相对值；返回 dq/dt（1/s）
  // 带负电时光电子被排斥，全部飞离；带正电后动能小的光电子被吸回，q 趋于 qSat（与 Ekmax 有关）
  function qSat(ek) { return ek > 0 ? clamp(0.35 + 0.3 * ek, 0, 1) : 0; }
  function escapeFrac(q, ek) {
    if (!(ek > 0)) return 0;
    if (q <= 0) return 1;
    return clamp(1 - q / qSat(ek), 0, 1);
  }
  function zincRate(q, ek, I) { return 0.32 * I * escapeFrac(q, ek); }
  // 白光：可见光中频率最高的是紫光端
  function whiteMaxNu() { return nuOf(VIS[0]); }

  // ---------- 颜色（波长 → 颜色见 shared/spectrum.js） ----------
  var SP = window.Spectrum, lamRGB = SP.lamRGB, css = SP.css;
  function nuCSS(nu, a) { return css(lamRGB(lamOf(nu)), a); }
  function colorName(nu) { return SP.colorName(lamOf(nu)); }
  function visible(nu) { return SP.visible(lamOf(nu)); }

  // ---------- 格式 ----------
  function f(x, n) { return x.toFixed(n == null ? 2 : n); }
  function sci(x, n) {
    if (x === 0) return '0';
    var e = Math.floor(Math.log10(Math.abs(x))), m = x / Math.pow(10, e);
    if (Math.abs(m) >= 9.995) { m /= 10; e++; }
    var sup = String(e).replace(/-/g, '⁻').replace(/\d/g, function (d) { return '⁰¹²³⁴⁵⁶⁷⁸⁹'[d]; });
    return m.toFixed(n == null ? 2 : n) + '×10' + sup;
  }

  window.Photo = {
    H: H, E0: E0, C: C, ME: ME, METALS: METALS, ORDER: ORDER, LIGHTS: LIGHTS, NU_RANGE: NU_RANGE, IS_MAX: IS_MAX, VIS: VIS,
    clamp: clamp, lamOf: lamOf, nuOf: nuOf, photonEV: photonEV, photonJ: photonJ,
    nuC: nuC, lamC: lamC, ekMax: ekMax, emits: emits, stopU: stopU, vMax: vMax,
    collect: collect, reachU: reachU, current: current, satCurrent: satCurrent, curve: curve,
    qSat: qSat, escapeFrac: escapeFrac, zincRate: zincRate, whiteMaxNu: whiteMaxNu,
    lamRGB: lamRGB, css: css, nuCSS: nuCSS, colorName: colorName, visible: visible, f: f, sci: sci
  };
})();
