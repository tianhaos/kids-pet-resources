// 2D 绘制：锌板与验电器、光电管实验电路与 I-U 图像、能量示意图与 Ek-ν（Uc-ν）图像
// 装置图用各自的“设计坐标”（x 右 y 下，单位任意）整体等比缩放进屏幕矩形；图像用屏幕坐标
(function () {
  var P = window.Photo;
  var ELEC = '#4fc3f7', GOLD = '#ffc94a', GREEN = '#7ee081', RED = '#ff7a59', ALT = '#c9a7ff';
  var MUTED = '#8d99ab', TEXT = '#e6ebf2', GLASS = 'rgba(150,185,230,.55)', METAL = '#9aa7b8', WIRE = '#c9d2de';
  var FONT = '-apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", sans-serif';
  var TRACE_COLS = ['#ffc94a', '#7ee081', '#ff7a59', '#4fc3f7'];

  // 装置图里的字号随缩放变大，但不超过基准的 1.25 倍
  function fsz(base, k) { return Math.max(10, Math.min(base * 1.25, base * k)); }
  function font(px, w) { return (w ? w + ' ' : '') + px + 'px ' + FONT; }
  function label(ctx, s, x, y, o) {
    o = o || {};
    ctx.font = font(o.size || 12, o.bold ? 600 : null);
    ctx.textAlign = o.align || 'center'; ctx.textBaseline = o.base || 'middle';
    ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(5,7,13,.85)'; ctx.strokeText(s, x, y);
    ctx.fillStyle = o.color || TEXT; ctx.fillText(s, x, y);
  }
  function arrow(ctx, x1, y1, x2, y2, size, color, width, dash) {
    var a = Math.atan2(y2 - y1, x2 - x1), len = Math.hypot(x2 - x1, y2 - y1);
    if (len < 1) return;
    size = Math.min(size, len * 0.8);
    ctx.strokeStyle = ctx.fillStyle = color; ctx.lineWidth = width || 2; ctx.setLineDash(dash || []);
    ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2 - Math.cos(a) * size * 0.6, y2 - Math.sin(a) * size * 0.6); ctx.stroke();
    ctx.setLineDash([]);
    ctx.beginPath();
    ctx.moveTo(x2, y2);
    ctx.lineTo(x2 - size * Math.cos(a - 0.42), y2 - size * Math.sin(a - 0.42));
    ctx.lineTo(x2 - size * Math.cos(a + 0.42), y2 - size * Math.sin(a + 0.42));
    ctx.closePath(); ctx.fill();
  }
  // 设计坐标 → 屏幕：把 bw×bh 的设计画布等比放进矩形 R（居中）
  function fit(R, bw, bh) {
    var k = Math.min(R.w / bw, R.h / bh), ox = R.x + (R.w - bw * k) / 2, oy = R.y + (R.h - bh * k) / 2;
    return { k: k, x: function (x) { return ox + x * k; }, y: function (y) { return oy + y * k; } };
  }
  // 光子：一小段正弦波包，沿 (dx, dy) 方向前进
  function photon(ctx, x, y, dx, dy, color, k) {
    var len = Math.hypot(dx, dy) || 1, ux = dx / len, uy = dy / len, L = 16 * k, amp = 3.2 * k;
    ctx.strokeStyle = color; ctx.lineWidth = Math.max(1.4, 1.8 * k); ctx.setLineDash([]);
    ctx.beginPath();
    for (var i = 0; i <= 16; i++) {
      var s = -L + L * i / 16, w = Math.sin(i / 16 * Math.PI * 3) * amp * Math.sin(i / 16 * Math.PI);
      var px = x + ux * s - uy * w, py = y + uy * s + ux * w;
      if (i) ctx.lineTo(px, py); else ctx.moveTo(px, py);
    }
    ctx.stroke();
    ctx.fillStyle = color; ctx.beginPath(); ctx.arc(x, y, Math.max(1.6, 2 * k), 0, 7); ctx.fill();
  }
  function electron(ctx, x, y, r, alpha) {
    ctx.globalAlpha = alpha == null ? 1 : alpha;
    var g = ctx.createRadialGradient(x, y, 0, x, y, r * 2.4);
    g.addColorStop(0, 'rgba(79,195,247,.55)'); g.addColorStop(1, 'rgba(79,195,247,0)');
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r * 2.4, 0, 7); ctx.fill();
    ctx.fillStyle = ELEC; ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.fill();
    if (r >= 4) { ctx.strokeStyle = '#06202c'; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.moveTo(x - r * 0.5, y); ctx.lineTo(x + r * 0.5, y); ctx.stroke(); }
    ctx.globalAlpha = 1;
  }
  function sign(ctx, x, y, plus, r) {
    ctx.strokeStyle = plus ? RED : ELEC; ctx.lineWidth = Math.max(1.4, r * 0.4);
    ctx.beginPath(); ctx.moveTo(x - r, y); ctx.lineTo(x + r, y);
    if (plus) { ctx.moveTo(x, y - r); ctx.lineTo(x, y + r); }
    ctx.stroke();
  }
  function meter(ctx, x, y, r, txt) {
    ctx.fillStyle = '#121a2a'; ctx.strokeStyle = WIRE; ctx.lineWidth = 1.6;
    ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.fill(); ctx.stroke();
    label(ctx, txt, x, y + 0.5, { size: Math.max(10, r * 0.75), bold: true });
  }
  function line(ctx, pts, color, w, dash) {
    ctx.strokeStyle = color; ctx.lineWidth = w || 1.6; ctx.setLineDash(dash || []);
    ctx.beginPath();
    pts.forEach(function (p, i) { if (i) ctx.lineTo(p[0], p[1]); else ctx.moveTo(p[0], p[1]); });
    ctx.stroke(); ctx.setLineDash([]);
  }
  function roundRect(ctx, x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y); ctx.lineTo(x + w - r, y); ctx.arcTo(x + w, y, x + w, y + r, r);
    ctx.lineTo(x + w, y + h - r); ctx.arcTo(x + w, y + h, x + w - r, y + h, r);
    ctx.lineTo(x + r, y + h); ctx.arcTo(x, y + h, x, y + h - r, r);
    ctx.lineTo(x, y + r); ctx.arcTo(x, y, x + r, y, r); ctx.closePath();
  }
  function lampBox(ctx, cx, cy, w, h, color, on, text, k) {
    roundRect(ctx, cx - w / 2, cy - h / 2, w, h, 5 * k);
    ctx.fillStyle = '#1b2436'; ctx.fill(); ctx.strokeStyle = '#56627a'; ctx.lineWidth = 1.4; ctx.stroke();
    if (on) {
      var g = ctx.createRadialGradient(cx, cy, 0, cx, cy, h * 0.9);
      g.addColorStop(0, color); g.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(cx, cy, h * 0.9, 0, 7); ctx.fill();
    }
    label(ctx, text, cx, cy, { size: fsz(11, k), color: on ? TEXT : MUTED });
  }

  // ---------- 视图 ----------
  function View(canvas) {
    var ctx = canvas.getContext('2d'), W = 0, H = 0, dpr = 1, narrow = false, geo = {};
    function resize(w, h) {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      W = w; H = h; narrow = w < 640;
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
      canvas.style.width = w + 'px'; canvas.style.height = h + 'px';
    }
    function bg() {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      var g = ctx.createLinearGradient(0, 0, 0, H);
      g.addColorStop(0, '#04060c'); g.addColorStop(1, '#0a1120');
      ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    }
    // 装置区 A 与图像区 G：宽屏左右排，窄屏上下排
    function split(ratio) {
      var t0 = narrow ? 70 : 48, bottom = 48, h = Math.max(200, H - t0 - bottom);
      if (W >= 760 && W / h > 1.25) {
        var aw = Math.round((W - 28) * ratio);
        return { A: { x: 14, y: t0, w: aw, h: h }, G: { x: 14 + aw + 16, y: t0 + 8, w: W - aw - 44, h: Math.min(h - 8, (W - aw - 44) * 0.9) } };
      }
      var ah = Math.round(h * 0.52);
      return { A: { x: 10, y: t0, w: W - 20, h: ah }, G: { x: 10, y: t0 + ah + 8, w: W - 20, h: h - ah - 8 } };
    }
    // 坐标轴框：留出刻度与标题的位置
    function plotBox(G, title) {
      ctx.fillStyle = 'rgba(16,22,36,.75)'; ctx.strokeStyle = 'rgba(141,153,171,.25)'; ctx.lineWidth = 1;
      roundRect(ctx, G.x, G.y, G.w, G.h, 10); ctx.fill(); ctx.stroke();
      label(ctx, title, G.x + 12, G.y + 15, { align: 'left', size: 12, bold: true, color: MUTED });
      return { x: G.x + 44, y: G.y + 48, w: G.w - 62, h: G.h - 80 };
    }

    // ================= 场景一：锌板与验电器 =================
    // o: { metal, src: 'uv'|'white', glass, I, on, q, photons:[{s, y, nu}], electrons:[{x, y, a}] }
    function drawZinc(o) {
      bg();
      var t0 = narrow ? 70 : 48, R = { x: 10, y: t0, w: W - 20, h: H - t0 - 50 };
      var F = fit(R, 470, 300), k = F.k, X = F.x, Y = F.y;
      var M = P.METALS[o.metal], uv = o.src === 'uv';
      var col = uv ? 'rgba(170,140,255,' : 'rgba(255,248,225,';
      var plateX = 236, glassX = 150, beamEnd = o.glass && uv ? glassX : plateX;
      // 光束
      if (o.on) {
        ctx.fillStyle = col + (0.06 + 0.14 * o.I) + ')';
        ctx.beginPath(); ctx.moveTo(X(82), Y(128)); ctx.lineTo(X(beamEnd), Y(beamEnd === plateX ? 96 : 104)); ctx.lineTo(X(beamEnd), Y(beamEnd === plateX ? 184 : 176)); ctx.lineTo(X(82), Y(152)); ctx.closePath(); ctx.fill();
        if (o.glass && !uv) {
          // 白光穿过玻璃（可见光可以透过）
          label(ctx, '可见光能透过玻璃', X(glassX), Y(214), { size: fsz(11, k), color: MUTED });
        }
      }
      lampBox(ctx, X(48), Y(140), 70 * k, 46 * k, uv ? 'rgba(170,140,255,.55)' : 'rgba(255,240,200,.6)', o.on, uv ? '紫外线灯' : '白光灯', k);
      label(ctx, uv ? 'λ = 254 nm' : '可见光 380～750 nm', X(48), Y(176), { size: fsz(11, k), color: MUTED });
      // 光子
      o.photons.forEach(function (ph) {
        var x = 82 + (ph.end - 82) * ph.s, y = 140 + (ph.y - 140) * ph.s;
        photon(ctx, X(x), Y(y), (ph.end - 82) * k, (ph.y - 140) * k, uv ? 'rgba(190,165,255,.95)' : P.nuCSS(ph.nu, 0.95), k);
      });
      // 玻璃板
      if (o.glass) {
        ctx.fillStyle = 'rgba(150,200,255,.18)'; ctx.strokeStyle = GLASS; ctx.lineWidth = 1.2;
        ctx.fillRect(X(glassX - 4), Y(74), 8 * k, 132 * k); ctx.strokeRect(X(glassX - 4), Y(74), 8 * k, 132 * k);
        label(ctx, '玻璃板', X(glassX), Y(64), { size: fsz(11, k), color: MUTED });
        if (uv && o.on) label(ctx, '挡住紫外线', X(glassX), Y(226), { size: fsz(11, k), color: ALT });
      }
      // 绝缘支架
      ctx.strokeStyle = '#56627a'; ctx.lineWidth = 4 * k;
      line(ctx, [[X(plateX + 5), Y(190)], [X(plateX + 5), Y(262)]], '#56627a', 4 * k);
      line(ctx, [[X(plateX - 20), Y(264)], [X(plateX + 30), Y(264)]], '#56627a', 5 * k);
      // 金属板
      ctx.fillStyle = METAL; ctx.fillRect(X(plateX), Y(92), 10 * k, 98 * k);
      label(ctx, M.name + '板', X(plateX + 5), Y(80), { size: fsz(12, k), bold: true });
      // 导线 → 验电器
      var bx = 380;
      line(ctx, [[X(plateX + 10), Y(100)], [X(plateX + 40), Y(100)], [X(plateX + 40), Y(58)], [X(bx), Y(58)], [X(bx), Y(80)]], WIRE, Math.max(1.4, 1.8 * k));
      // 验电器：金属球、金属杆、两片金箔、玻璃外壳
      roundRect(ctx, X(bx - 52), Y(118), 104 * k, 140 * k, 14 * k);
      ctx.fillStyle = 'rgba(120,150,200,.06)'; ctx.fill(); ctx.strokeStyle = GLASS; ctx.lineWidth = 1.4; ctx.stroke();
      line(ctx, [[X(bx), Y(88)], [X(bx), Y(196)]], WIRE, 3.2 * k);
      ctx.fillStyle = '#b8c3d2'; ctx.beginPath(); ctx.arc(X(bx), Y(86), 9 * k, 0, 7); ctx.fill();
      var ang = (3 + 46 * Math.sqrt(Math.min(1, Math.abs(o.q)))) * Math.PI / 180, Lf = 52;
      [-1, 1].forEach(function (s) {
        var px = bx, py = 192, ex = px + s * Lf * Math.sin(ang), ey = py + Lf * Math.cos(ang);
        ctx.strokeStyle = GOLD; ctx.lineWidth = 5 * k; ctx.lineCap = 'round';
        ctx.beginPath(); ctx.moveTo(X(px), Y(py)); ctx.lineTo(X(ex), Y(ey)); ctx.stroke(); ctx.lineCap = 'butt';
      });
      label(ctx, '验电器', X(bx), Y(274), { size: fsz(12, k), color: MUTED });
      // 电荷符号：板上与金箔上
      var n = Math.round(Math.abs(o.q) * 8), plus = o.q > 0;
      for (var i = 0; i < n; i++) {
        sign(ctx, X(plateX + 19), Y(100 + i * 11), plus, 3 * k);
        if (i < 4) {
          var ss = i % 2 ? 1 : -1, d = 18 + Math.floor(i / 2) * 18;
          sign(ctx, X(bx + ss * (d * Math.sin(ang) + 10)), Y(192 + d * Math.cos(ang)), plus, 2.6 * k);
        }
      }
      // 光电子
      ctx.save(); ctx.beginPath(); ctx.rect(R.x, R.y, R.w, R.h); ctx.clip();
      o.electrons.forEach(function (e) { electron(ctx, X(e.x), Y(e.y), Math.max(2.6, 3.4 * k), e.a); });
      ctx.restore();
      label(ctx, o.q > 0.02 ? '带正电' : o.q < -0.02 ? '带负电' : '不带电', X(plateX + 5), Y(206), { size: fsz(12, k), bold: true, color: o.q > 0.02 ? RED : o.q < -0.02 ? ELEC : MUTED });
      geo = { scene: 'zinc' };
    }

    // ================= 场景二：光电管 =================
    // o: { metal, nu, I, U, on, cur, photons:[{s, y}], electrons:[{x, y, a}], traces:[{W, nu, I, label}], Uc, ek }
    // 光电管内：阴极 K 表面 x = 0，阳极 A x = 1（电子坐标），y ∈ [−1, 1]
    var TK = { kx: 150, ax: 312, cy: 136, hy: 36 };
    function drawTube(o) {
      bg();
      var L = split(0.52), F = fit(L.A, 420, 330), k = F.k, X = F.x, Y = F.y;
      var col = P.nuCSS(o.nu, 1), M = P.METALS[o.metal];
      function ex(x) { return X(TK.kx + (TK.ax - TK.kx) * x); }
      function ey(y) { return Y(TK.cy + TK.hy * y); }
      // 光源与光束（从上方斜射到阴极）
      var lx = 250, ly = 22;
      if (o.on) {
        ctx.fillStyle = P.nuCSS(o.nu, 0.05 + 0.16 * o.I);
        ctx.beginPath(); ctx.moveTo(X(lx - 16), Y(ly + 12)); ctx.lineTo(X(lx + 16), Y(ly + 12)); ctx.lineTo(X(TK.kx + 2), Y(TK.cy + 34)); ctx.lineTo(X(TK.kx + 2), Y(TK.cy - 34)); ctx.closePath(); ctx.fill();
      }
      lampBox(ctx, X(lx), Y(ly), 74 * k, 26 * k, P.nuCSS(o.nu, 0.8), o.on, P.colorName(o.nu), k);
      label(ctx, 'λ = ' + P.lamOf(o.nu).toFixed(0) + ' nm', X(lx + 46), Y(ly), { align: 'left', size: fsz(11, k), color: MUTED });
      // 管壳
      roundRect(ctx, X(110), Y(66), 240 * k, 136 * k, 62 * k);
      ctx.fillStyle = 'rgba(120,150,200,.06)'; ctx.fill(); ctx.strokeStyle = GLASS; ctx.lineWidth = 1.4; ctx.stroke();
      // 电场方向（U > 0 时 A 电势高，电场由 A 指向 K）
      if (Math.abs(o.U) > 0.05) {
        var al = Math.min(0.5, 0.15 + Math.abs(o.U) * 0.08);
        ctx.globalAlpha = al;
        [-0.62, 0.62].forEach(function (yy) {
          var a = o.U > 0 ? ex(0.78) : ex(0.22), b = o.U > 0 ? ex(0.22) : ex(0.78);
          arrow(ctx, a, ey(yy), b, ey(yy), 7 * k, '#9fb3d9', 1.2);
        });
        ctx.globalAlpha = 1;
        label(ctx, 'E', ex(0.5), ey(-0.62) - 9 * k, { size: fsz(11, k), color: '#9fb3d9' });
      }
      // 阴极（弧面朝右）与阳极
      ctx.strokeStyle = METAL; ctx.lineWidth = 5 * k;
      ctx.beginPath(); ctx.arc(X(TK.kx + 30), Y(TK.cy), 44 * k, Math.PI * 0.79, Math.PI * 1.21); ctx.stroke();
      ctx.fillStyle = METAL; ctx.fillRect(X(TK.ax), Y(TK.cy - 30), 5 * k, 60 * k);
      label(ctx, 'K', X(TK.kx - 26), Y(TK.cy - 30), { size: fsz(14, k), bold: true });
      label(ctx, 'A', X(TK.ax + 22), Y(TK.cy - 30), { size: fsz(14, k), bold: true });
      label(ctx, '阴极：' + M.name, X(132), Y(224), { align: 'right', size: fsz(11, k), color: MUTED });
      if (Math.abs(o.U) > 0.05) {
        sign(ctx, X(TK.kx - 26), Y(TK.cy + 4), o.U < 0, 4 * k);
        sign(ctx, X(TK.ax + 22), Y(TK.cy + 4), o.U > 0, 4 * k);
      }
      // 光子与光电子
      o.photons.forEach(function (ph) {
        var x0 = lx, y0 = ly + 12, x1 = TK.kx + 4, y1 = TK.cy + TK.hy * ph.y;
        photon(ctx, X(x0 + (x1 - x0) * ph.s), Y(y0 + (y1 - y0) * ph.s), (x1 - x0) * k, (y1 - y0) * k, col, k * 0.9);
      });
      ctx.save(); roundRect(ctx, X(110), Y(66), 240 * k, 136 * k, 62 * k); ctx.clip();
      o.electrons.forEach(function (e) { electron(ctx, ex(e.x), ey(e.y), Math.max(2.4, 3.2 * k), e.a); });
      ctx.restore();
      // 电路：A → 微安表 → 电源 → K，电压表并联在 K、A 之间
      var wl = Math.max(1.3, 1.7 * k), yb = 312, yv = 262, xk = 140, xa = 324;
      line(ctx, [[X(TK.kx - 12), Y(TK.cy + 40)], [X(xk), Y(202)], [X(xk), Y(yb)], [X(xa), Y(yb)], [X(xa), Y(202)], [X(TK.ax + 3), Y(TK.cy + 30)]], WIRE, wl);
      line(ctx, [[X(xk), Y(yv)], [X(xa), Y(yv)]], WIRE, wl);
      ctx.fillStyle = WIRE; [[xk, yv], [xa, yv]].forEach(function (p) { ctx.beginPath(); ctx.arc(X(p[0]), Y(p[1]), 2.6 * k, 0, 7); ctx.fill(); });
      meter(ctx, X(xa), Y(230), 13 * k, 'μA');
      meter(ctx, X(232), Y(yv), 13 * k, 'V');
      label(ctx, (o.cur < 9.95 ? o.cur.toFixed(2) : o.cur.toFixed(1)) + ' μA', X(xa + 18), Y(230), { align: 'left', size: fsz(13, k), bold: true, color: GOLD });
      label(ctx, 'UAK = ' + (o.U > 0 ? '+' : '') + o.U.toFixed(2) + ' V', X(232), Y(yv - 22), { size: fsz(12, k), bold: true });
      // 电源：长线为正极。U > 0 时正极接 A（右侧）
      var bx = 232, pos = o.U >= 0 ? 1 : -1;
      ctx.fillStyle = '#0a1120'; ctx.fillRect(X(bx - 14), Y(yb - 16), 28 * k, 32 * k);
      [[-6, pos < 0 ? 15 : 8], [6, pos > 0 ? 15 : 8]].forEach(function (p) {
        ctx.strokeStyle = WIRE; ctx.lineWidth = p[1] > 10 ? 2 * k : 4 * k;
        ctx.beginPath(); ctx.moveTo(X(bx + p[0]), Y(yb - p[1])); ctx.lineTo(X(bx + p[0]), Y(yb + p[1])); ctx.stroke();
      });
      label(ctx, '+', X(bx + pos * 16), Y(yb - 14), { size: fsz(12, k), bold: true, color: RED });
      label(ctx, '可调电源（可换向）', X(bx), Y(yb + 24), { size: fsz(11, k), color: MUTED });
      label(ctx, o.U > 0.005 ? '正向电压：A 接正极' : o.U < -0.005 ? '反向电压：A 接负极' : '电压为零', X(bx), Y(yb - 30), { size: fsz(11, k), color: o.U < -0.005 ? RED : o.U > 0.005 ? GREEN : MUTED });

      drawIU(L.G, o);
      if (!o.emits && o.on) label(ctx, 'hν < W₀，没有光电子', ex(0.5), ey(0), { size: fsz(13, k), bold: true, color: RED });
    }
    // I-U 图像：横轴 −5～5 V，纵轴 0～1.15 Is,max
    function drawIU(G, o) {
      var A = plotBox(G, narrow ? 'I-U 图像（拖动改电压）' : '光电流 I-U 图像（在图上拖动改变电压）'), U0 = -5, U1 = 5, Imax = P.IS_MAX * 1.15;
      function X(U) { return A.x + (U - U0) / (U1 - U0) * A.w; }
      function Y(I) { return A.y + A.h - I / Imax * A.h; }
      ctx.lineWidth = 1; ctx.font = font(10);
      for (var u = U0; u <= U1; u++) {
        ctx.strokeStyle = u === 0 ? 'rgba(141,153,171,.6)' : 'rgba(141,153,171,.12)';
        ctx.beginPath(); ctx.moveTo(X(u), A.y); ctx.lineTo(X(u), A.y + A.h); ctx.stroke();
        if (!narrow || Math.abs(u % 2) === 1 || u === 0) label(ctx, String(u), X(u), A.y + A.h + 11, { size: 10, color: MUTED });
      }
      for (var i = 0; i <= 50; i += 10) {
        ctx.strokeStyle = i === 0 ? 'rgba(141,153,171,.6)' : 'rgba(141,153,171,.12)';
        ctx.beginPath(); ctx.moveTo(A.x, Y(i)); ctx.lineTo(A.x + A.w, Y(i)); ctx.stroke();
        label(ctx, String(i), A.x - 6, Y(i), { align: 'right', size: 10, color: MUTED });
      }
      label(ctx, 'UAK / V', A.x + A.w, A.y + A.h + 24, { align: 'right', size: 10, color: MUTED });
      label(ctx, 'I / μA', A.x - 6, A.y - 12, { align: 'right', size: 10, color: MUTED });
      // 保存的曲线
      o.traces.forEach(function (tr, j) {
        var pts = P.curve(tr, U0, U1, 200), c = TRACE_COLS[j % TRACE_COLS.length];
        line(ctx, pts.map(function (p) { return [X(p.U), Y(p.I)]; }), c, 1.6, [6, 4]);
        var uc = P.stopU(tr.W, tr.nu), ls = P.satCurrent(tr);
        var dy = 0;
        for (var q = 0; q < j; q++) if (Math.abs(P.satCurrent(o.traces[q]) - ls) < 4) dy += 15;
        label(ctx, tr.label, A.x + A.w - 4, Y(ls) - 9 - dy, { align: 'right', size: 11, color: c });
        if (ls > 0 && uc > 0.02) { ctx.fillStyle = c; ctx.beginPath(); ctx.arc(X(-uc), Y(0), 3, 0, 7); ctx.fill(); }
      });
      // 当前曲线
      var on = o.on ? o.I : 0, cur = { W: P.METALS[o.metal].W, nu: o.nu, I: on };
      var col = P.nuCSS(o.nu, 1);
      line(ctx, P.curve(cur, U0, U1, 240).map(function (p) { return [X(p.U), Y(p.I)]; }), col, 2.4);
      if (o.emits && on > 0) {
        var uc = o.Uc, is = P.satCurrent(cur);
        ctx.setLineDash([4, 4]); ctx.strokeStyle = 'rgba(230,235,242,.45)'; ctx.lineWidth = 1;
        ctx.beginPath(); ctx.moveTo(A.x, Y(is)); ctx.lineTo(A.x + A.w, Y(is)); ctx.stroke(); ctx.setLineDash([]);
        label(ctx, 'Is', A.x + 6, Y(is) - 8, { align: 'left', size: 11, bold: true });
        ctx.fillStyle = RED; ctx.beginPath(); ctx.arc(X(-uc), Y(0), 3.6, 0, 7); ctx.fill();
        label(ctx, '−Uc', X(-uc), Y(0) - 12, { size: 11, bold: true, color: RED });
      }
      // 当前工作点
      var px = X(o.U), py = Y(o.cur);
      ctx.strokeStyle = 'rgba(255,201,74,.5)'; ctx.setLineDash([3, 4]); ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(px, A.y); ctx.lineTo(px, A.y + A.h); ctx.stroke(); ctx.setLineDash([]);
      ctx.fillStyle = GOLD; ctx.strokeStyle = '#05070d'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(px, py, 6, 0, 7); ctx.fill(); ctx.stroke();
      geo = { scene: 'tube', A: A, U0: U0, U1: U1, G: G };
    }

    // ================= 场景三：能量示意图与 Ek-ν 图像 =================
    // o: { metal, nu, all, yAxis: 'ek'|'uc', ek, phase }
    function drawEk(o) {
      bg();
      var L = split(0.42), M = P.METALS[o.metal], hv = P.photonEV(o.nu), ek = hv - M.W, col = P.nuCSS(o.nu, 1);
      // ---- 能量示意图（设计坐标 300×330，能量 0 在 y = 150，每 eV 22 单位） ----
      var F = fit(L.A, 300, 330), k = F.k, X = F.x, Y = F.y;
      function YE(e) { return Y(150 - e * 22); }
      var top = -M.W, deep = -7.6;
      ctx.fillStyle = 'rgba(154,167,184,.16)'; ctx.fillRect(X(20), YE(top), 120 * k, YE(deep) - YE(top));
      ctx.strokeStyle = METAL; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(X(20), YE(top)); ctx.lineTo(X(140), YE(top)); ctx.stroke();
      // 金属里的自由电子
      for (var r = 0; r < 4; r++) for (var c = 0; c < 6; c++) {
        var xx = 32 + c * 19 + (r % 2) * 9, ee = top - 0.35 - r * 0.85;
        if (ee > deep + 0.3) electron(ctx, X(xx), YE(ee), Math.max(2, 2.6 * k), 0.55);
      }
      label(ctx, M.name + '（金属内部）', X(80), YE(deep) - 12 * k, { size: fsz(11, k), color: MUTED });
      // 真空能级
      ctx.setLineDash([6, 5]); ctx.strokeStyle = 'rgba(230,235,242,.5)'; ctx.lineWidth = 1.2;
      ctx.beginPath(); ctx.moveTo(X(20), YE(0)); ctx.lineTo(X(290), YE(0)); ctx.stroke(); ctx.setLineDash([]);
      label(ctx, '刚好逸出（Ek = 0）', X(290), YE(0) + 10 * k, { align: 'right', size: fsz(11, k), color: MUTED });
      // W₀ 标注
      var bxW = 150;
      line(ctx, [[X(bxW - 4), YE(0)], [X(bxW), YE(0)], [X(bxW), YE(top)], [X(bxW - 4), YE(top)]], MUTED, 1.2);
      label(ctx, 'W₀ = ' + M.W.toFixed(2) + ' eV', X(bxW + 6), (YE(0) + YE(top)) / 2, { align: 'left', size: fsz(12, k), color: TEXT });
      // 光子被表面电子吸收：竖直箭头长 hν
      var ax = 110, endE = Math.min(top + hv, 6.6), phx = X(ax - 64 + 10 * Math.sin(o.phase * 3)), phy = YE(top) - 36 * k;
      photon(ctx, phx, phy, 1, 0.5, col, k);
      var midY = (YE(top) + YE(endE)) / 2;
      label(ctx, 'hν', X(ax - 6), midY - 8 * k, { align: 'right', size: fsz(13, k), bold: true, color: col });
      label(ctx, hv.toFixed(2) + ' eV', X(ax - 6), midY + 8 * k, { align: 'right', size: fsz(11, k), color: col });
      arrow(ctx, X(ax), YE(top), X(ax), YE(endE), 9 * k, col, 2.4);
      electron(ctx, X(ax), YE(top), Math.max(3, 4 * k));
      // 内部的电子：同样吸收 hν，逸出时动能更小（虚线）
      var e2 = top - 0.9;
      arrow(ctx, X(34), YE(e2), X(34), YE(Math.min(e2 + hv, 6.6)), 8 * k, col, 1.4, [4, 4]);
      label(ctx, '内部电子', X(34), YE(e2) + 12 * k, { size: fsz(10, k), color: MUTED });
      if (ek > 0) {
        // 逸出的光电子带着 Ekmax 飞出
        var outX = 236 + 26 * ((o.phase * 0.6) % 1);
        line(ctx, [[X(ax + 4), YE(ek)], [X(outX), YE(ek)]], 'rgba(79,195,247,.5)', 1.2, [3, 3]);
        electron(ctx, X(outX), YE(ek), Math.max(3, 4 * k));
        arrow(ctx, X(outX + 8), YE(ek), X(outX + 30), YE(ek), 7 * k, ELEC, 1.6);
        line(ctx, [[X(ax + 10), YE(0)], [X(ax + 14), YE(0)], [X(ax + 14), YE(ek)], [X(ax + 10), YE(ek)]], GOLD, 1.4);
        label(ctx, 'Ekmax = ' + ek.toFixed(2) + ' eV', X(ax + 20), YE(ek) - 12 * k, { align: 'left', size: fsz(12, k), bold: true, color: GOLD });
        label(ctx, 'hν = W₀ + Ekmax', X(150), Y(20), { size: fsz(14, k), bold: true, color: GOLD });
      } else {
        label(ctx, 'hν < W₀：电子跳不出去', X(150), Y(20), { size: fsz(14, k), bold: true, color: RED });
        label(ctx, '差 ' + (-ek).toFixed(2) + ' eV', X(ax + 8), (YE(0) + YE(endE)) / 2, { align: 'left', size: fsz(11, k), color: RED });
      }
      drawEkGraph(L.G, o, M, ek);
    }
    // Ek-ν（或 Uc-ν）：横轴 0～16×10¹⁴ Hz，纵轴 −5～5（eV 或 V）。ν < νc 的部分是反向延长线，画虚线
    function drawEkGraph(G, o, M, ek) {
      var uc = o.yAxis === 'uc';
      var A = plotBox(G, uc ? '遏止电压 Uc-ν 图像（拖动改变频率）' : '最大初动能 Ek-ν 图像（拖动改变频率）');
      var N0 = 0, N1 = 16, E0 = -5, E1 = 5;
      function X(n) { return A.x + (n - N0) / (N1 - N0) * A.w; }
      function Y(e) { return A.y + (E1 - e) / (E1 - E0) * A.h; }
      ctx.lineWidth = 1;
      for (var n = 0; n <= 16; n += 2) {
        ctx.strokeStyle = n === 0 ? 'rgba(141,153,171,.6)' : 'rgba(141,153,171,.12)';
        ctx.beginPath(); ctx.moveTo(X(n), A.y); ctx.lineTo(X(n), A.y + A.h); ctx.stroke();
        if (n) label(ctx, String(n), X(n), Y(0) + 11, { size: 10, color: MUTED });
      }
      for (var e = E0; e <= E1; e++) {
        ctx.strokeStyle = e === 0 ? 'rgba(141,153,171,.6)' : 'rgba(141,153,171,.12)';
        ctx.beginPath(); ctx.moveTo(A.x, Y(e)); ctx.lineTo(A.x + A.w, Y(e)); ctx.stroke();
        if (e % (narrow ? 2 : 1) === 0 || e === -5) label(ctx, String(e), A.x - 6, Y(e), { align: 'right', size: 10, color: MUTED });
      }
      label(ctx, 'ν / ×10¹⁴ Hz', A.x + A.w, A.y + A.h + 14, { align: 'right', size: 10, color: MUTED });
      label(ctx, uc ? 'Uc / V' : 'Ek / eV', A.x - 6, A.y - 12, { align: 'right', size: 10, color: MUTED });
      // 可见光波段
      var v0 = P.nuOf(750), v1 = P.nuOf(380), gr = ctx.createLinearGradient(X(v0), 0, X(v1), 0);
      for (var s = 0; s <= 8; s++) { var lam = 750 - 370 * s / 8; gr.addColorStop(s / 8, P.css(P.lamRGB(lam), 0.85)); }
      ctx.fillStyle = gr; ctx.fillRect(X(v0), A.y + A.h - 5, X(v1) - X(v0), 5);
      label(ctx, '可见光', (X(v0) + X(v1)) / 2, A.y + A.h - 13, { size: 10, color: MUTED });
      // 各金属的直线
      var list = o.all ? P.ORDER : [o.metal];
      ctx.save(); ctx.beginPath(); ctx.rect(A.x, A.y, A.w, A.h); ctx.clip();
      list.forEach(function (key) {
        var m = P.METALS[key], nc = P.nuC(m.W), me = key === o.metal, c = me ? GOLD : 'rgba(141,153,171,.55)', w = me ? 2.4 : 1.2;
        line(ctx, [[X(0), Y(-m.W)], [X(nc), Y(0)]], c, me ? 1.6 : 1, [5, 4]);
        line(ctx, [[X(nc), Y(0)], [X(N1), Y(P.ekMax(m.W, N1))]], c, w);
      });
      ctx.restore();
      // 图线右端的金属名：当前金属先写，与已写的太近就省略
      var used = [];
      [o.metal].concat(list.filter(function (k2) { return k2 !== o.metal; })).forEach(function (key) {
        var m = P.METALS[key], me = key === o.metal, ye = Y(P.ekMax(m.W, N1));
        if (used.some(function (u) { return Math.abs(u - ye) < 13; })) return;
        used.push(ye);
        label(ctx, m.name, X(N1) + 4, ye, { align: 'left', size: 11, bold: me, color: me ? GOLD : MUTED });
      });
      // 当前金属的截距与斜率
      var nc = P.nuC(M.W);
      ctx.fillStyle = GOLD;
      ctx.beginPath(); ctx.arc(X(nc), Y(0), 3.5, 0, 7); ctx.fill();
      ctx.beginPath(); ctx.arc(X(0), Y(-M.W), 3.5, 0, 7); ctx.fill();
      label(ctx, 'νc = ' + nc.toFixed(2), X(nc) + 4, Y(0) - 12, { align: 'left', size: 11, bold: true, color: GOLD });
      label(ctx, uc ? '−W₀/e' : '−W₀', X(0) + 8, Y(-M.W) + 2, { align: 'left', size: 11, bold: true, color: GOLD });
      var n1 = Math.min(nc + 3, 15), n2 = Math.min(nc + 6, 16);
      if (n2 - n1 > 1.5) {
        var y1 = Y(P.ekMax(M.W, n1)), y2 = Y(P.ekMax(M.W, n2));
        line(ctx, [[X(n1), y1], [X(n2), y1], [X(n2), y2]], 'rgba(255,201,74,.7)', 1.2);
        label(ctx, 'Δν', (X(n1) + X(n2)) / 2, y1 + 10, { size: 10, color: GOLD });
        label(ctx, uc ? 'ΔUc' : 'ΔEk', X(n2) + 4, (y1 + y2) / 2, { align: 'left', size: 10, color: GOLD });
        label(ctx, uc ? '斜率 = h/e' : '斜率 = h', (X(n1) + X(n2)) / 2 - 6, y1 + 26, { size: 11, bold: true, color: GOLD });
      }
      // 当前频率
      var col = P.nuCSS(o.nu, 1), px = X(o.nu);
      ctx.strokeStyle = col; ctx.globalAlpha = 0.7; ctx.lineWidth = 1.2; ctx.setLineDash([3, 4]);
      ctx.beginPath(); ctx.moveTo(px, A.y); ctx.lineTo(px, A.y + A.h); ctx.stroke(); ctx.setLineDash([]); ctx.globalAlpha = 1;
      if (ek > 0) {
        ctx.fillStyle = col; ctx.strokeStyle = '#05070d'; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.arc(px, Y(ek), 6, 0, 7); ctx.fill(); ctx.stroke();
        label(ctx, (uc ? 'Uc = ' + ek.toFixed(2) + ' V' : 'Ek = ' + ek.toFixed(2) + ' eV'), px + (o.nu > 12 ? -10 : 10), Y(ek) + (ek > 3.8 ? 16 : -14), { align: o.nu > 12 ? 'right' : 'left', size: 11, bold: true, color: TEXT });
      } else {
        ctx.strokeStyle = RED; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.moveTo(px - 5, Y(0) - 5); ctx.lineTo(px + 5, Y(0) + 5); ctx.moveTo(px + 5, Y(0) - 5); ctx.lineTo(px - 5, Y(0) + 5); ctx.stroke();
        label(ctx, 'ν < νc，不发生', px + 8, Y(0) + 26, { align: 'left', size: 11, bold: true, color: RED });
      }
      geo = { scene: 'ek', A: A, N0: N0, N1: N1, G: G };
    }

    return { resize: resize, drawZinc: drawZinc, drawTube: drawTube, drawEk: drawEk, geo: function () { return geo; }, isNarrow: function () { return narrow; } };
  }

  window.PhotoDraw = { View: View, TRACE_COLS: TRACE_COLS };
})();
