/* 共点力：SI单位，角度从+x轴逆时针，纯计算。 */
(function () {
  'use strict';
  const rad = Math.PI / 180;
  const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
  function vector(f, a) { return { x: f * Math.cos(a * rad), y: f * Math.sin(a * rad) }; }
  function polar(v) {
    const f = Math.hypot(v.x, v.y);
    return { f: f < 1e-9 ? 0 : f, a: f < 1e-9 ? null : Math.atan2(v.y, v.x) / rad };
  }
  function calculate(s) {
    const u = s.scene === 'resolve' ? { x: vector(s.f, s.a).x, y: 0 } : vector(s.f1, s.a1);
    const v = s.scene === 'resolve' ? { x: 0, y: vector(s.f, s.a).y } : vector(s.f2, s.a2);
    const sum = { x: u.x + v.x, y: u.y + v.y };
    const theta = Math.acos(clamp(Math.cos((s.a2 - s.a1) * rad), -1, 1)) / rad;
    return { u, v, sum, ...polar(sum), theta };
  }
  function magnitude(f1, f2, theta) {
    return Math.sqrt(Math.max(0, f1 * f1 + f2 * f2 + 2 * f1 * f2 * Math.cos(theta * rad)));
  }
  window.ForceVectors = { vector, polar, calculate, magnitude, clamp };
}());
