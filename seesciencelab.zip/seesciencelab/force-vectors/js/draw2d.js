/* 绘图使用CSS像素，同一画面内各力使用统一比例；辅助线不是额外的力。 */
(function () {
  'use strict';
  const C = { one: '#77d8e3', two: '#f29e88', sum: '#ffc94a', ink: '#a5b1c3' };
  let geo;
  function geometry(w, h, r, showChart = true) {
    const top = 12;
    const chartHeight = Math.max(48, Math.min(108, h * .19));
    const chart = showChart ? { x: 44, y: h - chartHeight - 28, w: Math.max(1, w - 70), h: chartHeight } : null;
    const bottom = Math.max(top + 44, chart ? chart.y - 64 : h - 32);
    const extent = r ? Math.max(10, Math.abs(r.u.x), Math.abs(r.u.y),
      Math.abs(r.v.x), Math.abs(r.v.y), Math.abs(r.sum.x), Math.abs(r.sum.y)) : 10;
    const scale = Math.max(.5, Math.min((w - 76) / (2 * extent), (bottom - top - 30) / (2 * extent), 34));
    return { w, h, x: w / 2, y: (top + bottom) / 2, scale, top, bottom, chart };
  }
  function render(canvas, s, hover, showChart) {
    const box = canvas.getBoundingClientRect(), w = box.width, h = box.height;
    const dpr = Math.min(devicePixelRatio || 1, 2);
    if (canvas.width !== Math.round(w * dpr) || canvas.height !== Math.round(h * dpr)) {
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
    }
    const c = canvas.getContext('2d'); c.setTransform(dpr, 0, 0, dpr, 0, 0);
    const r = ForceVectors.calculate(s); geo = geometry(w, h, r, showChart); const g = geo;
    const pt = v => ({ x: g.x + v.x * g.scale, y: g.y - v.y * g.scale });
    const O = { x: g.x, y: g.y }, U = pt(r.u), V = pt(r.v), R = pt(r.sum);
    c.fillStyle = '#05070d'; c.fillRect(0, 0, w, h);
    if (w < 80 || h < 130) return { ...g, U, V, R };
    if (g.chart) {
      c.fillStyle = '#0b1019';
      c.beginPath(); c.roundRect(12, g.chart.y - 35, w - 24, g.chart.h + 60, 10); c.fill();
      c.strokeStyle = '#202a3a'; c.stroke();
    }
    function line(a, b, color, width = 1, dash = []) {
      c.beginPath(); c.setLineDash(dash); c.strokeStyle = color; c.lineWidth = width;
      c.moveTo(a.x, a.y); c.lineTo(b.x, b.y); c.stroke(); c.setLineDash([]);
    }
    function text(t, x, y, color = C.ink, size = 12, align = 'left') {
      c.font = `${size}px -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif`;
      c.fillStyle = color; c.textAlign = align; c.fillText(t, x, y);
    }
    function circle(x, y, radius, fill, stroke) {
      c.beginPath(); c.arc(x, y, radius, 0, Math.PI * 2); c.fillStyle = fill; c.fill();
      if (stroke) { c.strokeStyle = stroke; c.lineWidth = 1.5; c.stroke(); }
    }
    // 实验台细网格，明暗有层次，不干扰向量。
    c.save(); c.beginPath(); c.rect(20, g.top - 10, w - 40, g.bottom - g.top + 20); c.clip();
    for (let x = g.x % (g.scale * 2); x < w; x += g.scale * 2) line({ x, y: g.top - 10 }, { x, y: g.bottom + 10 }, '#72829b24');
    for (let y = g.y % (g.scale * 2); y < g.bottom + 10; y += g.scale * 2) line({ x: 20, y }, { x: w - 20, y }, '#72829b24');
    c.restore();
    // 坐标轴和刻度环帮助看清分力方向。
    const radius = Math.min(w / 2 - 25, (g.bottom - g.top) / 2 - 8);
    c.beginPath(); c.arc(g.x, g.y, radius, 0, Math.PI * 2); c.strokeStyle = '#72829b22'; c.lineWidth = 1; c.stroke();
    for (let i = 0; i < 360; i += 10) {
      const a = i * Math.PI / 180;
      line({ x: g.x + Math.cos(a) * radius, y: g.y - Math.sin(a) * radius },
        { x: g.x + Math.cos(a) * (radius - (i % 30 ? 3 : 7)), y: g.y - Math.sin(a) * (radius - (i % 30 ? 3 : 7)) }, '#72829b55');
    }
    line({ x: 28, y: g.y }, { x: w - 28, y: g.y }, '#72829b44');
    line({ x: g.x, y: g.top }, { x: g.x, y: g.bottom }, '#72829b44');
    text('+x', w - 29, g.y - 9, C.ink, 11, 'right'); text('+y', g.x + 9, g.top + 10, C.ink, 11);
    if (s.guide) {
      c.beginPath(); c.moveTo(O.x, O.y); c.lineTo(U.x, U.y); c.lineTo(R.x, R.y); c.lineTo(V.x, V.y); c.closePath();
      c.fillStyle = '#ffc94a09'; c.fill();
      line(U, R, C.two + '99', 1.3, [5, 5]); line(V, R, C.one + '99', 1.3, [5, 5]);
      if (s.scene === 'combine' && s.f1 > .1 && s.f2 > .1) {
        let delta = ((s.a2 - s.a1 + 540) % 360) - 180;
        const ar = Math.min(32, Math.min(s.f1, s.f2) * g.scale * .65);
        c.beginPath(); c.arc(g.x, g.y, ar, -s.a1 * Math.PI / 180, -(s.a1 + delta) * Math.PI / 180, delta > 0);
        c.strokeStyle = '#a5b1c388'; c.stroke();
      }
    }
    function arrow(a, b, color, width, shadow = true) {
      if (Math.hypot(b.x - a.x, b.y - a.y) < .1) return;
      const angle = Math.atan2(b.y - a.y, b.x - a.x);
      const n = Math.min(Math.hypot(b.x - a.x, b.y - a.y), width > 5 ? 14 : 9);
      const shaftEnd = { x: b.x - n * .75 * Math.cos(angle), y: b.y - n * .75 * Math.sin(angle) };
      if (shadow) line(a, shaftEnd, '#00000099', width + 4);
      line(a, shaftEnd, color, width);
      c.beginPath(); c.moveTo(b.x, b.y); c.lineTo(b.x - n * Math.cos(angle - .45), b.y - n * Math.sin(angle - .45));
      c.lineTo(b.x - n * Math.cos(angle + .45), b.y - n * Math.sin(angle + .45)); c.closePath(); c.fillStyle = color; c.fill();
    }
    // 合力与分力是两种等效描述，叠画便于比较。
    const sameRay = s.scene === 'combine' && s.f1 > 0 && s.f2 > 0 && r.theta < .001;
    arrow(O, R, C.sum, sameRay ? 7 : 4);
    arrow(O, U, C.one, sameRay ? 4.5 : 2.5, !sameRay);
    arrow(O, V, C.two, 2.5, !sameRay);
    function grip(P, color, id) {
      circle(P.x + 1, P.y + 3, 12, '#00000066');
      if (hover === id) circle(P.x, P.y, 20, color + '22', color + '66');
      circle(P.x, P.y, 10, '#111723', color); circle(P.x, P.y, 4, color);
      for (let i = -1; i <= 1; i++) line({ x: P.x - 3, y: P.y + i * 3 }, { x: P.x + 3, y: P.y + i * 3 }, '#111723', 1);
    }
    if (s.scene === 'combine') {
      grip(U, C.one, 'u');
      grip(V, C.two, 'v');
      if (sameRay && Math.hypot(U.x - V.x, U.y - V.y) < 1) {
        c.beginPath(); c.arc(U.x, U.y, 13, 0, Math.PI * 2);
        c.strokeStyle = C.one; c.lineWidth = 1.5; c.stroke();
      }
    } else grip(R, C.sum, 'sum');
    // 零矢量端点会与O重合，保留拖动命中，图外读数负责说明零值。
    circle(O.x, O.y, 7, '#0b0f17', '#a5b1c3'); circle(O.x, O.y, 2, '#d9e1ed');
    text('O', O.x - 14, O.y + 20, '#c9d2df', 12);
    const legendY = g.bottom + 23;
    text(s.scene === 'combine' ? `F₁ ${s.f1.toFixed(1)} N` : `Fₓ ${r.u.x.toFixed(2)} N`, 28, legendY, C.one);
    text(s.scene === 'combine' ? `F₂ ${s.f2.toFixed(1)} N` : `Fᵧ ${r.v.y.toFixed(2)} N`, 120, legendY, C.two);
    if (s.guide) text(s.scene === 'combine' ? '虚线 · 平行辅助线' : '虚线 · 投影辅助线', w - 28, legendY, '#a5b1c3', 11, 'right');
    // 保持F1/F2不变的夹角扫描曲线，或正交分量随方向变化。
    if (!g.chart) return { ...g, U, V, R };
    const q = g.chart, resolve = s.scene === 'resolve', maxY = resolve ? 10 : Math.max(10, Math.ceil((s.f1 + s.f2) / 5) * 5);
    text(resolve ? '分量随方向变化 / N' : '保持两力大小不变 · 合力 / N', q.x, q.y - 16, '#9aa6b8', 11);
    const chartPoint = (a, value) => ({ x: q.x + a / (resolve ? 360 : 180) * q.w, y: resolve ? q.y + q.h / 2 - value / 10 * q.h / 2 : q.y + q.h - value / maxY * q.h });
    [0, maxY / 2, maxY].forEach(value => {
      const y = resolve ? q.y + q.h - value / 10 * q.h : chartPoint(0, value).y;
      line({ x: q.x, y }, { x: q.x + q.w, y }, '#72829b26'); text(resolve ? String(value * 2 - 10) : String(value), q.x - 9, y + 4, '#8d99ab', 10, 'right');
    });
    function curve(fn, color) {
      c.beginPath(); for (let a = 0; a <= (resolve ? 360 : 180); a++) { const P = chartPoint(a, fn(a)); if (a === 0) c.moveTo(P.x, P.y); else c.lineTo(P.x, P.y); }
      c.strokeStyle = color; c.lineWidth = 2; c.stroke();
    }
    if (resolve) { curve(a => ForceVectors.vector(s.f, a - 180).x, C.one); curve(a => ForceVectors.vector(s.f, a - 180).y, C.two); }
    else curve(a => ForceVectors.magnitude(s.f1, s.f2, a), C.sum);
    const angle = resolve ? s.a + 180 : r.theta;
    const px = chartPoint(angle, 0).x; line({ x: px, y: q.y }, { x: px, y: q.y + q.h }, '#b4c0d477', 1, [3, 4]);
    if (resolve) { [r.u.x, r.v.y].forEach((v, i) => { const P = chartPoint(angle, v); circle(P.x, P.y, 4, i ? C.two : C.one); }); }
    else { const P = chartPoint(angle, r.f); circle(P.x, P.y, 4, C.sum); }
    [0, .5, 1].forEach(t => text(`${resolve ? t * 360 - 180 : t * 180}°`, q.x + t * q.w, q.y + q.h + 18, '#8d99ab', 10, 'center'));
    text(hover === 'chart' ? '拖动选择角度' : '点选或拖动', q.x + q.w, q.y - 16, '#8d99ab', 10, 'right');
    return { ...g, U, V, R };
  }
  window.ForceDraw = { render, geometry };
}());
