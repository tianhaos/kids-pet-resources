(function () {
  'use strict';
  const $ = id => document.getElementById(id), M = ForceVectors;
  const params = new URLSearchParams(location.search);
  const defaults = { scene: 'combine', f1: 5, f2: 5, a1: 0, a2: 120, f: 10, a: 30, guide: true };
  const state = { ...defaults, scene: params.get('scene') === 'resolve' ? 'resolve' : 'combine' };
  ['f1', 'f2', 'a1', 'a2', 'f', 'a'].forEach(key => {
    const raw = params.get(key), v = Number(raw);
    if (raw !== null && raw.trim() && Number.isFinite(v)) state[key] = M.clamp(v, key.startsWith('a') ? -180 : 0, key.startsWith('a') ? 180 : 10);
  });
  state.guide = params.get('guide') !== '0';
  const canvas = $('lab'); let geometry, dragging = null, hover = null, scanning = false, last = 0;
  const records = [];
  const track = (action, label = '') => window.Analytics && Analytics.track('力的合成与分解', action, String(label));
  const cleanAngle = a => ((a + 180) % 360 + 360) % 360 - 180;
  const fmt = v => (Math.abs(v) < .00001 ? 0 : v).toFixed(2);
  function update() {
    const r = M.calculate(state), resolve = state.scene === 'resolve';
    ['f1', 'f2', 'a1', 'a2', 'f', 'a'].forEach(key => { $(key).value = state[key]; $('o-' + key).textContent = state[key].toFixed(key.startsWith('a') ? 0 : 1); });
    $('combineControls').hidden = resolve; $('resolveControls').hidden = !resolve; $('presets').hidden = resolve;
    $('guide').checked = state.guide;
    document.querySelectorAll('[data-scene], [data-angle]').forEach(el => {
      const selected = el.dataset.scene ? el.dataset.scene === state.scene :
        state.f1 === 5 && state.f2 === 5 && Math.abs(r.theta - Number(el.dataset.angle)) < .001;
      el.classList.toggle('on', selected);
      el.setAttribute('aria-pressed', String(selected));
    });
    $('resultLabel').textContent = resolve ? '原力 F' : '合力 F';
    $('liveForce').textContent = `${fmt(r.f)} N`;
    $('angleLabel').textContent = resolve ? '方向 φ' : '两力夹角 θ';
    $('liveAngle').textContent = `${(resolve ? state.a : r.theta).toFixed(0)}°`;
    $('summary').textContent = resolve ? '沿 x、y 轴等效分解' : r.f === 0 ? '合力为零' : '合力是共同起点的对角线';
    $('name1').textContent = resolve ? 'x分量 Fₓ' : '分力 F₁'; $('name2').textContent = resolve ? 'y分量 Fᵧ' : '分力 F₂';
    $('read1').textContent = resolve ? `${fmt(r.u.x)} N` : `${fmt(state.f1)} N · ${state.a1.toFixed(0)}°`;
    $('read2').textContent = resolve ? `${fmt(r.v.y)} N` : `${fmt(state.f2)} N · ${state.a2.toFixed(0)}°`;
    $('directionLabel').textContent = resolve ? '原力方向' : '合力方向';
    $('direction').textContent = r.a === null ? '无确定方向' : `${fmt(r.a)}°（从+x轴逆时针）`;
    $('meaning').textContent = resolve ? '负分量表示沿对应坐标轴负向。原力与两个分力是等效描述。' : `合力范围 ${fmt(Math.abs(state.f1 - state.f2))}～${fmt(state.f1 + state.f2)} N（保持两力大小不变）。`;
    $('instruction').textContent = resolve ? '拖动金色端点，看两个分量的大小和正负变化' : '拖动蓝色或珊瑚色端点，改变力的大小与方向';
    $('guideLabel').textContent = resolve ? '显示投影辅助线' : '显示平行辅助线与夹角';
    $('sweep').textContent = scanning ? '暂停扫描' : '扫描角度'; $('sweep').classList.toggle('on', scanning);
  }
  function setScene(scene) { scanning = false; state.scene = scene === 'resolve' ? 'resolve' : 'combine'; update(); }
  document.querySelectorAll('[data-scene]').forEach(el => el.onclick = () => { setScene(el.dataset.scene); track('切换场景', state.scene); });
  ['f1', 'f2', 'a1', 'a2', 'f', 'a'].forEach(key => {
    $(key).oninput = () => { scanning = false; state[key] = Number($(key).value); update(); };
    $(key).onchange = () => track('调整参数', key);
  });
  document.querySelectorAll('[data-angle]').forEach(el => el.onclick = () => {
    scanning = false; Object.assign(state, { f1: 5, f2: 5, a1: 0, a2: Number(el.dataset.angle) }); update(); track('典型夹角', state.a2);
  });
  $('guide').onchange = () => { state.guide = $('guide').checked; track('辅助线', state.guide); };
  $('sweep').onclick = () => { scanning = !scanning; if (scanning) { if (state.scene === 'combine') { state.a1 = 0; state.a2 = 0; } else state.a = -180; } update(); track('扫描角度', scanning); };
  $('reset').onclick = () => { scanning = false; Object.assign(state, defaults, { scene: state.scene }); update(); track('复位'); };
  function position(e) { const b = canvas.getBoundingClientRect(); return { x: e.clientX - b.left, y: e.clientY - b.top }; }
  function hit(p) {
    if (!geometry) return null;
    const q = geometry.chart;
    if (q && p.x >= q.x - 15 && p.x <= q.x + q.w + 15 && p.y >= q.y - 8 && p.y <= q.y + q.h + 24) return 'chart';
    const ids = state.scene === 'combine' ? [['u', geometry.U], ['v', geometry.V]] : [['sum', geometry.R]];
    let nearest = null, dist = 30;
    ids.forEach(([id, v]) => { const d = Math.hypot(p.x - v.x, p.y - v.y); if (d < dist) { nearest = id; dist = d; } });
    return nearest;
  }
  function move(p) {
    if (dragging === 'chart') {
      if (!geometry.chart) return;
      const fraction = M.clamp((p.x - geometry.chart.x) / geometry.chart.w, 0, 1);
      if (state.scene === 'combine') state.a2 = cleanAngle(state.a1 + fraction * 180); else state.a = fraction * 360 - 180;
    } else {
      const v = { x: (p.x - geometry.x) / geometry.scale, y: (geometry.y - p.y) / geometry.scale }, polar = M.polar(v);
      const f = Math.round(M.clamp(polar.f, 0, 10) * 10) / 10, a = Math.round(polar.a === null ? 0 : polar.a);
      if (dragging === 'u') { state.f1 = f; state.a1 = a; }
      if (dragging === 'v') { state.f2 = f; state.a2 = a; }
      if (dragging === 'sum') { state.f = f; state.a = a; }
    }
    update();
  }
  canvas.onpointerdown = e => { const p = position(e); dragging = hit(p); if (!dragging) return; e.preventDefault(); scanning = false; canvas.setPointerCapture(e.pointerId); if (dragging === 'chart') move(p); else update(); };
  canvas.onpointerleave = () => { if (!dragging) hover = null; };
  canvas.onpointermove = e => { const p = position(e); hover = dragging || hit(p); canvas.style.cursor = hover ? dragging ? 'grabbing' : 'grab' : 'crosshair'; if (dragging) move(p); };
  function end(e) { if (!dragging) return; track('画面拖动', dragging); dragging = null; if (canvas.hasPointerCapture(e.pointerId)) canvas.releasePointerCapture(e.pointerId); }
  canvas.onpointerup = end; canvas.onpointercancel = end; canvas.onlostpointercapture = () => { dragging = null; };
  const mobile = matchMedia('(max-width:760px)');
  let panelOpen;
  function setPanel(open) {
    panelOpen = open;
    $('app').classList.toggle('parameters-open', mobile.matches && open);
    $('panel').classList.toggle('collapsed', !open);
    $('panelToggle').setAttribute('aria-expanded', String(open));
    $('panelToggle').textContent = open ? '收起参数' : '调节参数';
  }
  mobile.addEventListener('change', () => setPanel(!mobile.matches));
  setPanel(!mobile.matches);
  $('panelToggle').onclick = () => setPanel($('panel').classList.contains('collapsed'));
  document.querySelector('.stage-foot a').addEventListener('click', () => { if (mobile.matches) setPanel(false); });
  $('record').onclick = () => {
    const r = M.calculate(state);
    const row = state.scene === 'combine' ? `${state.f1.toFixed(1)} N + ${state.f2.toFixed(1)} N，θ=${r.theta.toFixed(0)}° → ${fmt(r.f)} N` : `${fmt(r.f)} N，φ=${state.a.toFixed(0)}° → (${fmt(r.u.x)}, ${fmt(r.v.y)}) N`;
    records.unshift(row); records.splice(6); $('records').replaceChildren(...records.map((t, i) => { const d = document.createElement('div'); d.textContent = `${i + 1}. ${t}`; return d; })); track('记录', state.scene);
  };
  $('clear').onclick = () => { records.length = 0; $('records').replaceChildren(); };
  function shareURL() {
    const u = new URL(location.href); u.hash = ''; u.search = '';
    ['scene', 'f1', 'f2', 'a1', 'a2', 'f', 'a'].forEach(key => u.searchParams.set(key, typeof state[key] === 'number' ? String(Math.round(state[key] * 1000) / 1000) : state[key]));
    u.searchParams.set('guide', state.guide ? '1' : '0'); return u.href;
  }
  $('share').onclick = async () => { scanning = false; update(); const url = shareURL(); try { await navigator.clipboard.writeText(url); $('shareNote').textContent = '已复制当前条件，打开后保持此状态。'; } catch { $('shareNote').textContent = url; } track('分享', state.scene); };
  function frame(t) {
    const dt = Math.min((t - last) / 1000 || 0, .05); last = t;
    if (scanning) {
      if (state.scene === 'combine') { state.a2 = Math.min(180, state.a2 + dt * 25); if (state.a2 >= 180) scanning = false; }
      else { state.a = Math.min(180, state.a + dt * 40); if (state.a >= 180) scanning = false; }
      update();
    }
    geometry = ForceDraw.render(canvas, state, hover, !(mobile.matches && panelOpen)); requestAnimationFrame(frame);
  }
  window.__model = { state, update, setScene, shareURL, get geometry() { return geometry; }, scan: () => $('sweep').click() };
  update(); requestAnimationFrame(frame);
}());
