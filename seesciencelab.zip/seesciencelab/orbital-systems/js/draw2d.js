// 星下点轨迹与双星半径对照；所有文字原生绘制，保持宽高比。
(function () {
  'use strict';
  function create(canvas) {
    var ctx = canvas.getContext('2d'), w = 0, h = 0, ratio = 1;
    function text(str, x, y, color, align) {
      ctx.fillStyle = color || '#8da7bf'; ctx.textAlign = align || 'left'; ctx.fillText(str, x, y);
    }
    function path(arr, color, width) {
      ctx.strokeStyle = color; ctx.lineWidth = width || 1; ctx.beginPath();
      arr.forEach(function (p, i) { if (i) ctx.lineTo(p[0], p[1]); else ctx.moveTo(p[0], p[1]); }); ctx.stroke();
    }
    function dot(x, y, color, radius) {
      ctx.fillStyle = color; ctx.beginPath(); ctx.arc(x, y, radius || 3.5, 0, Math.PI * 2); ctx.fill();
    }
    function draw(state, result) {
      var rect = canvas.getBoundingClientRect(), dpr = Math.min(devicePixelRatio, 2);
      if (rect.width !== w || rect.height !== h || ratio !== dpr) {
        w = rect.width; h = rect.height; ratio = dpr; canvas.width = Math.round(w * ratio); canvas.height = Math.round(h * ratio);
      }
      ctx.setTransform(ratio, 0, 0, ratio, 0, 0); ctx.clearRect(0, 0, w, h);
      ctx.font = '10px -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif';
      if (state.scene === 'sync') {
        var left = 35, right = w - 14, top = 16, bottom = h - 22;
        function xy(lon, lat) { return [left + (lon + 180) / 360 * (right - left), bottom - (lat + 90) / 180 * (bottom - top)]; }
        [-90, 0, 90].forEach(function (lat) { var a = xy(-180, lat), b = xy(180, lat); path([a, b], lat === 0 ? '#3e586d' : '#1f3142'); text(lat + '°', left - 5, a[1] + 3, null, 'right'); });
        [-180, -90, 0, 90, 180].forEach(function (lon) { var a = xy(lon, -90), b = xy(lon, 90); path([a, b], '#1f3142'); text(lon + '°', a[0], h - 6, null, 'center'); });
        var arr = [], last = null;
        // 淡色完整参考轨迹总是显示两个恒星日，亮点表示当前状态。
        for (var i = 0; i <= 720; i++) {
          var p = Orbital.satellite(state.height, state.inclination, state.retro, i / 720 * 2 * Orbital.DAY);
          if (last !== null && Math.abs(p.longitude - last) > 180) { path(arr, '#3986a5', 1.3); arr = []; }
          arr.push(xy(p.longitude, p.latitude)); last = p.longitude;
        }
        path(arr, '#3986a5', 1.3);
        var start = xy(0, 0), current = xy(result.longitude, result.latitude);
        dot(start[0], start[1], '#ffc94a', 4.5); dot(current[0], current[1], '#8de6ff', 3);
        text('淡线：两个恒星日参考轨迹', w - 14, 11, '#6c879f', 'right');
      } else {
        var leftX = 25, rightX = w - 25, y = 38, span = rightX - leftX;
        var centerX = leftX + result.r1 / (result.r1 + result.r2) * span;
        path([[leftX, y], [rightX, y]], '#586a81', 1.5);
        path([[centerX, y - 15], [centerX, y + 15]], '#c5d2e2');
        dot(leftX, y, '#ffc94a', 7); dot(rightX, y, '#78dfff', 7);
        text('m₁', leftX, 17, '#ffc94a', 'center'); text('m₂', rightX, 17, '#78dfff', 'center');
        text('质心', centerX, 17, '#dce5ef', 'center');
        text('r₁ = ' + (result.r1 / Orbital.AU).toFixed(3) + ' AU', (leftX + centerX) / 2, 65, '#ffc94a', 'center');
        text('r₂ = ' + (result.r2 / Orbital.AU).toFixed(3) + ' AU', (rightX + centerX) / 2, 65, '#78dfff', 'center');
        text('d = r₁ + r₂ = ' + state.distance.toFixed(1) + ' AU', w / 2, h - 5, '#a4b9cc', 'center');
      }
    }
    return { draw: draw };
  }
  window.OrbitalDraw = { create: create };
}());
