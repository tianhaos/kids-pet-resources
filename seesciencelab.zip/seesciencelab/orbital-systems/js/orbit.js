// 圆轨道的纯计算：长度 km、时间 s；双星界面输入 AU、M☉。
(function () {
  'use strict';
  var MU = 398600.4418, R = 6378.137, DAY = 86164.0905;
  var G = 6.67430e-20, SUN = 1.98847e30, AU = 149597870.7;
  var TAU = Math.PI * 2;
  function wrap(a) { return ((a + 180) % 360 + 360) % 360 - 180; }
  function geoHeight() { return Math.cbrt(MU * Math.pow(DAY / TAU, 2)) - R; }
  function period(radius, mu) { return TAU * Math.sqrt(radius * radius * radius / mu); }
  // 右手坐标，y为北极轴；正向从+x朝-z，即北极俯视逆时针。
  function satellite(height, inclination, retro, time) {
    var radius = R + height, T = period(radius, MU), inc = inclination * Math.PI / 180;
    var a = TAU * time / T * (retro ? -1 : 1), spin = TAU * time / DAY;
    var x = Math.cos(a), y = Math.sin(a) * Math.sin(inc), z = -Math.sin(a) * Math.cos(inc);
    var lon = wrap(Math.atan2(-z, x) * 180 / Math.PI - spin * 180 / Math.PI);
    return { radius: radius, period: T, speed: Math.sqrt(MU / radius), angle: a, spin: spin,
      x: x * radius / R, y: y * radius / R, z: z * radius / R,
      latitude: Math.asin(y) * 180 / Math.PI, longitude: lon,
      stationary: Math.abs(T - DAY) < 1 && inclination === 0 && !retro };
  }
  function binary(m1, m2, distance, time) {
    var d = distance * AU, mu = G * SUN * (m1 + m2), T = period(d, mu);
    var r1 = d * m2 / (m1 + m2), r2 = d * m1 / (m1 + m2), a = TAU * time / T;
    return { period: T, r1: r1, r2: r2, v1: TAU * r1 / T, v2: TAU * r2 / T,
      angle: a, x1: r1 * Math.cos(a), z1: -r1 * Math.sin(a),
      x2: -r2 * Math.cos(a), z2: r2 * Math.sin(a), force: 6.67430e-11 * m1 * SUN * m2 * SUN / Math.pow(d * 1000, 2) };
  }
  window.Orbital = { MU: MU, R: R, DAY: DAY, AU: AU, SUN: SUN, G: G, TAU: TAU,
    wrap: wrap, period: period, geoHeight: geoHeight, satellite: satellite, binary: binary };
}());
