// 三维场景：地球半径=1；双星场景1 AU=4个绘图单位。
(function () {
  'use strict';
  function create(host, onSelect) {
    var scene = new THREE.Scene();
    var camera = new THREE.PerspectiveCamera(34, 1, .05, 300);
    var renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
    renderer.outputEncoding = THREE.sRGBEncoding;
    host.prepend(renderer.domElement);
    var controls = new THREE.OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.minDistance = 4;
    controls.maxDistance = 65;
    controls.enablePan = false;
    scene.add(new THREE.AmbientLight(0xadc9ec, .65));
    var light = new THREE.DirectionalLight(0xffefcf, .95);
    light.position.set(6, 9, 12); scene.add(light);
    var sync = new THREE.Group(), stars = new THREE.Group();
    scene.add(sync, stars);
    function material(color, emissive) {
      return new THREE.MeshPhongMaterial({ color: color, emissive: emissive || 0x000000, shininess: 25 });
    }
    function sphere(radius, mat, group) {
      var o = new THREE.Mesh(new THREE.SphereGeometry(radius, 48, 32), mat);
      group.add(o); return o;
    }
    function line(color, group, dashed) {
      var mat = dashed ? new THREE.LineDashedMaterial({ color: color, dashSize: .12, gapSize: .09, transparent: true, opacity: .7 }) : new THREE.LineBasicMaterial({ color: color, transparent: true, opacity: .65 });
      var o = new THREE.Line(new THREE.BufferGeometry(), mat); group.add(o); return o;
    }
    function points(o, arr) {
      o.geometry.dispose(); o.geometry = new THREE.BufferGeometry().setFromPoints(arr);
      if (o.material.isLineDashedMaterial) o.computeLineDistances();
    }
    function circle(o, radius, inclination) {
      var arr = [], inc = inclination * Math.PI / 180;
      for (var k = 0; k <= 180; k++) {
        var a = k / 180 * Math.PI * 2;
        arr.push(new THREE.Vector3(radius * Math.cos(a), radius * Math.sin(a) * Math.sin(inc), -radius * Math.sin(a) * Math.cos(inc)));
      }
      points(o, arr);
    }
    var earth = sphere(1, material(0xffffff), sync);
    earth.material.map = new THREE.CanvasTexture(window.makeEarthCanvas());
    earth.material.map.encoding = THREE.sRGBEncoding;
    var grid = new THREE.Group(); earth.add(grid);
    // 赤道与经线随地球自转，帮助识别相对地面是否静止。
    for (var meridian = 0; meridian < 6; meridian++) {
      var l = line(0xadc3da, grid), ar = [];
      for (var k = 0; k <= 100; k++) {
        var b = k / 100 * Math.PI * 2, c = meridian / 6 * Math.PI;
        ar.push(new THREE.Vector3(1.006 * Math.cos(b) * Math.cos(c), 1.006 * Math.sin(b), 1.006 * Math.cos(b) * Math.sin(c)));
      }
      points(l, ar); l.material.opacity = .22;
    }
    var equator = line(0xffc94a, earth); circle(equator, 1.012, 0);
    var axis = line(0x9eb6cf, sync, true);
    points(axis, [new THREE.Vector3(0, -1.65, 0), new THREE.Vector3(0, 1.8, 0)]);
    var ground = sphere(.075, new THREE.MeshBasicMaterial({ color: 0xffc94a }), earth);
    ground.position.x = 1.025;
    var satellite = new THREE.Group(); sync.add(satellite);
    var body = new THREE.Mesh(new THREE.BoxGeometry(.22, .24, .22), material(0xe6d1a0));
    satellite.add(body);
    var panelMaterial = material(0x247fbb, 0x092438);
    [-1, 1].forEach(function (side) {
      var wing = new THREE.Mesh(new THREE.BoxGeometry(.36, .02, .34), panelMaterial);
      wing.position.x = side * .34; satellite.add(wing);
      // 电池片分格保持为几何细节，不使用文字贴图。
      for (var i = 0; i < 3; i++) {
        var divider = new THREE.Mesh(new THREE.BoxGeometry(.008, .025, .34), material(0x89b6c9));
        divider.position.x = side * .34 + (i - 1) * .1; satellite.add(divider);
      }
    });
    var dish = new THREE.Mesh(new THREE.SphereGeometry(.13, 20, 12, 0, Math.PI * 2, 0, Math.PI / 2), material(0xf5e3b1));
    dish.position.y = .17; satellite.add(dish);
    var orbit = line(0x67d6f5, sync), projection = line(0x67d6f5, sync, true);
    var subpoint = sphere(.05, new THREE.MeshBasicMaterial({ color: 0x68e4ff }), sync);
    var aStar = sphere(.36, material(0xffb938, 0x473008), stars);
    var bStar = sphere(.29, material(0x5acaff, 0x0a253b), stars);
    // 稀疏的同心线强调球体的曲面，恒星外观不参与质量计算。
    [aStar, bStar].forEach(function (star) {
      var wire = new THREE.Mesh(star.geometry, new THREE.MeshBasicMaterial({ color: 0xffffff, wireframe: true, transparent: true, opacity: .035 }));
      wire.scale.setScalar(1.005); star.add(wire);
    });
    var aOrbit = line(0xffc94a, stars), bOrbit = line(0x68dfff, stars);
    var connector = line(0xb1c4dc, stars, true);
    var center = new THREE.Group(); stars.add(center);
    [0, 1, 2].forEach(function (i) {
      var cross = line(0xe7eaf4, center), arr = [new THREE.Vector3(), new THREE.Vector3()];
      arr[0].setComponent(i, -.12); arr[1].setComponent(i, .12); points(cross, arr);
    });
    var down = null, lastMode, lastGeometry = '', width = 0, height = 0, reach = 7.5, scaleKey = '', tilted = false;
    var picks = [];
    renderer.domElement.addEventListener('pointerdown', function (e) { down = { x: e.clientX, y: e.clientY }; });
    renderer.domElement.addEventListener('pointerup', function (e) {
      if (!down || Math.hypot(e.clientX - down.x, e.clientY - down.y) > 8) { down = null; return; }
      var hit = hitTest(e); if (hit) onSelect(hit); down = null;
    });
    renderer.domElement.addEventListener('pointermove', function (e) {
      renderer.domElement.style.cursor = hitTest(e) ? 'pointer' : 'grab';
    });
    function hitTest(e) {
      var rect = renderer.domElement.getBoundingClientRect();
      // 扩大点选范围，保证放大的卫星与小天体在触摸设备上可选。
      var best = null, distance = Infinity;
      picks.forEach(function (entry) {
        var p = entry.object.getWorldPosition(new THREE.Vector3()).project(camera);
        var dx = (p.x + 1) * rect.width / 2 - (e.clientX - rect.left), dy = (1 - p.y) * rect.height / 2 - (e.clientY - rect.top);
        var dd = Math.hypot(dx, dy);
        if (dd < 24 && dd < distance) { best = entry.id; distance = dd; }
      });
      return best;
    }
    function reset(mode, top) {
      var direction = top ? new THREE.Vector3(0, 1, .0001) : new THREE.Vector3(.32, .58, .75).normalize();
      var distance = reach / Math.sin(camera.fov * Math.PI / 360) / Math.min(camera.aspect, 1) * 1.12;
      // 赤道圆轨道按实际投影适配；倾斜轨道保留包围球余量，地球参考系旋转也不裁切。
      if (!tilted || top) {
        for (var iteration = 0; iteration < 6; iteration++) {
          camera.position.copy(direction).multiplyScalar(distance); camera.lookAt(0, 0, 0); camera.updateMatrixWorld();
          var boundX = 0, boundY = 0;
          for (var i = 0; i < 120; i++) {
            var a = i / 120 * Math.PI * 2;
            var p = new THREE.Vector3(reach * Math.cos(a), 0, reach * Math.sin(a)).project(camera);
            boundX = Math.max(boundX, Math.abs(p.x)); boundY = Math.max(boundY, Math.abs(p.y));
          }
          distance *= Math.max(boundX / .87, boundY / .84);
        }
      }
      camera.position.copy(direction).multiplyScalar(Math.max(4, distance));
      controls.target.set(0, 0, 0); controls.update();
      controls.saveState();
    }
    function label(id, object, text, color) {
      var el = document.getElementById(id), world = object.getWorldPosition(new THREE.Vector3()), p = world.clone().project(camera);
      var radius = object.geometry && object.geometry.parameters.radius || 0;
      var offset = 8 + radius / world.distanceTo(camera.position) * height / (2 * Math.tan(camera.fov * Math.PI / 360));
      el.textContent = text; el.style.color = color || '#d8e5f2';
      el.style.left = Math.max(3, Math.min(width - el.offsetWidth - 3, (p.x + 1) * width / 2 + offset)) + 'px';
      el.style.top = Math.max(0, Math.min(height - 20, (1 - p.y) * height / 2 - 20)) + 'px';
      el.hidden = p.z > 1 || p.z < -1;
    }
    function update(state, result) {
      var nextScale = [state.scene, state.height, state.inclination, state.mass1, state.mass2, state.distance].join('|');
      tilted = state.scene === 'sync' && state.inclination > 0;
      reach = state.scene === 'sync' ? result.radius / Orbital.R * 1.1 : Math.max(2, Math.max(result.r1, result.r2) / Orbital.AU * 4 * 1.12);
      var w = host.clientWidth, h = host.clientHeight;
      if (width !== w || height !== h) {
        width = w; height = h; renderer.setSize(w, h); camera.aspect = w / Math.max(h, 1); camera.updateProjectionMatrix();
        reset(state.scene);
      }
      if (lastMode !== state.scene || scaleKey !== nextScale) { reset(state.scene); lastMode = state.scene; scaleKey = nextScale; }
      sync.visible = state.scene === 'sync'; stars.visible = !sync.visible;
      var key = [state.scene, state.height, state.inclination, state.mass1, state.mass2, state.distance].join('|');
      if (key !== lastGeometry) {
        if (sync.visible) circle(orbit, result.radius / Orbital.R, state.inclination);
        else { circle(aOrbit, result.r1 / Orbital.AU * 4, 0); circle(bOrbit, result.r2 / Orbital.AU * 4, 0); }
        lastGeometry = key;
      }
      if (sync.visible) {
        sync.rotation.y = state.earthFrame ? -result.spin : 0;
        earth.rotation.y = result.spin;
        satellite.position.set(result.x, result.y, result.z);
        satellite.rotation.y = result.angle;
        subpoint.position.copy(satellite.position).normalize().multiplyScalar(1.035);
        points(projection, [new THREE.Vector3(), satellite.position.clone()]);
        picks = [{ object: satellite, id: 'satellite' }, { object: earth, id: 'earth' }];
      } else {
        aStar.position.set(result.x1 / Orbital.AU * 4, 0, result.z1 / Orbital.AU * 4);
        bStar.position.set(result.x2 / Orbital.AU * 4, 0, result.z2 / Orbital.AU * 4);
        points(connector, [aStar.position.clone(), bStar.position.clone()]);
        picks = [{ object: aStar, id: 'star1' }, { object: bStar, id: 'star2' }, { object: center, id: 'center' }];
      }
      controls.update(); scene.updateMatrixWorld(); camera.updateMatrixWorld();
      if (sync.visible) {
        label('labelA', satellite, '卫星 · ' + (result.period / 3600).toFixed(2) + ' h', '#86dfff');
        label('labelB', earth, '地球', '#bdd8ee');
        label('labelC', ground, '地面标记', '#ffc94a');
        var groundWorld = ground.getWorldPosition(new THREE.Vector3());
        if (groundWorld.dot(camera.position) <= groundWorld.lengthSq()) document.getElementById('labelC').hidden = true;
      } else {
        label('labelA', aStar, 'm₁ · ' + state.mass1.toFixed(1) + ' M☉', '#ffc94a');
        label('labelB', bStar, 'm₂ · ' + state.mass2.toFixed(1) + ' M☉', '#86dfff');
        label('labelC', center, '共同质心', '#d9e4f2');
      }
      // 先排天体标签，再排质心/地面标签；小轨道和极端质量比也不互相覆盖。
      var placed = [];
      if (!sync.visible) [aStar, bStar].forEach(function (star) {
        var wp = star.getWorldPosition(new THREE.Vector3()), p = wp.clone().project(camera);
        var rp = star.geometry.parameters.radius / wp.distanceTo(camera.position) * height / (2 * Math.tan(camera.fov * Math.PI / 360));
        placed.push({ x: (p.x + 1) * width / 2 - rp, y: (1 - p.y) * height / 2 - rp, w: rp * 2, h: rp * 2 });
      });
      ['labelA', 'labelB', 'labelC'].forEach(function (id) {
        var el = document.getElementById(id);
        if (el.hidden) return;
        var x = el.offsetLeft, y = el.offsetTop, ew = el.offsetWidth, eh = el.offsetHeight;
        placed.forEach(function (box) {
          if (x < box.x + box.w + 4 && x + ew + 4 > box.x && y < box.y + box.h + 4 && y + eh + 4 > box.y) {
            y = box.y + box.h + 5;
            if (y + eh > height) y = box.y - eh - 5;
          }
        });
        el.style.top = y + 'px'; placed.push({ x: x, y: y, w: ew, h: eh });
      });
      renderer.render(scene, camera);
    }
    return { update: update, reset: reset, camera: camera, controls: controls, renderer: renderer,
      screenPoint: function (id) {
        var item = picks.find(function (entry) { return entry.id === id; });
        if (!item) return null;
        var p = item.object.getWorldPosition(new THREE.Vector3()).project(camera), rect = host.getBoundingClientRect();
        return { x: rect.left + (p.x + 1) * width / 2, y: rect.top + (1 - p.y) * height / 2 };
      } };
  }
  window.OrbitalScene = { create: create };
}());
