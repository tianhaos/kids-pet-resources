// 状态、URL、交互与逐帧更新。卫星时间为小时，双星时间为周期份额。
(function () {
  'use strict';
  var O = window.Orbital, query = new URLSearchParams(location.search);
  var $ = function (id) { return document.getElementById(id); };
  function num(key, fallback, min, max) {
    var n = query.has(key) ? Number(query.get(key)) : fallback;
    return Number.isFinite(n) ? Math.max(min, Math.min(max, n)) : fallback;
  }
  var state = {
    scene: query.get('scene') === 'binary' ? 'binary' : 'sync',
    height: num('height', O.geoHeight(), 400, 50000), inclination: num('inc', 0, 0, 80),
    retro: query.get('retro') === '1', earthFrame: query.get('frame') === 'earth',
    mass1: num('m1', 3, .5, 5), mass2: num('m2', 1, .5, 5), distance: num('d', 1, .5, 3),
    t: num('t', 0, 0, query.get('scene') === 'binary' ? 2 : 48),
    playing: query.has('play') ? query.get('play') !== '0' : !matchMedia('(prefers-reduced-motion: reduce)').matches,
    selected: ''
  };
  function track(action, label) {
    if (window.Analytics) Analytics.track('同步卫星与双星系统', action, String(label || ''));
  }
  var scene = OrbitalScene.create($('viewer'), function (id) { state.selected = id; track('点选天体', id); });
  var diagram = OrbitalDraw.create($('diagram')), result, last = performance.now(), finish = false;
  function calculate() {
    if (state.scene === 'sync') return O.satellite(state.height, state.inclination, state.retro, state.t * 3600);
    var b = O.binary(state.mass1, state.mass2, state.distance, 0);
    return O.binary(state.mass1, state.mass2, state.distance, b.period * state.t);
  }
  function updateControls() {
    ['height', 'mass1', 'mass2', 'distance'].forEach(function (key) { $(key).value = state[key]; });
    $('inclination').value = state.inclination;
    $('heightOut').textContent = Math.round(state.height).toLocaleString('en-US') + ' km';
    $('inclinationOut').textContent = state.inclination.toFixed(0) + '°';
    $('mass1Out').textContent = state.mass1.toFixed(1) + ' M☉';
    $('mass2Out').textContent = state.mass2.toFixed(1) + ' M☉';
    $('distanceOut').textContent = state.distance.toFixed(1) + ' AU';
    $('retro').checked = state.retro; $('earthFrame').checked = state.earthFrame;
    $('earthFrame').disabled = state.scene !== 'sync';
    $('syncControls').hidden = state.scene !== 'sync'; $('binaryControls').hidden = state.scene !== 'binary';
    $('time').max = state.scene === 'sync' ? 48 : 2;
    $('time').step = state.scene === 'sync' ? '.01' : '.001';
    document.querySelectorAll('[data-scene]').forEach(function (el) { el.classList.toggle('on', el.dataset.scene === state.scene); });
    document.querySelectorAll('[data-preset]').forEach(function (el) { el.classList.toggle('on',
      (el.dataset.preset === 'geo' && Math.abs(state.height - O.geoHeight()) < 1 && state.inclination === 0 && !state.retro) ||
      (el.dataset.preset === 'tilted' && Math.abs(state.height - O.geoHeight()) < 1 && state.inclination === 35 && !state.retro) ||
      (el.dataset.preset === 'low' && state.height === 800 && state.inclination === 0 && !state.retro) ||
      (el.dataset.preset === 'retro' && Math.abs(state.height - O.geoHeight()) < 1 && state.inclination === 0 && state.retro)); });
    $('sceneTitle').textContent = state.scene === 'sync' ? '跟着地球一起转' : '两颗星，绕着同一个中心';
    $('sceneDesc').textContent = state.scene === 'sync' ? '金色地面标记 · 浅蓝星下点 · 改条件看它们是否对齐' : '质量大的星轨道更小 · 两星周期、角速度相同';
    $('chartTitle').textContent = state.scene === 'sync' ? '星下点 · 相对起点经度' : '沿两星连线展开 · 半径按比例';
    $('speedNote').textContent = state.scene === 'sync' ? '播放：1秒约代表1.5小时。48小时后暂停，可拖动回看。' : '播放：12秒代表一个轨道周期。两圈后暂停，可拖动回看。';
  }
  var lastReadout = '';
  function readings() {
    var rows;
    if (state.scene === 'sync') {
      var syncPeriod = Math.abs(result.period - O.DAY) < 1;
      $('status').textContent = result.stationary ? '地球静止轨道' : syncPeriod ? '周期相同，位置仍在变' : '周期不同，相对地面移动';
      $('stageRead').textContent = result.stationary ? '赤道上空固定' : '纬度 ' + result.latitude.toFixed(1) + '° · 经度 ' + result.longitude.toFixed(1) + '°';
      rows = [['轨道半径 r', result.radius.toFixed(0) + ' km'], ['周期 T', (result.period / 3600).toFixed(3) + ' h'], ['地球自转周期', (O.DAY / 3600).toFixed(3) + ' h'], ['圆轨道速率', result.speed.toFixed(3) + ' km/s'], ['星下点纬度', result.latitude.toFixed(2) + '°'], ['相对起点经度', result.longitude.toFixed(2) + '°']];
      $('selected').textContent = state.selected === 'earth' ? '地球：金点随地面转，浅蓝点是卫星的地心投影。' : state.selected === 'satellite' ? '卫星：空间速度不为零；相对地面静止需要全部条件同时满足。' : '点选地球或卫星，探查它们的运动。';
    } else {
      $('status').textContent = '共同质心保持不动';
      $('stageRead').textContent = 'r₁∶r₂ = m₂∶m₁ = ' + (state.mass2 / state.mass1).toFixed(3);
      rows = [['共同周期 T', (result.period / 86400).toFixed(2) + ' 天'], ['共同角速度 ω', (O.TAU / result.period * 1e7).toFixed(3) + ' ×10⁻⁷ rad/s'], ['星1速率 v₁', result.v1.toFixed(2) + ' km/s'], ['星2速率 v₂', result.v2.toFixed(2) + ' km/s'], ['m₁r₁ = m₂r₂', (state.mass1 * result.r1 / O.AU).toFixed(3) + ' M☉·AU'], ['相互引力大小', result.force.toExponential(3) + ' N']];
      var messages = { star1: '星1：质量 ' + state.mass1.toFixed(1) + ' M☉；半径 ' + (result.r1 / O.AU).toFixed(3) + ' AU。', star2: '星2：质量 ' + state.mass2.toFixed(1) + ' M☉；半径 ' + (result.r2 / O.AU).toFixed(3) + ' AU。', center: '质心：满足 m₁r₁=m₂r₂，不是固定在某颗星中心。' };
      $('selected').textContent = messages[state.selected] || '点选两颗星或质心，对比质量与轨道半径。';
    }
    var markup = rows.map(function (r) { return '<dt>' + r[0] + '</dt><dd>' + r[1] + '</dd>'; }).join('');
    if (markup !== lastReadout) { $('readings').innerHTML = markup; lastReadout = markup; }
    $('time').value = state.t;
    $('timeOut').textContent = state.scene === 'sync' ? state.t.toFixed(2) + ' h' : state.t.toFixed(3) + ' 圈';
    $('stagePlay').textContent = $('play').textContent = state.playing ? '暂停' : finish ? '重新播放' : '播放';
  }
  function render() { result = calculate(); scene.update(state, result); diagram.draw(state, result); readings(); }
  function restart() { state.t = 0; finish = false; state.selected = ''; updateControls(); render(); }
  function setScene(value) { state.scene = value === 'binary' ? 'binary' : 'sync'; restart(); track('切换场景', state.scene); }
  function preset(value) {
    state.height = value === 'low' ? 800 : O.geoHeight(); state.inclination = value === 'tilted' ? 35 : 0;
    state.retro = value === 'retro'; restart(); track('轨道对照', value);
  }
  function toggle() {
    if (finish) restart(); state.playing = !state.playing; track('播放暂停', state.playing); render();
  }
  document.querySelectorAll('[data-scene]').forEach(function (el) { el.onclick = function () { setScene(el.dataset.scene); }; });
  document.querySelectorAll('[data-preset]').forEach(function (el) { el.onclick = function () { preset(el.dataset.preset); }; });
  ['height', 'inclination', 'mass1', 'mass2', 'distance'].forEach(function (key) {
    $(key).addEventListener('input', function () { state[key] = Number(this.value); restart(); });
    $(key).addEventListener('change', function () { track('改变参数', key + '=' + state[key]); });
  });
  $('retro').onchange = function () { state.retro = this.checked; restart(); track('反向绕行', state.retro); };
  $('earthFrame').onchange = function () { state.earthFrame = this.checked; track('参考系', state.earthFrame ? 'earth' : 'space'); render(); };
  $('time').oninput = function () { state.t = Number(this.value); state.playing = false; finish = false; render(); };
  $('time').onchange = function () { track('拖动时间', state.t); };
  $('equalMass').onclick = function () { state.mass1 = 2; state.mass2 = 2; restart(); track('质量对照', '2:2'); };
  $('unequalMass').onclick = function () { state.mass1 = 3; state.mass2 = 1; restart(); track('质量对照', '3:1'); };
  $('play').onclick = $('stagePlay').onclick = toggle;
  $('restart').onclick = function () { restart(); track('回到起点'); };
  $('resetView').onclick = function () { scene.reset(state.scene, false); track('视角复位'); };
  $('topView').onclick = function () { scene.reset(state.scene, true); track('俯视轨道'); };
  $('panelToggle').onclick = function () { $('panel').classList.toggle('collapsed'); };
  document.addEventListener('keydown', function (e) {
    if (e.code === 'Space' && !/INPUT|BUTTON|SELECT|TEXTAREA/.test(e.target.tagName)) { e.preventDefault(); toggle(); }
  });
  function shareURL() {
    var u = new URL(location.href); u.search = ''; u.hash = '';
    var p = u.searchParams; p.set('scene', state.scene); p.set('t', state.t.toFixed(4)); p.set('play', '0');
    if (state.scene === 'sync') { p.set('height', state.height.toFixed(3)); p.set('inc', state.inclination); p.set('retro', state.retro ? '1' : '0'); p.set('frame', state.earthFrame ? 'earth' : 'space'); }
    else { p.set('m1', state.mass1); p.set('m2', state.mass2); p.set('d', state.distance); }
    return u.href;
  }
  $('share').onclick = async function () {
    try { await navigator.clipboard.writeText(shareURL()); this.textContent = '链接已复制'; track('复制链接', state.scene); }
    catch (e) { this.textContent = '复制失败，可复制地址栏'; history.replaceState(null, '', shareURL()); }
    setTimeout(function () { $('share').textContent = '复制当前链接'; }, 2200);
  };
  window.__model = { state: state, scene: scene, setScene: setScene, preset: preset,
    setTime: function (n) { state.t = Math.max(0, Math.min(state.scene === 'sync' ? 48 : 2, n)); state.playing = false; finish = false; render(); },
    set: function (values) {
      ['height','inclination','mass1','mass2','distance','retro','earthFrame'].forEach(function (k) { if (k in values) state[k] = values[k]; }); restart();
    }, get result() { return calculate(); }, shareURL: shareURL };
  if (matchMedia('(max-width:760px)').matches) $('panel').classList.add('collapsed');
  updateControls();
  function frame(now) {
    var dt = Math.min((now - last) / 1000, .08); last = now;
    if (state.playing && !document.hidden) {
      state.t += dt * (state.scene === 'sync' ? 1.5 : 1 / 12);
      var max = state.scene === 'sync' ? 48 : 2;
      if (state.t >= max) { state.t = max; state.playing = false; finish = true; }
    }
    render(); requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
}());
