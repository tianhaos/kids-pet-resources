/* 绘图独立于面板；成像用近轴平面，视野用球面真实法线。 */
(function () {
  'use strict';
  const C = window.Curved;
  const gold = '#ffc94a', purple = '#c9a7ff', blue = '#60d6ff', red = '#ff9277';
  let map;
  function render(canvas, s, time) {
    const box = canvas.getBoundingClientRect(), dpr = devicePixelRatio || 1;
    if (canvas.width !== Math.round(box.width * dpr) || canvas.height !== Math.round(box.height * dpr)) {
      canvas.width = Math.round(box.width * dpr); canvas.height = Math.round(box.height * dpr);
    }
    const ctx = canvas.getContext('2d'), w = box.width, h = box.height, narrow = w < 600;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const bg = ctx.createRadialGradient(w * .55, h * .48, 0, w * .55, h * .48, w * .7); bg.addColorStop(0, '#111c2b'); bg.addColorStop(.55, '#090f1a'); bg.addColorStop(1, '#05070d');
    ctx.fillStyle = bg; ctx.fillRect(0, 0, w, h);
    const top = narrow ? 200 : 180, bottom = h - (narrow ? 225 : 195);
    const scale = Math.max(1, Math.min((w - (narrow ? 28 : 72)) / 96, Math.max(120, bottom - top) / 53));
    const ox = w / 2 + 13 * scale, oy = (top + bottom) / 2;
    map = { scale, ox, oy, w, h };
    const p = (x, y) => [ox + x * scale, oy - y * scale];
    function line(a, b, color, dash, width = 1.7) {
      ctx.beginPath(); ctx.strokeStyle = color; ctx.lineWidth = width; ctx.setLineDash(dash ? [6, 5] : []);
      ctx.moveTo(...p(a[0], a[1])); ctx.lineTo(...p(b[0], b[1])); ctx.stroke(); ctx.setLineDash([]);
    }
    function text(t, x, y, color = '#b9ccda', size = 13, align = 'center') {
      ctx.fillStyle = color; ctx.font = `${size}px -apple-system, sans-serif`; ctx.textAlign = align; ctx.fillText(t, x, y);
    }
    function label(t, x, y, color) { const q = p(x, y); text(t, q[0], q[1], color); }
    function ray(a, b, color, dash = false) {
      line(a, b, color, dash);
      if (dash) return;
      const phase = s.play ? (time / 2200) % 1 : .5;
      const x = a[0] + (b[0] - a[0]) * phase, y = a[1] + (b[1] - a[1]) * phase;
      const q = p(x, y); ctx.fillStyle = color; ctx.beginPath(); ctx.arc(...q, 3, 0, 7); ctx.fill();
      const q1 = p(a[0] + (b[0] - a[0]) * .45, a[1] + (b[1] - a[1]) * .45);
      const angle = Math.atan2(-(b[1] - a[1]), b[0] - a[0]);
      ctx.save(); ctx.translate(...q1); ctx.rotate(angle); ctx.beginPath(); ctx.moveTo(5, 0); ctx.lineTo(-4, -3); ctx.lineTo(-4, 3); ctx.closePath(); ctx.fill(); ctx.restore();
    }
    function candle(x, height, virtual, title) {
      const q = p(x, 0), ph = height * scale;
      if (title.includes('拖动') && (s.hover || s.dragging)) { ctx.save(); ctx.strokeStyle='#ffc94a88'; ctx.fillStyle='#ffc94a0a'; ctx.lineWidth=1; ctx.beginPath();ctx.roundRect(q[0]-22,q[1]-Math.max(25,ph)-10,44,Math.max(25,ph)+20,14);ctx.fill();ctx.stroke();ctx.restore(); }
      ctx.save(); ctx.translate(...q); ctx.scale(1, ph > 0 ? -1 : 1);
      const ah = Math.abs(ph), cw = Math.max(5, Math.min(19, ah * .22));
      ctx.globalAlpha = virtual ? .62 : 1; ctx.fillStyle = virtual ? purple : gold;
      ctx.strokeStyle = virtual ? purple : '#ffe4a1'; ctx.lineWidth = 2; ctx.setLineDash(virtual ? [4, 3] : []);
      const wax = ctx.createLinearGradient(-cw / 2, 0, cw / 2, 0); wax.addColorStop(0, virtual ? '#9476c8' : '#b77a2d'); wax.addColorStop(.4, virtual ? '#d9bcff' : '#ffe8a1'); wax.addColorStop(1, virtual ? '#9674cb' : '#e7ad45'); ctx.fillStyle = wax; ctx.fillRect(-cw / 2, 0, cw, ah * .66); ctx.fillStyle = virtual ? purple : gold; ctx.strokeRect(-cw / 2, 0, cw, ah * .66);
      ctx.shadowColor = virtual ? purple : '#ffb438'; ctx.shadowBlur = virtual ? 5 : 18;
      ctx.beginPath(); ctx.moveTo(0, ah); ctx.bezierCurveTo(cw, ah * .76, cw * .3, ah * .65, 0, ah * .68);
      ctx.bezierCurveTo(-cw, ah * .72, -cw * .4, ah * .87, 0, ah); ctx.fill(); ctx.stroke(); ctx.restore();
      const titleY = virtual ? (narrow ? -10 : -5.7) : height > 0 ? height + 4 : height - 4;
      const titlePoint = p(x, titleY); text(title, titlePoint[0], Math.max(top + 14, Math.min(bottom - 8, titlePoint[1])), virtual ? purple : gold);
    }
    function mirror(type, aperture = 15) {
      ctx.save(); ctx.beginPath();
      for (let i = 0; i <= 80; i++) { const y = -aperture + i * aperture / 40; const x = C.surface(type, 2 * s.f, y); const q = p(x, y); i ? ctx.lineTo(...q) : ctx.moveTo(...q); }
      ctx.strokeStyle = '#152435'; ctx.lineWidth = narrow ? 10 : 18; ctx.stroke(); ctx.strokeStyle = '#47667f'; ctx.lineWidth = narrow ? 6 : 11; ctx.stroke(); ctx.shadowColor = blue; ctx.shadowBlur = 9; ctx.strokeStyle = '#c2f0ff'; ctx.lineWidth = 2.5; ctx.stroke(); ctx.restore();
      if (s.scene !== 'field') { line([0,-aperture-1],[0,-20], '#5c7188', false, 4); line([-4,-20],[4,-20], '#7189a0', false, 4); }
      label(type === 'concave' ? '凹面镜' : '凸面镜', 1, aperture + 4, blue);
    }
    // 低对比网格只辅助读位置，不与真实光线争夺注意力。
    ctx.save(); ctx.beginPath(); ctx.rect(0, top - 15, w, Math.max(80, bottom - top + 30)); ctx.clip();
    for (let x = -60; x <= 35; x += 5) line([x,-30],[x,30], '#7995b40c', false, 1);
    for (let y = -25; y <= 25; y += 5) line([-65,y],[38,y], '#7995b40c', false, 1);
    if (s.scene === 'field') {
      // 固定眼睛与镜口；两边界夹角在远场形成可见扇区。
      const eye = { x: -20, y: 0 }, aperture = 7;
      for (const [type, color] of [['convex', blue], ['plane', '#9aa6b8']]) {
        const ends = C.field(type, 2 * s.f, aperture, eye);
        ctx.beginPath(); ctx.moveTo(...p(ends[0].x, ends[0].y));
        ctx.lineTo(...p(ends[0].x + ends[0].dx * 100, ends[0].y + ends[0].dy * 100));
        ctx.lineTo(...p(ends[1].x + ends[1].dx * 100, ends[1].y + ends[1].dy * 100)); ctx.lineTo(...p(ends[1].x, ends[1].y));
        ctx.closePath(); ctx.fillStyle = type === 'convex' ? '#60d6ff17' : '#ffffff16'; ctx.fill();
        ends.forEach(e => { line([eye.x, eye.y], [e.x, e.y], color, type === 'plane'); line([e.x, e.y], [e.x + e.dx * 100, e.y + e.dy * 100], color, type === 'plane'); });
      }
      // 道路标线及车辆为俯视环境示意，不判定具体车辆是否可见。
      ctx.fillStyle = '#16213166'; const road = p(-60,19); ctx.fillRect(road[0],road[1],54*scale,38*scale);
      for (const y of [-19,19]) line([-60,y],[-6,y], '#44576e', false, 1);
      for (let x = -60; x < -8; x += 10) line([x, -9], [x + 5, -9], '#728499', false, 1);
      for (const [x, y, color] of [[-44, 17, '#ce745e'], [-48, -17, '#71b391'], [-33, 2, '#c3a65b']]) {
        const q = p(x, y); ctx.fillStyle = color; ctx.beginPath(); ctx.roundRect(q[0] - 15, q[1] - 8, 30, 16, 5); ctx.fill(); ctx.fillStyle = '#162e42'; ctx.fillRect(q[0] - 4, q[1] - 6, 10, 12); ctx.fillStyle = '#080e18'; for (const dy of [-10,7]) { ctx.fillRect(q[0]-10,q[1]+dy,6,3); ctx.fillRect(q[0]+6,q[1]+dy,6,3); } ctx.strokeStyle='#b8d8ea77'; ctx.lineWidth=1; ctx.strokeRect(q[0]-5,q[1]-6,12,12);
      }
      mirror('convex', aperture); line([0, -7], [0, 7], '#9aa6b8', true);
      const ep = p(-20, 0); ctx.fillStyle = 'white'; ctx.beginPath(); ctx.ellipse(...ep, 13, 8, 0, 0, 7); ctx.fill(); ctx.fillStyle = '#18364c'; ctx.beginPath(); ctx.arc(...ep, 5, 0, 7); ctx.fill();
      label('眼睛', -20, -5); label('凸面镜 · 更宽的视野', -30, 25, blue); label('平面镜边界', -30, -23, '#b8c4d1');
    } else {
      line([-62, 0], [36, 0], '#52677c', true, 1);
      label('镜前', -30, 27, '#7f94ad'); label('镜后', 21, 27, '#7f94ad');
      line([0,-24],[0,24], '#5c7d9b33', true, 1);
      if (s.scene === 'image') {
        line([-57,-21],[32,-21], '#53677c', false, 1);
        label('cm',-55,-18,'#73889f');
        for(let x=-55;x<=30;x+=5) { line([x,-21],[x,-21-(x%10===0?1.2:.65)], '#627992', false, 1); if(x%10===0) label(String(Math.abs(x)),x,-25,'#73889f'); }
        const a=p(-s.u,-21), b=p(0,-21); ctx.strokeStyle='#ffc94a88';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(a[0],a[1]);ctx.lineTo(b[0],b[1]);ctx.stroke();
      }
      mirror(s.type);
      const signed = s.type === 'concave' ? -1 : 1;
      [1, 2].forEach(k => { const x = signed * s.f * k; const q = p(x, 0); if(q[0]<16 || q[0]>w-16)return; ctx.fillStyle = '#c2d9e8'; ctx.beginPath(); ctx.arc(...q, 3, 0, 7); ctx.fill(); const t = narrow ? (k === 1 ? 'F' : 'C') : (k === 1 ? 'F 焦点' : 'C 球心'); const right = q[0] + 8 + ctx.measureText(t).width > w - 8; text(t, q[0] + (right ? -8 : 8), q[1] + 14, '#b9ccda', 12, right ? 'right' : 'left'); });
      if (s.scene === 'parallel') {
        [-10, -5, 0, 5, 10].forEach(y => {
          ray([-58, y], [0, y], gold);
          const end = s.type === 'concave' ? [-58, y * (1 - 58 / s.f)] : [-58, y * (1 + 58 / s.f)];
          ray([0, y], end, blue);
          if (s.type === 'convex') ray([0, y], [s.f, 0], purple, true);
        });

      } else {
        const r = C.solve(s.type, s.u, s.f), objectTop = [-s.u, 7], sf = r.f;
        if (s.rays) {
          ray(objectTop, [0, 7], red); ray([0, 7], [-60, 7 * (1 - 60 / sf)], red);
          ray(objectTop, [0, 0], blue); ray([0, 0], [-60, -420 / s.u], blue);
          if (!r.infinity && !r.real) { ray([0, 7], [-r.v, 7 * r.m], purple, true); ray([0, 0], [-r.v, 7 * r.m], purple, true); }
        }
        candle(-s.u, 7, false, '物 · 拖动');
        const imagePos = p(-r.v, r.m * 7);
        if (!r.infinity && imagePos[0] > 18 && imagePos[0] < w - 18 && imagePos[1] > top && imagePos[1] < bottom) candle(-r.v, r.m * 7, !r.real, r.real ? '实像' : '虚像');
        else text(r.infinity ? '物在焦点上：反射光平行' : '像超出画面，请看读数', w / 2, bottom - 5, gold, narrow ? 11 : 13);
      }
    }
    ctx.restore();
    return map;
  }
  window.CurvedDraw = { render, world(clientX, rect) { return (clientX - rect.left - map.ox) / map.scale; }, objectPoint(s) { return [map.ox - s.u * map.scale, map.oy - 4 * map.scale]; } };
})();
