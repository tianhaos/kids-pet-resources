/* 球面镜近轴成像与向量反射；世界坐标 x 向右、y 向上，单位 cm。 */
(function () {
  'use strict';
  const clamp = (x, a, b) => Math.min(b, Math.max(a, x));
  function solve(type, u, f) {
    const signedF = type === 'convex' ? -f : f;
    const infinity = Math.abs(u - signedF) < 0.015;
    const v = infinity ? Infinity : signedF * u / (u - signedF);
    const m = -v / u;
    return { f: signedF, u, v, m, infinity, real: v > 0,
      kind: infinity ? '反射光平行，不成有限远像' : (v > 0 ? '倒立实像' : '正立虚像') + (Math.abs(m) > 1.015 ? ' · 放大' : Math.abs(m) < 0.985 ? ' · 缩小' : ' · 等大') };
  }
  function reflect(d, n) {
    const length = Math.hypot(n.x, n.y);
    const nx = n.x / length, ny = n.y / length;
    const dot = d.x * nx + d.y * ny;
    return { x: d.x - 2 * dot * nx, y: d.y - 2 * dot * ny };
  }
  // 球面镜顶点在原点；凹面镜球心在左，凸面镜球心在右。
  function surface(type, radius, y) {
    const sign = type === 'concave' ? -1 : 1;
    return sign * (radius - Math.sqrt(radius * radius - y * y));
  }
  function field(type, radius, aperture, eye) {
    return [-aperture, aperture].map(y => {
      const x = type === 'plane' ? 0 : surface(type, radius, y);
      const center = type === 'concave' ? -radius : radius;
      const n = type === 'plane' ? { x: 1, y: 0 } : { x: x - center, y };
      const out = reflect({ x: x - eye.x, y: y - eye.y }, n);
      const len = Math.hypot(out.x, out.y);
      return { x, y, dx: out.x / len, dy: out.y / len };
    });
  }
  window.Curved = { clamp, solve, reflect, surface, field };
})();
