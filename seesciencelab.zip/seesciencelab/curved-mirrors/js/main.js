(function () {
  'use strict';
  const C = window.Curved, D = window.CurvedDraw, $ = id => document.getElementById(id);
  const query = new URLSearchParams(location.search);
  const num = (key, fallback, lo, hi) => { const n = Number(query.get(key)); return query.has(key) && Number.isFinite(n) ? C.clamp(n, lo, hi) : fallback; };
  const state = { scene: ['image', 'parallel', 'field'].includes(query.get('scene')) ? query.get('scene') : 'image', type: query.get('type') === 'concave' ? 'concave' : 'convex', u: num('u', 30, 5, 55), f: num('f', 14, 10, 20), rays: query.get('rays') !== '0', play: query.has('play') ? query.get('play') !== '0' : !matchMedia('(prefers-reduced-motion:reduce)').matches };
  const canvas = $('canvas'); let drag = false;
  const track = (action, label) => window.Analytics && Analytics.track('凸面镜与凹面镜', action, label);
  function update() {
    const r = C.solve(state.type, state.u, state.f);
    document.querySelectorAll('[data-scene]').forEach(b => { b.classList.toggle('on', b.dataset.scene === state.scene); b.setAttribute('aria-pressed', String(b.dataset.scene === state.scene)); });
    document.querySelectorAll('[data-type]').forEach(b => { b.classList.toggle('on', b.dataset.type === state.type); b.setAttribute('aria-pressed', String(b.dataset.type === state.type)); });
    $('u').value = state.u; $('f').value = state.f; $('ou').textContent = state.u.toFixed(1) + ' cm'; $('of').textContent = state.f.toFixed(1) + ' cm';
    $('kind').textContent = state.scene === 'field' ? '凸面镜扩大视野' : state.scene === 'parallel' ? (state.type === 'concave' ? '会聚 · 镜前实焦点' : '发散 · 镜后虚焦点') : r.kind;
    $('v').textContent = r.infinity ? '无有限值' : Math.abs(r.v).toFixed(2) + ' cm · 镜' + (r.real ? '前' : '后');
    $('m').textContent = r.infinity ? '—' : Math.abs(r.m).toFixed(2) + ' 倍';
    $('imageControls').hidden = state.scene !== 'image'; document.querySelector('.mirror-switch').hidden = state.scene === 'field'; $('imageReadout').hidden = state.scene !== 'image';
    const isImage = state.scene === 'image', isField = state.scene === 'field';
    $('stageTitle').textContent = isImage ? '移动蜡烛，看像怎样改变' : isField ? '同一面镜口，看到更宽的世界' : '一束平行光，两种反射结果';
    $('stageNote').textContent = isImage ? '拖动金色蜡烛，或打开参数比较典型位置' : isField ? '俯视对比 · 固定眼睛位置与镜口大小' : '侧视光路 · 箭头表示真实光的传播方向';
    $('panelIntro').textContent = isImage ? '改变物距，比较像的正倒、大小与虚实。' : isField ? '改变镜面曲率，比较蓝色与灰色的视野边界。' : '切换凹、凸面镜，辨认实焦点与虚焦点。';
    $('summaryLabel').textContent = isImage ? '当前成像' : isField ? '视野对比' : '反射结果';
    $('summaryKind').textContent = $('kind').textContent;
    $('summaryKind').style.color = isImage ? (r.real && !r.infinity ? '#ffc94a' : '#dfc8ff') : '#a9e8ff';
    $('summaryNote').textContent = isImage ? (r.infinity ? '物体位于焦点 · 反射光平行' : `像在镜${r.real ? '前' : '后'} ${Math.abs(r.v).toFixed(1)} cm · 像高是物高的 ${Math.abs(r.m).toFixed(2)} 倍`) : isField ? '蓝色：凸面镜边界 · 灰色虚线：平面镜边界' : state.type === 'concave' ? '真实光线交于镜前焦点 F' : '紫色延长线交于镜后虚焦点 F';
    document.querySelector('.ray-key').hidden = isField;
    $('raysControl').hidden = !isImage;
    document.querySelectorAll('[data-k]').forEach(b => { const active = state.type === 'concave' && Math.abs(state.u / state.f - Number(b.dataset.k)) < .015; b.classList.toggle('on', active); b.setAttribute('aria-pressed', String(active)); });
    $('rays').checked = state.rays; $('play').checked = state.play;
  }
  function setU(u) { state.u = C.clamp(Number(u), 5, 55); update(); }
  function scene(name) { state.scene = name; update(); track('切换场景', name); }
  document.querySelectorAll('[data-scene]').forEach(b => b.onclick = () => scene(b.dataset.scene));
  document.querySelectorAll('[data-type]').forEach(b => b.onclick = () => { state.type = b.dataset.type; update(); track('切换镜面', state.type); });
  ['u', 'f'].forEach(key => { $(key).oninput = () => { state[key] = Number($(key).value); update(); }; $(key).onchange = () => track('调节参数', key); });
  ['rays', 'play'].forEach(key => $(key).onchange = () => { state[key] = $(key).checked; update(); });
  document.querySelectorAll('[data-k]').forEach(b => b.onclick = () => { state.type = 'concave'; setU(state.f * Number(b.dataset.k)); track('焦点预设', b.dataset.k); });
  function hit(e) { const p = D.objectPoint(state), r = canvas.getBoundingClientRect(); return state.scene === 'image' && Math.hypot(e.clientX - r.left - p[0], e.clientY - r.top - p[1]) < 44; }
  canvas.onpointerdown = e => { if (!hit(e)) return; drag = true; state.dragging = true; canvas.setPointerCapture(e.pointerId); canvas.style.cursor = 'grabbing'; };
  canvas.onpointermove = e => { if (drag) setU(-D.world(e.clientX, canvas.getBoundingClientRect())); else { state.hover = hit(e); canvas.style.cursor = state.hover ? 'grab' : 'default'; } };
  canvas.onpointerup = () => { if (drag) track('拖动蜡烛', state.u.toFixed(1)); drag = false; state.dragging = false; canvas.style.cursor = 'default'; };
  canvas.onpointercancel = () => { drag = false; state.dragging = false; canvas.style.cursor = 'default'; };
  if (matchMedia('(max-width:760px)').matches) $('panel').classList.add('collapsed');
  $('panelToggle').onclick = () => { $('panel').classList.toggle('collapsed'); $('panelToggle').setAttribute('aria-expanded', String(!$('panel').classList.contains('collapsed'))); };
  $('share').onclick = async () => {
    const params = new URLSearchParams({ scene: state.scene, type: state.type, u: state.u.toFixed(2), f: state.f.toFixed(2), rays: +state.rays, play: +state.play });
    const url = location.origin + location.pathname + '?' + params;
    try { await navigator.clipboard.writeText(url); $('status').textContent = '已复制当前状态链接'; } catch { $('status').textContent = url; }
    track('分享', state.scene);
  };
  window.__model = { state, update, setU, scene };
  update();
  function frame(t) { D.render(canvas, state, t); requestAnimationFrame(frame); } requestAnimationFrame(frame);
})();
