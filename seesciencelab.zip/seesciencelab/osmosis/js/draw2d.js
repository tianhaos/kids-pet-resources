// 显微视野、结构探测与体积曲线。细胞轮廓为二维形态示意。
(function(){
  'use strict';
  const TAU=Math.PI*2;
  const wallVertices=[[-232,-76],[-102,-107],[219,-95],[260,-63],[235,78],[127,105],[-222,79],[-258,49]];
  const inks={wall:'#ecd7b7',protoplast:'#f2a9db',vacuole:'#d287c9',gap:'#8fd6ef'};
  const views=new WeakMap();

  function surface(canvas){
    const {width:w,height:h}=canvas.getBoundingClientRect();
    const d=Math.min(devicePixelRatio||1,2);
    if(canvas.width!==Math.round(w*d)||canvas.height!==Math.round(h*d)){
      canvas.width=Math.round(w*d);
      canvas.height=Math.round(h*d);
    }
    const g=canvas.getContext('2d');
    g.setTransform(d,0,0,d,0,0);
    return {g,w,h};
  }

  function rounded(points,radius){
    const path=new Path2D();
    points.forEach(([x,y],i)=>{
      const [ax,ay]=points[(i+points.length-1)%points.length], [bx,by]=points[(i+1)%points.length];
      const a=Math.min(.45,radius/Math.hypot(ax-x,ay-y)), b=Math.min(.45,radius/Math.hypot(bx-x,by-y));
      const entryX=x+(ax-x)*a, entryY=y+(ay-y)*a;
      if(i===0) path.moveTo(entryX,entryY);
      else path.lineTo(entryX,entryY);
      path.quadraticCurveTo(x,y,x+(bx-x)*b,y+(by-y)*b);
    });
    path.closePath();
    return path;
  }

  function scalePoints(points,sx,sy,dx=0,dy=0){
    return points.map(([x,y])=>[x*sx+dx,y*sy+dy]);
  }

  const wall=rounded(wallVertices,17);
  const innerWall=rounded(scalePoints(wallVertices,.974,.938),13);
  // 周围细胞只提供组织纹理。共用交界顶点，形成连续的表皮组织。
  const [a0,b,c,d,e,f,g0,a]=wallVertices;
  const u=[-375,-193], v=[-46,-230], w0=[257,-219], r=[565,-191];
  const l=[-546,-21], r0=[555,15], l1=[-520,174], m0=[-145,231], m1=[201,232], r1=[549,176];
  const neighbors=[
    [l,u,v,b,a0,a], [v,w0,d,c,b], [w0,r,r0,e,d],
    [a,g0,m0,l1,l], [g0,f,m1,m0], [f,e,r0,r1,m1],
    [u,[-269,-361],[66,-349],v], [v,[66,-349],[339,-346],w0],
    [m0,m1,[94,384],[-226,374]], [m1,r1,[425,375],[94,384]]
  ].map(points=>({
    path:rounded(points,14),
    x:points.reduce((sum,[x])=>sum+x,0)/points.length,
    y:points.reduce((sum,[,y])=>sum+y,0)/points.length
  }));

  // 固定种子的颗粒纹理，随画面缩放，不参与动力学。
  let seed=73;
  function random(){
    seed=(Math.imul(seed,1664525)+1013904223)>>>0;
    return seed/4294967296;
  }
  const specks=Array.from({length:1100},()=>[
    (random()-.5)*1180,(random()-.5)*720, .35+random()*2,random()
  ]);
  const granules=Array.from({length:240},()=>[
    (random()-.5)*510,(random()-.5)*216,.6+random()*2.2,random()
  ]);

  function stroke(g,path,color,width){
    g.strokeStyle=color;
    g.lineWidth=width;
    g.stroke(path);
  }
  function fill(g,path,color){
    g.fillStyle=color;
    g.fill(path);
  }
  function gradient(g,x,y,r,stops){
    const p=g.createRadialGradient(x,y,0,x,y,r);
    stops.forEach(([offset,color])=>p.addColorStop(offset,color));
    return p;
  }
  function grainPaths(points){
    const paths=[new Path2D(),new Path2D(),new Path2D()];
    for(const [x,y,r,t] of points){
      const path=paths[Math.floor(t*paths.length)],angle=t*TAU;
      path.moveTo(x+r*Math.cos(angle),y+r*Math.sin(angle));
      path.ellipse(x,y,r,r*.55,angle,0,TAU);
    }
    return paths;
  }
  const speckPaths=grainPaths(specks),granulePaths=grainPaths(granules);
  function dots(g,paths,colors){
    paths.forEach((path,i)=>fill(g,path,colors[i]));
  }

  function structure(v){
    const shrink=Math.cbrt(Math.min(v,1));
    const detach=1-shrink;
    const rounding=Math.min(1,detach*3.4);
    const points=wallVertices.map(([x,y])=>{
      const angle=Math.atan2(y/102,x/249);
      const sx=Math.cos(angle)*246, sy=Math.sin(angle)*99;
      return [(x+(sx-x)*rounding)*.956*shrink+detach*52,
        (y+(sy-y)*rounding)*.91*shrink-detach*15];
    });
    const membrane=rounded(points,16+detach*155);
    const vacuole=rounded(scalePoints(points,.925,.835,-4,-4),19+detach*124);
    const nucleus=new Path2D();
    const nx=111*shrink+detach*52, ny=74*shrink-detach*52;
    nucleus.ellipse(nx,ny,18*shrink,10.5*shrink,-.12,0,TAU);
    return {membrane,vacuole,nucleus,nx,ny,shrink,detach};
  }

  function arrow(g,start,end,y,color){
    const sign=Math.sign(end-start), path=new Path2D();
    path.moveTo(start,y);
    path.lineTo(end,y);
    path.moveTo(end-sign*9,y-6);
    path.lineTo(end,y);
    path.lineTo(end-sign*9,y+6);
    g.lineCap='round';
    g.lineJoin='round';
    stroke(g,path,'#081421',6);
    stroke(g,path,color,2.4);
  }

  function render(canvas,s,options={}){
    const {g,w,h}=surface(canvas);
    if(!w||!h)return;
    const inset=options.clean?0:(w<550?52:48);
    const zoom=Math.max(.1,Math.min(w/(options.clean?610:w<550?583:688),(h-inset*2)/270,1.62));
    const cx=w/2,cy=h/2-(options.clean?0:w<550?18:10);
    const {membrane,vacuole,nucleus,nx,ny,shrink,detach}=structure(s.v);
    views.set(canvas,{cx,cy,zoom,membrane,vacuole,detach});
    g.fillStyle='#100d18';
    g.fillRect(0,0,w,h);
    g.save();
    g.translate(cx,cy);
    g.scale(zoom,zoom);
    g.fillStyle=gradient(g,-30,-28,640,[[0,'#4c354e'],[.48,'#302436'],[1,'#14111e']]);
    g.fillRect(-w/zoom/2,-h/zoom/2-30,w/zoom,h/zoom+60);
    neighbors.forEach(({path:p,x,y},i)=>{
      const color=['#a26f8b5c','#867ba148','#a75c843d'][i%3];
      fill(g,p,gradient(g,x,y,235,[[0,color],[.7,'#83618325'],[1,'#94737707']]));
      stroke(g,p,'#160e1b96',8);
      stroke(g,p,'#b99a913e',3.6);
      stroke(g,p,'#f1c5ac24',1);
    });
    dots(g,speckPaths,['#09061148','#cfa7aa21','#edc8bc24']);
    fill(g,wall,'#432e3f');
    fill(g,innerWall,gradient(g,-57,-40,344,[[0,'#3b5061'],[.65,'#283849'],[1,'#1d293c']]));
    g.save();
    g.clip(innerWall);
    dots(g,speckPaths,['#0d182550','#92b7cc31','#dfd3d729']);
    g.restore();
    stroke(g,wall,'#211524',8);
    stroke(g,wall,'#cdb2a1',3.9);
    stroke(g,innerWall,'#e5cbc0ad',1.05);
    fill(g,membrane,gradient(g,-64,-52,325,[[0,'#b6849f'],[.68,'#895272'],[1,'#4d304a']]));
    g.save();
    g.clip(membrane);
    g.scale(shrink,shrink);
    dots(g,granulePaths,['#471b4a71','#ffd2bc79','#fed6e48c']);
    g.restore();
    fill(g,vacuole,gradient(g,-66*shrink,-44,310*shrink,[
      [0,`rgb(${172+Math.round(detach*65)}, 101, ${157+Math.round(detach*53)})`],[.51,'#863876'],[.84,'#5c255e'],[1,'#471d4f']
    ]));
    g.save();
    g.clip(vacuole);
    // 液泡内的柔和明暗表现透光材质，颗粒用于表现显微视野。
    for(const [x,y,r,color] of [[-118,28,125,'#e28cad26'],[56,-29,105,'#e58cc322'],[105,32,128,'#3a144c39']]){
      g.fillStyle=gradient(g,x*shrink,y*shrink,r*shrink,[[0,color],[1,'#0000']]);
      g.fillRect((x-r)*shrink,(y-r)*shrink,2*r*shrink,2*r*shrink);
    }
    dots(g,speckPaths,['#31102b38','#ea9bd326','#f6b4c120']);
    g.restore();
    stroke(g,vacuole,'#e8a6cb7a',1.3);
    g.save();
    g.clip(membrane);
    fill(g,nucleus,gradient(g,nx-7*shrink,ny-4*shrink,29*shrink,[
      [0,'#ecd0ac'],[.32,'#be8b9a'],[1,'#623868']
    ]));
    stroke(g,nucleus,'#f5c9ccaa',1.3);
    const nucleolus=new Path2D();
    nucleolus.arc(nx+4*shrink,ny-shrink,3.1*shrink,0,TAU);
    fill(g,nucleolus,'#633458');
    g.restore();
    stroke(g,membrane,'#4d284c',4);
    stroke(g,membrane,'#efa9d1',1.55);

    if(s.particles){
      const end=-242*shrink+detach*52+23;
      g.fillStyle='#a4e8ff';
      for(let i=0;i<8;i++){
        const q=(s.phase*.55+i*.213)%1;
        const x=i%2 ? -288+(end+288)*q : end-(end+288)*q;
        g.beginPath();
        g.arc(x,-48+i*13+Math.sin(q*TAU+i)*3,2.1,0,TAU);
        g.fill();
      }
    }
    if(Math.abs(s.flow)>.0003){
      const start=-274,end=-232*shrink+detach*52+20;
      arrow(g,s.flow>0?start:end,s.flow>0?end:start,-4,'#b2e9ff');
    }
    const part=options.part;
    if(part==='gap'&&detach>.015){
      const gap=new Path2D(innerWall);
      gap.addPath(membrane);
      g.fillStyle='#83d0eb42';
      g.fill(gap,'evenodd');
      stroke(g,innerWall,inks.gap,2);
      stroke(g,membrane,inks.gap,2);
    }else if(part&&part!=='gap'){
      const path={wall,protoplast:membrane,vacuole}[part];
      stroke(g,path,'#201526',6);
      stroke(g,path,inks[part],3);
    }
    g.restore();
    const vignette=g.createRadialGradient(cx,cy,Math.min(w,h)*.20,cx,cy,Math.hypot(w,h)*.55);
    vignette.addColorStop(0,'#08061000');
    vignette.addColorStop(.6,'#08061027');
    vignette.addColorStop(1,'#080610d9');
    g.fillStyle=vignette;
    g.fillRect(0,0,w,h);
  }

  function pick(canvas,x,y){
    const view=views.get(canvas);
    if(!view)return null;
    const g=canvas.getContext('2d');
    const px=(x-view.cx)/view.zoom,py=(y-view.cy)/view.zoom;
    g.save();
    g.resetTransform();
    // 边界按屏幕像素扩展，膜与壁贴合时用结构按钮分别查看。
    g.lineWidth=16/view.zoom;
    const nearWall=g.isPointInStroke(wall,px,py);
    const nearMembrane=g.isPointInStroke(view.membrane,px,py);
    const inWall=g.isPointInPath(innerWall,px,py);
    const inVacuole=g.isPointInPath(view.vacuole,px,py);
    const inMembrane=g.isPointInPath(view.membrane,px,py);
    g.restore();
    if(inVacuole)return 'vacuole';
    if(inMembrane)return 'protoplast';
    if(inWall&&view.detach>.015)return 'gap';
    if(nearWall)return 'wall';
    if(nearMembrane)return 'protoplast';
    return null;
  }

  function chart(canvas,s){
    const {g,w,h}=surface(canvas);
    g.clearRect(0,0,w,h);
    const left=28,right=w-7,top=8,bottom=h-19;
    if(right<=left||bottom<=top)return;
    const maxTime=Math.max(30,Math.ceil(s.t/10)*10);
    const X=t=>left+t/maxTime*(right-left);
    const Y=v=>bottom-(v-.3)/.82*(bottom-top);
    g.font='11px system-ui';
    g.textAlign='right';
    g.lineWidth=1;
    for(const v of [.4,.7,1]){
      g.beginPath();
      g.moveTo(left,Y(v));
      g.lineTo(right,Y(v));
      g.strokeStyle=v===1?'#485061':'#303744';
      g.stroke();
      g.fillStyle='#a8b1c4';
      g.fillText(v.toFixed(1),left-6,Y(v)+4);
    }
    g.setLineDash([3,4]);
    g.strokeStyle='#72c6ee';
    g.beginPath();
    for(const e of s.events){
      g.moveTo(X(e.t),top);
      g.lineTo(X(e.t),bottom);
    }
    g.stroke();
    g.setLineDash([]);
    g.beginPath();
    g.moveTo(X(0),Y(s.history[0].v));
    for(const p of s.history)g.lineTo(X(p.t),Y(p.v));
    g.lineTo(X(s.t),Y(s.v));
    g.strokeStyle='#efa6ce';
    g.lineWidth=2.2;
    g.stroke();
    g.beginPath();
    g.arc(X(s.t),Y(s.v),3.5,0,TAU);
    g.fillStyle='#ffd7eb';
    g.fill();
    g.fillStyle='#a8b1c4';
    g.fillText('0',left+4,h-3);
    g.fillText(maxTime+' 示意秒',right,h-3);
  }
  window.OsmosisDraw={render,pick,chart};
})();
