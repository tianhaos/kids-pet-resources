// 纯计算：V为原生质相对体积，浓度mol/L，水势MPa，时间为示意秒。
(function(){
  'use strict';
  const RT=0.008314*298, N=0.30;
  function sample(v,c){
    const inside=N/v,pressure=8*Math.max(v-1,0),psi=-RT*inside+pressure,out=-RT*c,flow=0.12*(out-psi);
    return {
      v,c,inside,pressure,psi,out,flow
    };
  }
  function step(v,c,dt){
    let left=Math.max(0,dt);
    while(left>1e-8){
      const h=Math.min(left,.02);
      v=Math.max(.15,Math.min(1.2,v+sample(v,c).flow*h));
      left-=h;
    }
    return v;
  }
  function equilibrium(c){
    let a=.15,b=1.2;
    for(let i=0; i<70; i++){
      let m=(a+b)/2;
      if(sample(m,c).flow>0)a=m;
      else b=m;
    }
    return(a+b)/2;
  }
  window.Osmosis={
    sample,step,equilibrium,RT,N
  };
})();
