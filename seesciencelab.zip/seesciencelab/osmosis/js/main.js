(function(){
  'use strict';
  const $=id=>document.getElementById(id),qs=new URLSearchParams(location.search);
  const presets={
    hyper:{
      c:.6,v:1
    },iso:{
      c:.3,v:1
    },recover:{
      c:0,v:.5
    }
  };
  const num=(key,fallback,min,max)=>{
    const raw=qs.get(key),v=raw===null?fallback:Number(raw);
    return Number.isFinite(v)?Math.min(max,Math.max(min,v)):fallback;
  };
  let scene=Object.hasOwn(presets,qs.get('scene'))?qs.get('scene'):'hyper';
  const init=presets[scene];
  const canvas=$('osmosis'),chart=$('chart'),panel=$('panel');
  const mobile=matchMedia('(max-width:760px)'),reduceMotion=matchMedia('(prefers-reduced-motion:reduce)');
  const parts={
    wall:'细胞壁维持原来的轮廓，水和本实验中的溶质都可通过。',
    protoplast:'沿粉色细胞膜往内，还可看到薄层细胞质与液泡膜。它们合称原生质层。',
    vacuole:'淡紫色液泡占据细胞的大部分。失水时液泡缩小，吸水后重新扩张。',
    gap:'原生质层离开细胞壁后，分离间隙与外液相通，充满外界溶液。'
  };
  let selected=null,hovered=null,dirty=true,graphDirty=true;
  let gapVisible=false;
  const state={
    scene,c:num('c',init.c,0,.8),v:num('v',init.v,.3,1.12),t:0,play:qs.get('play')==='1',particles:qs.get('particles')!=='0',phase:0,history:[],events:[]
  };
  state.history.push({
    t:0,v:state.v
  });
  function track(a,l){
    if(window.Analytics)Analytics.track('渗透作用与质壁分离',a,l||'');
  }
  function update(){
    const m=Osmosis.sample(state.v,state.c);
    $('time').textContent=state.t.toFixed(1)+' s';
    $('volume').textContent=state.v.toFixed(3);
    $('inside').textContent=m.inside.toFixed(3)+' mol/L';
    $('pressure').textContent=m.pressure.toFixed(3)+' MPa';
    $('flow').textContent=Math.abs(m.flow)<.0003?'净水流近零 · 动态平衡':m.flow>0?'水净流入细胞':'水净流出细胞';
    const separated=Math.cbrt(Math.min(state.v,1))<.985;
    $('status').textContent=separated?'质壁分离':m.pressure>.02?'膨胀贴壁 · 有膨压':'原生质层贴壁';
    if(gapVisible!==separated){
      gapVisible=separated;
      if(selected==='gap')showPart();
    }
    $('eventKey').hidden=!state.events.length;
    dirty=graphDirty=true;
    $('concentration').value=state.c;
    $('cText').textContent=state.c.toFixed(2)+' mol/L';
    $('play').textContent=state.play?'暂停':'开始';
    $('particles').checked=state.particles;
    document.querySelectorAll('[data-scene]').forEach(b=>b.setAttribute('aria-pressed',b.dataset.scene===state.scene));
  }
  function setScene(name){
    if(!Object.hasOwn(presets,name))return;
    Object.assign(state,presets[name],{
      scene:name,t:0,play:false,history:[],events:[]
    });
    state.history.push({
      t:0,v:state.v
    });
    $('feedback').textContent='';
    hoverPart(null);
    selected=null;
    showPart();
    update();
    track('切换实验',name);
  }
  function setC(c){
    if(!Number.isFinite(+c))return;
    state.c=Math.min(.8,Math.max(0,+c));
    if(state.events.at(-1)?.t===state.t)state.events.at(-1).c=state.c;
    else state.events.push({t:state.t,c:state.c});
    update();
  }
  function advance(dt){
    let left=Math.max(0,dt);
    while(left>1e-8){
      const h=Math.min(.1,left);
      state.v=Osmosis.step(state.v,state.c,h);
      state.t+=h;
      left-=h;
      state.history.push({
        t:state.t,v:state.v
      });
    }
    if(state.history.length>6000)state.history=state.history.filter((_,i)=>i%2===0);
    dirty=graphDirty=true;
  }
  document.querySelectorAll('[data-scene]').forEach(b=>b.onclick=()=>setScene(b.dataset.scene));
  $('concentration').oninput=e=>setC(+e.target.value);
  $('concentration').onchange=()=>track('改变浓度',String(state.c));
  $('water').onclick=()=>{
    setC(0);
    track('换清水');
  };
  $('play').onclick=()=>{
    state.play=!state.play;
    update();
    track('播放',String(state.play));
  };
  $('reset').onclick=()=>setScene(state.scene);
  $('particles').onchange=e=>{
    state.particles=e.target.checked;
    dirty=true;
  };
  document.querySelectorAll('[data-answer]').forEach(b=>b.onclick=()=>{
    $('feedback').textContent=b.dataset.answer==='right'?'正确。细胞壁可透过外液；原生质层才是这里的选择透过屏障。':'再想想：细胞壁可让水和这些溶质通过，间隙与外液连通，充满外界溶液。';
    track('判断',b.dataset.answer);
  });
  $('share').onclick=async()=>{
    const u=new URL(location.href);
    u.search=new URLSearchParams({
      scene:state.scene,c:state.c.toFixed(2),v:state.v.toFixed(6),play:'0',particles:state.particles?'1':'0'
    });
    try{
      await navigator.clipboard.writeText(u.href);
      $('shareStatus').textContent='已复制当前状态链接';
    }
    catch(e){
      $('shareStatus').textContent=u.href;
    }
    track('分享');
  };
  function showPart(){
    $('partInfo').textContent=selected==='gap'&&!gapVisible
      ?'此刻原生质层贴近细胞壁。选择浓液失水并播放，观察分离间隙。'
      :parts[selected]||'点选细胞或下方对应的结构名称。';
    document.querySelectorAll('[data-part]').forEach(b=>b.setAttribute('aria-pressed',b.dataset.part===selected));
    dirty=true;
  }
  function choose(part){
    selected=selected===part?null:part;
    showPart();
    if(selected)track('点选结构',selected);
  }
  function hoverPart(part){
    if(hovered===part)return;
    hovered=part;
    canvas.style.cursor=part?'pointer':'crosshair';
    dirty=true;
  }
  function pick(e){
    const rect=canvas.getBoundingClientRect();
    return OsmosisDraw.pick(canvas,e.clientX-rect.left,e.clientY-rect.top);
  }
  document.querySelectorAll('[data-part]').forEach(b=>b.onclick=()=>choose(b.dataset.part));
  canvas.onpointermove=e=>{
    if(e.pointerType==='mouse')hoverPart(pick(e));
  };
  canvas.onpointerleave=()=>hoverPart(null);
  canvas.onclick=e=>choose(pick(e));

  function setPanel(open,focus=false){
    const collapsed=mobile.matches&&!open;
    panel.classList.toggle('collapsed',collapsed);
    panel.inert=collapsed;
    $('panelToggle').setAttribute('aria-expanded',!collapsed);
    if(focus)$(collapsed?'panelToggle':'panelClose').focus();
  }
  $('panelToggle').onclick=()=>setPanel(panel.classList.contains('collapsed'),true);
  $('panelClose').onclick=()=>setPanel(false,true);
  panel.addEventListener('keydown',e=>{
    if(e.key==='Escape'&&mobile.matches)setPanel(false,true);
  });
  mobile.addEventListener('change',()=>setPanel(false));
  setPanel(false);

  const resize=new ResizeObserver(()=>{ dirty=graphDirty=true; });
  resize.observe(canvas);
  resize.observe(chart);
  let prev=performance.now();
  function frame(now){
    const dt=Math.min((now-prev)/1000,.1);
    prev=now;
    if(state.play){
      if(!reduceMotion.matches)state.phase+=dt;
      advance(dt*3);
      update();
    }
    if(dirty){
      OsmosisDraw.render(canvas,{...state,flow:Osmosis.sample(state.v,state.c).flow},{part:hovered||selected});
      dirty=false;
    }
    if(graphDirty){
      OsmosisDraw.chart(chart,state);
      graphDirty=false;
    }
    requestAnimationFrame(frame);
  }
  update();
  requestAnimationFrame(frame);
  window.__model={
    state,setScene,setC,advance,update,sample:()=>Osmosis.sample(state.v,state.c)
  };
})();
