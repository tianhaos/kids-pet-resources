/* 固体平均压强：SI计算；形变只作示意，不参与受力面积计算。 */
(function () {
  'use strict';
  const faces = {
    flat: { name: '平放', width: 10, depth: 5, height: 2 },
    side: { name: '侧放', width: 10, depth: 2, height: 5 },
    end: { name: '竖放', width: 5, depth: 2, height: 10 }
  };
  function clamp(x, lo, hi) { return Math.max(lo, Math.min(hi, x)); }
  function solve(group) {
    const face = faces[group.face] || faces.flat;
    const load = clamp(Math.round(Number(group.load) || 0), 0, 3);
    const mass = 0.5 * (1 + load);
    const force = mass * 10;
    const area = face.width * face.depth;
    const pressure = force / (area * 1e-4);
    return { face, load, mass, force, area, pressure };
  }
  function preset(scene) {
    return [{ face: 'flat', load: 0 }, { face: scene === 'force' ? 'flat' : 'end', load: scene === 'force' ? 2 : 0 }];
  }
  function change(state, index, key, value) {
    const group = state.groups[index];
    group[key] = key === 'load' ? clamp(Math.round(value), 0, 3) : (faces[value] ? value : 'flat');
    if ((state.scene === 'area' && key === 'load') || (state.scene === 'force' && key === 'face')) {
      state.groups[1 - index][key] = group[key];
    }
  }
  // 任意画面单位，单调、有限；不输出毫米，不代表海绵本构关系。
  function dent(pressure) { return 47 * (1 - Math.exp(-pressure / 6500)); }
  function compare(groups) {
    const a = solve(groups[0]), b = solve(groups[1]);
    const ratio = b.pressure / a.pressure;
    const sameF = a.force === b.force, sameS = a.area === b.area;
    let reason = sameF && sameS ? '压力和面积均相同，两组压强相同。' : sameF ? '保持压力相同：受力面积越小，压强越大。' : sameS ? '保持面积相同：压力越大，压强越大。' : '压力和面积均不同，应计算 F/S；这不是单因素对照。';
    return { a, b, ratio, reason };
  }
  window.Pressure = { faces, clamp, solve, preset, change, dent, compare };
})();
