/* Canvas装置图；每块压块是同尺寸同质量长方体，固定砝码居中。 */
(function () {
  'use strict';
  const P = window.Pressure;
  const gold = '#ffc94a', blue = '#79dafa', ink = '#dfeaf3';
  let ctx, hits = [], transform, mobileMode = false;
  function text(s, x, y, size = 14, color = ink, align = 'left') {
    ctx.fillStyle = color; ctx.font = `${size}px -apple-system,"PingFang SC",sans-serif`; ctx.textAlign = align; ctx.fillText(s, x, y);
  }
  function path(points, fill, stroke, line = 1) {
    ctx.beginPath(); points.forEach((p, i) => i ? ctx.lineTo(...p) : ctx.moveTo(...p)); ctx.closePath();
    if (fill) { ctx.fillStyle = fill; ctx.fill(); }
    if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = line; ctx.stroke(); }
  }
  function line(x1,y1,x2,y2,color,width=1) {
    ctx.strokeStyle=color;ctx.lineWidth=width;ctx.beginPath();ctx.moveTo(x1,y1);ctx.lineTo(x2,y2);ctx.stroke();
  }
  function box(x,y,w,h,fill,stroke,r=5) {
    ctx.beginPath();ctx.roundRect(x,y,w,h,r);ctx.fillStyle=fill;ctx.fill();if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=1;ctx.stroke();}
  }
  function arrow(x,y,len) {
    line(x,y,x,y+len,gold,3);path([[x,y+len],[x-5,y+len-9],[x+5,y+len-9]],gold);
  }
  // 顶面轮廓：完整底面下陷，外侧平滑恢复；不模拟接触边缘应力。
  function sponge(cx, base, bw, d, width) {
    const left=cx-width/2,right=cx+width/2,bottom=base+88;
    function surface(x) {
      const distance=Math.abs(x-cx)-bw/2;
      return base+(distance<=0 ? d : d*Math.exp(-distance*distance/240));
    }
    ctx.beginPath(); ctx.moveTo(left,bottom);ctx.lineTo(left,surface(left));
    for(let x=left;x<=right;x+=2)ctx.lineTo(x,surface(x));
    ctx.lineTo(right,bottom);ctx.closePath();
    const grad=ctx.createLinearGradient(0,base,0,bottom);grad.addColorStop(0,'#cc9b65');grad.addColorStop(1,'#765233');ctx.fillStyle=grad;ctx.fill();
    ctx.save();ctx.clip();
    for(let row=0;row<9;row++) for(let col=0;col<32;col++) {
      const px=left+col*11+(row%2)*5, py=base+row*11+5;
      ctx.beginPath();ctx.ellipse(px,py,2.4+(col%3)*.4,1.8,0,0,Math.PI*2);ctx.fillStyle=(row+col)%3?'#503c2b55':'#ffe3aa50';ctx.fill();
    }
    ctx.restore();ctx.beginPath();ctx.moveTo(left,surface(left));for(let x=left;x<=right;x+=2)ctx.lineTo(x,surface(x));ctx.strokeStyle='#f8d49c';ctx.lineWidth=2;ctx.stroke();
    // 未受压表面作参照，不用长度刻度。
    ctx.setLineDash([4,5]);line(left,base,right,base,'#d7e9f059');ctx.setLineDash([]);
    box(left-8,bottom+1,width+16,13,'#344554','#617889',2);
    return bottom;
  }
  function rig(index,x,y,w,h,state,visual) {
    const data=P.solve(state.groups[index]), face=data.face;
    const cx=x+w/2;
    const unit=mobileMode?10:18;
    const base=y+(mobileMode?175:255);
    const bw=face.width*unit,bh=face.height*unit;
    const d=visual[index], top=base+d-bh;
    text(index?'乙组':'甲组',x+12,y+22,12,index?gold:blue);
    text(`${data.force} N / ${data.area} cm²`,cx,y+47,11,'#a8bdcb','center');
    text(`${Number((data.pressure/1000).toFixed(2))} kPa`,x+w-12,y+22,18,index?gold:blue,'right');
    // 背景台面与地面网格，保持装置焦点。
    box(x+4,y+64,w-8,base-y+40,'#0f182366',null,12);
    const bottom=sponge(cx,base,bw,d,Math.min(w-38,294));
    const dx=face.depth*3,dy=-face.depth*2;
    path([[cx-bw/2,top],[cx-bw/2+dx,top+dy],[cx+bw/2+dx,top+dy],[cx+bw/2,top]],'#ebce8e','#ffe5aa');
    path([[cx+bw/2,top],[cx+bw/2+dx,top+dy],[cx+bw/2+dx,base+d+dy],[cx+bw/2,base+d]],'#8c6637','#dfb773');
    const wood=ctx.createLinearGradient(cx-bw/2,0,cx+bw/2,0);wood.addColorStop(0,'#be8d50');wood.addColorStop(.5,'#e5b76d');wood.addColorStop(1,'#bc8848');
    box(cx-bw/2,top,bw,bh,wood,'#ffdd95',1);
    ctx.save();ctx.beginPath();ctx.rect(cx-bw/2,top,bw,bh);ctx.clip();
    for(let n=0;n<12;n++) {
      ctx.beginPath();ctx.moveTo(cx-bw/2,top+n*11+3);ctx.bezierCurveTo(cx-bw/4,top+n*11-3,cx+bw/4,top+n*11+8,cx+bw/2,top+n*11+1);ctx.strokeStyle='#865c3033';ctx.lineWidth=1;ctx.stroke();
    }
    ctx.restore();
    line(cx-bw/2,base+d,cx+bw/2,base+d,gold,4);
    text(face.name,cx,top+Math.min(bh/2+5,26),12,'#44311c','center');
    // 固定砝码架：始终有44px触控范围，空载也能向上拖动加砝码。
    const rackTop=top-16-data.load*13;
    line(cx,top,cx,rackTop-8,'#d9e6ee',3);
    line(cx-21,top-2,cx+21,top-2,'#d9e6ee',3);
    for(let j=0;j<data.load;j++) {
      box(cx-19,top-15-j*13,38,11,'#a7b9c4','#e0edf2',3);
      line(cx-13,top-12-j*13,cx+13,top-12-j*13,'#e5f2fa',1);
    }
    ctx.beginPath();ctx.arc(cx,rackTop-9,7,Math.PI,0);ctx.strokeStyle='#dae6f2';ctx.lineWidth=2;ctx.stroke();
    const hot=state.hover;
    if(hot&&hot.index===index) {
      ctx.setLineDash([4,3]);ctx.strokeStyle=gold;ctx.lineWidth=2;
      ctx.strokeRect(cx-bw/2-7,top-5,bw+14,bh+10);ctx.setLineDash([]);
    }
    hits.push({kind:'block',index,x:cx-bw/2-8,y:top-2,w:bw+16,h:Math.max(bh+6,44)});
    hits.push({kind:'load',index,x:cx-25,y:rackTop-25,w:50,h:Math.max(top-rackTop+24,50)});
    // 压力作用在海绵上，箭头起于接触面，向下；长度只随F改变。
    arrow(cx,base+d+3,18+data.force*1.2);
    text(`F = ${data.force} N`,cx+10,base+d+27,12,gold);
    text('相同海绵 · 形变示意',cx,bottom+33,10,'#8193aa','center');
    // 底面俯视，不用透视图中投影长度冒充面积。
    const by=bottom+67, scale=mobileMode?6:9;
    const fw=face.width*scale,fd=face.depth*scale;
    box(cx-fw/2,by,fw,fd,'#ffc94a23',gold,1);
    text('接触底面 · 俯视',cx,by-12,10,'#8193aa','center');
    text(`${face.width} × ${face.depth} cm`,cx,by+fd+17,11,ink,'center');
    text(`S = ${data.area} cm²`,cx,by+fd+35,12,gold,'center');
  }
  function render(canvas,state,visual) {
    const rect=canvas.getBoundingClientRect(),dpr=Math.min(devicePixelRatio||1,2);
    if(canvas.width!==Math.round(rect.width*dpr)||canvas.height!==Math.round(rect.height*dpr)){canvas.width=Math.round(rect.width*dpr);canvas.height=Math.round(rect.height*dpr);}
    ctx=canvas.getContext('2d');ctx.setTransform(dpr,0,0,dpr,0,0);
    const mobile=rect.width<650;mobileMode=mobile;
    const W=mobile?390:900,H=mobile?440:560;
    const scale=Math.min(rect.width/W,rect.height/H),ox=(rect.width-W*scale)/2,oy=(rect.height-H*scale)/2;
    ctx.fillStyle='#05070d';ctx.fillRect(0,0,rect.width,rect.height);
    ctx.translate(ox,oy);ctx.scale(scale,scale);hits=[];transform={scale,ox,oy};
    line(W/2,20,W/2,H-14,'#213043');
    if(mobile){rig(0,8,0,180,H,state,visual);rig(1,202,0,180,H,state,visual);}
    else{rig(0,24,0,402,H,state,visual);rig(1,474,0,402,H,state,visual);}
    return transform;
  }
  function hit(x,y){if(!transform)return null;const px=(x-transform.ox)/transform.scale,py=(y-transform.oy)/transform.scale;return hits.filter(h=>Math.abs(px-(h.x+h.w/2))<=Math.max(h.w/2,22/transform.scale)&&Math.abs(py-(h.y+h.h/2))<=Math.max(h.h/2,22/transform.scale)).sort((a,b)=>Math.hypot(px-a.x-a.w/2,py-a.y-a.h/2)-Math.hypot(px-b.x-b.w/2,py-b.y-b.h/2))[0]||null;}
  function targets(){return hits.map(h=>({...h,cx:transform.ox+(h.x+h.w/2)*transform.scale,cy:transform.oy+(h.y+h.h/2)*transform.scale}));}
  window.PressureDraw={render,hit,targets};
})();
