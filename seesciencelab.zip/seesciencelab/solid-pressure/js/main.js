(function () {
  'use strict';
  const P=window.Pressure,D=window.PressureDraw,$=id=>document.getElementById(id);
  const query=new URLSearchParams(location.search);
  const scene=['area','force','explore'].includes(query.get('scene'))?query.get('scene'):'area';
  const state={scene,groups:P.preset(scene),hover:null};
  // 先解析两组，再应用对照约束。甲组参数为对照共同量的来源。
  for(let i=0;i<2;i++) {
    if(P.faces[query.get('face'+i)])state.groups[i].face=query.get('face'+i);
    if(query.has('load'+i)&&Number.isFinite(+query.get('load'+i)))state.groups[i].load=P.clamp(Math.round(+query.get('load'+i)),0,3);
  }
  if(scene==='area')state.groups[1].load=state.groups[0].load;
  if(scene==='force')state.groups[1].face=state.groups[0].face;
  let visual=state.groups.map(g=>P.dent(P.solve(g).pressure));
  let drag=null, previous=performance.now(),records=[];
  const canvas=$('canvas');
  function track(action,label){if(window.Analytics)window.Analytics.track('固体压强与海绵实验',action,String(label));}
  function message(s){$('message').textContent=s;}
  function update(){
    const c=P.compare(state.groups);
    $('stageTitle').textContent=state.scene==='area'?'同样重，为什么陷得不同？':state.scene==='force'?'底面相同，加重会怎样？':'压力更大，压强一定更大吗？';
    $('condition').textContent=c.a.force===c.b.force?'压力相同 · '+c.a.force+' N':c.a.area===c.b.area?'面积相同 · '+c.a.area+' cm²':'同时比较压力与面积';
    $('ratio').textContent='乙 / 甲压强 = '+Number(c.ratio.toFixed(2))+' 倍';
    document.querySelectorAll('[data-scene]').forEach(b=>{b.classList.toggle('on',b.dataset.scene===state.scene);b.setAttribute('aria-pressed',b.dataset.scene===state.scene);});
    for(let i=0;i<2;i++){$('face'+i).value=state.groups[i].face;$('load'+i).value=state.groups[i].load;$('loadOut'+i).value=`${state.groups[i].load} 枚`;}
    $('status').textContent=`乙组压强是甲组的 ${c.ratio.toFixed(2)} 倍`;
    $('explain').textContent=c.reason;
    [c.a,c.b].forEach((v,i)=>{$(i?'rightRead':'leftRead').textContent=`${v.force} N / ${v.area} cm² / ${v.pressure.toFixed(0)} Pa`;});
  }
  function setScene(name){if(!['area','force','explore'].includes(name))return;state.scene=name;state.groups=P.preset(name);update();track('切换',name);}
  function change(i,key,value){P.change(state,i,key,value);update();}
  function link(){const q=new URLSearchParams({scene:state.scene});state.groups.forEach((g,i)=>{q.set('face'+i,g.face);q.set('load'+i,g.load);});return `${location.origin}${location.pathname}?${q}`;}
  document.querySelectorAll('[data-scene]').forEach(b=>b.onclick=()=>setScene(b.dataset.scene));
  for(let i=0;i<2;i++){
    $('face'+i).onchange=e=>{change(i,'face',e.target.value);track('翻面',i+':'+e.target.value);};
    $('load'+i).oninput=e=>change(i,'load',+e.target.value);
    $('load'+i).onchange=e=>track('砝码',i+':'+e.target.value);
  }
  $('reset').onclick=()=>{state.groups=P.preset(state.scene);update();track('重置',state.scene);};
  $('record').onclick=()=>{
    const c=P.compare(state.groups);records.push([c.a,c.b]);records=records.slice(-6);
    $('records').innerHTML='<table><thead><tr><th>组</th><th>F/N</th><th>S/cm²</th><th>p/Pa</th></tr></thead><tbody>'+records.map((row,j)=>row.map((v,i)=>`<tr><td>${j+1}${i?'乙':'甲'}</td><td>${v.force}</td><td>${v.area}</td><td>${v.pressure.toFixed(0)}</td></tr>`).join('')).join('')+'</tbody></table>';
    document.querySelector('.record-details').open=true;message('已记录当前两组，最多保留最近6次。');track('记录',state.scene);
  };
  $('share').onclick=async()=>{
    try{await navigator.clipboard.writeText(link());message('当前条件链接已复制。');}
    catch{message('请复制：'+link());}track('分享',state.scene);
  };
  $('panelToggle').onclick=()=>{const closed=$('panel').classList.toggle('collapsed');$('panelToggle').setAttribute('aria-expanded',!closed);};
  if(matchMedia('(max-width:760px)').matches)$('panel').classList.add('collapsed');
  $('panelToggle').setAttribute('aria-expanded',!$('panel').classList.contains('collapsed'));
  $('panelToggle').setAttribute('aria-controls','panel');
  function point(e){const r=canvas.getBoundingClientRect();return{x:e.clientX-r.left,y:e.clientY-r.top};}
  canvas.onpointerdown=e=>{
    const p=point(e),h=D.hit(p.x,p.y);if(!h)return;
    drag={...h,startY:p.y,startLoad:state.groups[h.index].load,moved:false};
    canvas.setPointerCapture(e.pointerId);state.hover=h;canvas.style.cursor=h.kind==='load'?'ns-resize':'pointer';
  };
  canvas.onpointermove=e=>{
    const p=point(e);
    if(drag){
      if(Math.abs(p.y-drag.startY)>8)drag.moved=true;
      if(drag.kind==='load')change(drag.index,'load',drag.startLoad+Math.round((drag.startY-p.y)/30));
    }else{state.hover=D.hit(p.x,p.y);canvas.style.cursor=state.hover?(state.hover.kind==='load'?'ns-resize':'pointer'):'default';}
  };
  function finish(e,cancel){
    if(!drag)return;
    if(!cancel){
      if(!drag.moved){if(drag.kind==='block'){const keys=Object.keys(P.faces);change(drag.index,'face',keys[(keys.indexOf(state.groups[drag.index].face)+1)%keys.length]);}else change(drag.index,'load',(state.groups[drag.index].load+1)%4);}
      track(drag.kind==='block'?'画面翻面':'画面砝码',drag.index+':'+JSON.stringify(state.groups[drag.index]));
    }
    drag=null;state.hover=null;if(canvas.hasPointerCapture(e.pointerId))canvas.releasePointerCapture(e.pointerId);
  }
  canvas.onpointerup=e=>finish(e,false);canvas.onpointercancel=e=>finish(e,true);
  canvas.onpointerleave=()=>{if(!drag)state.hover=null;};
  function frame(now){
    const dt=Math.min((now-previous)/1000,.1);previous=now;
    state.groups.forEach((g,i)=>{const target=P.dent(P.solve(g).pressure);visual[i]=matchMedia('(prefers-reduced-motion: reduce)').matches?target:visual[i]+(target-visual[i])*(1-Math.exp(-dt*7));});
    D.render(canvas,state,visual);requestAnimationFrame(frame);
  }
  window.__model={state,setScene,change,update,link,solve:()=>P.compare(state.groups),targets:D.targets};
  update();requestAnimationFrame(frame);
})();
