(function () {
  var Mo = window.Molecule;
  var $ = function (id) { return document.getElementById(id); };
  var qa = function (sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); };
  var NAME = '分子的空间结构';

  var state = {
    scene: 'vsepr', m: 'nh3', us: null, ws: null, conv: true, drag: -1,
    model: 'ball', lp: true, frame: false, angle: true, spin: true,
    h: 'ch4', step: 2, ph: 2,
    quiz: null, quizOnly: null, answered: false, correct: false, choice: null, score: { n: 0, ok: 0 }
  };
  var HINTS = {
    vsepr: '拖动旋转、滚轮缩放；按住一个原子或孤电子对拖开，松手看电子对怎样重新排开',
    hybrid: '杂化轨道：按步骤看原子轨道 → 杂化轨道 → 形成共价键',
    quiz: '分子的空间结构 · 判断练习'
  };
  var STEPS = ['原子轨道', '杂化轨道', '形成共价键'];

  var stage = $('stage'), panel = $('panel');
  var sc3 = null;
  try { sc3 = window.MoleculeScene(stage); } catch (e) { sc3 = null; }
  if (!sc3) $('hint').textContent = '此浏览器不支持 WebGL，无法显示 3D 分子；面板中的计算和练习仍可使用';
  function setSeg(attr, val) { qa('[data-' + attr + ']').forEach(function (b) { b.classList.toggle('on', b.dataset[attr] === String(val)); }); }
  function mol() { return Mo.M[state.m]; }

  // ---------- 选择分子 ----------
  $('picker').innerHTML = Mo.GROUPS.map(function (g) {
    return '<h3>' + g.name + '</h3><div class="presets xs">' + g.list.map(function (id) {
      var m = Mo.M[id], v = Mo.vsepr(m);
      return '<button data-m="' + id + '"><b>' + m.f + '</b><small>' + v.shape + '</small></button>';
    }).join('') + '</div>';
  }).join('');
  qa('[data-m]').forEach(function (b) {
    b.addEventListener('click', function () { setMol(b.dataset.m); Analytics.track(NAME, '分子', mol().f); });
  });
  function setMol(id, shuffled) {
    state.m = id;
    state.ws = Mo.weights(Mo.M[id]);
    state.us = shuffled ? Mo.randomDirs(state.ws.length, Math.random) : Mo.initDirs(Mo.M[id]);
    state.conv = !shuffled; state.drag = -1;
    syncUI();
  }
  $('picker2').innerHTML = '<div class="presets xs">' + Mo.HY_LIST.map(function (id) {
    var h = Mo.HY[id];
    return '<button data-h="' + id + '"><b>' + h.f + '</b><small>' + h.type + '</small></button>';
  }).join('') + '</div>';
  qa('[data-h]').forEach(function (b) {
    b.addEventListener('click', function () { state.h = b.dataset.h; state.step = 0; state.ph = 0; syncUI(); Analytics.track(NAME, '杂化', Mo.HY[state.h].f); });
  });

  // ---------- 控件 ----------
  qa('[data-scene]').forEach(function (b) {
    b.addEventListener('click', function () { setScene(b.dataset.scene); Analytics.track(NAME, '场景', b.textContent); });
  });
  function setScene(s) {
    state.scene = s;
    if (s === 'quiz' && !state.quiz) newQuiz();
    if (sc3) sc3.setMode(s === 'hybrid' ? 'h' : 'v');
    syncUI();
  }
  qa('[data-model]').forEach(function (b) { b.addEventListener('click', function () { state.model = b.dataset.model; syncUI(); Analytics.track(NAME, '模型', b.textContent); }); });
  qa('[data-step]').forEach(function (b) { b.addEventListener('click', function () { state.step = +b.dataset.step; syncUI(); Analytics.track(NAME, '杂化步骤', b.textContent); }); });
  [['lp', 'lp'], ['frame', 'frame'], ['angle', 'angle']].forEach(function (p) {
    $(p[0]).addEventListener('change', function () { state[p[1]] = $(p[0]).checked; syncUI(); Analytics.track(NAME, '显示', p[1] + (state[p[1]] ? ' 开' : ' 关')); });
  });
  $('spin').addEventListener('change', function () { state.spin = $('spin').checked; if (sc3) sc3.controls.autoRotate = state.spin; });
  qa('.homeBtn').forEach(function (b) { b.addEventListener('click', function () { if (sc3) sc3.home(); }); });
  $('shuffle').addEventListener('click', function () { setMol(state.m, true); Analytics.track(NAME, '打乱重排', mol().f); });
  $('playH').addEventListener('click', function () {
    state.step = 0; state.ph = 0; play = 1; syncUI(); Analytics.track(NAME, '杂化播放', Mo.HY[state.h].f);
  });
  var play = 0;   // 播放时依次走完三步

  // 拖动电子对（在容器上捕获，先于 OrbitControls 处理）
  if (sc3) {
    stage.addEventListener('pointerdown', function (e) {
      if (e.target !== sc3.canvas || state.scene !== 'vsepr' || state.model !== 'ball') return;
      var i = sc3.pick(e.clientX, e.clientY);
      if (i < 0 || (i >= mol().L.length && !state.lp)) return;
      state.drag = i; state.conv = false;
      sc3.controls.enabled = false;
      sc3.canvas.setPointerCapture(e.pointerId);
      Analytics.track(NAME, '拖动电子对', mol().f);
    }, true);
    sc3.canvas.addEventListener('pointermove', function (e) {
      if (state.drag < 0) return;
      state.us[state.drag] = sc3.dirAt(e.clientX, e.clientY, state.drag);
    });
    var up = function () { if (state.drag >= 0) { state.drag = -1; state.conv = false; sc3.controls.enabled = true; } };
    sc3.canvas.addEventListener('pointerup', up);
    sc3.canvas.addEventListener('pointercancel', up);
  }

  // ---------- 练习 ----------
  function newQuiz() {
    state.quiz = Mo.quiz(Math.random, state.quiz, state.quizOnly);
    state.answered = false; state.choice = null;
    var box = $('quizOpts');
    box.innerHTML = '';
    state.quiz.options.forEach(function (o) {
      var b = document.createElement('button');
      b.className = 'small';
      b.textContent = o;
      b.addEventListener('click', function () { answer(o); });
      box.appendChild(b);
    });
    box.classList.toggle('four', state.quiz.options.every(function (o) { return o.length <= 6; }));
    syncUI();
  }
  function answer(o) {
    if (state.answered) return;
    state.answered = true; state.choice = o;
    state.correct = o === state.quiz.answer;
    state.score.n++; if (state.correct) state.score.ok++;
    quizDirs = Mo.initDirs(Mo.M[state.quiz.id]);
    Analytics.track(NAME, '练习', state.quiz.type + (state.correct ? ' 对' : ' 错'));
    syncUI();
  }
  var quizDirs = null;
  $('nextQ').addEventListener('click', newQuiz);
  $('showQ').addEventListener('click', function () {
    var q = state.quiz;
    state.model = 'ball'; state.lp = true;
    if (q.type !== 'angle') state.frame = true;
    setMol(q.id);
    setScene('vsepr');
    Analytics.track(NAME, '练习 → 模型', q.type);
  });

  // ---------- 面板 ----------
  $('panelToggle').addEventListener('click', function () { panel.classList.toggle('collapsed'); });
  if (window.matchMedia('(max-width: 760px)').matches) panel.classList.add('collapsed');

  function syncUI() {
    var s = state.scene;
    setSeg('scene', s);
    qa('[data-for]').forEach(function (el) { el.hidden = el.dataset.for.split(' ').indexOf(s) < 0; });
    if (sc3) $('hint').textContent = HINTS[s];
    setSeg('m', state.m); setSeg('h', state.h); setSeg('model', state.model); setSeg('step', state.step);
    $('lp').checked = state.lp; $('frame').checked = state.frame; $('angle').checked = state.angle; $('spin').checked = state.spin;
    ['lp', 'frame', 'angle'].forEach(function (k) { $(k).disabled = state.model === 'fill'; });
    if (sc3) sc3.spin(state.spin);
    steps();
    cfg();
    var q = state.quiz;
    if (q) {
      $('quizQ').textContent = q.prompt;
      qa('#quizOpts button').forEach(function (b) {
        b.disabled = state.answered;
        b.classList.toggle('on', state.answered && b.textContent === q.answer);
        b.classList.toggle('no', state.answered && b.textContent === state.choice && !state.correct);
      });
      $('quizMsg').innerHTML = !state.answered ? ''
        : '<b class="' + (state.correct ? 'ok">✓ 答对了' : 'bad">✗ 应选「' + q.answer + '」') + '</b>' + q.explain;
      $('nextQ').textContent = state.answered ? '下一题 →' : '换一题';
      $('showQ').hidden = !state.answered;
    }
    $('cover').hidden = !(s === 'quiz' && q && !state.answered);
    if (s === 'quiz' && q) $('coverF').textContent = q.type === 'angle' || q.type === 'polar' ? '？' : Mo.M[q.id].f;
    legend();
  }
  // VSEPR 计算步骤
  function steps() {
    var m = mol(), v = Mo.vsepr(m), e = Mo.EL[m.c];
    var bs = m.L.map(function (l) { return l[0]; }), uniq = bs.filter(function (x, i) { return bs.indexOf(x) === i; });
    var bTxt = uniq.map(function (x) { var c = bs.filter(function (y) { return y === x; }).length; return x + ' 的 b = ' + Mo.bOf(x) + (c > 1 ? '（' + c + ' 个）' : ''); }).join('，');
    var html = [
      '中心原子 <b>' + m.c + '</b>（' + e.name + '）价电子数 ' + v.ev + (v.q ? '，' + (v.q < 0 ? '阴离子加上' : '阳离子减去') + '电荷数 ' + Math.abs(v.q) + '，a = ' + v.a : '，a = ' + v.a),
      'σ 键电子对数 = 结合原子数 x = <b>' + v.x + '</b>；' + bTxt,
      '孤电子对数 = ½(a − Σb) = ½(' + v.a + ' − ' + v.sumB + ') = <b>' + v.lp + '</b>',
      '价层电子对数 = ' + v.x + ' + ' + v.lp + ' = <b>' + v.n + '</b>，VSEPR 模型：<b>' + v.model + '</b>',
      (v.lp ? '略去 ' + v.lp + ' 对孤电子对' : '没有孤电子对，与 VSEPR 模型相同') + '，空间结构：<b class="gold">' + v.shape + '</b>',
      '杂化轨道数 = 价层电子对数 = ' + v.n + '，中心原子 <b>' + v.hyb + '</b> 杂化' + (m.ext ? '（涉及 d 轨道，拓展）' : '')
    ];
    $('steps').innerHTML = html.map(function (h) { return '<li>' + h + '</li>'; }).join('');
  }
  // 轨道表示式
  function cfg() {
    var hy = Mo.HY[state.h], cur = state.step === 0 ? 0 : hy.cfg.length - 1;
    $('cfg').innerHTML = hy.cfg.map(function (row, k) {
      return '<div class="cfg-row' + (k === cur ? ' on' : '') + '"><span class="cfg-n">' + row[0] + '</span>' + row[1].map(function (sh) {
        return '<span class="sh"><span class="boxes' + (/sp/.test(sh[0]) ? ' hy' : '') + '">' + sh[1].map(function (n) {
          return '<i>' + (n === 2 ? '↑↓' : n === 1 ? '↑' : '') + '</i>';
        }).join('') + '</span><small>' + sh[0] + '</small></span>';
      }).join('') + '</div>' + (k < hy.cfg.length - 1 ? '<div class="cfg-arr">↓ ' + (hy.cfg[k + 1][0].indexOf('激发') >= 0 ? '激发' : '杂化') + '</div>' : '');
    }).join('');
    $('hyNote').textContent = hy.note;
  }
  function legend() {
    var s = state.scene, html = '';
    if (s === 'hybrid') {
      html = '<span><i style="background:#ffb74d"></i>s 轨道</span><span><i style="background:#4fc3f7"></i>p 轨道</span>'
        + '<span><i style="background:#7ee081"></i>杂化轨道</span>' + (Mo.HY[state.h].centers[0].lone.length ? '<span><i style="background:#c9a7ff"></i>孤电子对</span>' : '');
    } else if (s === 'vsepr' || state.answered) {
      var m = s === 'vsepr' ? mol() : Mo.M[state.quiz.id], seen = {};
      [m.c].concat(m.L.map(function (l) { return l[0]; })).forEach(function (el) {
        if (seen[el]) return; seen[el] = 1;
        html += '<span><i style="background:' + Mo.EL[el].col + '"></i>' + el + '</span>';
      });
      if (Mo.vsepr(m).lp && state.model === 'ball' && state.lp) html += '<span><i style="background:#c9a7ff;opacity:.7"></i>孤电子对</span>';
      if (m.q) html += '<span class="chg">离子：带 ' + Math.abs(m.q) + ' 个单位' + (m.q < 0 ? '负' : '正') + '电荷</span>';
    }
    $('legend').innerHTML = html;
  }

  // ---------- 读数 ----------
  var lastText = {};
  function setText(id, t) { if (lastText[id] !== t) { lastText[id] = t; $(id).textContent = t; } }
  function rows(list) {
    for (var k = 1; k <= 6; k++) {
      var r = list[k - 1] || ['', ''];
      setText('d' + k, r[0]); setText('r' + k, r[1]);
      $('d' + k).hidden = $('r' + k).hidden = !r[0];
    }
  }
  function readVsepr() {
    var m = mol(), v = Mo.vsepr(m);
    setText('rName', m.f + ' ' + m.name);
    $('rName').className = '';
    setText('rKind', v.shape);
    var angs = m.ang.map(function (a) {
      var nm = m.L[a[0]][0] + '–' + m.c + '–' + m.L[a[1]][0];
      var live = Mo.angle(state.us[a[0]], state.us[a[1]]).toFixed(1) + '°';
      return nm + ' ' + (state.conv && a[2] ? a[2] : '≈ ' + live);
    }).join('，');
    rows([
      ['电子对', '价层 ' + v.n + ' = σ 键 ' + v.x + ' + 孤电子对 ' + v.lp],
      ['VSEPR 模型', v.model],
      ['空间结构', v.shape],
      ['杂化', v.hyb + (m.ext ? '（拓展）' : '')],
      ['键角', angs + (state.conv ? '' : '（排布中）')],
      ['极性', v.polar == null ? '离子（不讨论分子极性）' : v.polar ? '极性分子' : '非极性分子']
    ]);
    var tip;
    if (state.drag >= 0) tip = '拖住的电子对把其他电子对推开了；松手后它们会重新排开，回到斥力最小、彼此尽可能远离的位置。';
    else if (!state.conv) tip = '价层电子对之间相互排斥，正在重新排开……';
    else if (v.lp) tip = '中心原子上有 ' + v.lp + ' 对孤电子对：VSEPR 模型是' + v.model + '，略去孤电子对后分子呈' + v.shape + '。孤电子对的排斥作用更大，键角比 ' + (v.n === 4 ? '109°28′' : '120°') + ' 小。';
    else tip = '中心原子上没有孤电子对，价层电子对彼此尽可能远离，分子的空间结构就是 VSEPR 模型：' + v.model + '。';
    setText('rTip', tip);
  }
  function readHybrid() {
    var hy = Mo.HY[state.h];
    setText('rName', hy.f);
    $('rName').className = '';
    setText('rKind', hy.type + ' 杂化');
    var nH = hy.centers[0].dirs.length, ang = { sp: '180°', 'sp²': '120°', 'sp³': '109°28′' }[hy.type];
    rows([
      ['步骤', (state.step + 1) + ' / 3　' + STEPS[state.step]],
      ['杂化轨道', hy.centers.length > 1 ? '每个 C 原子 ' + nH + ' 个 ' + hy.type : nH + ' 个 ' + hy.type + (hy.centers[0].lone.length ? '（其中 ' + hy.centers[0].lone.length + ' 个含孤电子对）' : '')],
      ['轨道夹角', ang + ({ nh3: '（实际键角 107°）', h2o: '（实际键角 105°）' }[state.h] || '')],
      ['共价键', hy.pi ? 'σ 键 ' + (hy.L.length + 1) + ' 个、π 键 ' + hy.pi.length + ' 个' : 'σ 键 ' + hy.L.length + ' 个']
    ]);
    var tips = [
      '中心原子的价层原子轨道：球形的 s 轨道、哑铃形的 p 轨道（两瓣符号相反，颜色深浅表示）。',
      '能量相近的 s、p 轨道“混杂”起来，重新组合成数目相同、能量相同、方向不同的杂化轨道：一头大、一头小，大的一头用来成键。',
      '杂化轨道与结合原子的轨道沿键轴“头碰头”重叠形成 σ 键' + (hy.pi ? '；未参与杂化的 p 轨道“肩并肩”重叠形成 π 键' : '') + '。'
    ];
    setText('rTip', tips[state.step]);
  }
  function readQuiz() {
    var q = state.quiz, s = state.score;
    setText('rName', !state.answered ? '判断练习' : state.correct ? '✓ 答对了' : '✗ 答错了');
    $('rName').className = !state.answered ? '' : state.correct ? 'ok' : 'bad';
    setText('rKind', '得分 ' + s.ok + ' / ' + s.n);
    setText('rTip', state.answered ? q.explain : q.prompt);
    rows([]);
  }

  // ---------- 尺寸与主循环 ----------
  function resize() { if (sc3) { sc3.resize(stage.clientWidth, stage.clientHeight); } }
  new ResizeObserver(resize).observe(stage);

  // 支持 ?scene=vsepr|hybrid|quiz、&m=分子代号、&model=ball|fill、&lp=0、&frame=1、&angle=0、&spin=0、&shuffle=1，
  // 杂化 &h=becl2|bf3|ch4|nh3|h2o|c2h4|c2h2、&step=1|2|3，练习 &q=shape|count|hybrid|angle|polar
  var qs = new URLSearchParams(location.search);
  if (HINTS[qs.get('scene')]) state.scene = qs.get('scene');
  if (Mo.M[qs.get('m')]) state.m = qs.get('m');
  if (qs.get('model') === 'fill') state.model = 'fill';
  if (qs.get('lp') === '0') state.lp = false;
  if (qs.get('frame') === '1') state.frame = true;
  if (qs.get('angle') === '0') state.angle = false;
  if (qs.get('spin') === '0') state.spin = false;
  if (Mo.HY[qs.get('h')]) state.h = qs.get('h');
  if (/^[123]$/.test(qs.get('step') || '')) state.step = state.ph = +qs.get('step') - 1;
  if (Mo.TYPES.indexOf(qs.get('q')) >= 0) state.quizOnly = qs.get('q');
  resize();
  setMol(state.m, qs.get('shuffle') === '1');
  setScene(state.scene);

  var last = performance.now(), holdT = 0;
  function frame(now) {
    var dt = Math.min(0.05, (now - last) / 1000);
    last = now;
    var s = state.scene;
    if (s === 'vsepr') {
      if (!state.conv || state.drag >= 0) {
        var mv = Mo.relax(state.us, state.ws, state.drag, 4, 0.03);
        if (state.drag < 0 && mv < 2e-5) { Mo.relax(state.us, state.ws, -1, 600, 0.05); state.conv = true; }
      }
      if (sc3) sc3.vsepr({ id: state.m, us: state.us, model: state.model, lp: state.lp, frame: state.frame, angle: state.angle, conv: state.conv });
      readVsepr();
    } else if (s === 'hybrid') {
      if (play && Math.abs(state.ph - state.step) < 0.01) {
        holdT += dt;
        if (holdT > 1.2) { holdT = 0; if (state.step < 2) { state.step++; syncUI(); } else play = 0; }
      }
      var d = state.step - state.ph;
      state.ph += Math.sign(d) * Math.min(Math.abs(d), dt * 1.2);
      if (sc3) sc3.hybrid({ id: state.h, ph: state.ph });
      readHybrid();
    } else {
      var q = state.quiz;
      if (sc3 && q && state.answered) sc3.vsepr({ id: q.id, us: quizDirs, model: 'ball', lp: true, frame: true, angle: true, conv: true });
      else if (sc3) sc3.blank();
      readQuiz();
    }
    if (sc3) sc3.render();
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // 调试用
  window.__model = {
    state: state, Mo: Mo, scene: sc3, setMol: setMol, setScene: setScene, newQuiz: newQuiz, sync: syncUI,
    answer: function (o) { answer(o == null ? state.quiz.answer : o); }
  };
})();
