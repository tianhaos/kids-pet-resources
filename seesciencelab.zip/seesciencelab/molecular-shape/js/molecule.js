// 分子的空间结构：VSEPR 计算、电子对互斥的数值模拟、杂化轨道数据、练习题（纯计算，不碰 DOM）
// 方向向量用 three.js 坐标 [x, y, z]（y 向上），长度单位 pm
(function () {
  // 价电子数、结合原子最多能接受的电子数 b（H 为 1，其余为 8 − 价电子数）
  var EL = {
    H: { v: 1, name: '氢', col: '#e8eef5', r: 31, vdw: 120 },
    Be: { v: 2, name: '铍', col: '#c7f26b', r: 96, vdw: 153 },
    B: { v: 3, name: '硼', col: '#ffb38a', r: 84, vdw: 192 },
    C: { v: 4, name: '碳', col: '#9aa3ad', r: 76, vdw: 170 },
    N: { v: 5, name: '氮', col: '#5b8cff', r: 71, vdw: 155 },
    O: { v: 6, name: '氧', col: '#ff5a5a', r: 66, vdw: 152 },
    F: { v: 7, name: '氟', col: '#9be36a', r: 57, vdw: 147 },
    P: { v: 5, name: '磷', col: '#ff9f40', r: 107, vdw: 180 },
    S: { v: 6, name: '硫', col: '#ffd43b', r: 105, vdw: 180 },
    Cl: { v: 7, name: '氯', col: '#4cd06a', r: 102, vdw: 175 }
  };
  function bOf(el) { return el === 'H' ? 1 : 8 - EL[el].v; }

  // 价层电子对数 → VSEPR 模型、杂化方式
  var MODEL = { 2: '直线形', 3: '平面三角形', 4: '四面体形', 5: '三角双锥形', 6: '正八面体形' };
  var HYB = { 2: 'sp', 3: 'sp²', 4: 'sp³', 5: 'sp³d', 6: 'sp³d²' };
  // [价层电子对数][孤电子对数] → 分子空间结构
  var SHAPE = { 2: ['直线形'], 3: ['平面三角形', 'V 形'], 4: ['正四面体形', '三角锥形', 'V 形'], 5: ['三角双锥形'], 6: ['正八面体形'] };
  var IDEAL = { 2: 180, 3: 120, 4: 109.47, 5: 90, 6: 90 };

  // 分子与离子
  // c 中心原子；q 电荷；L 结合原子 [元素, 键长 pm, 键级（只用于画双键、三键）, 斥力权重]；lw 孤电子对的斥力权重
  // ang 键角标注 [i, j, 文字]（i、j 为 L 的下标；文字为 null 时显示模拟值）
  // 斥力权重是示意参数：让模拟出的键角与实测值相近（孤电子对 > 双键 > 单键）
  var M = {
    becl2: { f: 'BeCl₂', name: '氯化铍（气态）', c: 'Be', L: [['Cl', 177], ['Cl', 177]], ang: [[0, 1, '180°']] },
    co2: { f: 'CO₂', name: '二氧化碳', c: 'C', L: [['O', 116, 2], ['O', 116, 2]], ang: [[0, 1, '180°']] },
    hcn: { f: 'HCN', name: '氢氰酸', c: 'C', L: [['H', 107], ['N', 116, 3]], ang: [[0, 1, '180°']] },
    bf3: { f: 'BF₃', name: '三氟化硼', c: 'B', L: [['F', 131], ['F', 131], ['F', 131]], ang: [[0, 1, '120°']] },
    so3: { f: 'SO₃', name: '三氧化硫', c: 'S', L: [['O', 142], ['O', 142], ['O', 142]], ang: [[0, 1, '120°']] },
    hcho: { f: 'HCHO', name: '甲醛', c: 'C', L: [['H', 111], ['H', 111], ['O', 121, 2, 1.2]], ang: [[0, 1, '116.5°'], [0, 2, '121.8°']] },
    co3: { f: 'CO₃²⁻', name: '碳酸根离子', c: 'C', q: -2, L: [['O', 129], ['O', 129], ['O', 129]], ang: [[0, 1, '120°']] },
    no3: { f: 'NO₃⁻', name: '硝酸根离子', c: 'N', q: -1, L: [['O', 124], ['O', 124], ['O', 124]], ang: [[0, 1, '120°']] },
    so2: { f: 'SO₂', name: '二氧化硫', c: 'S', L: [['O', 143, 1, 1.25], ['O', 143, 1, 1.25]], ang: [[0, 1, '约 119°']] },
    ch4: { f: 'CH₄', name: '甲烷', c: 'C', L: [['H', 109], ['H', 109], ['H', 109], ['H', 109]], ang: [[0, 1, '109°28′']] },
    ccl4: { f: 'CCl₄', name: '四氯化碳', c: 'C', L: [['Cl', 177], ['Cl', 177], ['Cl', 177], ['Cl', 177]], ang: [[0, 1, '109°28′']] },
    nh4: { f: 'NH₄⁺', name: '铵根离子', c: 'N', q: 1, L: [['H', 103], ['H', 103], ['H', 103], ['H', 103]], ang: [[0, 1, '109°28′']] },
    so4: { f: 'SO₄²⁻', name: '硫酸根离子', c: 'S', q: -2, L: [['O', 149], ['O', 149], ['O', 149], ['O', 149]], ang: [[0, 1, '109°28′']] },
    nh3: { f: 'NH₃', name: '氨', c: 'N', L: [['H', 101], ['H', 101], ['H', 101]], ang: [[0, 1, '107°']] },
    h3o: { f: 'H₃O⁺', name: '水合氢离子', c: 'O', q: 1, L: [['H', 98], ['H', 98], ['H', 98]], ang: [[0, 1, null]] },
    pcl3: { f: 'PCl₃', name: '三氯化磷', c: 'P', L: [['Cl', 204], ['Cl', 204], ['Cl', 204]], lw: 2.4, ang: [[0, 1, '约 100°']] },
    h2o: { f: 'H₂O', name: '水', c: 'O', L: [['H', 96], ['H', 96]], ang: [[0, 1, '105°']] },
    pcl5: { f: 'PCl₅', name: '五氯化磷（气态）', c: 'P', ext: 1, L: [['Cl', 214], ['Cl', 214], ['Cl', 202], ['Cl', 202], ['Cl', 202]], ang: [[0, 2, '90°'], [2, 3, '120°']] },
    sf6: { f: 'SF₆', name: '六氟化硫', c: 'S', ext: 1, L: [['F', 156], ['F', 156], ['F', 156], ['F', 156], ['F', 156], ['F', 156]], ang: [[0, 2, '90°']] }
  };
  var GROUPS = [
    { name: '2 对：直线形', list: ['becl2', 'co2', 'hcn'] },
    { name: '3 对：平面三角形', list: ['bf3', 'so3', 'hcho', 'co3', 'no3', 'so2'] },
    { name: '4 对：四面体形', list: ['ch4', 'ccl4', 'nh4', 'so4', 'nh3', 'h3o', 'pcl3', 'h2o'] },
    { name: '5、6 对（拓展）', list: ['pcl5', 'sf6'] }
  ];
  var LW = 1.3;   // 孤电子对默认斥力权重（NH₃ 107°、H₂O 105°）

  // 价层电子对互斥模型的计算
  function vsepr(m) {
    var ev = EL[m.c].v, q = m.q || 0, a = ev - q, x = m.L.length, sb = 0;
    m.L.forEach(function (l) { sb += bOf(l[0]); });
    var lp = (a - sb) / 2, n = x + lp;
    var polar = null;
    if (!q) {
      // 中心原子无孤电子对、且结合原子相同时正负电荷中心重合
      var same = m.L.every(function (l) { return l[0] === m.L[0][0] && l[1] === m.L[0][1]; });
      polar = !(lp === 0 && (same || x >= 5));
    }
    return {
      a: a, ev: ev, q: q, x: x, bs: m.L.map(function (l) { return bOf(l[0]); }), sumB: sb,
      lp: lp, sigma: x, n: n, model: MODEL[n], shape: SHAPE[n][lp], hyb: HYB[n], polar: polar
    };
  }

  // ---------- 电子对互斥：单位球面上的点 ----------
  // E = Σ wᵢwⱼ / |uᵢ − uⱼ|^K；沿切向梯度下降，pin 为被拖住的电子对
  var K = 3;
  function weights(m) {
    var w = m.L.map(function (l) { return l[3] || 1; }), lp = vsepr(m).lp;
    for (var i = 0; i < lp; i++) w.push(m.lw || LW);
    return w;
  }
  function norm(v) { var l = Math.hypot(v[0], v[1], v[2]) || 1; return [v[0] / l, v[1] / l, v[2] / l]; }
  function relax(us, ws, pin, iters, eta) {
    var n = us.length, moved = 0;
    eta = eta || 0.05;
    for (var it = 0; it < iters; it++) {
      moved = 0;
      var F = [];
      for (var i = 0; i < n; i++) {
        var f = [0, 0, 0];
        for (var j = 0; j < n; j++) {
          if (i === j) continue;
          var d = [us[i][0] - us[j][0], us[i][1] - us[j][1], us[i][2] - us[j][2]];
          var r = Math.max(1e-3, Math.hypot(d[0], d[1], d[2])), s = ws[i] * ws[j] * K / Math.pow(r, K + 2);
          f[0] += s * d[0]; f[1] += s * d[1]; f[2] += s * d[2];
        }
        F.push(f);
      }
      for (i = 0; i < n; i++) {
        if (i === pin) continue;
        var u = us[i], fd = F[i][0] * u[0] + F[i][1] * u[1] + F[i][2] * u[2];
        var t = [F[i][0] - fd * u[0], F[i][1] - fd * u[1], F[i][2] - fd * u[2]];
        var tl = Math.hypot(t[0], t[1], t[2]), st = Math.min(eta * tl, 0.08) / (tl || 1);   // 限制单步转角
        us[i] = norm([u[0] + t[0] * st, u[1] + t[1] * st, u[2] + t[2] * st]);
        moved = Math.max(moved, tl * st);
      }
      if (moved < 1e-7) break;
    }
    return moved;
  }
  function angle(u, v) { return Math.acos(Math.max(-1, Math.min(1, u[0] * v[0] + u[1] * v[1] + u[2] * v[2]))) * 180 / Math.PI; }

  // 初始方向：按价层电子对数取理想多面体（略扰动），再模拟到稳定；然后转到便于观察的朝向
  var START = {
    2: [[1, 0, 0], [-1, 0, 0]],
    3: [[0, 1, 0], [0.866, -0.5, 0], [-0.866, -0.5, 0]],
    4: [[0, -0.333, 0.943], [0.816, -0.333, -0.471], [-0.816, -0.333, -0.471], [0, 1, 0]],
    5: [[0, 1, 0], [0, -1, 0], [1, 0, 0], [-0.5, 0, 0.866], [-0.5, 0, -0.866]],
    6: [[0, 1, 0], [0, -1, 0], [1, 0, 0], [-1, 0, 0], [0, 0, 1], [0, 0, -1]]
  };
  function initDirs(m) {
    var v = vsepr(m), us = START[v.n].map(function (u, i) { return norm([u[0] + 0.01 * Math.sin(i * 7.1), u[1] + 0.01 * Math.cos(i * 3.3), u[2] + 0.01 * Math.sin(i * 5.7)]); });
    // 四面体：结合原子先占下面三个、孤电子对占上面（三角锥“立”着）；V 形则两个孤电子对在上
    if (v.n === 4 && v.lp === 2) us = [START[4][1], START[4][2], START[4][0], START[4][3]].map(norm);
    if (v.n === 3 && v.lp === 1) us = [START[3][1], START[3][2], START[3][0]];
    relax(us, weights(m), -1, 4000, 0.05);
    return orient(us, v);
  }
  // 让分子“立”起来：孤电子对的合方向朝上；没有孤电子对的平面分子让平面正对观察者
  function orient(us, v) {
    var up = [0, 0, 0], i;
    for (i = v.x; i < us.length; i++) { up[0] += us[i][0]; up[1] += us[i][1]; up[2] += us[i][2]; }
    if (Math.hypot(up[0], up[1], up[2]) < 1e-6) return us;
    up = norm(up);
    // 绕 up × y 轴转到 y
    var ax = [-up[2], 0, up[0]], s = Math.hypot(ax[0], ax[1], ax[2]), c = up[1];
    if (s < 1e-9) return c > 0 ? us : us.map(function (u) { return [u[0], -u[1], -u[2]]; });
    ax = [ax[0] / s, ax[1] / s, ax[2] / s];
    var th = Math.atan2(s, c);
    return us.map(function (u) { return rot(u, ax, th); });
  }
  function rot(u, k, th) {   // 罗德里格斯旋转
    var c = Math.cos(th), s = Math.sin(th), d = k[0] * u[0] + k[1] * u[1] + k[2] * u[2];
    var x = [k[1] * u[2] - k[2] * u[1], k[2] * u[0] - k[0] * u[2], k[0] * u[1] - k[1] * u[0]];
    return [u[0] * c + x[0] * s + k[0] * d * (1 - c), u[1] * c + x[1] * s + k[1] * d * (1 - c), u[2] * c + x[2] * s + k[2] * d * (1 - c)];
  }
  function randomDirs(n, rnd) {
    var out = [];
    for (var i = 0; i < n; i++) {
      var z = rnd() * 2 - 1, t = rnd() * 2 * Math.PI, r = Math.sqrt(1 - z * z);
      out.push([r * Math.cos(t), z, r * Math.sin(t)]);
    }
    return out;
  }

  // ---------- 杂化轨道 ----------
  // 原子轨道角度部分：s = 1，p = √3·cosθ；spⁿ 杂化轨道 ψ = (1 + √(3n)·cosθ) / √(n + 1)
  // 画图用 |ψ|²（大小两瓣，符号决定颜色）
  function hybPsi(nP, cosT) {
    if (nP === Infinity) return Math.sqrt(3) * cosT;   // 纯 p
    return (1 + Math.sqrt(3 * nP) * cosT) / Math.sqrt(nP + 1);
  }
  var T4 = [[0.577, 0.577, 0.577], [0.577, -0.577, -0.577], [-0.577, 0.577, -0.577], [-0.577, -0.577, 0.577]];
  // 轨道表示式：每格 0/1/2 个电子；steps 为 基态 → (激发态) → 杂化
  // hyb 中心原子：dirs 杂化轨道方向、lone 其中含孤电子对的下标、pFree 未参与杂化的 p 轨道方向、L 结合原子方向
  var HY = {
    ch4: { f: 'CH₄', type: 'sp³', nP: 3, centers: [{ el: 'C', p: [0, 0, 0], dirs: T4, lone: [], pFree: [] }],
      L: [['H', 0, 0, 109], ['H', 0, 1, 109], ['H', 0, 2, 109], ['H', 0, 3, 109]],
      cfg: [['基态 C', [['2s', [2]], ['2p', [1, 1, 0]]]], ['激发态 C', [['2s', [1]], ['2p', [1, 1, 1]]]], ['sp³ 杂化', [['sp³', [1, 1, 1, 1]]]]],
      note: '碳原子 2s 轨道上的 1 个电子激发到 2p 轨道，1 个 2s 和 3 个 2p 轨道杂化成 4 个能量相同的 sp³ 杂化轨道，夹角 109°28′，各与 1 个氢原子的 1s 轨道“头碰头”重叠形成 σ 键。' },
    nh3: { f: 'NH₃', type: 'sp³', nP: 3, centers: [{ el: 'N', p: [0, 0, 0], dirs: [T4[1], T4[2], T4[3], T4[0]], lone: [3], pFree: [] }],
      L: [['H', 0, 0, 101], ['H', 0, 1, 101], ['H', 0, 2, 101]],
      cfg: [['基态 N', [['2s', [2]], ['2p', [1, 1, 1]]]], ['sp³ 杂化', [['sp³', [2, 1, 1, 1]]]]],
      note: '氮原子的 4 个 sp³ 杂化轨道中，1 个被孤电子对占据，另外 3 个各有 1 个电子，与氢原子形成 3 个 σ 键。孤电子对对成键电子对的排斥较大，键角被压缩到 107°。' },
    h2o: { f: 'H₂O', type: 'sp³', nP: 3, centers: [{ el: 'O', p: [0, 0, 0], dirs: [T4[1], T4[2], T4[0], T4[3]], lone: [2, 3], pFree: [] }],
      L: [['H', 0, 0, 96], ['H', 0, 1, 96]],
      cfg: [['基态 O', [['2s', [2]], ['2p', [2, 1, 1]]]], ['sp³ 杂化', [['sp³', [2, 2, 1, 1]]]]],
      note: '氧原子的 4 个 sp³ 杂化轨道中，2 个被孤电子对占据，另外 2 个与氢原子形成 σ 键。两对孤电子对的排斥更大，键角只有 105°，分子呈 V 形。' },
    bf3: { f: 'BF₃', type: 'sp²', nP: 2, centers: [{ el: 'B', p: [0, 0, 0], dirs: [[1, 0, 0], [-0.5, 0, 0.866], [-0.5, 0, -0.866]], lone: [], pFree: [[0, 1, 0]] }],
      L: [['F', 0, 0, 131], ['F', 0, 1, 131], ['F', 0, 2, 131]],
      cfg: [['基态 B', [['2s', [2]], ['2p', [1, 0, 0]]]], ['激发态 B', [['2s', [1]], ['2p', [1, 1, 0]]]], ['sp² 杂化', [['sp²', [1, 1, 1]], ['2p', [0]]]]],
      note: '硼原子的 1 个 2s 和 2 个 2p 轨道杂化成 3 个 sp² 杂化轨道，在同一平面内互成 120°，与 3 个氟原子形成 σ 键；剩下 1 个未参与杂化的 2p 轨道垂直于分子平面，是空轨道。' },
    becl2: { f: 'BeCl₂', type: 'sp', nP: 1, centers: [{ el: 'Be', p: [0, 0, 0], dirs: [[1, 0, 0], [-1, 0, 0]], lone: [], pFree: [[0, 1, 0], [0, 0, 1]] }],
      L: [['Cl', 0, 0, 177], ['Cl', 0, 1, 177]],
      cfg: [['基态 Be', [['2s', [2]], ['2p', [0, 0, 0]]]], ['激发态 Be', [['2s', [1]], ['2p', [1, 0, 0]]]], ['sp 杂化', [['sp', [1, 1]], ['2p', [0, 0]]]]],
      note: '铍原子的 1 个 2s 和 1 个 2p 轨道杂化成 2 个 sp 杂化轨道，夹角 180°，与 2 个氯原子的 3p 轨道形成 σ 键，分子呈直线形；另外 2 个 2p 轨道没有参与杂化。' },
    c2h4: { f: 'C₂H₄', type: 'sp²', nP: 2, cc: 134,
      centers: [{ el: 'C', p: [-67, 0, 0], dirs: [[1, 0, 0], [-0.5, 0, 0.866], [-0.5, 0, -0.866]], lone: [], pFree: [[0, 1, 0]] },
        { el: 'C', p: [67, 0, 0], dirs: [[-1, 0, 0], [0.5, 0, 0.866], [0.5, 0, -0.866]], lone: [], pFree: [[0, 1, 0]] }],
      L: [['H', 0, 1, 109], ['H', 0, 2, 109], ['H', 1, 1, 109], ['H', 1, 2, 109]], pi: [[0, 1, 0]],
      cfg: [['基态 C', [['2s', [2]], ['2p', [1, 1, 0]]]], ['激发态 C', [['2s', [1]], ['2p', [1, 1, 1]]]], ['sp² 杂化', [['sp²', [1, 1, 1]], ['2p', [1]]]]],
      note: '每个碳原子以 sp² 杂化：3 个 sp² 杂化轨道分别与另一个碳原子和 2 个氢原子形成 σ 键，6 个原子共平面；两个碳原子上未参与杂化的 2p 轨道垂直于分子平面，“肩并肩”重叠形成 π 键，所以碳碳双键 = 1 个 σ 键 + 1 个 π 键。' },
    c2h2: { f: 'C₂H₂', type: 'sp', nP: 1, cc: 120,
      centers: [{ el: 'C', p: [-60, 0, 0], dirs: [[1, 0, 0], [-1, 0, 0]], lone: [], pFree: [[0, 1, 0], [0, 0, 1]] },
        { el: 'C', p: [60, 0, 0], dirs: [[-1, 0, 0], [1, 0, 0]], lone: [], pFree: [[0, 1, 0], [0, 0, 1]] }],
      L: [['H', 0, 1, 106], ['H', 1, 1, 106]], pi: [[0, 1, 0], [0, 0, 1]],
      cfg: [['基态 C', [['2s', [2]], ['2p', [1, 1, 0]]]], ['激发态 C', [['2s', [1]], ['2p', [1, 1, 1]]]], ['sp 杂化', [['sp', [1, 1]], ['2p', [1, 1]]]]],
      note: '每个碳原子以 sp 杂化：2 个 sp 杂化轨道夹角 180°，分别与另一个碳原子和氢原子形成 σ 键，4 个原子在一条直线上；每个碳原子还有 2 个互相垂直的 2p 轨道，两两“肩并肩”形成 2 个 π 键，碳碳三键 = 1 个 σ 键 + 2 个 π 键。' }
  };
  var HY_LIST = ['becl2', 'bf3', 'ch4', 'nh3', 'h2o', 'c2h4', 'c2h2'];

  // ---------- 练习 ----------
  var TYPES = ['shape', 'count', 'hybrid', 'angle', 'polar'];
  var QPOOL = ['becl2', 'co2', 'hcn', 'bf3', 'so3', 'hcho', 'co3', 'no3', 'so2', 'ch4', 'ccl4', 'nh4', 'so4', 'nh3', 'h3o', 'pcl3', 'h2o'];
  var SHAPES = ['直线形', '平面三角形', 'V 形', '正四面体形', '三角锥形'];
  function pickOne(rnd, arr) { return arr[Math.floor(rnd() * arr.length) % arr.length]; }
  function shuffle(rnd, a) {
    a = a.slice();
    for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(rnd() * (i + 1)); var t = a[i]; a[i] = a[j]; a[j] = t; }
    return a;
  }
  function lpExpr(m, v) {
    return '中心原子 ' + m.c + ' 的 a = ' + (v.q ? v.ev + (v.q < 0 ? ' + ' + (-v.q) : ' − ' + v.q) + ' = ' : '') + v.a
      + '，x = ' + v.x + '，孤电子对数 = ½(a − Σb) = ½(' + v.a + ' − ' + v.sumB + ') = ' + v.lp;
  }
  function quiz(rnd, prev, only) {
    rnd = rnd || Math.random;
    var type = only || pickOne(rnd, TYPES), q;
    for (var tries = 0; tries < 20; tries++) {
      q = make(type, rnd);
      if (!prev || q.prompt !== prev.prompt) break;
    }
    return q;
  }
  function make(type, rnd) {
    var id = pickOne(rnd, QPOOL), m = M[id], v = vsepr(m), opts, ans, prompt, explain;
    var why = lpExpr(m, v) + '，价层电子对数 = ' + v.x + ' + ' + v.lp + ' = ' + v.n + '，VSEPR 模型为' + v.model;
    if (type === 'shape') {
      prompt = m.f + '（' + m.name + '）的空间结构是？';
      ans = v.shape;
      opts = shuffle(rnd, [ans].concat(shuffle(rnd, SHAPES.filter(function (s) { return s !== ans; })).slice(0, 3)));
      explain = why + (v.lp ? '，略去 ' + v.lp + ' 对孤电子对，' : '，没有孤电子对，') + '空间结构为' + ans + '。';
    } else if (type === 'count') {
      var askLp = rnd() < 0.5;
      prompt = m.f + ' 的中心原子上的' + (askLp ? '孤电子对数' : '价层电子对数') + '是？';
      ans = String(askLp ? v.lp : v.n);
      opts = askLp ? ['0', '1', '2', '3'] : ['2', '3', '4', '5'];
      explain = why + '。';
    } else if (type === 'hybrid') {
      prompt = m.f + ' 中心原子 ' + m.c + ' 的杂化轨道类型是？';
      ans = v.hyb;
      opts = ['sp', 'sp²', 'sp³', '不杂化'];
      explain = why + '，杂化轨道数 = 价层电子对数 = ' + v.n + '，所以是 ' + ans + ' 杂化。';
    } else if (type === 'angle') {
      // 三个价层电子对数或孤电子对数不同的粒子比较键角
      var sets = [['co2', 'bf3', 'ch4'], ['ch4', 'nh3', 'h2o'], ['bf3', 'ch4', 'nh3'], ['becl2', 'so2', 'h2o'], ['bf3', 'nh3', 'h2o'], ['co2', 'so3', 'nh4'], ['no3', 'so4', 'h2o']];
      var set = shuffle(rnd, pickOne(rnd, sets)), val = {};
      set.forEach(function (k) { var x = vsepr(M[k]); val[k] = IDEAL[x.n] - x.lp * 2 - (k === 'so2' ? 0.5 : 0); });
      var sorted = set.slice().sort(function (a, b) { return val[b] - val[a]; });
      var fmt = function (arr) { return arr.map(function (k) { return M[k].f; }).join(' > '); };
      ans = fmt(sorted);
      var perms = [[0, 1, 2], [0, 2, 1], [1, 0, 2], [1, 2, 0], [2, 0, 1], [2, 1, 0]].map(function (p) { return fmt(p.map(function (i) { return sorted[i]; })); });
      opts = shuffle(rnd, [ans].concat(shuffle(rnd, perms.slice(1)).slice(0, 3)));
      prompt = '下列粒子中键角由大到小排列正确的是？';
      explain = sorted.map(function (k) { var x = vsepr(M[k]); return M[k].f + '：价层电子对 ' + x.n + '、孤电子对 ' + x.lp + '，' + x.shape + '，键角 ' + M[k].ang[0][2]; }).join('；')
        + '。先看 VSEPR 模型（直线形 180° > 平面三角形 120° > 四面体形 109°28′），模型相同时孤电子对越多，键角越小。';
      id = sorted[sorted.length - 1];
    } else {
      // 极性分子：一个极性 + 三个非极性（或反过来问）
      var mols = QPOOL.filter(function (k) { return !M[k].q; });
      var pol = mols.filter(function (k) { return vsepr(M[k]).polar; }), non = mols.filter(function (k) { return !vsepr(M[k]).polar; });
      var askPolar = rnd() < 0.6, one = pickOne(rnd, askPolar ? pol : non), others = shuffle(rnd, askPolar ? non : pol).slice(0, 3);
      id = one;
      ans = M[one].f;
      opts = shuffle(rnd, [one].concat(others)).map(function (k) { return M[k].f; });
      prompt = '下列分子中，属于' + (askPolar ? '极性' : '非极性') + '分子的是？';
      explain = [one].concat(others).map(function (k) { var x = vsepr(M[k]); return M[k].f + ' ' + x.shape + '，' + (x.polar ? '极性' : '非极性'); }).join('；')
        + '。空间结构对称、正电中心与负电中心重合的是非极性分子；中心原子有孤电子对，或结合原子不同，一般是极性分子。';
      v = vsepr(M[id]);
    }
    return { type: type, id: id, prompt: prompt, options: opts, answer: ans, explain: explain };
  }

  window.Molecule = {
    EL: EL, M: M, GROUPS: GROUPS, MODEL: MODEL, HYB: HYB, SHAPE: SHAPE, IDEAL: IDEAL, HY: HY, HY_LIST: HY_LIST, TYPES: TYPES,
    bOf: bOf, vsepr: vsepr, weights: weights, relax: relax, angle: angle, initDirs: initDirs, randomDirs: randomDirs,
    orient: orient, norm: norm, hybPsi: hybPsi, lpExpr: lpExpr, quiz: quiz
  };
})();
