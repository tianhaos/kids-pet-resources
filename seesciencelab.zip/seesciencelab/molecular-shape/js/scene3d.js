// 分子的空间结构：three.js 场景（VSEPR 球棍/比例模型、孤电子对、VSEPR 框架与键角；杂化轨道的分步演示）
// 中心原子在原点，1 单位 = 40 pm；方向向量与 Molecule 相同（three 坐标，y 向上）
(function () {
  var Mo = window.Molecule;
  var V3 = THREE.Vector3, Y = new V3(0, 1, 0);
  var S = 1 / 40;
  var LP_COL = 0xc9a7ff, GOLD = 0xffc94a;
  var ORB = { s: 0xffb74d, p: 0x4fc3f7, pN: 0x2b6f99, h: 0x7ee081, hN: 0x3a7a43, lone: 0xc9a7ff, loneN: 0x7a5aa8 };
  var K = 2;     // 杂化演示中 sp³ 杂化轨道大瓣的长度（|ψ|³ = 8）

  function v3(a) { return new V3(a[0], a[1], a[2]); }
  function clamp(x) { return Math.max(0, Math.min(1, x)); }

  window.MoleculeScene = function (container) {
    var renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    container.appendChild(renderer.domElement);
    var canvas = renderer.domElement;
    canvas.id = 'view3d';

    var labelRenderer = new THREE.CSS2DRenderer();
    var ls = labelRenderer.domElement.style;
    ls.position = 'absolute'; ls.top = '0'; ls.left = '0'; ls.pointerEvents = 'none'; ls.zIndex = '2';
    container.appendChild(labelRenderer.domElement);

    var scene = new THREE.Scene();
    scene.background = new THREE.Color('#05070d');
    var camera = new THREE.PerspectiveCamera(32, 1, 0.1, 500);
    scene.add(camera);
    scene.add(new THREE.AmbientLight(0xffffff, 0.45));
    var key = new THREE.DirectionalLight(0xffffff, 0.85);
    key.position.set(-4, 6, 8);
    camera.add(key);
    var rim = new THREE.DirectionalLight(0x9fc8ff, 0.25);
    rim.position.set(6, -3, -4);
    camera.add(rim);

    var controls = new THREE.OrbitControls(camera, canvas);
    controls.enableDamping = true;
    controls.dampingFactor = 0.08;
    controls.enablePan = false;
    controls.minDistance = 6;
    controls.maxDistance = 80;
    controls.autoRotateSpeed = 0.8;
    var spinStopped = false;
    controls.addEventListener('start', function () { controls.autoRotate = false; spinStopped = true; });

    var root = new THREE.Group();
    scene.add(root);
    var sphere = new THREE.SphereGeometry(1, 32, 22);
    var cyl = new THREE.CylinderGeometry(1, 1, 1, 14, 1, true);

    function std(col, op) {
      var m = new THREE.MeshStandardMaterial({ color: new THREE.Color(col), roughness: 0.5, metalness: 0.05 });
      if (op != null && op < 1) { m.transparent = true; m.opacity = op; m.depthWrite = false; }
      return m;
    }
    function clear(g) {
      for (var i = g.children.length - 1; i >= 0; i--) {
        var o = g.children[i];
        if (o.children && o.children.length) clear(o);
        if (o.isCSS2DObject && o.element.parentNode) o.element.parentNode.removeChild(o.element);
        if (o.geometry && o.geometry !== sphere && o.geometry !== cyl && !o.geometry.userData.keep) o.geometry.dispose();
        if (o.material && o.material.dispose) o.material.dispose();
        g.remove(o);
      }
    }
    function ball(g, r, m) { var s = new THREE.Mesh(sphere, m); s.scale.setScalar(r); g.add(s); return s; }
    function setStick(s, a, b, r) {
      var d = b.clone().sub(a), len = d.length();
      s.position.copy(a).addScaledVector(d, 0.5);
      s.scale.set(r, len, r);
      if (len > 1e-6) s.quaternion.setFromUnitVectors(Y, d.normalize());
    }
    function label(g, html, cls) {
      var el = document.createElement('div');
      el.className = 'lab ' + (cls || '');
      el.innerHTML = html;
      var o = new THREE.CSS2DObject(el);
      g.add(o);
      return o;
    }
    function lineObj(g, n, col, op, dashed) {
      var geo = new THREE.BufferGeometry();
      geo.setAttribute('position', new THREE.Float32BufferAttribute(new Float32Array(n * 3), 3));
      var m = dashed ? new THREE.LineDashedMaterial({ color: col, dashSize: 0.22, gapSize: 0.14, transparent: true, opacity: op })
        : new THREE.LineBasicMaterial({ color: col, transparent: true, opacity: op });
      var l = new THREE.LineSegments(geo, m);
      l.frustumCulled = false;
      g.add(l);
      return l;
    }
    function setLine(l, pts) {
      var a = l.geometry.attributes.position, n = Math.min(pts.length, a.count);
      for (var i = 0; i < n; i++) a.setXYZ(i, pts[i].x, pts[i].y, pts[i].z);
      l.geometry.setDrawRange(0, n);
      a.needsUpdate = true;
      if (l.material.isLineDashedMaterial) l.computeLineDistances();
    }
    function perp(u) {   // 与 u 垂直、尽量落在 xy 平面内的方向（画双键）
      var p = new V3().crossVectors(u, new V3(0, 0, 1));
      if (p.lengthSq() < 1e-4) p.crossVectors(u, new V3(1, 0, 0));
      return p.normalize();
    }

    // ================= VSEPR =================
    var gV = new THREE.Group(), gH = new THREE.Group();
    root.add(gV); root.add(gH);
    var vsig = '', V = null;   // V：当前分子的网格对象

    // v：{ id, us, model 'ball'|'fill', lp, frame, angle, conv, drag }
    function buildVsepr(v) {
      clear(gV);
      var m = Mo.M[v.id], info = Mo.vsepr(m), fill = v.model === 'fill';
      var avg = 0;
      m.L.forEach(function (l) { avg += l[1]; });
      avg = avg / m.L.length * S;
      var ce = Mo.EL[m.c];
      V = { m: m, info: info, avg: avg, dom: [], arcs: [], fill: fill };
      ball(gV, fill ? ce.vdw * 0.8 * S : (ce.r * 0.3 + 8) * S, std(ce.col)).userData.center = 1;
      m.L.forEach(function (l, i) {
        var e = Mo.EL[l[0]], g = new THREE.Group(), bo = fill ? 0 : (l[2] || 1), sticks = [];
        var atom = ball(g, fill ? e.vdw * 0.8 * S : (e.r * 0.3 + 8) * S, std(e.col));
        atom.userData.i = i;
        for (var k = 0; k < bo; k++) { var s = new THREE.Mesh(cyl, std('#aab4c3')); gV.add(s); sticks.push(s); }
        gV.add(g);
        V.dom.push({ g: g, len: l[1] * S, bo: bo, sticks: sticks });
      });
      for (var j = 0; j < info.lp; j++) {
        var g = new THREE.Group(), L = avg * 0.75;
        var lobe = ball(g, 1, std(LP_COL, 0.32));
        lobe.scale.set(L * 0.36, L * 0.55, L * 0.36);
        lobe.position.y = L * 0.62;
        lobe.userData.i = m.L.length + j;
        var dm = new THREE.MeshBasicMaterial({ color: LP_COL });
        [-1, 1].forEach(function (sg) { var d = ball(g, 0.13, dm); d.position.set(sg * L * 0.15, L * 0.68, 0); });
        g.visible = v.lp && !fill;
        gV.add(g);
        V.dom.push({ g: g, len: L, lp: true });
      }
      // VSEPR 框架（各电子对方向上取同一半径的顶点）
      V.frame = lineObj(gV, 40, 0x8d99ab, 0.7, true);
      V.spokes = lineObj(gV, 12, LP_COL, 0.55, true);
      // 键角圆弧
      m.ang.forEach(function (a) {
        var arc = lineObj(gV, 48, GOLD, 0.9);
        V.arcs.push({ i: a[0], j: a[1], txt: a[2], line: arc, lab: label(gV, '', 'ang') });
      });
    }
    function updateVsepr(v) {
      var s = v.id + '|' + v.model;
      gV.visible = true; gH.visible = false;
      if (s !== vsig) { vsig = s; buildVsepr(v); homeCam(); }
      var us = v.us.map(v3), n = V.dom.length, fill = V.fill, i;
      V.dom.forEach(function (d, k) {
        var u = us[k];
        if (d.lp) {
          d.g.quaternion.setFromUnitVectors(Y, u);
          d.g.visible = v.lp && !fill;
          return;
        }
        var p = u.clone().multiplyScalar(d.len);
        d.g.position.copy(p);
        if (!d.bo) return;
        var off = d.bo > 1 ? perp(u).multiplyScalar(0.2) : new V3();
        d.sticks.forEach(function (st, k2) {
          var o = off.clone().multiplyScalar(d.bo === 2 ? (k2 ? -1 : 1) : k2 - 1);
          setStick(st, o, p.clone().add(o), d.bo > 1 ? 0.09 : 0.14);
        });
      });
      // 框架：夹角 < 150° 的电子对两两相连（直线形只有一条）
      var R = V.avg, segs = [], sp = [];
      V.frame.visible = v.frame && !fill;
      V.spokes.visible = v.frame && !fill && V.info.lp > 0;
      if (v.frame && !fill) {
        if (n === 2) segs.push(us[0].clone().multiplyScalar(R), us[1].clone().multiplyScalar(R));
        else for (i = 0; i < n; i++) for (var j = i + 1; j < n; j++) {
          if (us[i].angleTo(us[j]) < 150 * Math.PI / 180) segs.push(us[i].clone().multiplyScalar(R), us[j].clone().multiplyScalar(R));
        }
        for (i = V.m.L.length; i < n; i++) sp.push(new V3(), us[i].clone().multiplyScalar(R));
        setLine(V.frame, segs);
        setLine(V.spokes, sp);
      }
      // 键角
      V.arcs.forEach(function (a) {
        var show = v.angle && !fill;
        a.line.visible = a.lab.visible = show;
        a.lab.element.style.display = show ? '' : 'none';
        if (!show) return;
        var u1 = us[a.i], u2 = us[a.j], th = u1.angleTo(u2), r = V.avg * 0.5, pts = [], N = 24;
        var w = u2.clone().sub(u1.clone().multiplyScalar(Math.cos(th)));
        if (w.lengthSq() < 1e-8) w = perp(u1);   // 180°：在 xy 平面内画半圆
        w.normalize();
        for (var k = 0; k < N; k++) {
          var t0 = th * k / N, t1 = th * (k + 1) / N;
          pts.push(u1.clone().multiplyScalar(Math.cos(t0)).addScaledVector(w, Math.sin(t0)).multiplyScalar(r),
            u1.clone().multiplyScalar(Math.cos(t1)).addScaledVector(w, Math.sin(t1)).multiplyScalar(r));
        }
        setLine(a.line, pts);
        var mid = u1.clone().multiplyScalar(Math.cos(th / 2)).addScaledVector(w, Math.sin(th / 2)).multiplyScalar(r * 1.75);
        a.lab.position.copy(mid);
        var deg = th * 180 / Math.PI;
        var html = v.conv && a.txt ? a.txt : '≈ ' + deg.toFixed(1) + '°';
        if (a.lab.element.innerHTML !== html) a.lab.element.innerHTML = html;
      });
    }

    // ================= 杂化轨道 =================
    var hsig = '', H = null, geoCache = {};
    // 轨道波瓣：单位球面上的点按 |ψ|³ / 8 缩放（比 |ψ|² 细长，接近教材插图）；sign = +1 / −1 取对应符号的一瓣
    function lobeGeo(nP, sign) {
      var k = nP + '|' + sign;
      if (geoCache[k]) return geoCache[k];
      var g = new THREE.SphereGeometry(1, 48, 32), a = g.attributes.position;
      for (var i = 0; i < a.count; i++) {
        var x = a.getX(i), y = a.getY(i), z = a.getZ(i), psi = Mo.hybPsi(nP, y), r = psi * sign > 0 ? Math.pow(Math.abs(psi), 3) / 8 : 0;
        a.setXYZ(i, x * r, y * r, z * r);
      }
      g.computeVertexNormals();
      g.userData.keep = 1;
      return (geoCache[k] = g);
    }
    function orbital(g, nP, dir, cp, cn) {
      var o = new THREE.Group();
      o.quaternion.setFromUnitVectors(Y, v3(dir).normalize());
      var mp = std(cp, 0.85), mn = std(cn, 0.85);
      o.add(new THREE.Mesh(lobeGeo(nP, 1), mp));
      o.add(new THREE.Mesh(lobeGeo(nP, -1), mn));
      o.userData.mats = [mp, mn];
      g.add(o);
      return o;
    }
    function fade(o, op) {
      o.visible = op > 0.01;
      (o.userData.mats || [o.material]).forEach(function (m) { m.opacity = op * (m.userData.base || 0.85); m.transparent = true; m.depthWrite = op > 0.99; });
    }
    function buildHybrid(id) {
      clear(gH);
      var hy = Mo.HY[id];
      H = { hy: hy, atomic: [], hybs: [], free: [], lig: [], pi: [], labs: {} };
      hy.centers.forEach(function (c, ci) {
        var g = new THREE.Group();
        g.position.copy(v3(c.p).multiplyScalar(S));
        gH.add(g);
        var nl = c.lone.length, dirs = Mo.orient(c.dirs.map(function (d) { return Mo.norm(d); }), { x: c.dirs.length - nl });
        c._dirs = dirs;
        ball(g, 0.28, std(Mo.EL[c.el].col));
        // 原子轨道：2s 与参与杂化的 2p
        var sMesh = ball(g, 0.7, std(ORB.s, 0.85));
        sMesh.userData.base = 0.85;
        H.atomic.push(sMesh);
        var free = c.pFree.map(function (d) { return Mo.norm(d); });
        [[1, 0, 0], [0, 1, 0], [0, 0, 1]].forEach(function (ax) {
          var isFree = free.some(function (f) { return Math.abs(f[0] * ax[0] + f[1] * ax[1] + f[2] * ax[2]) > 0.99; });
          if (!isFree) { var p = orbital(g, Infinity, ax, ORB.p, ORB.pN); p.scale.setScalar(K); H.atomic.push(p); }
        });
        // 杂化轨道
        dirs.forEach(function (d, k) {
          var lone = c.lone.indexOf(k) >= 0;
          var o = orbital(g, hy.nP, d, lone ? ORB.lone : ORB.h, lone ? ORB.loneN : ORB.hN);
          o.userData.dir = d; o.userData.lone = lone;
          H.hybs.push(o);
        });
        free.forEach(function (d) { var p = orbital(g, Infinity, d, ORB.p, ORB.pN); p.scale.setScalar(K); H.free.push(p); });
        if (ci === 0) {
          H.labs.s = label(g, '2s', 'orb'); H.labs.s.position.set(-0.6, -0.9, 0.6);
          H.labs.p = label(g, '2p', 'orb');
          H.labs.h = label(g, hy.type + ' 杂化轨道', 'orb');
          var hd = v3(dirs[0]); H.labs.h.position.copy(hd.multiplyScalar(K * 1.15));
          H.labs.p.position.set(0, K * 0.8, 0);
          if (dirs.length > c.lone.length && c.lone.length) {
            H.labs.lone = label(g, '孤电子对', 'orb lone');
            H.labs.lone.position.copy(v3(dirs[c.lone[0]]).multiplyScalar(K * 1.15));
          }
          if (free.length) { H.labs.free = label(g, '未杂化的 2p', 'orb'); H.labs.free.position.copy(v3(free[0]).multiplyScalar(K * 0.75)).add(new V3(0.5, 0, 0)); }
        }
      });
      // 结合原子：H 画 1s 轨道，F、Cl 画指向中心原子的 p 轨道
      hy.L.forEach(function (l, k) {
        var c = hy.centers[l[1]], d = v3(c._dirs[l[2]]), e = Mo.EL[l[0]];
        var g = new THREE.Group();
        gH.add(g);
        ball(g, l[0] === 'H' ? 0.22 : 0.32, std(e.col));
        var orb;
        if (l[0] === 'H') { orb = ball(g, 0.7, std('#e8eef5', 0.55)); orb.material.userData.base = 0.55; }
        else { orb = orbital(g, Infinity, d.clone().negate().toArray(), e.col, '#2f6a3b'); orb.scale.setScalar(K * 0.9); }
        H.lig.push({ g: g, orb: orb, home: v3(c.p).multiplyScalar(S).add(d.clone().multiplyScalar(l[3] * S)), dir: d });
        if (k === 0) { H.labs.sig = label(gH, 'σ 键（头碰头）', 'orb sig'); H.labs.sig.position.copy(v3(c.p).multiplyScalar(S).add(d.clone().multiplyScalar(l[3] * S * 0.62))).add(new V3(0, 0.55, 0)); }
      });
      // π 键：两个碳原子未杂化的 p 轨道肩并肩重叠
      (hy.pi || []).forEach(function (pd, k) {
        var half = hy.cc * S / 2, d = v3(pd);
        [-1, 1].forEach(function (sg) {
          var m = ball(gH, 1, std(ORB.p, 0.32));
          m.material.userData.base = 0.32;
          m.scale.set(half + 0.6, d.y ? 0.4 : 0.5, d.z ? 0.4 : 0.5);
          m.position.copy(d.clone().multiplyScalar(sg * K * 0.36));
          H.pi.push(m);
        });
        if (!k) { H.labs.pi = label(gH, 'π 键（肩并肩）', 'orb pi'); H.labs.pi.position.copy(d.clone().multiplyScalar(K * 0.8)).add(new V3(0, 0.3, 0)); }
      });
      if (hy.centers.length > 1) {   // 两个碳原子之间的 σ 键标注
        H.labs.cc = label(gH, 'σ 键', 'orb sig');
        H.labs.cc.position.set(0, -0.45, -0.3);
      }
    }
    // ph：0 原子轨道、1 杂化轨道、2 成键（可取中间值做过渡）
    function updateHybrid(h) {
      gV.visible = false; gH.visible = true;
      if (h.id !== hsig) { hsig = h.id; buildHybrid(h.id); homeCam(); }
      var ph = h.ph, a = clamp(1 - ph), b = clamp(ph), c = clamp(ph - 1);
      H.atomic.forEach(function (o) { fade(o, a); });
      var sc = 0.45 + 0.55 * b;
      H.hybs.forEach(function (o) { fade(o, b); o.scale.setScalar(K * sc); });
      H.free.forEach(function (o) { fade(o, 1 - 0.55 * c * (H.pi.length ? 1 : 0)); });
      H.lig.forEach(function (l) {
        l.g.visible = c > 0.01;
        l.g.position.copy(l.home).addScaledVector(l.dir, 3 * (1 - c));
        fade(l.orb, c);
      });
      H.pi.forEach(function (m) { fade(m, c); });
      function show(lab, on) { if (lab) { lab.visible = on; lab.element.style.display = on ? '' : 'none'; } }
      show(H.labs.s, a > 0.5); show(H.labs.p, a > 0.5);
      show(H.labs.h, b > 0.5 && c < 0.5); show(H.labs.lone, b > 0.5); show(H.labs.free, b > 0.5 && c < 0.5);
      show(H.labs.sig, c > 0.5); show(H.labs.pi, c > 0.5); show(H.labs.cc, c > 0.5);
    }

    // ================= 相机、点选、拖动 =================
    var mode = '';
    function homeCam() {
      var R;
      if (gH.visible && H) { R = 2.7; H.lig.forEach(function (l) { R = Math.max(R, l.home.length() + 0.9); }); }
      else if (V) { R = 0; V.m.L.forEach(function (l) { R = Math.max(R, (l[1] + (V.fill ? Mo.EL[l[0]].vdw * 0.8 : 0)) * S); }); R += V.fill ? 0.3 : 1.4; }
      else R = 5;
      var aspect = Math.max(0.5, Math.min(1, camera.aspect || 1));
      var dist = R * 2 / (2 * Math.tan(camera.fov * Math.PI / 360)) * 1.25 / aspect;
      controls.target.set(0, 0, 0);
      camera.position.copy((gH.visible ? new V3(0.35, 0.75, 1) : new V3(0.42, 0.32, 1)).normalize().multiplyScalar(dist));
      controls.update();
    }
    var raycaster = new THREE.Raycaster(), ndc = new THREE.Vector2();
    function ray(cx, cy) {
      var r = canvas.getBoundingClientRect();
      ndc.set((cx - r.left) / r.width * 2 - 1, -(cy - r.top) / r.height * 2 + 1);
      raycaster.setFromCamera(ndc, camera);
      return raycaster.ray;
    }
    function pick(cx, cy) {
      if (!V || !gV.visible) return -1;
      ray(cx, cy);
      var hits = raycaster.intersectObjects(gV.children, true);
      for (var h = 0; h < hits.length; h++) {
        var o = hits[h].object;
        if (!o.visible || o.userData.center) continue;
        if (o.userData.i != null) return o.userData.i;
      }
      return -1;
    }
    // 拖动第 i 个电子对：鼠标射线与半径为该电子对长度的球面的交点（取靠近观察者的一侧）
    function dirAt(cx, cy, i) {
      var r = ray(cx, cy), d = V.dom[i], R = d.lp ? d.len * 0.62 : d.len;
      var o = r.origin, dv = r.direction, b = o.dot(dv), cc = o.lengthSq() - R * R, disc = b * b - cc, p;
      if (disc >= 0) p = o.clone().addScaledVector(dv, -b - Math.sqrt(disc));
      else p = o.clone().addScaledVector(dv, -b);
      p.normalize();
      return [p.x, p.y, p.z];
    }

    function resize(w, h) {
      camera.aspect = w / Math.max(1, h);
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
      labelRenderer.setSize(w, h);
    }
    function render() {
      controls.update();
      renderer.render(scene, camera);
      labelRenderer.render(scene, camera);
    }
    function spin(on) { controls.autoRotate = !!on && !spinStopped; }
    function blank() { gV.visible = gH.visible = false; }
    function setMode(m) { if (m !== mode) { mode = m; vsig = hsig = ''; } }

    return { vsepr: updateVsepr, hybrid: updateHybrid, blank: blank, setMode: setMode, render: render, resize: resize, pick: pick, dirAt: dirAt,
      home: homeCam, spin: spin, canvas: canvas, camera: camera, controls: controls };
  };
})();
