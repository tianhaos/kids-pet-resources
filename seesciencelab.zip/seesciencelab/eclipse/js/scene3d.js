// 3D 场景：一年中地球绕太阳公转、月球绕地球公转，白道面与黄道面的夹角、交点连线、地球和月球的影子
// 坐标：太阳在原点，y 轴指向黄北极，从北边看逆时针公转；黄经 lon、黄纬 lat 的方向 = (cos lat cos lon, sin lat, −cos lat sin lon)
// 尺寸、距离不按比例；白道倾角可放大 3 倍以便看清（判断日月食仍按真实的 5.1°）
(function () {
  var E = window.Eclipse, DEG = E.DEG, V3 = THREE.Vector3, Y = new V3(0, 1, 0);
  var ORBIT = 26, MOON_ORBIT = 5, EARTH_R = 1.0, MOON_R = 0.38, SUN_R = 2.6;
  var EARTH_SHADOW = 7, MOON_SHADOW = 5.3, SEASON = 17;

  function dir(lon, lat) {
    var l = lon * DEG, b = (lat || 0) * DEG;
    return new V3(Math.cos(b) * Math.cos(l), Math.sin(b), -Math.cos(b) * Math.sin(l));
  }

  window.EclipseScene = function (stage, opts) {
    opts = opts || {};
    var renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    var canvas = renderer.domElement;
    canvas.id = 'gl';
    stage.insertBefore(canvas, stage.firstChild);

    var labelRenderer = new THREE.CSS2DRenderer();
    var lEl = labelRenderer.domElement, ls = lEl.style;
    ls.position = 'absolute'; ls.top = '0'; ls.left = '0'; ls.pointerEvents = 'none'; ls.zIndex = '2';
    stage.appendChild(lEl);

    var scene = new THREE.Scene();
    scene.background = new THREE.Color('#05070d');
    var camera = new THREE.PerspectiveCamera(42, 1, 0.1, 3000);
    var controls = new THREE.OrbitControls(camera, canvas);
    controls.enableDamping = true;
    controls.dampingFactor = 0.08;
    controls.minDistance = 4;
    controls.maxDistance = 160;
    controls.enablePan = false;

    function label(html, cls, parent) {
      var el = document.createElement('div');
      el.className = 'lbl ' + (cls || '');
      el.innerHTML = html;
      var o = new THREE.CSS2DObject(el);
      parent.add(o);
      return o;
    }
    function line(pts, mat) { return new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts), mat); }

    // ---------- 星空、光照 ----------
    (function () {
      var n = 1600, pos = new Float32Array(n * 3);
      for (var i = 0; i < n; i++) {
        var v = new V3().randomDirection().multiplyScalar(700 + Math.random() * 400);
        pos[i * 3] = v.x; pos[i * 3 + 1] = v.y; pos[i * 3 + 2] = v.z;
      }
      var g = new THREE.BufferGeometry();
      g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
      scene.add(new THREE.Points(g, new THREE.PointsMaterial({ color: 0xffffff, size: 1.3, sizeAttenuation: false, transparent: true, opacity: 0.7 })));
    })();
    scene.add(new THREE.PointLight(0xffffff, 1.5, 0, 0));
    scene.add(new THREE.AmbientLight(0x8090b0, 0.16));

    // ---------- 太阳 ----------
    var sun = new THREE.Mesh(new THREE.SphereGeometry(SUN_R, 40, 24), new THREE.MeshBasicMaterial({ color: 0xffd54f }));
    scene.add(sun);
    var glow = new THREE.Sprite(new THREE.SpriteMaterial({
      map: (function () {
        var c = document.createElement('canvas'); c.width = c.height = 128;
        var x = c.getContext('2d'), g = x.createRadialGradient(64, 64, 0, 64, 64, 64);
        g.addColorStop(0, 'rgba(255,220,120,1)'); g.addColorStop(0.3, 'rgba(255,190,60,.5)'); g.addColorStop(1, 'rgba(255,140,0,0)');
        x.fillStyle = g; x.fillRect(0, 0, 128, 128);
        return new THREE.CanvasTexture(c);
      })(),
      blending: THREE.AdditiveBlending, depthWrite: false, transparent: true
    }));
    glow.scale.set(14, 14, 1);
    scene.add(glow);
    label('太阳', 'lbl-sun', sun).position.set(0, -SUN_R - 1, 0);

    // ---------- 黄道面、地球轨道、食季 ----------
    var ecl = new THREE.Mesh(new THREE.CircleGeometry(ORBIT + 6, 96),
      new THREE.MeshBasicMaterial({ color: 0x8d99ab, transparent: true, opacity: 0.05, side: THREE.DoubleSide, depthWrite: false }));
    ecl.rotation.x = -Math.PI / 2;
    scene.add(ecl);
    var orbitPts = [];
    for (var i = 0; i <= 240; i++) orbitPts.push(dir(i / 240 * 360).multiplyScalar(ORBIT));
    scene.add(line(orbitPts, new THREE.LineBasicMaterial({ color: 0x4a5870 })));
    label('黄道面（地球公转轨道面）', 'lbl-plane', ecl).position.set(ORBIT * 0.72, -ORBIT * 0.72, 0);

    // 食季：太阳在交点附近时地球所在的两段轨道（随交点连线缓慢转动）
    var seasons = new THREE.Group();
    scene.add(seasons);
    [0, 180].forEach(function (c) {
      var pts = [];
      for (var a = -SEASON; a <= SEASON; a += 1) pts.push(dir(c + a).multiplyScalar(ORBIT));
      var ln = new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts), new THREE.LineBasicMaterial({ color: 0xffc94a, transparent: true, opacity: 0.9 }));
      seasons.add(ln);
      label('食季', 'lbl-season', ln).position.copy(dir(c).multiplyScalar(ORBIT + 2.2));
    });
    // 交点连线的方向（穿过太阳的虚线，表示它在一年里几乎不变）
    var nodeDirLine = line([dir(0).multiplyScalar(-ORBIT - 4), dir(0).multiplyScalar(ORBIT + 4)],
      new THREE.LineDashedMaterial({ color: 0xffc94a, dashSize: 0.8, gapSize: 0.8, transparent: true, opacity: 0.25 }));
    nodeDirLine.computeLineDistances();
    seasons.add(nodeDirLine);

    // ---------- 地球 ----------
    var earthG = new THREE.Group();
    scene.add(earthG);
    var earth = new THREE.Mesh(new THREE.SphereGeometry(EARTH_R, 48, 32), new THREE.MeshPhongMaterial({
      map: new THREE.CanvasTexture(window.makeEarthCanvas()), shininess: 6
    }));
    earthG.add(earth);
    label('地球', 'lbl-body', earthG).position.set(0, -EARTH_R - 0.6, 0);
    // 地球附近的一小片黄道面
    var localEcl = new THREE.Mesh(new THREE.RingGeometry(EARTH_R * 1.3, MOON_ORBIT * 1.3, 64),
      new THREE.MeshBasicMaterial({ color: 0xc7d0dc, transparent: true, opacity: 0.07, side: THREE.DoubleSide, depthWrite: false }));
    localEcl.rotation.x = -Math.PI / 2;
    earthG.add(localEcl);

    // 白道（月球轨道）：在交点坐标系里建，绕 y 轴转到升交点黄经 Ω
    var moonOrbit = new THREE.Group();
    earthG.add(moonOrbit);
    var northMat = new THREE.LineBasicMaterial({ color: 0x4fc3f7 });
    var southMat = new THREE.LineDashedMaterial({ color: 0x4fc3f7, dashSize: 0.25, gapSize: 0.18, transparent: true, opacity: 0.55 });
    var northLine, southLine, planeDisc, incl = -1;
    var discMat = new THREE.MeshBasicMaterial({ color: 0x4fc3f7, transparent: true, opacity: 0.09, side: THREE.DoubleSide, depthWrite: false });
    function buildOrbit(iDeg) {
      if (iDeg === incl) return;
      incl = iDeg;
      [northLine, southLine, planeDisc].forEach(function (o) { if (o) { moonOrbit.remove(o); o.geometry.dispose(); } });
      var ii = iDeg * DEG, n = [], s = [];
      for (var k = 0; k <= 120; k++) {
        var u = k / 120 * Math.PI;
        n.push(new V3(Math.cos(u), Math.sin(ii) * Math.sin(u), -Math.cos(ii) * Math.sin(u)).multiplyScalar(MOON_ORBIT));
        s.push(new V3(Math.cos(u + Math.PI), Math.sin(ii) * Math.sin(u + Math.PI), -Math.cos(ii) * Math.sin(u + Math.PI)).multiplyScalar(MOON_ORBIT));
      }
      northLine = line(n, northMat); southLine = line(s, southMat); southLine.computeLineDistances();
      planeDisc = new THREE.Mesh(new THREE.CircleGeometry(MOON_ORBIT, 64), discMat);
      planeDisc.rotation.x = ii - Math.PI / 2;
      moonOrbit.add(northLine); moonOrbit.add(southLine); moonOrbit.add(planeDisc);
      orbitLabel.position.set(0, Math.sin(ii) * MOON_ORBIT * 0.8, -Math.cos(ii) * MOON_ORBIT * 0.8);
    }
    var orbitLabel = label('白道面', 'lbl-plane lbl-cyan', moonOrbit);
    // 交点连线与两个交点
    var nodeLine = line([new V3(-MOON_ORBIT * 1.35, 0, 0), new V3(MOON_ORBIT * 1.35, 0, 0)],
      new THREE.LineDashedMaterial({ color: 0xffc94a, dashSize: 0.3, gapSize: 0.2 }));
    nodeLine.computeLineDistances();
    moonOrbit.add(nodeLine);
    [[1, '升交点'], [-1, '降交点']].forEach(function (p) {
      var m = new THREE.Mesh(new THREE.OctahedronGeometry(0.2), new THREE.MeshBasicMaterial({ color: 0xffc94a }));
      m.position.set(p[0] * MOON_ORBIT, 0, 0);
      moonOrbit.add(m);
      label(p[1], 'lbl-node', m).position.set(p[0] * 0.9, 0.45, 0);
    });

    // ---------- 月球 ----------
    var moon = new THREE.Mesh(new THREE.SphereGeometry(MOON_R, 32, 20), new THREE.MeshLambertMaterial({ color: 0xd8d2c2 }));
    earthG.add(moon);
    label('月球', 'lbl-body', moon).position.set(0, MOON_R + 0.4, 0);

    // ---------- 影子：本影圆锥 + 半影（向外张开的截锥） ----------
    function shadow(r, len) {
      var g = new THREE.Group();
      var umbra = new THREE.Mesh(new THREE.ConeGeometry(r, len, 40, 1, true),
        new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.55, side: THREE.DoubleSide, depthWrite: false }));
      umbra.rotation.x = Math.PI;              // 尖端朝 −y
      umbra.position.y = -len / 2;
      var pen = new THREE.Mesh(new THREE.CylinderGeometry(r, r * 2.1, len, 40, 1, true),
        new THREE.MeshBasicMaterial({ color: 0x6a7690, transparent: true, opacity: 0.12, side: THREE.DoubleSide, depthWrite: false }));
      pen.position.y = -len / 2;
      g.add(umbra); g.add(pen);
      return g;
    }
    var earthShadow = shadow(EARTH_R, EARTH_SHADOW), moonShadow = shadow(MOON_R, MOON_SHADOW);
    earthG.add(earthShadow); earthG.add(moonShadow);

    // ---------- 更新 ----------
    var allLabels = [];
    scene.traverse(function (o) { if (o.isCSS2DObject) allLabels.push(o); });
    var lastEarth = new V3(), haveLast = false, view = 'over';

    function update(st) {
      var e = E.elements(st.t), k = st.exag ? 3 : 1;
      buildOrbit(E.INCL * k);
      var ep = dir(e.sun + 180).multiplyScalar(ORBIT);
      earthG.position.copy(ep);
      earth.rotation.y = st.t * 2 * Math.PI;
      moonOrbit.rotation.y = e.node * DEG;
      seasons.rotation.y = e.node * DEG;
      moon.position.copy(dir(e.sun + e.lambda, e.beta * k).multiplyScalar(MOON_ORBIT));
      // 影子都背向太阳
      var away = ep.clone().normalize();
      var q = new THREE.Quaternion().setFromUnitVectors(new V3(0, -1, 0), away);
      earthShadow.quaternion.copy(q);
      moonShadow.quaternion.copy(q);
      moonShadow.position.copy(moon.position);
      earthShadow.visible = moonShadow.visible = st.shadows;
      allLabels.forEach(function (o) { o.visible = st.labels; o.element.style.display = st.labels ? '' : 'none'; });
      // 跟随地球：相机随地球平移，保留用户转动的角度
      if (view === 'earth') {
        if (haveLast) { var d = ep.clone().sub(lastEarth); camera.position.add(d); controls.target.add(d); }
      }
      lastEarth.copy(ep); haveLast = true;
    }

    function resize(w, h) {
      renderer.setSize(w, h);
      labelRenderer.setSize(w, h);
      camera.aspect = w / h;
      camera.userData.fit = Math.max(1, 1.3 / camera.aspect);
      camera.updateProjectionMatrix();
    }
    function setView(v) {
      view = v;
      var fit = camera.userData.fit || 1;
      if (v === 'earth') {
        // 从地球公转方向的侧后方、略高于黄道面看：日地连线横在画面中，看月球从影子上方还是下方经过
        var ep = earthG.position, away = ep.clone().normalize(), side = new V3().crossVectors(Y, away).normalize();
        controls.target.copy(ep);
        camera.position.copy(ep).add(side.multiplyScalar(-15 * fit)).add(new V3(0, 3.2 * fit, 0)).add(away.multiplyScalar(2));
      } else {
        controls.target.set(0, 0, 0);
        camera.position.set(0, 40 * fit, 48 * fit);
      }
      controls.update();
    }
    function render() {
      controls.update();
      renderer.render(scene, camera);
      labelRenderer.render(scene, camera);
    }
    function setVisible(on) {
      canvas.style.display = on ? '' : 'none';
      lEl.style.display = on ? '' : 'none';
    }

    return {
      update: update, resize: resize, setView: setView, render: render, setVisible: setVisible,
      view: function () { return view; }
    };
  };
})();
