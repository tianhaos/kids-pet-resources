// 纯计算：日食、月食的影子几何与食相判断，一年中的朔望与食季，练习题（不碰 DOM）
// 侧视示意图（单位：地球半径，x 向右、y 向上）：太阳在左 (−Ds, 0)，地球在原点；日食时月球在日地之间，月食时在地球右侧
// 示意图不按比例：为了把太阳、地球、月球画在一个画面里，太阳画得很近很小、月球离地球很近；
// 但日食的“本影能否到达地面”按真实的月地距离换算，月食的地影大小（相对月球）按真实比例
(function () {
  var DEG = Math.PI / 180;
  var SYNODIC = 29.530589;   // 朔望月（天）
  var INCL = 5.145;          // 白道与黄道的夹角（°）

  // 示意几何
  var GEO = { Ds: 14, Rs: 3, Re: 1, Rm: 0.27, dl: 3.4 };
  // 真实月地距离（km）
  var PERIGEE = 356500, APOGEE = 406700, MEAN = 384400;

  // 月食：以月球半径为单位，月球处地球本影、半影的半径（平均距离，含大气使地影扩大约 2%）
  var UMBRA = 2.7, PENUMBRA = 4.8;
  var LUNAR_SPEED = 1.96;    // 月球相对地影每小时移动约 1.96 个月球半径（约 0.5°/h）

  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
  function wrap360(a) { return ((a % 360) + 360) % 360; }
  function wrap180(a) { return wrap360(a + 180) - 180; }

  // ---------- 日食：月地距离 → 示意图中月球的位置 ----------
  // 真实情况：月球本影长约 37.4 万 km，近地点时伸过地面（全食），远地点时够不着（环食）。
  // 示意图里让本影尖端越过地面的比例 ε/L 随月地距离线性变化（近地点 +25%、远地点 −25%，约为真实的 4 倍，便于看清）
  // EQUAL：从日下点看月球与太阳一样大时的月地距离（月球半径 1737.4 km ÷ tan 0.2666° + 地球半径），此时 ε = 0
  var EQUAL = 379770;
  function overshoot(km) {
    return km < EQUAL ? 0.25 * (EQUAL - km) / (EQUAL - PERIGEE) : -0.25 * (km - EQUAL) / (APOGEE - EQUAL);
  }
  // 从地面（月下点）看月球与太阳的真实视直径（°）
  function moonDiam(km) { return 2 * Math.atan(1737.4 / (km - 6378)) / DEG; }
  var SUN_DIAM = 0.533;
  function moonX(km) {
    var c = GEO.Rm / (GEO.Rs - GEO.Rm), g = 1 - overshoot(km);
    return -(1 + GEO.Ds * c * g) / (1 + c * g);
  }

  // ---------- 两圆的公切线 ----------
  // 外公切线（本影 / 伪本影的边界）与内公切线（半影的边界）；t1 在圆 1（太阳）上，t2 在圆 2 上，d 为从 t1 指向 t2 的方向
  function tangents(c1, r1, c2, r2) {
    var dx = c2.x - c1.x, dy = c2.y - c1.y, D = Math.hypot(dx, dy), ux = dx / D, uy = dy / D;
    function lines(cos, inner) {
      var s = Math.sqrt(Math.max(0, 1 - cos * cos)), out = [];
      [1, -1].forEach(function (sg) {
        var nx = ux * cos - uy * s * sg, ny = uy * cos + ux * s * sg;
        var t1 = { x: c1.x + r1 * nx, y: c1.y + r1 * ny };
        var k = inner ? -r2 : r2;
        var t2 = { x: c2.x + k * nx, y: c2.y + k * ny };
        var L = Math.hypot(t2.x - t1.x, t2.y - t1.y);
        out.push({ t1: t1, t2: t2, d: { x: (t2.x - t1.x) / L, y: (t2.y - t1.y) / L } });
      });
      return out;
    }
    var tip = { x: c1.x + dx * r1 / (r1 - r2), y: c1.y + dy * r1 / (r1 - r2) };
    return { ext: lines((r1 - r2) / D, false), int: lines((r1 + r2) / D, true), tip: tip, len: Math.hypot(tip.x - c2.x, tip.y - c2.y) };
  }

  // ---------- 两个圆面的遮挡 ----------
  // 两圆（半径 R、r，圆心距 d）重叠面积
  function overlap(R, r, d) {
    if (d >= R + r) return 0;
    if (d <= Math.abs(R - r)) return Math.PI * Math.min(R, r) * Math.min(R, r);
    var a = Math.acos(clamp((d * d + R * R - r * r) / (2 * d * R), -1, 1));
    var b = Math.acos(clamp((d * d + r * r - R * R) / (2 * d * r), -1, 1));
    return R * R * (a - Math.sin(2 * a) / 2) + r * r * (b - Math.sin(2 * b) / 2);
  }

  // 太阳（视半径 as）被月球（视半径 am，两者中心角距 sep）遮住的情况
  function solarType(as, am, sep) {
    sep = Math.abs(sep);
    var o = { mag: Math.max(0, (as + am - sep) / (2 * as)), cover: overlap(as, am, sep) / (Math.PI * as * as) };
    if (sep >= as + am) o.type = 'none';
    else if (am >= as && sep <= am - as) o.type = 'total';
    else if (am < as && sep <= as - am) o.type = 'annular';
    else o.type = 'partial';
    return o;
  }

  // 观察者（地面上与日下点夹角 theta，度，向上为正）
  function observerPos(theta) { return { x: -Math.cos(theta * DEG), y: Math.sin(theta * DEG) }; }

  // 从点 p 看半径 r、圆心 c 的圆：方向角与视半径（弧度）
  function look(p, c, r) {
    var dx = c.x - p.x, dy = c.y - p.y, d = Math.hypot(dx, dy);
    return { dir: Math.atan2(dy, dx), rad: Math.asin(Math.min(1, r / d)), dist: d };
  }

  // 日食：月球位于示意图 m = {x, y}，从地面点 p 看到的太阳与月球
  function solarView(p, m) {
    var sun = { x: -GEO.Ds, y: 0 };
    var s = look(p, sun, GEO.Rs), mo = look(p, m, GEO.Rm);
    var sep = mo.dir - s.dir;
    sep = Math.atan2(Math.sin(sep), Math.cos(sep));
    // 太阳是否在地平线以上：地面法线与太阳方向的夹角
    var n = Math.atan2(p.y, p.x), alt = 90 - Math.abs(Math.atan2(Math.sin(s.dir - n), Math.cos(s.dir - n))) / DEG;
    var o = solarType(s.rad, mo.rad, sep);
    o.sun = s; o.moon = mo; o.sep = sep; o.alt = alt;
    if (alt < 0) o.type = 'night';
    return o;
  }

  // 太阳与月球的连线方向上，地面上 theta 处属于哪个区
  function zoneAt(theta, m) { return solarView(observerPos(theta), m).type; }

  // 地球朝向太阳的一面上，各区覆盖的角度范围（侧视截面）
  function groundZones(m) {
    var list = [], cur = null;
    for (var th = -90; th <= 90.001; th += 0.25) {
      var z = zoneAt(th, m);
      if (!cur || cur.type !== z) { cur = { type: z, from: th, to: th }; list.push(cur); } else cur.to = th;
    }
    return list.filter(function (z) { return z.type !== 'none' && z.type !== 'night'; });
  }

  var SOLAR_NAME = { total: '日全食', annular: '日环食', partial: '日偏食', none: '看不到日食', night: '夜晚，看不到太阳' };
  var SOLAR_ZONE = { total: '本影区', annular: '伪本影区', partial: '半影区', none: '影子以外', night: '夜半球' };

  // ---------- 月食 ----------
  // 月球中心相对地影中心的位置（单位：月球半径；x 向西为正，y 向北为正），t 为距食甚的小时数，b 为月球离地影中心最近的距离
  function lunarPos(t, b) { return { x: -LUNAR_SPEED * t, y: b }; }
  function lunarStage(r) {
    if (r >= PENUMBRA + 1) return 'none';
    if (r > UMBRA + 1) return 'penumbral';
    if (r > UMBRA - 1) return 'partial';
    return 'total';
  }
  // 这次月食的类型（由 b 决定）与各食相时刻（小时，相对食甚）
  function lunarEvent(b) {
    b = Math.abs(b);
    var type = lunarStage(b);
    function half(R) { return R > b ? Math.sqrt(R * R - b * b) / LUNAR_SPEED : null; }
    var p = half(PENUMBRA + 1), u1 = half(UMBRA + 1), u2 = half(UMBRA - 1);
    var c = [];
    if (p != null) c.push({ key: 'P1', name: '半影食始', t: -p });
    if (u1 != null) c.push({ key: 'U1', name: '初亏', t: -u1 });
    if (u2 != null) c.push({ key: 'U2', name: '食既', t: -u2 });
    if (p != null) c.push({ key: 'MAX', name: '食甚', t: 0 });
    if (u2 != null) c.push({ key: 'U3', name: '生光', t: u2 });
    if (u1 != null) c.push({ key: 'U4', name: '复圆', t: u1 });
    if (p != null) c.push({ key: 'P4', name: '半影食终', t: p });
    return {
      type: type, contacts: c,
      mag: (UMBRA + 1 - b) / 2,              // 本影食分：月球直径被本影遮住的比例（大于 1 为全食）
      totality: u2 != null ? 2 * u2 : 0, umbral: u1 != null ? 2 * u1 : 0
    };
  }
  // 月面被本影遮住的面积比例
  function lunarCover(r) { return overlap(UMBRA, 1, r) / Math.PI; }
  var LUNAR_NAME = { total: '月全食', partial: '月偏食', penumbral: '半影月食', none: '没有月食' };

  // 侧视图（月食）：真实距离 r（月球半径）→ 示意图中月心离地影轴的距离（地球半径），使进出本影、半影的时刻一致
  function lunarSideY(r) {
    var d = GEO.dl, rm = GEO.Rm;
    var us = GEO.Re - d * (GEO.Rs - GEO.Re) / GEO.Ds, ps = GEO.Re + d * (GEO.Rs + GEO.Re) / GEO.Ds;
    var A = [0, UMBRA - 1, UMBRA + 1, PENUMBRA - 1, PENUMBRA + 1, PENUMBRA + 8];
    var B = [0, us - rm, us + rm, ps - rm, ps + rm, ps + rm + 1.4];
    r = Math.abs(r);
    for (var i = 1; i < A.length; i++) {
      if (r <= A[i]) return B[i - 1] + (B[i] - B[i - 1]) * (r - A[i - 1]) / (A[i] - A[i - 1]);
    }
    return B[B.length - 1];
  }

  // ---------- 一年中的朔望与食季（2026 年，按平均运动推算，朔望时刻加主要周期修正） ----------
  // 平均要素（Meeus）：d 为自 J2000.0 起的天数；D 月球与太阳的黄经差（日月角距），F 月球离升交点的角距（纬度参数）
  // t 为北京时间当年 1 月 1 日 0 时起的天数
  function leap(y) { return (y % 4 === 0 && y % 100 !== 0) || y % 400 === 0; }
  var YEAR, EPOCH, MONTH_DAYS;
  function setYear(y) {
    YEAR = y;
    var days = 0;
    for (var k = 2000; k < y; k++) days += leap(k) ? 366 : 365;
    EPOCH = days - 0.5 - 8 / 24;    // J2000.0 为 2000-01-01 12 时（世界时），北京时间早 8 小时
    MONTH_DAYS = [31, leap(y) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  }
  setYear(2026);
  function yearDays() { return leap(YEAR) ? 366 : 365; }
  function elements(t) {
    var d = EPOCH + t;
    var L = wrap360(280.460 + 0.9856474 * d);          // 太阳平黄经
    var D = wrap360(297.8502 + 12.19074912 * d);       // 平日月角距
    var F = wrap360(93.2721 + 13.2293505 * d);         // 月球纬度参数
    var Lm = wrap360(218.3165 + 13.17639648 * d);      // 月球平黄经
    var Mm = (134.9634 + 13.064993 * d) * DEG, f = F * DEG;
    // 月球黄纬：主项 + 最大的几个周期项
    var D2 = 2 * D * DEG;
    var beta = 5.128 * Math.sin(f) + 0.2806 * Math.sin(Mm + f) + 0.2777 * Math.sin(Mm - f) + 0.1732 * Math.sin(D2 - f) +
      0.0554 * Math.sin(D2 - Mm + f) + 0.0463 * Math.sin(D2 - Mm - f) + 0.0326 * Math.sin(D2 + f) + 0.0172 * Math.sin(2 * Mm + f);
    // 月地距离（km）与太阳的视半径（°）
    var dist = 385000.6 - 20905.4 * Math.cos(Mm) - 3699.1 * Math.cos(D2 - Mm) - 2956 * Math.cos(D2);
    var Ms = (357.5291 + 0.98560028 * d) * DEG;
    var sunRad = 0.2666 * (1 + 0.0167 * Math.cos(Ms));
    // 真黄经（主要周期项）：太阳的中心差，月球的中心差、出差、二均差等
    var sunT = wrap360(L + 1.915 * Math.sin(Ms) + 0.020 * Math.sin(2 * Ms));
    var moonT = wrap360(Lm + 6.289 * Math.sin(Mm) + 1.274 * Math.sin(D2 - Mm) + 0.658 * Math.sin(D2) + 0.214 * Math.sin(2 * Mm) - 0.186 * Math.sin(Ms));
    return { sun: sunT, moon: moonT, lambda: wrap360(moonT - sunT), D: D, u: F, node: wrap360(Lm - F), beta: beta, dist: dist, sunRad: sunRad };
  }
  // 一年中每次新月（朔）、满月（望）及是否发生日食、月食
  // 判断标准：朔时月球黄纬 |β| < 1.48° 发生日食，其中 γ < 0.997 时本影或伪本影扫过地面，再比较月球（从地面看）
  // 与太阳的视半径分全食、环食；望时按当时的地影大小（随月地距离变化）分月全食、月偏食、半影月食
  // 已与 2025—2030 年的实际日月食核对（类型一致，日期按北京时间）
  var LIM = { solar: 1.48, central: 0.997 };
  function syzygies(t0, t1) {
    var e0 = elements(0), rate = 12.19074912, out = [];
    var k = Math.ceil(((t0 * rate) + e0.D) / 180 - 1e-9);
    for (;; k++) {
      var t = (k * 180 - e0.D) / rate, d = EPOCH + t;
      // 平朔望 → 真朔望：月球、太阳轨道偏心造成的主要修正（天），误差约 1 小时
      var Ms = (357.5291 + 0.98560028 * d) * DEG, Mm = (134.9634 + 13.064993 * d) * DEG, F2 = 2 * elements(t).u * DEG;
      t += -0.407 * Math.sin(Mm) + 0.173 * Math.sin(Ms) + 0.0161 * Math.sin(2 * Mm) - 0.0097 * Math.sin(F2);
      if (t > t1) break;
      if (t < t0) continue;
      var e = elements(t), isNew = k % 2 === 0, b = Math.abs(e.beta), ecl = null;
      if (isNew) {
        // γ：月影轴离地心最近的距离（地球半径）；γ < 0.997 时本影或伪本影扫过地面
        var gamma = b * Math.cos(INCL * DEG) / (Math.asin(6378 / e.dist) / DEG);
        if (gamma < LIM.central) ecl = Math.atan(1737.4 / (e.dist - 6378)) / DEG > e.sunRad ? 'solarTotal' : 'solarAnnular';
        else if (b < LIM.solar) ecl = 'solarPartial';
      }
      else {
        // 地影大小随月地距离变化：本影半径 = 1.02 ×（月球视差 + 太阳视差 − 太阳视半径），半影把减号换成加号
        var par = Math.asin(6378 / e.dist) / DEG + 0.0024, mr = Math.asin(1737.4 / e.dist) / DEG;
        var U = 1.02 * (par - e.sunRad), P = 1.02 * (par + e.sunRad);
        b *= Math.cos(INCL * DEG);     // 月球斜着穿过地影，离地影中心最近的距离略小于望时的黄纬
        if (b < U - mr) ecl = 'total';
        else if (b < U + mr) ecl = 'partial';
        else if (b < P + mr) ecl = 'penumbral';
      }
      out.push({ t: t, kind: isNew ? 'new' : 'full', beta: e.beta, u: e.u, dist: e.dist, eclipse: ecl });
    }
    return out;
  }
  var ECL_NAME = { solarTotal: '日全食', solarAnnular: '日环食', solarPartial: '日偏食', total: '月全食', partial: '月偏食', penumbral: '半影月食' };
  // 太阳离最近的交点多少度（食季：太阳在交点附近约 ±17° 内）
  function sunNode(t) { var e = elements(t), x = Math.abs(wrap180(e.sun - e.node)); return Math.min(x, 180 - x); }
  function dateOf(t) {
    var day = Math.floor(t), m = 0;
    while (m < 11 && day >= MONTH_DAYS[m]) { day -= MONTH_DAYS[m]; m++; }
    return { month: m + 1, day: day + 1 };
  }
  function fmtDate(t) { var d = dateOf(t); return d.month + ' 月 ' + d.day + ' 日'; }

  // ---------- 练习题 ----------
  // type: zone 侧视图上判断某地看到的日食、stage 月食进程图判断食相、fact 日食月食的条件与过程
  function pick(rng, a) { return a[Math.floor(rng() * a.length)]; }
  function shuffle(rng, a) {
    for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(rng() * (i + 1)), t = a[i]; a[i] = a[j]; a[j] = t; }
    return a;
  }
  var FACTS = [
    { q: '日食发生时，月相是？', a: '新月', o: ['新月', '上弦月', '满月', '下弦月'],
      e: '日食是月球挡住了太阳，月球必须在太阳和地球之间，日、月、地大致在一条直线上，这时是新月（朔）。' },
    { q: '月食发生时，月相是？', a: '满月', o: ['新月', '上弦月', '满月', '下弦月'],
      e: '月食是月球进入地球的影子，地球必须在太阳和月球之间，日、地、月大致在一条直线上，这时是满月（望）。' },
    { q: '日食一般发生在农历哪一天前后？', a: '初一', o: ['初一', '初八', '十五', '廿三'],
      e: '日食发生在朔日，也就是农历初一。' },
    { q: '月食一般发生在农历哪几天？', a: '十五、十六', o: ['初一', '初七、初八', '十五、十六', '廿二、廿三'],
      e: '月食发生在望日，也就是农历十五、十六前后。' },
    { q: '日食发生时，日、地、月三者的排列是？', a: '太阳—月球—地球', o: ['太阳—月球—地球', '太阳—地球—月球', '月球—太阳—地球', '三者成直角'],
      e: '月球在中间，挡住了射向地球的太阳光，月球的影子落在地球上。' },
    { q: '月食发生时，日、地、月三者的排列是？', a: '太阳—地球—月球', o: ['太阳—月球—地球', '太阳—地球—月球', '月球—太阳—地球', '三者成直角'],
      e: '地球在中间，地球的影子落在月球上。' },
    { q: '日偏食时，太阳从哪一边开始缺？', a: '西边', o: ['东边', '西边', '上边', '下边'],
      e: '月球自西向东绕地球公转，比太阳在天空中向东移动得快，从西边追上并挡住太阳，所以日食从太阳的西边缘开始（初亏），从东边缘结束（复圆）。' },
    { q: '月食时，月亮从哪一边开始缺？', a: '东边', o: ['东边', '西边', '上边', '下边'],
      e: '月球自西向东运动，先进入地影的是它的东边缘，所以月食从月亮的东边缘开始（初亏），从西边缘结束（复圆）。' },
    { q: '为什么不是每个农历初一都发生日食？', a: '月球轨道与黄道面有约 5° 的夹角', o: ['月球轨道与黄道面有约 5° 的夹角', '初一时月球离地球太远', '初一时太阳被云挡住', '月球自转太慢'],
      e: '白道面与黄道面有约 5° 的夹角，多数新月时月球从太阳的上方或下方经过，只有新月恰好在交点附近时才会发生日食。' },
    { q: '能看到日全食的人，位于月球的哪个影区？', a: '本影区', o: ['本影区', '半影区', '伪本影区', '影子以外'],
      e: '本影区里太阳光完全被月球挡住，看到日全食；半影区看到日偏食；伪本影区看到日环食。' },
    { q: '日环食发生时，月球大约在什么位置？', a: '远地点附近', o: ['近地点附近', '远地点附近', '交点以外', '地球背后'],
      e: '月球在远地点附近时看起来比太阳小一点，挡不住整个太阳，四周露出一圈亮环，就是日环食。' },
    { q: '月全食时月亮为什么常呈暗红色？', a: '地球大气把红光折射进本影', o: ['地球大气把红光折射进本影', '月球本身发出红光', '太阳光直接照到月球', '月球表面是红色的'],
      e: '太阳光穿过地球大气时，蓝光多被散射掉，波长较长的红光被大气折射进地球的本影，照在月面上，所以全食时的月亮呈古铜色。' }
  ];
  var MOON_KM = { total: [358000, 368000], annular: [398000, 405000] };

  function quiz(rng, prevId, only) {
    rng = rng || Math.random;
    var q, tries = 0;
    do {
      var type = only || pick(rng, ['zone', 'zone', 'stage', 'stage', 'fact', 'fact']);
      if (type === 'zone') {
        var kind = rng() < 0.5 ? 'total' : 'annular';
        var km = MOON_KM[kind][0] + rng() * (MOON_KM[kind][1] - MOON_KM[kind][0]);
        var m = { x: moonX(km), y: (rng() - 0.5) * 0.5 };
        var zs = groundZones(m);
        // 四个观察点：中心区、半影区两侧各一个、影子以外一个
        var core = zs.filter(function (z) { return z.type === kind; })[0];
        var pen = zs.filter(function (z) { return z.type === 'partial'; });
        if (!core || pen.length < 2) { q = null; continue; }
        var lo = Math.min(pen[0].from, pen[1].from), hi = Math.max(pen[0].to, pen[1].to);
        var outs = [lo - 12 - rng() * 10, hi + 12 + rng() * 10].filter(function (t) { return t > -80 && t < 80; });
        var pts = [
          (core.from + core.to) / 2,
          (pen[0].from + pen[0].to) / 2, (pen[1].from + pen[1].to) / 2,
          pick(rng, outs)
        ];
        var names = shuffle(rng, ['A', 'B', 'C', 'D']);
        var marks = pts.map(function (th, i) { return { name: names[i], theta: th, type: zoneAt(th, m) }; });
        var ask = pick(rng, marks);
        q = { type: type, id: 'zone' + kind + ask.type, km: km, moon: m, marks: marks, ask: ask.name };
        q.prompt = '图中 ' + ask.name + ' 处的人看到的是？';
        q.answer = SOLAR_NAME[ask.type];
        q.options = [SOLAR_NAME.total, SOLAR_NAME.annular, SOLAR_NAME.partial, SOLAR_NAME.none];
        q.explain = '月球在' + (kind === 'total' ? '近地点附近，本影能到达地面' : '远地点附近，本影够不着地面，延长出去的是伪本影') + '。' +
          ask.name + ' 处位于' + SOLAR_ZONE[ask.type] + '，看到' + SOLAR_NAME[ask.type].replace('看到', '') + '。';
      } else if (type === 'stage') {
        var bs = [0.3, 0.9, 1.6, 2.6, 3.4];
        var b = pick(rng, bs) * (rng() < 0.5 ? 1 : -1);
        var t = (rng() - 0.5) * 3.6;
        var p = lunarPos(t, b), r = Math.hypot(p.x, p.y), st = lunarStage(r);
        if (Math.abs(r - (UMBRA + 1)) < 0.25 || Math.abs(r - (UMBRA - 1)) < 0.25 || Math.abs(r - (PENUMBRA + 1)) < 0.25) { q = null; continue; }
        q = { type: type, id: 'stage' + st + b, b: b, t: t };
        q.prompt = '图中虚线圈是地球的本影和半影，此时看到的是？';
        q.answer = LUNAR_NAME[st];
        q.options = [LUNAR_NAME.total, LUNAR_NAME.partial, LUNAR_NAME.penumbral, LUNAR_NAME.none];
        q.explain = {
          total: '整个月球都在地球的本影里，太阳光被地球完全挡住，月亮变成暗红色：月全食。',
          partial: '月球一部分进入本影，被本影遮住的部分明显变暗：月偏食。',
          penumbral: '月球只进入了半影，太阳光只被挡住一部分，月面只是略微变暗，肉眼不易察觉：半影月食。',
          none: '月球在地球的影子以外，看到的是满月，没有月食。'
        }[st];
      } else {
        var i = Math.floor(rng() * FACTS.length), f = FACTS[i];
        q = { type: type, id: 'fact' + i, fact: i, prompt: f.q, answer: f.a, options: shuffle(rng, f.o.slice()), explain: f.e };
        q.scene = /月食|满月|十五/.test(f.q) ? 'lunar' : 'solar';
      }
    } while ((!q || q.id === prevId) && ++tries < 30);
    if (!q) return quiz(rng, null, only);
    return q;
  }

  window.Eclipse = {
    DEG: DEG, SYNODIC: SYNODIC, INCL: INCL, GEO: GEO,
    PERIGEE: PERIGEE, APOGEE: APOGEE, MEAN: MEAN, UMBRA: UMBRA, PENUMBRA: PENUMBRA, LUNAR_SPEED: LUNAR_SPEED,
    clamp: clamp, wrap360: wrap360, wrap180: wrap180,
    EQUAL: EQUAL, SUN_DIAM: SUN_DIAM, overshoot: overshoot, moonX: moonX, moonDiam: moonDiam, tangents: tangents, overlap: overlap,
    solarType: solarType, observerPos: observerPos, solarView: solarView, zoneAt: zoneAt, groundZones: groundZones,
    SOLAR_NAME: SOLAR_NAME, SOLAR_ZONE: SOLAR_ZONE,
    lunarPos: lunarPos, lunarStage: lunarStage, lunarEvent: lunarEvent, lunarCover: lunarCover, lunarSideY: lunarSideY,
    LUNAR_NAME: LUNAR_NAME,
    setYear: setYear, year: function () { return YEAR; }, yearDays: yearDays, LIM: LIM, elements: elements, syzygies: syzygies, ECL_NAME: ECL_NAME, sunNode: sunNode,
    dateOf: dateOf, fmtDate: fmtDate,
    FACTS: FACTS, quiz: quiz
  };
})();
