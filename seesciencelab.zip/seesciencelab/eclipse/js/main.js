(function () {
  var E = window.Eclipse, D = window.EclipseDraw, G = E.GEO;
  var $ = function (id) { return document.getElementById(id); };
  var qa = function (sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); };
  var YEARS = [2025, 2026, 2027, 2028, 2029, 2030];
  var SPEEDS = [{ v: 2, t: '2 天/秒' }, { v: 8, t: '8 天/秒' }, { v: 30, t: '30 天/秒' }];

  var state = {
    scene: 'solar',
    solar: { y: 0.12, km: 362000, obs: 0, zoom: true, play: false },
    lunar: { t: -1.5, b: 0.6, play: false },
    year: { year: 2026, t: 47.6, play: false, speed: 1, view: 'over', exag: true, shadows: true, labels: true },
    show: { fill: true, lines: true, labels: true, shadow: true, path: true },
    quiz: null, answered: false, correct: false, choice: null, score: { n: 0, ok: 0 }
  };

  var HINTS = {
    solar: '上下拖动月球 · 沿地面拖动观察者',
    lunar: '拖动月球，或按播放看月食的全过程',
    year: '拖动旋转视角 · 点时间轴跳到某一天',
    quiz: '日食和月食判断练习'
  };

  var stage = $('stage'), panel = $('panel'), cv = $('view');
  var view = D.View(cv);
  var S3, has3d = true;
  try {
    S3 = window.EclipseScene(stage, {});
  } catch (err) {
    // 不支持 WebGL：「一年中的日月食」只剩时间轴和读数，其余 2D 场景照常
    has3d = false;
    var nop = function () {};
    S3 = { update: nop, resize: nop, setView: nop, render: nop, setVisible: nop, view: function () { return 'over'; } };
    var msg = document.createElement('div');
    msg.id = 'no3d'; msg.dataset.for = 'year';
    msg.textContent = '此浏览器不支持 WebGL，无法显示 3D 日地月；下方时间轴和右侧读数仍可使用。';
    stage.appendChild(msg);
    $('resetView').dataset.for = 'none';
  }

  function setSeg(attr, val) { qa('[data-' + attr + ']').forEach(function (b) { b.classList.toggle('on', b.dataset[attr] === String(val)); }); }
  function solarMoon() { return { x: E.moonX(state.solar.km), y: state.solar.y }; }

  // ---------- 场景 ----------
  qa('[data-scene]').forEach(function (b) {
    b.addEventListener('click', function () { setScene(b.dataset.scene); Analytics.track('日食月食', '场景', b.textContent); });
  });
  function setScene(sc) {
    state.scene = sc;
    stopAll();
    if (sc === 'quiz' && !state.quiz) newQuiz();
    $('rName').className = '';
    S3.setVisible(sc === 'year');
    cv.style.display = sc === 'year' ? 'none' : '';
    syncUI();
  }
  function stopAll() { setPlay('solar', false); setPlay('lunar', false); setPlay('year', false); }
  var PLAY_BTN = { solar: 'playSolar', lunar: 'playLunar', year: 'playYear' };
  function setPlay(k, on) {
    state[k].play = on;
    $(PLAY_BTN[k]).textContent = on ? '❚❚ 暂停' : '▶ 播放';
    $(PLAY_BTN[k]).classList.toggle('on', on);
  }
  Object.keys(PLAY_BTN).forEach(function (k) {
    $(PLAY_BTN[k]).addEventListener('click', function () {
      setPlay(k, !state[k].play);
      if (state[k].play) {
        if (k === 'lunar' && state.lunar.t >= 3.95) state.lunar.t = -4;
        Analytics.track('日食月食', '播放', k);
      }
    });
  });

  // ---------- 日食 ----------
  function bindSlider(id, get, set) {
    var el = $(id);
    el.addEventListener('input', function () { set(parseFloat(el.value)); });
    return { el: el, get: get };
  }
  var sliders = [
    bindSlider('moonY', function () { return state.solar.y; }, function (v) { setPlay('solar', false); state.solar.y = v; }),
    bindSlider('km', function () { return state.solar.km; }, function (v) { state.solar.km = v; }),
    bindSlider('obs', function () { return state.solar.obs; }, function (v) { state.solar.obs = v; }),
    bindSlider('lt', function () { return state.lunar.t; }, function (v) { setPlay('lunar', false); state.lunar.t = v; }),
    bindSlider('lb', function () { return state.lunar.b; }, function (v) { state.lunar.b = v; }),
    bindSlider('day', function () { return state.year.t; }, function (v) { setPlay('year', false); state.year.t = v; })
  ];
  qa('[data-km]').forEach(function (b) {
    b.addEventListener('click', function () { state.solar.km = +b.dataset.km; Analytics.track('日食月食', '月地距离', b.textContent); });
  });
  qa('[data-zoom]').forEach(function (b) {
    b.addEventListener('click', function () { state.solar.zoom = b.dataset.zoom === '1'; syncUI(); });
  });
  [['showFill', 'fill'], ['showLines', 'lines'], ['showLabels', 'labels'], ['showShadow', 'shadow'], ['showPath', 'path']].forEach(function (p) {
    $(p[0]).addEventListener('change', function () { state.show[p[1]] = $(p[0]).checked; });
  });

  // 在画布上拖动：日食拖月球（上下）和观察者（沿地面），月食拖月球
  var drag = null;
  function local(e) { var r = cv.getBoundingClientRect(); return { x: e.clientX - r.left, y: e.clientY - r.top }; }
  function hitSolar(p) {
    var g = view.geo(); if (!g) return null;
    var wx = (p.x - g.X(0)) / g.s, wy = (g.Y(0) - p.y) / g.s, m = solarMoon();
    if (Math.hypot(wx - m.x, wy - m.y) < Math.max(G.Rm * 2, 18 / g.s)) return 'moon';
    var op = E.observerPos(state.solar.obs), tip = { x: op.x * (1 + 19 / (g.s)), y: op.y * (1 + 19 / g.s) };
    if (Math.hypot(wx - tip.x, wy - tip.y) < 16 / g.s) return 'obs';
    var d = Math.hypot(wx, wy);
    if (wx < 0.3 && Math.abs(d - 1) < Math.max(0.12, 14 / g.s)) return 'obs';
    return null;
  }
  function hitLunar(p) {
    var g = view.geo(); if (!g || !g.k) return null;
    var m = E.lunarPos(state.lunar.t, state.lunar.b);
    return Math.hypot(p.x - g.X(m.x), p.y - g.Y(m.y)) < g.k * 1.5 ? 'lmoon' : null;
  }
  function dragTo(p) {
    var g = view.geo();
    if (drag === 'moon') {
      state.solar.y = E.clamp((g.Y(0) - p.y) / g.s, -1.5, 1.5);
    } else if (drag === 'obs') {
      var wx = (p.x - g.X(0)) / g.s, wy = (g.Y(0) - p.y) / g.s;
      state.solar.obs = E.clamp(Math.atan2(wy, -wx) / E.DEG, -80, 80);
    } else if (drag === 'lmoon') {
      var x = (p.x - g.X(0)) / g.k, y = (g.Y(0) - p.y) / g.k;
      state.lunar.t = E.clamp(-x / E.LUNAR_SPEED, -4, 4);
      state.lunar.b = E.clamp(y, -6.5, 6.5);
    }
  }
  cv.addEventListener('pointerdown', function (e) {
    if (e.button !== 0) return;
    var p = local(e);
    drag = state.scene === 'solar' ? hitSolar(p) : state.scene === 'lunar' ? hitLunar(p) : null;
    if (!drag) return;
    if (drag === 'moon') setPlay('solar', false);
    if (drag === 'lmoon') setPlay('lunar', false);
    try { cv.setPointerCapture(e.pointerId); } catch (err) { /* 合成事件 */ }
    cv.style.cursor = 'grabbing';
    Analytics.track('日食月食', '拖动', drag);
    dragTo(p);
  });
  cv.addEventListener('pointermove', function (e) {
    var p = local(e);
    if (drag) { dragTo(p); return; }
    if (e.buttons === 0) {
      var h = state.scene === 'solar' ? hitSolar(p) : state.scene === 'lunar' ? hitLunar(p) : null;
      cv.style.cursor = h ? 'grab' : '';
    }
  });
  function endDrag(e) {
    if (!drag) return;
    drag = null;
    if (cv.hasPointerCapture(e.pointerId)) cv.releasePointerCapture(e.pointerId);
    cv.style.cursor = '';
  }
  cv.addEventListener('pointerup', endDrag);
  cv.addEventListener('pointercancel', endDrag);

  // ---------- 月食 ----------
  qa('[data-lb]').forEach(function (b) {
    b.addEventListener('click', function () { state.lunar.b = +b.dataset.lb; Analytics.track('日食月食', '月食类型', b.textContent); });
  });
  var contactKey = '';
  function buildContacts() {
    var ev = E.lunarEvent(state.lunar.b);
    var list = ev.contacts.filter(function (c) { return c.key !== 'P1' && c.key !== 'P4'; });
    var key = list.map(function (c) { return c.key; }).join();
    if (key === contactKey) return list;
    contactKey = key;
    var box = $('contactBtns');
    box.innerHTML = '';
    box.style.gridTemplateColumns = 'repeat(' + Math.max(list.length, 1) + ', 1fr)';
    list.forEach(function (c) {
      var b = document.createElement('button');
      b.dataset.ck = c.key;
      b.textContent = c.name;
      b.addEventListener('click', function () {
        var cc = E.lunarEvent(state.lunar.b).contacts.filter(function (x) { return x.key === c.key; })[0];
        if (cc) { setPlay('lunar', false); state.lunar.t = cc.t; }
        Analytics.track('日食月食', '食相', c.name);
      });
      box.appendChild(b);
    });
    return list;
  }

  // ---------- 一年中的日月食 ----------
  var yearData = null;
  function setYear(y) {
    state.year.year = y;
    E.setYear(y);
    var days = E.yearDays(), list = E.syzygies(-1, days + 1), seasons = [], cur = null;
    for (var t = 0; t <= days; t += 0.5) {
      var on = E.sunNode(t) < 17;
      if (on && !cur) { cur = [t, t]; seasons.push(cur); } else if (on) cur[1] = t; else cur = null;
    }
    yearData = { days: days, list: list.filter(function (s) { return s.t >= 0 && s.t < days; }), all: list, seasons: seasons };
    $('day').max = days - 0.1;
    state.year.t = Math.min(state.year.t, days - 0.1);
    var box = $('eclList');
    box.innerHTML = '';
    yearData.list.filter(function (s) { return s.eclipse; }).forEach(function (s) {
      var b = document.createElement('button');
      b.className = s.kind === 'new' ? 'solar' : 'lunar';
      b.dataset.et = s.t;
      b.innerHTML = '<b>' + E.ECL_NAME[s.eclipse] + '</b>' + E.fmtDate(s.t);
      b.addEventListener('click', function () {
        setPlay('year', false);
        state.year.t = s.t;
        Analytics.track('日食月食', '跳到日月食', y + ' ' + b.textContent);
      });
      box.appendChild(b);
    });
    syncUI();
  }
  var yb = $('yearBtns');
  YEARS.forEach(function (y) {
    var b = document.createElement('button');
    b.dataset.yr = y;
    b.textContent = y;
    b.addEventListener('click', function () { setYear(y); Analytics.track('日食月食', '年份', String(y)); });
    yb.appendChild(b);
  });
  qa('[data-speed]').forEach(function (b) {
    b.addEventListener('click', function () { state.year.speed = +b.dataset.speed; syncUI(); });
  });
  qa('[data-view]').forEach(function (b) {
    b.addEventListener('click', function () {
      state.year.view = b.dataset.view;
      S3.setView(b.dataset.view); syncUI();
      Analytics.track('日食月食', '视角', b.textContent);
    });
  });
  $('resetView').addEventListener('click', function () { S3.setView(state.year.view); });
  [['exag', 'exag'], ['showShadows', 'shadows'], ['show3dLabels', 'labels']].forEach(function (p) {
    $(p[0]).addEventListener('change', function () { state.year[p[1]] = $(p[0]).checked; });
  });
  var barCanvas = $('yearBar'), barMap = null, barDrag = false;
  function barSet(e) {
    if (!barMap) return;
    var r = barCanvas.getBoundingClientRect();
    setPlay('year', false);
    state.year.t = barMap.tAt(e.clientX - r.left);
  }
  barCanvas.addEventListener('pointerdown', function (e) {
    barDrag = true;
    try { barCanvas.setPointerCapture(e.pointerId); } catch (err) { /* 合成事件 */ }
    barSet(e);
    Analytics.track('日食月食', '时间轴');
  });
  barCanvas.addEventListener('pointermove', function (e) { if (barDrag) barSet(e); });
  barCanvas.addEventListener('pointerup', function () { barDrag = false; });
  barCanvas.addEventListener('pointercancel', function () { barDrag = false; });

  // ---------- 练习 ----------
  function newQuiz() {
    state.quiz = E.quiz(Math.random, state.quiz && state.quiz.id, state.quizOnly);
    state.answered = false; state.choice = null;
    var box = $('quizOpts');
    box.innerHTML = '';
    state.quiz.options.forEach(function (o) {
      var b = document.createElement('button');
      b.className = 'small';
      b.textContent = o;
      b.addEventListener('click', function () { answer(o); });
      box.appendChild(b);
    });
    syncUI();
  }
  function answer(o) {
    if (state.answered) return;
    state.answered = true;
    state.choice = o;
    state.correct = o === state.quiz.answer;
    state.score.n++; if (state.correct) state.score.ok++;
    Analytics.track('日食月食', '练习', state.quiz.type + (state.correct ? ' 对' : ' 错'));
    syncUI();
  }
  $('nextQ').addEventListener('click', newQuiz);
  $('showQ').addEventListener('click', function () {
    var q = state.quiz;
    if (q.type === 'zone') {
      var ask = q.marks.filter(function (m) { return m.name === q.ask; })[0];
      state.solar.km = Math.round(q.km / 100) * 100; state.solar.y = q.moon.y; state.solar.obs = ask.theta; state.solar.zoom = true;
      setScene('solar');
    } else if (q.type === 'stage') {
      state.lunar.t = q.t; state.lunar.b = q.b;
      setScene('lunar');
    } else if (q.scene === 'lunar') {
      state.lunar.t = -1.5; state.lunar.b = 0.6;
      setScene('lunar');
    } else {
      state.solar.y = 0.12; state.solar.obs = 0;
      setScene('solar');
    }
  });

  // ---------- 面板 ----------
  $('panelToggle').addEventListener('click', function () { panel.classList.toggle('collapsed'); });
  if (window.matchMedia('(max-width: 760px)').matches) panel.classList.add('collapsed');
  window.addEventListener('keydown', function (e) {
    var tg = e.target.tagName;
    if (tg === 'INPUT' || tg === 'SELECT' || tg === 'BUTTON' || tg === 'TEXTAREA') return;
    if (e.code === 'Space' && PLAY_BTN[state.scene]) { e.preventDefault(); setPlay(state.scene, !state[state.scene].play); }
  });

  function syncUI() {
    var sc = state.scene;
    setSeg('scene', sc);
    qa('[data-for]').forEach(function (el) { el.hidden = el.dataset.for.split(' ').indexOf(sc) < 0; });
    $('hint').textContent = HINTS[sc];
    setSeg('zoom', state.solar.zoom ? '1' : '0');
    setSeg('speed', state.year.speed);
    $('speedNote').textContent = SPEEDS[state.year.speed].t;
    setSeg('view', state.year.view);
    setSeg('yr', state.year.year);
    [['showFill', 'fill'], ['showLines', 'lines'], ['showLabels', 'labels'], ['showShadow', 'shadow'], ['showPath', 'path']].forEach(function (p) { $(p[0]).checked = state.show[p[1]]; });
    $('exag').checked = state.year.exag; $('showShadows').checked = state.year.shadows; $('show3dLabels').checked = state.year.labels;
    var q = state.quiz;
    if (q) {
      $('quizQ').textContent = q.prompt;
      qa('#quizOpts button').forEach(function (b) {
        b.disabled = state.answered;
        b.classList.toggle('on', state.answered && b.textContent === q.answer);
        b.classList.toggle('no', state.answered && b.textContent === state.choice && !state.correct);
      });
      $('quizMsg').innerHTML = !state.answered ? ''
        : '<b class="' + (state.correct ? 'ok">✓ 答对了' : 'bad">✗ 应选「' + q.answer + '」') + '</b>' + q.explain;
      $('nextQ').textContent = state.answered ? '下一题 →' : '换一题';
      $('showQ').hidden = !state.answered;
    }
  }

  // ---------- 读数 ----------
  var last = {};
  function setText(id, s) { if (last[id] !== s) { last[id] = s; $(id).textContent = s; } }
  function rows(list) {
    for (var k = 1; k <= 5; k++) {
      var r = list[k - 1] || ['', ''];
      setText('d' + k, r[0]); setText('r' + k, r[1]);
      $('d' + k).hidden = $('r' + k).hidden = !r[0];
    }
  }
  function pct(x) { return Math.round(x * 100) + '%'; }
  function hm(h) {
    var m = Math.round(Math.abs(h) * 60), hh = Math.floor(m / 60), mm = m % 60;
    return (hh ? hh + ' 小时 ' : '') + mm + ' 分';
  }
  function kmText(km) { return (km / 10000).toFixed(1) + ' 万 km'; }

  var SOLAR_TIP = {
    total: '处在月球的本影里，太阳光全部被月球挡住：天空变暗，能看到太阳外围银白色的日冕。',
    annular: '本影够不着地面，这里在伪本影里：月球看起来比太阳小，挡在正中，四周露出一圈亮环。',
    partial: '处在月球的半影里，太阳只被挡住一部分。',
    none: '不在月球的影子里，太阳完整，看不到日食。',
    night: '这里是夜半球，太阳在地平线以下。'
  };
  function readSolar(v) {
    var km = state.solar.km, md = E.moonDiam(km), over = E.overshoot(km);
    setText('rName', E.SOLAR_NAME[v.type]);
    setText('rKind', E.SOLAR_ZONE[v.type]);
    setText('rTip', SOLAR_TIP[v.type]);
    var near = km < 368000 ? '，近地点附近' : km > 396000 ? '，远地点附近' : '';
    var seen = v.type !== 'night' && v.type !== 'none';
    rows([
      ['月地距离', kmText(km) + near],
      ['视直径', '月球 ' + md.toFixed(3) + '° · 太阳 ' + E.SUN_DIAM + '°'],
      ['本影', over >= 0 ? '能到达地面（全食）' : '够不着地面，伸过来的是伪本影（环食）'],
      ['食分', seen ? v.mag.toFixed(2) + '（太阳直径被遮住的比例）' : '—'],
      ['太阳被遮住', seen ? pct(v.cover) + ' 的面积' : '—']
    ]);
    setText('insetType', v.type === 'night' ? '' : E.SOLAR_NAME[v.type]);
    setText('insetFoot', seen ? '食分 ' + v.mag.toFixed(2) + ' · 遮住 ' + pct(v.cover) + ' · 月球自西向东移过' : v.type === 'none' ? '月球不在太阳前面' : '太阳在地平线以下');
  }

  var LUNAR_NOW = { total: '全食阶段', partial: '偏食阶段', penumbral: '半影食阶段', none: '不在地影中' };
  var LUNAR_TIP = {
    total: '整个月球都在地球的本影里，被大气折射进本影的红光照亮，呈暗红色（古铜色）。',
    partial: '月球一部分在本影里，那部分明显变暗、变成暗红色，像被咬掉了一块。',
    penumbral: '月球在地球的半影里，只有一部分太阳光被地球挡住，月面略微变暗，肉眼不易察觉。',
    none: '月球不在地球的影子里，看到的是一轮满月。'
  };
  function readLunar() {
    var L = state.lunar, p = E.lunarPos(L.t, L.b), r = Math.hypot(p.x, p.y), st = E.lunarStage(r), ev = E.lunarEvent(L.b);
    setText('rName', LUNAR_NOW[st]);
    setText('rKind', ev.type === 'none' ? '这次没有月食' : '这是一次' + E.LUNAR_NAME[ev.type]);
    setText('rTip', LUNAR_TIP[st]);
    rows([
      ['时刻', Math.abs(L.t) < 0.01 ? '食甚' : (L.t < 0 ? '食甚前 ' : '食甚后 ') + hm(L.t)],
      ['本影食分', ev.mag > 0 ? ev.mag.toFixed(2) + (ev.mag >= 1 ? '（≥ 1 为全食）' : '') : '—（没进入本影）'],
      ['全食持续', ev.totality ? hm(ev.totality) : '—'],
      ['本影食持续', ev.umbral ? hm(ev.umbral) + '（初亏到复圆）' : '—'],
      ['本影遮住月面', pct(E.lunarCover(r))]
    ]);
    var cs = buildContacts();
    qa('[data-ck]').forEach(function (b) {
      var c = cs.filter(function (x) { return x.key === b.dataset.ck; })[0];
      b.classList.toggle('on', !!c && Math.abs(c.t - L.t) < 0.02);
    });
  }

  function phaseName(l) {
    if (l < 6 || l > 354) return '新月';
    if (l < 84) return '娥眉月';
    if (l < 96) return '上弦月';
    if (l < 174) return '凸月（渐盈）';
    if (l < 186) return '满月';
    if (l < 264) return '凸月（渐亏）';
    if (l < 276) return '下弦月';
    return '残月';
  }
  function readYear() {
    var t = state.year.t, e = E.elements(t), all = yearData.all;
    var near = all.filter(function (s) { return Math.abs(s.t - t) < 0.75; })[0];
    var hour = Math.floor((t % 1) * 24);
    setText('rName', E.fmtDate(t) + ' ' + hour + ' 时');
    setText('rKind', near && near.eclipse ? E.ECL_NAME[near.eclipse] : phaseName(e.lambda));
    var tip;
    var side = e.beta >= 0 ? '以北' : '以南', over = e.beta >= 0 ? '上方' : '下方';
    if (near && near.eclipse) {
      tip = near.kind === 'new' ? '新月正好在交点附近，日、月、地几乎成一条直线，月球的影子落到地球上。'
        : '满月正好在交点附近，日、地、月几乎成一条直线，月球进入地球的影子。';
    } else if (near) {
      tip = (near.kind === 'new' ? '新月，但月球在黄道面' + side + ' ' + Math.abs(near.beta).toFixed(1) + '°，从太阳' + over + '经过，影子落不到地球上。'
        : '满月，但月球在黄道面' + side + ' ' + Math.abs(near.beta).toFixed(1) + '°，从地影' + over + '经过，没有月食。');
    } else tip = E.sunNode(t) < 17 ? '太阳在交点附近（食季），这段时间的新月、满月容易发生日食、月食。' : '太阳离交点较远，这段时间不会发生日食、月食。';
    setText('rTip', tip);
    function next(f) {
      var s = yearData.list.filter(function (x) { return x.t > t + 0.75 && x.eclipse && f(x); })[0];
      return s ? E.fmtDate(s.t) + ' ' + E.ECL_NAME[s.eclipse] : '今年没有了';
    }
    var sn = E.sunNode(t);
    rows([
      ['月相', phaseName(e.lambda) + '（日月角距 ' + Math.round(e.lambda) % 360 + '°）'],
      ['月球黄纬', Math.abs(e.beta).toFixed(2) + '°，在黄道面' + side],
      ['太阳离交点', sn.toFixed(0) + '°' + (sn < 17 ? '（食季）' : '')],
      ['下一次日食', next(function (x) { return x.kind === 'new'; })],
      ['下一次月食', next(function (x) { return x.kind === 'full'; })]
    ]);
    qa('[data-et]').forEach(function (b) { b.classList.toggle('on', Math.abs(+b.dataset.et - t) < 0.75); });
  }

  function readQuiz() {
    var q = state.quiz, sc = state.score;
    setText('rName', !state.answered ? '判断练习' : state.correct ? '✓ 答对了' : '✗ 答错了');
    $('rName').className = !state.answered ? '' : state.correct ? 'ok' : 'bad';
    setText('rKind', '得分 ' + sc.ok + ' / ' + sc.n);
    setText('rTip', state.answered ? q.explain : q.prompt);
    rows([]);
  }

  // ---------- 尺寸与主循环 ----------
  function resize() {
    var w = stage.clientWidth, h = stage.clientHeight;
    view.resize(w, h);
    S3.resize(w, h);
  }
  new ResizeObserver(resize).observe(stage);

  // 支持 ?scene=solar|lunar|year|quiz；日食 &km=、&y=（月球上下 −1.5~1.5）、&obs=（观察者 −80~80°）、&zoom=0（全景）；
  // 月食 &b=（偏离，月球半径）、&t=（距食甚小时）；一年 &year=2025~2030、&date=MM-DD、&view=earth、&exag=0；
  // 练习 &q=zone|stage|fact 只出某一类题
  var qs = new URLSearchParams(location.search);
  if (HINTS[qs.get('scene')]) state.scene = qs.get('scene');
  function num(k, lo, hi) { var v = parseFloat(qs.get(k)); return isFinite(v) && v >= lo && v <= hi ? v : null; }
  var v;
  if ((v = num('km', E.PERIGEE, E.APOGEE)) != null) state.solar.km = v;
  if ((v = num('y', -1.5, 1.5)) != null) state.solar.y = v;
  if ((v = num('obs', -80, 80)) != null) state.solar.obs = v;
  if (qs.get('zoom') === '0') state.solar.zoom = false;
  if ((v = num('b', -6.5, 6.5)) != null) state.lunar.b = v;
  if ((v = num('t', -4, 4)) != null) state.lunar.t = v;
  var yq = parseInt(qs.get('year'), 10);
  if (YEARS.indexOf(yq) >= 0) state.year.year = yq;
  if (qs.get('view') === 'earth') state.year.view = 'earth';
  if (qs.get('exag') === '0') state.year.exag = false;
  if (['zone', 'stage', 'fact'].indexOf(qs.get('q')) >= 0) state.quizOnly = qs.get('q');
  setYear(state.year.year);
  var dm = /^(\d{1,2})-(\d{1,2})$/.exec(qs.get('date') || '');
  if (dm) {
    for (var dd = 0; dd < yearData.days; dd++) {
      var dt = E.dateOf(dd);
      if (dt.month === +dm[1] && dt.day === +dm[2]) {
        // 这一天有日月食就直接跳到食甚时刻
        var hit = yearData.list.filter(function (s) { return s.eclipse && Math.floor(s.t) === dd; })[0];
        state.year.t = hit ? hit.t : dd + 0.5;
        break;
      }
    }
  }

  resize();
  // 跟随视角需要先把地球放到当天的位置
  S3.update({ t: state.year.t, exag: state.year.exag, shadows: state.year.shadows, labels: state.year.labels });
  S3.setView(state.year.view);
  setScene(state.scene);

  var insetCanvas = $('insetCanvas');
  var lastT = performance.now();
  function frame(now) {
    var dt = Math.min((now - lastT) / 1000, 0.1);
    lastT = now;
    var sc = state.scene;
    if (sc === 'solar' && state.solar.play) {
      state.solar.y -= 0.22 * dt;
      if (state.solar.y < -1.5) state.solar.y = 1.5;
    }
    if (sc === 'lunar' && state.lunar.play) {
      state.lunar.t += 0.5 * dt;
      if (state.lunar.t >= 4) { state.lunar.t = 4; setPlay('lunar', false); }
    }
    if (sc === 'year' && state.year.play) {
      state.year.t += SPEEDS[state.year.speed].v * dt;
      if (state.year.t >= yearData.days) state.year.t -= yearData.days;
    }
    sliders.forEach(function (s) { if (document.activeElement !== s.el) s.el.value = s.get(); });
    var y = state.solar.y;
    setText('moonYOut', Math.abs(y) < 0.005 ? '在日地连线上' : (y > 0 ? '偏上 ' : '偏下 ') + Math.abs(y).toFixed(2));
    setText('kmOut', kmText(state.solar.km));
    var o = state.solar.obs;
    setText('obsOut', Math.abs(o) < 0.5 ? '日下点' : (o > 0 ? '偏上 ' : '偏下 ') + Math.abs(o).toFixed(0) + '°');
    var lm = Math.round(Math.abs(state.lunar.t) * 60);
    setText('ltOut', lm === 0 ? '食甚' : (state.lunar.t < 0 ? '食甚前 ' : '食甚后 ') + Math.floor(lm / 60) + ':' + ('0' + lm % 60).slice(-2));
    var b = state.lunar.b;
    setText('lbOut', Math.abs(b).toFixed(1) + ' 个月球半径');
    setText('dayOut', E.fmtDate(state.year.t));

    if (sc === 'solar') {
      var m = solarMoon();
      view.drawSolar({ moon: m, zoom: state.solar.zoom, observer: state.solar.obs, show: state.show });
      var sv = E.solarView(E.observerPos(state.solar.obs), m);
      D.solarSky(insetCanvas, sv);
      readSolar(sv);
    } else if (sc === 'lunar') {
      view.drawLunar({ t: state.lunar.t, b: state.lunar.b, show: state.show, side: { fill: true, lines: state.show.lines, labels: true } });
      readLunar();
    } else if (sc === 'year') {
      S3.update({ t: state.year.t, exag: state.year.exag, shadows: state.year.shadows, labels: state.year.labels });
      S3.render();
      barMap = D.yearBar(barCanvas, { list: yearData.list, t: state.year.t, days: yearData.days, seasons: yearData.seasons });
      readYear();
    } else {
      view.drawQuiz(state.quiz, state.answered);
      readQuiz();
    }
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // 调试用
  window.__model = {
    state: state, setScene: setScene, newQuiz: newQuiz, setYear: setYear, syncUI: syncUI,
    setKm: function (km) { state.solar.km = E.clamp(km, E.PERIGEE, E.APOGEE); },
    setMoon: function (y) { state.solar.y = E.clamp(y, -1.5, 1.5); },
    setLunar: function (t, b) { state.lunar.t = t; if (b != null) state.lunar.b = b; },
    setDay: function (t) { state.year.t = t; }
  };
})();
