// 2D 绘制：日食 / 月食的侧视示意图（本影、半影、伪本影）、观察者看到的太阳、月食进程图（从地球上看）、一年的朔望时间轴、练习题画面
// 侧视图世界坐标同 Eclipse.GEO：单位地球半径、y 向上，太阳在左；月食进程图以月球半径为单位，左东右西（面向南方）
(function () {
  var E = window.Eclipse, G = E.GEO;
  var GOLD = '#ffc94a', MUTED = '#8d99ab', LINE = '#2a3446', TEXT = '#e6ebf2';
  var FONT = '-apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", sans-serif';
  var ZONE_COLOR = { total: '#05060a', annular: '#8a6fd0', partial: 'rgba(8,10,18,.55)' };

  // 月海（以月面半径为单位），与月相模型一致
  var MARIA = [
    [-0.38, -0.36, 0.30], [-0.08, -0.42, 0.20], [0.20, -0.30, 0.20], [0.36, -0.05, 0.22],
    [0.66, -0.18, 0.13], [-0.52, 0.06, 0.30], [-0.25, 0.42, 0.20], [0.10, 0.25, 0.14], [0.40, 0.32, 0.12]
  ];
  var STARS = [];
  for (var i = 0; i < 180; i++) STARS.push([Math.random(), Math.random(), 0.4 + Math.random() * 1.1]);

  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
  function font(px, w) { return (w ? w + ' ' : '') + px + 'px ' + FONT; }
  function poly(ctx, pts) {
    ctx.beginPath();
    pts.forEach(function (p, i) { if (i) ctx.lineTo(p[0], p[1]); else ctx.moveTo(p[0], p[1]); });
    ctx.closePath();
  }
  function roundRect(ctx, x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
  }
  function label(ctx, s, x, y, o) {
    o = o || {};
    ctx.font = font(o.size || 12, o.bold ? 600 : null);
    ctx.textAlign = o.align || 'center'; ctx.textBaseline = o.base || 'middle';
    ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(5,7,13,.85)'; ctx.strokeText(s, x, y);
    ctx.fillStyle = o.color || TEXT; ctx.fillText(s, x, y);
  }
  function stars(ctx, x, y, w, h, a) {
    ctx.fillStyle = 'rgba(255,255,255,' + a + ')';
    STARS.forEach(function (s) { ctx.fillRect(x + s[0] * w, y + s[1] * h, s[2], s[2]); });
  }

  // ---------- 侧视示意图 ----------
  // R 绘图区 {x,y,w,h}；o.mode 'solar'|'lunar'；o.moon {x,y}（世界坐标）；o.zoom 只看地月；o.observer 观察者角度；
  // o.marks 练习题的标注点；o.show {fill, lines, labels}；o.stage 月食时月球所处的阶段（给月球上色）
  function sideView(ctx, R, o) {
    var solar = o.mode === 'solar', show = o.show || { fill: true, lines: true, labels: true };
    var B = solar ? (o.zoom ? { x0: -3.7, x1: 1.4, h: 3.5 } : { x0: -17.4, x1: 2.0, h: 7.6 })
      : { x0: o.narrow ? -6.5 : -17.4, x1: 5.0, h: o.narrow ? 4.6 : 6.8 };
    var s = Math.min(R.w / (B.x1 - B.x0), R.h / B.h);
    var cx = R.x + R.w / 2 - s * (B.x0 + B.x1) / 2, cy = R.y + R.h / 2;
    function X(x) { return cx + x * s; }
    function Y(y) { return cy - y * s; }
    function P(p) { return [X(p.x), Y(p.y)]; }
    function add(p, d, k) { return { x: p.x + d.x * k, y: p.y + d.y * k }; }
    function yAt(l, x) { return l.t2.y + l.d.y * (x - l.t2.x) / l.d.x; }

    ctx.save();
    ctx.beginPath(); ctx.rect(R.x, R.y, R.w, R.h); ctx.clip();
    var sun = { x: -G.Ds, y: 0 }, earth = { x: 0, y: 0 };
    var occ = solar ? o.moon : earth, occR = solar ? G.Rm : G.Re;
    var tg = E.tangents(sun, G.Rs, occ, occR), LL = 80;

    // 太阳和照亮的空间（淡淡的暖色，影子才看得出来）
    var sx = X(sun.x), sy = Y(0), sr = G.Rs * s;
    var lg = ctx.createLinearGradient(sx, 0, R.x + R.w, 0);
    lg.addColorStop(0, 'rgba(255,201,74,.10)'); lg.addColorStop(1, 'rgba(255,201,74,.05)');
    ctx.fillStyle = lg; ctx.fillRect(Math.max(R.x, sx), R.y, R.x + R.w - Math.max(R.x, sx), R.h);
    var gl = ctx.createRadialGradient(sx, sy, sr * 0.8, sx, sy, sr * 1.6);
    gl.addColorStop(0, 'rgba(255,200,80,.45)'); gl.addColorStop(1, 'rgba(255,170,40,0)');
    ctx.fillStyle = gl; ctx.beginPath(); ctx.arc(sx, sy, sr * 1.6, 0, Math.PI * 2); ctx.fill();
    var sg = ctx.createRadialGradient(sx - sr * 0.2, sy - sr * 0.2, sr * 0.1, sx, sy, sr);
    sg.addColorStop(0, '#fff3b8'); sg.addColorStop(1, '#ffb52e');
    ctx.fillStyle = sg; ctx.beginPath(); ctx.arc(sx, sy, sr, 0, Math.PI * 2); ctx.fill();

    // 影子：先半影，再本影、伪本影；日食时与教材示意图一样只画到地球为止
    ctx.save();
    if (solar) { ctx.beginPath(); ctx.rect(R.x, R.y, X(0) - R.x, R.h); ctx.clip(); }
    var ia = tg.int[0], ib = tg.int[1], ea = tg.ext[0], eb = tg.ext[1], tip = tg.tip;
    if (show.fill) {
      ctx.fillStyle = 'rgba(70,82,104,.38)';
      poly(ctx, [P(ia.t2), P(add(ia.t2, ia.d, LL)), P(add(ib.t2, ib.d, LL)), P(ib.t2)]); ctx.fill();
      ctx.fillStyle = 'rgba(122,96,196,.32)';
      poly(ctx, [P(tip), P(add(tip, ea.d, LL)), P(add(tip, eb.d, LL))]); ctx.fill();
      ctx.fillStyle = 'rgba(2,3,6,.9)';
      poly(ctx, [P(ea.t2), P(tip), P(eb.t2)]); ctx.fill();
    }
    if (show.lines) {
      ctx.lineWidth = 1;
      ctx.strokeStyle = 'rgba(255,201,74,.75)';
      [ea, eb].forEach(function (l) {
        ctx.beginPath(); ctx.moveTo(X(l.t1.x), Y(l.t1.y)); ctx.lineTo(X(tip.x), Y(tip.y)); ctx.stroke();
      });
      ctx.setLineDash([4, 4]);
      [ea, eb].forEach(function (l) {
        var f = add(tip, l.d, LL);
        ctx.beginPath(); ctx.moveTo(X(tip.x), Y(tip.y)); ctx.lineTo(X(f.x), Y(f.y)); ctx.stroke();
      });
      ctx.setLineDash([]);
      ctx.strokeStyle = 'rgba(255,201,74,.45)';
      [ia, ib].forEach(function (l) {
        var f = add(l.t2, l.d, LL);
        ctx.beginPath(); ctx.moveTo(X(l.t1.x), Y(l.t1.y)); ctx.lineTo(X(f.x), Y(f.y)); ctx.stroke();
      });
    }
    ctx.restore();

    // 地球：朝向太阳的左半边是白天
    var ex = X(0), ey = Y(0), er = G.Re * s;
    ctx.fillStyle = '#13233a'; ctx.beginPath(); ctx.arc(ex, ey, er, 0, Math.PI * 2); ctx.fill();
    var eg = ctx.createRadialGradient(ex - er * 0.5, ey - er * 0.3, er * 0.1, ex, ey, er);
    eg.addColorStop(0, '#5aa6ea'); eg.addColorStop(1, '#245f9e');
    ctx.fillStyle = eg; ctx.beginPath(); ctx.arc(ex, ey, er, Math.PI / 2, Math.PI * 1.5); ctx.fill();

    // 日食：地面上各影区（侧视截面中的一段弧）
    var zones = solar ? E.groundZones(o.moon) : [];
    zones.forEach(function (z) {
      ctx.strokeStyle = ZONE_COLOR[z.type];
      ctx.lineWidth = Math.max(4, er * 0.1);
      ctx.beginPath(); ctx.arc(ex, ey, er - ctx.lineWidth / 2, Math.PI + z.from * Math.PI / 180, Math.PI + (z.to + 0.25) * Math.PI / 180); ctx.stroke();
    });

    // 月球：朝向太阳的左半边亮；月食时按所处阶段变暗、变红
    var mo = o.moon, mx = X(mo.x), my = Y(mo.y), mr = Math.max(3, G.Rm * s);
    var lit = '#f3ecd6';
    if (!solar) lit = { total: '#a4492b', partial: '#8a6a58', penumbral: '#cbbfa6', none: '#f3ecd6' }[o.stage || 'none'];
    ctx.fillStyle = '#3a3f4a'; ctx.beginPath(); ctx.arc(mx, my, mr, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = lit; ctx.beginPath(); ctx.arc(mx, my, mr, Math.PI / 2, Math.PI * 1.5); ctx.fill();

    // 观察者
    if (o.observer != null) {
      var op = E.observerPos(o.observer), ox = X(op.x), oy = Y(op.y), nx = op.x, ny = -op.y;
      ctx.strokeStyle = '#ff8a80'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(ox, oy); ctx.lineTo(ox + nx * 16, oy + ny * 16); ctx.stroke();
      ctx.fillStyle = '#ff8a80'; ctx.beginPath(); ctx.arc(ox + nx * 19, oy + ny * 19, 5, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.5; ctx.stroke();
      if (show.labels) label(ctx, '观察者', ox + nx * 19, oy + ny * 19 + (ny < 0 ? -15 : 15), { color: '#ff8a80', size: 12 });
    }
    // 练习题的标注点
    (o.marks || []).forEach(function (m) {
      var p = E.observerPos(m.theta), px = X(p.x), py = Y(p.y);
      ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(px, py, 3.5, 0, Math.PI * 2); ctx.fill();
      var lx = X(p.x * 1.0) + p.x * 22, ly = Y(p.y) - p.y * 22;
      ctx.strokeStyle = 'rgba(255,255,255,.6)'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(px, py); ctx.lineTo(lx, ly); ctx.stroke();
      label(ctx, m.name, lx + p.x * 9, ly - p.y * 9, { bold: true, size: 15, color: m.hl ? GOLD : '#fff' });
    });

    // 文字
    if (show.labels) {
      label(ctx, '太阳', sx + sr * 0.35, sy + Math.min(sr + 16, R.h / 2 - 12), { bold: true, color: GOLD, size: 13 });
      if (sx + sr < R.x + 30) label(ctx, '← 太阳', R.x + 34, Y(0) - 14, { color: GOLD, size: 12 });
      label(ctx, '地球', ex + er * 0.2, ey + er + 14, { bold: true, size: 13 });
      label(ctx, '月球', mx, my - mr - 12, { bold: true, size: 13 });
      if (solar) {
        var um = { x: (occ.x + tip.x) / 2, y: (occ.y + tip.y) / 2 };
        var umbraUp = Y(um.y) - Math.max(26, G.Rm * s * 1.6);
        if (show.fill && s > 90) {
          ctx.strokeStyle = 'rgba(255,255,255,.5)'; ctx.lineWidth = 1;
          ctx.beginPath(); ctx.moveTo(X(um.x), Y(um.y)); ctx.lineTo(X(um.x), umbraUp + 7); ctx.stroke();
          label(ctx, '本影', X(um.x), umbraUp, { size: 12 });
          // 半影：上方那条内公切线与外公切线之间
          var px = occ.x * 0.4, yi = Math.max(yAt(ia, px), yAt(ib, px)), ye = Math.max(yAt(ea, px), yAt(eb, px));
          label(ctx, '半影', X(px), Y((yi + ye) / 2), { size: 12, color: '#c7d0dc' });
          // 本影尖端在地面以外时，尖端到地面之间是伪本影
          var gx = -Math.sqrt(Math.max(0, 1 - tip.y * tip.y));
          if (tip.x < gx - 0.04) label(ctx, '伪本影', X((tip.x + gx) / 2) - 8, Y(tip.y) - Math.max(26, s * 0.3), { size: 12, color: '#b9a5f0' });
        }
      } else if (show.fill) {
        var ux = Math.min(2.2, B.x1 - 1.2), uw = G.Re - ux * (G.Rs - G.Re) / G.Ds;
        label(ctx, '本影', X(ux), Y(0), { size: 12 });
        label(ctx, '半影', X(ux), Y(uw + 0.42), { size: 12, color: '#c7d0dc' });
        label(ctx, '半影', X(ux), Y(-uw - 0.42), { size: 12, color: '#c7d0dc' });
      }
    }
    ctx.restore();
    return { X: X, Y: Y, s: s, zones: zones, tip: tip };
  }

  // ---------- 观察者看到的太阳（日食小窗） ----------
  // v 为 Eclipse.solarView 的结果；左东右西，月球自西向东（从右向左）移过日面
  function solarSky(canvas, v, south) {
    var ctx = canvas.getContext('2d'), dpr = Math.min(window.devicePixelRatio || 1, 2);
    var w = canvas.clientWidth, h = canvas.clientHeight;
    if (canvas.width !== Math.round(w * dpr)) { canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr); }
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    var cx = w / 2, cy = h / 2 + 2;
    if (v.type === 'night') {
      ctx.fillStyle = '#060a14'; ctx.fillRect(0, 0, w, h);
      stars(ctx, 0, 0, w, h, 0.6);
      label(ctx, '夜半球：看不到太阳', cx, cy, { color: MUTED });
      return;
    }
    // 天色：被遮住越多越暗，全食时天黑下来
    var dark = v.type === 'total' ? 0.93 : Math.pow(v.cover, 4) * 0.8;
    var sky = ctx.createLinearGradient(0, 0, 0, h);
    sky.addColorStop(0, mixRGB([61, 127, 196], [6, 10, 20], dark));
    sky.addColorStop(1, mixRGB([140, 190, 235], [16, 24, 44], dark));
    ctx.fillStyle = sky; ctx.fillRect(0, 0, w, h);
    if (dark > 0.6) stars(ctx, 0, 0, w, h, (dark - 0.6) * 1.5);
    var k = Math.min(w, h) * 0.24 / v.sun.rad, sr = v.sun.rad * k, mr = v.moon.rad * k;
    var mx = cx - v.sep * k;
    // 日冕（全食时才看得到）
    if (v.type === 'total') {
      var cg = ctx.createRadialGradient(cx, cy, sr * 0.9, cx, cy, sr * 2.6);
      cg.addColorStop(0, 'rgba(240,244,255,.85)'); cg.addColorStop(0.35, 'rgba(200,215,255,.25)'); cg.addColorStop(1, 'rgba(200,215,255,0)');
      ctx.fillStyle = cg; ctx.beginPath(); ctx.arc(cx, cy, sr * 2.6, 0, Math.PI * 2); ctx.fill();
    } else {
      var hg = ctx.createRadialGradient(cx, cy, sr, cx, cy, sr * 2.2);
      hg.addColorStop(0, 'rgba(255,240,190,' + (0.5 * (1 - dark)) + ')'); hg.addColorStop(1, 'rgba(255,240,190,0)');
      ctx.fillStyle = hg; ctx.beginPath(); ctx.arc(cx, cy, sr * 2.2, 0, Math.PI * 2); ctx.fill();
    }
    ctx.fillStyle = '#fff6d6'; ctx.beginPath(); ctx.arc(cx, cy, sr, 0, Math.PI * 2); ctx.fill();
    if (Math.abs(mx - cx) < w) {
      ctx.fillStyle = v.type === 'total' ? '#05070c' : '#1b2130';
      ctx.beginPath(); ctx.arc(mx, cy, mr, 0, Math.PI * 2); ctx.fill();
    }
    ctx.font = font(12); ctx.fillStyle = dark > 0.4 ? MUTED : 'rgba(10,20,40,.7)'; ctx.textBaseline = 'middle';
    ctx.textAlign = 'left'; ctx.fillText(south ? '西' : '东', 6, cy);
    ctx.textAlign = 'right'; ctx.fillText(south ? '东' : '西', w - 6, cy);
  }
  function mixRGB(a, b, t) {
    return 'rgb(' + a.map(function (v, i) { return Math.round(v + (b[i] - v) * t); }).join(',') + ')';
  }

  // ---------- 月球圆面（月食时叠加地影） ----------
  // (x, y) 月心，r 月球半径（像素），(sx, sy) 地影中心，k 每月球半径的像素数
  function lunarDisc(ctx, x, y, r, sx, sy, k) {
    ctx.save();
    ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.clip();
    var g = ctx.createRadialGradient(x - r * 0.3, y - r * 0.3, r * 0.1, x, y, r);
    g.addColorStop(0, '#fbf6e6'); g.addColorStop(1, '#d8d0bb');
    ctx.fillStyle = g; ctx.fillRect(x - r, y - r, 2 * r, 2 * r);
    ctx.fillStyle = 'rgba(128,122,108,.45)';
    MARIA.forEach(function (m) { ctx.beginPath(); ctx.arc(x + m[0] * r, y + m[1] * r, m[2] * r, 0, Math.PI * 2); ctx.fill(); });
    // 半影：越靠近本影越暗
    var U = E.UMBRA * k, Pn = E.PENUMBRA * k;
    var pg = ctx.createRadialGradient(sx, sy, U, sx, sy, Pn);
    pg.addColorStop(0, 'rgba(0,0,0,.5)'); pg.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = pg; ctx.beginPath(); ctx.arc(sx, sy, Pn, 0, Math.PI * 2); ctx.arc(sx, sy, U, 0, Math.PI * 2, true); ctx.fill();
    // 本影：全食时整个月面呈暗红（古铜色），偏食时本影部分与亮部对比强烈，显得很黑
    var total = Math.hypot(x - sx, y - sy) <= U - r + 0.5;
    ctx.globalCompositeOperation = 'multiply';
    ctx.fillStyle = '#9a3c20';
    ctx.beginPath(); ctx.arc(sx, sy, U, 0, Math.PI * 2); ctx.fill();
    ctx.globalCompositeOperation = 'source-over';
    ctx.fillStyle = total ? 'rgba(20,4,0,.35)' : 'rgba(8,3,2,.72)';
    ctx.beginPath(); ctx.arc(sx, sy, U, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
  }

  // ---------- 月食进程图：从地球上看（面向南方，左东右西） ----------
  // o.t 距食甚的小时数，o.b 月球离地影中心最近的距离（月球半径），o.show {shadow, path}
  function lunarFront(ctx, R, o) {
    var show = o.show || { shadow: true, path: true };
    var halfW = E.PENUMBRA + 3.6, halfH = E.PENUMBRA + 1.4;
    var k = Math.min(R.w / (2 * halfW), R.h / (2 * halfH));
    var cx = R.x + R.w / 2, cy = R.y + R.h / 2;
    ctx.save();
    ctx.beginPath(); ctx.rect(R.x, R.y, R.w, R.h); ctx.clip();
    var bg = ctx.createLinearGradient(0, R.y, 0, R.y + R.h);
    bg.addColorStop(0, '#04060c'); bg.addColorStop(1, '#0b1322');
    ctx.fillStyle = bg; ctx.fillRect(R.x, R.y, R.w, R.h);
    stars(ctx, R.x, R.y, R.w, R.h, 0.55);
    function X(x) { return cx + x * k; }
    function Y(y) { return cy - y * k; }

    if (show.shadow) {
      ctx.fillStyle = 'rgba(90,100,130,.08)';
      ctx.beginPath(); ctx.arc(cx, cy, E.PENUMBRA * k, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = 'rgba(150,50,30,.10)';
      ctx.beginPath(); ctx.arc(cx, cy, E.UMBRA * k, 0, Math.PI * 2); ctx.fill();
      ctx.setLineDash([5, 5]); ctx.lineWidth = 1.2;
      ctx.strokeStyle = 'rgba(160,172,196,.55)';
      ctx.beginPath(); ctx.arc(cx, cy, E.PENUMBRA * k, 0, Math.PI * 2); ctx.stroke();
      ctx.strokeStyle = 'rgba(255,138,110,.7)';
      ctx.beginPath(); ctx.arc(cx, cy, E.UMBRA * k, 0, Math.PI * 2); ctx.stroke();
      ctx.setLineDash([]);
      ctx.strokeStyle = 'rgba(255,255,255,.25)';
      ctx.beginPath(); ctx.moveTo(cx - 5, cy); ctx.lineTo(cx + 5, cy); ctx.moveTo(cx, cy - 5); ctx.lineTo(cx, cy + 5); ctx.stroke();
      var a = -0.8;
      label(ctx, '本影', cx + Math.cos(a) * E.UMBRA * k * 0.62, cy + Math.sin(a) * E.UMBRA * k * 0.62, { color: '#ff9e86', size: 12 });
      label(ctx, '半影', cx + Math.cos(a) * (E.UMBRA + E.PENUMBRA) / 2 * k, cy + Math.sin(a) * (E.UMBRA + E.PENUMBRA) / 2 * k, { color: '#aab6cc', size: 12 });
    }

    var by = Y(o.b);
    if (show.path) {
      ctx.strokeStyle = 'rgba(126,224,129,.45)'; ctx.lineWidth = 1.2;
      ctx.beginPath(); ctx.moveTo(R.x, by); ctx.lineTo(R.x + R.w, by); ctx.stroke();
      // 运动方向：自西向东（向左）
      ctx.fillStyle = 'rgba(126,224,129,.7)';
      var ax = X(-halfW + 0.9);
      ctx.beginPath(); ctx.moveTo(ax - 8, by); ctx.lineTo(ax + 3, by - 5); ctx.lineTo(ax + 3, by + 5); ctx.closePath(); ctx.fill();
      // 各食相的位置
      var ev = E.lunarEvent(o.b), up = o.b < 0;
      ev.contacts.forEach(function (c, i) {
        if (c.key === 'P1' || c.key === 'P4') return;
        var x = X(E.lunarPos(c.t, o.b).x);
        ctx.fillStyle = 'rgba(126,224,129,.9)';
        ctx.beginPath(); ctx.arc(x, by, 3, 0, Math.PI * 2); ctx.fill();
        var dy = (up ? -1 : 1) * (k * 1.0 + 12 + (i % 2) * 14);
        label(ctx, c.name, x, by + dy, { size: 11, color: '#a8e6a9' });
      });
    }

    // 月球
    var p = E.lunarPos(o.t, o.b);
    lunarDisc(ctx, X(p.x), Y(p.y), k, cx, cy, k);

    ctx.font = font(13, 600); ctx.fillStyle = '#c7d0dc'; ctx.textBaseline = 'middle';
    ctx.textAlign = 'left'; ctx.fillText('东', R.x + 10, cy);
    ctx.textAlign = 'right'; ctx.fillText('西', R.x + R.w - 10, cy);
    ctx.font = font(11); ctx.fillStyle = MUTED; ctx.textAlign = 'left'; ctx.textBaseline = 'top';
    ctx.fillText(o.title || '从地球上看（北半球面向南方）', R.x + 10, R.y + 8);
    ctx.restore();
    return { k: k, X: X, Y: Y };
  }

  // ---------- 一年的朔望时间轴 ----------
  // o.list 朔望列表，o.t 当前天数，o.days 全年天数，o.seasons 食季区间 [[t0, t1], ...]，返回 x ↔ t 的换算
  function yearBar(canvas, o) {
    var ctx = canvas.getContext('2d'), dpr = Math.min(window.devicePixelRatio || 1, 2);
    var w = canvas.clientWidth, h = canvas.clientHeight;
    if (canvas.width !== Math.round(w * dpr) || canvas.height !== Math.round(h * dpr)) { canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr); }
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, w, h);
    var x0 = w > 520 ? 44 : 14, x1 = w - 14;
    function tx(t) { return x0 + (x1 - x0) * t / o.days; }
    var rNew = 38, rFull = 64, base = h - 18;
    (o.seasons || []).forEach(function (s) {
      ctx.fillStyle = 'rgba(255,201,74,.10)';
      ctx.fillRect(tx(s[0]), 16, tx(s[1]) - tx(s[0]), base - 16);
      ctx.fillStyle = 'rgba(255,201,74,.75)'; ctx.font = font(10); ctx.textAlign = 'center'; ctx.textBaseline = 'top';
      ctx.fillText('食季', (tx(s[0]) + tx(s[1])) / 2, 3);
    });
    ctx.strokeStyle = LINE; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(x0, base + 0.5); ctx.lineTo(x1, base + 0.5); ctx.stroke();
    // 月份刻度
    var t = 0;
    ctx.font = font(10); ctx.textAlign = 'center'; ctx.textBaseline = 'top'; ctx.fillStyle = MUTED;
    for (var m = 1; m <= 12; m++) {
      var d0 = E.dateOf(t), len = 0;
      while (E.dateOf(t + len).month === m && t + len < o.days) len++;
      ctx.fillRect(tx(t), base - 3, 1, 6);
      if (w > 420 || m % 2 === 1) ctx.fillText(m + '月', tx(t + len / 2), base + 4);
      t += len;
    }
    ctx.textBaseline = 'middle'; ctx.textAlign = 'left'; ctx.font = font(10);
    if (w > 520) { ctx.fillStyle = MUTED; ctx.fillText('新月', 12, rNew); ctx.fillText('满月', 12, rFull); }
    var lastLabel = { new: -1e9, full: -1e9 };
    o.list.forEach(function (s) {
      var x = tx(s.t), y = s.kind === 'new' ? rNew : rFull, ecl = s.eclipse;
      ctx.beginPath(); ctx.arc(x, y, ecl ? 6 : 4, 0, Math.PI * 2);
      ctx.fillStyle = s.kind === 'new' ? '#2b3242' : '#f3ecd6'; ctx.fill();
      ctx.strokeStyle = ecl ? (s.kind === 'new' ? GOLD : '#ff8a6e') : 'rgba(141,153,171,.6)'; ctx.lineWidth = ecl ? 2 : 1; ctx.stroke();
      if (ecl && x - lastLabel[s.kind] > 40) {
        label(ctx, E.ECL_NAME[ecl], x, s.kind === 'new' ? rNew - 13 : rFull + 13, { size: 10, color: s.kind === 'new' ? GOLD : '#ff9e86' });
        lastLabel[s.kind] = x;
      }
    });
    ctx.strokeStyle = '#ff8a80'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(tx(o.t), 14); ctx.lineTo(tx(o.t), base); ctx.stroke();
    return { tAt: function (x) { return clamp((x - x0) / (x1 - x0) * o.days, 0, o.days - 0.01); } };
  }

  // ---------- 主画布 ----------
  function View(canvas) {
    var ctx = canvas.getContext('2d'), W = 0, H = 0, dpr = 1, narrow = false, geo = null;
    function resize(w, h) {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      W = w; H = h; narrow = w < 640;
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
      canvas.style.width = w + 'px'; canvas.style.height = h + 'px';
    }
    function bg() {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      var g = ctx.createLinearGradient(0, 0, 0, H);
      g.addColorStop(0, '#04060c'); g.addColorStop(1, '#0a1120');
      ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
      stars(ctx, 0, 0, W, H, 0.45);
    }
    function top() { return narrow ? 84 : 44; }

    // 场景一：日食
    function drawSolar(o) {
      bg();
      var R = { x: 12, y: top(), w: W - 24, h: H - top() - (narrow ? 40 : 44) };
      geo = sideView(ctx, R, { mode: 'solar', moon: o.moon, zoom: o.zoom, observer: o.observer, show: o.show, narrow: narrow });
      geo.rect = R;
      return geo;
    }
    // 场景二：月食（上：侧视截面；下：从地球上看）
    function drawLunar(o) {
      bg();
      var t0 = top(), avail = H - t0 - (narrow ? 36 : 40);
      var hs = Math.round(avail * (narrow ? 0.36 : 0.4));
      var R1 = { x: 12, y: t0, w: W - 24, h: hs }, R2 = { x: 12, y: t0 + hs + 8, w: W - 24, h: avail - hs - 8 };
      var p = E.lunarPos(o.t, o.b), r = Math.hypot(p.x, p.y);
      sideView(ctx, R1, { mode: 'lunar', moon: { x: G.dl, y: E.lunarSideY(r) }, stage: E.lunarStage(r), show: o.side, narrow: narrow });
      ctx.font = font(11); ctx.fillStyle = MUTED; ctx.textAlign = 'right'; ctx.textBaseline = 'top';
      ctx.fillText('侧视（过地影中心线和月球的截面，不按比例）', R1.x + R1.w - 6, R1.y + 4);
      ctx.strokeStyle = LINE; ctx.strokeRect(R1.x + 0.5, R1.y + 0.5, R1.w - 1, R1.h - 1);
      roundRect(ctx, R2.x, R2.y, R2.w, R2.h, 10); ctx.save(); ctx.clip();
      geo = lunarFront(ctx, R2, { t: o.t, b: o.b, show: o.show });
      ctx.restore();
      ctx.strokeStyle = LINE; roundRect(ctx, R2.x + 0.5, R2.y + 0.5, R2.w - 1, R2.h - 1, 10); ctx.stroke();
      geo.rect = R2;
      return geo;
    }
    // 场景四：练习
    function drawQuiz(q, answered) {
      bg();
      var R = { x: 12, y: top(), w: W - 24, h: H - top() - (narrow ? 250 : 210) };
      if (q.type === 'zone') {
        var marks = q.marks.map(function (m) { return { name: m.name, theta: m.theta, hl: m.name === q.ask }; });
        sideView(ctx, R, { mode: 'solar', moon: q.moon, zoom: true, marks: marks,
          show: { fill: true, lines: true, labels: answered }, narrow: narrow });
      } else if (q.type === 'stage') {
        lunarFront(ctx, R, { t: q.t, b: q.b, show: { shadow: true, path: false }, title: '月球与地球的影子（从地球上看）' });
      } else if (answered) {
        if (q.scene === 'lunar') sideView(ctx, R, { mode: 'lunar', moon: { x: G.dl, y: 0.15 }, stage: 'total', show: { fill: true, lines: true, labels: true }, narrow: narrow });
        else sideView(ctx, R, { mode: 'solar', moon: { x: E.moonX(E.MEAN), y: 0.05 }, zoom: false, show: { fill: true, lines: true, labels: true }, narrow: narrow });
      } else {
        ctx.font = font(64, 600); ctx.fillStyle = 'rgba(230,235,242,.25)'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText('?', W / 2, R.y + R.h / 2);
      }
    }
    return {
      resize: resize, drawSolar: drawSolar, drawLunar: drawLunar, drawQuiz: drawQuiz,
      geo: function () { return geo; }, narrow: function () { return narrow; }
    };
  }

  window.EclipseDraw = { View: View, solarSky: solarSky, yearBar: yearBar, lunarDisc: lunarDisc };
})();
