// DNA 的结构：three.js 场景（双螺旋示意模型：磷酸、脱氧核糖、碱基、氢键；解旋成平面梯子、分开两条链；尺寸标注）
// 单位 Å（0.1 nm），螺旋轴沿 y；宽屏时整体绕 z 转 −90°，轴改为水平（5′ 端在左）
(function () {
  var D = window.DNA, G = D.GEO;
  var V3 = THREE.Vector3, X = new V3(1, 0, 0), Y = new V3(0, 1, 0);
  var COL = { P: 0xffa65c, S: 0x8fa3bd, stick: 0x6b7a90, hb: 0xe6ebf2, dim: 0xc9a7ff };

  window.DnaScene = function (container) {
    var renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    container.appendChild(renderer.domElement);
    var canvas = renderer.domElement;
    canvas.id = 'view3d';

    var labelRenderer = new THREE.CSS2DRenderer();
    var ls = labelRenderer.domElement.style;
    ls.position = 'absolute'; ls.top = '0'; ls.left = '0'; ls.pointerEvents = 'none'; ls.zIndex = '2';
    container.appendChild(labelRenderer.domElement);

    var scene = new THREE.Scene();
    scene.background = new THREE.Color('#05070d');
    var camera = new THREE.PerspectiveCamera(30, 1, 1, 2000);
    scene.add(camera);
    scene.add(new THREE.AmbientLight(0xffffff, 0.5));
    var key = new THREE.DirectionalLight(0xffffff, 0.8);
    key.position.set(-4, 6, 8);
    camera.add(key);
    var rim = new THREE.DirectionalLight(0x9fc8ff, 0.25);
    rim.position.set(6, -3, -4);
    camera.add(rim);

    var controls = new THREE.OrbitControls(camera, canvas);
    controls.enableDamping = true;
    controls.dampingFactor = 0.08;
    controls.enablePan = false;
    controls.autoRotateSpeed = 0.7;
    var spinStopped = false;
    controls.addEventListener('start', function () { controls.autoRotate = false; spinStopped = true; });

    // spin：绕螺旋轴自转（自动旋转时用这个，比绕屏幕竖直轴转更能看出螺旋）
    var root = new THREE.Group(), spinG = new THREE.Group(), gDna = new THREE.Group(), gDim = new THREE.Group();
    scene.add(root); root.add(spinG); spinG.add(gDna); root.add(gDim);
    var sphere = new THREE.SphereGeometry(1, 20, 14);
    var cyl = new THREE.CylinderGeometry(1, 1, 1, 10, 1, true);
    var box = new THREE.BoxGeometry(1, 1, 1);
    var penta = new THREE.CylinderGeometry(1, 1, 1, 5);
    var KEEP = [sphere, cyl, box, penta];

    function std(col) {
      return new THREE.MeshStandardMaterial({ color: new THREE.Color(col), roughness: 0.55, metalness: 0.05, transparent: true, opacity: 1 });
    }
    function clear(g) {
      for (var i = g.children.length - 1; i >= 0; i--) {
        var o = g.children[i];
        if (o.children && o.children.length) clear(o);
        if (o.isCSS2DObject && o.element.parentNode) o.element.parentNode.removeChild(o.element);
        if (o.geometry && KEEP.indexOf(o.geometry) < 0) o.geometry.dispose();
        if (o.material && o.material.dispose) o.material.dispose();
        g.remove(o);
      }
    }
    function mesh(geo, col, g) { var m = new THREE.Mesh(geo, std(col)); (g || gDna).add(m); return m; }
    function v3(a) { return new V3(a[0], a[1], a[2]); }
    function setStick(s, a, b, r) {
      var d = b.clone().sub(a), len = d.length();
      s.position.copy(a).addScaledVector(d, 0.5);
      s.scale.set(r, len, r);
      if (len > 1e-6) s.quaternion.setFromUnitVectors(Y, d.normalize());
    }
    function label(g, html, cls) {
      var el = document.createElement('div');
      el.className = 'lab ' + (cls || '');
      el.innerHTML = html;
      var o = new THREE.CSS2DObject(el);
      g.add(o);
      return o;
    }

    // ---------- 建模 ----------
    var M = null, sig = '';
    function build(seq) {
      clear(gDna);
      var s2 = D.complement(seq);
      M = { seq: seq, n: seq.length, nt: [[], []], hb: [], sticks: [], ends: [] };
      for (var i = 0; i < M.n; i++) {
        [seq[i], s2[i]].forEach(function (b, s) {
          var nt = {
            b: b, s: s, i: i,
            P: mesh(sphere, COL.P), S: mesh(penta, COL.S), B: mesh(box, D.BASES[b].col),
            ps: mesh(cyl, COL.stick), link: null,
            lab: label(gDna, b, 'base')
          };
          nt.lab.element.style.color = D.BASES[b].col;
          [nt.P, nt.S, nt.B].forEach(function (m) { m.userData.pick = { s: s, i: i }; });
          M.nt[s].push(nt);
        });
        // 氢键：每根画成两小段（虚线）
        var geo = new THREE.BufferGeometry();
        geo.setAttribute('position', new THREE.Float32BufferAttribute(new Float32Array(3 * 4 * 3), 3));
        var hl = new THREE.LineSegments(geo, new THREE.LineBasicMaterial({ color: COL.hb, transparent: true, opacity: 0.9 }));
        hl.frustumCulled = false;
        gDna.add(hl);
        M.hb.push({ line: hl, k: D.BASES[seq[i]].hb });
      }
      // 磷酸二酯键：链 1 的 i 连到 i+1 的磷酸，链 2 的 i 连到 i−1 的磷酸
      for (i = 0; i < M.n - 1; i++) { M.nt[0][i].link = mesh(cyl, COL.stick); M.nt[1][i + 1].link = mesh(cyl, COL.stick); }
      // 5′、3′ 端标签：链 1 下 5′ 上 3′，链 2 上 5′ 下 3′
      M.ends = [['5′', 0, 0], ['3′', 0, M.n - 1], ['5′', 1, M.n - 1], ['3′', 1, 0]].map(function (e) {
        var l = label(gDna, e[0], 'end'); l.userData = { s: e[1], i: e[2], five: e[0] === '5′' }; return l;
      });
    }

    var tmp = new V3(), qRoll = new THREE.Quaternion();
    function place(o) {
      var L = D.layout(M.n, o), roll = (1 - o.tw) * Math.PI / 2;
      for (var i = 0; i < M.n; i++) {
        // 解旋成平面时把碱基、脱氧核糖绕碱基对方向转 90°，正面朝向观察者；w 为碱基板的宽度方向（画氢键用）
        var r = L[i], d = v3(r.d), w = new V3().crossVectors(Y, d).normalize().multiplyScalar(Math.cos(roll)).addScaledVector(Y, Math.sin(roll));
        for (var s = 0; s < 2; s++) {
          var nt = M.nt[s][i], S = v3(s ? r.S2 : r.S1), P = v3(s ? r.P2 : r.P1), dir = s ? d.clone().negate() : d;
          var len = D.baseLen(r.chord, D.BASES[nt.b].pur);
          nt.P.position.copy(P); nt.P.scale.setScalar(1.25);
          nt.S.position.copy(S); nt.S.scale.set(G.SUGAR, 0.8, G.SUGAR);
          qRoll.setFromAxisAngle(X, roll);
          nt.S.quaternion.setFromUnitVectors(X, dir).multiply(qRoll);
          var b0 = S.clone().addScaledVector(dir, G.SUGAR), bc = b0.clone().addScaledVector(dir, len / 2);
          nt.B.position.copy(bc); nt.B.scale.set(len, 0.9, 2.6);
          nt.B.quaternion.setFromUnitVectors(X, dir).multiply(qRoll);
          nt.lab.position.copy(bc);
          nt.end = b0.clone().addScaledVector(dir, len);
          setStick(nt.ps, P, S, 0.32);
          var nxt = s ? M.nt[1][i - 1] : M.nt[0][i + 1];
          if (nt.link && nxt) setStick(nt.link, S, v3(s ? L[i - 1].P2 : L[i + 1].P1), 0.32);
        }
        // 氢键
        var a = M.nt[0][i].end, b = M.nt[1][i].end, h = M.hb[i], pa = h.line.geometry.attributes.position, k = h.k;
        for (var j = 0; j < 3; j++) {
          var off = k === 2 ? (j - 0.5) * 1.1 : (j - 1) * 0.95, on = j < k;
          var A = a.clone().addScaledVector(w, off), B = b.clone().addScaledVector(w, off), Mid = A.clone().lerp(B, 0.5);
          var p1 = A.clone().lerp(B, 0.1), p2 = A.clone().lerp(B, 0.4), p3 = A.clone().lerp(B, 0.6), p4 = A.clone().lerp(B, 0.9);
          [p1, p2, p3, p4].forEach(function (p, t) { if (!on) p.copy(Mid); pa.setXYZ(j * 4 + t, p.x, p.y, p.z); });
        }
        pa.needsUpdate = true;
        h.line.visible = (o.sep || 0) < 0.15 && o.hbonds;
      }
      M.L = L;
    }

    // ---------- 高亮 ----------
    // hl：'none' | 'nuc' 一个脱氧核苷酸 | 'pair' 碱基对 | 'strand' 一条链 | 'backbone' 基本骨架；sel：{ s, i }
    function inHl(o, s, i, part) {
      var hl = o.hl, sel = o.sel;
      if (hl === 'none') return true;
      if (hl === 'nuc') return s === sel.s && i === sel.i && part !== 'link';
      if (hl === 'pair') return i === sel.i && (part === 'B' || part === 'hb');
      if (hl === 'strand') return s === sel.s && part !== 'hb';
      if (hl === 'backbone') return part === 'P' || part === 'S' || part === 'ps' || part === 'link';
      return true;
    }
    function shade(o) {
      for (var i = 0; i < M.n; i++) {
        for (var s = 0; s < 2; s++) {
          var nt = M.nt[s][i];
          ['P', 'S', 'B', 'ps', 'link'].forEach(function (p) {
            var m = nt[p]; if (!m) return;
            var on = inHl(o, s, i, p);
            m.material.opacity = on ? 1 : 0.13;
            m.material.depthWrite = on;
            m.material.emissive.setHex(on && o.hl !== 'none' && o.hl !== 'backbone' && o.hl !== 'strand' ? 0x332a10 : 0);
          });
          nt.lab.visible = o.letters && inHl(o, s, i, 'B');
        }
        M.hb[i].line.material.opacity = inHl(o, 0, i, 'hb') ? 0.95 : 0.12;
      }
    }

    // ---------- 尺寸标注 ----------
    var dimSig = '';
    function dims(o) {
      var want = o.dims && o.tw > 0.97 && (o.sep || 0) < 0.05 && M.n >= 2;
      var s = want ? M.n + '|' + horiz : '';
      gDim.visible = !!want;
      if (s === dimSig) return;
      dimSig = s;
      clear(gDim);
      if (!want) return;
      var pts = [], L = M.L, top = L[M.n - 1].y, bot = L[0].y, side = -G.RP - 5;
      function seg(a, b) { pts.push(v3(a), v3(b)); }
      // 直径：在最上方横跨
      var yd = top + 6;
      seg([-G.RP, yd, 0], [G.RP, yd, 0]); seg([-G.RP, yd - 1, 0], [-G.RP, yd + 1, 0]); seg([G.RP, yd - 1, 0], [G.RP, yd + 1, 0]);
      label(gDim, '直径 2 nm', 'dim').position.set(0, yd + 2.6, 0);
      // 螺距：10 个碱基对
      var n10 = Math.min(10, M.n - 1), y0 = bot - G.RISE / 2, y1 = y0 + n10 * G.RISE;
      seg([side, y0, 0], [side, y1, 0]); seg([side - 1, y0, 0], [side + 1, y0, 0]); seg([side - 1, y1, 0], [side + 1, y1, 0]);
      label(gDim, n10 === 10 ? '螺距 3.4 nm<br><small>每圈 10 个碱基对</small>' : n10 + ' 个碱基对 ' + (n10 * 0.34).toFixed(2) + ' nm', 'dim')
        .position.set(side - 3, (y0 + y1) / 2, 0);
      // 相邻碱基对 0.34 nm（标在右侧，上方一对）
      var r = G.RP + 4, ya = L[M.n - 1].y, yb = L[M.n - 2].y;
      seg([r, ya, 0], [r + 2.5, ya, 0]); seg([r, yb, 0], [r + 2.5, yb, 0]); seg([r + 1.25, ya, 0], [r + 1.25, yb, 0]);
      label(gDim, '相邻碱基对 0.34 nm', 'dim').position.set(r + 4, (ya + yb) / 2, 0);
      var geo = new THREE.BufferGeometry().setFromPoints(pts);
      gDim.add(new THREE.LineSegments(geo, new THREE.LineBasicMaterial({ color: COL.dim, transparent: true, opacity: 0.85 })));
    }

    // ---------- 每帧更新 ----------
    // o：{ seq, tw, sep, hl, sel, letters, ends, dims, hbonds }
    var lastPlace = '';
    function show(o) {
      if (o.seq !== sig) { sig = o.seq; build(o.seq); lastPlace = ''; dimSig = 'x'; fit(); }
      var ps = o.tw.toFixed(4) + '|' + (o.sep || 0).toFixed(4) + '|' + o.hbonds;
      if (ps !== lastPlace) { lastPlace = ps; place(o); }
      shade(o);
      M.ends.forEach(function (l) {
        var u = l.userData, r = M.L[u.i], P = v3(u.s ? r.P2 : r.P1), S = v3(u.s ? r.S2 : r.S1);
        // 5′ 端标在游离的磷酸外侧，3′ 端标在最后一个脱氧核糖外侧
        var base = u.five ? P : S, outY = (u.s === 0) === u.five ? -1 : 1;
        l.position.copy(base).add(tmp.set(base.x, 0, base.z).normalize().multiplyScalar(2.5)).add(tmp.set(0, outY * 3.2, 0));
        l.visible = o.ends;
      });
      dims(o);
      gDna.visible = true;
    }
    function blank() { gDna.visible = false; gDim.visible = false; }

    // ---------- 取景 ----------
    var horiz = false;
    function fit() {
      if (!M) return;
      var aspect = camera.aspect || 1;
      horiz = aspect > 1.15;
      root.rotation.z = horiz ? -Math.PI / 2 : 0;
      var len = Math.max(M.n * (G.RISE + G.FLAT_RISE) / 2, 30) + 16, wid = 2 * G.RP + 24;
      var half = Math.tan(camera.fov * Math.PI / 360);
      var sw = horiz ? len : wid, sh = horiz ? wid : len;
      var dist = Math.max(sh / 2 / half, sw / 2 / half / aspect) * 1.12 + G.RP;
      controls.target.set(0, 0, 0);
      camera.position.set(0, 0, dist);
      camera.up.set(0, 1, 0);
      controls.minDistance = dist * 0.25;
      controls.maxDistance = dist * 2.5;
      controls.update();
      dimSig = 'x';
    }
    function home() { spinStopped = false; spinG.rotation.y = 0; fit(); }

    // ---------- 拾取 ----------
    var ray = new THREE.Raycaster(), ndc = new THREE.Vector2();
    function pick(cx, cy) {
      if (!M || !gDna.visible) return null;
      var r = canvas.getBoundingClientRect();
      ndc.set((cx - r.left) / r.width * 2 - 1, -(cy - r.top) / r.height * 2 + 1);
      ray.setFromCamera(ndc, camera);
      var objs = [];
      M.nt.forEach(function (st) { st.forEach(function (nt) { objs.push(nt.P, nt.S, nt.B); }); });
      var hit = ray.intersectObjects(objs, false).filter(function (h) { return h.object.material.opacity > 0.5; })[0]
        || ray.intersectObjects(objs, false)[0];
      return hit ? hit.object.userData.pick : null;
    }

    function resize(w, h) {
      camera.aspect = w / Math.max(1, h);
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
      labelRenderer.setSize(w, h);
      if (!spinStopped) fit();     // 用户还没转动过视角时，随画面比例重新取景
    }
    var spinOn = true, last = performance.now();
    function render() {
      var now = performance.now(), dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      if (spinOn && !spinStopped) spinG.rotation.y += dt * 0.35;
      controls.update();
      renderer.render(scene, camera);
      labelRenderer.render(scene, camera);
    }
    function spin(on) { spinOn = !!on; }

    return { show: show, blank: blank, render: render, resize: resize, home: home, spin: spin, pick: pick,
      canvas: canvas, labels: labelRenderer.domElement, camera: camera, controls: controls };
  };
})();
