// DNA 的结构：碱基互补配对、碱基比例统计、双螺旋几何、判断练习（纯计算，不碰 DOM）
// 序列 seq 一律指“链 1”的碱基，按 5′→3′ 书写；链 2 与它逐个配对、方向相反（3′→5′）
(function () {
  var BASES = {
    A: { name: '腺嘌呤', pur: true, pair: 'T', hb: 2, col: '#7ee081' },
    T: { name: '胸腺嘧啶', pur: false, pair: 'A', hb: 2, col: '#ff7a59' },
    G: { name: '鸟嘌呤', pur: true, pair: 'C', hb: 3, col: '#ffc94a' },
    C: { name: '胞嘧啶', pur: false, pair: 'G', hb: 3, col: '#4fc3f7' },
    U: { name: '尿嘧啶', pur: false, pair: 'A', hb: 2, col: '#c9a7ff', rna: true }
  };
  var MAX = 30;

  // 双螺旋几何（B 型 DNA，单位 Å = 0.1 nm）：磷酸所在圆柱直径 2 nm，每个碱基对上升 0.34 nm、旋转 36°（每圈 10 个碱基对）
  var GEO = { RP: 10, RS: 7.2, RISE: 3.4, TWIST: 36, GROOVE: 146, SUGAR: 1.35, GAP: 2.2, PUR: 0.57, FLAT_RISE: 5, SEP: 7 };

  function comp(b) { return BASES[b].pair; }
  function nucName(b) { return BASES[b].name + (BASES[b].rna ? '核糖核苷酸' : '脱氧核苷酸'); }
  function parse(str) { return String(str || '').toUpperCase().replace(/[^ATGC]/g, '').slice(0, MAX); }
  // 链 2 中与链 1 逐个配对的碱基（按链 1 的位置排列，即链 2 的 3′→5′）
  function complement(seq) { return seq.split('').map(comp).join(''); }
  // 互补链按 5′→3′ 书写
  function revComp(seq) { return complement(seq).split('').reverse().join(''); }
  function random(n, rnd, gc) {
    var s = '', g = gc == null ? 0.5 : gc;
    for (var i = 0; i < n; i++) { var r = rnd(); s += r < g ? (rnd() < 0.5 ? 'G' : 'C') : (rnd() < 0.5 ? 'A' : 'T'); }
    return s;
  }
  var PRESETS = [
    { id: 'demo', name: '20 个碱基对（两圈）', seq: 'ATGCGTACCGATTGCAGCTA' },
    { id: 'at', name: 'A–T 多', seq: 'ATTAAATATTGATAATTTAA' },
    { id: 'gc', name: 'G–C 多', seq: 'GCCGGCGACGCGGCCTGCGG' },
    { id: 'short', name: '8 个碱基对', seq: 'ATGCCGTA' }
  ];

  function count(s) {
    var c = { A: 0, T: 0, G: 0, C: 0 };
    for (var i = 0; i < s.length; i++) c[s[i]]++;
    return c;
  }
  function ratio(a, b) { return b ? a / b : Infinity; }
  // 碱基统计：链 1、链 2、整个 DNA 分子
  function stats(seq) {
    var s2 = complement(seq), c1 = count(seq), c2 = count(s2), n = seq.length;
    var all = { A: c1.A + c2.A, T: c1.T + c2.T, G: c1.G + c2.G, C: c1.C + c2.C };
    function row(c, tot) {
      return {
        c: c, n: tot,
        pct: { A: c.A / tot, T: c.T / tot, G: c.G / tot, C: c.C / tot },
        agtc: ratio(c.A + c.G, c.T + c.C),     // (A+G)/(T+C)
        atgc: ratio(c.A + c.T, c.G + c.C),     // (A+T)/(G+C)
        gc: (c.G + c.C) / tot
      };
    }
    return {
      n: n, s1: row(c1, n), s2: row(c2, n), all: row(all, 2 * n),
      hb: 2 * (c1.A + c1.T) + 3 * (c1.G + c1.C),
      len: n * GEO.RISE / 10, turns: n * GEO.TWIST / 360
    };
  }

  // ---------- 双螺旋几何 ----------
  // three 坐标，螺旋轴沿 y：点 (r sin a, y, r cos a) 随 a、y 一起增大是右手螺旋
  function pos(r, a, y) { var t = a * Math.PI / 180; return [r * Math.sin(t), y, r * Math.cos(t)]; }
  // o：{ tw 0 平面梯子 → 1 双螺旋, sep 0 → 1 两条链分开 }；返回每个碱基对的各部分坐标
  // 链 1 自下而上 5′→3′，磷酸在本核苷酸脱氧核糖的下方（5′ 一侧）；链 2 自上而下 5′→3′，磷酸在上方
  function layout(n, o) {
    var G = GEO, tw = o.tw, sep = o.sep || 0;
    var rise = G.FLAT_RISE + (G.RISE - G.FLAT_RISE) * tw, step = G.TWIST * tw, gro = 180 + (G.GROOVE - 180) * tw;
    var mid = (n - 1) / 2, out = [];
    for (var i = 0; i < n; i++) {
      var y = (i - mid) * rise, a1 = -90 + (i - mid) * step - (gro - 180) / 2, a2 = a1 + gro;
      var S1 = pos(G.RS, a1, y), S2 = pos(G.RS, a2, y);
      var P1 = pos(G.RP, a1 - step / 2, y - rise / 2), P2 = pos(G.RP, a2 + step / 2, y + rise / 2);
      var d = [S2[0] - S1[0], 0, S2[2] - S1[2]], L = Math.hypot(d[0], d[2]);
      d = [d[0] / L, 0, d[2] / L];
      var sh = sep * G.SEP;
      [S1, P1].forEach(function (p) { p[0] -= d[0] * sh; p[2] -= d[2] * sh; });
      [S2, P2].forEach(function (p) { p[0] += d[0] * sh; p[2] += d[2] * sh; });
      out.push({ y: y, S1: S1, S2: S2, P1: P1, P2: P2, d: d, chord: L, rise: rise });
    }
    return out;
  }
  // 碱基长度：嘌呤（双环）长、嘧啶（单环）短，两者之间留出氢键的间隙
  function baseLen(chord, pur) {
    var room = chord - 2 * GEO.SUGAR - GEO.GAP;
    return room * (pur ? GEO.PUR : 1 - GEO.PUR);
  }

  // ---------- 判断练习 ----------
  var TYPES = ['pair', 'calc', 'hbond', 'struct'];
  function pick(a, rnd) { return a[Math.floor(rnd() * a.length)]; }
  function shuffle(a, rnd) {
    for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(rnd() * (i + 1)), t = a[i]; a[i] = a[j]; a[j] = t; }
    return a;
  }
  function uniq(a) { return a.filter(function (x, i) { return a.indexOf(x) === i; }); }
  function pct(x) { return Math.round(x * 10) / 10 + '%'; }
  function num(x) { return String(Math.round(x * 100) / 100); }
  function frac(p, q) {   // 写成最简分数或小数
    var g = function (a, b) { return b ? g(b, a % b) : a; }, k = g(p, q);
    p /= k; q /= k;
    return q === 1 ? String(p) : p + '/' + q;
  }

  var TRUE_ST = [
    'DNA 由两条脱氧核苷酸链按反向平行方式盘旋成双螺旋结构',
    '脱氧核糖和磷酸交替连接，排列在外侧，构成基本骨架',
    '碱基排列在内侧，两条链上的碱基通过氢键连接成碱基对',
    'A 与 T 之间有 2 个氢键，G 与 C 之间有 3 个氢键',
    '双链 DNA 分子中嘌呤碱基数等于嘧啶碱基数',
    '双链 DNA 分子中 A 与 T 的数量相等，G 与 C 的数量相等',
    '每条链都有一端带有一个游离的磷酸基团，这一端称为 5′ 端',
    '碱基对的排列顺序千变万化，构成了 DNA 分子的多样性',
    'DNA 分子中大多数脱氧核糖连接着 2 个磷酸'
  ];
  var FALSE_ST = [
    ['DNA 分子中每个脱氧核糖都连接着 2 个磷酸', '每条链 3′ 端的脱氧核糖只连接 1 个磷酸。'],
    ['两条链上的碱基通过磷酸二酯键连接成碱基对', '碱基对之间是氢键；磷酸二酯键连接的是同一条链上相邻的脱氧核苷酸。'],
    ['同一条链上相邻的两个碱基通过氢键直接相连', '同一条链上相邻的碱基通过“—脱氧核糖—磷酸—脱氧核糖—”相连。'],
    ['碱基排列在外侧，构成 DNA 分子的基本骨架', '基本骨架是外侧交替连接的脱氧核糖和磷酸，碱基在内侧。'],
    ['DNA 的两条链按同向平行方式盘旋成双螺旋', '两条链是反向平行的：一条 5′→3′，另一条 3′→5′。'],
    ['A 与 T 之间有 3 个氢键，G 与 C 之间有 2 个氢键', '正好相反：A–T 之间 2 个，G–C 之间 3 个。'],
    ['双链 DNA 分子中 A + T 的数量一定等于 G + C 的数量', '一定相等的是 A = T、G = C，以及嘌呤 = 嘧啶（A + G = T + C）；A + T 与 G + C 一般不等。'],
    ['DNA 分子中含有 A、T、G、C、U 五种碱基', 'DNA 只有 A、T、G、C 四种碱基；U（尿嘧啶）是 RNA 特有的。'],
    ['DNA 双螺旋是左手螺旋', 'DNA 双螺旋（B 型）是右手螺旋。']
  ];

  // 一题：{ type, prompt, options, answer, explain, seq（在模型里看时用的序列） }
  function quiz(rnd, prev, only) {
    for (var tries = 0; tries < 20; tries++) {
      var type = only || pick(TYPES, rnd), q = make(type, rnd);
      if (!q) continue;
      if (prev && prev.prompt === q.prompt) continue;
      if (q.options.length !== 4 || uniq(q.options).length !== 4 || q.options.indexOf(q.answer) < 0) continue;
      q.type = type;
      q.options = shuffle(q.options.slice(), rnd);
      return q;
    }
    return null;
  }
  function make(type, rnd) {
    var i;
    if (type === 'pair') {
      var s;
      do { s = random(5 + Math.floor(rnd() * 2), rnd, 0.5); } while (s === revComp(s) || s === s.split('').reverse().join(''));
      var rc = revComp(s), cm = complement(s), rv = s.split('').reverse().join('');
      return {
        prompt: 'DNA 一条链的碱基序列是 5′-' + s + '-3′，它的互补链按 5′→3′ 书写是',
        answer: '5′-' + rc + '-3′',
        options: ['5′-' + rc + '-3′', '5′-' + cm + '-3′', '5′-' + rv + '-3′', '5′-' + rc.replace(/T/g, 'U') + '-3′'],
        explain: '先按 A–T、G–C 逐个配对，得到与它对齐的 3′-' + cm + '-5′；两条链反向平行，改写成 5′→3′ 就是 5′-' + rc + '-3′。DNA 中没有 U。',
        seq: s
      };
    }
    if (type === 'calc') {
      var k = Math.floor(rnd() * 6);
      if (k === 0) {
        var a = pick([15, 18, 20, 22, 26, 30, 35], rnd);
        return {
          prompt: '某双链 DNA 分子中，腺嘌呤（A）占全部碱基的 ' + a + '%，则鸟嘌呤（G）占',
          answer: (50 - a) + '%', options: [(50 - a) + '%', a + '%', (100 - 2 * a) + '%', (100 - a) + '%'],
          explain: 'A = T = ' + a + '%，A + T = ' + 2 * a + '%，G + C = ' + (100 - 2 * a) + '%，G = C = ' + (50 - a) + '%。也可以直接用“嘌呤占一半”：A + G = 50%。'
        };
      }
      if (k === 1) {
        var m = pick([[2, 5], [1, 2], [2, 3], [3, 4], [1, 4]], rnd), whole = rnd() < 0.4;
        var mS = frac(m[0], m[1]), inv = frac(m[1], m[0]);
        return {
          prompt: 'DNA 一条链中 (A + G)/(T + C) = ' + mS + '，则' + (whole ? '整个 DNA 分子中' : '它的互补链中') + '这一比值为',
          answer: whole ? '1' : inv, options: uniq([inv, mS, '1', frac(m[0] + m[1], m[1])]),
          explain: '一条链的 A、G、T、C 分别与互补链的 T、C、A、G 相等，所以互补链中 (A + G)/(T + C) 是它的倒数 ' + inv + '；整个双链 DNA 中嘌呤 = 嘧啶，比值为 1。'
        };
      }
      if (k === 2) {
        var m2 = pick([[2, 3], [3, 2], [1, 2], [3, 5], [5, 4]], rnd), w2 = rnd() < 0.5;
        var mS2 = frac(m2[0], m2[1]);
        return {
          prompt: 'DNA 一条链中 (A + T)/(G + C) = ' + mS2 + '，则' + (w2 ? '整个 DNA 分子中' : '它的互补链中') + '这一比值为',
          answer: mS2, options: uniq([mS2, frac(m2[1], m2[0]), '1', frac(m2[0], m2[0] + m2[1])]),
          explain: '互补链中的 A + T 等于这条链中的 T + A，G + C 也一样，所以 (A + T)/(G + C) 在两条链和整个分子中都相同，都是 ' + mS2 + '。'
        };
      }
      if (k === 3) {
        var g = pick([36, 40, 44, 46, 52, 58], rnd);
        return {
          prompt: 'DNA 一条链中 G + C 占该链碱基总数的 ' + g + '%，则整个 DNA 分子中 G + C 占全部碱基的',
          answer: g + '%', options: [g + '%', g / 2 + '%', (100 - g) + '%', 50 + '%'],
          explain: '互补链中 G + C 的个数与这条链相同，两条链碱基总数也相同，所以 G + C 在每条链和整个分子中所占的比例都是 ' + g + '%。'
        };
      }
      if (k === 4) {
        var at = pick([40, 44, 48, 54, 60], rnd), qa = pick([16, 18, 20, 22, 24], rnd);
        return {
          prompt: '某双链 DNA 分子中 A + T 占全部碱基的 ' + at + '%，其中一条链（甲链）中 A 占该链碱基的 ' + qa + '%，则另一条链中 A 占该链碱基的',
          answer: (at - qa) + '%', options: uniq([(at - qa) + '%', qa + '%', (at / 2 - qa / 2) + '%', (50 - qa) + '%']),
          explain: 'A + T 在每条链中所占比例与整个分子相同，甲链中 A + T = ' + at + '%，所以甲链 T = ' + (at - qa) + '%；另一条链的 A 与甲链的 T 配对，也是 ' + (at - qa) + '%。'
        };
      }
      var nb = pick([3, 4, 5, 10, 50], rnd);
      var p4 = nb <= 5 ? String(Math.pow(4, nb)) : '4^' + nb, p2 = nb <= 5 ? String(Math.pow(2, nb)) : '2^' + nb;
      return {
        prompt: '由 ' + nb + ' 个碱基对组成的 DNA 分子片段，碱基对的排列方式最多有几种',
        answer: p4, options: uniq([p4, p2, nb <= 5 ? String(Math.pow(nb, 4)) : nb + '^4', String(4 * nb)]),
        explain: '每个位置的碱基对有 A–T、T–A、G–C、C–G 4 种可能，' + nb + ' 个位置就有 4^' + nb + (nb <= 5 ? ' = ' + p4 : '') + ' 种排列方式，这就是 DNA 多样性的来源。'
      };
    }
    if (type === 'hbond') {
      if (rnd() < 0.5) {
        var n = pick([50, 100, 120, 200], rnd), aN = Math.round(n * pick([0.2, 0.3, 0.35, 0.4], rnd));
        var h = 2 * aN + 3 * (n - aN);
        return {
          prompt: '某 DNA 片段含 ' + n + ' 个碱基对，其中腺嘌呤（A）有 ' + aN + ' 个，这个片段中共有多少个氢键',
          answer: String(h), options: uniq([String(h), String(3 * aN + 2 * (n - aN)), String(2 * n), String(5 * n / 2 | 0)]),
          explain: 'A–T 碱基对有 ' + aN + ' 个，各 2 个氢键；G–C 碱基对有 ' + n + ' − ' + aN + ' = ' + (n - aN) + ' 个，各 3 个氢键。共 2×' + aN + ' + 3×' + (n - aN) + ' = ' + h + ' 个。'
        };
      }
      var seqs = [], gcs = [0.2, 0.4, 0.6, 0.8];
      for (i = 0; i < 4; i++) {
        var t;
        do { t = random(8, rnd, gcs[i]); } while (Math.round(stats(t).s1.gc * 8) !== Math.round(gcs[i] * 8) || seqs.indexOf(t) >= 0);
        seqs.push(t);
      }
      var best = seqs[3];
      return {
        prompt: '下面是几个 DNA 片段一条链的碱基序列（长度相同），哪一个片段的结构最稳定、最耐高温',
        answer: best, options: seqs,
        explain: 'G–C 碱基对之间有 3 个氢键，A–T 只有 2 个；G + C 所占比例越高，氢键越多，DNA 越稳定。' + best + ' 中 G + C 有 ' + Math.round(stats(best).s1.gc * 8) + ' 个，最多。',
        seq: best
      };
    }
    // struct：选出错误的叙述
    var f = pick(FALSE_ST, rnd), tr = shuffle(TRUE_ST.slice(), rnd).slice(0, 3);
    return {
      prompt: '下列关于 DNA 分子结构的叙述，错误的是',
      answer: f[0], options: tr.concat([f[0]]),
      explain: f[1]
    };
  }

  window.DNA = {
    BASES: BASES, MAX: MAX, GEO: GEO, PRESETS: PRESETS, TYPES: TYPES,
    comp: comp, nucName: nucName, parse: parse, complement: complement, revComp: revComp, random: random,
    count: count, stats: stats, pos: pos, layout: layout, baseLen: baseLen,
    quiz: quiz, pct: pct, num: num
  };
})();
