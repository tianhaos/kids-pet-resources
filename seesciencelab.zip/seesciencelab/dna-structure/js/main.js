(function () {
  var D = window.DNA, Dr = window.DnaDraw;
  var $ = function (id) { return document.getElementById(id); };
  var qa = function (sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); };
  var NAME = 'DNA 的结构';

  var state = {
    scene: 'helix', seq: D.PRESETS[0].seq, tw: 1, twT: 1, sep: 0, sepT: 0,
    hl: 'none', sel: { s: 0, i: 9 }, letters: true, ends: true, dims: true, spin: true,
    pmode: 'know', pseq: 'ATGCCGTA', ps2: null, cur: 0, phl: 'nuc', psel: { s: 0, i: 1 }, part: 'S', nums: false, labels: true, msg: '',
    quiz: null, quizOnly: null, answered: false, correct: false, choice: null, score: { n: 0, ok: 0 }
  };
  var HINTS = {
    helix: '拖动旋转、滚轮或双指缩放；点一个碱基、磷酸或脱氧核糖看它是什么',
    plane: '点图中的磷酸、脱氧核糖、碱基或氢键看说明',
    pair: '点右链上的“?”，再选碱基，按碱基互补配对原则补全互补链',
    quiz: 'DNA 的结构 · 判断练习'
  };
  var HL_NAME = { none: '无', nuc: '一个脱氧核苷酸', pair: '碱基对', strand: '一条链', backbone: '基本骨架' };

  var stage = $('stage'), panel = $('panel'), cv = $('view2d'), ctx = cv.getContext('2d');
  var sc3 = null;
  try { sc3 = window.DnaScene(stage); } catch (e) { sc3 = null; }
  function setSeg(attr, val) { qa('[data-' + attr + ']').forEach(function (b) { b.classList.toggle('on', b.dataset[attr] === String(val)); }); }
  function colored(s) { return s.split('').map(function (b) { return '<b style="color:' + D.BASES[b].col + '">' + b + '</b>'; }).join(''); }

  // ---------- 序列 ----------
  $('presets').innerHTML = D.PRESETS.map(function (p) { return '<button data-pre="' + p.id + '">' + p.name + '</button>'; }).join('');
  qa('[data-pre]').forEach(function (b) {
    b.addEventListener('click', function () {
      setSeq(D.PRESETS.filter(function (p) { return p.id === b.dataset.pre; })[0].seq);
      Analytics.track(NAME, '序列', b.textContent);
    });
  });
  function setSeq(s) {
    s = D.parse(s);
    if (!s.length) return;
    state.seq = s;
    state.sel = { s: 0, i: Math.min(state.sel.i, s.length - 1) };
    $('seqIn').value = s;
    syncUI();
  }
  $('seqIn').addEventListener('input', function () {
    var s = D.parse($('seqIn').value);
    if (s.length) { state.seq = s; state.sel.i = Math.min(state.sel.i, s.length - 1); syncUI(); }
  });
  $('seqIn').addEventListener('change', function () { $('seqIn').value = state.seq; Analytics.track(NAME, '输入序列', String(state.seq.length)); });
  $('rand').addEventListener('click', function () { setSeq(D.random(10 + Math.floor(Math.random() * 11), Math.random)); Analytics.track(NAME, '随机序列'); });

  // ---------- 控件 ----------
  qa('[data-scene]').forEach(function (b) {
    b.addEventListener('click', function () { setScene(b.dataset.scene); Analytics.track(NAME, '场景', b.textContent); });
  });
  function setScene(s) {
    state.scene = s;
    if (s === 'quiz' && !state.quiz) newQuiz();
    syncUI();
  }
  $('tw').addEventListener('input', function () { state.twT = state.tw = +$('tw').value / 100; syncUI(); });
  $('unwind').addEventListener('click', function () {
    state.twT = state.twT > 0.5 ? 0 : 1;
    if (state.twT === 1) state.sepT = 0;
    syncUI(); Analytics.track(NAME, state.twT ? '旋成双螺旋' : '解旋');
  });
  $('sep').addEventListener('change', function () {
    state.sepT = $('sep').checked ? 1 : 0;
    syncUI(); Analytics.track(NAME, '分开两条链', state.sepT ? '开' : '关');
  });
  qa('[data-hl]').forEach(function (b) { b.addEventListener('click', function () { state.hl = b.dataset.hl; syncUI(); Analytics.track(NAME, '高亮', HL_NAME[state.hl]); }); });
  qa('[data-phl]').forEach(function (b) { b.addEventListener('click', function () { state.phl = b.dataset.phl; syncUI(); Analytics.track(NAME, '平面高亮', HL_NAME[state.phl]); }); });
  [['letters', 'letters'], ['ends', 'ends'], ['dims', 'dims'], ['nums', 'nums'], ['labels', 'labels'], ['ends2', 'ends']].forEach(function (p) {
    $(p[0]).addEventListener('change', function () { state[p[1]] = $(p[0]).checked; syncUI(); Analytics.track(NAME, '显示', p[1] + (state[p[1]] ? ' 开' : ' 关')); });
  });
  $('spin').addEventListener('change', function () { state.spin = $('spin').checked; syncUI(); });
  qa('.homeBtn').forEach(function (b) { b.addEventListener('click', function () { if (sc3) sc3.home(); }); });

  // 平面结构：认识结构 / 补全互补链
  qa('[data-pmode]').forEach(function (b) {
    b.addEventListener('click', function () { setPmode(b.dataset.pmode); Analytics.track(NAME, '平面模式', b.textContent); });
  });
  function setPmode(m) {
    state.pmode = m;
    if (m === 'pair') newPair(state.pseq);
    else state.ps2 = null;
    syncUI();
  }
  function newPair(s) {
    state.pseq = s || D.random(6 + Math.floor(Math.random() * 3), Math.random);
    state.ps2 = state.pseq.split('').map(function () { return ''; });
    state.cur = 0; state.msg = '';
  }
  $('newPair').addEventListener('click', function () { newPair(); syncUI(); Analytics.track(NAME, '换一段'); });
  $('autoPair').addEventListener('click', function () {
    state.ps2 = D.complement(state.pseq).split(''); state.cur = -1; state.msg = '';
    syncUI(); Analytics.track(NAME, '自动配对');
  });
  $('to3d').addEventListener('click', function () { setSeq(state.pseq); setScene('helix'); Analytics.track(NAME, '平面 → 3D'); });
  qa('[data-base]').forEach(function (b) { b.addEventListener('click', function () { fill(b.dataset.base); }); });
  document.addEventListener('keydown', function (e) {
    if (state.scene !== 'plane' || state.pmode !== 'pair' || e.target.tagName === 'INPUT') return;
    var k = e.key.toUpperCase();
    if (D.BASES[k]) fill(k);
  });
  function fill(b) {
    var i = state.cur;
    if (i < 0 || !state.ps2) return;
    var need = D.comp(state.pseq[i]), a = state.pseq[i];
    state.ps2[i] = b;
    if (b === need) state.msg = '✓ ' + a + ' 与 ' + b + ' 配对，形成 ' + D.BASES[a].hb + ' 个氢键。';
    else if (D.BASES[b].rna) state.msg = '✗ DNA 中没有 U（尿嘧啶），U 是 RNA 特有的碱基。' + a + ' 应与 ' + need + ' 配对。';
    else if (D.BASES[a].pur === D.BASES[b].pur) state.msg = '✗ ' + a + ' 与 ' + b + ' 都是' + (D.BASES[a].pur ? '嘌呤（双环），两个合起来太宽，放不下' : '嘧啶（单环），合起来太窄，够不着') + '；' + a + ' 应与 ' + need + ' 配对。';
    else state.msg = '✗ ' + a + ' 与 ' + b + ' 宽度合适，但形成氢键的位置对不上；' + a + ' 应与 ' + need + ' 配对。';
    Analytics.track(NAME, '配对', a + '-' + b + (b === need ? ' 对' : ' 错'));
    // 跳到下一个没填对的位置
    var nx = -1;
    for (var k = 1; k <= state.ps2.length; k++) {
      var j = (i + k) % state.ps2.length;
      if (state.ps2[j] !== D.comp(state.pseq[j])) { nx = j; break; }
    }
    state.cur = b === need ? nx : i;
    syncUI();
  }

  // 画布点击：3D 拾取 / 2D 命中
  var down = null;
  stage.addEventListener('pointerdown', function (e) { down = [e.clientX, e.clientY]; });
  stage.addEventListener('pointerup', function (e) {
    if (!down || Math.hypot(e.clientX - down[0], e.clientY - down[1]) > 6) { down = null; return; }
    down = null;
    var s = state.scene;
    if (s === 'helix' && sc3 && e.target === sc3.canvas) {
      var p = sc3.pick(e.clientX, e.clientY);
      if (!p) return;
      state.sel = { s: p.s, i: p.i };
      if (state.hl === 'none' || state.hl === 'backbone') state.hl = 'pair';
      syncUI(); Analytics.track(NAME, '点选', '3D');
    } else if (s === 'plane' && e.target === cv) {
      var r = cv.getBoundingClientRect(), h = Dr.hitTest(hits, e.clientX - r.left, e.clientY - r.top);
      if (!h) return;
      if (h.kind === 'slot' || (state.pmode === 'pair' && h.s === 1 && h.kind === 'B')) { state.cur = h.i; syncUI(); return; }
      state.psel = { s: h.s, i: h.i }; state.part = h.kind;
      if (h.kind === 'hb') state.phl = 'pair';
      syncUI(); Analytics.track(NAME, '点选', h.kind);
    }
  });

  // ---------- 练习 ----------
  function newQuiz() {
    state.quiz = D.quiz(Math.random, state.quiz, state.quizOnly);
    state.answered = false; state.choice = null;
    var box = $('quizOpts');
    box.innerHTML = '';
    state.quiz.options.forEach(function (o) {
      var b = document.createElement('button');
      b.className = 'small';
      b.textContent = o;
      b.dataset.opt = o;
      b.addEventListener('click', function () { answer(o); });
      box.appendChild(b);
    });
    box.className = 'answer' + (state.quiz.options.some(function (o) { return o.length > 14; }) ? ' one' : '');
    syncUI();
  }
  function answer(o) {
    if (state.answered) return;
    state.answered = true; state.choice = o;
    state.correct = o === state.quiz.answer;
    state.score.n++; if (state.correct) state.score.ok++;
    Analytics.track(NAME, '练习', state.quiz.type + (state.correct ? ' 对' : ' 错'));
    syncUI();
  }
  $('nextQ').addEventListener('click', newQuiz);
  $('showQ').addEventListener('click', function () {
    var q = state.quiz;
    if (q.seq) setSeq(q.seq);
    state.hl = 'none'; state.twT = 1; state.sepT = 0;
    setScene('helix');
    Analytics.track(NAME, '练习 → 模型', q.type);
  });

  // ---------- 面板 ----------
  $('panelToggle').addEventListener('click', function () { panel.classList.toggle('collapsed'); });
  if (window.matchMedia('(max-width: 760px)').matches) panel.classList.add('collapsed');

  function use3d() { var s = state.scene; return !!sc3 && (s === 'helix' || (s === 'quiz' && !(state.quiz && state.quiz.type === 'pair'))); }
  function syncUI() {
    var s = state.scene;
    setSeg('scene', s);
    qa('[data-for]').forEach(function (el) {
      var f = el.dataset.for.split(' ');
      el.hidden = f.indexOf(s) < 0 && f.indexOf(s + ':' + state.pmode) < 0;
    });
    $('hint').textContent = !sc3 && s === 'helix' ? '此浏览器不支持 WebGL，无法显示 3D 双螺旋；平面结构和练习仍可使用'
      : s === 'plane' ? HINTS[state.pmode === 'pair' ? 'pair' : 'plane'] : HINTS[s];
    setSeg('hl', state.hl); setSeg('phl', state.phl); setSeg('pmode', state.pmode);
    setSeg('pre', (D.PRESETS.filter(function (p) { return p.seq === state.seq; })[0] || {}).id);
    $('tw').value = Math.round(state.twT * 100);
    $('unwind').textContent = state.twT > 0.5 ? '⇋ 解旋成平面结构' : '⟲ 旋成双螺旋';
    $('sep').checked = state.sepT > 0;
    $('letters').checked = state.letters; $('ends').checked = $('ends2').checked = state.ends; $('dims').checked = state.dims;
    $('spin').checked = state.spin; $('nums').checked = state.nums; $('labels').checked = state.labels;
    if (document.activeElement !== $('seqIn')) $('seqIn').value = state.seq;
    $('comp').innerHTML = '链 2：3′-' + colored(D.complement(state.seq)) + '-5′';
    var three = use3d();
    if (sc3) { sc3.canvas.style.display = three ? '' : 'none'; sc3.labels.style.display = three ? '' : 'none'; sc3.spin(state.spin); }
    cv.style.display = three ? 'none' : '';
    $('pickBar').hidden = !(s === 'plane' && state.pmode === 'pair');
    var done = state.ps2 && state.ps2.every(function (b, i) { return b === D.comp(state.pseq[i]); });
    qa('[data-base]').forEach(function (b) { b.disabled = done || state.cur < 0; });
    $('pickMsg').textContent = done ? '✓ 互补链补全了：A 都对着 T，G 都对着 C。' : state.msg || ('第 ' + (state.cur + 1) + ' 个碱基对：左链是 ' + state.pseq[state.cur] + '，右链应填？');
    $('pickMsg').className = done || /^✓/.test(state.msg) ? 'ok' : /^✗/.test(state.msg) ? 'bad' : '';
    statTable();
    var q = state.quiz;
    if (q) {
      $('quizQ').textContent = q.prompt;
      qa('#quizOpts button').forEach(function (b) {
        b.disabled = state.answered;
        b.classList.toggle('on', state.answered && b.dataset.opt === q.answer);
        b.classList.toggle('no', state.answered && b.dataset.opt === state.choice && !state.correct);
      });
      $('quizMsg').innerHTML = !state.answered ? ''
        : '<b class="' + (state.correct ? 'ok">✓ 答对了' : 'bad">✗ 应选「' + q.answer + '」') + '</b>' + q.explain;
      $('nextQ').textContent = state.answered ? '下一题 →' : '换一题';
      $('showQ').hidden = !state.answered;
    }
    legend();
    requestAnimationFrame(resize2d);
  }
  function statTable() {
    var st = D.stats(state.seq);
    function r(name, x) {
      return '<tr><td>' + name + '</td>' + ['A', 'T', 'G', 'C'].map(function (b) { return '<td>' + x.c[b] + '</td>'; }).join('')
        + '<td>' + fmt(x.agtc) + '</td><td>' + fmt(x.atgc) + '</td></tr>';
    }
    $('stat').innerHTML = r('链 1', st.s1) + r('链 2', st.s2) + r('双链', st.all);
  }
  function fmt(x) { return x === Infinity ? '—' : D.num(x); }
  function legend() {
    var html = '';
    if (state.scene !== 'quiz' || state.answered || (state.quiz && state.quiz.type !== 'pair')) {
      html = ['A', 'T', 'G', 'C'].map(function (b) { return '<span><i style="background:' + D.BASES[b].col + '"></i>' + b + ' ' + D.BASES[b].name + '</span>'; }).join('')
        + '<span><i style="background:#ffa65c"></i>磷酸</span><span><i class="pen" style="background:#8fa3bd"></i>脱氧核糖</span>'
        + '<span><i class="hb"></i>氢键</span>';
    }
    if (W <= 760 && state.scene !== 'helix') html = '';   // 窄屏时平面图和练习占满画面，不放图例
    $('legend').innerHTML = html;
  }

  // ---------- 读数 ----------
  var lastText = {};
  function setText(id, t, html) { if (lastText[id] !== t) { lastText[id] = t; $(id)[html ? 'innerHTML' : 'textContent'] = t; } }
  function rows(list) {
    for (var k = 1; k <= 6; k++) {
      var r = list[k - 1] || ['', ''];
      setText('d' + k, r[0]); setText('r' + k, r[1], true);
      $('d' + k).hidden = $('r' + k).hidden = !r[0];
    }
  }
  function pairText(seq, i) {
    var a = seq[i], b = D.comp(a);
    return a + '–' + b + '（' + D.BASES[a].name + '–' + D.BASES[b].name + '，' + D.BASES[a].hb + ' 个氢键）';
  }
  function readHelix() {
    var st = D.stats(state.seq), c = st.s1.c, sel = state.sel, n = st.n;
    setText('rName', 'DNA 双螺旋');
    $('rName').className = '';
    setText('rKind', n + ' 个碱基对');
    var at = c.A + c.T, gc = c.G + c.C, ca = st.all.c;
    rows([
      ['链 1', '5′-' + colored(state.seq) + '-3′'],
      ['链 2', '3′-' + colored(D.complement(state.seq)) + '-5′'],
      ['长度', n + ' × 0.34 = ' + D.num(st.len) + ' nm，' + D.num(st.turns) + ' 圈'],
      ['碱基', 'A ' + ca.A + '　T ' + ca.T + '　G ' + ca.G + '　C ' + ca.C + '（A = T，G = C）'],
      ['嘌呤 / 嘧啶', 'A + G = ' + (ca.A + ca.G) + '，T + C = ' + (ca.T + ca.C) + '，相等'],
      ['氢键', '2 × ' + at + ' + 3 × ' + gc + ' = ' + st.hb + ' 个']
    ]);
    var b = (sel.s ? D.complement(state.seq) : state.seq)[sel.i], tip;
    if (state.tw < 0.02 && state.sep > 0.98) tip = '氢键断开，两条链分开了：每条链上的碱基序列都能按碱基互补配对原则确定另一条链（DNA 复制、转录都从解旋开始）。';
    else if (state.tw < 0.98 && state.twT < 1) tip = '把双螺旋“拧开”，就得到教材上的平面结构：两条链像梯子的两边扶手，碱基对是一级级横档。';
    else if (state.hl === 'nuc') tip = '一个' + D.nucName(b) + '：由 1 分子磷酸、1 分子脱氧核糖和 1 分子含氮碱基组成，磷酸连在脱氧核糖的 5′ 碳上。';
    else if (state.hl === 'pair') tip = '第 ' + (sel.i + 1) + ' 个碱基对 ' + pairText(state.seq, sel.i) + '。嘌呤（双环）总是与嘧啶（单环）配对，所以 DNA 直径处处相同（2 nm）。';
    else if (state.hl === 'strand') tip = '链 ' + (sel.s + 1) + '：从 5′ 端（游离的磷酸）到 3′ 端（脱氧核糖上的 —OH），' + (sel.s ? '自上而下' : '自下而上') + '；两条链反向平行。';
    else if (state.hl === 'backbone') tip = '脱氧核糖和磷酸交替连接，排列在外侧，构成基本骨架；碱基在内侧，两两配对。';
    else tip = '两条链反向平行，盘旋成右手双螺旋；脱氧核糖和磷酸在外侧构成基本骨架，碱基在内侧通过氢键形成碱基对（A–T、G–C）。';
    setText('rTip', tip);
  }
  var PART = {
    P: ['磷酸', '连在脱氧核糖的 5′ 碳上，又与上一个（或下一个）脱氧核苷酸的脱氧核糖的 3′ 碳相连，把脱氧核苷酸连成长链。每条链 5′ 端有一个游离的磷酸。'],
    S: ['脱氧核糖', '五碳糖：1′ 碳连碱基，5′ 碳连本脱氧核苷酸的磷酸，3′ 碳连下一个脱氧核苷酸的磷酸。与磷酸交替连接，排列在外侧，构成基本骨架。'],
    hb: ['氢键', '两条链的碱基之间通过氢键形成碱基对：A–T 之间 2 个，G–C 之间 3 个。氢键较弱，加热或解旋酶可以使它断开。']
  };
  function readPlane() {
    if (state.pmode === 'pair') {
      var n = state.pseq.length, f = state.ps2.filter(function (b) { return b; }).length;
      var ok = state.ps2.filter(function (b, i) { return b === D.comp(state.pseq[i]); }).length;
      setText('rName', ok === n ? '✓ 配对完成' : '补全互补链');
      $('rName').className = ok === n ? 'ok' : '';
      setText('rKind', ok + ' / ' + n);
      rows([
        ['左链', '5′-' + colored(state.pseq) + '-3′'],
        ['右链', '3′-' + state.ps2.map(function (b) { return b ? '<b style="color:' + D.BASES[b].col + '">' + b + '</b>' : '?'; }).join('') + '-5′'],
        ['已填', f + ' 个，配对正确 ' + ok + ' 个'],
        ['右链 5′→3′', ok === n ? '5′-' + colored(D.revComp(state.pseq)) + '-3′' : '补全后显示']
      ]);
      setText('rTip', '碱基互补配对原则：A 一定与 T 配对，G 一定与 C 配对。嘌呤（A、G，双环）与嘧啶（T、C，单环）配对，碱基对宽度相同。');
      return;
    }
    var sel = state.psel, s2 = D.complement(state.pseq), b = (sel.s ? s2 : state.pseq)[sel.i], p = state.part;
    var name, tip;
    if (p === 'B') { name = D.BASES[b].name + '（' + b + '）'; tip = (D.BASES[b].pur ? '嘌呤，双环' : '嘧啶，单环') + '，连在脱氧核糖的 1′ 碳上，排列在内侧，与另一条链上的 ' + D.comp(b) + '（' + D.BASES[D.comp(b)].name + '）配对，形成 ' + D.BASES[b].hb + ' 个氢键。'; }
    else { name = PART[p][0]; tip = PART[p][1]; }
    setText('rName', name);
    $('rName').className = '';
    setText('rKind', (sel.s ? '右链' : '左链') + '第 ' + (sel.i + 1) + ' 个');
    rows([
      ['所在核苷酸', D.nucName(b)],
      ['碱基对', pairText(state.pseq, sel.i)],
      ['左链', '5′-' + colored(state.pseq) + '-3′'],
      ['右链', '3′-' + colored(s2) + '-5′']
    ]);
    setText('rTip', tip);
  }
  function readQuiz() {
    var q = state.quiz, s = state.score;
    setText('rName', !state.answered ? '判断练习' : state.correct ? '✓ 答对了' : '✗ 答错了');
    $('rName').className = !state.answered ? '' : state.correct ? 'ok' : 'bad';
    setText('rKind', '得分 ' + s.ok + ' / ' + s.n);
    setText('rTip', state.answered ? q.explain : q.prompt);
    rows([]);
  }

  // ---------- 2D 画面 ----------
  var W = 0, H = 0, hits = [];
  function resize() {
    W = stage.clientWidth; H = stage.clientHeight;
    var dpr = window.devicePixelRatio || 1;
    cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr);
    cv.style.width = W + 'px'; cv.style.height = H + 'px';
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    if (sc3) sc3.resize(W, H);
  }
  new ResizeObserver(resize).observe(stage);
  var bottom = 40;
  function resize2d() {
    var s = state.scene;
    bottom = s === 'quiz' ? $('quizBar').offsetHeight + 56 : s === 'plane' && state.pmode === 'pair' ? $('pickBar').offsetHeight + 56 : 40;
  }
  function draw2d() {
    ctx.clearRect(0, 0, W, H);
    ctx.fillStyle = '#05070d'; ctx.fillRect(0, 0, W, H);
    var top = W <= 760 ? 84 : 44, box = { x: 8, y: top, w: W - 16, h: Math.max(120, H - top - bottom) };
    var s = state.scene, r;
    if (s === 'plane') {
      var know = state.pmode === 'know';
      r = Dr.plane(ctx, {
        box: box, seq: state.pseq, s2: know ? D.complement(state.pseq).split('') : state.ps2,
        hl: know ? state.phl : 'none', sel: state.psel, cur: state.cur, nums: state.nums, ends: state.ends, labels: state.labels
      });
      hits = r.hits;
    } else if (s === 'quiz' && state.quiz && state.quiz.type === 'pair') {
      var q = state.quiz;
      Dr.plane(ctx, { box: box, seq: q.seq, s2: state.answered ? D.complement(q.seq).split('') : q.seq.split('').map(function () { return ''; }),
        hl: 'none', cur: -1, ends: true });
    }
  }

  // ---------- 主循环 ----------
  // 支持 ?scene=helix|plane|quiz、&seq=ATGC…（链 1，5′→3′）、&tw=0~1、&sep=1、&hl=nuc|pair|strand|backbone、&sel=碱基对序号（从 1 起）、
  // &letters=0、&ends=0、&dims=0、&spin=0，平面 &mode=know|pair、&nums=1，练习 &q=pair|calc|hbond|struct
  var qs = new URLSearchParams(location.search);
  if (HINTS[qs.get('scene')] && qs.get('scene') !== 'pair') state.scene = qs.get('scene');
  if (D.parse(qs.get('seq')).length) { state.seq = D.parse(qs.get('seq')); state.pseq = state.seq.slice(0, 10); }
  state.sel.i = Math.min(state.sel.i, state.seq.length - 1);
  if (qs.get('sel')) { var si = +qs.get('sel') - 1; if (si >= 0 && si < state.seq.length) state.sel.i = si; state.psel.i = Math.min(Math.max(0, si), state.pseq.length - 1); }
  if (qs.get('tw') != null && !isNaN(+qs.get('tw'))) state.tw = state.twT = Math.max(0, Math.min(1, +qs.get('tw')));
  if (qs.get('sep') === '1') { state.sep = state.sepT = 1; if (qs.get('tw') == null) state.tw = state.twT = 0; }
  if (HL_NAME[qs.get('hl')]) state.hl = state.phl = qs.get('hl');
  ['letters', 'ends', 'dims', 'spin'].forEach(function (k) { if (qs.get(k) === '0') state[k] = false; });
  if (qs.get('nums') === '1') state.nums = true;
  if (D.TYPES.indexOf(qs.get('q')) >= 0) state.quizOnly = qs.get('q');
  resize();
  if (qs.get('mode') === 'pair') { state.pmode = 'pair'; newPair(qs.get('seq') ? state.pseq : null); }
  setScene(state.scene);

  var last = performance.now();
  function approach(k, kT, dt, rate) {
    var d = state[kT] - state[k];
    state[k] += Math.sign(d) * Math.min(Math.abs(d), dt * rate);
  }
  function frame(now) {
    var dt = Math.min(0.05, (now - last) / 1000);
    last = now;
    var s = state.scene;
    // 先分开再拧回 / 先解旋再分开
    if (state.sepT > 0 && state.twT > 0) state.twT = 0;
    if (state.sepT < state.sep) approach('sep', 'sepT', dt, 1.2);
    else if (state.tw > state.twT) approach('tw', 'twT', dt, 0.6);
    else if (state.sepT > state.sep) approach('sep', 'sepT', dt, 1.2);
    else approach('tw', 'twT', dt, 0.6);
    if (s === 'helix') {
      if (sc3) sc3.show({ seq: state.seq, tw: state.tw, sep: state.sep, hl: state.hl, sel: state.sel, letters: state.letters, ends: state.ends, dims: state.dims, hbonds: true });
      readHelix();
    } else if (s === 'plane') {
      readPlane();
    } else {
      var q = state.quiz;
      if (sc3 && use3d()) sc3.show({ seq: q && q.seq && state.answered ? q.seq : D.PRESETS[0].seq, tw: 1, sep: 0, hl: 'none', sel: { s: 0, i: 0 }, letters: !!(q && q.seq) && state.answered, ends: true, dims: false, hbonds: true });
      readQuiz();
    }
    if (!use3d()) draw2d();
    if (sc3 && use3d()) sc3.render();
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // 调试用
  window.__model = {
    state: state, D: D, scene: sc3, setSeq: setSeq, setScene: setScene, setPmode: setPmode, newQuiz: newQuiz, fill: fill, sync: syncUI,
    answer: function (o) { answer(o == null ? state.quiz.answer : o); }
  };
})();
