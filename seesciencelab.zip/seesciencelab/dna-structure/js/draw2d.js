// DNA 的结构：Canvas 平面结构图（教材式：磷酸 ○、脱氧核糖 ⬠、碱基 ▭、氢键虚线；左链 5′→3′ 自上而下，右链反向）
(function () {
  var D = window.DNA;
  var C = { text: '#e6ebf2', muted: '#8d99ab', line: '#2a3446', P: '#ffa65c', S: '#8fa3bd', stick: '#6b7a90', gold: '#ffc94a', bad: '#ff7a59', ok: '#7ee081', hl: '#ffc94a' };
  var PENTA = [-90, -18, 54, 126, 198];   // O、1′、2′、3′、4′ 的方向（左链；右链转 180°）

  function font(ctx, px, w) { ctx.font = (w || '') + ' ' + px + 'px -apple-system, "PingFang SC", "Microsoft YaHei", sans-serif'; }
  function rr(ctx, x, y, w, h, r) { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }
  // 颜色与背景 #05070d 按比例混合（不透明，骨架线不会透出来）
  function mix(hex, k) {
    var c = parseInt(hex.slice(1), 16), bg = [5, 7, 13];
    return 'rgb(' + [(c >> 16) & 255, (c >> 8) & 255, c & 255].map(function (v, i) { return Math.round(bg[i] + (v - bg[i]) * k); }).join(',') + ')';
  }
  function line(ctx, a, b) { ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); ctx.stroke(); }

  // 版面：o.box = { x, y, w, h }，n 个碱基对；返回各部分的屏幕坐标
  function geom(box, n) {
    var u = Math.min(box.h / (n + 1.5), (box.w - 40) / 8.6, 74);
    var cx = box.x + box.w / 2, y0 = box.y + (box.h - n * u) / 2 + u / 2;
    var g = { u: u, cx: cx, rows: [] };
    for (var i = 0; i < n; i++) {
      var y = y0 + i * u, row = { y: y, nt: [] };
      for (var s = 0; s < 2; s++) {
        var sg = s ? 1 : -1, sx = cx + sg * 2.25 * u, r = 0.34 * u, rot = s ? 180 : 0;
        var vx = PENTA.map(function (a) { var t = (a + rot) * Math.PI / 180; return [sx + r * Math.cos(t), y + r * Math.sin(t)]; });
        row.nt.push({
          sx: sx, r: r, vx: vx,
          P: [cx + sg * 3.2 * u, y + (s ? 0.5 : -0.5) * u],
          C5: [sx + sg * 0.5 * u, y + (s ? 0.4 : -0.4) * u]
        });
      }
      g.rows.push(row);
    }
    return g;
  }
  // 碱基在 x 方向的范围：嘌呤伸过中线，嘧啶不到中线，二者之间留 0.3u 画氢键
  function baseSpan(g, s, b) {
    var u = g.u, pur = D.BASES[b].pur, inner = pur ? 0.12 : -0.42;
    return s ? [g.cx - inner * u, g.cx + 1.75 * u] : [g.cx - 1.75 * u, g.cx + inner * u];
  }

  function baseShape(ctx, g, s, y, b, st) {
    var u = g.u, sp = baseSpan(g, s, b), h = 0.46 * u, col = D.BASES[b].col;
    ctx.globalAlpha = st.dim ? 0.32 : 1;
    rr(ctx, sp[0], y - h / 2, sp[1] - sp[0], h, Math.min(6, h / 3));
    ctx.fillStyle = mix(col, 0.22); ctx.fill();
    ctx.lineWidth = st.bad ? 2 : 1.4; ctx.strokeStyle = st.bad ? C.bad : col; ctx.stroke();
    if (D.BASES[b].pur) {   // 嘌呤是双环：画一条分隔线
      var xm = s ? sp[0] + (sp[1] - sp[0]) * 0.42 : sp[0] + (sp[1] - sp[0]) * 0.58;
      ctx.globalAlpha *= 0.5; line(ctx, [xm, y - h / 2 + 3], [xm, y + h / 2 - 3]); ctx.globalAlpha = st.dim ? 0.32 : 1;
    }
    font(ctx, Math.round(Math.max(12, u * 0.3)), '600');
    ctx.fillStyle = st.bad ? C.bad : col; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText(b + (st.bad ? ' ✗' : ''), (sp[0] + sp[1]) / 2, y + 1);
    ctx.globalAlpha = 1;
    return sp;
  }

  // o：{ box, seq, s2（链 2 各位置的碱基，'' 为待填）, mode 'know'|'pair', hl, sel { s, i }, cur, nums, ends, labels }
  function plane(ctx, o) {
    var n = o.seq.length, g = geom(o.box, n), u = g.u, hits = [];
    var hl = o.hl, sel = o.sel || { s: 0, i: 0 };
    function dimOf(s, i, part) {
      if (hl === 'none' || !hl) return false;
      if (hl === 'nuc') return !(s === sel.s && i === sel.i);
      if (hl === 'pair') return !(i === sel.i && (part === 'B' || part === 'hb'));
      if (hl === 'strand') return s !== sel.s || part === 'hb';
      if (hl === 'backbone') return part === 'B' || part === 'hb';
      return false;
    }
    ctx.lineCap = 'round';
    // 骨架：磷酸—5′C—脱氧核糖，3′C—下一个磷酸；先画完所有连线（pass 0），再画脱氧核糖和磷酸（pass 1）
    for (var pass = 0; pass < 2; pass++) for (var i = 0; i < n; i++) {
      for (var s = 0; s < 2; s++) {
        var nt = g.rows[i].nt[s], v = nt.vx, nx = s ? (i > 0 ? g.rows[i - 1].nt[s] : null) : (i < n - 1 ? g.rows[i + 1].nt[s] : null);
        if (!pass) {   // 连线
          ctx.strokeStyle = C.stick; ctx.lineWidth = Math.max(1.5, u * 0.045);
          ctx.globalAlpha = dimOf(s, i, 'S') ? 0.32 : 1;
          line(ctx, nt.P, nt.C5); line(ctx, nt.C5, v[4]);
          if (nx) { ctx.globalAlpha = hl === 'backbone' || (hl === 'strand' && s === sel.s) || hl === 'none' || !hl ? 1 : 0.32; line(ctx, v[3], nx.P); }
          else if (o.ends) {   // 3′ 端的 —OH
            var oh = [v[3][0] + (s ? 0.12 : -0.12) * u, v[3][1] + (s ? -0.32 : 0.32) * u];
            ctx.globalAlpha = 1; line(ctx, v[3], oh);
            font(ctx, Math.round(Math.max(10, u * 0.2))); ctx.fillStyle = C.muted; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
            ctx.fillText('OH', oh[0], oh[1] + (s ? -0.14 : 0.14) * u);
          }
          continue;
        }
        // 脱氧核糖与磷酸
        ctx.globalAlpha = dimOf(s, i, 'S') ? 0.32 : 1;
        ctx.beginPath(); v.forEach(function (p, k) { if (k) ctx.lineTo(p[0], p[1]); else ctx.moveTo(p[0], p[1]); }); ctx.closePath();
        ctx.fillStyle = '#1d2533'; ctx.fill(); ctx.strokeStyle = C.S; ctx.lineWidth = 1.4; ctx.stroke();
        ctx.globalAlpha = dimOf(s, i, 'P') ? 0.32 : 1;
        ctx.beginPath(); ctx.arc(nt.P[0], nt.P[1], 0.24 * u, 0, Math.PI * 2);
        ctx.fillStyle = '#3a2a1c'; ctx.fill(); ctx.strokeStyle = C.P; ctx.stroke();
        font(ctx, Math.round(Math.max(10, u * 0.22)), '600'); ctx.fillStyle = C.P; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText('P', nt.P[0], nt.P[1] + 1);
        if (o.nums) {
          font(ctx, Math.round(Math.max(9, u * 0.17))); ctx.fillStyle = C.muted;
          [[1, '1′'], [2, '2′'], [3, '3′'], [4, '4′']].forEach(function (k) {
            var p = v[k[0]], dx = p[0] - nt.sx, dy = p[1] - g.rows[i].y;
            ctx.fillText(k[1], p[0] + dx * 0.55, p[1] + dy * 0.55);
          });
          ctx.fillText('O', v[0][0] + (v[0][0] - nt.sx) * 0.5, v[0][1] + (s ? 0.12 : -0.12) * u);
          ctx.fillText('5′', nt.C5[0] + (s ? 0.13 : -0.13) * u, nt.C5[1]);
        }
        ctx.globalAlpha = 1;
        hits.push({ kind: 'P', s: s, i: i, x: nt.P[0], y: nt.P[1], r: 0.3 * u });
        hits.push({ kind: 'S', s: s, i: i, x: nt.sx, y: g.rows[i].y, r: 0.4 * u });
      }
    }
    // 碱基与氢键
    for (i = 0; i < n; i++) {
      var y = g.rows[i].y, b1 = o.seq[i], b2 = o.s2[i], ok = b2 && b2 === D.comp(b1);
      var n1 = g.rows[i].nt[0], n2 = g.rows[i].nt[1];
      ctx.strokeStyle = C.stick; ctx.lineWidth = Math.max(1.5, u * 0.045);
      ctx.globalAlpha = dimOf(0, i, 'B') ? 0.32 : 1;
      var sp1 = baseSpan(g, 0, b1); line(ctx, n1.vx[1], [sp1[0], y]);
      baseShape(ctx, g, 0, y, b1, { dim: dimOf(0, i, 'B') });
      hits.push({ kind: 'B', s: 0, i: i, x0: sp1[0], x1: sp1[1], y: y, h: 0.5 * u });
      if (b2) {
        var sp2 = baseSpan(g, 1, b2);
        ctx.globalAlpha = dimOf(1, i, 'B') ? 0.32 : 1; ctx.strokeStyle = C.stick;
        line(ctx, n2.vx[1], [sp2[1], y]);
        baseShape(ctx, g, 1, y, b2, { dim: dimOf(1, i, 'B'), bad: !ok });
        hits.push({ kind: 'B', s: 1, i: i, x0: sp2[0], x1: sp2[1], y: y, h: 0.5 * u });
      } else {
        var x0 = g.cx + 0.15 * u, x1 = g.cx + 1.75 * u, hh = 0.46 * u;
        ctx.globalAlpha = 1; ctx.strokeStyle = C.stick; line(ctx, n2.vx[1], [x1, y]);
        ctx.setLineDash([4, 4]); rr(ctx, x0, y - hh / 2, x1 - x0, hh, 5);
        ctx.fillStyle = o.cur === i ? 'rgba(255,201,74,.12)' : 'rgba(26,34,49,.9)'; ctx.fill();
        ctx.strokeStyle = o.cur === i ? C.gold : C.muted; ctx.lineWidth = o.cur === i ? 2 : 1; ctx.stroke(); ctx.setLineDash([]);
        font(ctx, Math.round(Math.max(12, u * 0.28)), '600'); ctx.fillStyle = o.cur === i ? C.gold : C.muted; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText('?', (x0 + x1) / 2, y + 1);
        hits.push({ kind: 'slot', s: 1, i: i, x0: x0, x1: x1, y: y, h: hh });
      }
      if (ok) {   // 氢键
        var k = D.BASES[b1].hb, xa = Math.min(sp1[1], sp2[0]), xb = Math.max(sp1[1], sp2[0]);
        ctx.globalAlpha = dimOf(0, i, 'hb') ? 0.2 : 1;
        ctx.strokeStyle = '#e6ebf2'; ctx.lineWidth = 1.3; ctx.setLineDash([2.5, 2.5]);
        for (var j = 0; j < k; j++) { var dy = (k === 2 ? (j - 0.5) * 0.18 : (j - 1) * 0.14) * u; line(ctx, [xa + 1, y + dy], [xb - 1, y + dy]); }
        ctx.setLineDash([]); ctx.globalAlpha = 1;
        hits.push({ kind: 'hb', s: 0, i: i, x0: xa - 2, x1: xb + 2, y: y, h: 0.5 * u });
      }
    }
    // 高亮框
    if (hl === 'nuc' || hl === 'pair') {
      var r = g.rows[sel.i], tag;
      ctx.strokeStyle = C.hl; ctx.lineWidth = 1.6; ctx.setLineDash([6, 4]);
      if (hl === 'nuc') {
        var t = r.nt[sel.s], sb = baseSpan(g, sel.s, sel.s ? (o.s2[sel.i] || D.comp(o.seq[sel.i])) : o.seq[sel.i]);
        var xl = sel.s ? sb[0] - 0.08 * u : t.P[0] - 0.34 * u, xr = sel.s ? t.P[0] + 0.34 * u : sb[1] + 0.08 * u;
        var yt = sel.s ? r.y - 0.42 * u : t.P[1] - 0.32 * u, yb = sel.s ? t.P[1] + 0.32 * u : r.y + 0.42 * u;
        rr(ctx, xl, yt, xr - xl, yb - yt, 10); ctx.stroke();
        tag = '一个脱氧核苷酸';
      } else {
        rr(ctx, g.cx - 1.85 * u, r.y - 0.34 * u, 3.7 * u, 0.68 * u, 10); ctx.stroke();
        tag = '碱基对';
      }
      ctx.setLineDash([]);
      if (o.labels) {
        font(ctx, 12, '600'); ctx.fillStyle = C.hl; ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
        var tx = g.cx + 3.65 * u, ty = hl === 'nuc' ? (sel.s ? r.y + 0.2 * u : r.y - 0.2 * u) : r.y;
        if (hl === 'nuc' && !sel.s) { ctx.textAlign = 'right'; tx = g.cx - 3.65 * u; }
        ctx.fillText(tag, tx, ty);
      }
    }
    // 两端与方向
    if (o.ends && n) {
      font(ctx, Math.round(Math.max(12, u * 0.24)), '600'); ctx.fillStyle = C.text; ctx.textBaseline = 'middle'; ctx.textAlign = 'center';
      var top = g.rows[0], bot = g.rows[n - 1];
      ctx.fillText('5′ 端', top.nt[0].P[0], top.nt[0].P[1] - 0.48 * u);
      ctx.fillText('3′ 端', bot.nt[0].vx[3][0] - 0.12 * u, bot.y + 0.95 * u);
      ctx.fillText('3′ 端', top.nt[1].vx[3][0] + 0.12 * u, top.y - 0.95 * u);
      ctx.fillText('5′ 端', bot.nt[1].P[0], bot.nt[1].P[1] + 0.48 * u);
      // 方向箭头
      var ya = top.y - 0.1 * u, yb2 = bot.y + 0.1 * u;
      [[g.cx - 3.85 * u, ya, yb2], [g.cx + 3.85 * u, yb2, ya]].forEach(function (a) {
        if (a[0] < o.box.x + 6 || a[0] > o.box.x + o.box.w - 6) return;
        ctx.strokeStyle = 'rgba(141,153,171,.6)'; ctx.fillStyle = 'rgba(141,153,171,.8)'; ctx.lineWidth = 1.2;
        line(ctx, [a[0], a[1]], [a[0], a[2]]);
        var d = a[2] > a[1] ? 1 : -1;
        ctx.beginPath(); ctx.moveTo(a[0], a[2]); ctx.lineTo(a[0] - 4, a[2] - d * 8); ctx.lineTo(a[0] + 4, a[2] - d * 8); ctx.closePath(); ctx.fill();
      });
    }
    return { hits: hits, u: u, cx: g.cx };
  }

  function hitTest(hits, x, y) {
    for (var k = hits.length - 1; k >= 0; k--) {
      var h = hits[k];
      if (h.r != null ? Math.hypot(x - h.x, y - h.y) <= h.r : x >= h.x0 && x <= h.x1 && Math.abs(y - h.y) <= h.h / 2) return h;
    }
    return null;
  }

  window.DnaDraw = { plane: plane, hitTest: hitTest, C: C };
})();
