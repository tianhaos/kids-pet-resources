(function(){
  'use strict';
  var $=function(id){return document.getElementById(id);},p=new URLSearchParams(location.search);
  function num(k,def,min,max){var v=Number(p.get(k));return p.has(k)&&Number.isFinite(v)?Math.max(min,Math.min(max,v)):def;}
  var scene=Object.hasOwn(Pursuit.presets,p.get('scene'))?p.get('scene'):'catch',preset=Pursuit.presets[scene];
  var s={scene:scene,d:num('d',preset.d,0,60),va:num('va',preset.va,0,16),vb:num('vb',preset.vb,0,16),aa:num('aa',preset.aa,0,3),ab:num('ab',preset.ab,0,3),T:12,t:num('t',3,0,12),graph:p.get('graph')==='gap'?'gap':'position',marks:p.get('marks')!=='0',speed:.7,playing:p.get('play')==='1'};
  var keys=['d','va','vb','aa','ab'],lastEvents='';
  function track(a,b){if(window.Analytics)Analytics.track('追及相遇',a,b||s.scene);}
  function update(){
    s.t=Math.max(0,Math.min(s.T,s.t));
    var q=Pursuit.at(s,s.t),r=Pursuit.roots(s),dv=q.vb-q.va;
    $('clock').textContent=s.t.toFixed(2)+' s';$('distance').textContent=Math.abs(q.gap).toFixed(2)+' m';
    $('order').textContent=Math.abs(q.gap)<.005?'两车位置相同':q.gap>0?'B 在 A 前方':'A 在 B 前方';
    var status=Math.abs(q.gap)<.005?'相遇 · 同一位置':Math.abs(dv)<.005?'此刻速度相等':q.gap*dv>0?'两车正在远离':'两车正在靠近';
    $('status').textContent=r.all?'全程位置相同':status;$('stageStatus').textContent=$('status').textContent;
    $('ra').textContent=q.xa.toFixed(2)+' m';$('rb').textContent=q.xb.toFixed(2)+' m';$('rva').textContent=q.va.toFixed(2)+' m/s';$('rvb').textContent=q.vb.toFixed(2)+' m/s';$('rgap').textContent=(q.gap>0?'+':'')+q.gap.toFixed(2)+' m';
    keys.forEach(function(k){$(k).value=s[k];$('o'+k).textContent=s[k].toFixed(k==='d'?1:1)+(k==='d'?' m':k[0]==='v'?' m/s':' m/s²');});
    $('time').value=s.t;$('ot').textContent=s.t.toFixed(2)+' s';$('play').textContent=s.playing?'❚❚ 暂停':'▶ 播放';$('marks').checked=s.marks;
    document.querySelectorAll('[data-scene]').forEach(function(b){b.classList.toggle('on',b.dataset.scene===s.scene);});
    document.querySelectorAll('[data-graph]').forEach(function(b){b.classList.toggle('on',b.dataset.graph===s.graph);});
    var equal=Pursuit.equalSpeed(s);$('equal').disabled=equal===null;
    var summary=r.all?'0–12 s 内两条轨迹完全重合。':r.times.length?'0–12 s 内相遇 '+r.times.length+' 次：点击下方时刻。':'0–12 s 内没有相遇。更晚是否相遇需另外求解。';
    $('eventNote').textContent=summary;
    var events=JSON.stringify(r);
    if(events!==lastEvents){lastEvents=events;$('events').replaceChildren();r.times.forEach(function(t,i){var b=document.createElement('button');b.textContent='相遇'+(i+1)+' · '+t.toFixed(2)+' s';b.onclick=function(){time(t);track('相遇定位',String(i+1));};$('events').appendChild(b);});}
    document.querySelector('.stage-title h2').textContent=({catch:'追上之前，先越离越远？',twice:'一次超越，为什么还会再相遇？',uniform:'速度差，怎样缩短两车间距？'})[s.scene];
    $('caption').textContent=s.graph==='gap'?'看 Δx 的正负：谁在前？过零：何时相遇？':'两条位置曲线的交点，对应道路上同一位置。';
    PursuitDraw.draw($('road'),s);
  }
  function time(t){s.playing=false;s.t=t;update();}
  function setScene(v){if(!Object.hasOwn(Pursuit.presets,v))return;s.scene=v;Object.assign(s,Pursuit.presets[v]);s.t=0;s.playing=false;track('切换场景');update();}
  document.querySelectorAll('[data-scene]').forEach(function(b){b.onclick=function(){setScene(b.dataset.scene);};});
  document.querySelectorAll('[data-graph]').forEach(function(b){b.onclick=function(){s.graph=b.dataset.graph;track('切换图像',s.graph);update();};});
  keys.forEach(function(k){$(k).oninput=function(){s[k]=+this.value;s.t=0;s.playing=false;update();};$(k).onchange=function(){track('改变条件',k);};});
  $('time').oninput=function(){time(+this.value);};$('time').onchange=function(){track('回看时间');};
  $('speed').oninput=function(){s.speed=+this.value;$('os').textContent=s.speed.toFixed(1)+'×';};
  function play(){if(s.t>=s.T)s.t=0;s.playing=!s.playing;track('播放暂停');update();}
  $('play').onclick=play;$('reset').onclick=function(){time(0);track('重新开始');};
  $('equal').onclick=function(){var t=Pursuit.equalSpeed(s);if(t!==null){time(t);track('速度相等');}};
  $('marks').onchange=function(){s.marks=this.checked;track('等时位置');update();};
  $('panelToggle').onclick=function(){var closed=$('panel').classList.toggle('collapsed');$('panelToggle').setAttribute('aria-expanded',String(!closed));$('panelToggle').textContent=closed?'☰ 实验设置':'收起设置 ↓';};
  function shareURL(){var u=new URL(location.href);u.search='';Object.entries({scene:s.scene,d:s.d,va:s.va,vb:s.vb,aa:s.aa,ab:s.ab,t:s.t.toFixed(6),graph:s.graph,marks:+s.marks,play:0}).forEach(function(a){u.searchParams.set(a[0],a[1]);});return u.href;}
  $('share').onclick=async function(){var u=shareURL();try{await navigator.clipboard.writeText(u);$('shareNote').textContent='已复制当前条件与时刻';track('复制链接');}catch(e){$('shareNote').textContent=u;}};
  var canvas=$('road'),drag=null;
  function pos(e){var r=canvas.getBoundingClientRect();return {x:e.clientX-r.left,y:e.clientY-r.top};}
  function hit(m,z){if(Math.hypot(m.x-z.flag.x,m.y-z.flag.y)<26)return 'gap';if(Math.hypot(m.x-z.a.x,m.y-z.a.y)<30)return 'a';if(Math.hypot(m.x-z.b.x,m.y-z.b.y)<30)return 'b';if(m.x>=z.plot.x-15&&m.x<=z.plot.x+z.plot.w+15&&m.y>=z.plot.y-25&&m.y<=z.plot.y+z.plot.h+20)return 'time';return null;}
  function move(e){if(!drag)return;var m=pos(e),z=drag.geometry;s.playing=false;if(drag.type==='gap'){s.d=Math.round(Math.max(0,Math.min(60,(m.x-z.left)/z.span*z.extent))*2)/2;s.t=0;}else if(drag.type==='time')s.t=Math.max(0,Math.min(s.T,(m.x-z.plot.x)/z.plot.w*s.T));else{var t=Pursuit.timeAt(s,drag.type,(m.x-z.left)/z.span*z.extent);if(t!==null)s.t=t;}update();}
  canvas.onpointerdown=function(e){var z=PursuitDraw.geometry(),type=hit(pos(e),z);if(!type)return;drag={type:type,geometry:z};canvas.setPointerCapture(e.pointerId);canvas.style.cursor='grabbing';if(type==='time')move(e);};
  canvas.onpointermove=function(e){if(drag)move(e);else canvas.style.cursor=hit(pos(e),PursuitDraw.geometry())?'grab':'default';};
  function end(){if(drag)track('画面拖动',drag.type);drag=null;canvas.style.cursor='default';}
  canvas.onpointerup=end;canvas.onpointercancel=end;
  window.addEventListener('keydown',function(e){if(e.code==='Space'&&!/INPUT|BUTTON|SELECT/.test(e.target.tagName)){e.preventDefault();play();}});
  window.addEventListener('resize',update);
  if(innerWidth<=760)$('panel').classList.add('collapsed');$('panelToggle').setAttribute('aria-expanded',String(innerWidth>760));
  window.__model={state:s,setTime:time,setScene:setScene,update:update,play:play,shareURL:shareURL};
  var last=0;function tick(now){var dt=last?Math.min(.05,(now-last)/1000):0;last=now;if(s.playing){s.t+=dt*s.speed;if(s.t>=s.T){s.t=s.T;s.playing=false;}}update();requestAnimationFrame(tick);}update();requestAnimationFrame(tick);
})();
