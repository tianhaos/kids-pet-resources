/* 画面与数值分离。所有文字以 CSS 像素绘制，不拉伸贴图。 */
(function(){
  'use strict';
  var geo={};
  var gold='#ffc94a',blue='#63cafa',muted='#8fa3bd';
  function draw(canvas,s){
    var r=canvas.getBoundingClientRect(),w=r.width,h=r.height,dpr=Math.min(2,devicePixelRatio||1);
    if(canvas.width!==Math.round(w*dpr)||canvas.height!==Math.round(h*dpr)){canvas.width=Math.round(w*dpr);canvas.height=Math.round(h*dpr);}
    var c=canvas.getContext('2d');c.setTransform(dpr,0,0,dpr,0,0);c.clearRect(0,0,w,h);
    var narrow=w<650,left=narrow?42:66,right=w-(narrow?30:50),span=right-left;
    var roadTop=h<660?140:190,roadH=h<660?80:Math.min(140,h*.17),ya=roadTop+roadH*.27,yb=roadTop+roadH*.73;
    var graphY=h*.46+(h<660?92:112),graphBottom=h-(narrow?178:153);
    var extent=Pursuit.extent(s),q=Pursuit.at(s,s.t),meet=Pursuit.roots(s);
    function X(x){return left+x/extent*span;}
    function text(t,x,y,color,size,align){c.fillStyle=color||muted;c.font=(size||12)+'px -apple-system,"PingFang SC",sans-serif';c.textAlign=align||'left';c.fillText(t,x,y);}
    function line(x1,y1,x2,y2,color,width,dash){c.beginPath();c.strokeStyle=color;c.lineWidth=width||1;c.setLineDash(dash||[]);c.moveTo(x1,y1);c.lineTo(x2,y2);c.stroke();c.setLineDash([]);}
    function rect(x,y,ww,hh,rad,fill){c.beginPath();c.roundRect(x,y,ww,hh,rad);c.fillStyle=fill;c.fill();}
    // 俯视道路提供位置参照；车道错开只用于辨认两物体。
    rect(left-35,roadTop-5,span+70,roadH+10,12,'#233045');
    rect(left-35,roadTop,span+70,roadH,10,'#111b29');
    line(left-35,roadTop+roadH/2,right+35,roadTop+roadH/2,'#71839c',1,[14,14]);
    line(left-24,roadTop+5,right+24,roadTop+5,'#475c76',1.5);line(left-24,roadTop+roadH-5,right+24,roadTop+roadH-5,'#475c76',1.5);
    // 共同的横向位置坐标。两条车道只用于区分物体，不计算横向运动。
    var step=extent>400?100:extent>180?50:20;
    for(var x=0;x<=extent;x+=step){line(X(x),roadTop+roadH+8,X(x),roadTop+roadH+15,'#7f9b99');text(x+'',X(x),roadTop+roadH+31,muted,11,'center');}
    text('x / m →',right,roadTop+roadH+51,muted,10,'right');
    // 先前位置的等时采样，避免过密车身影响比较。
    if(s.marks){for(var t=0;t<s.t-.05;t+=1){var past=Pursuit.at(s,t);[ ['xa',ya,gold],['xb',yb,blue] ].forEach(function(a){c.beginPath();c.arc(X(past[a[0]]),a[1],2.5,0,Math.PI*2);c.fillStyle=a[2]+'77';c.fill();});}}
    function car(x,y,color,label,v){
      var cw=narrow?38:54,ch=narrow?22:29;
      c.save();c.translate(x,y);
      c.fillStyle='#050a1088';c.beginPath();c.ellipse(0,15,cw*.65,7,0,0,Math.PI*2);c.fill();
      [-cw*.3,cw*.3].forEach(function(xx){rect(xx-6,-ch*.65,12,ch*1.3,4,'#090f17');});
      var g=c.createLinearGradient(0,-ch/2,0,ch/2);g.addColorStop(0,color);g.addColorStop(1,color===gold?'#b67b21':'#2673a0');
      rect(-cw/2,-ch/2,cw,ch,7,g);rect(-cw*.17,-ch*.39,cw*.42,ch*.78,4,'#19333f');
      line(cw*.04,-ch*.37,cw*.04,ch*.37,'#6a8790',1);
      rect(cw/2-4,-ch*.34,3,5,1,'#fff0bf');rect(cw/2-4,ch*.34-5,3,5,1,'#fff0bf');
      // 中心参考线才是 x，不把车头当作质点位置。
      line(0,-ch/2-5,0,ch/2+5,'#e7f0eb',1,[2,3]);
      c.restore();text(label+'  '+v.toFixed(1)+' m/s',Math.min(w-46,Math.max(46,x)),y-25,color,11,'center');
      return {x:x,y:y};
    }
    // 间距连接线的端点严格位于同一位置轴上。
    var gapY=roadTop-17;
    line(X(q.xa),ya,X(q.xa),gapY,'#ffc94a55',1,[3,4]);line(X(q.xb),yb,X(q.xb),gapY,'#63cafa55',1,[3,4]);
    line(X(q.xa),gapY,X(q.xb),gapY,'#e7dfc4',1.5);
    [q.xa,q.xb].forEach(function(v){line(X(v),gapY-4,X(v),gapY+4,'#e7dfc4',1.5);});
    var ca=car(X(q.xa),ya,gold,'A',q.va),cb=car(X(q.xb),yb,blue,'B',q.vb);
    if(Math.abs(q.gap)<.05){line(X(q.xa),ya-15,X(q.xb),yb+15,'#e8f3d0',2,[4,4]);}
    // B 的出发旗始终留在初始位置，独立于当前车身，用于拖动初始间距。
    var flagY=roadTop+roadH+49;
    line(X(s.d),flagY-6,X(s.d),flagY+20,blue,1.5);c.beginPath();c.moveTo(X(s.d),flagY-6);c.lineTo(X(s.d)+14,flagY-2);c.lineTo(X(s.d),flagY+4);c.fillStyle=blue;c.fill();
    if(h>=660)text(narrow?'拖蓝旗改初距 · 拖车身回看':'拖蓝旗改初距 · 拖车身或图像回看时刻',left,roadTop+roadH+76,muted,10);
    var plot={x:left,y:graphY,w:span,h:Math.max(55,graphBottom-graphY)};
    text(s.graph==='gap'?'Δx = xB − xA / m':'位置 x / m',left,graphY-25,'#c9d8ea',11);

    var min=0,max=extent;
    if(s.graph==='gap'){
      var values=[Pursuit.at(s,0).gap,Pursuit.at(s,s.T).gap],eq=Pursuit.equalSpeed(s);
      if(eq!==null)values.push(Pursuit.at(s,eq).gap);
      min=Math.min(0,...values);max=Math.max(0,...values);
      var margin=Math.max(5,(max-min)*.13);min-=margin;max+=margin;
    }
    function Y(v){return plot.y+plot.h-(v-min)/(max-min)*plot.h;}
    for(var i=0;i<=4;i++){
      var val=min+(max-min)*i/4,yy=Y(val);line(left,yy,right,yy,'#202c3e');text(val.toFixed(0),left-8,yy+4,muted,10,'right');
    }
    for(var j=0;j<=4;j++){var tt=s.T*j/4,xx=left+span*j/4;line(xx,plot.y,xx,plot.y+plot.h,'#192436');text(tt.toFixed(0),xx,plot.y+plot.h+20,muted,11,'center');}
    text('t / s',right,plot.y+plot.h+39,muted,11,'right');
    if(s.graph==='gap')line(left,Y(0),right,Y(0),'#b8c6b7',1.5);
    function curve(key,color){
      for(var future=0;future<2;future++){
        var start=future?s.t:0,end=future?s.T:s.t;c.beginPath();c.strokeStyle=color;c.lineWidth=2.3;c.setLineDash(future?[5,5]:[]);
        for(var i=0;i<=140;i++){var t=start+(end-start)*i/140,p=Pursuit.at(s,t),xx=left+t/s.T*span,yy=Y(p[key]);if(i===0)c.moveTo(xx,yy);else c.lineTo(xx,yy);}c.stroke();c.setLineDash([]);
      }
    }
    if(s.graph==='gap')curve('gap','#b5dda7');else{curve('xa',gold);curve('xb',blue);}
    meet.times.forEach(function(t,i){var p=Pursuit.at(s,t),xx=left+t/s.T*span,yy=Y(s.graph==='gap'?0:p.xa);c.beginPath();c.arc(xx,yy,5,0,Math.PI*2);c.fillStyle='#f2f0d7';c.fill();text('相遇'+(i+1),xx+(xx>right-40?-8:8),yy-9,'#e0eacb',10,xx>right-40?'right':'left');});
    var tx=left+s.t/s.T*span;line(tx,plot.y,tx,plot.y+plot.h,'#e5eae2',1,[3,4]);
    (s.graph==='gap'?[['gap','#b5dda7']]:[['xa',gold],['xb',blue]]).forEach(function(a){c.beginPath();c.arc(tx,Y(q[a[0]]),4,0,Math.PI*2);c.fillStyle=a[1];c.fill();});
    text('实线：已发生　虚线：未来预测',left,graphY-8,muted,10);
    geo={left:left,span:span,extent:extent,plot:plot,a:ca,b:cb,flag:{x:X(s.d),y:flagY+4},roadTop:roadTop,roadH:roadH};
  }
  window.PursuitDraw={draw:draw,geometry:function(){return geo;}};
})();
