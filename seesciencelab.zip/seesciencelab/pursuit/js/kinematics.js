/* 同一直线上的匀变速运动：SI 单位，车身以质点参考线表示。 */
(function () {
  'use strict';
  var EPS = 1e-9;
  var presets = {
    catch: { d: 20, va: 4, vb: 10, aa: 2, ab: 0 },
    twice: { d: 20, va: 12, vb: 2, aa: 0, ab: 2 },
    uniform: { d: 30, va: 10, vb: 6, aa: 0, ab: 0 }
  };
  function at(s, t) {
    t = Math.max(0, Math.min(s.T, t));
    var xa = s.va*t + s.aa*t*t/2;
    var xb = s.d + s.vb*t + s.ab*t*t/2;
    return { t: t, xa: xa, xb: xb, va: s.va+s.aa*t, vb: s.vb+s.ab*t, gap: xb-xa };
  }
  function roots(s) {
    var a = (s.ab-s.aa)/2, b = s.vb-s.va, c = s.d, r = [];
    if (Math.abs(a)<EPS) {
      if (Math.abs(b)<EPS) return { all: Math.abs(c)<EPS, times: [] };
      r = [-c/b];
    } else {
      var D = b*b-4*a*c;
      if (D < -EPS) return { all: false, times: [] };
      if (Math.abs(D)<EPS) r = [-b/(2*a)];
      else {
        // 避免相近数相减损失精度，再用根的乘积求第二根。
        var q = -.5*(b+(b>=0?1:-1)*Math.sqrt(D));
        r = [q/a, c/q];
      }
    }
    return { all: false, times: r.filter(function(t){return Number.isFinite(t)&&t>=-EPS&&t<=s.T+EPS;}).map(function(t){return Math.max(0,Math.min(s.T,t));}).sort(function(x,y){return x-y;}).filter(function(t,i,a){return !i||Math.abs(t-a[i-1])>EPS;}) };
  }
  function equalSpeed(s) {
    var da = s.ab-s.aa;
    if (Math.abs(da)<EPS) return null;
    var t = (s.va-s.vb)/da;
    return t>=0&&t<=s.T?t:null;
  }
  function extent(s) { return Math.max(60,Math.ceil(Math.max(at(s,s.T).xa,at(s,s.T).xb)/20)*20); }
  function timeAt(s, car, x) {
    var v=car==='a'?s.va:s.vb, a=car==='a'?s.aa:s.ab;
    x-=car==='a'?0:s.d;
    if (v<EPS&&a<EPS) return null;
    if(x<=0)return 0;
    return Math.min(s.T,a<EPS?x/v:2*x/(v+Math.sqrt(v*v+2*a*x)));
  }
  window.Pursuit={presets:presets,at:at,roots:roots,equalSpeed:equalSpeed,extent:extent,timeAt:timeAt};
})();
