// 人眼屈光计算（纯函数）：简化眼模型，角膜 + 晶状体合成一个薄凸透镜，全部用屈光度（D = 1/m）计算。
// 约定：物距 u 单位 m（Infinity 表示远处），聚散度 V = −1/u（发散为负）；
// 眼镜与眼睛的焦度直接相加（忽略镜眼距离）；像落在视网膜上 ⇔ V + 眼镜焦度 + 眼的焦度 = R。
(function () {
  var P_STD = 60;     // 正常眼放松时的焦度（D），也是正常眼"对准视网膜"所需的焦度
  var N_EYE = 1.336;  // 眼内介质折射率，只用于把焦度差换算成毫米
  var A_YOUNG = 5;    // 青少年调节力（D，示意值：近点 20 cm）
  var A_OLD = 1;      // 老花眼调节力（D：近点约 1 m）
  var CLEAR = 0.25;   // 离焦小于 0.25 D 视为看得清
  var PUPIL_MM = 4;   // 瞳孔直径，用于估算视网膜上的模糊光斑

  var TYPES = {
    normal:     { key: 'normal',     name: '正常眼' },
    myopia:     { key: 'myopia',     name: '近视眼' },
    hyperopia:  { key: 'hyperopia',  name: '远视眼' },
    presbyopia: { key: 'presbyopia', name: '老花眼' }
  };

  // 构造一只眼：type 见 TYPES；cause = 'axial' 眼轴长短异常 / 'lens' 晶状体曲度异常；deg 为屈光不正度数（100 度 = 1 D）
  //   R   视网膜位置对应的焦度：只有 V + Pg + P0 + A = R 时像才落在视网膜上（R 越小眼轴越长）
  //   P0  晶状体完全放松（最薄）时眼的焦度
  //   Amax 睫状肌收缩能使焦度增加的最大值（调节力）
  function eye(type, cause, deg) {
    var d = (type === 'myopia' || type === 'hyperopia') ? deg / 100 : 0;
    var s = type === 'myopia' ? 1 : -1;     // 近视：折光相对太强；远视：相对太弱
    var R = P_STD, P0 = P_STD;
    if (cause === 'lens') P0 += s * d;      // 晶状体太凸 / 太扁
    else R -= s * d;                        // 眼轴太长 / 太短
    return {
      type: type, cause: cause, deg: d * 100, name: TYPES[type].name,
      R: R, P0: P0, Amax: type === 'presbyopia' ? A_OLD : A_YOUNG
    };
  }

  function vergence(u) { return isFinite(u) ? -1 / u : 0; }

  // 能看清物体所需的调节量（不夹取）
  function needA(e, u, Pg) { return e.R - e.P0 - Pg - vergence(u); }

  // 睫状体自动调节的目标：尽量对焦，但不能超出 [0, Amax]
  function targetA(e, u, Pg) { return Math.max(0, Math.min(e.Amax, needA(e, u, Pg))); }

  // 成像结果：V 入射聚散度，V2 经眼镜后，Vi 经眼睛后，dV = Vi − R（> 0 像在视网膜前，< 0 在视网膜后）
  function solve(e, u, Pg, A) {
    var V = vergence(u), V2 = V + Pg, Pe = e.P0 + A, Vi = V2 + Pe, dV = Vi - e.R;
    return {
      V: V, V2: V2, Pe: Pe, Vi: Vi, dV: dV,
      dmm: N_EYE * 1000 * (1 / Vi - 1 / e.R),   // 像相对视网膜的位置（mm），负数在前
      blur: PUPIL_MM * Math.abs(dV),            // 模糊角（毫弧度）≈ 瞳孔直径 × 离焦
      clear: Math.abs(dV) < CLEAR,
      where: Math.abs(dV) < CLEAR ? 'on' : dV > 0 ? 'front' : 'behind'
    };
  }

  // 戴着焦度 Pg 的眼镜时能看清的范围（m）：far 远点、near 近点；none = 无论远近都看不清
  function range(e, Pg) {
    var E0 = e.P0 + Pg - e.R, Et = E0 + e.Amax;
    if (Et < -CLEAR / 2) return { none: true };
    return {
      far: E0 > 1e-6 ? 1 / E0 : Infinity,
      farNeedsAcc: E0 < -1e-6,               // 远视：连看远处都要调节
      near: Et > 1e-6 ? 1 / Et : Infinity
    };
  }

  // 自动配镜（D，0.25 D 一档）：
  //  近视、远视：完全矫正，让晶状体放松时正好看清远处；
  //  老花：让当前物体刚好看清所需的最小度数（看远处时为 0）；正常眼：0。
  function prescribe(e, u) {
    var p = 0;
    if (e.type === 'myopia' || e.type === 'hyperopia') p = e.R - e.P0;
    else if (e.type === 'presbyopia') {
      var lo = needA(e, u, 0) - e.Amax, hi = needA(e, u, 0);  // 可选焦度区间 [lo, hi]
      p = lo > 0 ? lo : hi < 0 ? hi : 0;
    }
    return Math.round(p * 4) / 4;
  }

  window.Eye = {
    eye: eye, vergence: vergence, targetA: targetA, solve: solve, range: range, prescribe: prescribe,
    TYPES: TYPES, P_STD: P_STD, A_YOUNG: A_YOUNG, A_OLD: A_OLD, CLEAR: CLEAR
  };
})();
