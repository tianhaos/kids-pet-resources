(function () {
  var E = window.Eye;
  var $ = function (id) { return document.getElementById(id); };
  var qa = function (sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); };

  var state = {
    type: 'normal', cause: 'axial', deg: { myopia: 300, hyperopia: 300 },
    u: Infinity,                       // 物距（m），Infinity = 远处
    glass: 'none', gdeg: 300,          // 眼镜：none / concave / convex，度数
    autoAcc: true, A: 0,               // 睫状体自动调节、当前调节量（D）
    show: { labels: true },
    preset: 'n-far',
    e: null, Pg: 0                     // 每帧由上面的字段导出
  };

  // 情景预设
  var PRESETS = {
    'n-far':  { type: 'normal',     u: Infinity, glass: 'none' },
    'n-near': { type: 'normal',     u: 0.25,     glass: 'none' },
    'm-far':  { type: 'myopia',     u: Infinity, glass: 'none',    cause: 'axial', deg: 300 },
    'm-fix':  { type: 'myopia',     u: Infinity, glass: 'concave', cause: 'axial', deg: 300, gdeg: 300 },
    'h-near': { type: 'hyperopia',  u: 0.25,     glass: 'none',    cause: 'axial', deg: 300 },
    'h-fix':  { type: 'hyperopia',  u: 0.25,     glass: 'convex',  cause: 'axial', deg: 300, gdeg: 300 },
    'p-near': { type: 'presbyopia', u: 0.25,     glass: 'none' },
    'p-fix':  { type: 'presbyopia', u: 0.25,     glass: 'convex',  gdeg: 300 }
  };

  var stage = $('stage'), canvas = $('eye'), panel = $('panel');
  var view = window.EyeDraw(canvas);

  function derive() {
    state.e = E.eye(state.type, state.cause, state.deg[state.type] || 0);
    state.Pg = state.glass === 'none' ? 0 : (state.glass === 'concave' ? -1 : 1) * state.gdeg / 100;
    if (state.A > state.e.Amax) state.A = state.e.Amax;
  }

  // ---------- 物距：滑块 0..100 对数映射 10 cm～10 m，100 视为无穷远 ----------
  var distEl = $('dist');
  function uToSlider(u) { return isFinite(u) ? Math.max(0, Math.min(99, 50 * Math.log10(u / 0.1))) : 100; }
  function sliderToU(v) { return v >= 100 ? Infinity : 0.1 * Math.pow(10, v / 50); }
  function fmtU(u) { return !isFinite(u) ? '∞（远处）' : u >= 1 ? u.toFixed(1) + ' m' : Math.round(u * 100) + ' cm'; }

  function setU(u, fromSlider) {
    state.u = u;
    if (!fromSlider) distEl.value = uToSlider(u);
    $('distOut').textContent = fmtU(u);
  }
  distEl.addEventListener('input', function () { clearPreset(); setU(sliderToU(parseFloat(distEl.value)), true); });
  qa('[data-u]').forEach(function (b) {
    b.addEventListener('click', function () { clearPreset(); setU(b.dataset.u === 'inf' ? Infinity : parseFloat(b.dataset.u)); });
  });

  // ---------- 拖动视力表 ----------
  var dragging = false, dragOff = 0;
  function localXY(e) { var r = canvas.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; }
  canvas.addEventListener('pointerdown', function (e) {
    var p = localXY(e);
    if (!view.hitObject(p[0], p[1], state.u)) return;
    dragging = true;
    dragOff = p[0] - view.objX(state.u);
    try { canvas.setPointerCapture(e.pointerId); } catch (err) { /* 合成事件无法捕获指针 */ }
    canvas.classList.add('grabbing');
    clearPreset();
  });
  canvas.addEventListener('pointermove', function (e) {
    var p = localXY(e);
    if (!dragging) { canvas.classList.toggle('grab', view.hitObject(p[0], p[1], state.u)); return; }
    var u = view.uFromX(p[0] - dragOff);
    if (isFinite(u) && Math.abs(u - 0.25) < 0.012) u = 0.25;   // 吸附到明视距离 25 cm
    setU(u);
  });
  function endDrag(e) {
    if (!dragging) return;
    dragging = false;
    canvas.classList.remove('grabbing');
    if (canvas.hasPointerCapture(e.pointerId)) canvas.releasePointerCapture(e.pointerId);
  }
  canvas.addEventListener('pointerup', endDrag);
  canvas.addEventListener('pointercancel', endDrag);

  // ---------- 眼睛 ----------
  function setSeg(attr, val) { qa('[data-' + attr + ']').forEach(function (b) { b.classList.toggle('on', b.dataset[attr] === val); }); }

  qa('[data-eye]').forEach(function (b) {
    b.addEventListener('click', function () { clearPreset(); state.type = b.dataset.eye; syncUI(); });
  });
  qa('[data-cause]').forEach(function (b) {
    b.addEventListener('click', function () { clearPreset(); state.cause = b.dataset.cause; syncUI(); });
  });
  $('deg').addEventListener('input', function () {
    clearPreset();
    if (state.deg[state.type] !== undefined) state.deg[state.type] = parseFloat($('deg').value);
    syncUI();
  });

  // ---------- 晶状体曲度 ----------
  var accEl = $('acc'), autoAccEl = $('autoAcc');
  autoAccEl.addEventListener('change', function () { state.autoAcc = autoAccEl.checked; });
  accEl.addEventListener('input', function () {
    state.autoAcc = false; autoAccEl.checked = false;
    state.A = Math.min(state.e.Amax, parseFloat(accEl.value));
  });

  // ---------- 眼镜 ----------
  qa('[data-glass]').forEach(function (b) {
    b.addEventListener('click', function () { clearPreset(); state.glass = b.dataset.glass; syncUI(); });
  });
  $('gdeg').addEventListener('input', function () { clearPreset(); state.gdeg = parseFloat($('gdeg').value); syncUI(); });
  $('rx').addEventListener('click', function () {
    clearPreset();
    derive();
    var p = E.prescribe(state.e, state.u), note;
    if (Math.abs(p) < 0.125) {
      state.glass = 'none';
      note = state.type === 'presbyopia' ? '老花眼看远处不需要戴老花镜。' : '这只眼睛看当前物体不需要戴眼镜。';
    } else {
      state.glass = p < 0 ? 'concave' : 'convex';
      state.gdeg = Math.min(600, Math.round(Math.abs(p) * 100 / 25) * 25);
      note = '配 ' + (p < 0 ? '凹透镜 −' : '凸透镜 +') + state.gdeg + ' 度（' + (p > 0 ? '+' : '−') + (state.gdeg / 100).toFixed(2) + ' D）'
        + (state.type === 'presbyopia' ? '，看近处时戴。' : '，晶状体放松时正好看清远处。');
    }
    $('rxNote').textContent = note;
    syncUI();
    Analytics.track('眼睛', '自动配镜', state.type);
  });

  // ---------- 情景 ----------
  qa('[data-preset]').forEach(function (b) {
    b.addEventListener('click', function () { applyPreset(b.dataset.preset); Analytics.track('眼睛', '情景', b.textContent); });
  });
  function applyPreset(id) {
    var p = PRESETS[id];
    state.type = p.type; state.glass = p.glass;
    if (p.cause) state.cause = p.cause;
    if (p.deg) state.deg[p.type] = p.deg;
    if (p.gdeg) state.gdeg = p.gdeg;
    state.autoAcc = true; autoAccEl.checked = true;
    setU(p.u);
    state.preset = id;
    syncUI();
  }
  function clearPreset() { state.preset = null; $('rxNote').textContent = ''; }

  // ---------- 显示 ----------
  $('showLabels').addEventListener('change', function () { state.show.labels = $('showLabels').checked; });

  function syncUI() {
    derive();
    setSeg('eye', state.type);
    setSeg('cause', state.cause);
    setSeg('glass', state.glass);
    var hasDeg = state.type === 'myopia' || state.type === 'hyperopia';
    $('causeRow').hidden = !hasDeg;
    $('degRow').hidden = !hasDeg;
    if (hasDeg) {
      $('deg').value = state.deg[state.type];
      $('degOut').textContent = state.deg[state.type] + ' 度';
      qa('[data-cause]').forEach(function (b) {
        b.textContent = b.dataset.cause === 'axial'
          ? (state.type === 'myopia' ? '眼轴过长' : '眼轴过短')
          : (state.type === 'myopia' ? '晶状体过凸' : '晶状体过扁');
      });
    }
    $('eyeNote').textContent = {
      normal: '晶状体放松时，远处物体的像正好落在视网膜上；看近处时睫状体收缩，晶状体变厚。',
      myopia: state.cause === 'axial'
        ? '眼球前后径过长，远处物体的像落在视网膜前。'
        : '晶状体太厚、折光能力太强，即使完全放松，远处物体的像也落在视网膜前。',
      hyperopia: state.cause === 'axial'
        ? '眼球前后径过短，近处物体的像落在视网膜后。'
        : '晶状体太薄、折光能力太弱，近处物体的像落在视网膜后。',
      presbyopia: '年龄增大后晶状体变硬、弹性下降，调节能力只剩约 1 D（近点约 1 m），看远正常、看近模糊。'
    }[state.type];
    accEl.max = state.e.Amax;
    $('accMax').textContent = '最大 ' + state.e.Amax + ' D';
    $('gdegRow').hidden = state.glass === 'none';
    $('gdeg').value = state.gdeg;
    $('gdegOut').textContent = (state.glass === 'concave' ? '−' : '+') + state.gdeg + ' 度';
    qa('[data-preset]').forEach(function (b) { b.classList.toggle('on', b.dataset.preset === state.preset); });
  }

  $('panelToggle').addEventListener('click', function () { panel.classList.toggle('collapsed'); });
  if (window.matchMedia('(max-width: 760px)').matches) panel.classList.add('collapsed');

  // ---------- 眼中所见：静态视力表，CSS 模糊程度随离焦变化 ----------
  var chart = $('chart');
  function drawChart() {
    var w = chart.clientWidth, h = chart.clientHeight, dpr = Math.min(window.devicePixelRatio || 1, 2);
    if (!w || !h) return;
    chart.width = Math.round(w * dpr); chart.height = Math.round(h * dpr);
    var c = chart.getContext('2d');
    c.setTransform(dpr, 0, 0, dpr, 0, 0);
    c.fillStyle = '#f2efe6'; c.fillRect(0, 0, w, h);
    var rows = [[1, 0.26], [2, 0.17], [3, 0.12], [4, 0.085], [5, 0.06], [6, 0.042]];
    var y = h * 0.06, rot = [0, 2, 1, 3, 0, 3, 2, 1, 1, 0, 2, 3, 3, 1, 0, 2, 0, 1, 2, 3, 1];
    var n = 0;
    c.fillStyle = '#1b2230'; c.textAlign = 'center'; c.textBaseline = 'middle';
    rows.forEach(function (r) {
      var fs = h * r[1];
      y += fs * 0.62;
      c.font = '700 ' + fs + 'px Arial, sans-serif';
      for (var i = 0; i < r[0]; i++) {
        c.save();
        c.translate(w * (i + 0.5) / r[0] * 0.82 + w * 0.09, y);
        c.rotate(rot[n++ % rot.length] * Math.PI / 2);
        c.fillText('E', 0, 0);
        c.restore();
      }
      y += fs * 0.62;
    });
  }

  // ---------- 读数 ----------
  var last = {};
  function setText(id, s) { if (last[id] !== s) { last[id] = s; $(id).textContent = s; } }
  function fmtDist(m) { return !isFinite(m) ? '∞' : m >= 1 ? m.toFixed(1) + ' m' : Math.round(m * 100) + ' cm'; }

  function tip(sol) {
    var g = state.glass;
    if (sol.clear) {
      if (g !== 'none') return g === 'concave'
        ? '凹透镜先让光线发散一些，像向后移，正好落回视网膜。'
        : '凸透镜先让光线会聚一些，像向前移，正好落回视网膜。';
      if (state.A > 0.3) return '睫状体收缩，晶状体变厚、折光能力变强，近处物体也能看清。';
      return '晶状体放松变薄，像正好落在视网膜上。';
    }
    if (!state.autoAcc) return '自动调节已关闭：拖动「晶状体曲度」滑块试着对焦，或重新打开自动调节。';
    if (sol.where === 'front') {
      if (g === 'convex' && state.type === 'presbyopia') return '老花镜只在看近处时戴：戴着它看远处，光线太会聚，像落在视网膜前。';
      if (g === 'convex') return '凸透镜让光线更会聚，像更靠前了。这只眼睛需要的不是凸透镜。';
      if (g === 'concave') return '凹透镜度数不够，像仍在视网膜前，试试加大度数。';
      return '晶状体已放到最薄，折光仍太强，像落在视网膜前 → 戴凹透镜矫正。';
    }
    if (g === 'concave') return '凹透镜让光线更发散，像更靠后了。这只眼睛需要的不是凹透镜。';
    if (g === 'convex') return '凸透镜度数不够，像仍在视网膜后，试试加大度数。';
    return '晶状体已调到最厚，折光仍不够，像落在视网膜后 → 戴凸透镜矫正。';
  }

  function updateReadouts(sol) {
    var e = state.e;
    var big = $('rState');
    setText('rState', sol.clear ? '✓ 看得清' : sol.where === 'front' ? '✗ 模糊：像在视网膜前' : '✗ 模糊：像在视网膜后');
    big.className = sol.clear ? 'ok' : 'bad';
    setText('rTip', tip(sol));
    var eyeStr = e.name;
    if (e.type === 'myopia' || e.type === 'hyperopia') {
      eyeStr += ' ' + e.deg + ' 度（' + (e.cause === 'axial'
        ? (e.type === 'myopia' ? '眼轴过长' : '眼轴过短')
        : (e.type === 'myopia' ? '晶状体过凸' : '晶状体过扁')) + '）';
    }
    setText('rEye', eyeStr);
    setText('rU', fmtU(state.u));
    setText('rLens', '焦度 ' + sol.Pe.toFixed(1) + ' D · 调节 +' + state.A.toFixed(1) + ' / ' + e.Amax + ' D'
      + (state.A > 0.3 ? '（变厚）' : '（放松）'));
    setText('rImg', sol.clear ? '视网膜上' : '视网膜' + (sol.where === 'front' ? '前 ' : '后 ') + Math.abs(sol.dmm).toFixed(2) + ' mm'
      + '（差 ' + Math.abs(sol.dV).toFixed(2) + ' D）');
    var r = E.range(e, state.Pg);
    setText('rRange', r.none ? '远近都看不清' : fmtDist(r.near) + ' ～ ' + fmtDist(r.far) + (r.farNeedsAcc ? '（看远也要调节）' : ''));
    setText('rGlass', state.glass === 'none' ? '未戴' : (state.glass === 'concave' ? '凹透镜 −' : '凸透镜 +') + state.gdeg + ' 度（'
      + (state.Pg > 0 ? '+' : '−') + Math.abs(state.Pg).toFixed(2) + ' D）');

    // 眼中所见
    var px = Math.min(9, sol.blur * 0.55);
    var f = px < 0.15 ? 'none' : 'blur(' + px.toFixed(2) + 'px)';
    if (last.blur !== f) { last.blur = f; chart.style.filter = f; }
    setText('viewNote', sol.clear ? '清晰' : '模糊 · 离焦 ' + Math.abs(sol.dV).toFixed(1) + ' D');
    $('viewNote').className = sol.clear ? 'ok' : 'bad';
    setText('accOut', '+' + state.A.toFixed(1) + ' D');
  }

  // ---------- 尺寸与主循环 ----------
  function resize() {
    view.resize(stage.clientWidth, stage.clientHeight);
    drawChart();
  }
  new ResizeObserver(resize).observe(stage);

  syncUI();
  setU(state.u);
  resize();

  var lastT = performance.now();
  function frame(t) {
    var dt = Math.min((t - lastT) / 1000, 0.1);
    lastT = t;
    derive();
    if (state.autoAcc) {
      // 睫状体调节需要一点时间：指数逼近目标
      var target = E.targetA(state.e, state.u, state.Pg);
      state.A += (target - state.A) * (1 - Math.exp(-dt / 0.15));
      if (Math.abs(target - state.A) < 0.005) state.A = target;
      if (document.activeElement !== accEl) accEl.value = state.A;
    }
    var sol = E.solve(state.e, state.u, state.Pg, state.A);
    view.draw(state, sol);
    updateReadouts(sol);
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // 调试用
  window.__model = { state: state, setU: setU, applyPreset: applyPreset, solve: function () { derive(); return E.solve(state.e, state.u, state.Pg, state.A); } };
})();
