// 2D 眼球剖面 + 光路图（像素坐标，主光轴在 y = cy，晶状体在 x = xL）
// 示意比例：眼球按单位 D0 绘制；物距、眼镜后光线的"表观发出点"用 g(s) 压缩到画面内；
// 眼内会聚点与视网膜位置都由焦度经同一映射 xAt() 换算，二者的前后关系与计算一致。
(function () {
  var E = window.Eye;
  var EXAG = 3;          // 眼内纵向放大倍数：让 1～6 D 的离焦在图上看得出来
  var G_HALF = 0.4;      // g(s) 的半饱和距离（m）：0.4 m 处位于可用宽度的一半

  var C = {
    grid: 'rgba(255,255,255,0.035)', axis: '#3c475a', text: '#c9d2df', muted: '#8d99ab',
    globe: '#0d1524', sclera: 'rgba(214,222,234,0.55)', retina: '#ff8fa3', nerve: '#d9b38c',
    cornea: '#8fd0ff', aqueous: 'rgba(143,208,255,0.08)', iris: '#5d7fa8',
    lens: 'rgba(143,208,255,0.24)', lensEdge: '#8fd0ff', ciliary: '#b8735a', zonule: 'rgba(214,190,170,0.45)',
    ray: '#ffd166', rayBack: 'rgba(255,209,102,0.55)',
    ok: '#7ee081', bad: '#ff7a59',
    concave: '#c9a7ff', convex: '#ffc94a', board: '#eeeae0'
  };

  function EyeDraw(canvas) {
    var ctx = canvas.getContext('2d');
    var W = 1, H = 1, dpr = 1, D0 = 200, xL = 0, xG = 0, cy = 0, gMax = 100, xInf = 24;
    var geo = null;   // 上一帧的眼球几何，用于命中测试

    function resize(w, h) {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      W = w; H = h;
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
      canvas.style.width = w + 'px'; canvas.style.height = h + 'px';
      var narrow = w < 640;
      D0 = Math.min(w * (narrow ? 0.32 : 0.27), h * 0.38, 300);
      xL = w - (narrow ? 14 : 48) - 1.55 * D0;    // 右侧留出最长眼轴（约 1.33 D0）和视神经
      xG = xL - 0.62 * D0;
      gMax = xG - (narrow ? 34 : 80);
      xInf = narrow ? 18 : 30;
      cy = h * (narrow ? 0.47 : 0.5);
    }

    // ---------- 坐标映射 ----------
    function g(s) { return gMax * s / (s + G_HALF); }
    function gInv(d) { return G_HALF * d / (gMax - d); }
    function objX(u) { return isFinite(u) ? xG - g(u) : xInf; }
    // 屏幕 x → 物距（m），越过最远端即视为无穷远
    function uFromX(x) {
      var d = xG - x;
      if (d >= g(10)) return Infinity;
      return Math.max(0.1, gInv(Math.max(d, 1)));
    }
    // 聚散度为 V 的光束在 x0 处的"表观点"：V < 0 好像从左侧 x 处发出，V > 0 会聚到右侧 x 处
    function apparent(V, x0) {
      if (Math.abs(V) < 1e-6) return null;
      return V < 0 ? x0 - g(-1 / V) : x0 + g(1 / V);
    }
    // 眼内：焦度 P 对准的位置（P = 60 D 时在 D0 处）
    function xAt(P) {
      var x = xL + D0 * (1 + EXAG * (E.P_STD / P - 1));
      return Math.max(xL + 0.12 * D0, Math.min(xL + 3 * D0, x));
    }

    // ---------- 基本绘图 ----------
    function seg(x1, y1, x2, y2, color, width, dash) {
      ctx.beginPath();
      ctx.setLineDash(dash || []);
      ctx.strokeStyle = color; ctx.lineWidth = width || 1.5;
      ctx.moveTo(x1, y1); ctx.lineTo(x2, y2);
      ctx.stroke();
      ctx.setLineDash([]);
    }
    function arrowMid(x1, y1, x2, y2, color) {
      var len = Math.hypot(x2 - x1, y2 - y1);
      if (len < 50) return;
      ctx.save();
      ctx.translate((x1 + x2) / 2, (y1 + y2) / 2); ctx.rotate(Math.atan2(y2 - y1, x2 - x1));
      ctx.beginPath(); ctx.moveTo(5, 0); ctx.lineTo(-4, -3.5); ctx.lineTo(-4, 3.5); ctx.closePath();
      ctx.fillStyle = color; ctx.fill();
      ctx.restore();
    }
    function font(size, weight) {
      ctx.font = (weight || '') + ' ' + (size || 12) + 'px -apple-system, "PingFang SC", "Microsoft YaHei", sans-serif';
    }
    function text(str, x, y, color, align, size, weight) {
      font(size, weight);
      ctx.fillStyle = color || C.text;
      ctx.textAlign = align || 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(str, x, y);
    }
    function roundRect(x, y, w, h, r) {
      ctx.beginPath();
      ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r);
      ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
    }
    function tag(str, x, y, color) {
      font(12);
      var w = ctx.measureText(str).width + 14;
      x = Math.max(w / 2 + 4, Math.min(W - w / 2 - 4, x));
      ctx.fillStyle = 'rgba(11,15,23,0.88)';
      ctx.strokeStyle = color; ctx.lineWidth = 1;
      roundRect(x - w / 2, y - 10, w, 20, 10);
      ctx.fill(); ctx.stroke();
      text(str, x, y, color);
      return x;
    }
    // 结构名称：从锚点引一条细线到文字
    function label(str, ax, ay, tx, ty, align) {
      seg(ax, ay, tx, ty, 'rgba(141,153,171,0.5)', 1);
      text(str, tx + (align === 'left' ? 4 : align === 'right' ? -4 : 0), ty + (align ? 0 : ty < ay ? -8 : 8),
        C.muted, align || 'center', 12);
    }

    // ---------- 眼球几何 ----------
    function geometry(e, Pe) {
      var front = xL - 0.3 * D0, back = xAt(e.R);
      var gm = {
        front: front, back: back, cx: (front + back) / 2, rx: (back - front) / 2, ry: 0.64 * D0,
        pr: 0.17 * D0,                                       // 瞳孔半径
        lw: D0 * (0.03 + Math.max(0, Math.min(18, Pe - 54)) * 0.0055),  // 晶状体半厚度：越凸越厚
        lh: D0 * (0.29 - Math.max(0, Math.min(18, Pe - 54)) * 0.002)    // 变厚时略变圆
      };
      gm.halfH = function (x) {
        var t = (x - gm.cx) / gm.rx;
        return gm.ry * Math.sqrt(Math.max(0, 1 - t * t));
      };
      return gm;
    }

    // 从眼内 (px, py) 沿 (dx, dy) 射出，与眼球椭圆（视网膜）的交点参数 t
    function hitGlobe(gm, px, py, dx, dy) {
      var ox = px - gm.cx, oy = py - cy;
      var a = dx * dx / (gm.rx * gm.rx) + dy * dy / (gm.ry * gm.ry);
      var b = 2 * (ox * dx / (gm.rx * gm.rx) + oy * dy / (gm.ry * gm.ry));
      var c = ox * ox / (gm.rx * gm.rx) + oy * oy / (gm.ry * gm.ry) - 1;
      return (-b + Math.sqrt(Math.max(0, b * b - 4 * a * c))) / (2 * a);
    }

    // ---------- 各部分 ----------
    function drawGrid() {
      ctx.strokeStyle = C.grid; ctx.lineWidth = 1;
      ctx.beginPath();
      var step = Math.max(24, D0 / 6);
      for (var x = xL % step; x < W; x += step) { ctx.moveTo(x, 0); ctx.lineTo(x, H); }
      for (var y = cy % step; y < H; y += step) { ctx.moveTo(0, y); ctx.lineTo(W, y); }
      ctx.stroke();
      seg(0, cy, W, cy, C.axis, 1, [6, 5]);
    }

    function drawEye(gm, st) {
      // 眼球（巩膜）与玻璃体
      ctx.beginPath();
      ctx.ellipse(gm.cx, cy, gm.rx, gm.ry, 0, 0, Math.PI * 2);
      ctx.fillStyle = C.globe; ctx.fill();
      ctx.strokeStyle = C.sclera; ctx.lineWidth = 2.5; ctx.stroke();

      // 视神经
      var a = 0.32, nx = gm.cx + gm.rx * Math.cos(a), ny = cy + gm.ry * Math.sin(a);
      ctx.beginPath();
      ctx.lineCap = 'round';
      ctx.moveTo(nx - 0.02 * D0, ny);
      ctx.quadraticCurveTo(nx + 0.12 * D0, ny + 0.03 * D0, nx + 0.24 * D0, ny + 0.12 * D0);
      ctx.strokeStyle = C.nerve; ctx.lineWidth = 0.09 * D0; ctx.globalAlpha = 0.75; ctx.stroke();
      ctx.globalAlpha = 1; ctx.lineCap = 'butt';

      // 视网膜：眼球后壁
      ctx.beginPath();
      ctx.ellipse(gm.cx, cy, gm.rx - 3, gm.ry - 3, 0, -1.05, 1.05);
      ctx.strokeStyle = C.retina; ctx.lineWidth = 3.5; ctx.stroke();

      // 角膜与房水
      var k = 0.5, xe = gm.cx - gm.rx * Math.sqrt(1 - k * k), ye = k * gm.ry;
      var ctrl = 2 * (gm.front - 0.08 * D0) - xe;
      ctx.beginPath();
      ctx.moveTo(xe, cy - ye);
      ctx.quadraticCurveTo(ctrl, cy, xe, cy + ye);
      ctx.closePath();
      ctx.fillStyle = C.aqueous; ctx.fill();
      ctx.beginPath();
      ctx.moveTo(xe, cy - ye);
      ctx.quadraticCurveTo(ctrl, cy, xe, cy + ye);
      ctx.strokeStyle = C.cornea; ctx.lineWidth = 2; ctx.stroke();

      // 虹膜（中间留出瞳孔）
      var xi = xL - 0.07 * D0, hi = gm.halfH(xi) - 2;
      seg(xi, cy - hi, xi, cy - gm.pr, C.iris, 0.035 * D0);
      seg(xi, cy + gm.pr, xi, cy + hi, C.iris, 0.035 * D0);

      // 睫状体 + 悬韧带：调节时睫状肌收缩（画得更鼓），悬韧带放松，晶状体靠自身弹性变厚
      var hL = gm.halfH(xL), acc = st.e.Amax > 0 ? st.A / E.A_YOUNG : 0;
      [-1, 1].forEach(function (s) {
        var yc = cy + s * (hL - 0.06 * D0);
        ctx.beginPath();
        ctx.ellipse(xL, yc, 0.045 * D0, (0.065 + 0.03 * acc) * D0, 0, 0, Math.PI * 2);
        ctx.fillStyle = C.ciliary; ctx.globalAlpha = 0.85; ctx.fill(); ctx.globalAlpha = 1;
        var y1 = yc - s * (0.065 + 0.03 * acc) * D0, y2 = cy + s * gm.lh;
        for (var i = -1; i <= 1; i++) {
          seg(xL + i * 0.03 * D0, y1, xL + i * 0.6 * gm.lw, y2 + s * 2, C.zonule, 1, acc > 0.15 ? [3, 3] : null);
        }
      });

      // 晶状体：双凸，厚度随焦度变化
      ctx.beginPath();
      ctx.moveTo(xL, cy - gm.lh);
      ctx.quadraticCurveTo(xL + 2 * gm.lw, cy, xL, cy + gm.lh);
      ctx.quadraticCurveTo(xL - 2 * gm.lw, cy, xL, cy - gm.lh);
      ctx.closePath();
      ctx.fillStyle = C.lens; ctx.fill();
      ctx.strokeStyle = C.lensEdge; ctx.lineWidth = 1.6; ctx.stroke();
    }

    function drawLabels(gm, st) {
      var top = cy - gm.ry, bot = cy + gm.ry, hL = gm.halfH(xL);
      var lift = Math.min(36, 0.14 * D0);
      label('角膜', gm.front - 0.06 * D0, cy - 0.3 * gm.ry, gm.front - 0.2 * D0, top + 0.05 * gm.ry, 'right');
      label(st.A > 0.15 ? '睫状体（收缩）' : '睫状体（放松）', xL, cy - hL + 0.02 * D0, xL - 0.1 * D0, top - lift);
      label('视网膜', gm.cx + gm.rx * Math.cos(-0.8), cy + gm.ry * Math.sin(-0.8), gm.back + 0.04 * D0, top - lift * 0.4, 'left');
      label('晶状体', xL, cy + gm.lh, xL - 0.05 * D0, bot + lift);
      label('虹膜', xL - 0.07 * D0, cy + gm.pr + 0.1 * D0, gm.front - 0.2 * D0, bot - 0.05 * gm.ry, 'right');
      var a = 0.32;
      label('视神经', gm.cx + gm.rx * Math.cos(a) + 0.2 * D0, cy + gm.ry * Math.sin(a) + 0.1 * D0,
        gm.back + 0.06 * D0, bot + lift * 0.6, 'left');
      text('玻璃体', gm.cx + 0.12 * gm.rx, cy + 0.55 * gm.ry, 'rgba(141,153,171,0.6)', 'center', 12);
    }

    function drawGlasses(st, showLabels) {
      if (!st.Pg) return;
      var gh = 0.4 * D0, mag = Math.min(6, Math.abs(st.Pg));
      var thin = 0.012 * D0, thick = 0.02 * D0 + mag * 0.007 * D0;
      var concave = st.Pg < 0;
      var te = concave ? thick : thin, tc = concave ? thin : thick;   // 边缘 / 中心半厚度
      var color = concave ? C.concave : C.convex;
      ctx.beginPath();
      ctx.moveTo(xG - te, cy - gh);
      ctx.lineTo(xG + te, cy - gh);
      ctx.quadraticCurveTo(xG + 2 * tc - te, cy, xG + te, cy + gh);
      ctx.lineTo(xG - te, cy + gh);
      ctx.quadraticCurveTo(xG - 2 * tc + te, cy, xG - te, cy - gh);
      ctx.closePath();
      ctx.fillStyle = concave ? 'rgba(201,167,255,0.16)' : 'rgba(255,201,74,0.16)'; ctx.fill();
      ctx.strokeStyle = color; ctx.lineWidth = 1.6; ctx.stroke();
      // 镜框
      seg(xG - te - 3, cy - gh - 2, xG + te + 3, cy - gh - 2, '#9aa6b8', 3);
      seg(xG - te - 3, cy + gh + 2, xG + te + 3, cy + gh + 2, '#9aa6b8', 3);
      if (showLabels) {
        text((concave ? '凹透镜 ' : '凸透镜 ') + (concave ? '−' : '+') + Math.round(Math.abs(st.Pg) * 100) + ' 度',
          xG, cy + gh + 18, color, 'center', 12);
      }
    }

    function drawObject(st, showLabels) {
      var far = !isFinite(st.u);
      var x = objX(st.u), bw = Math.max(18, 0.1 * D0), bh = Math.max(50, 0.32 * D0);
      ctx.save();
      roundRect(x - bw / 2, cy - bh / 2, bw, bh, 3);
      ctx.fillStyle = C.board; ctx.fill();
      ctx.strokeStyle = '#8d99ab'; ctx.lineWidth = 1; ctx.stroke();
      // 视力表上的 E：一行比一行小
      var sizes = [0.42, 0.28, 0.2, 0.14], y = cy - bh / 2 + bh * 0.08;
      sizes.forEach(function (s, i) {
        var fs = Math.max(5, bw * s * 1.6);
        y += fs * 0.6;
        font(fs, '700');
        ctx.fillStyle = '#1b2230'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.save();
        ctx.translate(x, y); ctx.rotate([0, Math.PI / 2, Math.PI, -Math.PI / 2][i % 4]);
        ctx.fillText('E', 0, 0);
        ctx.restore();
        y += fs * 0.75;
      });
      ctx.restore();
      seg(x, cy + bh / 2, x, cy + bh / 2 + 0.12 * D0, '#5b677b', 2);
      // 光线出发点
      ctx.beginPath(); ctx.arc(x, cy, 3, 0, Math.PI * 2); ctx.fillStyle = C.ray; ctx.fill();
      if (showLabels) {
        var dist = far ? '远处（≈ 无穷远）' : st.u >= 1 ? st.u.toFixed(1) + ' m' : Math.round(st.u * 100) + ' cm';
        text(dist, x + (far ? bw / 2 + 2 : 0), cy + bh / 2 + 0.12 * D0 + 14, C.text, far ? 'left' : 'center', 12);
      }
    }

    // 光线：物 → 眼镜 → 晶状体 → 会聚点 / 视网膜
    function drawRays(gm, st, sol) {
      var far = !isFinite(st.u), xo = objX(st.u);
      var src = apparent(sol.V2, xG);                       // 经眼镜后（或不戴眼镜时）光束的表观点
      var xf = xAt(sol.Vi);                                 // 会聚点（视网膜在 xAt(R)，同一映射）
      var hits = [], hs = [-1, -0.5, 0, 0.5, 1];
      var backDrawn = false;
      hs.forEach(function (k) {
        var he = k * gm.pr * 0.85;                          // 晶状体处的高度（向上为正）
        var hg = src === null ? he : he * (xG - src) / (xL - src);
        var yG = cy - hg, yL = cy - he;
        // 入射光
        var x0 = far ? xo + Math.max(9, 0.05 * D0) : xo, y0 = far ? yG : cy;
        seg(x0, y0, xG, yG, C.ray, 1.5);
        arrowMid(x0, y0, xG, yG, C.ray);
        // 眼镜 → 晶状体
        seg(xG, yG, xL, yL, C.ray, 1.5);
        // 戴眼镜时画出折射后光线的反向延长线，指向"好像从这里发出"的点
        if (st.Pg && src !== null && sol.V2 < 0 && Math.abs(k) === 1) {
          seg(xG, yG, src, cy, C.rayBack, 1, [4, 4]);
          backDrawn = true;
        }
        // 眼内
        var dx = xf - xL, dy = cy - yL;
        var t = hitGlobe(gm, xL, yL, dx, dy);
        var hx = xL + dx * t, hy = yL + dy * t;
        seg(xL, yL, hx, hy, C.ray, 1.5);
        if (t > 1.15) arrowMid(xL, yL, xf, cy, C.ray);
        if (t < 1 && !sol.clear) seg(hx, hy, xf, cy, C.rayBack, 1, [4, 4]);
        hits.push(hy);
      });
      if (backDrawn) {
        ctx.beginPath(); ctx.arc(src, cy, 3, 0, Math.PI * 2); ctx.fillStyle = C.rayBack; ctx.fill();
        if (st.show.labels && src > 40) text('好像从这里发出', src, cy - 14, C.muted, 'center', 11);
      }
      return { xf: xf, hits: hits };
    }

    function drawFocus(gm, sol, r) {
      var color = sol.clear ? C.ok : C.bad;
      // 视网膜上的光斑
      var y1 = Math.min.apply(null, r.hits), y2 = Math.max.apply(null, r.hits);
      var xr = gm.cx + gm.rx;
      ctx.save();
      ctx.shadowColor = color; ctx.shadowBlur = 10;
      if (y2 - y1 > 3) seg(xr - 3, y1, xr - 3, y2, color, 4);
      else { ctx.beginPath(); ctx.arc(xr - 3, cy, 4, 0, Math.PI * 2); ctx.fillStyle = color; ctx.fill(); }
      ctx.restore();
      // 会聚点
      if (!sol.clear) {
        ctx.beginPath(); ctx.arc(r.xf, cy, 4, 0, Math.PI * 2);
        if (sol.where === 'behind') { ctx.setLineDash([2, 2]); ctx.strokeStyle = color; ctx.lineWidth = 1.5; ctx.stroke(); ctx.setLineDash([]); }
        else { ctx.fillStyle = color; ctx.fill(); }
      }
      var str = sol.clear ? '像成在视网膜上 ✓' : sol.where === 'front' ? '像成在视网膜前' : '像成在视网膜后';
      var ty = cy - gm.ry - Math.min(36, 0.14 * D0) - 22;
      var xt = sol.clear ? xr : r.xf;
      seg(xt, ty + 10, xt, cy - 6, color, 1, [3, 3]);
      tag(str, xt, ty, color);
    }

    function draw(st, sol) {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, W, H);
      var gm = geometry(st.e, sol.Pe);
      geo = gm;
      drawGrid();
      drawEye(gm, st);
      if (st.show.labels) drawLabels(gm, st);
      drawGlasses(st, st.show.labels);
      drawObject(st, st.show.labels);
      var r = drawRays(gm, st, sol);
      drawFocus(gm, sol, r);
    }

    function hitObject(px, py, u) {
      var x = objX(u);
      var bw = Math.max(18, 0.1 * D0), bh = Math.max(50, 0.32 * D0);
      return Math.abs(px - x) < bw / 2 + 12 && Math.abs(py - cy) < bh / 2 + 0.12 * D0 + 12;
    }

    return { resize: resize, draw: draw, hitObject: hitObject, uFromX: uFromX, objX: objX };
  }

  window.EyeDraw = EyeDraw;
})();
