(function () {
  'use strict';
  const $=id=>document.getElementById(id),params=new URLSearchParams(location.search);
  const state={...Magnetic.clean({scene:params.get('scene'),x:params.get('x'),y:params.get('y'),flip:params.get('flip')==='1',lines:params.get('lines')!=='0',filings:params.get('filings')==='1',grid:params.get('grid')==='1'}),drag:false,records:[]};
  const canvas=$('experiment');let geometry;
  const track=(a,v)=>{if(window.Analytics)Analytics.track('磁场与小磁针',a,String(v??state.scene));};
  function solve(){return Magnetic.sample(state);}
  function update(){
    Object.assign(state,Magnetic.clean(state));Magnetic.relocate(state);const q=solve();
    $('reading').textContent=Magnetic.names[state.scene];
    $('stageAngle').textContent=q.degrees.toFixed(1)+'°';
    $('stageContext').textContent=state.scene==='earth'?'理想地磁 · 子午剖面':state.flip?'磁极已对调 · 同一点方向反转':'磁体外部 · N → S';
    $('stageHint').textContent=state.drag?'松开以固定探测位置':'拖动金色圆框，或点选空白处探测';
    $('position').textContent=`(${state.x.toFixed(2)}, ${(-state.y).toFixed(2)})`;
    $('direction').textContent=q.degrees.toFixed(1)+'°';
    $('x').value=state.x;$('y').value=-state.y;$('xOut').textContent=state.x.toFixed(2);$('yOut').textContent=(-state.y).toFixed(2);
    $('flip').disabled=state.scene==='earth';$('flip').textContent=state.flip?'恢复磁极':'对调磁极';
    $('sceneNote').textContent=state.scene==='earth'?'理想地磁子午剖面，磁轴与地轴重合。探针可沿剖面自由转动，不是只在水平面转动的指南针。':'小磁针中心固定在所选位置，N端直接对齐当地磁场；不模拟磁针平移吸引与转动惯性。';
    for(const key of ['lines','filings','grid'])$(key).checked=state[key];
    document.querySelectorAll('[data-scene]').forEach(b=>{b.classList.toggle('on',b.dataset.scene===state.scene);b.setAttribute('aria-pressed',String(b.dataset.scene===state.scene));});
    geometry=MagneticDraw.render(canvas,state,q);
  }
  function setScene(scene){if(!Object.hasOwn(Magnetic.names,scene))return;Object.assign(state,{scene,flip:false,x:scene==='earth'?1.7:scene==='horseshoe'?.5:0,y:scene==='bar'?-1.25:0});update();track('场景',scene);}
  function setProbe(x,y){state.x=x;state.y=y;update();}
  document.querySelectorAll('[data-scene]').forEach(b=>b.onclick=()=>setScene(b.dataset.scene));
  for(const key of ['lines','filings','grid'])$(key).onchange=()=>{state[key]=$(key).checked;track('显示',key+':'+state[key]);update();};
  $('flip').onclick=()=>{if(state.scene==='earth')return;state.flip=!state.flip;track('对调磁极');update();};
  for(const id of ['x','y']){$(id).oninput=()=>{state[id]=Number($(id).value)*(id==='y'?-1:1);update();};$(id).onchange=()=>track('探测坐标',id);}
  $('reset').onclick=()=>{setScene(state.scene);state.lines=true;state.filings=false;state.grid=false;update();};
  $('record').onclick=()=>{const q=solve();state.records.push(`${Magnetic.names[state.scene]}${state.flip?'（反向）':''}：位置(${state.x.toFixed(2)},${(-state.y).toFixed(2)})，N端 ${q.degrees.toFixed(1)}°`);if(state.records.length>6)state.records.shift();$('records').replaceChildren(...state.records.map(t=>{const p=document.createElement('p');p.textContent=t;return p;}));track('记录');};
  $('clear').onclick=()=>{state.records=[];$('records').textContent='尚无记录。试试在同一点对调磁极前后各记一次。';};
  function link(){const u=new URL(location.href);u.search='';u.hash='';for(const key of ['scene','x','y','flip','lines','filings','grid'])u.searchParams.set(key,typeof state[key]==='boolean'?(state[key]?'1':'0'):state[key]);return u.href;}
  $('share').onclick=async()=>{const u=link();try{await navigator.clipboard.writeText(u);$('shareNote').textContent='已复制当前场景、位置与显示设置。';}catch{$('shareNote').textContent=u;}track('分享');};
  if(matchMedia('(max-width:760px)').matches)$('panel').classList.add('collapsed');
  $('panelToggle').onclick=()=>{$('panelToggle').setAttribute('aria-expanded',String(!$('panel').classList.toggle('collapsed')));};
  // 画面任意空白点可探测；磁针有44px以上的命中范围。
  canvas.onpointerdown=e=>{const p=MagneticDraw.point(e,canvas,geometry);if(Magnetic.inside(state.scene,p.x,p.y,.1)||Math.abs(p.x)>3||Math.abs(p.y)>2.4)return;e.preventDefault();state.drag=true;canvas.setPointerCapture(e.pointerId);setProbe(p.x,p.y);};
  canvas.onpointermove=e=>{const p=MagneticDraw.point(e,canvas,geometry);canvas.style.cursor=state.drag?'grabbing':Magnetic.inside(state.scene,p.x,p.y,.1)?'default':Math.hypot(p.x-state.x,p.y-state.y)*geometry.scale<35?'grab':'crosshair';if(state.drag&&!Magnetic.inside(state.scene,p.x,p.y,.1))setProbe(p.x,p.y);};
  function release(){if(state.drag)track('拖动探测');state.drag=false;update();}
  canvas.onpointerup=release;canvas.onpointercancel=release;
  // 键盘等效操作：聚焦画布，方向键移动探针。
  canvas.onkeydown=e=>{const d={ArrowLeft:[-.1,0],ArrowRight:[.1,0],ArrowUp:[0,-.1],ArrowDown:[0,.1]}[e.key];if(!d)return;e.preventDefault();setProbe(state.x+d[0],state.y+d[1]);};
  window.addEventListener('resize',update);
  window.__model={state,solve,update,setScene,setProbe,link,geometry:()=>geometry};
  new ResizeObserver(update).observe(canvas);update();
}());
