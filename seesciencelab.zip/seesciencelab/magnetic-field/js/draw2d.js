(function () {
  'use strict';
  const cache={};
  const C={n:'#f07875',s:'#72b7ef',line:'#77d9ce',text:'#e3edf4',muted:'#91a9ba'};
  function render(canvas,s,q) {
    const w=canvas.clientWidth,h=canvas.clientHeight,dpr=Math.min(devicePixelRatio||1,2);
    if(canvas.width!==Math.round(w*dpr)||canvas.height!==Math.round(h*dpr)){canvas.width=Math.round(w*dpr);canvas.height=Math.round(h*dpr);}
    const c=canvas.getContext('2d');c.setTransform(dpr,0,0,dpr,0,0);
    c.fillStyle='#05070d';c.fillRect(0,0,w,h);
    // 手机保留相同物理范围；标题与底部观察栏不参与缩放。
    const top=w<800?166:124,bottom=w<600?132:115,scale=Math.max(12,Math.min((w-28)/6.5,(h-top-bottom)/5.3));
    const ox=w/2,oy=top+(h-top-bottom)/2;
    const X=x=>ox+x*scale,Y=y=>oy+y*scale;
    function text(t,x,y,size=13,col=C.text,align='center') {c.font=`${size}px system-ui, sans-serif`;c.fillStyle=col;c.textAlign=align;c.fillText(t,x,y);}
    function path(pts,col,width=1) {c.beginPath();pts.forEach((p,i)=>i?c.lineTo(X(p.x),Y(p.y)):c.moveTo(X(p.x),Y(p.y)));c.strokeStyle=col;c.lineWidth=width;c.stroke();}
    function arrow(x,y,a,len=8,col=C.line) {
      c.save();c.translate(x,y);      c.rotate(a);c.beginPath();c.moveTo(-len/2,-len*.42);c.lineTo(len/2,0);c.lineTo(-len/2,len*.42);c.strokeStyle=col;c.lineWidth=1.6;c.stroke();c.restore();
    }
    // 实验台网格。
    c.save();c.beginPath();c.rect(8,top,w-16,h-top-bottom);c.clip();
    c.strokeStyle='#8199bc16';c.lineWidth=.6;
    for(let x=-3;x<=3;x+=.25){c.beginPath();c.moveTo(X(x),Y(-2.6));c.lineTo(X(x),Y(2.6));c.stroke();}
    for(let y=-2.5;y<=2.5;y+=.25){c.beginPath();c.moveTo(X(-3.25),Y(y));c.lineTo(X(3.25),Y(y));c.stroke();}
    if(s.filings) {
      // 固定采样位置，只画转向后的排列，不模拟铁屑移动或密度。
      for(let i=0;i<33;i++)for(let j=0;j<26;j++) {
        const x=-3.12+i*.194+.025*Math.sin(i*13+j*7),y=-2.4+j*.192+.024*Math.cos(i*7+j*13);
        if(Magnetic.inside(s.scene,x,y,.09))continue;
        const b=Magnetic.field(s.scene,x,y,s.flip),a=Math.atan2(b.y,b.x),l=3.3;
        c.beginPath();c.moveTo(X(x)-l*Math.cos(a),Y(y)-l*Math.sin(a));c.lineTo(X(x)+l*Math.cos(a),Y(y)+l*Math.sin(a));c.strokeStyle='#ccd8cfb0';c.lineWidth=1.4;c.stroke();
      }
    }
    if(s.lines) {
      const lines=cache[s.scene]||(cache[s.scene]=Magnetic.lines(s.scene));
      for(const pts of lines) {
        if(pts.length<8)continue;path(pts,'#75cfc482',1.2);
        for(let i=35;i<pts.length;i+=95) {
          const p=pts[i],b=Magnetic.field(s.scene,p.x,p.y,s.flip);
          arrow(X(p.x),Y(p.y),Math.atan2(b.y,b.x),7);
        }
      }
    }
    if(s.grid)for(let x=-2.7;x<2.8;x+=.54)for(let y=-2.1;y<2.2;y+=.54) {
      if(Magnetic.inside(s.scene,x,y,.15))continue;const b=Magnetic.field(s.scene,x,y,s.flip);
      needle(X(x),Y(y),Math.atan2(b.y,b.x),9,false);
    }
    function rect(x,y,ww,hh,fill){const g=c.createLinearGradient(0,Y(y),0,Y(y+hh));g.addColorStop(0,fill);g.addColorStop(.45,fill);g.addColorStop(1,fill==='#ffffff30'?fill:'#263448');c.fillStyle=g;c.fillRect(X(x),Y(y),ww*scale,hh*scale);c.strokeStyle='#ffffff18';c.lineWidth=1;c.strokeRect(X(x),Y(y),ww*scale,hh*scale);}
    if(s.scene==='bar') {
      c.shadowColor='#0009';c.shadowBlur=15;c.shadowOffsetY=6;
      rect(-1.12,-.26,1.12,.52,s.flip?C.s:C.n);rect(0,-.26,1.12,.52,s.flip?C.n:C.s);c.shadowBlur=0;c.shadowOffsetY=0;
      rect(-1.12,-.26,2.24,.07,'#ffffff30');text(s.flip?'S':'N',X(-.67),Y(.08),22,'#122333');text(s.flip?'N':'S',X(.67),Y(.08),22,'#122333');
    } else if(s.scene==='horseshoe') {
      // 两臂与弯头构成连续实体，右侧为磁极间隙。
      rect(-1.5,-1.05,.48,2.1,'#8393a1');rect(-1.05,-1.05,2,.44,s.flip?C.s:C.n);rect(-1.05,.61,2,.44,s.flip?C.n:C.s);
      rect(-1.05,-1.05,2,.06,'#ffffff30');rect(-1.05,.61,2,.06,'#ffffff30');
      text(s.flip?'S':'N',X(-.35),Y(-.73),20,'#122333');text(s.flip?'N':'S',X(-.35),Y(.93),20,'#122333');
    } else {
      const g=c.createRadialGradient(X(-.3),Y(-.4),0,X(0),Y(0),scale);g.addColorStop(0,'#3989ac');g.addColorStop(1,'#11354e');
      c.beginPath();c.arc(X(0),Y(0),scale*1.03,0,Math.PI*2);c.fillStyle=g;c.fill();c.save();c.clip();
      c.strokeStyle='#75bdd15c';c.lineWidth=1;for(const r of [.35,.7,1]){c.beginPath();c.ellipse(X(0),Y(0),r*scale,scale,0,0,Math.PI*2);c.stroke();}
      for(const y of [-.5,0,.5]){c.beginPath();c.ellipse(X(0),Y(y),Math.sqrt(1-y*y)*scale,.12*scale,0,0,Math.PI*2);c.stroke();}
      // 地球为子午剖面，内部虚线仅示意闭合方向，不画真实大陆。
      c.setLineDash([5,4]);path([{x:0,y:-.8},{x:0,y:.8}],'#ffc94a90',2);c.setLineDash([]);arrow(X(0),Y(.3),Math.PI/2,9,'#ffc94a');c.restore();
      text('地理北',X(0),Y(-1.22),14);text('地理南',X(0),Y(1.38),14);
      text('磁性相当于 S',X(0),Y(-.55),12,C.s);text('磁性相当于 N',X(0),Y(.65),12,C.n);
      text('子午剖面',X(0),Y(0),11,C.text);
    }
    function needle(x,y,a,r,selected) {
      c.save();c.translate(x,y);
      if(selected){c.shadowColor='#ffc94a66';c.shadowBlur=14;c.beginPath();c.arc(0,0,r+10,0,Math.PI*2);c.fillStyle='#122534e8';c.fill();c.strokeStyle=s.drag?'#fff0a8':'#ffc94a';c.lineWidth=s.drag?3:1.5;c.stroke();c.shadowBlur=0;}
      if(selected){c.strokeStyle='#72859d88';c.lineWidth=1;for(let i=0;i<12;i++){const t=i*Math.PI/6;c.beginPath();c.moveTo(Math.cos(t)*(r+5),Math.sin(t)*(r+5));c.lineTo(Math.cos(t)*(r+8),Math.sin(t)*(r+8));c.stroke();}}
      c.rotate(a);c.beginPath();c.moveTo(r,0);c.lineTo(0,-r*.3);c.lineTo(0,r*.3);c.closePath();c.fillStyle=C.n;c.fill();
      c.beginPath();c.moveTo(-r,0);c.lineTo(0,-r*.3);c.lineTo(0,r*.3);c.closePath();c.fillStyle=C.s;c.fill();
      c.beginPath();c.arc(0,0,2.2,0,Math.PI*2);c.fillStyle='#dce7ec';c.fill();c.restore();
      if(selected){text('N',x+Math.cos(a)*(r+5),y+Math.sin(a)*(r+5)+4,12,C.n);text('S',x-Math.cos(a)*(r+5),y-Math.sin(a)*(r+5)+4,12,C.s);}
    }
    // 大磁针是受位置约束、无扰动的方向探针，直接对齐平衡方向。
    needle(X(s.x),Y(s.y),q.angle,19,true);
    c.restore();
    return {w,h,scale,ox,oy,x:X(s.x),y:Y(s.y)};
  }
  function point(e,canvas,g){const r=canvas.getBoundingClientRect();return {x:(e.clientX-r.left-g.ox)/g.scale,y:(e.clientY-r.top-g.oy)/g.scale};}
  window.MagneticDraw={render,point};
}());
