(function () {
  'use strict';
  // 场景坐标：x向右、y向下；长度与磁场均为示意单位。
  const names = {bar:'条形磁铁', horseshoe:'蹄形磁铁', earth:'地磁场'};
  const clamp = (v,a,b) => Math.max(a,Math.min(b,v));
  const number = (v,d,a,b) => v !== null && v !== '' && Number.isFinite(Number(v)) ? clamp(Number(v),a,b) : d;
  function clean(s) {
    const scene=Object.hasOwn(names,s.scene)?s.scene:'bar';
    return {scene, flip:scene==='earth'?false:!!s.flip,
      x:number(s.x,scene==='earth'?1.7:scene==='horseshoe'?.5:0,-2.8,2.8),y:number(s.y,scene==='bar'?-1.25:0,-2.3,2.3),
      lines:s.lines!==false,filings:!!s.filings,grid:!!s.grid};
  }
  function inside(scene,x,y,pad=0) {
    if(scene==='earth')return Math.hypot(x,y)<1.03+pad;
    if(scene==='bar')return Math.abs(x)<1.12+pad&&Math.abs(y)<.26+pad;
    // 开口向右的U形磁铁，与绘图使用相同轮廓。
    return x> -1.5-pad&&x<.95+pad&&y> -1.05-pad&&y<1.05+pad&&
      (x< -1.02+pad||Math.abs(y)>.61-pad);
  }
  function poles(scene) {
    return scene==='horseshoe'?[{x:.93,y:-.83,q:1},{x:.93,y:.83,q:-1}]:[{x:-1.1,y:0,q:1},{x:1.1,y:0,q:-1}];
  }
  function field(scene,x,y,flip=false) {
    if(scene==='earth') {
      // 理想轴对称偶极场 m=(0,1)，北部外场指向地球内部。
      const r=Math.max(.01,Math.hypot(x,y)), r3=r*r*r, dot=y/r;
      return {x:3*dot*x/r/r3,y:(3*dot*y/r-1)/r3};
    }
    let bx=0,by=0;
    for(const p of poles(scene)) {
      const dx=x-p.x,dy=y-p.y,r=Math.max(.015,Math.hypot(dx,dy));
      bx+=p.q*dx/(r*r*r);by+=p.q*dy/(r*r*r);
    }
    const sign=flip?-1:1;return {x:bx*sign,y:by*sign};
  }
  function sample(s) {
    const b=field(s.scene,s.x,s.y,s.flip),m=Math.hypot(b.x,b.y);
    return {bx:b.x,by:b.y,m,angle:Math.atan2(b.y,b.x),degrees:(Math.atan2(-b.y,b.x)*180/Math.PI+360)%360,blocked:inside(s.scene,s.x,s.y,.035)};
  }
  function trace(scene,x,y,flip=false,sign=1) {
    const pts=[{x,y}];
    for(let i=0;i<1600;i++) {
      const b=field(scene,x,y,flip),m=Math.hypot(b.x,b.y);if(m<1e-10)break;
      // 中点法，以固定弧长沿方向积分；不表示粒子轨迹或运动速度。
      const h=.018*sign, mid=field(scene,x+h*b.x/m/2,y+h*b.y/m/2,flip),n=Math.hypot(mid.x,mid.y);
      x+=h*mid.x/n;y+=h*mid.y/n;
      if(Math.abs(x)>3.28||Math.abs(y)>2.65||inside(scene,x,y,.005))break;
      pts.push({x,y});
    }
    return pts;
  }
  function lines(scene) {
    const result=[];
    if(scene==='earth') {
      // 偶极场线 r=L·sin²θ，完整生成两半球的可见外部段。
      for(const side of [-1,1])for(const L of [1.16,1.45,1.9,2.6,3.8,6.2,11]) {
        const edge=Math.asin(Math.sqrt(1.04/L)),pts=[];
        for(let i=0;i<=600;i++) {
          const a=edge+(Math.PI-2*edge)*i/600,r=L*Math.sin(a)**2;
          pts.push({x:side*r*Math.sin(a),y:r*Math.cos(a)});
        }
        result.push(pts);
      }
    } else {
      // 从对称面选线，向两端积分，避免只在一端撒种造成视觉不对称。
      const seeds=scene==='bar'?[.40,.68,1.05,1.55,2.2].flatMap(y=>[{x:0,y},{x:0,y:-y}]):[-2.7,-2,-.8,-.4,0,.4,.8,1.25,1.9,2.7].map(x=>({x,y:0}));
      for(const p of seeds) {
        const back=trace(scene,p.x,p.y,false,-1).reverse();
        result.push(back.concat(trace(scene,p.x,p.y).slice(1)));
      }
      if(scene==='bar')for(const x of [-1.45,1.45]) {
        const back=trace(scene,x,0,false,-1).reverse();result.push(back.concat(trace(scene,x,0).slice(1)));
      }
    }
    return result;
  }
  function relocate(s) {
    if(!inside(s.scene,s.x,s.y,.06))return;
    // 沿当前位置附近最近的可用网格点退出实体，避免磁针插入磁铁。
    let best=null,d=Infinity;
    for(let x=-2.8;x<=2.8;x+=.06)for(let y=-2.3;y<=2.3;y+=.06) {
      const d2=(x-s.x)**2+(y-s.y)**2;
      if(d2<d&&!inside(s.scene,x,y,.13)){best={x,y};d=d2;}
    }
    if(best)Object.assign(s,best);
  }
  window.Magnetic={names,clean,inside,poles,field,sample,trace,lines,relocate,clamp};
}());
