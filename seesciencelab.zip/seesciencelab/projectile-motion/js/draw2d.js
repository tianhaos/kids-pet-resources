// 2D 绘制：抛出平台与地面、轨迹与频闪像、自由落体/匀速直线对比小球、速度与位移的分解、斜面上的平抛、练习题画面
// 世界坐标同 Proj：x 右、y 上，单位 m；frame(R, box) 把世界范围 box 等比放进屏幕矩形 R
// 小球的世界坐标是球心，地面、平台、斜面都向外让出一个小球半径（像素），看起来小球“落在”表面上
(function () {
  var P = window.Proj, DEG = P.DEG, f = P.f;
  var BALL = '#ffc94a', FALL = '#c9a7ff', UNI = '#4fc3f7', VX = '#4fc3f7', VY = '#7ee081', V = '#ff7a59';
  var MUTED = '#8d99ab', TEXT = '#e6ebf2', GRID = 'rgba(141,153,171,.12)', GROUND = '#2b3346', EDGE = '#6f86c9';
  var FONT = '-apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", sans-serif';
  var BR = 8;  // 小球半径（像素）

  function font(px, w) { return (w ? w + ' ' : '') + px + 'px ' + FONT; }
  function label(ctx, s, x, y, o) {
    o = o || {};
    ctx.font = font(o.size || 12, o.bold ? 600 : null);
    ctx.textAlign = o.align || 'center'; ctx.textBaseline = o.base || 'middle';
    ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(5,7,13,.85)'; ctx.strokeText(s, x, y);
    ctx.fillStyle = o.color || TEXT; ctx.fillText(s, x, y);
  }
  function arrow(ctx, x1, y1, x2, y2, color, o) {
    o = o || {};
    var a = Math.atan2(y2 - y1, x2 - x1), len = Math.hypot(x2 - x1, y2 - y1), size = Math.min(o.size || 10, len * 0.6);
    if (len < 1) return;
    ctx.strokeStyle = ctx.fillStyle = color; ctx.lineWidth = o.width || 2.4; ctx.setLineDash(o.dash || []);
    ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2 - Math.cos(a) * size * 0.6, y2 - Math.sin(a) * size * 0.6); ctx.stroke();
    ctx.setLineDash([]);
    ctx.beginPath();
    ctx.moveTo(x2, y2);
    ctx.lineTo(x2 - size * Math.cos(a - 0.42), y2 - size * Math.sin(a - 0.42));
    ctx.lineTo(x2 - size * Math.cos(a + 0.42), y2 - size * Math.sin(a + 0.42));
    ctx.closePath(); ctx.fill();
  }
  function line(ctx, a, b, color, o) {
    o = o || {};
    ctx.strokeStyle = color; ctx.lineWidth = o.width || 1.2; ctx.setLineDash(o.dash || []);
    ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke(); ctx.setLineDash([]);
  }
  function dot(ctx, p, color, r) { ctx.fillStyle = color; ctx.beginPath(); ctx.arc(p.x, p.y, r || 3.5, 0, 7); ctx.fill(); }
  function ball(ctx, p, color, o) {
    o = o || {};
    var r = o.r || BR;
    ctx.globalAlpha = o.alpha == null ? 1 : o.alpha;
    var g = ctx.createRadialGradient(p.x - r * 0.35, p.y - r * 0.35, r * 0.1, p.x, p.y, r);
    g.addColorStop(0, '#fff'); g.addColorStop(0.35, color); g.addColorStop(1, shade(color));
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(p.x, p.y, r, 0, 7); ctx.fill();
    ctx.globalAlpha = 1;
  }
  function shade(c) {
    var n = parseInt(c.slice(1), 16);
    return 'rgb(' + ((n >> 16) * 0.45 | 0) + ',' + ((n >> 8 & 255) * 0.45 | 0) + ',' + ((n & 255) * 0.45 | 0) + ')';
  }
  // 屏幕坐标下从 a0 到 a1（世界角，逆时针为正）画角弧并标注
  function angleArc(ctx, c, a0, a1, r, color, text, o) {
    o = o || {};
    ctx.strokeStyle = color; ctx.lineWidth = 1.5; ctx.setLineDash([]);
    ctx.beginPath(); ctx.arc(c.x, c.y, r, -a0, -a1, a1 > a0); ctx.stroke();
    if (!text) return;
    var am = (a0 + a1) / 2, lr = r + (o.gap || 14);
    label(ctx, text, c.x + Math.cos(am) * lr, c.y - Math.sin(am) * lr, { color: color, size: 12, bold: true });
  }
  function rightMark(ctx, c, a, b, s) {
    // a、b 为两条边的单位向量（屏幕坐标）
    s = s || 9;
    ctx.strokeStyle = TEXT; ctx.lineWidth = 1.2; ctx.setLineDash([]);
    ctx.beginPath();
    ctx.moveTo(c.x + a.x * s, c.y + a.y * s); ctx.lineTo(c.x + (a.x + b.x) * s, c.y + (a.y + b.y) * s); ctx.lineTo(c.x + b.x * s, c.y + b.y * s);
    ctx.stroke();
  }

  // ---------- 世界 ⇄ 屏幕 ----------
  // ax：横向有富余时 box 放在哪里（0 靠左、0.5 居中）
  function frame(R, box, ax) {
    var k = Math.min(R.w / (box.x1 - box.x0), R.h / (box.y1 - box.y0)), slack = R.w - (box.x1 - box.x0) * k;
    var cx = R.x + R.w / 2 + (ax == null ? 0 : (ax - 0.5) * slack), cy = R.y + R.h / 2, mx = (box.x0 + box.x1) / 2, my = (box.y0 + box.y1) / 2;
    return {
      k: k, R: R,
      p: function (x, y) { return { x: cx + (x - mx) * k, y: cy - (y - my) * k }; },
      w: function (sx, sy) { return { x: mx + (sx - cx) / k, y: my - (sy - cy) / k }; },
      view: { x0: mx - R.w / 2 / k, x1: mx + R.w / 2 / k, y0: my - R.h / 2 / k, y1: my + R.h / 2 / k }
    };
  }

  // 网格与刻度（地面以上）
  function grid(ctx, fr, step, o) {
    o = o || {};
    var v = fr.view, R = fr.R, i, a, b;
    ctx.strokeStyle = GRID; ctx.lineWidth = 1;
    ctx.beginPath();
    for (i = Math.ceil(v.x0 / step); i * step <= v.x1; i++) { a = fr.p(i * step, 0); ctx.moveTo(a.x, R.y); ctx.lineTo(a.x, R.y + R.h); }
    for (i = Math.ceil(v.y0 / step); i * step <= v.y1; i++) { a = fr.p(0, i * step); ctx.moveTo(R.x, a.y); ctx.lineTo(R.x + R.w, a.y); }
    ctx.stroke();
    if (o.noLabels) return;
    var y0 = o.y0 || 0;
    for (i = Math.ceil(Math.max(0, v.x0) / step); i * step <= v.x1 - step * 0.3; i++) {
      a = fr.p(i * step, y0);
      label(ctx, f(i * step) + (i === 0 ? '' : ''), a.x, a.y + BR + 12, { size: 11, color: MUTED });
    }
    b = fr.p(0, y0);
    label(ctx, 'x / m', Math.min(R.x + R.w - 22, fr.p(v.x1, 0).x - 22), b.y + BR + 26, { size: 11, color: MUTED });
  }
  function heightTicks(ctx, fr, step, h) {
    var x = fr.R.x + 6;
    for (var i = 1; i * step <= h + 1e-9; i++) {
      var a = fr.p(0, i * step);
      label(ctx, f(i * step), x, a.y, { size: 11, color: MUTED, align: 'left' });
    }
    label(ctx, 'h / m', x, fr.p(0, h).y - 22 < fr.R.y + 8 ? fr.R.y + 8 : fr.p(0, h).y - 22, { size: 11, color: MUTED, align: 'left' });
  }
  function groundFill(ctx, fr, yWorld) {
    var R = fr.R, gy = fr.p(0, yWorld).y + BR;
    ctx.fillStyle = 'rgba(43,51,70,.55)'; ctx.fillRect(0, gy, R.x * 2 + R.w, 4000);
    ctx.strokeStyle = '#4a5670'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(0, gy); ctx.lineTo(R.x * 2 + R.w, gy); ctx.stroke();
    return gy;
  }
  function cliff(ctx, fr, yTop, yBot) {
    var R = fr.R, top = fr.p(0, yTop), bot = fr.p(0, yBot);
    var x1 = top.x - BR - 1, ty = top.y + BR;
    ctx.fillStyle = GROUND; ctx.fillRect(R.x - 40, ty, x1 - R.x + 40, bot.y + BR - ty);
    ctx.strokeStyle = '#4a5670'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(R.x - 40, ty); ctx.lineTo(x1, ty); ctx.lineTo(x1, bot.y + BR); ctx.stroke();
  }

  // 轨迹：从抛出点 o 起、时间 [0, t1] 的抛物线（采样）
  function trajPath(ctx, fr, o, v0, g, t1, n) {
    n = n || 60;
    ctx.beginPath();
    for (var i = 0; i <= n; i++) {
      var t = t1 * i / n, p = fr.p(o.x + v0 * t, o.y - g * t * t / 2);
      if (i) ctx.lineTo(p.x, p.y); else ctx.moveTo(p.x, p.y);
    }
  }
  function traj(ctx, fr, o, v0, g, t1, color, opt) {
    opt = opt || {};
    if (t1 <= 0) return;
    trajPath(ctx, fr, o, v0, g, t1);
    ctx.strokeStyle = color; ctx.lineWidth = opt.width || 2.2; ctx.globalAlpha = opt.alpha == null ? 1 : opt.alpha;
    ctx.setLineDash(opt.dash || []); ctx.stroke(); ctx.setLineDash([]); ctx.globalAlpha = 1;
  }

  // 速度的分解：在屏幕点 sp 处画 vx、vy、v 与夹角 θ
  function velocity(ctx, sp, st, kv, o) {
    o = o || {};
    var ex = sp.x + st.vx * kv, ey = sp.y + st.vy * kv;
    if (o.parts !== false) {
      line(ctx, { x: ex, y: sp.y }, { x: ex, y: ey }, 'rgba(230,235,242,.35)', { dash: [3, 4] });
      line(ctx, { x: sp.x, y: ey }, { x: ex, y: ey }, 'rgba(230,235,242,.35)', { dash: [3, 4] });
      arrow(ctx, sp.x, sp.y, ex, sp.y, VX, { width: 2.2 });
      if (st.vy * kv > 4) arrow(ctx, sp.x, sp.y, sp.x, ey, VY, { width: 2.2 });
      label(ctx, 'vx', ex + 14, sp.y - 8, { color: VX, bold: true, size: 12 });
      if (st.vy * kv > 14) label(ctx, 'vy', sp.x - 14, ey - 4, { color: VY, bold: true, size: 12 });
    }
    arrow(ctx, sp.x, sp.y, ex, ey, V, { width: 2.8, size: 12 });
    var a = Math.atan2(ey - sp.y, ex - sp.x);
    label(ctx, 'v', ex + Math.cos(a) * 14, ey + Math.sin(a) * 14, { color: V, bold: true, size: 13 });
    if (o.angle !== false && st.theta > 2 * DEG) angleArc(ctx, sp, -st.theta, 0, 22, V, 'θ', { gap: 10 });
  }
  // 速度箭头长度比例：最大速度对应约 maxPx 像素
  function kVel(vmax, maxPx) { return Math.min(30, maxPx / Math.max(vmax, 0.1)); }

  // ---------- 视图 ----------
  function View(canvas) {
    var ctx = canvas.getContext('2d'), W = 0, H = 0, dpr = 1, narrow = false, geo = null;
    function resize(w, h) {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      W = w; H = h; narrow = w < 640;
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
      canvas.style.width = w + 'px'; canvas.style.height = h + 'px';
    }
    function bg() {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      var g = ctx.createLinearGradient(0, 0, 0, H);
      g.addColorStop(0, '#04060c'); g.addColorStop(1, '#0a1120');
      ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    }
    function area(bottomExtra) {
      var t0 = narrow ? 84 : 44, bottom = (narrow ? 44 : 50) + (bottomExtra || 0);
      return { x: 12, y: t0, w: W - 24, h: Math.max(120, H - t0 - bottom) };
    }
    function corner(R, lines) {
      lines.forEach(function (s, i) { label(ctx, s, R.x + R.w - 6, R.y + 10 + i * 17, { align: 'right', size: 12, color: i ? MUTED : TEXT }); });
    }

    // 场景一：平抛运动
    // o: { v0, h, g, gName, t, tLand, step, show: { strobe, fall, uniform, vel, disp, ext } }
    function drawThrow(o) {
      bg();
      var R = area(), xr = P.range(o.v0, o.h, o.g);
      var X = P.niceCeil(Math.max(xr * 1.04, 0.4)), Y = P.niceCeil(o.h * 1.04), S = Math.max(X, Y), m = 0.07 * S;
      var fr = frame(R, { x0: -m * 1.6, x1: X + m, y0: -m * 1.4, y1: Y + m * 0.8 }, 0.25);
      var step = P.gridStep(Math.max(X, Y), narrow ? 6 : 9);
      var O = { x: 0, y: o.h }, sh = o.show, t = o.t, st = P.at(o.v0, o.g, t);
      grid(ctx, fr, step);
      groundFill(ctx, fr, 0);
      cliff(ctx, fr, o.h, 0);
      heightTicks(ctx, fr, step, o.h);
      ctx.save(); ctx.beginPath(); ctx.rect(R.x, R.y - 10, R.w, R.h + 20); ctx.clip();
      // 整条轨迹（虚线）和已走过的部分
      traj(ctx, fr, O, o.v0, o.g, o.tLand, BALL, { alpha: 0.3, dash: [4, 5], width: 1.4 });
      traj(ctx, fr, O, o.v0, o.g, t, BALL, { width: 2.4 });
      var sp = fr.p(st.x, o.h - st.drop);
      // 频闪像
      if (sh.strobe) {
        for (var i = 1; i * o.step <= t + 1e-9; i++) {
          var ti = i * o.step, si = P.at(o.v0, o.g, ti), pi = fr.p(si.x, o.h - si.drop);
          if (sh.fall) {
            var pf = fr.p(0, o.h - si.drop);
            line(ctx, pf, pi, 'rgba(201,167,255,.35)', { dash: [3, 4] });
            ball(ctx, pf, FALL, { alpha: 0.45, r: BR - 1.5 });
          }
          if (sh.uniform) {
            var pu = fr.p(si.x, 0);
            line(ctx, pi, pu, 'rgba(79,195,247,.3)', { dash: [3, 4] });
            ball(ctx, pu, UNI, { alpha: 0.45, r: BR - 1.5 });
          }
          ball(ctx, pi, BALL, { alpha: 0.5, r: BR - 1.5 });
        }
        var o0 = fr.p(0, o.h);
        ball(ctx, o0, BALL, { alpha: 0.5, r: BR - 1.5 });
      }
      // 位移的分解
      if (sh.disp && t > 0) {
        var A = fr.p(0, o.h), Bx = fr.p(st.x, o.h);
        line(ctx, A, Bx, 'rgba(230,235,242,.8)', { width: 1.6 });
        line(ctx, Bx, sp, 'rgba(230,235,242,.8)', { width: 1.6 });
        arrow(ctx, A.x, A.y, sp.x, sp.y, TEXT, { width: 1.8, size: 9 });
        if (Bx.x - A.x > 40) label(ctx, 'x = ' + f(st.x) + ' m', (A.x + Bx.x) / 2, A.y - 12, { size: 12 });
        if (sp.y - Bx.y > 26) label(ctx, 'y = ' + f(st.drop) + ' m', Bx.x + 8, (Bx.y + sp.y) / 2, { size: 12, align: 'left' });
        if (st.alpha > 2 * DEG && Bx.x - A.x > 30) angleArc(ctx, A, -st.alpha, 0, Math.min(34, (Bx.x - A.x) * 0.5), TEXT, 'α', { gap: 10 });
      }
      // 速度反向延长线过水平位移中点
      if (sh.ext && t > 0) {
        var M = fr.p(st.x / 2, o.h);
        line(ctx, sp, M, 'rgba(255,122,89,.85)', { dash: [5, 4], width: 1.4 });
        line(ctx, fr.p(0, o.h), fr.p(st.x, o.h), 'rgba(230,235,242,.35)', { dash: [2, 4] });
        dot(ctx, M, V, 3.5);
        label(ctx, 'x/2', M.x, M.y + 13, { size: 12, color: V, bold: true });
      }
      // 对比小球
      if (sh.fall) {
        var fp = fr.p(0, o.h - st.drop);
        if (!sh.strobe && t > 0) line(ctx, fp, sp, 'rgba(201,167,255,.5)', { dash: [3, 4] });
        ball(ctx, fp, FALL);
      }
      if (sh.uniform) {
        var up = fr.p(st.x, 0);
        if (!sh.strobe && t > 0) line(ctx, sp, up, 'rgba(79,195,247,.5)', { dash: [3, 4] });
        ball(ctx, up, UNI);
      }
      // 速度的分解
      var kv = kVel(Math.hypot(o.v0, o.g * o.tLand), Math.min(R.w, R.h) * 0.3);
      if (sh.vel) velocity(ctx, sp, st, kv);
      ball(ctx, sp, BALL);
      ctx.restore();
      corner(R, [o.gName + ' m/s²', sh.strobe ? '频闪间隔 ' + f(o.step) + ' s' : '']);
      geo = { scene: 'throw', fr: fr, O: O };
      return geo;
    }

    // 场景二：斜面上的平抛
    // o: { mode: 'land'|'perp', v0, th, g, gName, t, cmp, show: { vel, far } }
    function drawSlope(o) {
      bg();
      var R = area(), th = o.th, g = o.g, c = Math.cos(th), s = Math.sin(th);
      ctx.save(); ctx.beginPath(); ctx.rect(R.x - 12, R.y - 10, R.w + 24, R.h + 20); ctx.clip();
      var res;
      if (o.mode === 'land') res = slopeLand(R, o, c, s);
      else res = slopePerp(R, o, c, s);
      ctx.restore();
      corner(R, [o.gName + ' m/s²', '斜面倾角 θ = ' + P.deg(th)]);
      geo = { scene: 'slope', fr: res.fr, O: { x: 0, y: 0 } };
      return geo;
    }
    function slopeLand(R, o, c, s) {
      var th = o.th, g = o.g, ks = o.cmp ? [0.5, 1, 1.5] : [1];
      var main = P.onSlope(o.v0, th, g), big = P.onSlope(o.v0 * ks[ks.length - 1], th, g);
      var X = P.niceCeil(Math.max(big.x * 1.12, 0.4)), Yd = X * Math.tan(th);
      var span = Math.max(X, Yd), m = span * 0.06;
      var fr = frame(R, { x0: -m * 2.2, x1: X + m, y0: -Yd - m, y1: m * 2.4 });
      grid(ctx, fr, P.gridStep(span, narrow ? 6 : 9), { noLabels: true });
      // 斜面（向右下方），整体沿法线向外让出一个小球半径
      var off = { x: -s * BR, y: c * BR };  // 屏幕坐标：沿法线向斜面内偏
      var A = fr.p(0, 0), Bp = fr.p(X + m * 3, -(X + m * 3) * Math.tan(th));
      var top = { x: A.x + off.x, y: A.y + off.y }, bot = { x: Bp.x + off.x, y: Bp.y + off.y };
      ctx.fillStyle = GROUND;
      ctx.beginPath(); ctx.moveTo(R.x - 20, top.y); ctx.lineTo(top.x, top.y); ctx.lineTo(bot.x, bot.y); ctx.lineTo(bot.x, R.y + R.h + 40); ctx.lineTo(R.x - 20, R.y + R.h + 40); ctx.closePath(); ctx.fill();
      ctx.strokeStyle = '#4a5670'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(R.x - 20, top.y); ctx.lineTo(top.x, top.y); ctx.lineTo(bot.x, bot.y); ctx.stroke();
      // 倾角
      line(ctx, top, { x: top.x + 70, y: top.y }, 'rgba(230,235,242,.35)', { dash: [3, 4] });
      angleArc(ctx, top, -th, 0, 46, MUTED, 'θ', { gap: 12 });
      var colors = o.cmp ? ['#7ee081', BALL, '#c9a7ff'] : [BALL];
      var kv = kVel(big.v, Math.min(R.w, R.h) * 0.2);
      ks.forEach(function (k, i) {
        var v0 = o.v0 * k, r = P.onSlope(v0, th, g), t = Math.min(o.t, r.t), st = P.at(v0, g, t), col = colors[i], isMain = k === 1;
        traj(ctx, fr, { x: 0, y: 0 }, v0, g, r.t, col, { alpha: 0.3, dash: [4, 5], width: 1.4 });
        traj(ctx, fr, { x: 0, y: 0 }, v0, g, t, col, { width: isMain ? 2.4 : 1.8 });
        var L = fr.p(r.x, -r.drop);
        dot(ctx, L, col, 2.5);
        if (o.cmp) {
          // 落点的速度方向（彼此平行）
          if (t >= r.t - 1e-9) {
            var e = P.at(v0, g, r.t), len = 42;
            arrow(ctx, L.x, L.y, L.x + Math.cos(e.theta) * len, L.y + Math.sin(e.theta) * len, col, { width: 2, size: 9 });
          }
          label(ctx, (k === 1 ? '' : k) + 'v0', L.x + 4, L.y - 16, { color: col, size: 11, bold: true });
        }
        if (isMain && o.show.far) {
          var sf = P.at(v0, g, r.tFar), F = fr.p(sf.x, -sf.drop);
          // 最远点到斜面的垂足
          var d = sf.x * s - sf.drop * c, foot = fr.p(sf.x - d * s, -sf.drop - d * c);
          foot = { x: foot.x + off.x, y: foot.y + off.y };
          line(ctx, F, foot, 'rgba(255,201,74,.8)', { dash: [4, 3], width: 1.4 });
          rightMark(ctx, foot, { x: s, y: -c }, { x: -c, y: -s }, 7);
          dot(ctx, F, BALL, 3);
          label(ctx, '最远 ' + f(r.far) + ' m', (F.x + foot.x) / 2 + 10, (F.y + foot.y) / 2, { size: 11, color: BALL, align: 'left' });
          if (t >= r.tFar) arrow(ctx, F.x, F.y, F.x + c * 40, F.y + s * 40, 'rgba(255,122,89,.75)', { width: 1.6, size: 8 });
        }
        if (isMain && t >= r.t - 1e-9) {
          // 落点：速度与水平方向的夹角 φ
          var en = P.at(v0, g, r.t), Lp = fr.p(r.x, -r.drop);
          line(ctx, Lp, { x: Lp.x + 50, y: Lp.y }, 'rgba(230,235,242,.4)', { dash: [3, 4] });
          angleArc(ctx, Lp, -en.theta, 0, 30, V, 'φ', { gap: 10 });
        }
        var sp = fr.p(st.x, -st.drop);
        if (isMain && o.show.vel) velocity(ctx, sp, st, kv, { angle: false });
        ball(ctx, sp, col, { r: isMain ? BR : BR - 1.5 });
      });
      var Ap = fr.p(0, 0);
      label(ctx, 'O', Ap.x - 12, Ap.y - 12, { size: 12, bold: true });
      return { fr: fr, main: main };
    }
    function slopePerp(R, o, c, s) {
      var th = o.th, g = o.g, r = P.perpHit(o.v0, th, g), t = Math.min(o.t, r.t), st = P.at(o.v0, g, t);
      var Pw = { x: r.x, y: -r.drop }, S = Math.hypot(r.x, r.drop);
      var d1 = Math.min(0.55 * S, 0.8 * r.x / c), d2 = 0.4 * S;
      var foot = { x: Pw.x - d1 * c, y: Pw.y - d1 * s }, tip = { x: Pw.x + d2 * c, y: Pw.y + d2 * s };
      var x1 = Math.max(tip.x, r.x * 1.1), span = Math.max(x1, -foot.y), m = span * 0.07;
      var fr = frame(R, { x0: -m * 2.2, x1: x1 + m, y0: foot.y - m, y1: Math.max(tip.y, 0) + m * 1.6 });
      grid(ctx, fr, P.gridStep(span, narrow ? 6 : 9), { noLabels: true });
      groundFill(ctx, fr, foot.y);
      cliff(ctx, fr, 0, foot.y);
      // 斜面：表面朝左上，沿法线向右下让出小球半径
      var off = { x: s * BR, y: c * BR };
      var F = fr.p(foot.x, foot.y), T = fr.p(tip.x, tip.y), gy = F.y + BR;
      var Fs = { x: F.x + off.x, y: F.y + off.y }, Ts = { x: T.x + off.x, y: T.y + off.y };
      var Fg = { x: Fs.x - (gy - Fs.y) / Math.tan(th), y: gy };
      ctx.fillStyle = GROUND;
      ctx.beginPath(); ctx.moveTo(Fg.x, gy); ctx.lineTo(Ts.x, Ts.y); ctx.lineTo(Ts.x, gy); ctx.closePath(); ctx.fill();
      ctx.strokeStyle = '#4a5670'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(Fg.x, gy); ctx.lineTo(Ts.x, Ts.y); ctx.lineTo(Ts.x, gy); ctx.stroke();
      angleArc(ctx, { x: Fg.x, y: gy }, 0, th, 36, MUTED, 'θ', { gap: 12 });
      traj(ctx, fr, { x: 0, y: 0 }, o.v0, g, r.t, BALL, { alpha: 0.3, dash: [4, 5], width: 1.4 });
      traj(ctx, fr, { x: 0, y: 0 }, o.v0, g, t, BALL, { width: 2.4 });
      var Pp = fr.p(Pw.x, Pw.y), sp = fr.p(st.x, -st.drop);
      var kv = kVel(r.v, Math.min(R.w, R.h) * 0.22);
      if (t >= r.t - 1e-9) {
        // 垂直撞击：速度方向与斜面垂直；速度与竖直方向的夹角等于 θ
        var hitS = { x: Pp.x + off.x, y: Pp.y + off.y };
        rightMark(ctx, hitS, { x: c, y: -s }, { x: -s, y: -c }, 15);
        line(ctx, Pp, { x: Pp.x, y: Pp.y - 70 }, 'rgba(230,235,242,.4)', { dash: [3, 4] });
        var en = P.at(o.v0, g, r.t);
        line(ctx, Pp, { x: Pp.x - en.vx * kv, y: Pp.y - en.vy * kv }, 'rgba(230,235,242,.25)', { dash: [2, 4] });
        angleArc(ctx, Pp, Math.PI / 2, Math.PI / 2 + th, 26, V, 'θ', { gap: 10 });
      }
      if (o.show.vel) velocity(ctx, sp, st, kv, { angle: false });
      ball(ctx, sp, BALL);
      var Op = fr.p(0, 0);
      label(ctx, 'O', Op.x - 14, Op.y - 12, { size: 12, bold: true });
      return { fr: fr, hit: r };
    }

    // ---------- 练习 ----------
    function drawQuiz(q, answered, o) {
      bg();
      var R = area((o.quizH || 180) + 8);
      ctx.save(); ctx.beginPath(); ctx.rect(R.x - 6, R.y - 6, R.w + 12, R.h + 12); ctx.clip();
      if (q.type === 'time') quizTime(R, q, answered);
      else if (q.type === 'calc') quizCalc(R, q, answered);
      else if (q.type === 'grid') quizGrid(R, q, answered);
      else quizAngle(R, q, answered);
      ctx.restore();
      geo = { scene: 'quiz' };
      return geo;
    }
    // 一个抛出平台的小画面：高 h、初速度 v0（g = 10），answered 时画轨迹
    function mini(R, h, v0, name, show, box) {
      var fr = frame(R, box, 0.3), O = { x: 0, y: h }, tl = Math.sqrt(h / 5);
      groundFill(ctx, fr, 0); cliff(ctx, fr, h, 0);
      var top = fr.p(0, h), bot = fr.p(0, 0);
      // 高度标注
      var hx = top.x - BR - 16;
      line(ctx, { x: hx, y: top.y + BR }, { x: hx, y: bot.y + BR }, MUTED);
      label(ctx, f(h, 2) + ' m', hx - 6, (top.y + bot.y) / 2 + BR, { size: 12, align: 'right', color: TEXT });
      if (show) {
        if (v0) traj(ctx, fr, O, v0, 10, tl, BALL, { width: 2 });
        else line(ctx, top, bot, BALL, { width: 2 });
        var L = fr.p(v0 * tl, 0);
        ball(ctx, L, BALL, { alpha: 0.6 });
        label(ctx, 't = ' + f(tl) + ' s' + (v0 ? '，x = ' + f(v0 * tl) + ' m' : ''), L.x - 14, L.y + BR + 26, { size: 12, color: BALL, align: 'right' });
      }
      if (v0) {
        arrow(ctx, top.x, top.y, top.x + 36, top.y, V, { width: 2.2 });
        label(ctx, v0 + ' m/s', top.x + 40, top.y - 12, { size: 12, color: V, align: 'left' });
      } else label(ctx, '静止释放', top.x + 12, top.y - 14, { size: 12, color: MUTED, align: 'left' });
      ball(ctx, top, BALL);
      label(ctx, name, top.x - BR - 4, top.y - 16, { size: 13, bold: true, align: 'right' });
      return fr;
    }
    function quizTime(R, q, answered) {
      var hm = Math.max(q.a.h, q.b.h), xm = Math.max(q.a.v * q.a.t, q.b.v * q.b.t, 0.5);
      var box = { x0: -Math.max(hm, xm) * 0.3, x1: xm * 1.15 + hm * 0.05, y0: -hm * 0.2, y1: hm * 1.15 };
      var gap = 16, w = (R.w - gap) / 2;
      mini({ x: R.x, y: R.y, w: w, h: R.h }, q.a.h, q.a.v, 'A', answered, box);
      mini({ x: R.x + w + gap, y: R.y, w: w, h: R.h }, q.b.h, q.b.v, 'B', answered, box);
    }
    function quizCalc(R, q, answered) {
      var xm = q.v0 * q.t;
      var box = { x0: -Math.max(q.h, xm) * 0.25, x1: xm * 1.4, y0: -q.h * 0.25, y1: q.h * 1.2 };
      var fr = mini(R, q.h, q.v0, '', answered, box);
      if (answered && q.what === 'v') {
        var st = P.at(q.v0, 10, q.t), sp = fr.p(xm, 0);
        velocity(ctx, sp, st, kVel(st.v, Math.min(R.w, R.h) * 0.25), { angle: false });
      }
    }
    function quizGrid(R, q, answered) {
      var m = q.m, k = q.k, cols = 2 * m + 4, rows = 2 * k + 2 + 4;
      var cell = Math.min(R.w / cols, R.h / rows, 44), w = cell * cols, h = cell * rows;
      var x0 = R.x + (R.w - w) / 2, y0 = R.y + (R.h - h) / 2;
      ctx.strokeStyle = 'rgba(141,153,171,.35)'; ctx.lineWidth = 1;
      ctx.beginPath();
      for (var i = 0; i <= cols; i++) { ctx.moveTo(x0 + i * cell, y0); ctx.lineTo(x0 + i * cell, y0 + h); }
      for (i = 0; i <= rows; i++) { ctx.moveTo(x0, y0 + i * cell); ctx.lineTo(x0 + w, y0 + i * cell); }
      ctx.stroke();
      // 网格坐标：a 在 (2, 2)，向右 m 格、向下 k 格 / k+2 格
      function gp(gx, gy) { return { x: x0 + gx * cell, y: y0 + gy * cell }; }
      var pts = [gp(2, 2), gp(2 + m, 2 + k), gp(2 + 2 * m, 4 + 2 * k)];
      if (answered) {
        // a 点的竖直速度 vay = kL/T − gT/2，抛出点在 a 之前 ta = vay/g
        var L = q.L, T = q.T, vay = k * L / T - 10 * T / 2, ta = vay / 10;
        ctx.strokeStyle = BALL; ctx.lineWidth = 1.8; ctx.globalAlpha = 0.8;
        ctx.beginPath();
        for (i = 0; i <= 60; i++) {
          var tt = -ta + (ta + 2.3 * T) * i / 60, xx = q.v0 * tt, yy = 5 * tt * tt - 5 * ta * ta;
          var p = { x: pts[0].x + xx / L * cell, y: pts[0].y + yy / L * cell };
          if (i) ctx.lineTo(p.x, p.y); else ctx.moveTo(p.x, p.y);
        }
        ctx.stroke(); ctx.globalAlpha = 1;
        if (k > 1) {
          var Op = { x: pts[0].x - q.v0 * ta / L * cell, y: pts[0].y - 5 * ta * ta / L * cell };
          dot(ctx, Op, TEXT, 3.5);
          label(ctx, '抛出点', Op.x, Op.y - 12, { size: 11, color: TEXT });
        }
        // 竖直间隔
        var bx = x0 + w - cell * 0.6;
        [[pts[0], pts[1], k], [pts[1], pts[2], k + 2]].forEach(function (s) {
          line(ctx, { x: bx, y: s[0].y }, { x: bx, y: s[1].y }, VY, { width: 2 });
          line(ctx, { x: s[1].x, y: s[1].y }, { x: bx, y: s[1].y }, 'rgba(126,224,129,.35)', { dash: [3, 4] });
          label(ctx, s[2] + ' 格', bx - 8, (s[0].y + s[1].y) / 2, { size: 12, color: VY, align: 'right' });
        });
        line(ctx, { x: pts[0].x, y: pts[0].y }, { x: bx, y: pts[0].y }, 'rgba(126,224,129,.35)', { dash: [3, 4] });
        line(ctx, { x: pts[0].x, y: y0 + cell * 0.5 }, { x: pts[1].x, y: y0 + cell * 0.5 }, VX, { width: 2 });
        line(ctx, { x: pts[1].x, y: y0 + cell * 0.5 }, { x: pts[2].x, y: y0 + cell * 0.5 }, VX, { width: 2 });
        label(ctx, m + ' 格', (pts[0].x + pts[1].x) / 2, y0 + cell * 0.5 - 10, { size: 12, color: VX });
        label(ctx, m + ' 格', (pts[1].x + pts[2].x) / 2, y0 + cell * 0.5 - 10, { size: 12, color: VX });
      }
      ['a', 'b', 'c'].forEach(function (n, j) { ball(ctx, pts[j], BALL, { r: Math.min(BR, cell * 0.28) }); label(ctx, n, pts[j].x - cell * 0.45, pts[j].y - cell * 0.35, { size: 13, bold: true }); });
      label(ctx, '每格 5 cm', x0 + 4, y0 + h + 14, { size: 11, color: MUTED, align: 'left' });
    }
    function quizAngle(R, q, answered) {
      var v0, t, g = 10;
      if (q.sub === 'v') { v0 = q.v0; t = q.t; }
      else { v0 = 10; t = 2 * Math.tan(q.alpha * DEG); }  // 位移方向与水平成 α 时 gt/(2v0) = tanα
      var st = P.at(v0, g, t), xm = st.x, ym = st.drop, span = Math.max(xm, ym);
      var fr = frame(R, { x0: -span * 0.2, x1: xm + span * 0.45, y0: -ym - span * 0.35, y1: span * 0.15 });
      grid(ctx, fr, P.gridStep(span, 8), { noLabels: true });
      var O = fr.p(0, 0), sp = fr.p(xm, -ym), kv = kVel(st.v, Math.min(R.w, R.h) * 0.3);
      traj(ctx, fr, { x: 0, y: 0 }, v0, g, t * 1.15, BALL, { alpha: 0.3, dash: [4, 5], width: 1.4 });
      traj(ctx, fr, { x: 0, y: 0 }, v0, g, t, BALL, { width: 2.2 });
      arrow(ctx, O.x, O.y, O.x + 40, O.y, V, { width: 2.2 });
      label(ctx, 'v0', O.x + 46, O.y - 10, { size: 12, color: V, bold: true });
      ball(ctx, O, BALL, { alpha: 0.6 });
      var Bx = fr.p(xm, 0);
      if (q.sub === 'rel') {
        line(ctx, O, Bx, 'rgba(230,235,242,.6)'); line(ctx, Bx, sp, 'rgba(230,235,242,.6)');
        arrow(ctx, O.x, O.y, sp.x, sp.y, TEXT, { width: 1.8, size: 9 });
        angleArc(ctx, O, -st.alpha, 0, 40, TEXT, q.alpha + '°', { gap: 16 });
        if (answered) {
          var M = fr.p(xm / 2, 0);
          line(ctx, sp, M, 'rgba(255,122,89,.85)', { dash: [5, 4], width: 1.4 });
          dot(ctx, M, V, 3.5); label(ctx, 'x/2', M.x, M.y - 12, { size: 12, color: V, bold: true });
          velocity(ctx, sp, st, kv);
        } else {
          arrow(ctx, sp.x, sp.y, sp.x + st.vx * kv, sp.y + st.vy * kv, V, { width: 2.6 });
          angleArc(ctx, sp, -st.theta, 0, 22, V, 'θ', { gap: 10 });
        }
      } else {
        line(ctx, sp, { x: sp.x + 60, y: sp.y }, 'rgba(230,235,242,.4)', { dash: [3, 4] });
        if (answered) velocity(ctx, sp, st, kv);
        else { arrow(ctx, sp.x, sp.y, sp.x + st.vx * kv, sp.y + st.vy * kv, V, { width: 2.6 }); angleArc(ctx, sp, -st.theta, 0, 22, V, '?', { gap: 10 }); }
        label(ctx, 't = ' + f(t) + ' s', sp.x - 14, sp.y + 4, { size: 12, align: 'right' });
      }
      ball(ctx, sp, BALL);
    }

    return { resize: resize, drawThrow: drawThrow, drawSlope: drawSlope, drawQuiz: drawQuiz, geo: function () { return geo; }, narrow: function () { return narrow; } };
  }

  window.ProjDraw = { View: View, frame: frame, COLORS: { BALL: BALL, FALL: FALL, UNI: UNI, VX: VX, VY: VY, V: V } };
})();
