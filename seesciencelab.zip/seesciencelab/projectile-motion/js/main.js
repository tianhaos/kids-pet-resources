(function () {
  var P = window.Proj, D = window.ProjDraw, DEG = P.DEG, f = P.f;
  var $ = function (id) { return document.getElementById(id); };
  var qa = function (sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); };
  var NAME = '平抛运动';

  var state = {
    scene: 'throw',
    v0: 3, h: 5, grav: 'earth', slow: 0.5,
    show: { strobe: true, fall: false, uniform: false, vel: true, disp: false, ext: false },
    mode: 'land', th: 37, sv0: 4, multi: false, sshow: { vel: true, far: false },
    t: 0, wait: 0, paused: false,
    quiz: null, quizOnly: null, answered: false, correct: false, choice: null, score: { n: 0, ok: 0 }
  };

  var HINTS = {
    throw: '拖动画面中的小球，看任意时刻的位置和速度',
    slope: '拖动小球沿轨迹移动 · 改倾角和初速度',
    quiz: '平抛运动 · 判断练习'
  };
  var SHOWS = ['strobe', 'fall', 'uniform', 'vel', 'disp', 'ext'];

  var stage = $('stage'), panel = $('panel'), cv = $('view');
  var view = D.View(cv);
  function g() { return P.GRAV[state.grav].g; }
  function gName() { return 'g = ' + f(g()); }
  function setSeg(attr, val) { qa('[data-' + attr + ']').forEach(function (b) { b.classList.toggle('on', b.dataset[attr] === String(val)); }); }
  function rethrow() { state.t = 0; state.wait = 0; }

  // 当前场景的总时间
  function tTotal() {
    if (state.scene === 'throw') return P.landTime(state.h, g());
    var th = state.th * DEG;
    if (state.mode === 'perp') return P.perpHit(state.sv0, th, g()).t;
    return P.onSlope(state.sv0 * (state.multi ? 1.5 : 1), th, g()).t;
  }

  // ---------- 场景 ----------
  qa('[data-scene]').forEach(function (b) {
    b.addEventListener('click', function () { setScene(b.dataset.scene); Analytics.track(NAME, '场景', b.textContent); });
  });
  function setScene(sc) {
    state.scene = sc;
    if (sc === 'quiz' && !state.quiz) newQuiz();
    $('rName').className = '';
    rethrow();
    syncUI();
  }

  // ---------- 控件 ----------
  qa('[data-grav]').forEach(function (b) {
    b.addEventListener('click', function () { state.grav = b.dataset.grav; rethrow(); syncUI(); Analytics.track(NAME, '重力加速度', b.textContent); });
  });
  qa('[data-slow]').forEach(function (b) {
    b.addEventListener('click', function () { state.slow = parseFloat(b.dataset.slow); syncUI(); Analytics.track(NAME, '播放速度', b.textContent); });
  });
  qa('[data-mode]').forEach(function (b) {
    b.addEventListener('click', function () { state.mode = b.dataset.mode; rethrow(); syncUI(); Analytics.track(NAME, '斜面', b.textContent); });
  });
  function bindSlider(id, get, set, restart) {
    var el = $(id);
    el.addEventListener('input', function () { set(parseFloat(el.value)); if (restart) rethrow(); });
    el.addEventListener('change', function () { Analytics.track(NAME, '滑块', id); });
    return { el: el, get: get };
  }
  var sliders = [
    bindSlider('v0', function () { return state.v0; }, function (x) { state.v0 = x; }, true),
    bindSlider('h', function () { return state.h; }, function (x) { state.h = x; }, true),
    bindSlider('sv0', function () { return state.sv0; }, function (x) { state.sv0 = x; }, true),
    bindSlider('th', function () { return state.th; }, function (x) { state.th = x; }, true),
    bindSlider('tSl', function () { return Math.round(state.t / tTotal() * 1000); }, function (x) { state.t = x / 1000 * tTotal(); state.paused = true; state.wait = 0; syncUI(); }, false)
  ];
  SHOWS.forEach(function (k) {
    var el = $('show-' + k);
    el.addEventListener('change', function () { state.show[k] = el.checked; if (el.checked && (k === 'fall' || k === 'uniform')) rethrow(); Analytics.track(NAME, '显示', k); });
  });
  $('multi').addEventListener('change', function () { state.multi = $('multi').checked; rethrow(); Analytics.track(NAME, '多个初速度', String(state.multi)); });
  $('far').addEventListener('change', function () { state.sshow.far = $('far').checked; });
  $('svel').addEventListener('change', function () { state.sshow.vel = $('svel').checked; });
  function togglePause() {
    if (state.paused && state.t >= tTotal() - 1e-9) rethrow();
    state.paused = !state.paused; syncUI();
  }
  qa('.pause').forEach(function (b) { b.addEventListener('click', togglePause); });
  qa('.rethrow').forEach(function (b) { b.addEventListener('click', function () { rethrow(); state.paused = false; syncUI(); Analytics.track(NAME, '重新抛出', state.scene); }); });

  // ---------- 画布：拖动小球沿轨迹移动 ----------
  var drag = false;
  function local(e) { var r = cv.getBoundingClientRect(); return { x: e.clientX - r.left, y: e.clientY - r.top }; }
  function scrubTo(p) {
    var gm = view.geo(); if (!gm || !gm.fr) return;
    var w = gm.fr.w(p.x, p.y), v0 = state.scene === 'throw' ? state.v0 : state.sv0, O = gm.O, gg = g(), T = tTotal();
    // 在轨迹上找离指针最近的点
    var best = 0, bd = Infinity;
    for (var i = 0; i <= 200; i++) {
      var t = T * i / 200, x = O.x + v0 * t, y = O.y - gg * t * t / 2, d = Math.hypot(x - w.x, y - w.y);
      if (d < bd) { bd = d; best = t; }
    }
    state.t = best; state.wait = 0;
  }
  cv.addEventListener('pointerdown', function (e) {
    if (e.button !== 0 || state.scene === 'quiz') return;
    drag = true; state.paused = true; syncUI();
    try { cv.setPointerCapture(e.pointerId); } catch (err) { /* 合成事件 */ }
    Analytics.track(NAME, '拖动', state.scene);
    scrubTo(local(e));
  });
  cv.addEventListener('pointermove', function (e) {
    if (drag) { scrubTo(local(e)); return; }
    cv.style.cursor = state.scene === 'quiz' ? '' : 'grab';
  });
  function endDrag(e) {
    if (!drag) return;
    drag = false;
    if (cv.hasPointerCapture(e.pointerId)) cv.releasePointerCapture(e.pointerId);
  }
  cv.addEventListener('pointerup', endDrag);
  cv.addEventListener('pointercancel', endDrag);

  // ---------- 练习 ----------
  function newQuiz() {
    state.quiz = P.quiz(Math.random, state.quiz && state.quiz.id, state.quizOnly);
    state.answered = false; state.choice = null;
    var box = $('quizOpts');
    box.innerHTML = '';
    state.quiz.options.forEach(function (o) {
      var b = document.createElement('button');
      b.className = 'small';
      b.textContent = o;
      b.addEventListener('click', function () { answer(o); });
      box.appendChild(b);
    });
    syncUI();
  }
  function answer(o) {
    if (state.answered) return;
    state.answered = true;
    state.choice = o;
    state.correct = o === state.quiz.answer;
    state.score.n++; if (state.correct) state.score.ok++;
    Analytics.track(NAME, '练习', state.quiz.type + (state.correct ? ' 对' : ' 错'));
    syncUI();
  }
  $('nextQ').addEventListener('click', newQuiz);
  // 把题目的条件搬到模型里
  $('showQ').addEventListener('click', function () {
    var q = state.quiz;
    state.grav = 'ten';
    SHOWS.forEach(function (k) { state.show[k] = false; });
    state.show.vel = true;
    if (q.type === 'time') { state.h = q.a.h; state.v0 = q.a.v || q.b.v; state.show.strobe = true; state.show.fall = true; }
    else if (q.type === 'calc') { state.h = q.h; state.v0 = q.v0; }
    else if (q.type === 'grid') { state.h = 1.8; state.v0 = q.v0; state.show.strobe = true; state.show.uniform = true; state.show.fall = true; }
    else { state.v0 = q.sub === 'v' ? q.v0 : 10; state.h = 20; state.show.disp = true; state.show.ext = q.sub === 'rel'; }
    state.h = P.clamp(state.h, P.H_RANGE[0], P.H_RANGE[1]); state.v0 = P.clamp(state.v0, P.V_RANGE[0], P.V_RANGE[1]);
    setScene('throw');
    if (q.type === 'angle') {
      // v0 被滑块范围截断时按比例缩短时间，保持 gt/v0 即速度方向不变
      var t = q.sub === 'v' ? q.t * state.v0 / q.v0 : 2 * state.v0 * Math.tan(q.alpha * DEG) / 10;
      state.t = Math.min(t, tTotal()); state.paused = true; syncUI();
    }
  });

  // ---------- 面板 ----------
  $('panelToggle').addEventListener('click', function () { panel.classList.toggle('collapsed'); });
  if (window.matchMedia('(max-width: 760px)').matches) panel.classList.add('collapsed');
  window.addEventListener('keydown', function (e) {
    var tg = e.target.tagName;
    if (tg === 'INPUT' || tg === 'SELECT' || tg === 'BUTTON' || tg === 'TEXTAREA') return;
    if (e.code === 'Space' && state.scene !== 'quiz') { e.preventDefault(); togglePause(); }
  });

  function syncUI() {
    var sc = state.scene;
    setSeg('scene', sc);
    qa('[data-for]').forEach(function (el) { el.hidden = el.dataset.for.split(' ').indexOf(sc) < 0; });
    qa('[data-mode-for]').forEach(function (el) { el.hidden = el.dataset.modeFor !== state.mode; });
    $('hint').textContent = HINTS[sc];
    setSeg('grav', state.grav);
    setSeg('slow', state.slow);
    setSeg('mode', state.mode);
    SHOWS.forEach(function (k) { $('show-' + k).checked = state.show[k]; });
    $('multi').checked = state.multi; $('far').checked = state.sshow.far; $('svel').checked = state.sshow.vel;
    qa('.pause').forEach(function (b) { b.textContent = state.paused ? '▶ 继续' : '❚❚ 暂停'; });
    var q = state.quiz;
    if (q) {
      $('quizQ').textContent = q.prompt;
      qa('#quizOpts button').forEach(function (b) {
        b.disabled = state.answered;
        b.classList.toggle('on', state.answered && b.textContent === q.answer);
        b.classList.toggle('no', state.answered && b.textContent === state.choice && !state.correct);
      });
      $('quizMsg').innerHTML = !state.answered ? ''
        : '<b class="' + (state.correct ? 'ok">✓ 答对了' : 'bad">✗ 应选「' + q.answer + '」') + '</b>' + q.explain;
      $('nextQ').textContent = state.answered ? '下一题 →' : '换一题';
      $('showQ').hidden = !state.answered;
    }
  }

  // ---------- 读数 ----------
  var lastText = {};
  function setText(id, s) { if (lastText[id] !== s) { lastText[id] = s; $(id).textContent = s; } }
  function rows(list) {
    for (var k = 1; k <= 5; k++) {
      var r = list[k - 1] || ['', ''];
      setText('d' + k, r[0]); setText('r' + k, r[1]);
      $('d' + k).hidden = $('r' + k).hidden = !r[0];
    }
  }

  function readThrow(T, step) {
    var gg = g(), st = P.at(state.v0, gg, state.t), landed = state.t >= T - 1e-9, sh = state.show;
    setText('rName', 't = ' + state.t.toFixed(2) + ' s');
    setText('rKind', landed ? '落地' : state.t === 0 ? '抛出' : '空中');
    var tip;
    if (sh.fall && sh.uniform) tip = '平抛小球总在自由落体小球的同一高度、匀速小球的正上方：平抛 = 水平匀速直线运动 + 竖直自由落体运动。';
    else if (sh.fall) tip = '平抛小球和自由落体小球总在同一高度、同时落地：竖直方向是自由落体运动，与水平速度无关。';
    else if (sh.uniform) tip = '平抛小球总在匀速小球的正上方，落地时恰好砸中它：水平方向是匀速直线运动。';
    else if (sh.ext) tip = '速度的反向延长线过水平位移的中点 x/2，所以 tanθ = 2tanα。';
    else if (sh.strobe) tip = '频闪像：相等时间内水平间距相等；竖直间距之比 1 : 3 : 5 : …，相邻差值恒为 gT²。';
    else tip = '平抛运动是加速度为 g 的匀变速曲线运动：水平速度不变，竖直速度均匀增大。';
    setText('rTip', tip);
    var list = [
      ['位置', 'x = v0t = ' + f(st.x) + ' m，y = ½gt² = ' + f(st.drop) + ' m'],
      ['速度', 'vx = ' + f(st.vx) + '，vy = gt = ' + f(st.vy) + '，v = ' + f(st.v) + ' m/s'],
      ['方向', state.t > 0 ? 'θ = ' + P.deg(st.theta) + '，α = ' + P.deg(st.alpha) + '（tanθ = ' + f(Math.tan(st.theta), 3) + ' = 2tanα）' : '水平'],
      ['落地', 't = √(2h/g) = ' + f(T) + ' s，x = ' + f(P.range(state.v0, state.h, gg)) + ' m，v = ' + f(Math.hypot(state.v0, gg * T)) + ' m/s']
    ];
    if (sh.strobe) {
      var n = Math.floor(state.t / step + 1e-9), dys = [];
      for (var i = 1; i <= Math.min(n, 4); i++) dys.push(f(gg * step * step / 2 * (2 * i - 1), 3));
      list.push(['频闪', n >= 2 ? 'Δx = ' + f(state.v0 * step, 3) + ' m，Δy = ' + dys.join('、') + (n > 4 ? '…' : '') + ' m，差 gT² = ' + f(gg * step * step, 3) + ' m'
        : '每 ' + f(step) + ' s 拍一次，Δx = ' + f(state.v0 * step, 3) + ' m']);
    }
    rows(list);
  }

  function readSlope() {
    var th = state.th * DEG, gg = g(), v0 = state.sv0;
    if (state.mode === 'land') {
      var r = P.onSlope(v0, th, gg), t = Math.min(state.t, r.t), st = P.at(v0, gg, t);
      setText('rName', 't = ' + t.toFixed(2) + ' s');
      setText('rKind', t >= r.t - 1e-9 ? '落到斜面' : '空中');
      setText('rTip', state.multi ? '初速度不同，落到斜面时速度方向却都相同（彼此平行）：tanφ = 2tanθ，与 v0 无关。'
        : '落到斜面上时位移方向沿斜面：tanθ = y/x = gt/(2v0)，所以 t = 2v0tanθ/g。');
      rows([
        ['时间', 't = 2v0tanθ/g = ' + f(r.t) + ' s'],
        ['落点', 'x = ' + f(r.x) + ' m，y = ' + f(r.drop) + ' m，沿斜面 ' + f(r.L) + ' m'],
        ['落地速度', 'v = ' + f(r.v) + ' m/s，φ = ' + P.deg(r.phi) + '（tanφ = 2tanθ）'],
        ['与斜面', '速度与斜面夹角 φ − θ = ' + P.deg(r.rel) + '，与 v0 无关'],
        ['最远', 't/2 = ' + f(r.tFar) + ' s 时速度平行于斜面，H = ' + f(r.far) + ' m']
      ]);
      return;
    }
    var p = P.perpHit(v0, th, gg), tp = Math.min(state.t, p.t), sp = P.at(v0, gg, tp);
    setText('rName', 't = ' + tp.toFixed(2) + ' s');
    setText('rKind', tp >= p.t - 1e-9 ? '垂直撞上斜面' : '空中');
    setText('rTip', '垂直撞到斜面时，速度与竖直方向的夹角等于斜面倾角 θ：tanθ = vx/vy = v0/(gt)。');
    rows([
      ['时间', 't = v0/(g·tanθ) = ' + f(p.t) + ' s'],
      ['撞击点', 'x = ' + f(p.x) + ' m，下落 y = ' + f(p.drop) + ' m'],
      ['撞击速度', 'v = v0/sinθ = ' + f(p.v) + ' m/s，vy = ' + f(gg * p.t) + ' m/s'],
      ['位移之比', 'x : y = 2tanθ = ' + f(p.ratio, 3)],
      ['当前', 'vx = ' + f(sp.vx) + '，vy = ' + f(sp.vy) + ' m/s']
    ]);
  }

  function readQuiz() {
    var q = state.quiz, sc = state.score;
    setText('rName', !state.answered ? '判断练习' : state.correct ? '✓ 答对了' : '✗ 答错了');
    $('rName').className = !state.answered ? '' : state.correct ? 'ok' : 'bad';
    setText('rKind', '得分 ' + sc.ok + ' / ' + sc.n);
    setText('rTip', state.answered ? q.explain : q.prompt);
    rows([]);
  }

  // ---------- 尺寸与主循环 ----------
  function resize() { view.resize(stage.clientWidth, stage.clientHeight); }
  new ResizeObserver(resize).observe(stage);

  // 支持 ?scene=throw|slope|quiz；&v0=（m/s）、&h=（m）、&g=earth|ten|moon、&t=（s，暂停在该时刻）、&slow=1|0.5|0.25；
  // 显示 &show=strobe,fall,uniform,vel,disp,ext（逗号分隔）；斜面 &mode=land|perp、&th=15~60、&multi=1、&far=1；练习 &q=time|calc|grid|angle
  var qs = new URLSearchParams(location.search);
  function num(k, lo, hi) { var x = parseFloat(qs.get(k)); return isFinite(x) && x >= lo && x <= hi ? x : null; }
  var x;
  if (HINTS[qs.get('scene')]) state.scene = qs.get('scene');
  if ((x = num('v0', P.V_RANGE[0], P.V_RANGE[1])) != null) { state.v0 = x; state.sv0 = x; }
  if ((x = num('h', P.H_RANGE[0], P.H_RANGE[1])) != null) state.h = x;
  if (P.GRAV[qs.get('g')]) state.grav = qs.get('g');
  if ([1, 0.5, 0.25].indexOf(parseFloat(qs.get('slow'))) >= 0) state.slow = parseFloat(qs.get('slow'));
  if (qs.get('show') != null) {
    var want = qs.get('show').split(',');
    SHOWS.forEach(function (k) { state.show[k] = want.indexOf(k) >= 0; });
  }
  if (qs.get('mode') === 'land' || qs.get('mode') === 'perp') state.mode = qs.get('mode');
  if ((x = num('th', P.TH_RANGE[0], P.TH_RANGE[1])) != null) state.th = x;
  if (qs.get('multi') === '1') state.multi = true;
  if (qs.get('far') === '1') state.sshow.far = true;
  if (P.TYPES.indexOf(qs.get('q')) >= 0) state.quizOnly = qs.get('q');

  resize();
  setScene(state.scene);
  if ((x = num('t', 0, 100)) != null) { state.t = Math.min(x, tTotal()); state.paused = true; syncUI(); }

  var lastT = performance.now();
  function frame(now) {
    var dt = Math.min((now - lastT) / 1000, 0.1);
    lastT = now;
    var sc = state.scene, T = sc === 'quiz' ? 0 : tTotal();
    if (sc !== 'quiz') {
      if (state.t > T) state.t = T;
      if (!state.paused) {
        if (state.t < T) state.t = Math.min(T, state.t + dt * state.slow);
        else { state.wait += dt; if (state.wait > 1.4) rethrow(); }
      }
    }
    sliders.forEach(function (s) { if (document.activeElement !== s.el) s.el.value = s.get(); });
    setText('v0Out', state.v0.toFixed(1) + ' m/s');
    setText('hOut', state.h.toFixed(state.h < 10 ? 2 : 1) + ' m');
    setText('sv0Out', state.sv0.toFixed(1) + ' m/s');
    setText('thOut', state.th.toFixed(0) + '°');
    setText('tOut', state.t.toFixed(2) + ' s');

    if (sc === 'throw') {
      var step = P.strobeStep(T);
      view.drawThrow({ v0: state.v0, h: state.h, g: g(), gName: gName(), t: state.t, tLand: T, step: step, show: state.show });
      readThrow(T, step);
    } else if (sc === 'slope') {
      view.drawSlope({ mode: state.mode, v0: state.sv0, th: state.th * DEG, g: g(), gName: gName(), t: state.t, cmp: state.multi && state.mode === 'land', show: state.sshow });
      readSlope();
    } else {
      view.drawQuiz(state.quiz, state.answered, { quizH: $('quizBar').offsetHeight });
      readQuiz();
    }
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // 调试用
  window.__model = {
    state: state, setScene: setScene, newQuiz: newQuiz, syncUI: syncUI, rethrow: rethrow,
    setV0: function (v) { state.v0 = P.clamp(v, P.V_RANGE[0], P.V_RANGE[1]); rethrow(); },
    setH: function (h) { state.h = P.clamp(h, P.H_RANGE[0], P.H_RANGE[1]); rethrow(); },
    setT: function (t) { state.t = Math.min(t, tTotal()); state.paused = true; syncUI(); }
  };
})();
