// 平抛运动的计算：位置、速度、方向角，落地时间与水平射程，斜面上的平抛，频闪间隔，练习题
// 世界坐标 x 右、y 上，单位 m、s、m/s。场景一抛出点在 (0, h)、地面 y = 0；场景二抛出点在原点
// 不计空气阻力；竖直方向的“下落高度”drop 与竖直分速度 vy 都取向下为正
(function () {
  var DEG = Math.PI / 180;
  var GRAV = { earth: { g: 9.8, name: '地球 g = 9.8' }, ten: { g: 10, name: '取 g = 10' }, moon: { g: 1.63, name: '月球 g = 1.63' } };
  var V_RANGE = [0.5, 12], H_RANGE = [0.2, 20], TH_RANGE = [15, 60];

  function clamp(x, a, b) { return Math.max(a, Math.min(b, x)); }

  // ---------- 平抛 ----------
  function landTime(h, g) { return Math.sqrt(2 * h / g); }
  function range(v0, h, g) { return v0 * landTime(h, g); }
  // t 时刻的运动状态（相对抛出点）
  function at(v0, g, t) {
    var x = v0 * t, drop = g * t * t / 2, vy = g * t, v = Math.hypot(v0, vy);
    return {
      t: t, x: x, drop: drop, s: Math.hypot(x, drop), vx: v0, vy: vy, v: v,
      theta: Math.atan2(vy, v0),          // 速度与水平方向的夹角
      alpha: t > 0 ? Math.atan2(drop, x) : 0  // 位移与水平方向的夹角
    };
  }
  // 轨迹方程 y = g x² / (2 v0²)（下落高度）
  function dropAtX(v0, g, x) { return g * x * x / (2 * v0 * v0); }

  // 频闪间隔：使整个下落过程拍到不超过 14 张
  var STEPS = [0.02, 0.05, 0.1, 0.2, 0.25, 0.5, 1];
  function strobeStep(tTotal) {
    for (var i = 0; i < STEPS.length; i++) if (tTotal / STEPS[i] <= 14) return STEPS[i];
    return STEPS[STEPS.length - 1];
  }
  // 不小于 x 的“整”数：1、1.2、1.5、2、2.5、3、4、5、6、8 × 10ⁿ（画面范围随参数分档变化，不会连续缩放）
  function niceCeil(x) {
    var p = Math.pow(10, Math.floor(Math.log10(x))), m = x / p;
    var ks = [1, 1.2, 1.5, 2, 2.5, 3, 4, 5, 6, 8, 10];
    for (var i = 0; i < ks.length; i++) if (m <= ks[i] + 1e-9) return ks[i] * p;
    return 10 * p;
  }
  // 网格间距：让 span 分成约 n 格
  function gridStep(span, n) {
    var raw = span / (n || 8), p = Math.pow(10, Math.floor(Math.log10(raw))), m = raw / p;
    return (m < 1.5 ? 1 : m < 3.5 ? 2 : m < 7.5 ? 5 : 10) * p;
  }

  // ---------- 斜面上的平抛 ----------
  // 从倾角 θ 的斜面顶端水平抛出、落回斜面：tanθ = (gt²/2)/(v0 t) ⇒ t = 2v0 tanθ / g
  function onSlope(v0, th, g) {
    var tn = Math.tan(th), t = 2 * v0 * tn / g, x = v0 * t, drop = g * t * t / 2;
    var phi = Math.atan(2 * tn);
    return {
      t: t, x: x, drop: drop, L: x / Math.cos(th),
      phi: phi,                  // 落到斜面时速度与水平方向的夹角，tanφ = 2tanθ，与 v0 无关
      rel: phi - th,             // 速度与斜面的夹角
      v: v0 * Math.sqrt(1 + 4 * tn * tn),
      tFar: t / 2,               // 速度与斜面平行时离斜面最远
      far: Math.pow(v0 * Math.sin(th), 2) / (2 * g * Math.cos(th))
    };
  }
  // 水平抛出后垂直撞在倾角 θ 的斜面上：速度与水平夹角 90° − θ ⇒ tan(90° − θ) = gt/v0 ⇒ t = v0 / (g tanθ)
  function perpHit(v0, th, g) {
    var t = v0 / (g * Math.tan(th)), x = v0 * t, drop = g * t * t / 2;
    return { t: t, x: x, drop: drop, v: v0 / Math.sin(th), ratio: x / drop };  // 水平位移 : 竖直位移 = 2tanθ
  }

  // ---------- 格式 ----------
  function f(x, d) {
    if (d == null) d = Math.abs(x) >= 100 ? 0 : Math.abs(x) >= 10 ? 1 : 2;
    var s = x.toFixed(d);
    return s.indexOf('.') >= 0 ? s.replace(/\.?0+$/, '') : s;
  }
  function deg(a) { return f(a / DEG, 1) + '°'; }

  // ---------- 练习（一律取 g = 10 m/s²） ----------
  var TYPES = ['time', 'calc', 'grid', 'angle'];
  function pick(rand, a) { return a[Math.floor(rand() * a.length)]; }
  function shuffle(rand, a) {
    a = a.slice();
    for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(rand() * (i + 1)), t = a[i]; a[i] = a[j]; a[j] = t; }
    return a;
  }
  function uniq(a) { return a.filter(function (x, i) { return a.indexOf(x) === i; }); }
  function options(rand, answer, pool, n) {
    var rest = shuffle(rand, uniq(pool).filter(function (o) { return o !== answer; })).slice(0, (n || 4) - 1);
    return shuffle(rand, rest.concat([answer]));
  }
  // 高度 h（m）与落地时间 t（s），g = 10
  var HT = [[0.8, 0.4], [1.25, 0.5], [1.8, 0.6], [3.2, 0.8], [5, 1], [7.2, 1.2], [11.25, 1.5], [20, 2], [45, 3]];

  // 比较两个物体的落地时间 / 水平位移
  function quizTime(rand) {
    var a = pick(rand, HT), b = pick(rand, HT), va = pick(rand, [2, 3, 4, 5, 6]), vb = pick(rand, [2, 3, 4, 5, 6]);
    if (rand() < 0.4) b = a;
    if (rand() < 0.3 && b === a) vb = 0;  // B 由静止释放（自由落体）
    if (b === a && vb === va) vb = va === 6 ? 2 : va + 1;
    var desc = function (n, hh, v) { return n + ' 从 ' + f(hh[0], 2) + ' m 高处' + (v ? '以 ' + v + ' m/s 水平抛出' : '由静止释放'); };
    var prompt = desc('A', a, va) + '，' + desc('B', b, vb) + '（不计空气阻力）。';
    var ans, opts, explain, what;
    if (rand() < 0.6 || !vb) {
      what = 'first';
      ans = a[1] === b[1] ? '同时落地' : a[1] < b[1] ? 'A 先落地' : 'B 先落地';
      opts = ['A 先落地', 'B 先落地', '同时落地', '无法确定'];
      prompt += '哪个先落地？';
      explain = '平抛运动的竖直分运动是自由落体运动，落地时间 t = √(2h/g) 只由高度决定，与水平初速度无关：t_A = ' + f(a[1]) + ' s，t_B = ' + f(b[1]) + ' s，' + ans + '。';
    } else {
      what = 'x';
      var xa = va * a[1], xb = vb * b[1];
      ans = simplify(xa + ' : ' + xb);
      opts = options(rand, ans, [va + ' : ' + vb, a[1] + ' : ' + b[1], '1 : 1', '1 : 2', '2 : 1', '3 : 2', '2 : 3', '1 : 3'].map(simplify));
      prompt += '水平位移之比 x_A : x_B = ？';
      explain = 'x = v0·t，t = √(2h/g)：t_A = ' + f(a[1]) + ' s，x_A = ' + f(xa) + ' m；t_B = ' + f(b[1]) + ' s，x_B = ' + f(xb) + ' m，所以 x_A : x_B = ' + ans + '。水平射程由初速度和高度共同决定。';
    }
    return { type: 'time', what: what, a: { h: a[0], t: a[1], v: va }, b: { h: b[0], t: b[1], v: vb }, answer: ans, options: opts, prompt: prompt, explain: explain };
  }
  function gcd(a, b) { a = Math.abs(a); b = Math.abs(b); while (b) { var t = a % b; a = b; b = t; } return a || 1; }
  function simplify(s) {
    var p = s.split(' : ').map(Number), g = gcd(Math.round(p[0] * 100), Math.round(p[1] * 100));
    return Math.round(p[0] * 100) / g + ' : ' + Math.round(p[1] * 100) / g;
  }

  // 已知高度和初速度，求时间 / 水平位移 / 落地速度
  // 落地速度用勾股数：v0 与 vy = gt 组成整数斜边
  var TRIPLES = [[3, 0.4, 5], [8, 0.6, 10], [6, 0.8, 10], [12, 0.5, 13], [15, 2, 25], [5, 1.2, 13], [9, 1.2, 15], [16, 1.2, 20]];
  function quizCalc(rand) {
    var what = pick(rand, ['t', 'x', 'v']), h, t, v0, ans, pool, explain;
    if (what === 'v') {
      var tr = pick(rand, TRIPLES); v0 = tr[0]; t = tr[1]; h = 5 * t * t;
      var vy = 10 * t;
      ans = tr[2] + ' m/s';
      pool = [v0 + vy, Math.round(Math.sqrt(v0 * v0 + 10 * h)), vy, v0, tr[2] * 2, Math.round(Math.sqrt(2 * 10 * h))].map(function (x) { return f(x) + ' m/s'; });
      explain = '竖直分速度 vy = gt，t = √(2h/g) = ' + f(t) + ' s，vy = ' + f(vy) + ' m/s；落地速度 v = √(v0² + vy²) = √(' + v0 + '² + ' + f(vy) + '²) = ' + tr[2] + ' m/s。不能把两个分速度直接相加。';
    } else {
      var ht = pick(rand, HT.slice(0, 8)); h = ht[0]; t = ht[1]; v0 = pick(rand, [2, 3, 4, 5, 6, 8, 10]);
      if (what === 't') {
        ans = f(t) + ' s';
        pool = [t * 2, Math.sqrt(h / 10), h / v0, t / 2, Math.sqrt(2 * h)].map(function (x) { return f(x) + ' s'; });
        explain = '竖直方向是自由落体：h = ½gt²，t = √(2h/g) = √(2 × ' + f(h, 2) + ' / 10) = ' + f(t) + ' s，与初速度 ' + v0 + ' m/s 无关。';
      } else {
        ans = f(v0 * t) + ' m';
        pool = [v0 * t * 2, v0 * t / 2, v0 * Math.sqrt(h / 10), h, v0 * h / 5].map(function (x) { return f(x) + ' m'; });
        explain = '先由 h = ½gt² 求时间 t = ' + f(t) + ' s，水平方向匀速直线运动：x = v0·t = ' + v0 + ' × ' + f(t) + ' = ' + f(v0 * t) + ' m。';
      }
    }
    return { type: 'calc', what: what, h: h, t: t, v0: v0, answer: ans, options: options(rand, ans, pool),
      prompt: '小球从 ' + f(h, 2) + ' m 高处以 ' + v0 + ' m/s 的速度水平抛出，g 取 10 m/s²，' + { t: '它在空中运动的时间是？', x: '落地点与抛出点的水平距离是？', v: '落地时的速度大小是？' }[what],
      explain: explain };
  }

  // 方格纸上的频闪照片：方格边长 5 cm，相邻两点 Δy₂ − Δy₁ = 2 格 = gT² ⇒ T = 0.1 s
  function quizGrid(rand) {
    var L = 0.05, T = 0.1, m = pick(rand, [2, 3, 4, 5]), k = pick(rand, [1, 3, 5]), what = rand() < 0.6 ? 'v0' : 'vb';
    // a、b、c 三点：水平各隔 m 格，竖直分别隔 k、k+2 格（k = 1 时 a 为抛出点）
    var ans, pool, explain, v0 = m * L / T, vb = (2 * k + 2) * L / (2 * T);
    var pre = '竖直方向：Δy = y_bc − y_ab = ' + (k + 2) + ' 格 − ' + k + ' 格 = 2 格 = 0.1 m，由 Δy = gT² 得 T = √(Δy/g) = 0.1 s。';
    if (what === 'v0') {
      ans = f(v0) + ' m/s';
      pool = [v0 * 2, v0 / 2, m * L, v0 + 0.5, v0 - 0.5, 1, 1.5, 2, 2.5].filter(function (x) { return x > 0; }).map(function (x) { return f(x) + ' m/s'; });
      explain = pre + '水平方向：x = ' + m + ' 格 = ' + f(m * L) + ' m，v0 = x/T = ' + f(v0) + ' m/s。';
    } else {
      ans = f(vb) + ' m/s';
      pool = [vb * 2, vb / 2, Math.hypot(vb, v0), v0, vb + 0.5, 1, 2, 3].map(function (x) { return f(x) + ' m/s'; });
      explain = pre + 'b 点的竖直分速度等于 a 到 c 竖直方向的平均速度：vby = (' + k + ' + ' + (k + 2) + ') 格 / 2T = ' + f((2 * k + 2) * L) + ' m / 0.2 s = ' + f(vb) + ' m/s。';
    }
    explain += k === 1 ? '竖直间隔之比 1 : 3，a 点恰是抛出点。' : 'a 点竖直方向已有速度（间隔之比不是 1 : 3），a 不是抛出点。';
    return { type: 'grid', what: what, m: m, k: k, L: L, T: T, v0: v0, vb: vb, answer: ans, options: options(rand, ans, pool),
      prompt: '用方格纸（每格边长 5 cm）记录平抛小球的频闪照片，a、b、c 为相邻三次闪光时的位置，g 取 10 m/s²。' + (what === 'v0' ? '小球的初速度 v0 = ？' : '小球经过 b 点时竖直分速度 vby = ？'),
      explain: explain };
  }

  // 速度方向 / 位移方向（sin37° = 0.6）
  var TANS = [[1, 45], [0.75, 37], [4 / 3, 53]];
  var VT = { 45: [[10, 1], [5, 0.5], [20, 2], [8, 0.8]], 37: [[4, 0.3], [8, 0.6], [16, 1.2], [20, 1.5]], 53: [[3, 0.4], [6, 0.8], [9, 1.2], [15, 2]] };
  function quizAngle(rand) {
    var sub = rand() < 0.65 ? 'v' : 'rel';
    if (sub === 'rel') {
      var a0 = pick(rand, [30, 37, 45]);
      var tv = { 30: '2√3/3', 37: '3/2', 45: '2' }[a0];
      var ans1 = tv;
      return { type: 'angle', sub: 'rel', alpha: a0, answer: ans1, options: options(rand, ans1, ['1', '√2', '1/2', '2', '3/2', '√3', '2√3/3', '3/4', '4/3']),
        prompt: '平抛运动中，某时刻小球的位移方向与水平方向成 ' + a0 + '°' + (a0 === 37 ? '（tan37° = 0.75）' : '') + '，此时速度方向与水平方向夹角 θ 的正切 tanθ = ？',
        explain: 'tanθ = vy/v0 = gt/v0，tanα = (½gt²)/(v0t) = gt/(2v0)，所以 tanθ = 2tanα = 2 × tan' + a0 + '° = ' + ans1 + '。这也说明速度的反向延长线一定过水平位移的中点。' };
    }
    var tn = pick(rand, TANS), vt = pick(rand, VT[tn[1]]);
    var ans = tn[1] + '°';
    return { type: 'angle', sub: 'v', v0: vt[0], t: vt[1], ang: tn[1], answer: ans, options: options(rand, ans, ['30°', '37°', '45°', '53°', '60°']),
      prompt: '小球以 ' + vt[0] + ' m/s 的速度水平抛出，g 取 10 m/s²（sin37° = 0.6），经过 ' + f(vt[1]) + ' s，速度方向与水平方向的夹角是？',
      explain: 'vy = gt = ' + f(10 * vt[1]) + ' m/s，tanθ = vy/v0 = ' + f(10 * vt[1]) + '/' + vt[0] + ' = ' + f(tn[0], 2) + '，θ = ' + ans + '。注意不是位移方向：位移与水平方向夹角的正切只有它的一半。' };
  }

  function quiz(rand, avoid, only) {
    var gen = { time: quizTime, calc: quizCalc, grid: quizGrid, angle: quizAngle }, q;
    for (var i = 0; i < 10; i++) {
      q = gen[only && gen[only] ? only : pick(rand, TYPES)](rand);
      q.id = q.type + '|' + q.prompt;
      if (q.id !== avoid && q.options.indexOf(q.answer) >= 0) break;
    }
    return q;
  }

  window.Proj = {
    DEG: DEG, GRAV: GRAV, V_RANGE: V_RANGE, H_RANGE: H_RANGE, TH_RANGE: TH_RANGE, TYPES: TYPES,
    clamp: clamp, landTime: landTime, range: range, at: at, dropAtX: dropAtX,
    strobeStep: strobeStep, niceCeil: niceCeil, gridStep: gridStep,
    onSlope: onSlope, perpHit: perpHit,
    f: f, deg: deg, quiz: quiz
  };
})();
