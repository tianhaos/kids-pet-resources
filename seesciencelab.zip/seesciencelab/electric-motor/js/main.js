(function () {
  var M = window.Motor, Dr = window.MotorDraw, MO = M.MOTOR, DEG = M.DEG;
  var $ = function (id) { return document.getElementById(id); };
  var qa = function (sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); };
  var NAME = '电动机原理';

  var state = {
    scene: 'motor',
    wire: { x: 0, v: 0, pol: 1, nTop: true, closed: false }, rec: [], recKey: '',
    th: 0, w: 0, wAvg: 0, I: 1.5, b: 1, pol: 1, mag: 1, comm: 'split', on: true,
    field: true, force: true, current: true, labels: true, end: true, slow: false, phase: 0,
    quiz: null, quizOnly: null, answered: false, correct: false, choice: null, score: { n: 0, ok: 0 }
  };
  var HINTS = {
    wire: '拖动旋转、滚轮或双指缩放；闭合开关看导体 AB 怎样运动',
    motor: '拖动旋转、滚轮或双指缩放；勾选“慢放”看换向器怎样换向',
    quiz: '电动机原理 · 判断练习'
  };

  var stage = $('stage'), panel = $('panel'), ev = $('endView'), ectx = ev.getContext('2d');
  var sc3 = null;
  try { sc3 = window.MotorScene(stage); } catch (e) { sc3 = null; }
  function setSeg(attr, val) { qa('[data-' + attr + ']').forEach(function (b) { b.classList.toggle('on', b.dataset[attr] === String(val)); }); }

  // ---------- 场景 ----------
  qa('[data-scene]').forEach(function (b) {
    b.addEventListener('click', function () { setScene(b.dataset.scene); Analytics.track(NAME, '场景', b.textContent); });
  });
  function setScene(s) {
    state.scene = s;
    if (s === 'quiz' && !state.quiz) newQuiz();
    syncUI();
  }
  // 练习里“如图装置”用的是导线场景
  function view() {
    if (state.scene !== 'quiz') return state.scene;
    return state.quiz && state.quiz.type === 'dir' ? 'wire' : 'motor';
  }

  // ---------- 场景一：通电导线 ----------
  var W = state.wire;
  function toggleSwitch(on) {
    W.closed = on == null ? !W.closed : on;
    syncUI(); Analytics.track(NAME, '开关', W.closed ? '闭合' : '断开');
  }
  function resetRod() { W.x = 0; W.v = 0; state.recKey = ''; }
  $('wSwitch').addEventListener('click', function () { toggleSwitch(); });
  $('wPol').addEventListener('click', function () { W.pol = -W.pol; W.closed = false; resetRod(); syncUI(); Analytics.track(NAME, '导线', '对调电源'); });
  $('wMag').addEventListener('click', function () { W.nTop = !W.nTop; W.closed = false; resetRod(); syncUI(); Analytics.track(NAME, '导线', '对调磁极'); });
  $('wReset').addEventListener('click', function () { W.closed = false; resetRod(); syncUI(); Analytics.track(NAME, '导线', '放回中间'); });
  function curName(pol) { return pol > 0 ? 'A → B' : 'B → A'; }
  function magName(nTop) { return nTop ? '向下（N 上 S 下）' : '向上（S 上 N 下）'; }
  function moveName(d) { return d < 0 ? '向左' : d > 0 ? '向右' : '不动'; }
  // 开关闭合、导体开始运动时记一行；同一组合只记一次
  function record() {
    var d = M.wireDir(W.pol, W.nTop, true), k = W.pol + '|' + W.nTop;
    if (state.recKey === k) return;
    state.recKey = k;
    if (state.rec.some(function (r) { return r.k === k; })) return;
    state.rec.push({ k: k, pol: W.pol, nTop: W.nTop, d: d });
    Analytics.track(NAME, '记录', String(state.rec.length));
    recTable();
  }
  function recTable() {
    var rows = state.rec.map(function (r, i) {
      return '<tr class="done"><td>' + (i + 1) + '</td><td>' + curName(r.pol) + '</td><td>' + (r.nTop ? '向下' : '向上') + '</td><td>' + moveName(r.d) + '</td></tr>';
    });
    for (var i = rows.length; i < 4; i++) rows.push('<tr><td>' + (i + 1) + '</td><td>—</td><td>—</td><td>—</td></tr>');
    $('rec').innerHTML = rows.join('');
    $('recNote').textContent = state.rec.length >= 4
      ? '✓ 四种组合都做过了：只改变电流方向或只改变磁感线方向，运动方向相反；两个同时改变，运动方向不变。通电导线受力的方向跟电流方向、磁感线方向都有关。'
      : '还差 ' + (4 - state.rec.length) + ' 种组合。提示：对调电源正负极、对调磁极，或两个都对调。';
  }

  // ---------- 场景二：直流电动机 ----------
  qa('[data-comm]').forEach(function (b) {
    b.addEventListener('click', function () { state.comm = b.dataset.comm; syncUI(); Analytics.track(NAME, '换向器', b.textContent); });
  });
  $('cur').addEventListener('input', function () { state.I = +$('cur').value; syncUI(); });
  $('cur').addEventListener('change', function () { Analytics.track(NAME, '电流', state.I.toFixed(1)); });
  qa('[data-b]').forEach(function (b) {
    b.addEventListener('click', function () { state.b = +b.dataset.b; syncUI(); Analytics.track(NAME, '磁性', b.textContent); });
  });
  function toggleOn() { state.on = !state.on; syncUI(); Analytics.track(NAME, '电源', state.on ? '接通' : '断开'); }
  function kick() {
    // 顺着通电后的转向拨（没有转向时按默认方向）
    var dir = -state.pol * state.mag;
    state.w += dir * 2.2;
    Analytics.track(NAME, '拨一下');
  }
  $('mOn').addEventListener('click', toggleOn);
  $('mPol').addEventListener('click', function () { state.pol = -state.pol; syncUI(); Analytics.track(NAME, '电动机', '对调电源'); });
  $('mMag').addEventListener('click', function () { state.mag = -state.mag; syncUI(); Analytics.track(NAME, '电动机', '对调磁极'); });
  $('mKick').addEventListener('click', kick);
  $('mDead').addEventListener('click', function () {
    state.th = 90 * DEG; state.w = 0; state.wAvg = 0; state.comm = 'split'; state.on = true;
    syncUI(); Analytics.track(NAME, '停在平衡位置');
  });

  // 画面下方的快捷按钮（窄屏时面板收起也能操作）
  $('actMain').addEventListener('click', function () { if (view() === 'wire') toggleSwitch(); else toggleOn(); });
  $('actSub').addEventListener('click', function () {
    if (view() === 'wire') { W.closed = false; resetRod(); syncUI(); Analytics.track(NAME, '导线', '放回中间'); } else kick();
  });

  // ---------- 显示 ----------
  ['field', 'force', 'current', 'labels', 'end', 'slow'].forEach(function (k) {
    $(k).addEventListener('change', function () { state[k] = $(k).checked; syncUI(); Analytics.track(NAME, '显示', k + (state[k] ? ' 开' : ' 关')); });
  });
  $('homeBtn').addEventListener('click', function () { if (sc3) sc3.home(); });

  // ---------- 练习 ----------
  function newQuiz() {
    state.quiz = M.quiz(Math.random, state.quiz, state.quizOnly);
    state.answered = false; state.choice = null;
    var q = state.quiz;
    if (q.type === 'dir') { W.pol = q.pol; W.nTop = q.nTop; W.closed = false; resetRod(); }
    var box = $('quizOpts');
    box.innerHTML = '';
    q.options.forEach(function (o) {
      var b = document.createElement('button');
      b.className = 'small';
      b.textContent = o;
      b.dataset.opt = o;
      b.addEventListener('click', function () { answer(o); });
      box.appendChild(b);
    });
    box.className = 'answer' + (q.options.some(function (o) { return o.length > 10; }) ? ' one' : '');
    syncUI();
  }
  function answer(o) {
    if (state.answered) return;
    state.answered = true; state.choice = o;
    state.correct = o === state.quiz.answer;
    state.score.n++; if (state.correct) state.score.ok++;
    Analytics.track(NAME, '练习', state.quiz.type + (state.correct ? ' 对' : ' 错'));
    syncUI();
  }
  $('nextQ').addEventListener('click', newQuiz);
  $('showQ').addEventListener('click', function () {
    var sh = state.quiz.show || {};
    if (sh.scene === 'wire') { W.pol = sh.pol; W.nTop = sh.nTop; resetRod(); W.closed = !!sh.closed; }
    else {
      if (sh.comm) state.comm = sh.comm;
      if (sh.angle != null) { state.th = sh.angle * DEG; state.w = 0; }
      if (sh.rev) state.pol = -state.pol;
      state.on = true;
    }
    Analytics.track(NAME, '练习 → 模型', state.quiz.type);
    setScene(sh.scene || 'motor');
  });

  // ---------- 面板 ----------
  // 窄屏默认收起面板；页面加载时窗口宽度可能还没定下来，第一次在窄屏下布局时也收起一次
  var collapsedOnce = false;
  function autoCollapse() {
    if (collapsedOnce || !window.matchMedia('(max-width: 760px)').matches) return;
    collapsedOnce = true;
    panel.classList.add('collapsed');
  }
  $('panelToggle').addEventListener('click', function () { collapsedOnce = true; panel.classList.toggle('collapsed'); });
  autoCollapse();

  function syncUI() {
    var s = state.scene, v = view();
    readNow = true;
    setSeg('scene', s);
    qa('[data-for]').forEach(function (el) { el.hidden = el.dataset.for.split(' ').indexOf(s) < 0; });
    $('hint').textContent = !sc3 ? '此浏览器不支持 WebGL，无法显示 3D 模型；端视图和练习仍可使用' : HINTS[s];
    setSeg('comm', state.comm); setSeg('b', state.b);
    $('cur').value = state.I; $('curOut').textContent = state.I.toFixed(1) + ' A';
    $('wSwitch').textContent = W.closed ? '断开开关' : '闭合开关';
    $('mOn').textContent = state.on ? '断开电源' : '接通电源';
    ['field', 'force', 'current', 'labels', 'end', 'slow'].forEach(function (k) { $(k).checked = state[k]; });
    $('actBar').hidden = s === 'quiz';
    $('actMain').textContent = v === 'wire' ? (W.closed ? '断开开关' : '闭合开关') : (state.on ? '断开电源' : '接通电源');
    $('actMain').classList.toggle('on', v === 'wire' ? W.closed : state.on);
    $('actSub').textContent = v === 'wire' ? '↺ 放回中间' : '✋ 拨一下';
    ev.hidden = !state.end && !!sc3;
    var q = state.quiz;
    if (q) {
      $('quizQ').textContent = q.prompt;
      qa('#quizOpts button').forEach(function (b) {
        b.disabled = state.answered;
        b.classList.toggle('on', state.answered && b.dataset.opt === q.answer);
        b.classList.toggle('no', state.answered && b.dataset.opt === state.choice && !state.correct);
      });
      $('quizMsg').innerHTML = !state.answered ? ''
        : '<b class="' + (state.correct ? 'ok">✓ 答对了' : 'bad">✗ 应选「' + q.answer + '」') + '</b>' + q.explain;
      $('nextQ').textContent = state.answered ? '下一题 →' : '换一题';
      $('showQ').hidden = !state.answered;
    }
    legend();
  }
  function legend() {
    var html = '<span><i style="background:#e0574f"></i>N 极</span><span><i style="background:#4a78d8"></i>S 极</span>'
      + '<span><i class="ln" style="border-color:#4fc3f7"></i>磁感线</span><span><i class="dot"></i>电流</span><span><i class="ln" style="border-color:#ff7a59"></i>受力 F</span>';
    $('legend').innerHTML = state.scene === 'quiz' ? '' : html;
  }

  // ---------- 读数 ----------
  var lastText = {};
  function setText(id, t, html) { if (lastText[id] !== t) { lastText[id] = t; $(id)[html ? 'innerHTML' : 'textContent'] = t; } }
  function rows(list) {
    for (var k = 1; k <= 6; k++) {
      var r = list[k - 1] || ['', ''];
      setText('d' + k, r[0]); setText('r' + k, r[1], true);
      if ($('d' + k).hidden !== !r[0]) $('d' + k).hidden = $('r' + k).hidden = !r[0];
    }
  }
  function readWire() {
    var f = M.wireDir(W.pol, W.nTop, W.closed), frac = M.fieldFrac(W.x), moving = Math.abs(W.v) > 0.05;
    setText('rName', '通电导线在磁场中');
    $('rName').className = '';
    setText('rKind', W.closed ? '开关闭合' : '开关断开');
    rows([
      ['AB 中电流', W.closed ? curName(W.pol) : '无'],
      ['磁感线', magName(W.nTop)],
      ['AB 受力', !W.closed ? '不受磁场力' : frac < 0.02 ? '不受力（已离开磁场）' : moveName(M.wireDir(W.pol, W.nTop, true)) + (frac < 0.98 ? '（在磁场边缘，较小）' : '')],
      ['AB 运动', moving ? moveName(W.v) + ' ' + Math.abs(W.v).toFixed(1) + ' cm/s' : '静止'],
      ['能量', W.closed && moving && frac > 0.02 ? '电能 → 机械能' : '—']
    ]);
    var tip;
    if (!W.closed) tip = '断开开关时导体中没有电流，磁场对它没有作用力。闭合开关试试。';
    else if (frac < 0.02 && !moving) tip = '导体已经滚出两磁极之间，这里磁场很弱，几乎不受力。点“放回中间”再做一次。';
    else if (f) tip = '通电导线在磁场中受到力的作用：电流 ' + curName(W.pol) + '、磁感线' + (W.nTop ? '向下' : '向上') + '，AB 受力' + moveName(f) + '。';
    else tip = '';
    setText('rTip', tip);
  }
  function readMotor() {
    var s = state.on ? M.abCurrent(state.th, state.pol, state.comm) : 0, B = MO.B_LEVELS[state.b];
    var F = M.sideForce(s, state.I, B, state.mag), pos = M.posInfo(state.th);
    var ang = Math.round(Math.acos(Math.min(1, Math.abs(Math.cos(state.th)))) / DEG);
    var spin = Math.abs(state.wAvg) > 0.15, swing = state.comm === 'ring' && Math.abs(state.w) > 0.05;
    setText('rName', '直流电动机');
    $('rName').className = '';
    setText('rKind', !state.on ? (Math.abs(state.w) > 0.05 ? '断电，惯性转动' : '断电') : state.comm === 'ring' ? (swing ? '来回摆动' : '停在平衡位置') : spin ? '持续转动' : Math.abs(state.w) > 0.05 || s !== 0 ? '起动中' : '不转');
    var up = function (f) { return f > 0 ? '向上' : '向下'; };
    rows([
      ['线圈位置', pos.key === 'eq' ? '平衡位置（与磁感线垂直）' : '线圈平面与磁感线成 ' + ang + '°'],
      ['ab 中电流', !state.on ? '无（电源断开）' : s === 0 ? '无（电刷在绝缘缝上）' : s < 0 ? 'a → b' : 'b → a'],
      ['受力', s === 0 ? '不受力' : 'ab ' + up(F) + '，cd ' + up(-F) + (pos.key === 'eq' ? '（在同一直线上，平衡）' : '')],
      ['转向', Math.abs(state.w) < 0.05 ? '—' : '从换向器一端看' + (state.w < 0 ? '顺时针' : '逆时针')],
      ['转速', state.comm === 'ring' ? '—' : (Math.abs(state.wAvg) / (2 * Math.PI)).toFixed(2) + ' 圈/秒（示意）'],
      ['能量', state.on && Math.abs(state.w) > 0.05 && s !== 0 ? '电能 → 机械能（及少量内能）' : '—']
    ]);
    var tip, near = Math.abs(Math.cos(state.th)) < 0.42;
    if (!state.on) tip = '电源断开，线圈中没有电流，不受磁场力，靠惯性转一会儿就停下来。';
    else if (state.comm === 'ring') tip = swing ? '没有换向器，线圈中电流方向不变：线圈转过平衡位置后，受力把它拉回来，只能在平衡位置附近来回摆动。'
      : '线圈停在平衡位置：ab、cd 受力大小相等、方向相反、在同一直线上，彼此平衡。换上换向器才能持续转动。';
    else if (s === 0 && Math.abs(state.w) < 0.05) tip = '线圈停在平衡位置，电刷正压在两个半环之间的绝缘缝上，线圈中没有电流，电动机不能自行起动——点“拨一下”。';
    else if (near) tip = '换向器：线圈每次刚转过平衡位置，电刷就换接到另一个半环，线圈中电流方向改变，受力方向也随之改变，线圈继续朝原方向转。';
    else tip = '通电线圈在磁场中受力转动：ab、cd 两边电流方向相反，受力方向相反，使线圈绕轴转动。线圈平面与磁感线平行时转动效果最强。';
    setText('rTip', tip);
  }
  function readQuiz() {
    var q = state.quiz, s = state.score;
    setText('rName', !state.answered ? '判断练习' : state.correct ? '✓ 答对了' : '✗ 答错了');
    $('rName').className = !state.answered ? '' : state.correct ? 'ok' : 'bad';
    setText('rKind', '得分 ' + s.ok + ' / ' + s.n);
    setText('rTip', state.answered ? q.explain : q.prompt);
    rows([]);
  }

  // ---------- 尺寸 ----------
  var EV = 200;
  function resize() {
    var w = stage.clientWidth, h = stage.clientHeight;
    autoCollapse();
    if (sc3) sc3.resize(w, h);
    // 没有 WebGL 时把端视图放大到画面中央，代替 3D 模型
    var size = !sc3 ? Math.max(200, Math.min(520, Math.round(Math.min(w - 24, h - 150))))
      : w <= 760 ? 132 : Math.min(210, Math.max(150, Math.round(Math.min(w, h) * 0.26)));
    ev.classList.toggle('big', !sc3);
    var dpr = window.devicePixelRatio || 1;
    if (size !== EV || ev.width !== Math.round(size * dpr)) {
      EV = size;
      ev.width = ev.height = Math.round(size * dpr);
      ev.style.width = ev.style.height = size + 'px';
      ectx.setTransform(dpr, 0, 0, dpr, 0, 0);
    }
  }
  new ResizeObserver(resize).observe(stage);

  // ---------- 主循环 ----------
  // 支持 ?scene=wire|motor|quiz；导线 &pol=-1、&s=1（S 极在上）、&closed=1；电动机 &comm=split|ring、&I=0.5~3、&B=1|2|3、
  // &rev=1（对调电源）、&flip=1（对调磁极）、&angle=（线圈角 θ，度，90 为平衡位置）、&on=0、&slow=1；
  // 显示 &field=0、&force=0、&current=0、&labels=0、&end=0；练习 &q=dir|turn|pos|energy
  var qs = new URLSearchParams(location.search);
  if (HINTS[qs.get('scene')]) state.scene = qs.get('scene');
  if (qs.get('pol') === '-1') W.pol = -1;
  if (qs.get('s') === '1') W.nTop = false;
  if (qs.get('closed') === '1') W.closed = true;
  if (qs.get('comm') === 'ring' || qs.get('comm') === 'split') state.comm = qs.get('comm');
  if (qs.get('I') && !isNaN(+qs.get('I'))) state.I = M.clamp(Math.round(+qs.get('I') * 10) / 10, MO.I_RANGE[0], MO.I_RANGE[1]);
  if (['1', '2', '3'].indexOf(qs.get('B')) >= 0) state.b = +qs.get('B') - 1;
  if (qs.get('rev') === '1') state.pol = -1;
  if (qs.get('flip') === '1') state.mag = -1;
  if (qs.get('angle') && !isNaN(+qs.get('angle'))) state.th = M.wrap(+qs.get('angle') * DEG);
  if (qs.get('on') === '0') state.on = false;
  if (qs.get('slow') === '1') state.slow = true;
  ['field', 'force', 'current', 'labels', 'end'].forEach(function (k) { if (qs.get(k) === '0') state[k] = false; });
  if (M.TYPES.indexOf(qs.get('q')) >= 0) state.quizOnly = qs.get('q');
  recTable();
  resize();
  setScene(state.scene);
  // 窗口大小变化后的首次布局在下一帧才稳定
  requestAnimationFrame(resize);

  var last = performance.now(), lastRead = 0, readNow = true;
  function frame(now) {
    var dt = Math.min(0.05, (now - last) / 1000), v = view();
    last = now;
    var k = state.slow ? 0.25 : 1, h = dt * k;
    // 两个场景都推进（切换场景时各自保持状态）；练习时导线不动
    if (state.scene !== 'quiz' || state.answered) {
      var wasMoving = Math.abs(W.v) > 0.05;
      M.wireStep(W, h, { pol: W.pol, nTop: W.nTop, closed: W.closed, I: 2 });
      if (!wasMoving && Math.abs(W.v) > 0.05 && W.closed && state.scene === 'wire') record();
    }
    var B = MO.B_LEVELS[state.b];
    var p = { I: state.I, B: B, pol: state.pol, mag: state.mag, comm: state.comm, on: state.on };
    M.motorStep(state, h, p);
    state.wAvg += (state.w - state.wAvg) * Math.min(1, dt * 1.5);
    state.phase += h * 3.2;
    var s = state.on ? M.abCurrent(state.th, state.pol, state.comm) : 0;
    if (sc3) {
      if (v === 'wire') {
        sc3.show('wire', { x: W.x, pol: W.pol, nTop: W.nTop, closed: W.closed, phase: state.phase, field: state.field, force: state.force && (state.scene !== 'quiz' || state.answered), current: state.current });
      } else {
        sc3.show('motor', { th: state.th, I: state.I, B: B, pol: state.pol, mag: state.mag, comm: state.comm, on: state.on, phase: state.phase,
          field: state.field, force: state.force, current: state.current, labels: state.labels });
      }
      sc3.render();
    }
    if (!ev.hidden) {
      if (v === 'wire') Dr.wire(ectx, EV, { pol: W.pol, nTop: W.nTop, closed: W.closed, f: M.wireDir(W.pol, W.nTop, W.closed) * (M.fieldFrac(W.x) > 0.02 ? 1 : 0) });
      else Dr.motor(ectx, EV, { th: state.th, s: s, F: M.sideForce(s, state.I, B, state.mag), mag: state.mag, w: state.w });
    }
    // 面板读数每 0.15 s 刷新一次，避免每帧改 DOM
    if (now - lastRead > 150 || readNow) {
      lastRead = now; readNow = false;
      if (state.scene === 'wire') readWire();
      else if (state.scene === 'motor') readMotor();
      else readQuiz();
    }
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // 调试用
  window.__model = {
    state: state, M: M, scene: sc3, setScene: setScene, newQuiz: newQuiz, sync: syncUI, kick: kick,
    answer: function (o) { answer(o == null ? state.quiz.answer : o); }
  };
})();
