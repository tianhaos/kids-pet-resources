// 电动机原理：2D 端视图小图（从前方、即沿 −z 看过去）
// 电流垂直纸面：⊙ 表示流出纸面（+z，朝向观察者），⊗ 表示流入纸面（−z）；屏幕 y 向下，所以画图时 y 取反
(function () {
  var M = window.Motor;
  var K = 1;   // 字号、线宽随小图尺寸缩放（小图为 1，放大代替 3D 时最多 1.45）
  function font(px, w) { return (w || '') + ' ' + Math.round(px * K) + 'px system-ui, sans-serif'; }
  var C = { N: '#e0574f', S: '#4a78d8', field: '#4fc3f7', I: '#ffc94a', F: '#ff7a59', cu: '#d98b4a', text: '#e6ebf2', muted: '#8a96a8', line: '#2a3446' };

  function arrowLine(ctx, x0, y0, x1, y1, col, w, head) {
    var a = Math.atan2(y1 - y0, x1 - x0), h = head || 7;
    ctx.strokeStyle = ctx.fillStyle = col; ctx.lineWidth = w || 2;
    ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1 - Math.cos(a) * h * 0.6, y1 - Math.sin(a) * h * 0.6); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(x1, y1);
    ctx.lineTo(x1 - Math.cos(a - 0.45) * h, y1 - Math.sin(a - 0.45) * h);
    ctx.lineTo(x1 - Math.cos(a + 0.45) * h, y1 - Math.sin(a + 0.45) * h);
    ctx.closePath(); ctx.fill();
  }
  // 导线截面：s = +1 ⊙，−1 ⊗，0 无电流
  function wireDot(ctx, x, y, r, s, name, lx, ly) {
    ctx.fillStyle = C.cu; ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = '#05070d'; ctx.fillStyle = '#05070d'; ctx.lineWidth = 1.6;
    if (s > 0) { ctx.beginPath(); ctx.arc(x, y, r * 0.28, 0, Math.PI * 2); ctx.fill(); }
    else if (s < 0) {
      var k = r * 0.55;
      ctx.beginPath(); ctx.moveTo(x - k, y - k); ctx.lineTo(x + k, y + k); ctx.moveTo(x + k, y - k); ctx.lineTo(x - k, y + k); ctx.stroke();
    }
    if (name) { ctx.fillStyle = C.text; ctx.font = font(11, 600); ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(name, lx, ly); ctx.textBaseline = 'alphabetic'; }
  }
  function frame(ctx, S, title) {
    ctx.clearRect(0, 0, S, S);
    K = Math.min(1.45, Math.max(1, S / 260));
    ctx.fillStyle = 'rgba(11,15,24,.92)'; ctx.fillRect(0, 0, S, S);
    ctx.fillStyle = C.muted; ctx.font = font(11); ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic';
    ctx.fillText(title, 8 * K, 15 * K);
  }
  function key(ctx, S) {
    ctx.font = font(10); ctx.textAlign = 'left'; ctx.fillStyle = C.muted;
    ctx.fillText('⊙ 电流流出纸面  ⊗ 流入纸面', 8 * K, S - 7 * K);
  }

  // 直流电动机：o = { th, s（ab 中电流，+1 沿 +z）, F（ab 受力 y 分量）, mag, comm, w, on }
  function motor(ctx, S, o) {
    frame(ctx, S, '从换向器一端看');
    var cx = S / 2, cy = S / 2 + 4, R = S * 0.26, pw = S * 0.1, ph = S * 0.5, gx = R + S * 0.1;
    var nl = o.mag > 0;
    // 磁极
    [[-1, nl ? 'N' : 'S'], [1, nl ? 'S' : 'N']].forEach(function (p) {
      var x = cx + p[0] * gx + (p[0] < 0 ? -pw : 0);
      ctx.fillStyle = p[1] === 'N' ? C.N : C.S; ctx.fillRect(x, cy - ph / 2, pw, ph);
      ctx.fillStyle = '#fff'; ctx.font = font(12, 600); ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText(p[1], x + pw / 2, cy);
    });
    ctx.textBaseline = 'alphabetic';
    // 磁感线
    ctx.globalAlpha = 0.5;
    [-0.62, 0.62].forEach(function (k) {
      var y = cy + k * ph / 2, x0 = cx - gx + 2, x1 = cx + gx - 2;
      arrowLine(ctx, nl ? x0 : x1, y, nl ? x1 : x0, y, C.field, 1.2, 6);
    });
    ctx.globalAlpha = 1;
    // 平衡位置（竖直虚线）与转动轨迹
    ctx.setLineDash([4, 4]); ctx.strokeStyle = C.line; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.arc(cx, cy, R, 0, Math.PI * 2); ctx.stroke();
    ctx.strokeStyle = '#6b7a90';
    ctx.beginPath(); ctx.moveTo(cx, cy - R - 10); ctx.lineTo(cx, cy + R + 10); ctx.stroke();
    ctx.setLineDash([]);
    // 标在虚线下端右侧，避开线圈转到平衡位置时 cd（或 ab）的标签
    ctx.fillStyle = C.muted; ctx.font = font(10); ctx.textAlign = 'left';
    ctx.fillText('平衡位置', cx + 16 * K, cy + R + 14 * K);
    // 线圈平面
    var ax = cx + R * Math.cos(o.th), ay = cy - R * Math.sin(o.th), dx = cx - R * Math.cos(o.th), dy = cy + R * Math.sin(o.th);
    ctx.strokeStyle = C.cu; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.moveTo(ax, ay); ctx.lineTo(dx, dy); ctx.stroke();
    ctx.fillStyle = '#9aa3b0'; ctx.beginPath(); ctx.arc(cx, cy, 3, 0, Math.PI * 2); ctx.fill();
    // 受力
    var fl = o.s ? (16 + Math.abs(o.F) * 9) * K : 0, up = o.F >= 0 ? -1 : 1;
    if (fl) {
      arrowLine(ctx, ax, ay, ax, ay + up * fl, C.F, 2.4, 8);
      arrowLine(ctx, dx, dy, dx, dy - up * fl, C.F, 2.4, 8);
    }
    var r = Math.max(6, S * 0.04);
    var ux = Math.cos(o.th), uy = -Math.sin(o.th), off = r + 9 * K;
    wireDot(ctx, ax, ay, r, o.s, 'ab', ax + ux * off, ay + uy * off);
    wireDot(ctx, dx, dy, r, -o.s, 'cd', dx - ux * off, dy - uy * off);
    // 转向
    if (Math.abs(o.w) > 0.15) {
      // 画布角度 = −θ；在 ab 后方画一段弧，箭头指向转动方向
      var ccw = o.w > 0, k = ccw ? 1 : -1, a0 = -o.th + k * 0.9, a1 = -o.th + k * 0.25, rr = R + 12;
      ctx.strokeStyle = C.muted; ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.arc(cx, cy, rr, Math.min(a0, a1), Math.max(a0, a1)); ctx.stroke();
      var ex = cx + rr * Math.cos(a1), ey = cy + rr * Math.sin(a1), ta = a1 + (ccw ? -Math.PI / 2 : Math.PI / 2);
      arrowLine(ctx, ex - Math.cos(ta) * 2, ey - Math.sin(ta) * 2, ex + Math.cos(ta) * 3, ey + Math.sin(ta) * 3, C.muted, 1.5, 6);
    }
    key(ctx, S);
  }

  // 通电导线：o = { pol, nTop, closed, f }
  function wire(ctx, S, o) {
    frame(ctx, S, '从 A 端看（前方）');
    var cx = S / 2, cy = S / 2 + 4, aw = S * 0.62, ah = S * 0.09, gap = S * 0.25;
    [[-1, o.nTop ? 'N' : 'S'], [1, o.nTop ? 'S' : 'N']].forEach(function (p) {
      var y = p[0] < 0 ? cy - gap - ah : cy + gap;
      ctx.fillStyle = p[1] === 'N' ? C.N : C.S; ctx.fillRect(cx - aw / 2, y, aw, ah);
      ctx.fillStyle = '#fff'; ctx.font = font(12, 600); ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText(p[1], cx + aw / 2 - 10, y + ah / 2);
    });
    ctx.textBaseline = 'alphabetic';
    ctx.globalAlpha = 0.5;
    [-0.36, 0.36].forEach(function (k) {
      var x = cx + k * aw, y0 = cy - gap + 2, y1 = cy + gap - 2;
      arrowLine(ctx, x, o.nTop ? y0 : y1, x, o.nTop ? y1 : y0, C.field, 1.2, 6);
    });
    ctx.globalAlpha = 1;
    // 导轨截面与导体
    ctx.fillStyle = '#aab4c3'; ctx.fillRect(cx - aw / 2 - 6, cy + 9, aw + 12, 3);
    var s = o.closed ? (o.pol > 0 ? -1 : 1) : 0, r = Math.max(7, S * 0.045);
    if (s && o.f) arrowLine(ctx, cx, cy, cx + (o.f > 0 ? 1 : -1) * S * 0.2, cy, C.F, 2.6, 9);
    wireDot(ctx, cx, cy, r, s, 'AB', cx, cy - r - 9 * K);
    key(ctx, S);
  }

  window.MotorDraw = { motor: motor, wire: wire };
})();
