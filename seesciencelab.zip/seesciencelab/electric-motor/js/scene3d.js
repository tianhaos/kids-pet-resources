// 电动机原理：three.js 场景
// 场景一：蹄形磁体（两臂上下、弯头在后）+ 两根导轨 + 导体 AB + 电源与开关；场景二：直流电动机（磁极、线圈 abcd、换向器或滑环、电刷、电源）
// 坐标与单位见 motor.js：x 右、y 上、z 指向观察者，单位 cm
(function () {
  var M = window.Motor, W = M.WIRE, MO = M.MOTOR;
  var V3 = THREE.Vector3, Y = new V3(0, 1, 0);
  var COL = { N: 0xe0574f, S: 0x4a78d8, yoke: 0x6b7484, cu: 0xd98b4a, cu2: 0xe8a868, rail: 0xaab4c3, wire: 0x8a96a8,
    brush: 0x3a3f48, ins: 0x1b1f27, axle: 0x9aa3b0, field: 0x4fc3f7, I: 0xffc94a, F: 0xff7a59, bat: 0x2f3746 };

  window.MotorScene = function (container) {
    var renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    container.appendChild(renderer.domElement);
    var canvas = renderer.domElement;
    canvas.id = 'view3d';

    var labelRenderer = new THREE.CSS2DRenderer();
    var ls = labelRenderer.domElement.style;
    ls.position = 'absolute'; ls.top = '0'; ls.left = '0'; ls.pointerEvents = 'none'; ls.zIndex = '2';
    container.appendChild(labelRenderer.domElement);

    var scene = new THREE.Scene();
    scene.background = new THREE.Color('#05070d');
    var camera = new THREE.PerspectiveCamera(32, 1, 0.5, 500);
    scene.add(camera);
    scene.add(new THREE.AmbientLight(0xffffff, 0.45));
    var key = new THREE.DirectionalLight(0xffffff, 0.85);
    key.position.set(-3, 6, 8);
    camera.add(key);
    var rim = new THREE.DirectionalLight(0x9fc8ff, 0.3);
    rim.position.set(6, -3, -5);
    camera.add(rim);

    var controls = new THREE.OrbitControls(camera, canvas);
    controls.enableDamping = true;
    controls.dampingFactor = 0.08;
    controls.enablePan = false;
    var moved = false;
    controls.addEventListener('start', function () { moved = true; });

    var box = new THREE.BoxGeometry(1, 1, 1), cyl = new THREE.CylinderGeometry(1, 1, 1, 16), ball = new THREE.SphereGeometry(1, 12, 8);
    var cone = new THREE.ConeGeometry(1, 1, 14);
    function std(col, o) {
      o = o || {};
      return new THREE.MeshStandardMaterial({ color: new THREE.Color(col), roughness: o.r == null ? 0.5 : o.r, metalness: o.m || 0.1,
        transparent: !!o.op, opacity: o.op || 1, side: o.ds ? THREE.DoubleSide : THREE.FrontSide, emissive: new THREE.Color(o.em || 0) });
    }
    function mesh(geo, mat, g, pos, scl) {
      var m = new THREE.Mesh(geo, mat.isMaterial ? mat : std(mat));
      if (pos) m.position.set(pos[0], pos[1], pos[2]);
      if (scl) m.scale.set(scl[0], scl[1], scl[2]);
      g.add(m);
      return m;
    }
    // 两点之间的圆柱（导线、转轴）
    function stick(g, a, b, r, mat) {
      var m = mesh(cyl, mat, g);
      setStick(m, a, b, r);
      return m;
    }
    function setStick(m, a, b, r) {
      a = a.isVector3 ? a : new V3(a[0], a[1], a[2]); b = b.isVector3 ? b : new V3(b[0], b[1], b[2]);
      var d = b.clone().sub(a), len = d.length();
      m.position.copy(a).addScaledVector(d, 0.5);
      m.scale.set(r, len, r);
      if (len > 1e-6) m.quaternion.setFromUnitVectors(Y, d.normalize());
    }
    function polyline(g, pts, r, mat) {
      for (var i = 0; i < pts.length - 1; i++) stick(g, pts[i], pts[i + 1], r, mat);
      pts.slice(1, -1).forEach(function (p) { mesh(ball, mat, g, p, [r, r, r]); });
    }
    function label(g, html, cls, pos) {
      var el = document.createElement('div');
      el.className = 'lab ' + (cls || '');
      el.innerHTML = html;
      var o = new THREE.CSS2DObject(el);
      if (pos) o.position.set(pos[0], pos[1], pos[2]);
      g.add(o);
      return o;
    }
    function setLab(o, html) { if (o.element.innerHTML !== html) o.element.innerHTML = html; }
    // 箭头：圆柱 + 圆锥，沿 +y 建模，再转到所需方向
    function arrow(g, col, r) {
      var a = new THREE.Group(), mat = std(col, { em: col, r: 0.4 });
      a.userData.shaft = mesh(cyl, mat, a);
      a.userData.head = mesh(cone, mat, a);
      a.userData.r = r || 0.16;
      g.add(a);
      return a;
    }
    function setArrow(a, from, dir, len) {
      var r = a.userData.r, hl = Math.min(len * 0.45, r * 5);
      a.visible = len > 0.05;
      if (!a.visible) return;
      a.position.copy(from);
      a.quaternion.setFromUnitVectors(Y, dir.clone().normalize());
      a.userData.shaft.scale.set(r, len - hl, r); a.userData.shaft.position.set(0, (len - hl) / 2, 0);
      a.userData.head.scale.set(r * 2.6, hl, r * 2.6); a.userData.head.position.set(0, len - hl / 2, 0);
    }
    // 电流小点：沿折线等距分布，phase 随时间推进
    function makeDots(g, n) {
      var mat = new THREE.MeshBasicMaterial({ color: COL.I }), arr = [];
      for (var i = 0; i < n; i++) arr.push(mesh(ball, mat, g, null, [0.13, 0.13, 0.13]));
      return arr;
    }
    function placeDots(dots, pts, phase, on) {
      var segs = [], tot = 0;
      for (var i = 0; i < pts.length - 1; i++) { var l = pts[i].distanceTo(pts[i + 1]); segs.push(l); tot += l; }
      var step = 1.1, n = Math.min(dots.length, Math.floor(tot / step));
      for (var k = 0; k < dots.length; k++) {
        var d = dots[k];
        d.visible = on && k < n;
        if (!d.visible) continue;
        var s = ((k * step + phase) % tot + tot) % tot, j = 0;
        while (j < segs.length - 1 && s > segs[j]) { s -= segs[j]; j++; }
        d.position.copy(pts[j]).lerp(pts[j + 1], segs[j] ? Math.min(1, s / segs[j]) : 0);
      }
    }
    function fieldLines(g, list, len, axis) {
      // list：起点数组；沿 axis（单位向量）画长 len 的磁感线，中间加箭头
      var pts = [], mat = new THREE.LineBasicMaterial({ color: COL.field, transparent: true, opacity: 0.55 }), heads = [];
      list.forEach(function (p) {
        var a = new V3(p[0], p[1], p[2]);
        pts.push(a, a.clone().addScaledVector(axis, len));
        var h = mesh(cone, std(COL.field, { em: COL.field, op: 0.8 }), g, null, [0.2, 0.5, 0.2]);
        h.position.copy(a).addScaledVector(axis, len / 2);
        heads.push(h);
      });
      var geo = new THREE.BufferGeometry().setFromPoints(pts);
      var ln = new THREE.LineSegments(geo, mat);
      g.add(ln);
      return { line: ln, heads: heads };
    }
    function pointHeads(f, dir) {
      f.heads.forEach(function (h) { h.quaternion.setFromUnitVectors(Y, dir); });
    }

    // =============== 场景一：通电导线在磁场中受力 ===============
    var gWire = new THREE.Group();
    scene.add(gWire);
    var wr = {};
    (function buildWire() {
      var g = gWire, d = W.depth, t = W.gap + W.arm;
      wr.top = mesh(box, COL.N, g, [0, W.gap + W.arm / 2, 0], [W.x1 - W.x0, W.arm, 2 * d]);
      wr.bot = mesh(box, COL.S, g, [0, -W.gap - W.arm / 2, 0], [W.x1 - W.x0, W.arm, 2 * d]);
      mesh(box, COL.yoke, g, [0, 0, -d - 0.9], [W.x1 - W.x0, 2 * t, 1.8]);
      wr.lTop = label(g, 'N', 'pole', [W.x1 - 0.9, W.gap + W.arm / 2, d + 0.05]);
      wr.lBot = label(g, 'S', 'pole', [W.x1 - 0.9, -W.gap - W.arm / 2, d + 0.05]);
      // 磁感线（竖直）
      var starts = [];
      [-3, -1, 1, 3].forEach(function (x) { [-1.6, 1.6].forEach(function (z) { starts.push([x, W.gap, z]); }); });
      wr.field = fieldLines(g, starts, 2 * W.gap, new V3(0, -1, 0));
      // 导轨
      var ry = W.railY - 0.15, len = W.railX1 - W.railX0, cx = (W.railX0 + W.railX1) / 2;
      [W.rail, -W.rail].forEach(function (z) { mesh(box, std(COL.rail, { m: 0.6, r: 0.35 }), g, [cx, ry, z], [len, 0.3, 0.3]); });
      // 导体 AB
      wr.rod = new THREE.Group(); g.add(wr.rod);
      var rm = mesh(cyl, std(COL.cu2, { m: 0.5, r: 0.3 }), wr.rod, null, [W.rodR, 2 * W.rod, W.rodR]);
      rm.rotation.x = Math.PI / 2;
      label(wr.rod, 'A', 'pt', [0, 0.9, W.rod + 0.3]);
      label(wr.rod, 'B', 'pt', [0, 0.9, -W.rod - 0.3]);
      // 电源（沿 z 放在导轨左端外侧）与开关
      var bx = W.railX0 - 2.6, by = ry, hinge = W.railX0 - 1;
      mesh(box, COL.bat, g, [bx, by, 0], [1.3, 1.3, 3.2]);
      wr.batF = mesh(box, std(0xc0392b), g, [bx, by, 1.75], [0.7, 0.7, 0.3]);
      wr.batB = mesh(box, std(0x34495e), g, [bx, by, -1.75], [0.7, 0.7, 0.3]);
      wr.lF = label(g, '+', 'sign', [bx - 1.1, by + 0.4, 1.4]);
      wr.lB = label(g, '−', 'sign', [bx - 1.1, by + 0.4, -1.4]);
      label(g, '电源', 'part', [bx - 1.8, by - 0.8, 0]);
      var wm = std(COL.wire, { m: 0.4 });
      polyline(g, [[bx, by, 1.9], [bx, by, W.rail]], 0.09, wm);
      polyline(g, [[hinge, by, W.rail], [W.railX0, by, W.rail]], 0.09, wm);
      polyline(g, [[bx, by, -1.9], [bx, by, -W.rail], [W.railX0, by, -W.rail]], 0.09, wm);
      mesh(box, std(0x59636f), g, [hinge, by - 0.2, W.rail], [0.4, 0.3, 0.6]);
      mesh(box, std(0x59636f), g, [bx + 0.1, by - 0.2, W.rail], [0.4, 0.3, 0.6]);
      wr.blade = new THREE.Group(); wr.blade.position.set(hinge, by + 0.05, W.rail); g.add(wr.blade);
      var bl = mesh(box, std(0xc9ced6, { m: 0.6, r: 0.3 }), wr.blade, [-(hinge - bx) / 2, 0, 0], [hinge - bx, 0.12, 0.3]);
      mesh(cyl, std(0x222831), wr.blade, [-(hinge - bx) + 0.1, 0.45, 0], [0.16, 0.8, 0.16]);
      wr.lSw = label(g, '开关', 'part', [hinge - 0.8, by + 1.6, W.rail + 0.6]);
      bl.userData = 0;
      // 电流点、力与电流箭头
      wr.dots = makeDots(g, 60);
      wr.F = arrow(g, COL.F, 0.18);
      wr.lF2 = label(g, 'F', 'force');
      wr.I = arrow(g, COL.I, 0.12);
      wr.path = [];
    })();

    function showWire(o) {
      gWire.visible = true; gMotor.visible = false;
      var y = W.railY + W.rodR, x = o.x;
      wr.top.material.color.setHex(o.nTop ? COL.N : COL.S);
      wr.bot.material.color.setHex(o.nTop ? COL.S : COL.N);
      setLab(wr.lTop, o.nTop ? 'N' : 'S'); setLab(wr.lBot, o.nTop ? 'S' : 'N');
      wr.lTop.element.className = 'lab pole ' + (o.nTop ? 'n' : 's');
      wr.lBot.element.className = 'lab pole ' + (o.nTop ? 's' : 'n');
      pointHeads(wr.field, new V3(0, o.nTop ? -1 : 1, 0));
      wr.field.line.visible = o.field; wr.field.heads.forEach(function (h) { h.visible = o.field; });
      wr.rod.position.set(x, y, 0);
      setLab(wr.lF, o.pol > 0 ? '+' : '−'); setLab(wr.lB, o.pol > 0 ? '−' : '+');
      wr.batF.material.color.setHex(o.pol > 0 ? 0xc0392b : 0x34495e);
      wr.batB.material.color.setHex(o.pol > 0 ? 0x34495e : 0xc0392b);
      wr.blade.rotation.z = o.closed ? 0 : -0.6;
      // 电流路径：前接线柱 → 开关 → 前导轨 → A → B → 后导轨 → 后接线柱
      var bx = W.railX0 - 2.6, by = W.railY - 0.15, hinge = W.railX0 - 1;
      var pts = [[bx, by, 1.9], [bx, by, W.rail], [hinge, by, W.rail], [x, by, W.rail], [x, y, W.rod - 0.4], [x, y, -W.rod + 0.4],
        [x, by, -W.rail], [bx, by, -W.rail], [bx, by, -1.9]].map(function (p) { return new V3(p[0], p[1], p[2]); });
      if (o.pol < 0) pts.reverse();
      placeDots(wr.dots, pts, o.phase, o.closed && o.current);
      // 受力
      var f = M.wireDir(o.pol, o.nTop, o.closed) * M.fieldFrac(x);
      setArrow(wr.F, new V3(x, y + 1.4, 0), new V3(f >= 0 ? 1 : -1, 0, 0), o.force ? Math.abs(f) * 3.2 : 0);
      wr.lF2.visible = o.force && Math.abs(f) > 0.05;
      wr.lF2.position.set(x + (f > 0 ? 3.7 : -3.7), y + 1.4, 0);
      // AB 中电流方向（金色箭头，画在导体上方）
      setArrow(wr.I, new V3(x, y + 0.75, o.pol > 0 ? 1.6 : -1.6), new V3(0, 0, o.pol > 0 ? -1 : 1), o.closed && o.current ? 3.2 : 0);
    }

    // =============== 场景二：直流电动机 ===============
    var gMotor = new THREE.Group();
    scene.add(gMotor);
    var mo = {};
    (function buildMotor() {
      var g = gMotor, px = MO.pole + MO.poleW / 2;
      mo.L = mesh(box, COL.N, g, [-px, 0, 0], [MO.poleW, MO.poleH, MO.poleD]);
      mo.R = mesh(box, COL.S, g, [px, 0, 0], [MO.poleW, MO.poleH, MO.poleD]);
      // 底座（示意定子的支架）
      mesh(box, COL.yoke, g, [0, -MO.poleH / 2 - 0.6, 0], [2 * (MO.pole + MO.poleW), 1.2, MO.poleD]);
      mo.lL = label(g, 'N', 'pole n', [-px, MO.poleH / 2 + 0.9, 0]);
      mo.lR = label(g, 'S', 'pole s', [px, MO.poleH / 2 + 0.9, 0]);
      var starts = [];
      [-2.6, 2.6].forEach(function (y) { [-2.4, 0.4, 3].forEach(function (z) { starts.push([-MO.pole, y, z]); }); });
      [-0.9, 0.9].forEach(function (y) { [-3.2, 2.2].forEach(function (z) { starts.push([-MO.pole, y, z]); }); });
      mo.field = fieldLines(g, starts, 2 * MO.pole, new V3(1, 0, 0));
      mo.lStator = label(g, '定子（磁体）', 'part', [-px, -MO.poleH / 2 - 1.8, MO.poleD / 2]);

      // 转子：线圈 + 转轴 + 换向器 / 滑环，绕 z 轴转
      mo.rotor = new THREE.Group(); g.add(mo.rotor);
      var r = mo.rotor, R = MO.R, h = MO.L / 2, cz = MO.commZ, cr = MO.commR, cl = MO.commLen;
      stick(r, [0, 0, -h - 2], [0, 0, cz + cl / 2 + 1.6], 0.22, std(COL.axle, { m: 0.7, r: 0.3 }));
      var cu = std(COL.cu, { m: 0.45, r: 0.35 });
      mo.coilPts = [[cr * 0.9, 0, cz - cl / 2], [R, 0, h], [R, 0, -h], [-R, 0, -h], [-R, 0, h], [-cr * 0.9, 0, cz - cl / 2]];
      polyline(r, mo.coilPts, 0.2, cu);
      mo.coilV = mo.coilPts.map(function (p) { return new V3(p[0], p[1], p[2]); });
      mo.la = label(r, 'a', 'pt', [R + 0.5, 0.4, h]);
      mo.lb = label(r, 'b', 'pt', [R + 0.5, 0.4, -h]);
      mo.lc = label(r, 'c', 'pt', [-R - 0.5, 0.4, -h]);
      mo.ld = label(r, 'd', 'pt', [-R - 0.5, 0.4, h]);
      mo.lRotor = label(r, '线圈（转子）', 'part', [0, 0.6, -h - 0.4]);
      // 换向器：两个铜半环 + 中间绝缘套（CylinderGeometry 转到沿 z：几何角 θ 对应 xy 平面内 φ = θ − 90°）
      var g2 = MO.GAP / Math.PI * 180, half = function (start) {
        var geo = new THREE.CylinderGeometry(cr, cr, cl, 24, 1, true, (start + g2) * Math.PI / 180, (180 - 2 * g2) * Math.PI / 180);
        geo.rotateX(Math.PI / 2);
        return geo;
      };
      mo.split = new THREE.Group(); r.add(mo.split);
      mo.split.position.z = cz;
      mesh(half(0), std(COL.cu2, { m: 0.6, r: 0.25, ds: true }), mo.split);
      mesh(half(180), std(COL.cu2, { m: 0.6, r: 0.25, ds: true }), mo.split);
      var insul = mesh(cyl, std(COL.ins), mo.split, null, [cr * 0.93, cl * 1.02, cr * 0.93]);
      insul.rotation.x = Math.PI / 2;
      // 滑环（无换向器时）：两个完整铜环，分别接 a、d
      mo.ring = new THREE.Group(); r.add(mo.ring);
      mo.ring.position.z = cz;
      [-0.38, 0.38].forEach(function (dz) {
        var m = mesh(cyl, std(COL.cu2, { m: 0.6, r: 0.25 }), mo.ring, [0, 0, dz], [cr, cl * 0.42, cr]);
        m.rotation.x = Math.PI / 2;
      });
      var ins2 = mesh(cyl, std(COL.ins), mo.ring, null, [cr * 0.93, cl * 1.02, cr * 0.93]);
      ins2.rotation.x = Math.PI / 2;
      mo.lComm = label(g, '换向器', 'part', [0, cr + 1.1, cz + 0.5]);

      // 电刷与电源（固定）：split 时电刷在左右两侧；ring 时两个电刷都在右侧，前后各压一个滑环
      mo.brushes = new THREE.Group(); g.add(mo.brushes);
      mo.bat = new THREE.Group(); g.add(mo.bat);
      var by = -MO.poleH / 2 - 2.6, bz = cz + 0.3;
      mesh(box, COL.bat, mo.bat, [0, by, bz], [3.4, 1.2, 1.2]);
      mo.batR = mesh(box, std(0xc0392b), mo.bat, [1.85, by, bz], [0.3, 0.7, 0.7]);
      mo.batL = mesh(box, std(0x34495e), mo.bat, [-1.85, by, bz], [0.3, 0.7, 0.7]);
      mo.lBR = label(mo.bat, '+', 'sign', [1.5, by + 1.1, bz]);
      mo.lBL = label(mo.bat, '−', 'sign', [-1.5, by + 1.1, bz]);
      label(mo.bat, '电源', 'part', [0, by - 1.2, bz]);
      mo.dotsCoil = makeDots(r, 40);
      mo.dotsExt = makeDots(g, 40);
      mo.Fab = arrow(g, COL.F, 0.18); mo.Fcd = arrow(g, COL.F, 0.18);
      mo.lFab = label(g, 'F', 'force'); mo.lFcd = label(g, 'F', 'force');
      mo.Iab = arrow(r, COL.I, 0.12); mo.Icd = arrow(r, COL.I, 0.12);
      mo.comm = '';
    })();

    // 电刷与外电路随换向器 / 滑环重建
    function clearG(g) {
      for (var i = g.children.length - 1; i >= 0; i--) {
        var o = g.children[i];
        if (o.isCSS2DObject && o.element.parentNode) o.element.parentNode.removeChild(o.element);
        if (o.material && o.material.dispose) o.material.dispose();
        g.remove(o);
      }
    }
    function buildBrushes(comm) {
      clearG(mo.brushes);
      var g = mo.brushes, cz = MO.commZ, cr = MO.commR, by = -MO.poleH / 2 - 2.6, bz = cz + 0.3;
      var bm = std(COL.brush, { r: 0.8 }), wm = std(COL.wire, { m: 0.4 });
      var ext;   // 外电路：从左（负，pol=+1 时）电刷 → 电源左端 → 电源右端 → 右电刷
      if (comm === 'split') {
        mesh(box, bm, g, [cr + 0.35, 0, cz], [0.7, 0.55, 0.7]);
        mesh(box, bm, g, [-cr - 0.35, 0, cz], [0.7, 0.55, 0.7]);
        var pr = [[cr + 0.7, 0, cz], [2.4, 0, cz], [2.4, by, bz], [2, by, bz]];
        var pl = [[-cr - 0.7, 0, cz], [-2.4, 0, cz], [-2.4, by, bz], [-2, by, bz]];
        polyline(g, pr, 0.08, wm); polyline(g, pl, 0.08, wm);
        mo.lBrush = label(g, '电刷', 'part', [cr + 1.9, 0.75, cz]);
        ext = pl.concat([[-1.7, by, bz], [1.7, by, bz]]).concat(pr.slice().reverse());
      } else {
        var z1 = cz - 0.38, z2 = cz + 0.38;
        mesh(box, bm, g, [cr + 0.35, 0, z1], [0.7, 0.55, 0.5]);
        mesh(box, bm, g, [cr + 0.35, 0, z2], [0.7, 0.55, 0.5]);
        // z1 环接 a（正极一侧），z2 环接 d
        var p1 = [[cr + 0.7, 0, z1], [2.4, 0, z1], [2.4, by, bz], [2, by, bz]];
        var p2 = [[cr + 0.7, 0, z2], [1.6, 0, z2 + 0.9], [-2.4, 0, z2 + 0.9], [-2.4, by, bz], [-2, by, bz]];
        polyline(g, p1, 0.08, wm); polyline(g, p2, 0.08, wm);
        mo.lBrush = label(g, '电刷', 'part', [cr + 1.9, 0.75, cz]);
        ext = p2.concat([[-1.7, by, bz], [1.7, by, bz]]).concat(p1.slice().reverse());
      }
      mo.ext = ext.map(function (p) { return new V3(p[0], p[1], p[2]); });
    }

    function showMotor(o) {
      gWire.visible = false; gMotor.visible = true;
      if (o.comm !== mo.comm) {
        mo.comm = o.comm; buildBrushes(o.comm);
        mo.split.visible = o.comm === 'split'; mo.ring.visible = !mo.split.visible;
        setLab(mo.lComm, o.comm === 'split' ? '换向器' : '两个滑环（无换向器）');
      }
      var nl = o.mag > 0;
      mo.L.material.color.setHex(nl ? COL.N : COL.S); mo.R.material.color.setHex(nl ? COL.S : COL.N);
      setLab(mo.lL, nl ? 'N' : 'S'); setLab(mo.lR, nl ? 'S' : 'N');
      mo.lL.element.className = 'lab pole ' + (nl ? 'n' : 's'); mo.lR.element.className = 'lab pole ' + (nl ? 's' : 'n');
      pointHeads(mo.field, new V3(o.mag, 0, 0));
      mo.field.line.visible = o.field; mo.field.heads.forEach(function (h) { h.visible = o.field; });
      mo.rotor.rotation.z = o.th;
      // 电源方向：pol=+1 时右端为正（split：接右电刷；ring：接前一个滑环所在电刷，也在右侧）
      mo.batR.material.color.setHex(o.pol > 0 ? 0xc0392b : 0x34495e);
      mo.batL.material.color.setHex(o.pol > 0 ? 0x34495e : 0xc0392b);
      setLab(mo.lBR, o.pol > 0 ? '+' : '−'); setLab(mo.lBL, o.pol > 0 ? '−' : '+');
      var s = o.on ? M.abCurrent(o.th, o.pol, o.comm) : 0;
      // 线圈中电流：s = −1 表示 a→b（沿线圈折线正向）
      var cp = mo.coilV.slice(); if (s > 0) cp.reverse();
      placeDots(mo.dotsCoil, cp, o.phase, s !== 0 && o.current);
      var ep = mo.ext.slice(); if (o.pol < 0) ep.reverse();
      // 电刷在绝缘缝上时外电路也断开
      placeDots(mo.dotsExt, ep, o.phase, s !== 0 && o.current);
      // ab、cd 边受力（竖直）
      var F = M.sideForce(s, o.I, o.B, o.mag), c = Math.cos(o.th), sn = Math.sin(o.th), R = MO.R;
      var len = o.force && s !== 0 ? 1.1 + Math.abs(F) * 0.9 : 0, up = new V3(0, F >= 0 ? 1 : -1, 0);
      var pab = new V3(R * c, R * sn, 0), pcd = new V3(-R * c, -R * sn, 0);
      setArrow(mo.Fab, pab, up, len); setArrow(mo.Fcd, pcd, up.clone().negate(), len);
      mo.lFab.visible = mo.lFcd.visible = len > 0;
      mo.lFab.position.copy(pab).addScaledVector(up, len + 0.6);
      mo.lFcd.position.copy(pcd).addScaledVector(up, -(len + 0.6));
      // 线圈两边上的电流方向箭头（转子坐标）
      var il = s !== 0 && o.current ? 2.2 : 0;
      setArrow(mo.Iab, new V3(R, 0.45, s < 0 ? 1.1 : -1.1), new V3(0, 0, s < 0 ? -1 : 1), il);
      setArrow(mo.Icd, new V3(-R, 0.45, s < 0 ? -1.1 : 1.1), new V3(0, 0, s < 0 ? 1 : -1), il);
      [mo.lStator, mo.lRotor, mo.lComm, mo.lBrush].forEach(function (l) { l.visible = o.labels; });
    }

    // ---------- 取景 ----------
    var mode = '';
    // 取景：观察方向 + 需要完整装进画面的包围盒（含标签），fit() 迭代调整目标点和距离
    var VIEWS = {
      wire: { dir: [0.32, 0.5, 1], box: [[W.railX0 - 4.2, -W.gap - W.arm - 0.4, -W.depth - 1.8], [W.railX1 + 0.3, W.gap + W.arm + 0.6, W.depth + 1]] },
      motor: { dir: [0.42, 0.42, 1], box: [[-MO.pole - MO.poleW, -MO.poleH / 2 - 4.2, -MO.poleD / 2], [MO.pole + MO.poleW, MO.poleH / 2 + 1.4, MO.commZ + 2.3]] }
    };
    function fit() {
      var v = VIEWS[mode]; if (!v) return;
      var aspect = camera.aspect || 1, half = Math.tan(camera.fov * Math.PI / 360);
      var b0 = v.box[0], b1 = v.box[1], corners = [];
      for (var i = 0; i < 8; i++) corners.push(new V3(i & 1 ? b1[0] : b0[0], i & 2 ? b1[1] : b0[1], i & 4 ? b1[2] : b0[2]));
      var d = new V3(v.dir[0], v.dir[1], v.dir[2]).normalize();
      var target = new V3((b0[0] + b1[0]) / 2, (b0[1] + b1[1]) / 2, (b0[2] + b1[2]) / 2);
      var size = Math.max(b1[0] - b0[0], b1[1] - b0[1], b1[2] - b0[2]), dist = size / half;
      var right = new V3(), up = new V3(), p = new V3();
      // 窄屏下方留出按钮条，视觉中心略上移
      var margin = 0.9, lift = aspect < 0.8 ? 0.08 : 0;
      for (var k = 0; k < 6; k++) {
        camera.position.copy(target).addScaledVector(d, dist);
        camera.lookAt(target);
        camera.updateMatrixWorld();
        var x0 = 1e9, x1 = -1e9, y0 = 1e9, y1 = -1e9;
        corners.forEach(function (c) {
          p.copy(c).project(camera);
          x0 = Math.min(x0, p.x); x1 = Math.max(x1, p.x); y0 = Math.min(y0, p.y); y1 = Math.max(y1, p.y);
        });
        // 把包围盒中心移到画面中心（NDC → 目标点所在平面的世界距离）
        right.setFromMatrixColumn(camera.matrixWorld, 0); up.setFromMatrixColumn(camera.matrixWorld, 1);
        var hh = dist * half, ww = hh * aspect;
        target.addScaledVector(right, (x0 + x1) / 2 * ww).addScaledVector(up, ((y0 + y1) / 2 - lift) * hh);
        dist *= Math.max((x1 - x0) / 2, (y1 - y0) / 2) / margin;
      }
      controls.target.copy(target);
      camera.position.copy(target).addScaledVector(d, dist);
      controls.minDistance = dist * 0.35;
      controls.maxDistance = dist * 2.2;
      controls.update();
    }
    function home() { moved = false; fit(); }
    function show(m, o) {
      if (m !== mode) { mode = m; moved = false; fit(); }
      if (m === 'wire') showWire(o); else showMotor(o);
    }
    function resize(w, h) {
      camera.aspect = w / Math.max(1, h);
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
      labelRenderer.setSize(w, h);
      if (!moved) fit();
    }
    function render() {
      controls.update();
      renderer.render(scene, camera);
      labelRenderer.render(scene, camera);
    }
    // 投影到屏幕（端视图用：判断观察方向）
    function viewDir() { return camera.position.clone().sub(controls.target).normalize(); }

    return { show: show, render: render, resize: resize, home: home, viewDir: viewDir,
      canvas: canvas, labels: labelRenderer.domElement, camera: camera, controls: controls };
  };
})();
