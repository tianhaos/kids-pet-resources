// 电动机原理的计算（不碰 DOM）
// 世界坐标 x 右、y 上、z 指向观察者，单位 cm。
// 场景一（通电导线在磁场中受力）：蹄形磁体两臂上下、弯头在后，两臂之间磁场竖直；导体 AB 沿 z 放在两根导轨上（A 在前、B 在后），
//   只能沿 x 滚动；电源在导轨左端，pol = +1 表示正极接前导轨，电流在导体中由 A 流向 B（−z 方向）。
// 场景二（直流电动机）：磁场沿 x，mag = +1 表示 N 极在左（B 沿 +x）；线圈绕 z 轴转，θ 为线圈平面与 x 轴的夹角，
//   ab 边在 (R cos θ, R sin θ)、cd 边在对侧，θ = ±90° 时线圈平面与磁感线垂直，即“平衡位置”；θ 减小 = 从换向器一端（前方）看顺时针。
//   换向器两个半环分别接 a、d 端，电刷在左右两侧，正电刷在右（pol = +1）。
(function () {
  var DEG = Math.PI / 180, TAU = Math.PI * 2;
  function clamp(x, a, b) { return x < a ? a : x > b ? b : x; }
  function sgn(x) { return x > 0 ? 1 : x < 0 ? -1 : 0; }
  function cross(a, b) { return [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]]; }
  // 角度化到 (−π, π]
  function wrap(a) { a = (a + Math.PI) % TAU; if (a < 0) a += TAU; return a - Math.PI; }

  // ---------- 场景一：通电导线在磁场中受力 ----------
  var WIRE = {
    x0: -4, x1: 4,              // 磁极 x 范围
    gap: 2.4, arm: 1.6, depth: 3.2,  // 两臂之间半间隙、臂厚、磁体前后半宽（z）
    rail: 2.6, railY: -0.9,     // 导轨 z = ±rail，导轨顶面高度
    rod: 3.4, rodR: 0.42,       // 导体半长、半径
    xMin: -8.6, xMax: 8.6,      // 导体在导轨上的活动范围
    railX0: -11, railX1: 9.4,   // 导轨两端
    ACC: 6, FRIC: 3             // 每安培的加速度（cm/s²）、滚动摩擦减速度（cm/s²）
  };
  // 导体所在 x 处的磁场占比（磁极边缘 0.8 cm 内平滑过渡，近似边缘效应）
  function fieldFrac(x) {
    var e = 0.8, a = clamp((x - (WIRE.x0 - e)) / (2 * e), 0, 1), b = clamp(((WIRE.x1 + e) - x) / (2 * e), 0, 1);
    var f = Math.min(a, b);
    return f * f * (3 - 2 * f);
  }
  // 导体受力方向（x 分量的符号）：pol 电源方向（+1：A→B），nTop N 极在上；closed 开关闭合
  function wireDir(pol, nTop, closed) {
    if (!closed) return 0;
    var I = [0, 0, -pol], B = [0, nTop ? -1 : 1, 0];
    return sgn(cross(I, B)[0]);
  }
  // 推进一步：st = { x, v }；p = { pol, nTop, closed, I }
  function wireStep(st, dt, p) {
    var f = wireDir(p.pol, p.nTop, p.closed) * WIRE.ACC * p.I * fieldFrac(st.x);
    var a = f - WIRE.FRIC * sgn(st.v);
    var v = st.v + a * dt;
    if (st.v !== 0 && sgn(v) !== sgn(st.v) && Math.abs(f) < WIRE.FRIC) v = 0;  // 摩擦只让它停下，不让它倒退
    if (st.v === 0 && Math.abs(f) <= WIRE.FRIC) v = 0;                          // 静摩擦
    var x = st.x + v * dt;
    if (x < WIRE.xMin) { x = WIRE.xMin; v = 0; }
    if (x > WIRE.xMax) { x = WIRE.xMax; v = 0; }
    st.x = x; st.v = v; st.f = f;
    return st;
  }

  // ---------- 场景二：直流电动机 ----------
  var MOTOR = {
    R: 3, L: 7,                 // 线圈半宽（ab、cd 到转轴的距离）、ab 边长（沿 z）
    pole: 4.3, poleW: 3, poleH: 7.4, poleD: 8.4,  // 磁极内表面 x、厚度、高、前后宽
    commZ: 5.6, commR: 1.0, commLen: 1.3,         // 换向器位置、半径、长度
    GAP: 9 * DEG,               // 换向器两个半环之间绝缘缝的半角：电刷压在缝上时线圈中没有电流
    K: 0.8,                     // 力矩系数：最大力矩 = 2K·I·B
    J: 1, C: 0.5, F0: 0.03,        // 转动惯量、阻力系数、摩擦力矩（示意单位）
    I_RANGE: [0.5, 3],
    B_LEVELS: [0.6, 1, 1.4]     // 磁性 弱 / 中 / 强
  };
  // ab 边中的电流方向（+1 沿 +z，−1 沿 −z，0 为电刷在缝上、断路）
  // split：换向器，ab 所接的半环在 θ 一侧，cos θ > 0 时接正电刷；ring：两端直接接电源（两个滑环），电流方向不变
  function abCurrent(th, pol, comm) {
    if (comm !== 'split') return -pol;
    var c = Math.cos(th);
    if (Math.abs(c) < Math.sin(MOTOR.GAP)) return 0;
    return -pol * sgn(c);
  }
  // ab 边受力：F = I·L × B，B 沿 x，受力沿 y；返回 y 分量的符号 × 大小因子
  function sideForce(sAb, I, B, mag) { return sAb * mag * I * B; }   // ẑ × x̂ = ŷ
  // 线圈受到的力矩（z 分量，正为逆时针）
  function torque(th, p) {
    var s = abCurrent(th, p.pol, p.comm), F = sideForce(s, p.I, p.B, p.mag);
    return 2 * MOTOR.K * F * Math.cos(th);   // ab、cd 两边力臂都是 R cos θ，K 里含 R·L
  }
  // 推进一步：st = { th, w }；p = { I, B, pol, mag, comm, on }
  function motorStep(st, dt, p) {
    var n = Math.max(1, Math.ceil(dt / 0.004)), h = dt / n;
    for (var i = 0; i < n; i++) {
      var t = p.on ? torque(st.th, p) : 0;
      var a = (t - MOTOR.C * st.w) / MOTOR.J;
      if (Math.abs(st.w) < 1e-3 && Math.abs(t) <= MOTOR.F0) { st.w = 0; continue; }   // 静摩擦
      a -= MOTOR.F0 * sgn(st.w || t) / MOTOR.J;
      var w = st.w + a * h;
      if (st.w !== 0 && sgn(w) !== sgn(st.w) && Math.abs(t) <= MOTOR.F0) w = 0;
      st.w = w;
      st.th += w * h;
    }
    st.th = wrap(st.th);
    return st;
  }
  // 线圈相对平衡位置的情况
  function posInfo(th) {
    var c = Math.cos(th), d = Math.abs(c);
    if (d < Math.sin(MOTOR.GAP)) return { key: 'eq', name: '平衡位置', tip: '线圈平面与磁感线垂直' };
    if (d > Math.cos(10 * DEG)) return { key: 'par', name: '线圈平面与磁感线平行', tip: '两边受力的力臂最大，转动效果最强' };
    return { key: 'mid', name: '两位置之间', tip: '' };
  }
  // 理想稳定转速（ω，rad/s）：有换向器时平均力矩 = (2/π)·最大力矩
  function steadyW(I, B) {
    var t = 2 / Math.PI * 2 * MOTOR.K * I * B - MOTOR.F0;
    return Math.max(0, t / MOTOR.C);
  }

  // ---------- 练习 ----------
  var TYPES = ['dir', 'turn', 'pos', 'energy'];
  function pick(rand, arr) { return arr[Math.floor(rand() * arr.length) % arr.length]; }
  function shuffle(rand, arr) {
    arr = arr.slice();
    for (var i = arr.length - 1; i > 0; i--) { var j = Math.floor(rand() * (i + 1)); var t = arr[i]; arr[i] = arr[j]; arr[j] = t; }
    return arr;
  }
  var CHANGES = [
    { id: 'pol', text: '只把电源的正负极对调', p: -1, n: false },
    { id: 'mag', text: '只把蹄形磁体上下翻转（对调磁极）', p: 1, n: true },
    { id: 'both', text: '同时对调电源正负极和磁体的磁极', p: -1, n: true },
    { id: 'big', text: '只增大导体中的电流', p: 1, n: false },
    { id: 'open', text: '断开开关', p: 1, n: false, open: true }
  ];
  function quizDir(rand) {
    var pol = pick(rand, [1, -1]), nTop = rand() < 0.5, ch = pick(rand, CHANGES);
    var d0 = wireDir(pol, nTop, true), p1 = pol * ch.p, n1 = ch.n ? !nTop : nTop, d1 = wireDir(p1, n1, !ch.open);
    var name = function (d) { return d < 0 ? '向左运动' : d > 0 ? '向右运动' : '不动'; };
    var ans = name(d1);
    var explain = {
      pol: '通电导线在磁场中受力的方向跟电流方向有关：只改变电流方向，受力方向变得相反，AB ' + ans + '。',
      mag: '受力方向跟磁感线方向有关：只把磁极对调，磁感线方向相反，受力方向也相反，AB ' + ans + '。',
      both: '电流方向和磁感线方向同时变得相反，受力方向“反了再反”，与原来相同，AB 仍' + ans + '。',
      big: '受力方向只跟电流方向、磁感线方向有关，与电流大小无关；电流增大，受力变大，AB 仍' + ans + '，而且运动得更快。',
      open: '断开开关，导体中没有电流，不受磁场力，AB 不动（磁场对不通电的铜棒没有作用力）。'
    }[ch.id];
    return { type: 'dir', pol: pol, nTop: nTop, d0: d0, answer: ans, options: ['向左运动', '向右运动', '不动'],
      prompt: '如图装置，闭合开关后导体 AB ' + name(d0) + '。' + (ch.open ? '把 AB 放回中间、断开开关，AB 将？' : '若' + ch.text + '，再闭合开关，AB 将？'),
      explain: explain, show: { scene: 'wire', pol: p1, nTop: n1, closed: !ch.open } };
  }
  var TURN = {
    rev: { q: '要改变直流电动机的转动方向，可行的办法是？', right: ['对调电源的正负极', '对调磁体的两极'],
      wrong: ['同时对调电源正负极和磁体两极', '增大线圈中的电流', '换用磁性更强的磁体', '去掉换向器'],
      explain: '线圈的转动方向由受力方向决定，受力方向跟电流方向和磁感线方向有关：只改变其中一个，电动机就反转；两个同时改变，转向不变。增大电流、增强磁场只改变转速。' },
    fast: { q: '要使直流电动机转得更快，可行的办法是？', right: ['增大线圈中的电流', '换用磁性更强的磁体'],
      wrong: ['对调电源的正负极', '对调磁体的两极', '把换向器换成两个滑环', '减小电源电压'],
      explain: '线圈受力的大小跟电流大小和磁场强弱有关：增大电流（提高电压）或换用磁性更强的磁体，受力变大，转得更快。对调电源或磁极只改变转向；没有换向器线圈就不能持续转动。' }
  };
  function quizTurn(rand) {
    var k = pick(rand, ['rev', 'fast']), t = TURN[k], ans = pick(rand, t.right);
    var opts = shuffle(rand, [ans].concat(shuffle(rand, t.wrong).slice(0, 3)));
    return { type: 'turn', answer: ans, options: opts, prompt: t.q, explain: t.explain,
      show: { scene: 'motor', comm: 'split', rev: k === 'rev' } };
  }
  var BANK = {
    pos: [
      { q: '线圈转到线圈平面与磁感线垂直的位置（平衡位置）时，ab、cd 两边受到的力：', a: '大小相等、方向相反，在同一直线上',
        w: ['大小相等、方向相反，不在同一直线上', '都为零', '方向相同，使线圈加速转动'],
        e: '平衡位置时两边受力仍不为零，但它们大小相等、方向相反、作用在同一直线上（都沿竖直方向且通过转轴），是一对平衡力，不能使线圈转动。线圈靠惯性转过这个位置。', show: { scene: 'motor', comm: 'ring', angle: 90 } },
      { q: '直流电动机中换向器的作用是：', a: '线圈刚转过平衡位置时，自动改变线圈中的电流方向',
        w: ['改变磁感线的方向', '线圈到达平衡位置之前，改变线圈中的电流方向', '增大线圈中的电流'],
        e: '换向器由两个铜半环组成，通过电刷与电源相连。每当线圈刚转过平衡位置，电刷就从一个半环换到另一个半环，线圈中电流方向改变，受力方向也随之改变，使线圈继续朝原方向转动。', show: { scene: 'motor', comm: 'split' } },
      { q: '去掉换向器，把线圈两端直接接在电源上，闭合开关后线圈会：', a: '转到平衡位置附近来回摆动，最后停在平衡位置',
        w: ['持续朝一个方向转动', '一直静止不动', '转得比有换向器时更快'],
        e: '没有换向器，线圈中电流方向不变。线圈越过平衡位置后，两边受力会把它拉回来，所以线圈只能在平衡位置附近摆动几下，最后停在平衡位置。', show: { scene: 'motor', comm: 'ring' } },
      { q: '一台直流电动机接通电源后不转，用手轻轻拨一下转轴就转起来了。原因可能是：', a: '线圈刚好处在平衡位置',
        w: ['电源的正负极接反了', '磁体的磁性太强', '换向器与电刷接触不良，线圈断路'],
        e: '线圈刚好在平衡位置时，电刷正压在换向器两个半环之间的绝缘缝上（或两边受力相互平衡），线圈不能自行起动。拨一下让它离开平衡位置，就能转起来。正负极接反只会反转。', show: { scene: 'motor', angle: 90 } }
    ],
    energy: [
      { q: '电动机的工作原理是：', a: '通电线圈在磁场中受力转动',
        w: ['电磁感应现象', '电流的磁效应', '磁极间的相互作用'],
        e: '电动机是利用通电线圈在磁场中受力转动的原理制成的。电磁感应是发电机的原理；电流的磁效应用在电磁铁、电磁继电器上。', show: { scene: 'motor' } },
      { q: '电动机工作时，主要的能量转化是：', a: '电能转化为机械能',
        w: ['机械能转化为电能', '化学能转化为电能', '内能转化为机械能'],
        e: '电动机消耗电能，带动转轴转动，主要把电能转化为机械能（线圈发热还会有一小部分转化为内能）。发电机则相反，把机械能转化为电能。', show: { scene: 'motor' } },
      { q: '下列设备中，主要利用“通电导线在磁场中受到力的作用”工作的是：', a: '电风扇',
        w: ['发电机', '电磁起重机', '动圈式话筒'],
        e: '电风扇里的电动机利用通电线圈在磁场中受力转动。发电机和动圈式话筒利用电磁感应，电磁起重机利用电流的磁效应。扬声器也是利用通电线圈在磁场中受力，带动纸盆振动发声。', show: { scene: 'motor' } },
      { q: '关于直流电动机，下列说法正确的是：', a: '转子是线圈，定子是磁体',
        w: ['转速只与电流方向有关', '没有换向器也能持续转动', '工作时把机械能转化为电能'],
        e: '电动机由转子（能转动的线圈）和定子（固定不动的磁体）两部分组成。转速与电流大小、磁场强弱有关，转向与电流方向、磁场方向有关；没有换向器线圈只能在平衡位置附近摆动。', show: { scene: 'motor' } }
    ]
  };
  function quizBank(type, rand) {
    var b = pick(rand, BANK[type]);
    return { type: type, answer: b.a, options: shuffle(rand, [b.a].concat(b.w)), prompt: b.q, explain: b.e, show: b.show };
  }
  function quiz(rand, avoid, only) {
    var q;
    for (var i = 0; i < 12; i++) {
      var t = only && TYPES.indexOf(only) >= 0 ? only : pick(rand, TYPES);
      q = t === 'dir' ? quizDir(rand) : t === 'turn' ? quizTurn(rand) : quizBank(t, rand);
      q.id = q.type + '|' + q.prompt;
      if (!avoid || q.id !== avoid.id) break;
    }
    return q;
  }

  window.Motor = {
    DEG: DEG, WIRE: WIRE, MOTOR: MOTOR, TYPES: TYPES,
    clamp: clamp, sgn: sgn, wrap: wrap, cross: cross,
    fieldFrac: fieldFrac, wireDir: wireDir, wireStep: wireStep,
    abCurrent: abCurrent, sideForce: sideForce, torque: torque, motorStep: motorStep, posInfo: posInfo, steadyW: steadyW,
    quiz: quiz
  };
})();
