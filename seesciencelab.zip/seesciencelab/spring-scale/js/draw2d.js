/* 长度尺、伸长括号与指针均来自同一个静态平衡解，不模拟振荡。 */
(function () {
  'use strict';
  const gold='#ffc94a',blue='#78d6ff',muted='#93a4b9';
  let geometry={};
  function render(canvas,state,hover,drag) {
    const rect=canvas.getBoundingClientRect(),dpr=Math.min(devicePixelRatio||1,2);
    if(canvas.width!==Math.round(rect.width*dpr)||canvas.height!==Math.round(rect.height*dpr)){canvas.width=Math.round(rect.width*dpr);canvas.height=Math.round(rect.height*dpr);}
    const c=canvas.getContext('2d'),mobile=rect.width<660,W=mobile?390:960,H=mobile?630:570;
    const scale=Math.min(rect.width/W,rect.height/H),ox=(rect.width-W*scale)/2,oy=(rect.height-H*scale)/2;
    c.setTransform(dpr,0,0,dpr,0,0);c.clearRect(0,0,rect.width,rect.height);c.translate(ox,oy);c.scale(scale,scale);
    const r=Spring.solve(state),sx=mobile?119:207,top=62,zero=top+100,end=top+r.length*1000;
    function line(x,y,a,b,color,width=1,dash=[]){c.beginPath();c.setLineDash(dash);c.strokeStyle=color;c.lineWidth=width;c.moveTo(x,y);c.lineTo(a,b);c.stroke();c.setLineDash([]);}
    function text(t,x,y,color=muted,size=12,align='left'){c.font=`${size}px -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif`;c.fillStyle=color;c.textAlign=align;c.fillText(t,x,y);}
    function box(x,y,w,h,fill,stroke,rad=8){c.beginPath();c.roundRect(x,y,w,h,rad);c.fillStyle=fill;c.fill();if(stroke){c.strokeStyle=stroke;c.lineWidth=1;c.stroke();}}
    function metal(x,w){const g=c.createLinearGradient(x,0,x+w,0);g.addColorStop(0,'#4d6072');g.addColorStop(.24,'#aebdca');g.addColorStop(.45,'#d5dce1');g.addColorStop(.65,'#7e919f');g.addColorStop(1,'#3e5062');return g;}
    const left=mobile?15:62,right=mobile?375:450,base=mobile?405:428;
    box(left,12,right-left,base+66,'#0b111b','#202d3c',16);
    text('01  挂码与读数',left+18,35,'#becbdb',12);
    // 稳固实验架、透明外壳和具有金属明暗的线圈。
    box(sx-65,top-9,11,base-top+9,metal(sx-65,11),null,3);
    box(sx-70,base,160,12,metal(sx-70,160),'#435668',5);
    line(sx-59,top-9,sx+25,top-9,'#a8b9c7',7);
    c.beginPath();c.arc(sx,top+1,8,0,Math.PI*2);c.strokeStyle='#becbd5';c.lineWidth=2.5;c.stroke();
    box(sx-29,top+12,58,224,'#96c9ed08','#526f8966',14);
    line(sx-24,zero,sx+48,zero,'#a6b6c977',1,[4,4]);
    text('原长位置',sx-34,zero+4,muted,11,'right');
    const coilTop=top+14,coilBottom=end-12,turns=10;
    // 每半圈分开绘制，背面暗、正面亮，不额外改变弹簧长度。
    for(let j=0;j<turns*2;j++){
      c.beginPath();for(let i=0;i<=24;i++){const t=(j+i/24)/(turns*2),a=t*turns*Math.PI*2,x=sx+18*Math.sin(a),y=coilTop+t*(coilBottom-coilTop);if(!i)c.moveTo(x,y);else c.lineTo(x,y);}
      c.strokeStyle=j%2?'#ffe3a0':'#b98a37';c.lineWidth=3.3;c.stroke();
    }
    line(sx,coilBottom,sx,end+11,'#c7d2dc',3);
    c.beginPath();c.arc(sx+4,end+15,5,-Math.PI/2,Math.PI*.88);c.strokeStyle='#c7d2dc';c.lineWidth=2.5;c.stroke();
    // 长度尺固定0–22 cm，暖色括号仅表示多出的长度。
    const rx=sx+75;
    box(rx-7,top-3,36,228,'#182330','#3c5067',3);
    for(let i=0;i<=22;i++){const y=top+i*10;line(rx-4,y,rx+(i%5===0?9:3),y,i%5===0?'#bdcbd9':'#687b90');if(i%5===0)text(String(i),rx+14,y+4,'#c4d0dd',10);}
    text('长度 / cm',rx+8,top-14,muted,11,'center');
    line(sx+28,end,rx-8,end,gold,1.5,[3,3]);
    if(r.x>.001){line(sx+44,zero,sx+44,end,gold,2);line(sx+39,zero,sx+49,zero,gold,2);line(sx+39,end,sx+49,end,gold,2);text('x',sx+37,(zero+end)/2+4,gold,12,'right');}
    // 力刻度随弹簧标定：力相同而k不同，刻度间距也不同。
    const fx=sx+164,pointerY=zero+r.reading/r.k*1000,maxY=zero+3/r.k*1000;
    box(fx-8,zero-15,41,maxY-zero+32,'#132435','#39566e',4);
    text('力 / N',fx+11,zero-27,blue,11,'center');
    for(let i=0;i<=30;i++){const y=zero+i*.1/r.k*1000;line(fx-4,y,fx+(i%5===0?9:2),y,i%5===0?'#b7d6e6':'#5c7e96');if(i%(r.k>50?10:5)===0)text((i/10).toFixed(1),fx+13,y+3,'#bed5e4',9);}
    line(sx+22,end,fx-13,pointerY,blue,1.4);
    c.beginPath();c.moveTo(fx-12,pointerY-4);c.lineTo(fx-4,pointerY);c.lineTo(fx-12,pointerY+4);c.fillStyle=r.valid?blue:'#ff8b7b';c.fill();
    text(`${r.reading.toFixed(1)} N`,fx-16,pointerY-10,r.valid?blue:'#ff8b7b',mobile?14:16,'right');
    const massY=end+25;
    for(let i=0;i<r.count;i++){const y=massY+i*16;box(sx-26,y,52,15,metal(sx-26,52),hover==='load'?'#ffe3a0':'#7d8f9f',3);text('50 g',sx,y+11,'#152435',9,'center');}
    if(!r.count)text('空载 · 可调零',sx,end+49,muted,11,'center');
    if(hover==='load'||drag?.type==='load'){box(sx-35,end+21,70,Math.max(44,r.count*16+5),'#ffc94a08','#ffc94a88',8);}
    const trayY=base+35;
    box(sx-70,trayY-7,160,37,hover==='tray'?'#223247':'#14202d',hover==='tray'?gold:'#304459',6);
    for(let i=0;i<3;i++){box(sx-53+i*43,trayY-14,34,23,metal(sx-53+i*43,34),'#91a3b2',4);text('50g',sx-36+i*43,trayY+1,'#172b3b',9,'center');}
    text('拖到挂钩 / 点一下挂码',sx+9,trayY+22,'#b9c8d8',11,'center');
    if(drag?.type==='tray'&&drag.point){const p=drag.point;box(p.x-22,p.y-10,44,22,'#d4dce2',gold,4);text('50 g',p.x,p.y+5,'#182638',10,'center');c.beginPath();c.arc(sx,end+20,33,0,7);c.strokeStyle=gold;c.setLineDash([4,4]);c.stroke();c.setLineDash([]);}
    // 读数与图像独立区域，避免覆盖装置。
    const gx=mobile?49:535,gy=mobile?532:259,gw=mobile?292:350,gh=mobile?68:190;
    if(!mobile){
      text('02  总长 ≠ 伸长量',gx,41,'#becbdb',12);
      const y=80;
      [['原长 L₀','10.0 cm',muted],['总长 L',`${(r.length*100).toFixed(1)} cm`,'#d9e5f1'],['伸长量 x',`${(r.x*100).toFixed(1)} cm`,gold]].forEach((v,i)=>{const x=gx+i*121;box(x,y,108,69,'#101925','#253348',10);text(v[0],x+12,y+23,muted,11);text(v[1],x+12,y+49,v[2],18);});
      text(`x = ${(r.length*100).toFixed(1)} − 10.0 = ${(r.x*100).toFixed(1)} cm`,gx,181,gold,18);
      text('03  拉力与伸长量',gx,224,'#becbdb',12);
    } else {text(`总长 ${(r.length*100).toFixed(1)} − 原长 10.0 = 伸长 ${(r.x*100).toFixed(1)} cm`,195,510,gold,13,'center');}
    text('F / N',gx,gy-10,'#b7c9db',11);text(`k = ${r.k} N/m`,gx+gw,gy-10,gold,12,'right');
    for(let i=0;i<=3;i++){const y=gy+gh-i/3*gh;line(gx,y,gx+gw,y,'#b6cdef16');text(String(i),gx-11,y+4,muted,10,'right');}
    for(let i=0;i<=12;i+=2){const x=gx+i/12*gw;line(x,gy,x,gy+gh,'#b6cdef0c');text(String(i),x,gy+gh+17,muted,10,'center');}
    line(gx,gy,gx,gy+gh,'#55677f');line(gx,gy+gh,gx+gw,gy+gh,'#55677f');
    const point=(x,f)=>({x:gx+x/12*gw,y:gy+gh-f/3*gh});
    const ref=point(6,3);line(gx,gy+gh,ref.x,ref.y,'#8292aa',1.5,[5,5]);
    const final=point(3/r.k*100,3);line(gx,gy+gh,final.x,final.y,gold,2);
    state.records.forEach(row=>{const p=point(row.x*100,row.force);c.beginPath();c.arc(p.x,p.y,3.5,0,7);c.fillStyle='#d8e9ed';c.fill();});
    const q=point(r.x*100,r.force);line(q.x,gy+gh,q.x,q.y,'#ffc94a55',1,[3,4]);line(gx,q.y,q.x,q.y,'#ffc94a55',1,[3,4]);
    c.beginPath();c.arc(q.x,q.y,5,0,7);c.fillStyle=gold;c.shadowColor=gold;c.shadowBlur=12;c.fill();c.shadowBlur=0;
    text('x / cm',gx+gw+3,gy+gh+(mobile?30:34),muted,11,'right');
    if(!mobile){text('金线  当前弹簧     灰虚线  k = 50 N/m',gx,gy+gh+60,muted,11);text(state.scene==='zero'?`真实拉力 ${r.force.toFixed(1)} N · 零点偏差 ${r.bias>=0?'+':''}${r.bias.toFixed(1)} N`:'同一根弹簧：拉力加倍，伸长量也加倍',gx,gy+gh+89,blue,13);}
    geometry={scale,ox,oy,sx,end,zero,k:r.k,tray:{x:sx-70,y:trayY-20,w:160,h:54},load:{x:sx-35,y:end+7,w:70,h:Math.max(44,r.count*16+22)},point:q,graph:{gx,gy,gw,gh},mobile};return geometry;
  }
  function hit(x,y){for(const key of ['tray','load']){const r=geometry[key];if(r&&x>=r.x&&x<=r.x+r.w&&y>=r.y&&y<=r.y+r.h)return key;}return null;}
  window.SpringDraw={render,hit,get geometry(){return geometry;}};
})();
