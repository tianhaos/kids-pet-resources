/* 线性工作范围内的静态平衡；SI单位，长度读数转为cm。 */
(function () {
  'use strict';
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  function clean(s) {
    const number = (v, d) => Number.isFinite(Number(v)) ? Number(v) : d;
    return { count: Math.round(clamp(number(s.count, 4), 0, 6)), k: clamp(number(s.k, 50), 25, 75), bias: clamp(number(s.bias, 0), -.4, .4) };
  }
  function solve(s) {
    const c = clean(s), mass = c.count * .05, force = mass * 10, x = force / c.k;
    return { ...c, mass, force, x, length: .10 + x, reading: force + c.bias, valid: force + c.bias >= -1e-9 && force + c.bias <= 3 + 1e-9 };
  }
  function countAtExtension(x, k) { return Math.round(clamp(x * k / .5, 0, 6)); }
  window.Spring = { clean, solve, countAtExtension };
})();
