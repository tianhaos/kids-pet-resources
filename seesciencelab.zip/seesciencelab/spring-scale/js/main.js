(function () {
  'use strict';
  const $=id=>document.getElementById(id), canvas=$('spring');
  const params=new URLSearchParams(location.search), scenes=['hooke','compare','zero'];
  const scene=scenes.includes(params.get('scene'))?params.get('scene'):'hooke';
  const state={scene,...Spring.clean({count:params.has('count')?params.get('count'):4,k:params.has('k')?params.get('k'):(scene==='compare'?25:50),bias:params.has('bias')?params.get('bias'):(scene==='zero'?.2:0)}),records:[]};
  let hover=null,drag=null,notice='';
  function track(action,label){if(window.Analytics)Analytics.track('弹簧测力计与胡克定律',action,label);}
  function update(){
    Object.assign(state,Spring.clean(state));const r=Spring.solve(state);
    $('count').value=state.count;$('stiffness').value=state.k;$('bias').value=state.bias;
    $('countOut').textContent=state.count+' 个';$('kOut').textContent=state.k+' N/m';$('biasOut').textContent=(state.bias>=0?'+':'')+state.bias.toFixed(1)+' N';
    $('reading').textContent='示数 '+r.reading.toFixed(1)+' N'+(r.valid?'':'（量程外）');
    $('mass').textContent=(r.mass*1000).toFixed(0)+' g';$('length').textContent=(r.length*100).toFixed(1)+' cm';$('extension').textContent=(r.x*100).toFixed(1)+' cm';$('force').textContent=r.force.toFixed(1)+' N';
    $('equation').textContent=`F = kx = ${r.k} × ${r.x.toFixed(3)} = ${r.force.toFixed(1)} N`;
    $('zeroTools').hidden=state.scene!=='zero';$('zeroNote').textContent=notice||'先卸下全部钩码，再调零；挂载时不能用调零抵消负载。';
    $('stageNote').textContent=state.scene==='zero'?`真实 ${r.force.toFixed(1)} N · 零偏 ${r.bias>=0?'+':''}${r.bias.toFixed(1)} N${r.valid?'':' · 示数量程外'}`:state.scene==='compare'?'同样的拉力，换一根弹簧会伸长多少？':'挂上钩码，对照原长，观察新的平衡位置。';
    $('sceneNote').textContent={hooke:'同一根弹簧，逐个挂码；看伸长量随力成正比。',compare:'固定钩码数量，改变 k；同样的力能拉多长？',zero:'零点偏差只改变示数；弹簧形变和真实拉力不变。'}[state.scene];
    $('remove').disabled=state.count===0;$('add').disabled=state.count===6;
    document.querySelectorAll('[data-step]').forEach(b=>b.disabled=+b.dataset.step<0?state.count===0:state.count===6);
    document.querySelectorAll('[data-scene]').forEach(b=>{b.classList.toggle('on',b.dataset.scene===state.scene);b.setAttribute('aria-pressed',String(b.dataset.scene===state.scene));});
    $('records').innerHTML=state.records.length?'<table><thead><tr><th>F/N</th><th>L/cm</th><th>x/cm</th></tr></thead><tbody>'+state.records.map(row=>`<tr><td>${row.force.toFixed(1)}</td><td>${(row.length*100).toFixed(1)}</td><td>${(row.x*100).toFixed(1)}</td></tr>`).join('')+'</tbody></table>':'<p class="note">还没有记录。先卸载记下原长，再逐次加载。</p>';
  }
  function setCount(n){state.count=n;notice='';update();}
  function setK(k){state.k=k;state.records=[];update();}
  function setScene(next){if(!scenes.includes(next))return;state.scene=next;state.count=4;state.k=next==='compare'?25:50;state.bias=next==='zero'?.2:0;state.records=[];notice='';update();track('切换实验',next);}
  document.querySelectorAll('[data-scene]').forEach(b=>b.onclick=()=>setScene(b.dataset.scene));
  document.querySelectorAll('[data-step]').forEach(b=>b.onclick=()=>{setCount(state.count+Number(b.dataset.step));track('画面挂卸码',String(state.count));});
  $('add').onclick=()=>{setCount(state.count+1);track('挂码',String(state.count));};$('remove').onclick=()=>{setCount(state.count-1);track('卸码',String(state.count));};
  $('count').oninput=e=>setCount(+e.target.value);$('count').onchange=()=>track('调整数量',String(state.count));
  $('stiffness').oninput=e=>setK(+e.target.value);$('stiffness').onchange=()=>track('更换弹簧',String(state.k));
  $('bias').oninput=e=>{state.bias=+e.target.value;notice='';update();};$('bias').onchange=()=>track('零点偏差',String(state.bias));
  $('zero').onclick=()=>{if(state.count){notice='请先卸下全部钩码，避免把负载当成零点。';}else{state.bias=0;notice='已在空载状态调零，可以重新挂码。';track('调零','空载');}update();};
  $('record').onclick=()=>{const r=Spring.solve(state);if(!state.records.some(v=>v.count===r.count)){state.records.push(r);state.records.sort((a,b)=>a.count-b.count);update();track('记录',String(r.force));}};
  $('clear').onclick=()=>{state.records=[];update();};
  function link(){const p=new URLSearchParams({scene:state.scene,count:state.count,k:state.k,bias:state.bias.toFixed(1)});return location.origin+location.pathname+'?'+p;}
  $('share').onclick=async()=>{try{await navigator.clipboard.writeText(link());$('shareNote').textContent='已复制当前条件链接（不含记录表）。';track('分享',state.scene);}catch{$('shareNote').textContent=link();}};
  function local(e){const r=canvas.getBoundingClientRect(),g=SpringDraw.geometry;return{x:(e.clientX-r.left-g.ox)/g.scale,y:(e.clientY-r.top-g.oy)/g.scale};}
  canvas.onpointerdown=e=>{const p=local(e),type=SpringDraw.hit(p.x,p.y);if(!type)return;drag={type,x:p.x,y:p.y,count:state.count,moved:false,point:p};canvas.setPointerCapture(e.pointerId);e.preventDefault();};
  canvas.onpointermove=e=>{const p=local(e);hover=SpringDraw.hit(p.x,p.y);canvas.style.cursor=drag?'grabbing':hover?'grab':'default';if(drag){drag.point=p;if(Math.hypot(p.x-drag.x,p.y-drag.y)>5)drag.moved=true;if(drag.type==='load'&&drag.moved){setCount(Spring.countAtExtension(Math.max(0,(p.y-drag.y+drag.count*.5/state.k*1000)/1000),state.k));}}};
  canvas.onpointerup=e=>{if(!drag)return;const p=local(e),g=SpringDraw.geometry;if(drag.type==='tray'&&Math.abs(p.x-g.sx)<70&&p.y>90&&p.y<g.end+150){setCount(state.count+1);track('拖钩码','挂码');}else if(drag.type==='tray'&&!drag.moved){setCount(state.count+1);track('点钩码','挂码');}else if(drag.type==='load'){if(!drag.moved)setCount(state.count-1);track('拖挂载','数量'+state.count);}drag=null;hover=null;canvas.style.cursor='default';};
  canvas.onpointercancel=()=>{drag=null;hover=null;};canvas.onlostpointercapture=()=>{drag=null;};
  $('panelToggle').onclick=()=>{const closed=$('panel').classList.toggle('collapsed');$('panelToggle').setAttribute('aria-expanded',String(!closed));};
  if(matchMedia('(max-width:760px)').matches)$('panel').classList.add('collapsed');
  $('panelToggle').setAttribute('aria-expanded',String(!$('panel').classList.contains('collapsed')));
  function frame(){SpringDraw.render(canvas,state,hover,drag);requestAnimationFrame(frame);}
  window.__model={state,setScene,setCount,setK,update,solve:()=>Spring.solve(state),link};update();requestAnimationFrame(frame);
})();
