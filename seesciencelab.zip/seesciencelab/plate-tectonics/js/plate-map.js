(function () {
  const groups = {
    eurasia: { name: '亚欧板块', color: '#9b89cb', position: [70, 56], codes: ['EU'], detail: '主要对应亚欧板块主体。喜马拉雅山脉在印度大陆与亚欧大陆的汇聚带上。' },
    africa: { name: '非洲板块', color: '#c7985f', position: [13, 4], codes: ['AF', 'SO'], detail: '主体包含非洲大部及周围海底。这里把非洲主体与正在分离的索马里板块放在同一个教材组，保留东非一带的分界。' },
    america: { name: '美洲板块', color: '#69b191', position: [-92, 47], codes: ['NA', 'SA'], detail: '教材分类概括北美板块与南美板块。纳斯卡板块俯冲到南美板块之下，形成南美洲西缘的海沟与山带。' },
    pacific: { name: '太平洋板块', color: '#5c9ccf', position: [-135, -11], codes: ['PA'], detail: '主体位于太平洋下方。太平洋海盆还包含纳斯卡等其他板块。' },
    indian: { name: '印度洋板块', color: '#cb806f', position: [98, -18], codes: ['IN', 'AU'], detail: '这里按教材称为印度洋板块，合看 PB2002 的印度和澳大利亚板块，保留它们之间的分界。' },
    antarctic: { name: '南极洲板块', color: '#8ea9bd', position: [0, -72], codes: ['AN'], detail: '主体包含南极大陆及周围海底，北侧多为海底扩张边界。' },
  };
  const examples = [
    { scene: 'subduction', name: '安第斯山脉', position: [-75, -26] },
    { scene: 'collision', name: '喜马拉雅山脉', position: [85, 29] },
    { scene: 'spreading', name: '大西洋中脊', position: [-12, -35] },
  ];
  const toGroup = Object.fromEntries(Object.entries(groups).flatMap(([id, group]) => group.codes.map(code => [code, id])));

  // 经纬等距投影，路径使用 360×180 的逻辑坐标。
  function pathFor(rings) {
    const path = new Path2D();
    for (const ring of rings) {
      ring.forEach(([longitude, latitude], i) => {
        if (i === 0) path.moveTo(longitude + 180, 90 - latitude);
        else path.lineTo(longitude + 180, 90 - latitude);
      });
      path.closePath();
    }
    return path;
  }

  function create(canvas) {
    const ctx = canvas.getContext('2d');
    const coast = pathFor(window.Continents.LAND);
    const plates = window.PB2002.flatMap(([code, polygons]) =>
      polygons.map(rings => ({ id: toGroup[code], path: pathFor(rings) })));
    let width, height, current, lastHover;

    function draw(selected, hover) {
      const w = canvas.clientWidth;
      const h = canvas.clientHeight;
      if (!w || !h) return;
      const ratio = Math.min(2, window.devicePixelRatio || 1);
      if (width === w && height === h && current === selected && lastHover === hover &&
          canvas.width === Math.round(w * ratio)) return;
      width = w;
      height = h;
      current = selected;
      lastHover = hover;
      canvas.width = Math.round(w * ratio);
      canvas.height = Math.round(h * ratio);
      ctx.setTransform(canvas.width / 360, 0, 0, canvas.height / 180, 0, 0);
      ctx.fillStyle = '#142535';
      ctx.fillRect(0, 0, 360, 180);
      for (const { id, path } of plates) {
        ctx.globalAlpha = !selected || selected === id ? .78 : .27;
        ctx.fillStyle = groups[id]?.color || '#526276';
        ctx.fill(path, 'evenodd');
      }
      ctx.globalAlpha = 1;
      ctx.fillStyle = '#e0d7b5';
      ctx.globalAlpha = .27;
      ctx.fill(coast);
      ctx.globalAlpha = 1;
      ctx.strokeStyle = '#f1e5ce';
      ctx.lineWidth = .64;
      ctx.stroke(coast);
      ctx.strokeStyle = '#0c1420';
      ctx.lineWidth = .42;
      for (const { path } of plates) ctx.stroke(path);
      if (selected || groups[hover]) {
        const focus = selected || hover;
        ctx.lineWidth = 1;
        ctx.strokeStyle = groups[focus].color;
        for (const { id, path } of plates) if (focus === id) ctx.stroke(path);
      }
      ctx.strokeStyle = '#e4f3ff22';
      ctx.lineWidth = .34;
      ctx.beginPath();
      for (let i = 30; i < 360; i += 30) { ctx.moveTo(i, 0); ctx.lineTo(i, 180); }
      for (let i = 30; i < 180; i += 30) { ctx.moveTo(0, i); ctx.lineTo(360, i); }
      ctx.stroke();

      // 文字在屏幕坐标绘制，保持字形比例。
      ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.font = `600 ${w < 500 ? 10 : 13}px -apple-system, "PingFang SC", sans-serif`;
      const screen = ([x, y]) => [(x + 180) * w / 360, (90 - y) * h / 180];
      for (const [id, group] of Object.entries(groups)) {
        const [x, y] = screen(group.position);
        ctx.lineWidth = 3;
        ctx.strokeStyle = '#0b1421d9';
        ctx.fillStyle = !selected || selected === id ? '#f6f3ec' : '#b1b7be';
        ctx.strokeText(group.name, x, y);
        ctx.fillText(group.name, x, y);
      }
      for (const example of examples) {
        const [x, y] = screen(example.position);
        ctx.strokeStyle = '#110e13';
        ctx.lineWidth = 2;
        ctx.fillStyle = '#ffcf60';
        ctx.beginPath();
        ctx.arc(x, y, hover === example.scene ? 6.5 : 4.8, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
      }
    }

    function hit(clientX, clientY) {
      const box = canvas.getBoundingClientRect();
      const x = (clientX - box.left) * 360 / box.width;
      const y = (clientY - box.top) * 180 / box.height;
      if (!(x >= 0 && x <= 360 && y >= 0 && y <= 180)) return null;
      for (const example of examples) {
        const [longitude, latitude] = example.position;
        if (Math.hypot((x - longitude - 180) * box.width / 360, (y + latitude - 90) * box.height / 180) < 18) {
          return example.scene;
        }
      }
      ctx.save();
      ctx.resetTransform();
      const plate = plates.find(item => ctx.isPointInPath(item.path, x, y, 'evenodd'));
      ctx.restore();
      return plate?.id || null;
    }

    return { draw, hit };
  }

  window.TectonicsMap = { groups, examples, create };
})();
