// 教学剖面的无量纲几何。x 沿剖面向右，y 向上，z 向观察者。
(function () {
  const scenes = {
    subduction: {
      name: '海陆俯冲',
      place: '秘鲁—智利海沟 · 安第斯山脉',
      motion: '大洋板块向大陆汇聚并向下俯冲',
      sequence: ['大洋板块接近大陆', '大洋板块下弯', '海沟与大陆山带并列'],
      features: [
        { id: 'trench', label: '海沟', color: '#78e3fc', text: '大洋板块开始下弯，海底在大陆边缘附近形成狭长的深凹。' },
        { id: 'slab', label: '俯冲板片', color: '#98b9ff', text: '较密的大洋岩石圈沿边界斜向下沉。俯冲的是岩石圈，包含地壳和上地幔顶部。' },
        { id: 'arc', label: '大陆山带', color: '#ffc694', text: '海沟陆侧可同时出现隆升和火山活动。俯冲板片释放的水等挥发分有助于上方地幔岩石部分熔融。' },
      ],
    },
    collision: {
      name: '大陆碰撞',
      place: '印度大陆与亚欧大陆 · 喜马拉雅山脉',
      motion: '两侧大陆向中间汇聚，地壳缩短并增厚',
      sequence: ['两块大陆开始接触', '地壳缩短增厚', '高山与深部山根形成'],
      features: [
        { id: 'mountain', label: '碰撞山脉', color: '#ffc694', text: '喜马拉雅山脉主要由大陆碰撞导致的挤压、缩短和隆升形成。' },
        { id: 'root', label: '增厚地壳', color: '#f5bc86', text: '地壳增厚时，向上隆起的地形下方也可发育向深部伸展的山根。' },
        { id: 'suture', label: '碰撞带', color: '#ffd86c', text: '这里从大陆接触开始观察。现实中碰撞可伴随断层、褶皱和大陆岩石圈的下插。' },
      ],
    },
    spreading: {
      name: '海底扩张',
      place: '大西洋中脊 · 以南大西洋为例',
      motion: '两侧大洋板块背离洋中脊，新增洋壳向两侧移开',
      sequence: ['扩张中心已有洋脊', '新生洋壳向两侧移开', '靠近洋脊的洋壳最年轻'],
      features: [
        { id: 'ridge', label: '洋中脊', color: '#8cf1f5', text: '海底扩张中心附近岩石圈较热、较薄，海底相对两侧隆起。' },
        { id: 'melt', label: '岩浆补给', color: '#ffb07a', text: '地幔上涌时减压，可发生部分熔融。岩浆在扩张中心冷却凝固形成新洋壳。' },
        { id: 'stripes', label: '较早形成的洋壳', color: '#91b4ff', text: '同一对颜色标记在中脊两侧同时形成。拖动进程，比较它们离中脊的距离。' },
      ],
    },
    map: { name: '六大板块', place: '教材六大板块与真实地理实例', motion: '', sequence: [], features: [] },
  };
  const clamp = value => Math.max(0, Math.min(1, value));
  const gauss = (value, width) => Math.exp(-Math.pow(value / width, 2));
  const trench = -1.8;
  const edge = 11;
  const halfDepth = 3.5;
  const floor = -8.9;
  const sea = -.48;
  const phases = ['起始', '演化中', '充分发展'];

  // 山带沿边界延伸，横向与沿走向起伏使山脊有可辨认的三维轮廓。
  function relief(x, z) {
    const jitter = Math.sin(z * 1.14) * .46 + Math.sin(z * 2.55) * .17;
    return .82 + .16 * Math.cos(z * 1.35 + x * .9) + .09 * Math.sin(z * 2.9 - x * 1.7) + .07 * Math.cos(x * 5.7 + z * 3.4 + jitter);
  }

  function slab(x, progress) {
    const bend = .28 + .72 * progress;
    const ocean = -1.3 - 1.55 * bend * gauss(x - trench, 1.8);
    const after = Math.max(0, x - trench);
    return ocean - bend * (1 - Math.exp(-after / 2.15)) * after * 1.12;
  }

  function oceanHeight(x, z) {
    return -1.47 + 1.07 * gauss(x, 3.5) - .26 * gauss(x, .38) +
      .11 * Math.sin(x * 2.8 + z * 2.3) * Math.min(1, Math.abs(x));
  }

  function profile(scene, side, x, z, progress) {
    if (scene === 'subduction') {
      if (side === 'left') {
        const surface = slab(x, progress);
        return { surface, crust: surface - .39, base: surface - 1.08 };
      }
      const fromEdge = Math.max(0, x - trench);
      const wheat = .31 + .30 * relief(x, z) + (.45 + progress * 2.05) * gauss(x - 3.65 - .385 * Math.sin(z), 2.65) * relief(x, z);
      const coast = 1 - Math.exp(-fromEdge * .65);
      const surface = slab(trench, progress) * (1 - coast) + wheat * coast;
      const base = Math.max(surface - 3.59 * coast, slab(x, progress));
      return { surface, crust: surface - (surface - base) * .54, base };
    }
    if (scene === 'collision') {
      const center = x - .25 * Math.sin(z * 1.3);
      const uplift = progress * (3.25 * gauss(center, 2.75) + .66 * gauss(Math.abs(center) - 3.1, .8));
      const surface = .22 + .28 * relief(x, z) + uplift * relief(x, z);
      const crust = surface - 1.74 - progress * 4.65 * gauss(x, 3.2);
      return { surface, crust, base: crust - 1.41 };
    }
    const surface = oceanHeight(x, z);
    const thickness = .45 + Math.abs(x) * .135;
    return { surface, crust: surface - .32, base: surface - thickness };
  }

  function ranges(scene, progress) {
    if (scene === 'subduction') return [[-edge, trench + 5.05 + (1 - progress) * 1.3], [trench, edge]];
    return [[-edge, 0], [0, edge]];
  }

  function anchors(scene, progress) {
    const front = halfDepth + .04;
    if (scene === 'subduction') return [
      [trench - .26, slab(trench, progress), front],
      [trench + 3.8, slab(trench + 3.8, progress) - .2, front],
      [3.55, profile(scene, 'right', 3.55, 1.1, progress).surface, 1.1],
    ];
    if (scene === 'collision') return [
      [-.15, profile(scene, 'left', -.15, 0, progress).surface, 0],
      [1.15, profile(scene, 'right', 1.15, front, progress).crust + .25, front],
      [0, profile(scene, 'right', 0, -.4, progress).surface, -.4],
    ];
    return [
      [0, oceanHeight(0, 1), 1],
      [0, -3.25, front],
      [stripeDistance(progress, 1), oceanHeight(stripeDistance(progress, 1), front), front],
    ];
  }

  // 对称的年龄标记与板块运动同向。这里只表达相对年龄。
  function stripeDistance(progress, index) {
    return 1.0 + index * 2.65 + progress * 2.39;
  }

  function phase(progress) {
    return progress < .2 ? 0 : progress < .64 ? 1 : 2;
  }

  window.Tectonics = { scenes, clamp, profile, ranges, anchors, stripeDistance, phase, phases, trench, edge, halfDepth, floor, sea };
})();
