(function () {
  const T = window.Tectonics;
  const M = window.TectonicsMap;
  const byId = id => document.getElementById(id);
  const range = byId('progress');
  const stage = byId('stage');
  const canvas = byId('plateMap');
  const map = M.create(canvas);
  const params = new URLSearchParams(location.search);
  const initialScene = params.get('scene');
  const initialPlate = params.get('plate');
  const rawProgress = params.get('p');
  const parsedProgress = rawProgress === null || rawProgress.trim() === '' ? NaN : Number(rawProgress);
  const state = {
    scene: Object.hasOwn(T.scenes, initialScene) ? initialScene : 'subduction',
    progress: Number.isFinite(parsedProgress) ? T.clamp(parsedProgress / 100) : .78,
    playing: params.get('play') === '1',
    plate: Object.hasOwn(M.groups, initialPlate) ? initialPlate : null,
    hover: null,
    feature: null,
    time: 0,
  };
  const track = (action, label) => window.Analytics?.track('板块构造与六大板块', action, label);
  let world = null;
  try {
    world = window.TectonicsScene.create(byId('world'));
  } catch {
    byId('unavailable').hidden = false;
  }
  const tabs = [...stage.querySelectorAll('[data-scene]')];
  const legendItems = {
    subduction: [['#629eb5', '大洋地壳'], ['#b48c68', '大陆地壳'], ['#4d5670', '岩石圈地幔'], ['#684d42', '软流层']],
    collision: [['#b48c68', '大陆地壳'], ['#6e4449', '岩石圈地幔'], ['#684d42', '软流层']],
    spreading: [['#629eb5', '大洋地壳'], ['#3c5574', '岩石圈地幔'], ['#684d42', '软流层'], ['#b46042', '熔融区示意']],
  };
  const offsets = {
    subduction: [[-45, -35], [7, 34], [32, -37]],
    collision: [[-64, -41], [4, 42], [59, -8]],
    spreading: [[-50, -42], [-29, 39], [55, -17]],
  };
  let pins = [];
  let lastPhase;
  const mobile = matchMedia('(max-width: 760px)');
  const panel = byId('panel');
  const panelToggle = byId('panelToggle');
  const panelClose = byId('panelClose');

  function button(text, css, action) {
    const control = document.createElement('button');
    control.type = 'button';
    control.className = css;
    control.textContent = text;
    control.addEventListener('click', action);
    return control;
  }

  function syncPanel() {
    const expanded = !panel.classList.contains('collapsed');
    panel.inert = mobile.matches && !expanded;
    panelToggle.setAttribute('aria-expanded', String(expanded));
  }

  function setPanel(expanded) {
    panel.classList.toggle('collapsed', !expanded);
    syncPanel();
    (expanded ? panelClose : panelToggle).focus({ preventScroll: true });
  }

  panelToggle.addEventListener('click', () => setPanel(panel.classList.contains('collapsed')));
  panelClose.addEventListener('click', () => setPanel(false));
  panel.addEventListener('keydown', event => {
    if (event.key === 'Escape' && mobile.matches) setPanel(false);
  });
  mobile.addEventListener('change', syncPanel);

  function chooseFeature(id, userAction = false) {
    const feature = T.scenes[state.scene].features.find(item => item.id === id);
    if (!feature) return;
    if (id === state.feature && userAction) {
      state.feature = null;
    } else {
      state.feature = id;
      if (userAction) track('点选剖面', feature.label);
    }
    const active = state.feature === id;
    for (const pin of pins) {
      const on = pin.feature.id === state.feature;
      pin.control.setAttribute('aria-pressed', String(on));
      pin.listButton.setAttribute('aria-pressed', String(on));
    }
    byId('featureText').textContent = active ? feature.text : '选择图中的标注，观察对应的岩层与地貌。';
    byId('captionLabel').textContent = active ? feature.label : T.scenes[state.scene].sequence[T.phase(state.progress)];
    byId('captionText').textContent = active ? feature.text : T.scenes[state.scene].motion;
  }

  function setupFeatures() {
    const container = byId('tags');
    const list = byId('featureList');
    const legend = byId('legend');
    container.replaceChildren();
    list.replaceChildren();
    legend.replaceChildren();
    state.feature = null;
    byId('featureText').textContent = '选择图中的标注，观察对应的岩层与地貌。';
    pins = T.scenes[state.scene].features.map(feature => {
      const label = document.createElement('div');
      label.className = 'pin';
      label.style.setProperty('--mark', feature.color);
      const dot = document.createElement('span');
      dot.className = 'pin-dot';
      const leader = document.createElement('span');
      leader.className = 'pin-leader';
      const select = () => chooseFeature(feature.id, true);
      const control = button(feature.label, 'pin-button', select);
      const listButton = button(feature.label, 'action', select);
      control.setAttribute('aria-pressed', 'false');
      listButton.setAttribute('aria-pressed', 'false');
      label.append(dot, leader, control);
      container.append(label);
      list.append(listButton);
      return { feature, label, leader, control, listButton };
    });
    for (const [color, label] of legendItems[state.scene]) {
      const item = document.createElement('li');
      const swatch = document.createElement('span');
      swatch.style.background = color;
      item.append(swatch, label);
      legend.append(item);
    }
  }

  function layoutPins() {
    const anchors = T.anchors(state.scene, state.progress);
    const tags = byId('tags');
    pins.forEach(({ label, leader, control }, index) => {
      const [x, y] = world.project(anchors[index]);
      const visible = x >= 5 && y >= 5 && x < tags.clientWidth - 5 && y < tags.clientHeight - 5;
      label.hidden = !visible;
      if (!visible) return;
      const [dx, dy] = offsets[state.scene][index];
      const half = control.offsetWidth / 2;
      const targetX = Math.max(half + 6, Math.min(tags.clientWidth - half - 6, x + dx));
      const targetY = Math.max(23, Math.min(tags.clientHeight - 23, y + dy));
      const xOffset = targetX - x;
      const yOffset = targetY - y;
      label.style.transform = `translate(${x}px,${y}px)`;
      leader.style.width = Math.hypot(xOffset, yOffset) + 'px';
      leader.style.transform = `rotate(${Math.atan2(yOffset, xOffset)}rad)`;
      control.style.transform = `translate(${xOffset}px,${yOffset}px) translate(-50%,-50%)`;
    });
  }

  const plateButtons = new Map();
  function syncMap() {
    for (const [id, b] of plateButtons) b.setAttribute('aria-pressed', String(state.plate === id));
    const selected = M.groups[state.plate];
    const hover = M.examples.find(item => item.scene === state.hover)?.name || M.groups[state.hover]?.name;
    byId('mapTip').textContent = hover || selected?.name || '点板块高亮 · 点金色标记查看剖面';
    byId('plateDescription').textContent = selected?.detail ||
      '比较彩色板块范围与海岸线。大西洋中脊在宽阔的海洋中，安第斯山带则紧邻南美洲西岸。';
  }

  function choosePlate(id, userAction = false) {
    if (id !== null && !Object.hasOwn(M.groups, id)) return;
    state.plate = state.plate === id ? null : id;
    syncMap();
    if (id && userAction) track('点选板块', M.groups[id].name);
  }

  for (const [id, group] of Object.entries(M.groups)) {
    const b = button(group.name, 'action plate-button', () => choosePlate(id, true));
    b.style.setProperty('--swatch', group.color);
    byId('plateButtons').append(b);
    plateButtons.set(id, b);
  }

  function openExample(scene) {
    track('地理实例', T.scenes[scene].place);
    setScene(scene);
  }

  for (const example of M.examples) {
    byId('exampleButtons').append(button(example.name, 'action', () => openExample(example.scene)));
  }

  canvas.addEventListener('pointermove', event => {
    const hover = map.hit(event.clientX, event.clientY);
    if (state.hover === hover) return;
    state.hover = hover;
    canvas.style.cursor = hover ? 'pointer' : 'default';
    syncMap();
  });
  canvas.addEventListener('pointerleave', () => { state.hover = null; syncMap(); });
  canvas.addEventListener('click', event => {
    const id = map.hit(event.clientX, event.clientY);
    if (M.examples.some(example => example.scene === id)) openExample(id);
    else choosePlate(id, true);
  });

  function syncTimeline() {
    const phase = T.phase(state.progress);
    const percent = Math.round(state.progress * 100);
    stage.style.setProperty('--progress', percent + '%');
    range.value = percent;
    range.setAttribute('aria-valuetext', T.phases[phase] + '，' + percent + '%');
    const play = byId('play');
    const text = state.playing ? '暂停' : state.progress >= 1 ? '重播' : '播放';
    if (play.textContent !== text) play.textContent = text;
    if (lastPhase === phase) return;
    lastPhase = phase;
    byId('phase').textContent = T.phases[phase];
    if (state.feature === null) {
      byId('captionLabel').textContent = T.scenes[state.scene].sequence[phase];
      byId('captionText').textContent = T.scenes[state.scene].motion;
    }
  }

  function setScene(scene, initial = false) {
    if (!Object.hasOwn(T.scenes, scene) || !initial && state.scene === scene) return;
    const isMap = scene === 'map';
    state.scene = scene;
    state.hover = null;
    if (!initial) {
      state.progress = .78;
      state.playing = false;
      state.time = 0;
      track('切换场景', T.scenes[scene].name);
    }
    if (state.progress >= 1 || isMap) state.playing = false;
    byId('sceneTitle').textContent = T.scenes[scene].name;
    byId('scenePlace').textContent = T.scenes[scene].place;
    for (const tab of tabs) tab.setAttribute('aria-pressed', String(tab.dataset.scene === scene));
    for (const id of ['mapView', 'mapControls', 'mapPanel']) byId(id).hidden = !isMap;
    for (const id of ['world', 'tags', 'crossControls', 'crossPanel']) byId(id).hidden = isMap;
    byId('unavailable').hidden = isMap || Boolean(world);
    byId('resetView').disabled = !world;
    if (isMap) syncMap();
    else {
      setupFeatures();
      lastPhase = undefined;
      syncTimeline();
    }
  }

  function setProgress(value) {
    if (!Number.isFinite(value)) return;
    state.playing = false;
    state.progress = T.clamp(value);
    syncTimeline();
  }

  for (const tab of tabs) tab.addEventListener('click', () => setScene(tab.dataset.scene));
  range.addEventListener('input', () => setProgress(Number(range.value) / 100));
  range.addEventListener('change', () => track('拖动演化进程', T.scenes[state.scene].name));
  byId('play').addEventListener('click', () => {
    state.playing = !state.playing;
    if (state.playing && state.progress >= 1) {
      state.progress = 0;
      state.time = 0;
    }
    if (state.playing) track('播放演化', T.scenes[state.scene].name);
    syncTimeline();
  });
  byId('resetView').addEventListener('click', () => world?.reset());

  setScene(state.scene, true);
  syncPanel();
  let lastTime = performance.now();
  function frame(now) {
    const dt = Math.min((now - lastTime) / 1000, .05);
    lastTime = now;
    if (state.playing) {
      state.time += dt;
      state.progress = T.clamp(state.progress + dt / 11);
      if (state.progress === 1) state.playing = false;
      syncTimeline();
    }
    if (state.scene === 'map') map.draw(state.plate, state.hover);
    else if (world) {
      world.render(state.scene, state.progress, state.time);
      layoutPins();
    }
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
  window.__model = { state, setScene, setProgress, chooseFeature, choosePlate, world };
})();
