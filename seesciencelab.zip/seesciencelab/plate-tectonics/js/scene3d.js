(function () {
  const T = window.Tectonics;
  const THREE = window.THREE;
  const rock = new THREE.Color('#64504d');
  const abyss = new THREE.Color('#31475d');
  const basalt = new THREE.Color('#508da7');
  const coast = new THREE.Color('#779265');
  const granite = new THREE.Color('#9b7b66');
  const ridgeColor = new THREE.Color('#75b9ba');
  const snow = new THREE.Color('#ecedea');

  function surfaceColor(scene, side, x, y, z, target) {
    if (scene === 'subduction' && side === 'right' || scene === 'collision') {
      if (y < T.sea) target.copy(abyss).lerp(coast, T.clamp((y + 2.7) * .24));
      else target.copy(coast).lerp(granite, T.clamp((y - .27) / 1.75)).lerp(snow, T.clamp((y - 2.07) / .95));
    } else {
      target.copy(abyss).lerp(basalt, T.clamp((y + 2.65) / 2.8));
      if (scene === 'spreading') target.lerp(ridgeColor, .22 * Math.exp(-x * x / 8));
    }
    const grain = Math.sin(x * 8.9 + z * 1.8) * Math.sin(z * 8.2 - x * 2.8);
    return target.multiplyScalar(.95 + grain * .075);
  }

  function material(options = {}) {
    return new THREE.MeshStandardMaterial({ side: THREE.DoubleSide, roughness: .94, ...options });
  }

  // 网格保留顶点索引，只更新高度与材料色。
  function grid(group, nx, nz, surfaceMaterial) {
    const width = nx + 1;
    const geometry = new THREE.BufferGeometry();
    const positions = new Float32Array(width * (nz + 1) * 3);
    const colors = new Float32Array(positions.length);
    const indices = [];
    for (let j = 0; j < nz; j++) {
      for (let i = 0; i < nx; i++) {
        const a = j * width + i;
        indices.push(a, a + width, a + 1, a + width, a + width + 1, a + 1);
      }
    }
    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3).setUsage(THREE.DynamicDrawUsage));
    if (surfaceMaterial.vertexColors) geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    geometry.setIndex(indices);
    const mesh = new THREE.Mesh(geometry, surfaceMaterial);
    mesh.frustumCulled = false;
    group.add(mesh);
    return function update(sample) {
      const point = new THREE.Vector3();
      const color = new THREE.Color();
      for (let j = 0; j <= nz; j++) {
        for (let i = 0; i <= nx; i++) {
          sample(i / nx, j / nz, point, color);
          const offset = (j * width + i) * 3;
          point.toArray(positions, offset);
          color.toArray(colors, offset);
        }
      }
      geometry.attributes.position.needsUpdate = true;
      if (geometry.attributes.color) geometry.attributes.color.needsUpdate = true;
      geometry.computeVertexNormals();
    };
  }

  function polyline(group, count, color, opacity = 1) {
    const geometry = new THREE.BufferGeometry();
    const positions = new Float32Array(count * 3);
    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    const line = new THREE.Line(geometry, new THREE.LineBasicMaterial({ color, transparent: opacity < 1, opacity }));
    line.frustumCulled = false;
    group.add(line);
    return sample => {
      for (let i = 0; i < count; i++) positions.set(sample(i / (count - 1)), i * 3);
      geometry.attributes.position.needsUpdate = true;
    };
  }

  function layerColor(scene, side, layer) {
    if (layer === 'mantle') return '#684d42';
    if (scene === 'subduction' && side === 'left' || scene === 'spreading') {
      return layer === 'crust' ? '#629eb5' : '#3c5574';
    }
    if (layer === 'crust') return side === 'left' ? '#a47d5c' : '#b48c68';
    return side === 'left' ? '#633f42' : '#6e4449';
  }

  function createBlock(group, scene, side) {
    const surface = grid(group, 84, 24, material({ vertexColors: true }));
    const shell = [];
    const front = T.halfDepth + (scene === 'subduction' && side === 'left' ? .075 : 0);
    const layers = [
      ['crust', 'surface', 'crust'],
      ['lithosphere', 'crust', 'base'],
      ['mantle', 'base', 'floor'],
    ];
    for (const [layer, top, bottom] of layers) {
      const color = new THREE.Color(layerColor(scene, side, layer));
      const face = material({ vertexColors: true });
      for (const endpoint of ['front', 'back', 'outer', 'inner']) {
        if (endpoint === 'inner' && (scene === 'collision' || scene === 'subduction' && side === 'right')) continue;
        shell.push({ update: grid(group, endpoint === 'front' || endpoint === 'back' ? 84 : 24, 8, face),
          endpoint, color, top, bottom, mantle: layer === 'mantle' });
      }
    }
    const stripes = Array.from({ length: 7 }, (_, index) =>
      polyline(group, 85, index % 2 ? '#d8a681' : '#2d202b', .35));
    const seam = polyline(group, 35, '#f3c08a', .64);

    return function update(progress, [start, end]) {
      const sample = (x, z) => T.profile(scene, side, x, z, progress);
      const longitude = t => THREE.MathUtils.lerp(start, end, t);
      surface((u, v, point, color) => {
        const x = longitude(u);
        const z = THREE.MathUtils.lerp(-T.halfDepth, front, v);
        const y = sample(x, z).surface;
        point.set(x, y, z);
        surfaceColor(scene, side, x, y, z, color);
      });
      for (const { update, endpoint, color, top, bottom, mantle } of shell) {
        update((u, v, point, tint) => {
          const onCut = endpoint === 'front' || endpoint === 'back';
          const inward = (endpoint === 'outer') === (side === 'left') ? 0 : 1;
          const sectionEnd = mantle && scene === 'subduction' && side === 'left' ? T.trench : end;
          const x = THREE.MathUtils.lerp(start, sectionEnd, onCut ? u : inward);
          let z = onCut ? (endpoint === 'front' ? front : -T.halfDepth) : THREE.MathUtils.lerp(-T.halfDepth, front, u);
          if (endpoint === 'front' && mantle) z = T.halfDepth - .017;
          const values = sample(x, z);
          const lower = bottom === 'floor' ? T.floor : values[bottom];
          const y = THREE.MathUtils.lerp(values[top], lower, v);
          const grain = Math.sin(x * 25.17 + y * 17.4 + z * 12) * Math.cos(x * 14.4 - y * 21);
          const fade = mantle ? T.clamp((-y - 3) / (-T.floor - 3)) : v;
          tint.copy(color).multiplyScalar(.98 - fade * .13 + grain * .065);
          if (mantle) tint.lerp(rock, fade * .77);
          point.set(x, y, z);
        });
      }
      stripes.forEach((draw, index) => draw(t => {
        const x = longitude(t);
        const values = sample(x, front);
        const thin = scene === 'spreading' || scene === 'subduction' && side === 'left';
        const y = THREE.MathUtils.lerp(values.surface, thin ? values.base : values.crust, (index + 1) / 8);
        const r = Math.min(.075, (values.surface - values.base) * .06);
        return [x, y + r * Math.sin(x * (thin ? .52 : 1.9) + index * .5), front + .014];
      }));
      seam(t => {
        const z = THREE.MathUtils.lerp(-T.halfDepth, front, t);
        return [side === 'left' ? end : start, sample(side === 'left' ? end : start, z).surface + .018, z];
      });
    };
  }

  function water(group, scene) {
    const surface = grid(group, 36, 10, material({
      color: '#2794c7', transparent: true, opacity: .27, depthWrite: false,
    }));
    const frontWall = grid(group, 42, 6, material({
      color: '#2496c8', transparent: true, opacity: .31, depthWrite: false,
    }));
    const line = polyline(group, 42, '#83dff8', .64);
    const ripples = Array.from({ length: 26 }, (_, index) =>
      polyline(group, 12, index % 2 ? '#6dd1ef' : '#a9e5f1', .17));
    const level = scene === 'spreading' ? .27 : T.sea;
    return progress => {
      const shorelineAt = z => {
        if (scene === 'spreading') return T.edge;
        let start = T.trench;
        let end = 3;
        for (let i = 0; i < 13; i++) {
          const mid = (start + end) / 2;
          if (T.profile(scene, 'right', mid, z, progress).surface < T.sea) start = mid;
          else end = mid;
        }
        return (start + end) / 2;
      };
      const floorAt = (x, z) => T.profile(scene, x < (scene === 'subduction' ? T.trench : 0) ? 'left' : 'right', x, z, progress).surface;
      surface((u, v, point) => {
        const z = THREE.MathUtils.lerp(-T.halfDepth, T.halfDepth, v);
        point.set(THREE.MathUtils.lerp(-T.edge, shorelineAt(z), u), level + .012, z);
      });
      const front = T.halfDepth + .105;
      const coast = shorelineAt(front);
      frontWall((u, v, point) => {
        const x = THREE.MathUtils.lerp(-T.edge, coast, u);
        point.set(x, THREE.MathUtils.lerp(Math.min(level, floorAt(x, front)), level, v), front);
      });
      line(t => [THREE.MathUtils.lerp(-T.edge, coast, t), level + .02, front]);
      ripples.forEach((draw, i) => draw(t => {
        const v = (i * .6180339) % 1;
        const z = -3.2 + v * 6.3;
        const x = THREE.MathUtils.lerp(-10.2, shorelineAt(z) - 1.2, (i * .3821) % 1);
        return [x + t * (.22 + i % 5 * .14), level + .04 + .013 * Math.sin(t * 3 + i), z + .055 * t];
      }));
    };
  }

  function markerBands(group) {
    const tracks = [];
    for (const direction of [-1, 1]) {
      for (let i = 0; i < 4; i++) {
        const band = grid(group, 4, 26, material({
          color: ['#76e4e4', '#7ba3c5', '#466c9e', '#60698e'][i],
          transparent: true, opacity: .84, depthWrite: false,
        }));
        tracks.push({ direction, i, band });
      }
    }
    return progress => {
      for (const { direction, i, band } of tracks) {
        const center = T.stripeDistance(progress, i);
        band((u, v, point) => {
          const x = direction * Math.min(T.edge, center + (u - .5) * .3);
          const z = THREE.MathUtils.lerp(-T.halfDepth, T.halfDepth, v);
          point.set(x, T.profile('spreading', 'left', x, z, progress).surface + .045, z);
        });
      }
    };
  }

  function meltZone(group) {
    const area = new THREE.Shape();
    area.moveTo(0, -1.18);
    area.bezierCurveTo(.28, -2.8, 1.25, -3.25, 1.32, -4.08);
    area.bezierCurveTo(.59, -4.82, -.64, -4.85, -1.39, -4.2);
    area.bezierCurveTo(-1.29, -3.12, -.4, -2.63, 0, -1.18);
    const partialMelt = new THREE.Mesh(new THREE.ShapeGeometry(area, 20), material({
      color: '#b46042', emissive: '#3b190e', transparent: true, opacity: .79,
    }));
    partialMelt.position.z = T.halfDepth + .03;
    group.add(partialMelt);
    const magma = polyline(group, 15, '#ffbc81', .9);
    magma(t => [Math.sin(t * 8) * .13 * (1 - t), -4.5 + t * 3.8, T.halfDepth + .2]);
  }

  function flow(group, scene) {
    const arrows = [];
    const head = new THREE.ConeGeometry(.145, .31, 10);
    const tail = new THREE.CylinderGeometry(.046, .046, .52, 8);
    const up = new THREE.Vector3(0, 1, 0);
    for (const side of ['left', 'right']) {
      const color = side === 'left' || scene === 'spreading' ? '#9deafa' : '#ffd38c';
      for (let index = 0; index < 3; index++) {
        const arrow = new THREE.Group();
        const paint = new THREE.MeshBasicMaterial({ color, transparent: true });
        const tip = new THREE.Mesh(head, paint);
        tip.position.y = .33;
        arrow.add(tip, new THREE.Mesh(tail, paint));
        group.add(arrow);
        arrows.push({ arrow, paint, side, index });
      }
    }
    return (progress, time) => {
      const z = T.halfDepth + .23;
      for (const { arrow, paint, side, index } of arrows) {
        const sign = side === 'left' ? -1 : 1;
        const along = ((index + .44) / 3 + time * .27) % 1;
        paint.opacity = .81 * Math.min(1, along * 10, (1 - along) * 10);
        const inSlab = scene === 'subduction' && side === 'left';
        const outward = scene === 'spreading';
        const x = inSlab ? -10.3 + along * (T.ranges(scene, progress)[0][1] + 9.85) :
          sign * (1.2 + (outward ? along : 1 - along) * 8.7);
        const yAt = s => T.profile(scene, side, s, T.halfDepth, progress).surface;
        const inside = inSlab || outward;
        const y = yAt(x) + (inside ? -.57 : .55);
        const direction = inSlab ? 1 : outward ? sign : -sign;
        const dy = Math.max(-.73, Math.min(.73, yAt(x + .5 * direction) - yAt(x - .5 * direction)));
        arrow.position.set(x, y, z);
        arrow.quaternion.setFromUnitVectors(up, new THREE.Vector3(direction, dy, 0).normalize());
      }
    };
  }

  function create(host) {
    const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true, powerPreference: 'low-power' });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.8));
    renderer.outputEncoding = THREE.LinearEncoding;
    host.append(renderer.domElement);

    const world = new THREE.Scene();
    const camera = new THREE.OrthographicCamera();
    const target = new THREE.Vector3(0, -2.88, 0);
    const controls = new THREE.OrbitControls(camera, renderer.domElement);
    controls.enablePan = false;
    controls.enableDamping = true;
    controls.dampingFactor = .15;
    controls.minZoom = .72;
    controls.maxZoom = 2.6;
    controls.minPolarAngle = .2;
    controls.maxPolarAngle = 1.53;
    const hemi = new THREE.HemisphereLight('#e2edf9', '#67505a', 1.07);
    const key = new THREE.DirectionalLight('#fff0d9', .97);
    key.position.set(-8, 14, 9);
    const rim = new THREE.DirectionalLight('#aac5f1', .32);
    rim.position.set(8, 6, -8);
    world.add(hemi, key, rim);

    const blocks = {};
    let current, lastProgress, lastTime;
    let dirty = true;
    controls.addEventListener('change', () => { dirty = true; });
    let width = 0;
    let height = 0;
    const projected = new THREE.Vector3();
    function reset() {
      dirty = true;
      controls.enableDamping = false;
      controls.update();
      camera.position.copy(target).add(new THREE.Vector3(5.6, 8.7, 28));
      controls.target.copy(target);
      camera.zoom = 1;
      camera.updateProjectionMatrix();
      controls.update();
      controls.enableDamping = true;
    }

    function select(scene) {
      if (current === scene) return;
      if (current) blocks[current].group.visible = false;
      current = scene;
      lastProgress = undefined;
      if (!blocks[scene]) {
        const group = new THREE.Group();
        const left = createBlock(group, scene, 'left');
        const right = createBlock(group, scene, 'right');
        const sea = scene !== 'collision' && water(group, scene);
        const bands = scene === 'spreading' && markerBands(group);
        if (scene === 'spreading') meltZone(group);
        const move = flow(group, scene);
        blocks[scene] = { group, left, right, sea, bands, move };
        world.add(group);
      }
      blocks[scene].group.visible = true;
      reset();
    }

    function render(scene, progress, time) {
      select(scene);
      const w = host.clientWidth;
      const h = host.clientHeight;
      if (!w || !h) return;
      if (width !== w || height !== h) {
        dirty = true;
        width = w;
        height = h;
        const viewHeight = Math.max(14.7, 25.1 * height / width);
        camera.left = -viewHeight * width / height / 2;
        camera.right = -camera.left;
        camera.top = viewHeight / 2;
        camera.bottom = -camera.top;
        camera.near = .1;
        camera.far = 100;
        camera.updateProjectionMatrix();
        renderer.setSize(width, height);
      }
      const block = blocks[scene];
      if (lastProgress !== progress) {
        const [left, right] = T.ranges(scene, progress);
        block.left(progress, left);
        block.right(progress, right);
        if (block.sea) block.sea(progress);
        if (block.bands) block.bands(progress);
        lastProgress = progress;
        dirty = true;
      }
      if (lastTime !== time || dirty) block.move(progress, time);
      controls.update();
      if (dirty || lastTime !== time) renderer.render(world, camera);
      dirty = false;
      lastTime = time;
    }

    function project([x, y, z]) {
      projected.set(x, y, z).project(camera);
      return [(projected.x + 1) * width / 2, (1 - projected.y) * height / 2];
    }

    reset();
    return { render, project, reset, camera, controls };
  }

  window.TectonicsScene = { create };
})();
