/* 房屋剖面与完整并联线路；所有尺寸等比投影，非施工接线图。 */
(function () {
  'use strict';
  let frame={scale:1,x:0,y:0},hits=[];
  const C={live:'#ff927e',neutral:'#6dbde8',gold:'#ffd16c',ink:'#e6edf6',dim:'#8d9db1'};
  const reduced=matchMedia('(prefers-reduced-motion: reduce)');
  function point(canvas,e){const r=canvas.getBoundingClientRect();return {x:(e.clientX-r.left-frame.x)/frame.scale,y:(e.clientY-r.top-frame.y)/frame.scale};}
  function hit(p){return hits.find(h=>p.x>=h.x&&p.x<=h.x+h.w&&p.y>=h.y&&p.y<=h.y+h.h);}
  function draw(canvas,s,t,hover){
    if(reduced.matches)t=0;
    const r=canvas.getBoundingClientRect(),dpr=Math.min(devicePixelRatio||1,2),mobile=r.width<650,W=mobile?480:800,H=mobile?690:590;
    if(canvas.width!==Math.round(r.width*dpr)||canvas.height!==Math.round(r.height*dpr)){canvas.width=Math.round(r.width*dpr);canvas.height=Math.round(r.height*dpr);}
    const c=canvas.getContext('2d');c.setTransform(dpr,0,0,dpr,0,0);c.fillStyle='#05070d';c.fillRect(0,0,r.width,r.height);
    const scale=Math.min(r.width/W,(r.height-12)/H);frame={scale,x:(r.width-W*scale)/2,y:(r.height-H*scale)/2};c.translate(frame.x,frame.y);c.scale(scale,scale);hits=[];
    function box(x,y,w,h,fill,stroke,rad=8){c.beginPath();c.roundRect(x,y,w,h,rad);c.fillStyle=fill;c.fill();if(stroke){c.strokeStyle=stroke;c.lineWidth=1;c.stroke();}}
    function line(p,color,width=2){c.beginPath();p.forEach((v,i)=>i?c.lineTo(...v):c.moveTo(...v));c.strokeStyle=color;c.lineWidth=width;c.lineCap='round';c.stroke();}
    function text(str,x,y,size=14,color=C.ink,align='left'){c.font=`${size}px -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif`;c.fillStyle=color;c.textAlign=align;c.fillText(str,x,y);}
    function circle(x,y,rad,fill){c.beginPath();c.arc(x,y,rad,0,Math.PI*2);c.fillStyle=fill;c.fill();}
    function wire(p,color,on,I){
      line(p,on?color:'#3a4658',on?Math.min(6,2+Math.sqrt(I)*.5):2);
      if(on)for(let j=1;j<p.length;j++){const a=p[j-1],b=p[j],len=Math.hypot(b[0]-a[0],b[1]-a[1]);for(let k=18;k<len-6;k+=30){const u=(k+Math.sin(t*2)*7)/len;circle(a[0]+(b[0]-a[0])*u,a[1]+(b[1]-a[1])*u,1.8,'#fff0c8');}}
    }
    const powered=!s.tripped,warning=powered&&s.danger,progress=s.demoProgress||0,L=52,N=W-36,top=mobile?161:155,bottom=mobile?579:461;
    text('把电流的路，看进房间里',28,33,mobile?20:18);
    text('点选电器，独立控制每一条支路',28,57,14,C.dim);
    // 电表与保护装置保持在房屋外，接入火线总线。
    box(28,77,W-56,60,'#101722','#2b384c',10);
    text('总电流',44,99,13,C.dim);text(s.I.toFixed(2)+' A',44,124,mobile?22:18,C.gold);
    const sx=mobile?195:280;
    text(s.tripped?'已断开':s.kind==='正常'?'正常供电':s.kind+' · 保护演示',sx,101,15,s.tripped?C.dim:warning?C.live:'#8ed9b4');
    text('220 V 交流  /  16 A 教学阈值',sx,123,12,C.dim);
    // 房屋剖面：冷色墙体、暖色灯光、家具与楼板。
    line([[24,top+23],[W/2,top-15],[W-24,top+23]],'#536580',3);
    box(29,top+23,W-58,bottom-top+24,'#111b29','#344257',3);
    const floorH=mobile?190:250,rows=mobile?2:1;
    for(let row=0;row<rows;row++){
      const y=top+38+row*floorH;
      const grad=c.createLinearGradient(0,y,0,y+floorH-10);grad.addColorStop(0,'#1b2939');grad.addColorStop(1,'#131c29');box(67,y,W-120,floorH-12,grad,null,2);
      line([[67,y+floorH-12],[W-53,y+floorH-12]],'#596273',5);
      // 细窗框与远景，不遮挡接线。
      box(W-130,y+58,53,62,'#0b1728','#354c68',2);line([[W-104,y+59],[W-104,y+119]],'#354c68',1);line([[W-129,y+89],[W-78,y+89]],'#354c68',1);
      box(81,y+floorH-55,55,27,'#293548',null,5);box(76,y+floorH-39,64,17,'#364154',null,3);
    }
    const ys=mobile?[top+55,top+245]:[top+55];
    // 每层的火、零线分别连到同一对总线，支路均跨接L/N。
    if(warning&&s.kind==='过载'){
      c.save();c.globalAlpha=.18+progress*.3;c.shadowColor=C.live;c.shadowBlur=10+progress*15;line([[L,top+65],[L,bottom]],C.live,9+progress*8);c.restore();
    }
    wire([[L,top-1],[L,bottom]],C.live,powered,s.I);wire([[N,top+64],[N,bottom]],C.neutral,powered,s.I);
    text('L 火线',87,top+45,13,C.live);text('N 零线',N+13,top+43,13,C.neutral,'right');
    ys.forEach(y=>{wire([[L,y+10],[N-23,y+10]],C.live,powered,s.I);wire([[L+23,y+(mobile?164:218)],[N,y+(mobile?164:218)]],C.neutral,powered,s.I);});
    s.branches.forEach((b,i)=>{
      const row=mobile?Math.floor(i/2):0,col=mobile?i%2:i,x=mobile?153+col*171:154+col*166,y=ys[row],on=powered&&b.on,cy=y+(mobile?88:111),end=y+(mobile?164:218);
      if(hover==='load'+i)box(x-60,y+23,120,end-y-30,'#ffffff07',C.gold,10);
      wire([[x,y+10],[x,y+32]],C.live,on,b.I);circle(x,y+32,3,C.live);circle(x,y+49,3,C.live);
      line(b.on?[[x,y+32],[x,y+49]]:[[x,y+32],[x+13,y+43]],b.on?C.live:C.dim,3);
      wire([[x,y+49],[x,cy-21]],C.live,on,b.I);wire([[x,cy+29],[x,end]],C.neutral,on,b.I);
      if(i===0){
        if(on){const g=c.createRadialGradient(x,cy,3,x,cy,70);g.addColorStop(0,'#ffc94a42');g.addColorStop(1,'#ffc94a00');box(x-70,cy-65,140,140,g);}
        line([[x,cy-34],[x,cy-20]],'#97a5b8',2);c.beginPath();c.moveTo(x-29,cy+3);c.lineTo(x-15,cy-20);c.lineTo(x+15,cy-20);c.lineTo(x+29,cy+3);c.closePath();c.fillStyle=on?'#ffda86':'#627084';c.fill();circle(x,cy+7,10,on?'#fff0c1':'#344053');
      }else if(i===1){
        box(x-24,cy-22,48,49,on?'#b6c7d0':'#5f7083','#d1dce3',13);line([[x+25,cy-15],[x+37,cy-13],[x+37,cy+11],[x+25,cy+13]],'#91a6b8',5);line([[x-22,cy-10],[x-35,cy-18],[x-27,cy+5]],'#91a6b8',5);box(x-29,cy+27,60,6,'#38495f');circle(x+11,cy+13,3,on?C.gold:'#263346');
        if(on)for(let k=0;k<2;k++)line([[x-9+k*16,cy-28],[x-12+k*16+Math.sin(t*2+k)*3,cy-38],[x-7+k*16,cy-49]],'#bdcfdf',1.5);
      }else if(i===2){
        box(x-34,cy-23,68,49,'#3f4c60','#7a8b9e',5);for(let k=0;k<6;k++)box(x-26+k*10,cy-16,4,32,on?'#ffac70':'#1b2534',null,2);line([[x-26,cy+26],[x-30,cy+33]],C.dim,3);line([[x+26,cy+26],[x+30,cy+33]],C.dim,3);
      }else{box(x-29,cy-16,58,43,on?'#c0b8a7':'#687383','#d1d3d4',13);box(x-29,cy-21,58,8,'#8094a6',null,3);box(x-11,cy-27,22,6,'#c1cdd5',null,3);circle(x,cy+13,4,on?C.gold:'#263346');}
      // 标签底板隔开线路与文字；数值不覆盖物体。
      box(x-61,end-47,122,41,'#111a28ee',null,5);text(b.name+' · '+b.P+' W',x,end-30,14,C.ink,'center');text(b.I.toFixed(2)+' A'+(b.on?'':' · 关'),x,end-12,13,on?C.gold:C.dim,'center');
      hits.push({id:'load'+i,x:x-62,y:y+22,w:124,h:end-y-27});
    });
    // 配电箱置于总线前；触点真正断开火线，零线连续。
    box(32,top-1,40,54,'#9ba9ba',hover==='protect'?C.gold:'#c7d1df',5);box(41,top+7,22,33,'#253247',null,3);line(s.tripped?[[47,top+30],[58,top+15]]:[[46,top+23],[58,top+23]],s.tripped?C.dim:C.gold,5);
    text('总开关',87,top+24,12,C.dim);hits.push({id:'protect',x:24,y:top-7,w:56,h:66});
    if(s.scene==='short'){
      const fy=bottom+16;wire([[L,bottom],[L,fy],[N,fy],[N,bottom]],C.live,powered,s.faultI);
      box(W/2-77,fy-14,154,28,'#38232a',C.live,5);text('L / N 低阻跨接 · 2 Ω',W/2,fy+5,13,C.live,'center');
    }
    const footer=mobile?636:528;
    if(warning){box(28,footer-10,W-56,4,'#263246',null,2);if(progress>0)box(28,footer-10,(W-56)*Math.min(1,progress),4,C.live,null,2);}
    text(s.tripped?'开关断开 → 灯灭、电器停、各支路 0 A':s.scene==='short'?'短路：电流沿额外低阻通路绕过电器':s.kind==='过载'?'过载：支路仍经过电器，总电流叠加过大':'并联：关掉一只电器，其他支路仍工作',W/2,footer+13,14,s.tripped?C.dim:warning?C.live:C.gold,'center');
    text(warning?(s.demoPlaying?'教学慢放中 · 可暂停检查通路':'演示已暂停 · 点继续观察保护动作'):'点电器开 / 关 · 点总开关断电',W/2,footer+37,13,C.dim,'center');
    text(warning&&s.kind==='过载'?'主线光晕仅示发热增加，不表示真实温度':'光点往复示通路；灰线表示无电流，不表示无电压',W/2,footer+58,11,C.dim,'center');
  }
  window.HouseDraw={draw,point,hit,get frame(){return frame;}};
})();
