(function () {
  'use strict';
  const $=id=>document.getElementById(id),q=new URLSearchParams(location.search),H=window.HouseCircuit;
  const state=H.clean({scene:q.get('scene'),mask:q.has('mask')?q.get('mask'):undefined,tripped:q.get('trip')});
  let hover='',records=[],solution;
  const demo={elapsed:0,playing:q.get('play')!=='0',cause:state.tripped?(['手动断开','过载保护跳闸','短路保护跳闸'].includes(q.get('cause'))?q.get('cause'):'保护断开'):''};
  const canvas=$('house');
  function track(action,label){if(window.Analytics)window.Analytics.track('家庭电路',action,label||'');}
  function update(){
    Object.assign(state,H.clean(state));solution=H.solve(state);
    document.querySelectorAll('[data-scene]').forEach(b=>{b.classList.toggle('on',b.dataset.scene===state.scene);b.setAttribute('aria-pressed',b.dataset.scene===state.scene);});
    $('status').textContent=state.tripped?demo.cause+' · 全屋断电':solution.kind+(solution.danger?' · 将自动跳闸':' · 供电中');
    $('current').textContent=solution.I.toFixed(2)+' A';
    $('meterFill').style.width=Math.min(100,solution.I/24*100)+'%';
    $('panel').dataset.state=state.tripped?'off':solution.danger?'danger':'normal';$('power').textContent=solution.P+' W';$('fault').textContent=solution.faultI.toFixed(2)+' A';
    $('reason').textContent=state.tripped?'开关已断开，照明熄灭、电器停止、电流归零。先减小负载，再重新演示；改变电器不会自动重合闸。':state.scene==='short'?'低阻通路绕过电器，保护快速断开；为看清路径已作教学慢放。':solution.danger?'总电流过大使主线发热增加，持续过载后保护自动断开。演示时间不是真实跳闸时间。':'总电流等于各开启支路电流之和。';
    H.loads.forEach((l,i)=>{const b=$('load'+i);b.classList.toggle('on',!!(state.mask&1<<i));b.setAttribute('aria-pressed',!!(state.mask&1<<i));b.querySelector('small').textContent=solution.branches[i].I.toFixed(2)+' A';});
    $('protect').disabled=state.tripped;$('protect').textContent=state.tripped?'线路已断开':'立即手动断开';
    $('pause').textContent=demo.playing?'暂停演示':'继续演示';
    $('pause').disabled=state.tripped||!solution.danger;
  }
  H.loads.forEach((l,i)=>{const b=document.createElement('button');b.id='load'+i;b.innerHTML='<span class=load-switch aria-hidden=true></span><span>'+l.name+'<em>'+l.P+' W</em></span><small></small>';b.onclick=()=>toggle(i);$('loads').append(b);});
  function toggle(i){state.mask^=1<<i;demo.elapsed=0;track('电器开关',H.loads[i].name);update();}
  function setScene(scene){Object.assign(state,H.clean({scene}));Object.assign(demo,{elapsed:0,playing:true,cause:''});track('切换场景',scene);update();}
  function protect(cause='手动断开'){if(!state.tripped){state.tripped=true;demo.cause=cause;track('断开',cause);update();}}
  document.querySelectorAll('[data-scene]').forEach(b=>b.onclick=()=>setScene(b.dataset.scene));
  $('protect').onclick=()=>protect();$('reset').onclick=()=>{state.tripped=false;Object.assign(demo,{elapsed:0,playing:true,cause:''});track('重新演示');update();};
  $('pause').onclick=()=>{demo.playing=!demo.playing;track('演示',demo.playing?'继续':'暂停');update();};
  function link(){const u=new URL(location.href);u.search='';u.searchParams.set('scene',state.scene);u.searchParams.set('mask',state.mask);u.searchParams.set('trip',state.tripped?'1':'0');u.searchParams.set('play','0');if(state.tripped)u.searchParams.set('cause',demo.cause);u.hash='';return u.href;}
  $('share').onclick=async()=>{const url=link();try{await navigator.clipboard.writeText(url);$('shareNote').textContent='已复制当前条件';}catch(e){$('shareNote').textContent=url;}track('分享条件');};
  $('record').onclick=()=>{records.unshift(solution.kind+' / '+(state.tripped?'断开':'接通')+' / '+solution.P+' W / '+solution.I.toFixed(2)+' A');records=records.slice(0,6);renderRecords();track('记录');};
  function renderRecords(){$('records').replaceChildren(...records.map(r=>{const p=document.createElement('p');p.textContent=r;return p;}));}
  $('clear').onclick=()=>{records=[];renderRecords();};
  if(matchMedia('(max-width:760px)').matches)$('panel').classList.add('collapsed');
  $('panelToggle').setAttribute('aria-expanded',String(!$('panel').classList.contains('collapsed')));
  $('panelToggle').onclick=()=>$('panelToggle').setAttribute('aria-expanded',String(!$('panel').classList.toggle('collapsed')));
  canvas.addEventListener('pointermove',e=>{const h=HouseDraw.hit(HouseDraw.point(canvas,e));hover=h?h.id:'';canvas.style.cursor=h?'pointer':'default';});
  canvas.addEventListener('pointerleave',()=>hover='');
  canvas.addEventListener('pointerdown',e=>{const h=HouseDraw.hit(HouseDraw.point(canvas,e));hover=h?h.id:'';});
  canvas.addEventListener('pointerup',e=>{if(e.pointerType==='touch')hover='';});
  canvas.addEventListener('click',e=>{const h=HouseDraw.hit(HouseDraw.point(canvas,e));if(h){if(h.id==='protect')protect();else toggle(+h.id.slice(4));}});
  // 面板提供同等键盘可达操作，画面是直接点选的补充。
  function advance(dt){const next=H.advanceDemo(state,demo,dt);Object.assign(demo,next.demo);if(next.trip)protect(solution.kind+'保护跳闸');}
  update();let last=0;function loop(t){const dt=last?Math.min(.1,(t-last)/1000):0;last=t;if(!document.hidden)advance(dt);HouseDraw.draw(canvas,{...solution,demoProgress:demo.elapsed/H.demoDuration(solution),demoPlaying:demo.playing,tripCause:demo.cause},t/1000,hover);requestAnimationFrame(loop);}requestAnimationFrame(loop);
  window.__model={state,demo,advance,update,setScene,toggle,protect,solve:()=>H.solve(state),link};
})();
