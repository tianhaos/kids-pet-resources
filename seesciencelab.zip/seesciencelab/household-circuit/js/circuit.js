/* 纯计算：有效值电路，不碰DOM。功率W、电压V、电流A、电阻Ω。 */
(function () {
  'use strict';
  const loads = [
    { name:'照明', P:60 }, { name:'电水壶', P:1500 },
    { name:'电暖器', P:2000 }, { name:'电饭煲', P:1000 }
  ];
  const scenes = ['normal','overload','short'];
  function clean(s) {
    const scene = scenes.includes(s.scene) ? s.scene : 'normal';
    const mask = Number.isInteger(+s.mask) && +s.mask >= 0 && +s.mask <= 15 ? +s.mask : scene === 'overload' ? 15 : 3;
    return { scene, mask, tripped: s.tripped === true || s.tripped === '1' };
  }
  function solve(input) {
    const s = clean(input), U=220, limit=16, faultR=2;
    const branches=loads.map((l,i)=>({...l,R:U*U/l.P,on:!!(s.mask & 1<<i),I:!s.tripped&&(s.mask & 1<<i)?l.P/U:0}));
    const selectedP=branches.reduce((a,l)=>a+(l.on?l.P:0),0);
    const faultI=s.scene==='short'&&!s.tripped?U/faultR:0;
    const I=branches.reduce((a,l)=>a+l.I,0)+faultI;
    const prospectiveI=selectedP/U+(s.scene==='short'?U/faultR:0);
    return { ...s,U,limit,faultR,branches,selectedP,P:s.tripped?0:selectedP,faultI,I,prospectiveI,
      danger:prospectiveI>limit,kind:s.scene==='short'?'短路':selectedP/U>limit?'过载':'正常' };
  }
  // 教学时间轴仅用于看清过程，既不是热模型，也不是断路器动作曲线。
  function demoDuration(s) { return s.kind==='短路'?2.5:8; }
  function advanceDemo(input, demo, dt) {
    const s=solve(input),next={...demo};
    if(s.tripped || !s.danger) { next.elapsed=0; return {demo:next,trip:false}; }
    if(!next.playing) return {demo:next,trip:false};
    next.elapsed=Math.min(demoDuration(s),Math.max(0,next.elapsed)+Math.max(0,dt));
    return {demo:next,trip:next.elapsed>=demoDuration(s)};
  }
  window.HouseCircuit={loads,scenes,clean,solve,demoDuration,advanceDemo};
})();
