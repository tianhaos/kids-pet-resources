// 从同一个三维地平坐标系绘制观测视野与全天星图。
(function () {
  const { clamp, direction, angles } = window.NightSky;
  const { DEG } = window.Astro;
  const GOLD = '#ffc94a';
  const INK = '#dceafb';
  const GRID = '#7999c2';
  const dot = (a, b) => a.x * b.x + a.y * b.y + a.z * b.z;
  const compass = ['北', '东北', '东', '东南', '南', '西南', '西', '西北'];
  const colors = ['#b8d6ff', '#edf4ff', '#ffe9ce', '#ffc497'];

  function perspective(width, height, view) {
    const forward = direction(view.yaw, view.pitch);
    const right = direction(view.yaw + 90, 0);
    const up = direction(view.yaw + 180, 90 - view.pitch);
    const focal = Math.min(height, width * 1.02) / (2 * Math.tan(view.fov * DEG / 2));
    const centerY = height / 2 + Math.max(0, height - width * 1.25) * 0.08;
    return {
      level: centerY + focal * Math.tan(view.pitch * DEG),
      project(v) {
        const depth = dot(v, forward);
        if (depth <= 0.05) return null;
        return { x: width / 2 + focal * dot(v, right) / depth, y: centerY - focal * dot(v, up) / depth };
      }
    };
  }

  function allSky(width, height) {
    const r = Math.min(width * 0.405, height * 0.325);
    const x = width / 2;
    const y = height * 0.43;
    return {
      x, y, r,
      project(v) {
        const horizontal = Math.hypot(v.x, v.y);
        if (horizontal < 1e-9) return v.z > 0 ? { x, y } : null;
        const scale = Math.acos(clamp(v.z, -1, 1)) / (Math.PI / 2) * r / horizontal;
        // 星图仰视，北在上，东在左。
        return { x: x - v.x * scale, y: y - v.y * scale };
      }
    };
  }

  function stroke(ctx, a, b, color, width = 1) {
    ctx.strokeStyle = color;
    ctx.lineWidth = width;
    ctx.beginPath();
    ctx.moveTo(a.x, a.y);
    ctx.lineTo(b.x, b.y);
    ctx.stroke();
  }

  function circle(ctx, x, y, radius, color, fill = true) {
    ctx.beginPath();
    ctx.arc(x, y, radius, 0, Math.PI * 2);
    if (fill) {
      ctx.fillStyle = color;
      ctx.fill();
    } else {
      ctx.strokeStyle = color;
      ctx.lineWidth = 1;
      ctx.stroke();
    }
  }

  function lineOnSky(ctx, points, project, color, width = 1) {
    ctx.beginPath();
    let started = false;
    for (const v of points) {
      const p = v.z >= -0.000001 ? project(v) : null;
      if (!p) {
        started = false;
      } else if (started) {
        ctx.lineTo(p.x, p.y);
      } else {
        ctx.moveTo(p.x, p.y);
        started = true;
      }
    }
    ctx.strokeStyle = color;
    ctx.lineWidth = width;
    ctx.stroke();
  }

  // 大圆弧在地平线处的交点。局部透视中的大圆投影是直线。
  function clipPair(a, b) {
    if (a.z < 0 && b.z < 0) return [];
    if (a.z >= 0 && b.z >= 0) return [a, b];
    const t = a.z / (a.z - b.z);
    const x = a.x + (b.x - a.x) * t;
    const y = a.y + (b.y - a.y) * t;
    const length = Math.hypot(x, y);
    const edge = { x: x / length, y: y / length, z: 0 };
    return a.z < 0 ? [edge, b] : [a, edge];
  }

  function arc(ctx, a, b, project, color) {
    const clipped = clipPair(a, b);
    if (!clipped.length) return;
    const [first, last] = clipped;
    const points = Array.from({ length: 13 }, (_, i) => {
      const t = i / 12;
      const x = first.x + (last.x - first.x) * t;
      const y = first.y + (last.y - first.y) * t;
      const z = first.z + (last.z - first.z) * t;
      const length = Math.hypot(x, y, z);
      return { x: x / length, y: y / length, z: z / length };
    });
    lineOnSky(ctx, points, project, color, 1.25);
  }

  function skyGradient(ctx, width, height, level, day) {
    const gradient = ctx.createLinearGradient(0, 0, 0, clamp(level, 1, height));
    gradient.addColorStop(0, '#050a19');
    gradient.addColorStop(0.55, '#0c1b37');
    gradient.addColorStop(1, '#25435b');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);
    if (day <= 0) return;
    const light = ctx.createLinearGradient(0, 0, 0, clamp(level, 1, height));
    light.addColorStop(0, '#21477c');
    light.addColorStop(0.65, '#5d93ba');
    light.addColorStop(1, '#e4c193');
    ctx.globalAlpha = day;
    ctx.fillStyle = light;
    ctx.fillRect(0, 0, width, height);
    ctx.globalAlpha = 1;
  }

  function landscape(ctx, width, height, level, day, yaw) {
    if (level >= height) return;
    const depth = height - level;
    const ground = ctx.createLinearGradient(0, level, 0, height);
    ground.addColorStop(0, day > 0.55 ? '#496e70' : '#152b3a');
    ground.addColorStop(0.38, '#142838');
    ground.addColorStop(1, '#060b15');
    ctx.fillStyle = ground;
    ctx.fillRect(0, level, width, depth);
    // 山岸在几何地平线下，叠加不同起伏和远近的轮廓。
    for (let layer = 0; layer < 4; layer++) {
      ctx.beginPath();
      ctx.moveTo(0, height);
      for (let x = 0; x <= width + 3; x += 3) {
        const u = (x - width / 2) / Math.max(480, width) + yaw / 280;
        const ridge = (Math.sin(u * 9 + layer) + Math.sin(u * 24 + layer * 1.8) * 0.48 +
          Math.sin(u * 51 - layer * 2) * 0.16 + Math.sin(u * 118) * 0.07) / 3.5 + 0.5;
        const rise = depth * (0.06 + layer * 0.24 + ridge * (0.18 + 0.065 * layer));
        ctx.lineTo(x, level + rise);
      }
      ctx.lineTo(width, height);
      ctx.closePath();
      ctx.fillStyle = day > 0.55
        ? ['#42646d', '#305563', '#244150', '#102233'][layer]
        : ['#233d4d', '#162e41', '#0c1d2e', '#070f1e'][layer];
      ctx.fill();
    }
  }

  function grid(ctx, frame, state) {
    const { project, map, width, height, level } = frame;
    if (map) {
      circle(ctx, map.x, map.y, map.r, '#9db9d7', false);
      for (const fraction of [1 / 3, 2 / 3]) {
        circle(ctx, map.x, map.y, map.r * fraction, '#839ec740', false);
      }
      stroke(ctx, { x: map.x - map.r, y: map.y }, { x: map.x + map.r, y: map.y }, '#839ec740');
      stroke(ctx, { x: map.x, y: map.y - map.r }, { x: map.x, y: map.y + map.r }, '#839ec740');
    } else if (level < height) {
      stroke(ctx, { x: 0, y: level }, { x: width, y: level }, '#a3c7e47a');
    }
    ctx.font = '600 12px system-ui';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = INK;
    const step = map ? 2 : 1;
    for (let i = 0; i < compass.length; i += step) {
      const p = map ? project(direction(i * 45, -10)) : project(direction(i * 45, 0));
      if (!p || p.x < 14 || p.x > width - 14 || p.y > height - 15) continue;
      const angularDistance = Math.abs(((i * 45 - state.view.yaw + 540) % 360) - 180);
      ctx.fillStyle = map || angularDistance > 22.5 ? INK : GOLD;
      const offset = frame.level > height - 135 ? -14 : 15;
      ctx.fillText(compass[i], p.x, p.y + (map ? 0 : offset));
    }
  }

  function labels(ctx, items, frame) {
    const used = [];
    const { width, height } = frame;
    ctx.textAlign = 'left';
    ctx.textBaseline = 'middle';
    for (const { p, title, color, size } of items) {
      if (!p || p.x < 9 || p.x > width - 9 || p.y < 25 || p.y > height - 12) continue;
      ctx.font = `600 ${size}px system-ui`;
      const textWidth = ctx.measureText(title).width;
      const candidates = [
        [p.x + 9, p.y - 11], [p.x - textWidth - 9, p.y - 11],
        [p.x + 9, p.y + 13], [p.x - textWidth - 9, p.y + 13]
      ];
      for (const [x, y] of candidates) {
        if (x < 8 || x + textWidth > width - 8 || y < 16 || y > height - 9) continue;
        if (used.some(r => x < r.right + 5 && x + textWidth > r.x - 5 && Math.abs(y - r.y) < 19)) continue;
        used.push({ x, y, right: x + textWidth });
        ctx.strokeStyle = '#060e1c';
        ctx.lineWidth = 3.5;
        ctx.lineJoin = 'round';
        ctx.strokeText(title, x, y);
        ctx.fillStyle = color;
        ctx.fillText(title, x, y);
        break;
      }
    }
  }

  function draw(canvas, state, sky) {
    const ctx = canvas.getContext('2d');
    const width = canvas.clientWidth;
    const height = canvas.clientHeight;
    if (!width || !height) return [];
    const ratio = Math.min(window.devicePixelRatio || 1, 2);
    const pixels = [Math.round(width * ratio), Math.round(height * ratio)];
    if (canvas.width !== pixels[0] || canvas.height !== pixels[1]) {
      canvas.width = pixels[0];
      canvas.height = pixels[1];
    }
    ctx.setTransform(ratio, 0, 0, ratio, 0, 0);

    const map = state.scene === 'season' ? allSky(width, height) : null;
    const camera = map || perspective(width, height, state.view);
    const { project } = camera;
    const level = map ? height : camera.level;
    const frame = { width, height, map, level, project };
    const light = clamp((sky.sun + 14) / 16, 0, 1);
    const dark = 1 - clamp((sky.sun + 15) / 13, 0, 1);
    ctx.fillStyle = '#080f1e';
    ctx.fillRect(0, 0, width, height);
    ctx.save();
    if (map) {
      ctx.beginPath();
      ctx.arc(map.x, map.y, map.r, 0, Math.PI * 2);
      ctx.clip();
    }
    skyGradient(ctx, width, height, level, light);
    if (!map) landscape(ctx, width, height, level, light, state.view.yaw);

    const info = [];
    const hits = [];
    if (dark > 0.025) {
      ctx.globalAlpha = dark;
      if (state.lines) drawPatterns(ctx, sky, project, info);
      if (state.track) {
        ctx.setLineDash([4, 5]);
        lineOnSky(ctx, sky.orbit, project, '#ffc94a8c', 1.3);
        ctx.setLineDash([]);
      }
      for (const { star, v } of sky.stars) {
        if (v.z < 0) continue;
        const p = project(v);
        if (!p || p.x < 0 || p.x > width || p.y < 0 || p.y > height) continue;
        const color = colors[star.color];
        const radius = clamp(2.45 - star.mag * 0.29, 0.5, 3.15);
        const opacity = dark * clamp(1.42 - star.mag * 0.19, 0.28, 1);
        if (star.mag < 2.65) {
          const halo = ctx.createRadialGradient(p.x, p.y, radius * 0.6, p.x, p.y, radius * 4.3);
          halo.addColorStop(0, color + '70');
          halo.addColorStop(1, color + '00');
          ctx.globalAlpha = opacity;
          circle(ctx, p.x, p.y, radius * 4.3, halo);
        }
        ctx.globalAlpha = opacity;
        circle(ctx, p.x, p.y, radius, color);
        if (star.name) hits.push({ ...p, id: star.id });
        if (star.id === state.selected || star.id === state.hover) {
          circle(ctx, p.x, p.y, star.id === state.selected ? 8 : 7, GOLD, false);
          info.unshift({ p, title: star.name, color: GOLD, size: 13 });
        } else if (star.name && (star.mag < 1 || star.id === 11767)) {
          info.push({ p, title: star.name, color: INK, size: 12 });
        }
      }
      ctx.globalAlpha = 1;
    }
    ctx.restore();
    grid(ctx, frame, state);
    if (state.guide) drawPole(ctx, sky, frame, info);
    labels(ctx, info, frame);
    return hits;
  }

  function drawPatterns(ctx, sky, project, info) {
    for (const pattern of sky.patterns) {
      for (const [a, b] of pattern.edges) arc(ctx, a, b, project, pattern.color + '95');
      const center = pattern.caption.z > 0.015 ? project(pattern.caption) : null;
      info.push({ p: center, title: pattern.name + (pattern.complete ? '' : '（部分）'), color: pattern.color, size: 13 });
    }
    const { approach, pointer } = sky;
    if (approach) {
      ctx.setLineDash([5, 4]);
      arc(ctx, pointer, approach, project, '#ffc94a9a');
      ctx.setLineDash([]);
    }
  }

  function drawPole(ctx, sky, frame, info) {
    const { project, map, width, height } = frame;
    if (sky.pole.z < 0) return;
    const point = project(sky.pole);
    if (!point || point.x < 15 || point.x > width - 15 || point.y < 13 || point.y > height - 12) return;
    const pole = angles(sky.pole);
    const axis = sky.north ? 0 : 180;
    const base = project(direction(axis, 0));
    ctx.setLineDash([3, 5]);
    if (base) stroke(ctx, base, point, '#ffc94a7a');
    ctx.setLineDash([]);
    stroke(ctx, { x: point.x - 5, y: point.y }, { x: point.x + 5, y: point.y }, GOLD);
    stroke(ctx, { x: point.x, y: point.y - 5 }, { x: point.x, y: point.y + 5 }, GOLD);
    if (!map && base && Math.abs(point.y - base.y) > 25) {
      info.unshift({
        p: { x: base.x + 4, y: (base.y + point.y) / 2 },
        title: pole.alt.toFixed(0) + '°', color: GOLD, size: 14
      });
    }
  }

  window.NightSkyDraw = { draw, allSky, perspective };
})();
