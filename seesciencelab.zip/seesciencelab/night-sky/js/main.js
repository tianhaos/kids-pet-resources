// 协调观测状态、星图、播放和鼠标、触摸、键盘输入。
(function () {
  const Astro = window.Astro;
  const Sky = window.NightSky;
  const { stars, patterns } = window.NightSkyStars;
  const Draw = window.NightSkyDraw;
  const $ = id => document.getElementById(id);
  const canvas = $('sky');
  const panel = $('panel');
  const query = new URLSearchParams(location.search);
  const compact = matchMedia('(max-width: 760px)');
  const byId = new Map(stars.map(star => [star.id, { ...star, ...Sky.equatorial(star.ra, star.dec) }]));
  const equatorial = Array.from(byId.values());
  const presets = {
    spring: '北斗在北方高处，狮子座靠近南方高处。',
    summer: '从东半边天空找织女星、牛郎星和天津四。',
    autumn: '从南方高处往东找由飞马座与仙女座亮星组成的四边形。',
    winter: '面向南方，在参宿四和参宿七之间找三颗腰带星。'
  };
  const places = [
    { lat: 80, name: '北纬 80°' }, { lat: 40, name: '北纬 40°' },
    { lat: 0, name: '赤道' }, { lat: -35, name: '南纬 35°' }
  ];

  function numberParam(name, fallback, min, max) {
    const value = query.get(name);
    const number = Number(value);
    return value !== null && value.trim() && Number.isFinite(number) ? Sky.clamp(number, min, max) : fallback;
  }

  const initial = query.get('scene') === 'season' ? 'season' : 'north';
  const terms = Astro.TERMS;
  const firstTerm = terms.find(term => term.key === query.get('term')) || terms[initial === 'north' ? 0 : 3];
  const time = numberParam('t', 21, 0, 24);
  const state = {
    scene: initial, lat: Math.round(numberParam('lat', 40, -90, 90)),
    ...Sky.advance(firstTerm.day, 0, time), selected: 11767, trailStar: 54061, hover: null,
    playing: false, lines: true, guide: initial === 'north', track: initial === 'north',
    view: { yaw: 0, pitch: 31, fov: 92 }
  };
  let dirty = true;
  let skyKey = '';
  let model;
  let hits = [];
  let orbitKey = '';
  let orbit = [];
  let previous;
  const latitude = value => Astro.formatLatCN(value, 0);
  const initialSceneValues = {
    north: { selected: 11767, trailStar: 54061, guide: true, track: true },
    season: { selected: 27989, trailStar: 27989, guide: false, track: false }
  };
  if (initial === 'season') Object.assign(state, initialSceneValues.season);
  const seasonFocus = { spring: 54061, summer: 91262, autumn: 677, winter: 27989 };
  if (initial === 'season') state.selected = seasonFocus[firstTerm.key];
  if (state.lat < 0) state.view.yaw = 180;

  function track(action, label) {
    window.Analytics?.track('星空、星座与北极星', action, label);
  }

  function refresh() {
    dirty = true;
  }

  function world() {
    const key = [state.lat, state.day, state.time].join('/');
    if (skyKey !== key) {
      skyKey = key;
      const site = Sky.observer(state.lat);
      const hour = Sky.sidereal(state.day, state.time);
      const north = state.lat >= 0;
      const here = equatorial.map(star => ({ star, v: Sky.horizon(star, site, hour) }));
      const points = new Map(here.map(point => [point.star.id, point.v]));
      const shapes = patterns.map(pattern => {
        const edges = pattern.paths.flatMap(path => path.slice(1).map((id, i) => [points.get(path[i]), points.get(id)]));
        const vertices = [...new Set(pattern.paths.flat())].map(id => points.get(id));
        const center = vertices.reduce((sum, v) => ({ x: sum.x + v.x, y: sum.y + v.y, z: sum.z + v.z }), { x: 0, y: 0, z: 0 });
        const length = Math.hypot(center.x, center.y, center.z);
        return { ...pattern, edges, complete: vertices.every(v => v.z >= 0),
          caption: { x: center.x / length, y: center.y / length, z: center.z / length } };
      });
      model = {
        stars: here, points, patterns: shapes, site, north,
        sun: Sky.sunAltitude(state.day, state.time, site),
        pole: Sky.direction(north ? 0 : 180, Math.abs(state.lat)),
        pointer: points.get(54061), approach: points.get(11767)
      };
    }
    const trailKey = [state.lat, state.trailStar].join('/');
    if (orbitKey !== trailKey) {
      orbitKey = trailKey;
      orbit = Sky.orbit(byId.get(state.trailStar), model.site);
    }
    return { ...model, orbit };
  }

  function text(id, value) {
    const element = $(id);
    if (element.textContent !== value) element.textContent = value;
  }

  function pressed(selector, value, key) {
    document.querySelectorAll(selector).forEach(button => {
      const active = button.dataset[key] === String(value);
      button.classList.toggle('on', active);
      button.setAttribute('aria-pressed', active);
    });
  }

  function sync(sky) {
    const day = Astro.dayToDate(state.day);
    const clock = Astro.formatClock(Math.floor(state.time * 60 + 0.000001) / 60);
    const selected = byId.get(state.selected);
    const { alt, az } = Sky.angles(sky.points.get(state.selected));
    const term = terms.find(term => term.day === state.day);
    const daylit = sky.sun > -2;
    const position = alt < 0 ? '地平线下' : daylit ? '白昼星光难见' : '地平线上';
    text('stamp', `${day.month}月${day.date}日 · ${latitude(state.lat)}`);
    text('clock', clock);
    text('starlight', daylit ? '白昼' : sky.sun > -14 ? '曙暮光' : '夜间');
    text('selected-name', selected.name);
    text('star-position', position);
    text('quick-star', `${selected.name} · 高度 ${alt.toFixed(1)}° · ${az === null || alt < 0 || daylit ? position : `方位 ${az.toFixed(1)}°`}`);
    text('star-alt', `${alt.toFixed(1)}°`);
    text('star-az', az === null ? '—' : `${az.toFixed(1)}°`);
    text('pole-height', `${sky.north ? '北' : '南'}天极高度 ${Math.abs(state.lat)}°`);
    text('latitude-value', latitude(state.lat));
    text('date-value', `${day.month}月${day.date}日`);
    text('orbit-note', state.track ? `${byId.get(state.trailStar).name}的周日轨迹` : '');
    text('season-note', state.scene !== 'season' ? '' : term && state.lat === 40 && Math.abs(state.time - 21) < 0.05
      ? presets[term.key] : '固定纬度和地方时，切换节气比较露出地平线的星形。');
    text('sky-help', state.scene === 'north' ? '拖动转向 · 点亮星读方位' : '星图圆心是天顶，圆周是地平线');
    text('play', state.playing ? 'Ⅱ 暂停' : '▶ 播放');
    $('play').setAttribute('aria-pressed', state.playing);
    $('time').value = Math.floor(state.time * 12) * 5;
    $('time').setAttribute('aria-valuetext', clock);
    $('date').value = state.day;
    $('date').setAttribute('aria-valuetext', `${day.month}月${day.date}日`);
    $('latitude').value = state.lat;
    $('latitude').setAttribute('aria-valuetext', latitude(state.lat));
    $('star-picker').value = state.selected;
    $('view-tools').hidden = state.scene !== 'north';
    $('season-note').hidden = state.scene !== 'season';
    $('terms').hidden = state.scene !== 'season';
    $('orbit-note').hidden = !state.track;
    $('point-north').textContent = sky.north ? '向北看' : '向南看';
    for (const id of ['lines', 'guide', 'track']) $(id).checked = state[id];
    pressed('[data-scene]', state.scene, 'scene');
    pressed('[data-term]', term?.key, 'term');
    pressed('[data-lat]', state.lat, 'lat');
  }

  function setTime(value) {
    state.playing = false;
    if (value === 24) {
      Object.assign(state, Sky.advance(state.day, 0, 24));
    } else {
      state.time = value;
    }
    refresh();
  }

  function setLatitude(value) {
    const crossed = (state.lat < 0) !== (value < 0);
    state.lat = value;
    if (crossed && state.scene === 'north') resetView();
    refresh();
  }

  function resetView() {
    state.view.yaw = state.lat < 0 ? 180 : 0;
    state.view.pitch = 31;
    state.view.fov = 92;
    refresh();
  }

  function pointPole() {
    state.view.yaw = state.lat < 0 ? 180 : 0;
    state.view.pitch = Sky.clamp(Math.abs(state.lat) * 0.65 + 8, 12, 76);
    refresh();
  }

  function select(id, source) {
    if (!byId.get(id)?.name) return;
    state.selected = id;
    state.trailStar = id;
    refresh();
    if (source === 'picker' && state.scene === 'north') {
      const { alt, az } = Sky.angles(world().points.get(id));
      if (alt >= 0) {
        if (az !== null) state.view.yaw = az;
        state.view.pitch = Sky.clamp(alt, 12, 89);
      }
    }
    if (source) track('点选恒星', byId.get(id).name);
  }

  function setScene(scene) {
    if (state.scene === scene) return;
    state.scene = scene;
    state.playing = false;
    state.hover = null;
    Object.assign(state, initialSceneValues[scene]);
    if (scene === 'season') {
      const term = terms.find(t => t.day === state.day);
      if (term) select(seasonFocus[term.key]);
    } else resetView();
    refresh();
    track('切换场景', scene);
  }

  function setup() {
    for (const place of places) {
      const button = document.createElement('button');
      button.type = 'button';
      button.dataset.lat = place.lat;
      button.textContent = place.name;
      button.addEventListener('click', () => {
        setLatitude(place.lat);
        track('更换纬度', place.name);
      });
      $('places').append(button);
    }
    for (const term of terms) {
      const button = document.createElement('button');
      button.type = 'button';
      button.dataset.term = term.key;
      button.textContent = term.name;
      button.addEventListener('click', () => {
        state.day = term.day;
        state.playing = false;
        if (state.scene === 'season') select(seasonFocus[term.key]);
        refresh();
        track('选择节气', term.name);
      });
      $('terms').append(button);
    }
    for (const star of equatorial.filter(star => star.name)) {
      const option = new Option(star.name, star.id);
      $('star-picker').append(option);
    }
    for (const button of document.querySelectorAll('[data-scene]')) {
      button.addEventListener('click', () => setScene(button.dataset.scene));
    }
    $('star-picker').addEventListener('change', event => select(Number(event.target.value), 'picker'));
    $('time').addEventListener('input', event => setTime(Number(event.target.value) / 60));
    $('time').addEventListener('change', () => track('调节时间', '地方平太阳时'));
    $('latitude').addEventListener('input', event => setLatitude(Number(event.target.value)));
    $('latitude').addEventListener('change', () => track('调节纬度', latitude(state.lat)));
    $('date').addEventListener('input', event => {
      state.day = Number(event.target.value);
      state.playing = false;
      refresh();
    });
    $('date').addEventListener('change', () => track('调节日期', state.scene));
    $('play').addEventListener('click', () => {
      state.playing = !state.playing;
      refresh();
      if (state.playing) track('播放星空', state.scene);
    });
    $('point-north').addEventListener('click', pointPole);
    $('reset-view').addEventListener('click', resetView);
    for (const id of ['lines', 'guide', 'track']) {
      $(id).addEventListener('change', event => {
        state[id] = event.target.checked;
        refresh();
        track('切换图层', id);
      });
    }
  }

  function panelState(open) {
    panel.classList.toggle('collapsed', !open);
    panel.inert = !open;
    const button = $('panelToggle');
    button.setAttribute('aria-expanded', open);
    button.textContent = open ? '收起参数' : '观测参数';
    $('app').classList.toggle('drawer-open', open && compact.matches);
    refresh();
  }

  function nearby(x, y) {
    let best = null;
    let distance = compact.matches ? 23 : 15;
    for (const hit of hits) {
      const next = Math.hypot(x - hit.x, y - hit.y);
      if (next >= distance) continue;
      best = hit;
      distance = next;
    }
    return best?.id || null;
  }

  function rotate(dx, dy) {
    const scale = state.view.fov / Math.max(canvas.clientHeight, 1);
    state.view.yaw = Sky.wrap(state.view.yaw - dx * scale);
    state.view.pitch = Sky.clamp(state.view.pitch + dy * scale, 0, 89);
    refresh();
  }

  function zoom(factor) {
    state.view.fov = Sky.clamp(state.view.fov * factor, 35, 115);
    refresh();
  }

  function pointers() {
    const contacts = new Map();
    let moved = false;
    let split = 0;
    const position = event => {
      const rect = canvas.getBoundingClientRect();
      return { x: event.clientX - rect.left, y: event.clientY - rect.top };
    };
    const distance = () => {
      const [a, b] = contacts.values();
      return Math.hypot(a.x - b.x, a.y - b.y);
    };
    canvas.addEventListener('pointerdown', event => {
      if (event.button !== 0) return;
      if (!contacts.size) moved = false;
      const point = position(event);
      contacts.set(event.pointerId, { ...point, start: point });
      if (contacts.size === 2) {
        split = distance();
        moved = true;
      }
      canvas.setPointerCapture(event.pointerId);
      canvas.classList.add('pressed');
    });
    canvas.addEventListener('pointermove', event => {
      const point = position(event);
      const prior = contacts.get(event.pointerId);
      if (!prior) {
        const next = nearby(point.x, point.y);
        if (next !== state.hover) {
          state.hover = next;
          canvas.classList.toggle('over-star', Boolean(next));
          refresh();
        }
        return;
      }
      if (Math.hypot(point.x - prior.start.x, point.y - prior.start.y) > 5) moved = true;
      contacts.set(event.pointerId, { ...point, start: prior.start });
      if (state.scene !== 'north') return;
      if (contacts.size === 2) {
        const next = distance();
        if (split > 0 && next > 0) zoom(split / next);
        split = next;
      } else if (contacts.size === 1 && moved) {
        rotate(point.x - prior.x, point.y - prior.y);
      }
    });
    function release(event) {
      const prior = contacts.get(event.pointerId);
      if (!prior) return;
      if (!moved && event.type === 'pointerup') {
        const point = position(event);
        const target = nearby(point.x, point.y);
        if (target) select(target, 'canvas');
      }
      contacts.delete(event.pointerId);
      if (!contacts.size) canvas.classList.remove('pressed');
    }
    for (const type of ['pointerup', 'pointercancel', 'lostpointercapture']) canvas.addEventListener(type, release);
    canvas.addEventListener('pointerleave', () => {
      state.hover = null;
      canvas.classList.remove('over-star');
      refresh();
    });
    canvas.addEventListener('wheel', event => {
      if (state.scene !== 'north') return;
      event.preventDefault();
      zoom(Math.exp(Sky.clamp(event.deltaY, -180, 180) * 0.002));
    }, { passive: false });
    canvas.addEventListener('keydown', event => {
      if (state.scene !== 'north') return;
      const arrows = { ArrowLeft: [32, 0], ArrowRight: [-32, 0], ArrowUp: [0, 32], ArrowDown: [0, -32] };
      if (arrows[event.key]) rotate(...arrows[event.key]);
      else if (event.key === '+' || event.key === '=') zoom(0.88);
      else if (event.key === '-') zoom(1.14);
      else if (event.key === 'Home') resetView();
      else return;
      event.preventDefault();
    });
  }

  setup();
  pointers();
  panelState(!compact.matches);
  compact.addEventListener('change', event => panelState(!event.matches));
  $('panelToggle').addEventListener('click', () => panelState(panel.classList.contains('collapsed')));
  new ResizeObserver(refresh).observe(canvas);
  window.__model = { state, setTime, setLatitude, setScene, resetView, select, world, refresh, getHits: () => hits };

  function frame(now) {
    if (state.playing && previous !== undefined) {
      const elapsed = Math.min(now - previous, 100);
      // 播放每秒推进一小时，越过午夜后日期一起前进。
      Object.assign(state, Sky.advance(state.day, state.time, elapsed / 1000));
      refresh();
    }
    previous = now;
    if (dirty) {
      dirty = false;
      const sky = world();
      hits = Draw.draw(canvas, state, sky);
      sync(sky);
    }
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
})();
