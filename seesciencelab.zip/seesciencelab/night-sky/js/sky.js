// 赤道坐标、地方恒星时和地平坐标之间的换算。
(function () {
  const { DEG, dayToPhi, declination } = window.Astro;
  const YEAR = 365;
  const DAILY_RATE = 15 + 15 / YEAR;
  const EQUINOX_DAY = 80;
  const clamp = (n, lo, hi) => Math.max(lo, Math.min(hi, n));
  const wrap = (n, period = 360) => ((n % period) + period) % period;

  function sidereal(day, time) {
    // 春分附近地方平太阳正午的恒星时近似为零。平太阳时每过一天，恒星时增加一圈再约 1°。
    return wrap((day - EQUINOX_DAY) * 360 / YEAR + (time - 12) * DAILY_RATE);
  }

  function observer(lat) {
    return { sin: Math.sin(lat * DEG), cos: Math.cos(lat * DEG) };
  }

  function equatorial(ra, dec) {
    return { ra, sin: Math.sin(dec * DEG), cos: Math.cos(dec * DEG) };
  }

  function horizon(star, site, siderealAngle) {
    const hour = (siderealAngle - star.ra) * DEG;
    const meridian = star.cos * Math.cos(hour);
    return {
      x: -star.cos * Math.sin(hour),
      y: star.sin * site.cos - meridian * site.sin,
      z: star.sin * site.sin + meridian * site.cos
    };
  }

  function angles(point) {
    return {
      alt: Math.asin(clamp(point.z, -1, 1)) / DEG,
      az: Math.hypot(point.x, point.y) < 1e-9 ? null : wrap(Math.atan2(point.x, point.y) / DEG)
    };
  }

  function direction(az, alt) {
    const h = alt * DEG;
    const a = az * DEG;
    return { x: Math.sin(a) * Math.cos(h), y: Math.cos(a) * Math.cos(h), z: Math.sin(h) };
  }

  function sunAltitude(day, time, site) {
    const instant = day + (time - 12) / 24;
    const longitude = (dayToPhi(instant) - 90) * DEG;
    const ra = Math.atan2(Math.sin(longitude) * Math.cos(23.44 * DEG), Math.cos(longitude)) / DEG;
    return angles(horizon(equatorial(ra, declination(instant)), site, sidereal(day, time))).alt;
  }

  function advance(day, time, hours) {
    const sum = time + hours;
    return { day: 1 + wrap(day - 1 + Math.floor(sum / 24), YEAR), time: wrap(sum, 24) };
  }

  function orbit(star, site) {
    return Array.from({ length: 181 }, (_, i) => horizon(star, site, i * 2));
  }

  window.NightSky = {
    clamp, wrap, observer, equatorial, horizon, angles, direction, sidereal, sunAltitude, advance, orbit
  };
})();
