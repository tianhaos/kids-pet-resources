// 原子轨道与电子云：类氢原子波函数、电子云取样、90% 电子云轮廓面，核外电子排布（构造原理、泡利原理、洪特规则）与练习
// 电子云部分按氢原子（Z = 1）计算，长度单位玻尔半径 a₀ = 52.9 pm；化学坐标 x、y 水平，z 向上
(function () {
  var A0 = 52.9;

  // ---------- 角度部分（实球谐函数） ----------
  var C0 = 0.2820948, C1 = 0.4886025, C2 = 1.0925484, C20 = 0.3153916, C22 = 0.5462742;
  var ANG = {
    s: { l: 0, max: C0, f: function () { return C0; } },
    px: { l: 1, max: C1, f: function (x, y, z, r) { return C1 * x / r; } },
    py: { l: 1, max: C1, f: function (x, y, z, r) { return C1 * y / r; } },
    pz: { l: 1, max: C1, f: function (x, y, z, r) { return C1 * z / r; } },
    dxy: { l: 2, max: C2 / 2, f: function (x, y, z, r) { return C2 * x * y / (r * r); } },
    dxz: { l: 2, max: C2 / 2, f: function (x, y, z, r) { return C2 * x * z / (r * r); } },
    dyz: { l: 2, max: C2 / 2, f: function (x, y, z, r) { return C2 * y * z / (r * r); } },
    dx2y2: { l: 2, max: C22, f: function (x, y, z, r) { return C22 * (x * x - y * y) / (r * r); } },
    dz2: { l: 2, max: 2 * C20, f: function (x, y, z, r) { return C20 * (3 * z * z - r * r) / (r * r); } }
  };
  var SUBX = { s: '', px: '<sub>x</sub>', py: '<sub>y</sub>', pz: '<sub>z</sub>', dxy: '<sub>xy</sub>', dxz: '<sub>xz</sub>',
    dyz: '<sub>yz</sub>', dx2y2: '<sub>x²−y²</sub>', dz2: '<sub>z²</sub>' };
  var SHAPE = { 0: '球形', 1: '哑铃状', 2: '花瓣形' };

  // 轨道：'2px' → { n: 2, a: 'px', l: 1 }
  var ORBS = {};
  ['1s', '2s', '3s', '4s', '2px', '2py', '2pz', '3px', '3py', '3pz', '4px', '4py', '4pz',
    '3dxy', '3dxz', '3dyz', '3dx2y2', '3dz2'].forEach(function (id) {
    var n = +id[0], a = id.slice(1);
    ORBS[id] = { id: id, n: n, a: a, l: ANG[a].l, html: n + a[0] + SUBX[a], shape: a === 'dz2' ? '两瓣加一圈' : SHAPE[ANG[a].l] };
  });
  // 组合显示
  var GROUPS = {
    ns: { name: '1s、2s、3s 对比', list: ['3s', '2s', '1s'] },
    p2: { name: '2p 的三个轨道', list: ['2px', '2py', '2pz'] },
    d3: { name: '3d 的五个轨道', list: ['3dxy', '3dxz', '3dyz', '3dx2y2', '3dz2'] }
  };
  function list(sel) { return GROUPS[sel] ? GROUPS[sel].list : [sel]; }

  // ---------- 径向部分 ----------
  function laguerre(k, al, x) {
    if (k === 0) return 1;
    var a = 1, b = 1 + al - x;
    for (var j = 1; j < k; j++) { var c = ((2 * j + 1 + al - x) * b - (j + al) * a) / (j + 1); a = b; b = c; }
    return b;
  }
  var RAD = {};    // 'n,l' → { N 归一化系数, r[], cdf[], rmax }
  function rawR(n, l, r) { var p = 2 * r / n; return Math.pow(p, l) * Math.exp(-p / 2) * laguerre(n - l - 1, 2 * l + 1, p); }
  function radial(n, l) {
    var key = n + ',' + l;
    if (RAD[key]) return RAD[key];
    var M = 3000, rmax = 3.5 * n * n + 8, h = rmax / M, cdf = new Float64Array(M + 1), s = 0, prev = 0;
    for (var i = 1; i <= M; i++) {
      var r = i * h, v = rawR(n, l, r), p = r * r * v * v;
      s += (p + prev) * h / 2; prev = p; cdf[i] = s;
    }
    for (i = 0; i <= M; i++) cdf[i] /= s;
    return (RAD[key] = { N: 1 / Math.sqrt(s), cdf: cdf, h: h, M: M, rmax: rmax });
  }
  function R(n, l, r) { return radial(n, l).N * rawR(n, l, r); }
  // 径向分布函数 P(r) = r²R²（单位 1/a₀）
  function P(n, l, r) { var v = R(n, l, r); return r * r * v * v; }
  // 半径 r 的球内找到电子的概率达到 q 的 r
  function rWithin(n, l, q) {
    var t = radial(n, l), i = 0;
    while (i < t.M && t.cdf[i] < q) i++;
    return i * t.h;
  }

  function psi(o, x, y, z) {
    var r = Math.sqrt(x * x + y * y + z * z) || 1e-9;
    return R(o.n, o.l, r) * ANG[o.a].f(x, y, z, r);
  }

  // ---------- 取样：按 |ψ|² 抽点（径向用累积分布反查，角度用舍选法） ----------
  function rng(seed) {
    var a = seed >>> 0;
    return function () {
      a = (a + 0x6D2B79F5) >>> 0;
      var t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  function sample(id, count, rnd) {
    var o = ORBS[id], t = radial(o.n, o.l), an = ANG[o.a], pos = new Float32Array(count * 3), sg = new Int8Array(count);
    rnd = rnd || Math.random;
    for (var k = 0; k < count; k++) {
      var u = rnd(), lo = 0, hi = t.M;
      while (hi - lo > 1) { var mid = (lo + hi) >> 1; if (t.cdf[mid] < u) lo = mid; else hi = mid; }
      var r = (lo + (u - t.cdf[lo]) / Math.max(1e-12, t.cdf[hi] - t.cdf[lo])) * t.h, x, y, z, w;
      do {
        z = 2 * rnd() - 1; var ph = 2 * Math.PI * rnd(), s = Math.sqrt(1 - z * z);
        x = s * Math.cos(ph); y = s * Math.sin(ph);
        w = an.f(x, y, z, 1) / an.max;
      } while (rnd() > w * w);
      pos[3 * k] = r * x; pos[3 * k + 1] = r * y; pos[3 * k + 2] = r * z;
      sg[k] = (rawR(o.n, o.l, r) * w) >= 0 ? 1 : -1;
    }
    return { pos: pos, sign: sg };
  }

  // 90% 轮廓：|ψ|² 的 10% 分位数 c 满足 P(|ψ|² > c) = 0.9；bound 为轮廓面能到达的最远距离
  var ISO = {};
  function iso(id, q) {
    q = q || 0.9;
    var key = id + q;
    if (ISO[key]) return ISO[key];
    var o = ORBS[id], M = 24000, sm = sample(id, M, rng(7 + o.n * 13 + o.l)), v = new Float64Array(M);
    for (var i = 0; i < M; i++) { var p = psi(o, sm.pos[3 * i], sm.pos[3 * i + 1], sm.pos[3 * i + 2]); v[i] = p * p; }
    var sorted = Array.prototype.slice.call(v).sort(function (a, b) { return a - b; });
    var c = sorted[Math.floor((1 - q) * M)], bound = 0;
    for (i = 0; i < M; i++) if (v[i] >= c) {
      var x = sm.pos[3 * i], y = sm.pos[3 * i + 1], z = sm.pos[3 * i + 2];
      bound = Math.max(bound, Math.abs(x), Math.abs(y), Math.abs(z));
    }
    return (ISO[key] = { k: Math.sqrt(c), bound: bound * 1.12 + 0.3 });
  }

  // ---------- 轮廓面：marching tetrahedra 提取 ψ = +k 与 ψ = −k 两张面 ----------
  var CUBE = [[0, 0, 0], [1, 0, 0], [1, 1, 0], [0, 1, 0], [0, 0, 1], [1, 0, 1], [1, 1, 1], [0, 1, 1]];
  var TETS = [[0, 5, 1, 6], [0, 1, 2, 6], [0, 2, 3, 6], [0, 3, 7, 6], [0, 7, 4, 6], [0, 4, 5, 6]];
  var MESH = {};
  function mesh(id, N) {
    N = N || 52;
    var key = id + ',' + N;
    if (MESH[key]) return MESH[key];
    var o = ORBS[id], is = iso(id), B = is.bound, h = 2 * B / N, N1 = N + 1, F = new Float32Array(N1 * N1 * N1);
    for (var k = 0; k <= N; k++) for (var j = 0; j <= N; j++) for (var i = 0; i <= N; i++)
      F[(k * N1 + j) * N1 + i] = psi(o, -B + i * h, -B + j * h, -B + k * h);
    function surf(sg) {
      var pos = [], nrm = [], lev = is.k, cv = new Float32Array(8), cp = [];
      for (var c = 0; c < 8; c++) cp.push([0, 0, 0]);
      function grad(p) {
        var e = h * 0.5;
        var g = [psi(o, p[0] + e, p[1], p[2]) - psi(o, p[0] - e, p[1], p[2]),
          psi(o, p[0], p[1] + e, p[2]) - psi(o, p[0], p[1] - e, p[2]),
          psi(o, p[0], p[1], p[2] + e) - psi(o, p[0], p[1], p[2] - e)];
        var L = -sg / (Math.hypot(g[0], g[1], g[2]) || 1);     // 朝外：|ψ| 减小的方向
        return [g[0] * L, g[1] * L, g[2] * L];
      }
      function edge(a, b) {
        var t = (lev - cv[a]) / (cv[b] - cv[a]), pa = cp[a], pb = cp[b];
        return [pa[0] + t * (pb[0] - pa[0]), pa[1] + t * (pb[1] - pa[1]), pa[2] + t * (pb[2] - pa[2])];
      }
      function tri(p0, p1, p2) {
        var n0 = grad(p0), n1 = grad(p1), n2 = grad(p2);
        var ux = p1[0] - p0[0], uy = p1[1] - p0[1], uz = p1[2] - p0[2], vx = p2[0] - p0[0], vy = p2[1] - p0[1], vz = p2[2] - p0[2];
        var cx = uy * vz - uz * vy, cy = uz * vx - ux * vz, cz = ux * vy - uy * vx;
        if (cx * (n0[0] + n1[0] + n2[0]) + cy * (n0[1] + n1[1] + n2[1]) + cz * (n0[2] + n1[2] + n2[2]) < 0) {
          var t = p1; p1 = p2; p2 = t; t = n1; n1 = n2; n2 = t;
        }
        pos.push(p0[0], p0[1], p0[2], p1[0], p1[1], p1[2], p2[0], p2[1], p2[2]);
        nrm.push(n0[0], n0[1], n0[2], n1[0], n1[1], n1[2], n2[0], n2[1], n2[2]);
      }
      for (k = 0; k < N; k++) for (j = 0; j < N; j++) for (i = 0; i < N; i++) {
        var nin = 0;
        for (c = 0; c < 8; c++) {
          var d = CUBE[c];
          cv[c] = sg * F[((k + d[2]) * N1 + j + d[1]) * N1 + i + d[0]];
          if (cv[c] > lev) nin++;
        }
        if (nin === 0 || nin === 8) continue;
        for (c = 0; c < 8; c++) { d = CUBE[c]; cp[c][0] = -B + (i + d[0]) * h; cp[c][1] = -B + (j + d[1]) * h; cp[c][2] = -B + (k + d[2]) * h; }
        for (var q = 0; q < 6; q++) {
          var T = TETS[q], ins = [], out = [];
          for (var m = 0; m < 4; m++) (cv[T[m]] > lev ? ins : out).push(T[m]);
          if (ins.length === 1) tri(edge(ins[0], out[0]), edge(ins[0], out[1]), edge(ins[0], out[2]));
          else if (ins.length === 3) tri(edge(out[0], ins[0]), edge(out[0], ins[1]), edge(out[0], ins[2]));
          else if (ins.length === 2) {
            var a = edge(ins[0], out[0]), b = edge(ins[0], out[1]), cc = edge(ins[1], out[1]), dd = edge(ins[1], out[0]);
            tri(a, b, cc); tri(a, cc, dd);
          }
        }
      }
      return { pos: new Float32Array(pos), nrm: new Float32Array(nrm) };
    }
    return (MESH[key] = { plus: surf(1), minus: surf(-1), bound: B });
  }

  // 节面说明
  function nodes(id) {
    var o = ORBS[id], rad = o.n - o.l - 1, t = [];
    if (rad) t.push(rad + ' 个球形节面');
    if (o.l === 1) t.push('1 个过核的节面（' + { px: 'yz', py: 'xz', pz: 'xy' }[o.a] + ' 平面）');
    if (o.l === 2) t.push('2 个过核的节面' + (o.a === 'dz2' ? '（两个圆锥面）' : ''));
    return t.length ? t.join('、') : '没有节面';
  }

  // ---------- 元素与核外电子排布 ----------
  var SYM = 'H He Li Be B C N O F Ne Na Mg Al Si P S Cl Ar K Ca Sc Ti V Cr Mn Fe Co Ni Cu Zn Ga Ge As Se Br Kr'.split(' ');
  var NAME = '氢氦锂铍硼碳氮氧氟氖钠镁铝硅磷硫氯氩钾钙钪钛钒铬锰铁钴镍铜锌镓锗砷硒溴氪'.split('');
  // 能级：按构造原理的填充顺序（到 4p 为止，够 1–36 号元素用）
  var SUBS = [['1s', 1, 0], ['2s', 2, 0], ['2p', 2, 1], ['3s', 3, 0], ['3p', 3, 1], ['4s', 4, 0], ['3d', 3, 2], ['4p', 4, 1]].map(function (a, i) {
    return { id: a[0], n: a[1], l: a[2], m: 2 * a[2] + 1, rank: i };
  });
  var SUB = {};
  SUBS.forEach(function (s) { SUB[s.id] = s; });
  var WRITE = ['1s', '2s', '2p', '3s', '3p', '3d', '4s', '4p'];   // 书写顺序（按能层）
  var SPECIAL = { 24: { '3d': 5, '4s': 1 }, 29: { '3d': 10, '4s': 1 } };
  var SUP = '⁰¹²³⁴⁵⁶⁷⁸⁹';
  function sup(n) { return String(n).split('').map(function (d) { return SUP[+d]; }).join(''); }

  function aufbau(e) {     // 严格按构造原理填 e 个电子
    var c = {};
    SUBS.forEach(function (s) { var k = Math.min(e, 2 * s.m); c[s.id] = k; e -= k; });
    return c;
  }
  function ground(Z) {
    var c = aufbau(Z), sp = SPECIAL[Z];
    if (sp) for (var k in sp) c[k] = sp[k];
    return c;
  }
  // 方框：0 空、1 ↑、2 ↑↓、3 ↓、4 ↑↑（违反泡利原理）
  var NE = [0, 1, 2, 1, 2];
  function boxesOf(c) {
    var b = {};
    SUBS.forEach(function (s) {
      var e = c[s.id] || 0, row = [];
      for (var i = 0; i < s.m; i++) row.push(e > s.m + i ? 2 : e > i ? 1 : 0);
      b[s.id] = row;
    });
    return b;
  }
  function countsOf(b) {
    var c = {};
    SUBS.forEach(function (s) { c[s.id] = b[s.id].reduce(function (a, v) { return a + NE[v]; }, 0); });
    return c;
  }
  function total(c) { var t = 0; for (var k in c) t += c[k]; return t; }
  function same(a, b) { return SUBS.every(function (s) { return (a[s.id] || 0) === (b[s.id] || 0); }); }
  function copyBoxes(b) { var o = {}; for (var k in b) o[k] = b[k].slice(); return o; }

  function config(c, short) {
    var core = '', skip = {};
    if (short) {
      var cores = [[18, '[Ar]', ['1s', '2s', '2p', '3s', '3p']], [10, '[Ne]', ['1s', '2s', '2p']], [2, '[He]', ['1s']]];
      for (var i = 0; i < cores.length; i++) {
        var cr = cores[i], full = cr[2].every(function (id) { return c[id] === 2 * SUB[id].m; });
        if (full && total(c) > cr[0]) { core = cr[1]; cr[2].forEach(function (id) { skip[id] = 1; }); break; }
      }
    }
    return core + WRITE.filter(function (id) { return c[id] && !skip[id]; }).map(function (id) { return id + sup(c[id]); }).join('');
  }
  function highestN(c) { var n = 0; SUBS.forEach(function (s) { if (c[s.id]) n = Math.max(n, s.n); }); return n; }
  // 价层电子排布：主族为 ns、np，过渡元素为 (n−1)d、ns
  function valence(c) {
    var n = highestN(c), t = (n === 4 && c['3d'] && !c['4p'] ? ['3d'] : []).concat([n + 's', n + 'p']);
    return t.filter(function (id) { return c[id]; }).map(function (id) { return id + sup(c[id]); }).join('');
  }
  function unpaired(b) {
    var u = 0;
    for (var k in b) b[k].forEach(function (v) { if (v === 1 || v === 3) u++; });
    return u;
  }
  function occupied(b) { var u = 0; for (var k in b) b[k].forEach(function (v) { if (v) u++; }); return u; }
  var ROMAN = ['', 'Ⅰ', 'Ⅱ', 'Ⅲ', 'Ⅳ', 'Ⅴ', 'Ⅵ', 'Ⅶ', 'Ⅷ'];
  function position(Z) {
    var c = ground(Z), n = highestN(c), s = c[n + 's'], p = c[n + 'p'] || 0, d = n === 4 ? c['3d'] : 0, blk, grp;
    if (Z === 2) { blk = 'p'; grp = '0 族'; }
    else if (p) { blk = 'p'; grp = p === 6 ? '0 族' : ROMAN[2 + p] + 'A 族'; }
    else if (d === 10) { blk = 'ds'; grp = ROMAN[s] + 'B 族'; }
    else if (d) { blk = 'd'; grp = d + s >= 8 ? 'Ⅷ 族' : ROMAN[d + s] + 'B 族'; }
    else { blk = 's'; grp = ROMAN[s] + 'A 族'; }
    return { period: n, block: blk, group: grp };
  }

  // 检查一张轨道表示式（是否符合泡利原理、洪特规则、能量最低原理）
  function check(Z, b) {
    var c = countsOf(b), t = total(c), g = ground(Z), bad, i;
    for (i = 0; i < SUBS.length && !bad; i++) if (b[SUBS[i].id].indexOf(4) >= 0) bad = { kind: 'pauli', sub: SUBS[i].id,
      msg: '违反泡利原理：' + SUBS[i].id + ' 的一个原子轨道里两个电子自旋相同。一个原子轨道里最多容纳 2 个电子，而且它们的自旋相反。' };
    for (i = 0; i < SUBS.length && !bad; i++) {
      var row = b[SUBS[i].id], id = SUBS[i].id;
      if (row.indexOf(2) >= 0 && row.indexOf(0) >= 0) bad = { kind: 'hund', sub: id,
        msg: '违反洪特规则：' + id + ' 能级还有空轨道，电子却成对挤在一个轨道里。基态原子中，填入简并轨道的电子总是先单独分占，且自旋平行。' };
      else if (row.indexOf(1) >= 0 && row.indexOf(3) >= 0) bad = { kind: 'hund', sub: id,
        msg: '违反洪特规则：' + id + ' 能级中单独分占轨道的电子自旋方向不同。基态原子中，单独分占简并轨道的电子自旋平行。' };
    }
    if (bad) return bad;
    if (t !== Z) return { kind: 'count', msg: (t < Z ? '还差 ' + (Z - t) : '多了 ' + (t - Z)) + ' 个电子：' + SYM[Z - 1] + ' 原子核外有 ' + Z + ' 个电子。' };
    if (same(c, g)) return { kind: 'ground', ok: true, msg: SPECIAL[Z]
      ? '基态原子的轨道表示式。注意 ' + SYM[Z - 1] + ' 的 3d 能级' + (Z === 24 ? '半充满（3d⁵）' : '全充满（3d¹⁰）') + '，比按构造原理得到的 ' + config(aufbau(Z), true) + ' 能量更低、更稳定（洪特规则特例）。'
      : '符合泡利原理、洪特规则和能量最低原理：这是基态 ' + SYM[Z - 1] + ' 原子的轨道表示式。' };
    var low = SUBS.filter(function (s) { return c[s.id] < (g[s.id] || 0); }).map(function (s) { return s.id; });
    var high = SUBS.filter(function (s) { return c[s.id] > (g[s.id] || 0); }).map(function (s) { return s.id; });
    return { kind: 'excited', msg: '不符合能量最低原理：' + low.join('、') + ' 能级没有按基态填满，电子却进入了能量更高的 ' + high.join('、')
      + '。这是激发态，基态应为 ' + config(g, Z > 10) + '。' };
  }

  // 逐个填入电子的过程（Cr、Cu 最后一步把一个 4s 电子移到 3d）
  function fillSteps(Z) {
    var st = [];
    for (var e = 0; e <= Z; e++) st.push(boxesOf(aufbau(e)));
    if (SPECIAL[Z]) st.push(boxesOf(ground(Z)));
    return st;
  }
  // 激发：能量最高的一个电子跃迁到更高的能级
  function excite(b) {
    var c = countsOf(b), hi = -1;
    SUBS.forEach(function (s, i) { if (c[s.id]) hi = i; });
    if (hi < 0) return null;
    for (var j = hi + 1; j < SUBS.length; j++) if (c[SUBS[j].id] < 2 * SUBS[j].m) break;
    if (j >= SUBS.length) return null;
    var nb = copyBoxes(b), from = nb[SUBS[hi].id], to = nb[SUBS[j].id];
    var k = from.lastIndexOf(2);
    if (k >= 0) from[k] = 1; else { k = from.lastIndexOf(1) >= 0 ? from.lastIndexOf(1) : from.lastIndexOf(3); from[k] = 0; }
    var e = to.indexOf(0);
    if (e >= 0) to[e] = 1; else to[to.indexOf(1)] = 2;
    return nb;
  }

  // ---------- 练习 ----------
  var TYPES = ['shape', 'config', 'rule', 'count'];
  function pick(rnd, a) { return a[Math.floor(rnd() * a.length)]; }
  function shuffle(rnd, a) { a = a.slice(); for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(rnd() * (i + 1)), t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
  function cfgName(Z) { return SYM[Z - 1] + '（' + NAME[Z - 1] + '）'; }

  function quiz(rnd, prev, only, types) {
    rnd = rnd || Math.random;
    types = types || TYPES;
    var q;
    for (var tries = 0; tries < 30; tries++) {
      q = make(only || pick(rnd, types), rnd);
      if (q && (!prev || q.prompt !== prev.prompt || q.answer !== prev.answer)) break;
    }
    return q;
  }
  function make(type, rnd) {
    var q = { type: type };
    if (type === 'shape') {
      var u = rnd(), id, cand;
      if (u < 0.15) { id = pick(rnd, ['1s', '2s', '3s']); var np = Math.max(2, +id[0]); cand = [id, np + 'px', np + 'py', np + 'pz']; }
      else if (u < 0.7) { id = pick(rnd, ['2px', '2py', '2pz', '3px', '3py', '3pz']); cand = [id[0] + 's', id[0] + 'px', id[0] + 'py', id[0] + 'pz']; }
      else { id = pick(rnd, GROUPS.d3.list); cand = shuffle(rnd, GROUPS.d3.list.filter(function (x) { return x !== id; })).slice(0, 3).concat([id]); }
      var o = ORBS[id];
      q.orb = id;
      q.prompt = '画面中是哪个原子轨道的电子云轮廓图？（注意坐标轴）';
      q.answer = o.html;
      q.options = shuffle(rnd, cand).map(function (x) { return ORBS[x].html; });
      q.explain = o.html + ' 轨道的电子云呈' + o.shape + (o.l === 1 ? '，两瓣沿 ' + o.a[1] + ' 轴伸展' : o.l === 2 ? '（d 轨道属于拓展内容）' : '，s 电子云没有方向性')
        + '。能层序数越大，电子云越向外扩展。';
      return q;
    }
    var Z, g, b;
    if (type === 'config') {
      Z = pick(rnd, [7, 8, 9, 11, 13, 14, 15, 16, 17, 19, 20, 21, 22, 23, 24, 24, 25, 26, 27, 28, 29, 29, 30, 31, 33, 34, 35]);
      g = ground(Z);
      var short = Z > 20, right = config(g, short), opts = [right], alt = [];
      var plain = aufbau(Z);
      if (SPECIAL[Z]) alt.push(plain);
      if (g['4s'] && g['3d'] < 10) { var c1 = Object.assign({}, g); var mv = Math.min(c1['4s'], 10 - c1['3d']); c1['3d'] += mv; c1['4s'] -= mv; alt.push(c1); }
      if (g['4s'] && !g['3d'] && !g['4p']) { var c2 = Object.assign({}, g); c2['3d'] = c2['4s']; c2['4s'] = 0; alt.push(c2); }
      if (g['3d'] && g['3d'] < 10 && g['4s'] === 2 && !SPECIAL[Z]) { var c3 = Object.assign({}, g); c3['3d']++; c3['4s']--; alt.push(c3); }
      var n = highestN(g);
      if (g[n + 'p'] && g[n + 's'] === 2) { var c4 = Object.assign({}, g); c4[n + 's'] = 1; c4[n + 'p']++; alt.push(c4); }
      var last = WRITE.filter(function (x) { return g[x]; }).pop();
      [1, -1].forEach(function (dd) {
        var c5 = Object.assign({}, g); c5[last] += dd;
        if (c5[last] > 0 && c5[last] <= 2 * SUB[last].m) alt.push(c5);
      });
      var li = SUB[last].rank, nx = SUBS[li + 1], pv = SUBS.filter(function (x) { return x.rank < li && g[x.id]; }).pop();
      if (nx && !g[nx.id]) { var c8 = Object.assign({}, g); c8[last]--; c8[nx.id] = 1; if (c8[last] >= 0) alt.push(c8); }
      if (pv && g[last] < 2 * SUB[last].m) { var c9 = Object.assign({}, g); c9[pv.id]--; c9[last]++; alt.push(c9); }
      [1, 2].forEach(function (k) { if (g['3d'] >= k && !g['4p']) { var c6 = Object.assign({}, g); c6['3d'] -= k; c6['4p'] = k; alt.push(c6); } });
      [2, -2].forEach(function (dd) {
        var c7 = Object.assign({}, g); c7[last] += dd;
        if (c7[last] > 0 && c7[last] <= 2 * SUB[last].m) alt.push(c7);
      });
      var core = function (s) { return short ? s.split(']')[0] : ''; };     // 选项的简化写法要用同一个稀有气体结构
      shuffle(rnd, alt).forEach(function (c) { var s = config(c, short); if (opts.indexOf(s) < 0 && opts.length < 4 && core(s) === core(right)) opts.push(s); });
      q.Z = Z;
      q.prompt = '基态 ' + cfgName(Z) + ' 原子的电子排布式是？';
      q.answer = right;
      q.options = shuffle(rnd, opts);
      q.explain = SYM[Z - 1] + ' 有 ' + Z + ' 个电子，按构造原理依次填入 1s、2s、2p、3s、3p、4s、3d、4p，书写时按能层顺序：' + config(g, false) + '，简写为 ' + config(g, true) + '。'
        + (SPECIAL[Z] ? 'Cr、Cu 是特例：3d 能级' + (Z === 24 ? '半充满' : '全充满') + '时能量更低。' : '');
      return q;
    }
    if (type === 'rule') {
      var kind = pick(rnd, ['pauli', 'hund', 'hund', 'excited', 'ground']), nb;
      for (var t = 0; t < 40; t++) {
        Z = kind === 'hund' ? pick(rnd, [6, 7, 8, 14, 15, 16, 22, 23, 25, 26, 27, 28]) : kind === 'ground' ? pick(rnd, [6, 7, 8, 11, 15, 16, 24, 26, 29]) : pick(rnd, [3, 4, 5, 6, 7, 8, 11, 12, 13, 19, 20]);
        b = boxesOf(ground(Z));
        nb = copyBoxes(b);
        if (kind === 'pauli') {
          var paired = SUBS.filter(function (s) { return nb[s.id].indexOf(2) >= 0; }), sp2 = pick(rnd, paired);
          nb[sp2.id][nb[sp2.id].indexOf(2)] = 4;
        } else if (kind === 'hund') {
          var part = SUBS.filter(function (s) { var e = countsOf(nb)[s.id]; return s.l && e >= 2 && e <= 2 * s.m - 2; })[0];
          if (!part) continue;
          var row = nb[part.id];
          if (rnd() < 0.5 && row.indexOf(1) !== row.lastIndexOf(1)) row[row.lastIndexOf(1)] = 3;
          else { var i1 = row.lastIndexOf(1), i0 = row.indexOf(0); if (i1 < 0 || i0 < 0) { row[row.lastIndexOf(1)] = 3; } else { row[i1] = 0; row[row.indexOf(1)] = 2; } }
        } else if (kind === 'excited') {
          var cs = countsOf(nb), from = SUBS.filter(function (s) { return cs[s.id] === 2 * s.m && s.rank < 5; });
          if (!from.length) continue;
          var f = pick(rnd, from), r0 = nb[f.id];
          r0[r0.lastIndexOf(2)] = 1;
          var to = SUBS.filter(function (s) { return s.rank > f.rank && cs[s.id] < 2 * s.m && s.rank <= f.rank + 3; });
          if (!to.length) continue;
          var tt = to[0], r1 = nb[tt.id], e0 = r1.indexOf(0);
          if (e0 >= 0) r1[e0] = 1; else r1[r1.indexOf(1)] = 2;
        }
        var ck = check(Z, nb);
        if (ck.kind === kind) break;
      }
      q.Z = Z; q.boxes = nb;
      q.prompt = '下面是 ' + cfgName(Z) + ' 原子的轨道表示式，它';
      var M2 = { pauli: '违反泡利原理', hund: '违反洪特规则', excited: '违反能量最低原理', ground: '正确（基态）' };
      q.options = ['违反泡利原理', '违反洪特规则', '违反能量最低原理', '正确（基态）'];
      q.answer = M2[check(Z, nb).kind];
      q.explain = check(Z, nb).msg;
      return q;
    }
    // count
    var k2 = pick(rnd, ['unpaired', 'unpaired', 'space', 'shell', 'orbs']);
    if (k2 === 'shell') {
      n = pick(rnd, [2, 3, 4]);
      q.prompt = '第 ' + n + ' 能层（' + 'KLMN'[n - 1] + ' 层）最多能容纳多少个电子？';
      q.answer = String(2 * n * n);
      q.options = ['8', '18', '32', String(2 * n * n), String(n * n), '2'].filter(function (x, i, a) { return a.indexOf(x) === i; }).slice(0, 4);
      if (q.options.indexOf(q.answer) < 0) q.options[3] = q.answer;
      q.options.sort(function (a, b2) { return a - b2; });
      q.explain = '第 n 能层有 n 个能级、n² 个原子轨道，每个轨道最多容纳 2 个电子，最多容纳 2n² 个电子：第 ' + n + ' 能层有 ' + n * n + ' 个轨道，最多 ' + 2 * n * n + ' 个电子。';
      return q;
    }
    if (k2 === 'orbs') {
      var lv = pick(rnd, ['3s', '2p', '4p', '3d', '4f']), m = { s: 1, p: 3, d: 5, f: 7 }[lv[1]];
      q.prompt = lv + ' 能级有几个原子轨道？';
      q.answer = String(m); q.options = ['1', '3', '5', '7'];
      q.explain = 's、p、d、f 能级分别有 1、3、5、7 个原子轨道，与能层序数无关；' + lv + ' 能级有 ' + m + ' 个轨道，最多容纳 ' + 2 * m + ' 个电子。';
      return q;
    }
    Z = pick(rnd, k2 === 'unpaired' ? [5, 6, 7, 8, 9, 14, 15, 16, 17, 22, 23, 24, 25, 26, 27, 28, 29, 33, 34] : [6, 7, 8, 11, 13, 15, 16, 17, 19, 26]);
    g = ground(Z); b = boxesOf(g);
    q.Z = Z; q.boxes = b; q.afterBoxes = true;
    if (k2 === 'unpaired') {
      var up = unpaired(b);
      q.prompt = '基态 ' + cfgName(Z) + ' 原子有几个未成对电子？';
      q.answer = String(up);
      q.options = (up <= 3 ? ['0', '1', '2', '3'] : up <= 5 ? ['2', '3', '4', '5'] : ['3', '4', '5', '6']);
      q.explain = '基态 ' + SYM[Z - 1] + '：' + config(g, Z > 18) + '。按洪特规则，' + (valence(g)) + ' 中有 ' + up + ' 个单独分占轨道的电子，即 ' + up + ' 个未成对电子。';
    } else {
      var oc = occupied(b);
      q.prompt = '基态 ' + cfgName(Z) + ' 原子的核外电子有几种不同的空间运动状态（占据几个原子轨道）？';
      q.answer = String(oc);
      var base = Math.max(1, oc - 1 - Math.floor(rnd() * 2));
      q.options = [base, base + 1, base + 2, base + 3].map(String);
      if (q.options.indexOf(q.answer) < 0) q.options[0] = q.answer;
      q.options.sort(function (a, b2) { return a - b2; });
      q.explain = SYM[Z - 1] + '：' + config(g, false) + '，电子占据 ' + oc + ' 个原子轨道。一个原子轨道就是一种空间运动状态；核外 ' + Z + ' 个电子的运动状态（还要算上自旋）各不相同，共 ' + Z + ' 种。';
    }
    return q;
  }

  window.Orbital = {
    A0: A0, ORBS: ORBS, GROUPS: GROUPS, ANG: ANG, list: list, R: R, P: P, psi: psi, rWithin: rWithin, radial: radial,
    sample: sample, rng: rng, iso: iso, mesh: mesh, nodes: nodes,
    SYM: SYM, NAME: NAME, SUBS: SUBS, SUB: SUB, WRITE: WRITE, SPECIAL: SPECIAL, sup: sup,
    aufbau: aufbau, ground: ground, boxesOf: boxesOf, countsOf: countsOf, total: total, config: config, valence: valence,
    unpaired: unpaired, occupied: occupied, position: position, check: check, fillSteps: fillSteps, excite: excite, copyBoxes: copyBoxes,
    TYPES: TYPES, quiz: quiz
  };
})();
