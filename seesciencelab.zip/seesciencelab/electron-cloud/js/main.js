(function () {
  var Or = window.Orbital, D = window.OrbDraw;
  var $ = function (id) { return document.getElementById(id); };
  var qa = function (sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); };
  var NAME = '原子轨道与电子云';
  var PAL = ['#ff7a59', '#7ee081', '#4fc3f7', '#ffc94a', '#c9a7ff'];
  var SHELL = 'KLMN';

  var state = {
    scene: 'cloud', sel: '1s', view: 'dots', sign: false, cut: false, axes: true, spin: true, count: 8000,
    Z: 8, boxes: null, play: null, hl: null, note: '',
    quiz: null, quizOnly: null, answered: false, correct: false, choice: null, score: { n: 0, ok: 0 }
  };
  var HINTS = {
    cloud: '拖动旋转、滚轮或双指缩放；小点越密，电子在那里出现的概率密度越大',
    config: '点方框放入电子，点能级符号看它的电子云',
    quiz: '原子轨道与电子云 · 判断练习'
  };

  var stage = $('stage'), panel = $('panel'), cv = $('view2d'), ctx = cv.getContext('2d');
  var sc3 = null;
  try { sc3 = window.OrbitalScene(stage); } catch (e) { sc3 = null; }
  var quizTypes = sc3 ? Or.TYPES : Or.TYPES.filter(function (t) { return t !== 'shape'; });
  function setSeg(attr, val) { qa('[data-' + attr + ']').forEach(function (b) { b.classList.toggle('on', b.dataset[attr] === String(val)); }); }
  function list() { return Or.list(state.sel); }

  // ---------- 选择轨道 ----------
  var PICK = [['s 轨道', ['1s', '2s', '3s', '4s']], ['p 轨道', ['2px', '2py', '2pz', '3px', '3py', '3pz']],
    ['d 轨道（拓展）', ['3dxy', '3dxz', '3dyz', '3dx2y2', '3dz2']], ['对比', ['ns', 'p2', 'd3']]];
  $('picker').innerHTML = PICK.map(function (g) {
    return '<h3>' + g[0] + '</h3><div class="presets ' + (g[1].length > 4 ? 'six' : g[1].length === 3 ? 'three' : 'four') + '">' + g[1].map(function (id) {
      return '<button data-sel="' + id + '">' + (Or.GROUPS[id] ? Or.GROUPS[id].name : Or.ORBS[id].html) + '</button>';
    }).join('') + '</div>';
  }).join('');
  qa('[data-sel]').forEach(function (b) {
    b.addEventListener('click', function () { setSel(b.dataset.sel); Analytics.track(NAME, '轨道', b.dataset.sel); });
  });
  function setSel(id) { state.sel = id; syncUI(); }

  // ---------- 控件 ----------
  qa('[data-scene]').forEach(function (b) {
    b.addEventListener('click', function () { setScene(b.dataset.scene); Analytics.track(NAME, '场景', b.textContent); });
  });
  function setScene(s) {
    state.scene = s;
    if (s === 'quiz' && !state.quiz) newQuiz();
    syncUI();
  }
  qa('[data-view]').forEach(function (b) { b.addEventListener('click', function () { state.view = b.dataset.view; syncUI(); Analytics.track(NAME, '显示', b.textContent); }); });
  [['cut', 'cut'], ['sign', 'sign'], ['axes', 'axes']].forEach(function (p) {
    $(p[0]).addEventListener('change', function () { state[p[1]] = $(p[0]).checked; syncUI(); Analytics.track(NAME, '显示', p[1] + (state[p[1]] ? ' 开' : ' 关')); });
  });
  $('spin').addEventListener('change', function () { state.spin = $('spin').checked; if (sc3) sc3.controls.autoRotate = state.spin; });
  $('count').addEventListener('input', function () { state.count = +$('count').value; syncUI(); });
  $('replay').addEventListener('click', function () { if (sc3) sc3.replay(); Analytics.track(NAME, '重新打点', state.sel); });
  qa('.homeBtn').forEach(function (b) { b.addEventListener('click', function () { if (sc3) sc3.home(); }); });

  // 元素
  $('zr').addEventListener('input', function () { setZ(+$('zr').value); });
  $('zPrev').addEventListener('click', function () { setZ(Math.max(1, state.Z - 1)); });
  $('zNext').addEventListener('click', function () { setZ(Math.min(36, state.Z + 1)); });
  var QUICK = [1, 6, 7, 8, 11, 17, 19, 24, 26, 29, 30, 35];
  $('elQuick').innerHTML = QUICK.map(function (z) { return '<button data-z="' + z + '">' + Or.SYM[z - 1] + '</button>'; }).join('');
  qa('[data-z]').forEach(function (b) { b.addEventListener('click', function () { setZ(+b.dataset.z); Analytics.track(NAME, '元素', Or.SYM[+b.dataset.z - 1]); }); });
  function setZ(z, boxes) {
    state.Z = z; state.play = null; state.hl = null; state.note = '';
    state.boxes = boxes ? Or.copyBoxes(boxes) : Or.boxesOf(Or.ground(z));
    syncUI();
  }
  $('fill').addEventListener('click', function () { startFill(); Analytics.track(NAME, '逐个填入', Or.SYM[state.Z - 1]); });
  function startFill() {
    state.play = { steps: Or.fillSteps(state.Z), k: 0, t: 0 };
    state.boxes = Or.copyBoxes(state.play.steps[0]); state.hl = null; state.note = '';
    syncUI();
  }
  $('ground').addEventListener('click', function () { setZ(state.Z); });
  $('clear').addEventListener('click', function () { setZ(state.Z, Or.boxesOf({})); state.note = '自己填：点方框放入电子，读数区会检查是否符合三条原理。'; Analytics.track(NAME, '自己填', Or.SYM[state.Z - 1]); });
  $('excite').addEventListener('click', function () {
    var nb = Or.excite(state.boxes);
    state.play = null;
    if (!nb) { state.note = '没有更高的能级可以跃迁了（本模型只画到 4p）。'; syncUI(); return; }
    var c0 = Or.countsOf(state.boxes), c1 = Or.countsOf(nb), from = '', to = '';
    Or.SUBS.forEach(function (s) { if (c1[s.id] < c0[s.id]) from = s.id; if (c1[s.id] > c0[s.id]) to = s.id; });
    state.boxes = nb; state.hl = to;
    state.note = '吸收能量，一个 ' + from + ' 电子跃迁到能量更高的 ' + to + ' 能级，原子由基态变为激发态；电子跃迁回低能级时会放出能量（以光的形式释放，产生发射光谱）。';
    syncUI();
    Analytics.track(NAME, '激发', Or.SYM[state.Z - 1]);
  });

  // 能级图点击：方框放电子，能级符号去看电子云
  var hits = null;
  cv.addEventListener('pointerdown', function (e) {
    if (state.scene !== 'config' || !hits) return;
    var r = cv.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top;
    var inside = function (h) { return x >= h.x && x <= h.x + h.w && y >= h.y && y <= h.y + h.h; };
    var b = hits.boxes.filter(inside)[0];
    if (b) {
      state.play = null; state.hl = b.sub; state.note = '';
      var row = state.boxes[b.sub];
      row[b.i] = (row[b.i] + 1) % 5;
      syncUI();
      Analytics.track(NAME, '放电子', b.sub);
      return;
    }
    var l = hits.labels.filter(inside)[0];
    if (l && sc3) {
      var id = l.sub, ORB = { '2p': 'p2', '3d': 'd3', '3p': '3pz', '4p': '4pz' };
      state.sel = ORB[id] || id;
      setScene('cloud');
      Analytics.track(NAME, '能级 → 电子云', id);
    }
  });

  // ---------- 练习 ----------
  function newQuiz() {
    state.quiz = Or.quiz(Math.random, state.quiz, state.quizOnly, quizTypes);
    state.answered = false; state.choice = null;
    var box = $('quizOpts');
    box.innerHTML = '';
    state.quiz.options.forEach(function (o) {
      var b = document.createElement('button');
      b.className = 'small';
      b.innerHTML = o;
      b.dataset.opt = o;
      b.addEventListener('click', function () { answer(o); });
      box.appendChild(b);
    });
    box.classList.toggle('four', state.quiz.options.every(function (o) { return o.replace(/<[^>]+>/g, '').length <= 6; }));
    syncUI();
  }
  function answer(o) {
    if (state.answered) return;
    state.answered = true; state.choice = o;
    state.correct = o === state.quiz.answer;
    state.score.n++; if (state.correct) state.score.ok++;
    Analytics.track(NAME, '练习', state.quiz.type + (state.correct ? ' 对' : ' 错'));
    syncUI();
  }
  $('nextQ').addEventListener('click', newQuiz);
  $('showQ').addEventListener('click', function () {
    var q = state.quiz;
    if (q.type === 'shape') { state.sel = q.orb; state.view = 'surf'; setScene('cloud'); }
    else if (q.Z) { setZ(q.Z, q.type === 'rule' ? q.boxes : null); setScene('config'); }
    Analytics.track(NAME, '练习 → 模型', q.type);
  });

  // ---------- 面板 ----------
  $('panelToggle').addEventListener('click', function () { panel.classList.toggle('collapsed'); });
  if (window.matchMedia('(max-width: 760px)').matches) panel.classList.add('collapsed');

  function use3d() { var s = state.scene; return !!sc3 && (s === 'cloud' || (s === 'quiz' && state.quiz && state.quiz.type === 'shape')); }
  function syncUI() {
    var s = state.scene;
    setSeg('scene', s);
    qa('[data-for]').forEach(function (el) { el.hidden = el.dataset.for.split(' ').indexOf(s) < 0; });
    $('hint').textContent = !sc3 && s === 'cloud' ? '此浏览器不支持 WebGL，无法显示 3D 电子云；核外电子排布和练习仍可使用' : HINTS[s];
    setSeg('sel', state.sel); setSeg('view', state.view);
    $('cut').checked = state.cut; $('sign').checked = state.sign; $('axes').checked = state.axes; $('spin').checked = state.spin;
    $('count').value = state.count; $('countV').textContent = state.count;
    $('count').disabled = state.view === 'surf';
    $('zr').value = state.Z; $('zV').textContent = state.Z + ' ' + Or.SYM[state.Z - 1];
    setSeg('z', state.Z);
    var three = use3d();
    if (sc3) { sc3.canvas.style.display = three ? '' : 'none'; sc3.labels.style.display = three ? '' : 'none'; sc3.spin(state.spin); }
    cv.style.display = three ? 'none' : '';
    var q = state.quiz;
    if (q) {
      $('quizQ').textContent = q.prompt;
      qa('#quizOpts button').forEach(function (b) {
        b.disabled = state.answered;
        b.classList.toggle('on', state.answered && b.dataset.opt === q.answer);
        b.classList.toggle('no', state.answered && b.dataset.opt === state.choice && !state.correct);
      });
      $('quizMsg').innerHTML = !state.answered ? ''
        : '<b class="' + (state.correct ? 'ok">✓ 答对了' : 'bad">✗ 应选「' + q.answer + '」') + '</b>' + q.explain;
      $('nextQ').textContent = state.answered ? '下一题 →' : '换一题';
      $('showQ').hidden = !state.answered || !(q.type === 'shape' || q.Z);
    }
    radialChart();
    legend();
  }
  function radialChart() {
    var c = $('radial'), w = c.clientWidth || 300, h = c.clientHeight || 150, dpr = window.devicePixelRatio || 1;
    if (c.width !== Math.round(w * dpr)) { c.width = Math.round(w * dpr); c.height = Math.round(h * dpr); }
    var g = c.getContext('2d');
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
    var L = list(), multi = L.length > 1;
    D.radial(g, w, h, L, L.map(function (id, i) { return multi ? PAL[i % PAL.length] : '#7fd3ff'; }));
  }
  function legend() {
    var html = '';
    if (state.scene === 'cloud' && sc3) {
      html = '<span><i style="background:#ff5252"></i>原子核</span>';
      if (state.sign) html += '<span><i style="background:#ffb74d"></i>ψ &gt; 0</span><span><i style="background:#4fc3f7"></i>ψ &lt; 0</span>';
      if (state.view === 'dots' && list().length === 1) html += '<span class="chg">共 ' + state.count + ' 个点</span>';
    }
    $('legend').innerHTML = html;
  }

  // ---------- 读数 ----------
  var lastText = {};
  function setText(id, t, html) { if (lastText[id] !== t) { lastText[id] = t; $(id)[html ? 'innerHTML' : 'textContent'] = t; } }
  function rows(lst) {
    for (var k = 1; k <= 6; k++) {
      var r = lst[k - 1] || ['', ''];
      setText('d' + k, r[0]); setText('r' + k, r[1], true);
      $('d' + k).hidden = $('r' + k).hidden = !r[0];
    }
  }
  function pm(a0) { return Math.round(a0 * Or.A0) + ' pm'; }
  function peak(n, l) { var best = 0, br = 0; for (var r = 0.02; r < Or.radial(n, l).rmax; r += 0.02) { var p = Or.P(n, l, r); if (p > best) { best = p; br = r; } } return br; }
  var DIR = { s: '没有方向性', px: '沿 x 轴伸展', py: '沿 y 轴伸展', pz: '沿 z 轴伸展', dxy: '四瓣在 xy 平面内、夹在两轴之间', dxz: '四瓣在 xz 平面内、夹在两轴之间',
    dyz: '四瓣在 yz 平面内、夹在两轴之间', dx2y2: '四瓣在 xy 平面内、沿 x、y 轴', dz2: '沿 z 轴伸展，xy 平面内有一圈' };
  function readCloud() {
    var L = list(), g = Or.GROUPS[state.sel];
    $('rName').className = '';
    if (g) {
      setText('rName', g.name);
      setText('rKind', '对比');
      if (state.sel === 'ns') rows(['1s', '2s', '3s'].map(function (id) {
        var o = Or.ORBS[id];
        return [id, '90% 在 ' + pm(Or.rWithin(o.n, 0, 0.9)) + ' 以内，' + (o.n - 1 ? (o.n - 1) + ' 个球形节面' : '没有节面')];
      }).concat([['规律', '能层序数 n 越大，电子能量越高，电子云越向外扩展，轨道半径越大']]));
      else if (state.sel === 'p2') rows([['轨道数', '2p 能级有 3 个轨道：2p<sub>x</sub>、2p<sub>y</sub>、2p<sub>z</sub>'], ['形状', '都是哑铃状，分别沿 x、y、z 轴伸展，相互垂直'],
        ['能量', '相同（简并轨道），电子按洪特规则先分占'], ['合起来', '三个 p 轨道的电子云叠加后是球对称的']]);
      else rows([['轨道数', '3d 能级有 5 个轨道'], ['形状', '四个花瓣形，d<sub>z²</sub> 为两瓣加一圈'], ['能量', '五个 3d 轨道能量相同（简并轨道）'], ['说明', 'd 轨道的形状属于拓展内容']]);
    } else {
      var o = Or.ORBS[L[0]], sub = o.n + 'spd'[o.l], m = 2 * o.l + 1;
      setText('rName', o.html + ' 轨道', true);
      setText('rKind', o.shape);
      rows([
        ['能层', '第 ' + o.n + ' 能层（' + SHELL[o.n - 1] + ' 层），共 ' + o.n + ' 个能级、' + o.n * o.n + ' 个轨道'],
        ['能级', sub + ' 能级有 ' + m + ' 个轨道，最多容纳 ' + 2 * m + ' 个电子'],
        ['形状', o.shape + '，' + DIR[o.a]],
        ['节面', Or.nodes(o.id)],
        ['径向分布', '最大值在 r ≈ ' + pm(peak(o.n, o.l)) + (o.id === '1s' ? '（玻尔半径）' : '')],
        ['大小', o.l ? '轮廓外缘距核约 ' + pm((Or.iso(o.id).bound - 0.3) / 1.12) : '90% 的概率在 r ≤ ' + pm(Or.rWithin(o.n, 0, 0.9)) + ' 的球内']
      ]);
    }
    var tip;
    if (sc3 && sc3.revealing() && state.view !== 'surf') tip = '想象给电子拍了很多张照片再叠在一起：每个小点表示电子曾在那里出现过一次，小点越密，电子出现的概率密度越大。小点不是电子，氢原子核外只有 1 个电子。';
    else if (state.view === 'dots') tip = '电子云是电子在原子核外空间出现的概率密度分布的形象化描述：离核越近小点越密' + (state.sel === '1s' ? '，1s 电子云呈球形对称' : '') + (state.cut ? '；剖开后能看到内部的疏密' : '；勾选“剖开”看内部') + '。';
    else tip = '把电子出现概率约为 90% 的空间圈起来，就是电子云轮廓图' + (state.sign ? '；两种颜色表示波函数 ψ 的正负号（拓展），不是电荷的正负' : '') + (/^[23]s$/.test(state.sel) ? '；剖开看内部，' + state.sel + ' 里面还有一层（球形节面把它们隔开）' : '') + '。';
    setText('rTip', tip);
  }
  function readConfig() {
    var Z = state.Z, b = state.boxes, c = Or.countsOf(b), ck = Or.check(Z, b), g = Or.ground(Z), pos = Or.position(Z);
    setText('rName', Z + ' ' + Or.SYM[Z - 1] + ' ' + Or.NAME[Z - 1]);
    var KIND = { ground: '基态', excited: '激发态', pauli: '违反泡利原理', hund: '违反洪特规则', count: '电子数不对' };
    setText('rKind', state.play ? '填入中' : KIND[ck.kind]);
    $('rKind').className = 'kind' + (state.play ? '' : ck.ok ? ' okk' : ck.kind === 'excited' || ck.kind === 'count' ? ' mid' : ' badk');
    $('rName').className = '';
    var cur = Or.total(c), isG = ck.kind === 'ground';
    rows([
      ['电子排布式', cur ? Or.config(c, false) : '—'],
      ['简化写法', cur ? Or.config(c, true) : '—'],
      ['价层电子', isG ? Or.valence(g) : '基态：' + Or.valence(g)],
      ['未成对电子', ck.kind === 'pauli' || ck.kind === 'hund' ? '—' : Or.unpaired(b) + ' 个'],
      ['位置', '第 ' + pos.period + ' 周期 ' + pos.group + '，' + pos.block + ' 区'],
      ['电子', '已填 ' + cur + ' / ' + Z + '，占据 ' + Or.occupied(b) + ' 个原子轨道']
    ]);
    setText('rTip', state.note || (state.play ? playNote() : ck.msg));
  }
  function playNote() {
    var p = state.play, k = p.k, n = p.steps.length - 1;
    if (!k) return '按构造原理，电子依次填入 1s、2s、2p、3s、3p、4s、3d、4p……';
    if (Or.SPECIAL[state.Z] && k === n) return '最后：' + Or.SYM[state.Z - 1] + ' 的 3d ' + (state.Z === 24 ? '半充满' : '全充满') + '时能量更低，一个 4s 电子转入 3d（洪特规则特例）。';
    var hl = state.hl, row = state.boxes[hl], sub = Or.SUB[hl];
    var e = row.reduce(function (a, v) { return a + [0, 1, 2, 1, 2][v]; }, 0);
    return '第 ' + Math.min(k, state.Z) + ' 个电子进入 ' + hl + (sub.m > 1 ? (e <= sub.m ? '：先单独分占空轨道，自旋平行（洪特规则）' : '：轨道都有 1 个电子了，再与已有电子配对，自旋相反（泡利原理）')
      : e === 2 ? '：与已有电子配对，自旋相反（泡利原理）' : '');
  }
  function readQuiz() {
    var q = state.quiz, s = state.score;
    setText('rName', !state.answered ? '判断练习' : state.correct ? '✓ 答对了' : '✗ 答错了');
    $('rName').className = !state.answered ? '' : state.correct ? 'ok' : 'bad';
    setText('rKind', '得分 ' + s.ok + ' / ' + s.n);
    $('rKind').className = 'kind';
    setText('rTip', state.answered ? q.explain.replace(/<[^>]+>/g, '') : q.prompt);
    rows([]);
  }

  // ---------- 画 2D ----------
  var W = 0, H = 0;
  function resize() {
    W = stage.clientWidth; H = stage.clientHeight;
    var dpr = window.devicePixelRatio || 1;
    cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr);
    cv.style.width = W + 'px'; cv.style.height = H + 'px';
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    if (sc3) sc3.resize(W, H);
    radialChart();
  }
  new ResizeObserver(resize).observe(stage);
  function topY() { return W <= 760 ? 84 : 46; }
  function draw2d() {
    ctx.clearRect(0, 0, W, H);
    ctx.fillStyle = '#05070d'; ctx.fillRect(0, 0, W, H);
    var s = state.scene, y0 = topY();
    if (s === 'config') {
      var ck = Or.check(state.Z, state.boxes);
      ctx.fillStyle = D.C.muted; ctx.font = '12px -apple-system, "PingFang SC", sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'top';
      ctx.fillText('轨道表示式（按能层顺序书写）', W / 2, y0);
      var hRow = D.orbRow(ctx, { boxes: state.boxes, x: 16, y: y0 + 20, w: W - 32, maxS: 26, bad: ck.sub });
      hits = D.ladder(ctx, W, H - 44, { boxes: state.boxes, hl: state.hl, bad: ck.sub, top: y0 + 20 + hRow + 6 });
    } else if (s === 'quiz' && state.quiz) {
      var q = state.quiz;
      if (q.type === 'rule' || (state.answered && q.boxes)) {
        ctx.fillStyle = D.C.text; ctx.font = '600 22px -apple-system, "PingFang SC", sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'top';
        ctx.fillText(q.Z + ' ' + Or.SYM[q.Z - 1] + (q.type === 'rule' ? '' : '（基态）'), W / 2, y0 + 30);
        var rb = q.type === 'rule' ? q.boxes : Or.boxesOf(Or.ground(q.Z));
        D.orbRow(ctx, { boxes: rb, x: 20, y: y0 + 74, w: W - 40, maxS: 40, bad: state.answered && q.type === 'rule' ? Or.check(q.Z, rb).sub : null });
        if (state.answered && q.type !== 'rule') {
          ctx.fillStyle = D.C.gold; ctx.font = '16px -apple-system, sans-serif'; ctx.textBaseline = 'top';
          ctx.fillText(Or.config(Or.ground(q.Z), false), W / 2, y0 + 150);
        }
      } else if (q.Z) D.card(ctx, W, H, q.Z);
      else D.card(ctx, W, H, 0, q.type === 'count' ? (/能层/.test(q.prompt) ? 'n = ' + q.prompt.match(/第 (\d)/)[1] : q.prompt.split(' ')[0]) : '?');
    } else if (!sc3) {
      ctx.fillStyle = D.C.muted; ctx.font = '14px sans-serif'; ctx.textAlign = 'center';
      ctx.fillText('此浏览器不支持 WebGL，无法显示 3D 电子云', W / 2, H / 2);
    }
  }

  // 支持 ?scene=cloud|config|quiz、&orb=1s|2px|…|ns|p2|d3、&view=dots|surf|both、&cut=1、&sign=1、&axes=0、&spin=0、&n=点数，
  // 排布 &el=Fe 或 &z=26、&fill=1（逐个填入）、&excite=1，练习 &q=shape|config|rule|count
  var qs = new URLSearchParams(location.search);
  if (HINTS[qs.get('scene')]) state.scene = qs.get('scene');
  var o0 = qs.get('orb');
  if (o0 && (Or.ORBS[o0] || Or.GROUPS[o0])) state.sel = o0;
  if (/^(dots|surf|both)$/.test(qs.get('view') || '')) state.view = qs.get('view');
  if (qs.get('cut') === '1') state.cut = true;
  if (qs.get('sign') === '1') state.sign = true;
  if (qs.get('axes') === '0') state.axes = false;
  if (qs.get('spin') === '0') state.spin = false;
  if (+qs.get('n') >= 1000) state.count = Math.min(30000, Math.round(+qs.get('n') / 1000) * 1000);
  var z0 = Or.SYM.indexOf(qs.get('el')) + 1 || +qs.get('z');
  if (z0 >= 1 && z0 <= 36) state.Z = z0;
  if (quizTypes.indexOf(qs.get('q')) >= 0) state.quizOnly = qs.get('q');
  resize();
  setZ(state.Z);
  if (qs.get('fill') === '1') startFill();
  else if (qs.get('excite') === '1') $('excite').click();
  setScene(state.scene);

  var last = performance.now();
  function frame(now) {
    var dt = Math.min(0.05, (now - last) / 1000);
    last = now;
    var s = state.scene, p = state.play;
    if (p) {
      p.t += dt;
      var iv = Math.max(0.16, Math.min(0.55, 7 / state.Z));
      if (p.t > iv) {
        p.t = 0;
        if (p.k < p.steps.length - 1) {
          var a = p.steps[p.k], b = p.steps[p.k + 1];
          p.k++;
          state.boxes = Or.copyBoxes(b);
          state.hl = Or.SUBS.filter(function (sb) { return a[sb.id].join() !== b[sb.id].join() && Or.countsOf(b)[sb.id] >= Or.countsOf(a)[sb.id]; }).map(function (sb) { return sb.id; })[0] || state.hl;
          syncUI();
        } else if (p.t === 0 && p.k >= p.steps.length - 1) { p.hold = (p.hold || 0) + 1; if (p.hold > 3) { state.play = null; state.hl = null; syncUI(); } }
      }
    }
    if (s === 'cloud') readCloud();
    else if (s === 'config') readConfig();
    else readQuiz();
    if (use3d()) {
      var q = state.quiz;
      if (s === 'cloud') sc3.show({ list: list(), mode: state.view, sign: state.sign, cut: state.cut, axes: state.axes, count: state.count, labels: true });
      else sc3.show({ list: [q.orb], mode: 'surf', sign: false, cut: false, axes: true, count: 0, labels: false });
      sc3.render();
    } else draw2d();
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // 调试用
  window.__model = {
    state: state, Or: Or, scene: sc3, setSel: setSel, setScene: setScene, setZ: setZ, startFill: startFill, newQuiz: newQuiz, sync: syncUI,
    answer: function (o) { answer(o == null ? state.quiz.answer : o); }
  };
})();
