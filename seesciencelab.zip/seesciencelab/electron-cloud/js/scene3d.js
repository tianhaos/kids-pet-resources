// 原子轨道与电子云：three.js 场景（电子云点图、90% 电子云轮廓图、剖开一半、坐标轴与 100 pm 刻度）
// 内部用化学坐标（x、y 水平，z 向上，单位 a₀），由 chem 组旋转到 three 坐标：(x, y, z) → (x, z, −y)
(function () {
  var Or = window.Orbital;
  var V3 = THREE.Vector3;
  var SIGN = [0xffb74d, 0x4fc3f7];          // ψ > 0、ψ < 0
  var MONO = 0x7fd3ff;
  var PAL = [0xff7a59, 0x7ee081, 0x4fc3f7, 0xffc94a, 0xc9a7ff];
  var FIT = 4.6;                            // 画面中电子云的外缘约 4.6 单位

  function dotTexture() {
    var c = document.createElement('canvas'); c.width = c.height = 32;
    var g = c.getContext('2d'), gr = g.createRadialGradient(16, 16, 0, 16, 16, 16);
    gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(0.45, 'rgba(255,255,255,.8)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = gr; g.fillRect(0, 0, 32, 32);
    return new THREE.CanvasTexture(c);
  }

  window.OrbitalScene = function (container) {
    var renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.localClippingEnabled = true;
    container.appendChild(renderer.domElement);
    var canvas = renderer.domElement;
    canvas.id = 'view3d';

    var labelRenderer = new THREE.CSS2DRenderer();
    var ls = labelRenderer.domElement.style;
    ls.position = 'absolute'; ls.top = '0'; ls.left = '0'; ls.pointerEvents = 'none'; ls.zIndex = '2';
    labelRenderer.domElement.id = 'labels3d';
    container.appendChild(labelRenderer.domElement);

    var scene = new THREE.Scene();
    scene.background = new THREE.Color('#05070d');
    var camera = new THREE.PerspectiveCamera(34, 1, 0.1, 500);
    scene.add(camera);
    scene.add(new THREE.AmbientLight(0xffffff, 0.42));
    var key = new THREE.DirectionalLight(0xffffff, 0.8);
    key.position.set(-4, 6, 8);
    camera.add(key);
    var rim = new THREE.DirectionalLight(0x9fc8ff, 0.3);
    rim.position.set(6, -3, -4);
    camera.add(rim);

    var controls = new THREE.OrbitControls(camera, canvas);
    controls.enableDamping = true;
    controls.dampingFactor = 0.08;
    controls.enablePan = false;
    controls.minDistance = 6;
    controls.maxDistance = 60;
    controls.autoRotateSpeed = 0.7;
    var spinStopped = false;
    controls.addEventListener('start', function () { controls.autoRotate = false; spinStopped = true; });

    var chem = new THREE.Group();
    chem.rotation.x = -Math.PI / 2;
    scene.add(chem);
    var gCloud = new THREE.Group(), gAxes = new THREE.Group();
    chem.add(gCloud); chem.add(gAxes);
    var nucleus = new THREE.Mesh(new THREE.SphereGeometry(1, 20, 14), new THREE.MeshBasicMaterial({ color: 0xff5252 }));
    scene.add(nucleus);
    var cutPlane = new THREE.Plane(new V3(0, 0, -1), 0), CLIP = [cutPlane];
    var tex = dotTexture();

    function clear(g) {
      for (var i = g.children.length - 1; i >= 0; i--) {
        var o = g.children[i];
        if (o.children && o.children.length) clear(o);
        if (o.isCSS2DObject && o.element.parentNode) o.element.parentNode.removeChild(o.element);
        if (o.geometry && !o.geometry.userData.keep) o.geometry.dispose();
        if (o.material && o.material.dispose) o.material.dispose();
        g.remove(o);
      }
    }
    function label(g, html, cls, p) {
      var el = document.createElement('div');
      el.className = 'lab ' + (cls || '');
      el.innerHTML = html;
      var o = new THREE.CSS2DObject(el);
      o.position.set(p[0], p[1], p[2]);
      g.add(o);
      return o;
    }
    function hexCss(c) { return '#' + ('00000' + c.toString(16)).slice(-6); }

    // 每个轨道朝外的一个方向（放标签）
    var TIP = { s: [0.62, -0.62, 0.48], px: [1, 0, 0], py: [0, 1, 0], pz: [0, 0, 1], dxy: [0.71, 0.71, 0], dxz: [0.71, 0, 0.71],
      dyz: [0, 0.71, 0.71], dx2y2: [-1, 0, 0], dz2: [0, 0, 1] };

    var sig = '', cur = null, scale = 1, target = 1, reveal = 1, revealT = 0;
    // opts：{ list, mode 'dots'|'surf'|'both', sign, cut, axes, count, labels }
    function build(o) {
      clear(gCloud); clear(gAxes);
      var list = o.list, multi = list.length > 1, bound = 0;
      cur = { o: o, points: [], surfs: [] };
      list.forEach(function (id, idx) {
        var orb = Or.ORBS[id], col = multi ? PAL[idx % PAL.length] : MONO, is = Or.iso(id);
        bound = Math.max(bound, is.bound);
        if (o.mode !== 'surf') {
          var n = Math.round(o.count / (multi ? Math.min(list.length, 3) : 1)), sm = Or.sample(id, n, Or.rng(11 + idx * 101 + n));
          var geo = new THREE.BufferGeometry(), cols = new Float32Array(n * 3), cc = new THREE.Color();
          for (var i = 0; i < n; i++) {
            cc.setHex(o.sign ? SIGN[sm.sign[i] > 0 ? 0 : 1] : col);
            cols[3 * i] = cc.r; cols[3 * i + 1] = cc.g; cols[3 * i + 2] = cc.b;
          }
          geo.setAttribute('position', new THREE.BufferAttribute(sm.pos, 3));
          geo.setAttribute('color', new THREE.BufferAttribute(cols, 3));
          var pm = new THREE.PointsMaterial({ size: n > 15000 ? 0.08 : 0.12, map: tex, vertexColors: true, transparent: true, depthWrite: false,
            blending: THREE.AdditiveBlending, opacity: o.mode === 'both' ? 0.55 : 0.9, clippingPlanes: CLIP });
          var pts = new THREE.Points(geo, pm);
          pts.frustumCulled = false;
          gCloud.add(pts);
          cur.points.push(pts);
        }
        if (o.mode !== 'dots') {
          var ms = Or.mesh(id);
          [['plus', 0], ['minus', 1]].forEach(function (pr) {
            var d = ms[pr[0]];
            if (!d.pos.length) return;
            var g = new THREE.BufferGeometry();
            g.setAttribute('position', new THREE.BufferAttribute(d.pos, 3));
            g.setAttribute('normal', new THREE.BufferAttribute(d.nrm, 3));
            g.userData.keep = true;    // 网格缓存在 Orbital 里，几何体也复用
            var op = o.mode === 'both' ? 0.35 : multi ? 0.4 : 0.88;
            var mat = new THREE.MeshStandardMaterial({ color: o.sign ? SIGN[pr[1]] : col, roughness: 0.45, metalness: 0.05,
              side: THREE.DoubleSide, transparent: op < 1, opacity: op, depthWrite: !multi && o.mode !== 'both', clippingPlanes: CLIP });
            var me = new THREE.Mesh(g, mat);
            me.renderOrder = 1;
            gCloud.add(me);
            cur.surfs.push(me);
          });
        }
        if (o.labels && multi) {
          var t = TIP[orb.a], r = orb.l === 0 ? Or.rWithin(orb.n, 0, 0.9) : is.bound * 0.82;
          label(gCloud, orb.html, 'orb', [t[0] * r, t[1] * r, t[2] * r]).element.style.color = hexCss(col);
        }
      });
      cur.bound = bound;
      target = FIT / bound;
      // 坐标轴与 100 pm 刻度
      if (o.axes) {
        var L = bound * 1.12, pts2 = [], step = 100 / Or.A0;
        [[1, 0, 0], [0, 1, 0], [0, 0, 1]].forEach(function (a) {
          pts2.push(new V3(-L * a[0], -L * a[1], -L * a[2]), new V3(L * a[0], L * a[1], L * a[2]));
          for (var k = step; k < L; k += step) [-1, 1].forEach(function (sg) {
            var c = new V3(a[0], a[1], a[2]).multiplyScalar(sg * k), e = (a[2] ? new V3(1, 0, 0) : new V3(0, 0, 1)).multiplyScalar(L * 0.012);
            pts2.push(c.clone().sub(e), c.clone().add(e));
          });
        });
        var ag = new THREE.BufferGeometry().setFromPoints(pts2);
        gAxes.add(new THREE.LineSegments(ag, new THREE.LineBasicMaterial({ color: 0x8d99ab, transparent: true, opacity: 0.55 })));
        label(gAxes, 'x', 'axis', [L * 1.05, 0, 0]); label(gAxes, 'y', 'axis', [0, L * 1.05, 0]); label(gAxes, 'z', 'axis', [0, 0, L * 1.05]);
        var nt = Math.floor(L / step);
        if (nt >= 1) label(gAxes, nt > 1 ? '每格 100 pm' : '100 pm', 'tick', [step * Math.ceil(nt / 2), 0, -L * 0.07]);
      }
    }
    function show(o) {
      var s = JSON.stringify(o);
      gCloud.visible = gAxes.visible = nucleus.visible = true;
      if (s !== sig) {
        var oldList = cur ? cur.o.list.join() : '';
        sig = s; build(o);
        if (oldList !== o.list.join() || o.replay) { reveal = 0; revealT = 0; }
        if (!oldList) { scale = target; reveal = 1; }
      }
    }
    function replay() { reveal = 0; revealT = 0; }
    function blank() { gCloud.visible = gAxes.visible = nucleus.visible = false; }

    function homeCam() {
      var aspect = Math.max(0.55, Math.min(1, camera.aspect || 1));
      var dist = FIT * 1.18 / Math.tan(camera.fov * Math.PI / 360) / aspect;
      controls.target.set(0, 0, 0);
      camera.position.copy(new V3(0.55, 0.42, 1).normalize().multiplyScalar(dist));
      controls.update();
    }

    function resize(w, h) {
      camera.aspect = w / Math.max(1, h);
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
      labelRenderer.setSize(w, h);
      if (!spinStopped) homeCam();     // 用户还没转动过视角时，随画面比例重新取景
    }
    var last = performance.now();
    function render() {
      var now = performance.now(), dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      scale += (target - scale) * Math.min(1, dt * 5);
      chem.scale.setScalar(scale);
      nucleus.scale.setScalar(0.06 + 0.04 * Math.min(1, scale));
      // 打点：小点逐渐出现
      if (cur && reveal < 1) {
        revealT += dt; reveal = Math.min(1, revealT / 2.4);
        var f = reveal * reveal;
        cur.points.forEach(function (p) { p.geometry.setDrawRange(0, Math.ceil(p.geometry.attributes.position.count * f)); });
        cur.surfs.forEach(function (m) { m.material.opacity = m.userData.op == null ? (m.userData.op = m.material.opacity) * f : m.userData.op * f; });
      } else if (cur) cur.surfs.forEach(function (m) { if (m.userData.op != null) m.material.opacity = m.userData.op; });
      // 剖开：去掉靠近观察者的一半
      var on = cur && cur.o.cut;
      cutPlane.normal.copy(camera.position).normalize().negate();
      cutPlane.constant = on ? 0 : 1e6;
      controls.update();
      renderer.render(scene, camera);
      labelRenderer.render(scene, camera);
    }
    function spin(on) { controls.autoRotate = !!on && !spinStopped; }
    function revealing() { return reveal < 1; }

    homeCam();
    return { show: show, blank: blank, replay: replay, render: render, resize: resize, home: homeCam, spin: spin, revealing: revealing,
      canvas: canvas, labels: labelRenderer.domElement, camera: camera, controls: controls };
  };
})();
