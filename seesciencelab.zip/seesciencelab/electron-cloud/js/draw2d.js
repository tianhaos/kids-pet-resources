// 原子轨道与电子云：Canvas 绘图（能级图与轨道表示式、径向分布曲线、元素卡片）
(function () {
  var Or = window.Orbital;
  var C = { text: '#e6ebf2', muted: '#8d99ab', line: '#2a3446', box: '#8d99ab', gold: '#ffc94a', bad: '#ff7a59', blue: '#4fc3f7', green: '#7ee081' };
  // 示意能量（只表示高低次序，3d 介于 4s、4p 之间）
  var EN = { '1s': 0, '2s': 2.3, '2p': 3.0, '3s': 4.3, '3p': 5.0, '4s': 6.0, '3d': 6.55, '4p': 7.15 };
  var COL = { 0: 0, 1: 1, 2: 2 };

  function font(ctx, px, w) { ctx.font = (w || '') + ' ' + px + 'px -apple-system, "PingFang SC", "Microsoft YaHei", sans-serif'; }
  function rr(ctx, x, y, w, h, r) { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }

  // 一个方框里的电子：v 为 0 空、1 ↑、2 ↑↓、3 ↓、4 ↑↑
  function arrows(ctx, x, y, s, v, col) {
    var dirs = [[], [1], [1, -1], [-1], [1, 1]][v];
    ctx.strokeStyle = ctx.fillStyle = v === 4 ? C.bad : col || C.gold;
    ctx.lineWidth = Math.max(1.4, s * 0.06);
    dirs.forEach(function (d, k) {
      var cx = x + s * (dirs.length === 1 ? 0.5 : k === 0 ? 0.34 : 0.66), top = y + s * 0.18, bot = y + s * 0.82, hd = s * 0.16;
      ctx.beginPath(); ctx.moveTo(cx, top); ctx.lineTo(cx, bot); ctx.stroke();
      var tip = d > 0 ? top : bot;
      ctx.beginPath(); ctx.moveTo(cx, tip); ctx.lineTo(cx - hd * 0.6, tip + d * hd); ctx.lineTo(cx + hd * 0.6, tip + d * hd); ctx.closePath(); ctx.fill();
    });
  }
  function boxRow(ctx, x, y, s, row, hl) {
    for (var i = 0; i < row.length; i++) {
      ctx.fillStyle = hl ? 'rgba(255,201,74,.10)' : 'rgba(26,34,49,.9)';
      ctx.fillRect(x + i * s, y, s, s);
      ctx.strokeStyle = C.box; ctx.lineWidth = 1;
      ctx.strokeRect(x + i * s + 0.5, y + 0.5, s, s);
      arrows(ctx, x + i * s, y, s, row[i]);
    }
  }

  // 轨道表示式（按能层书写顺序）。opt：{ boxes, x, y, w, maxS, bad, all }；返回占用高度
  function orbRow(ctx, opt) {
    var b = opt.boxes, c = Or.countsOf(b), ids = Or.WRITE.filter(function (id) { return c[id] || (opt.all && opt.all.indexOf(id) >= 0); });
    if (!ids.length) ids = ['1s'];
    var nb = 0;
    ids.forEach(function (id) { nb += Or.SUB[id].m; });
    var s = Math.min(opt.maxS || 30, opt.w / (nb + ids.length * 0.55)), gap = s * 0.55, tw = nb * s + (ids.length - 1) * gap;
    var x = opt.x + (opt.w - tw) / 2, y = opt.y;
    font(ctx, Math.max(10, s * 0.48));
    ctx.textAlign = 'center'; ctx.textBaseline = 'top';
    ids.forEach(function (id) {
      var m = Or.SUB[id].m;
      boxRow(ctx, x, y, s, b[id], false);
      if (opt.bad === id) { ctx.strokeStyle = C.bad; ctx.lineWidth = 2; ctx.strokeRect(x - 2, y - 2, m * s + 4, s + 4); }
      ctx.fillStyle = C.muted;
      ctx.fillText(id, x + m * s / 2, y + s + 4);
      x += m * s + gap;
    });
    return s * 1.5 + 8;
  }

  // 能级图（按能量高低排列，横向按 s、p、d 分列）。st：{ boxes, hl, bad, path }；返回可点击区域
  function ladder(ctx, W, H, st) {
    var hits = { boxes: [], labels: [] };
    var top = st.top || 0, padL = W < 520 ? 40 : 64, padR = 12, padB = 30, avail = W - padL - padR;
    var s = Math.max(18, Math.min(36, (avail - 3 * 30 - 20) / 9)), lab = Math.max(30, Math.min(s * 1.25, (avail - 9 * s - 20) / 3));
    var colW = [s + lab, 3 * s + lab, 5 * s + lab], gapC = Math.max(10, (avail - colW[0] - colW[1] - colW[2]) / 2.6);
    var x0 = padL + Math.max(0, (avail - colW[0] - colW[1] - colW[2] - 2 * gapC) / 2);
    var colX = [x0, x0 + colW[0] + gapC, x0 + colW[0] + colW[1] + 2 * gapC];
    var yTop = top + 22 + s, yBot = H - padB - s, k = (yBot - yTop) / EN['4p'];
    function yOf(id) { return yBot - EN[id] * k; }
    // 能量轴
    ctx.strokeStyle = C.muted; ctx.fillStyle = C.muted; ctx.lineWidth = 1.2;
    var ax = padL - 22;
    ctx.beginPath(); ctx.moveTo(ax, yBot + s); ctx.lineTo(ax, yTop - 6); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(ax, yTop - 12); ctx.lineTo(ax - 4, yTop - 3); ctx.lineTo(ax + 4, yTop - 3); ctx.closePath(); ctx.fill();
    font(ctx, 12);
    ctx.save(); ctx.translate(ax - 9, (yTop + yBot) / 2); ctx.rotate(-Math.PI / 2); ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText('能量', 0, 0); ctx.restore();
    ctx.textAlign = 'center'; ctx.textBaseline = 'alphabetic';
    ctx.textBaseline = 'top';
    ['s 能级', 'p 能级', 'd 能级'].forEach(function (t, i) { ctx.fillText(t, colX[i] + lab + (colW[i] - lab) / 2, top); });

    var pos = {};
    Or.SUBS.forEach(function (sb) { pos[sb.id] = { x: colX[COL[sb.l]] + lab, y: yOf(sb.id) - s / 2 }; });
    // 构造原理：按填充顺序连线
    if (st.path !== false) {
      ctx.save();
      ctx.strokeStyle = 'rgba(79,195,247,.35)'; ctx.lineWidth = 1.2; ctx.setLineDash([4, 4]);
      ctx.beginPath();
      Or.SUBS.forEach(function (sb, i) {
        var p = pos[sb.id], cx = p.x - lab * 0.5, cy = p.y + s / 2;
        if (i) ctx.lineTo(cx, cy); else ctx.moveTo(cx, cy);
      });
      ctx.stroke(); ctx.restore();
    }
    Or.SUBS.forEach(function (sb) {
      var p = pos[sb.id], hl = st.hl === sb.id, row = st.boxes[sb.id];
      boxRow(ctx, p.x, p.y, s, row, hl);
      if (st.bad === sb.id) { ctx.strokeStyle = C.bad; ctx.lineWidth = 2; ctx.strokeRect(p.x - 3, p.y - 3, sb.m * s + 6, s + 6); }
      for (var i = 0; i < sb.m; i++) hits.boxes.push({ sub: sb.id, i: i, x: p.x + i * s, y: p.y, w: s, h: s });
      // 能级符号（可点：去看它的电子云）
      var lx = p.x - lab, ly = p.y + (s - 22) / 2;
      rr(ctx, lx + 2, ly, lab - 8, 22, 6);
      ctx.fillStyle = hl ? 'rgba(255,201,74,.18)' : 'rgba(17,23,35,.9)'; ctx.fill();
      ctx.strokeStyle = hl ? C.gold : C.line; ctx.lineWidth = 1; ctx.stroke();
      ctx.fillStyle = hl ? C.gold : C.text; font(ctx, 13, '600');
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText(sb.id, lx + 2 + (lab - 8) / 2, ly + 11.5);
      hits.labels.push({ sub: sb.id, x: lx, y: ly, w: lab - 4, h: 22 });
    });
    // 能级交错标注
    var p4 = pos['4s'], p3 = pos['3d'];
    font(ctx, 11); ctx.fillStyle = C.muted; ctx.textAlign = 'left'; ctx.textBaseline = 'bottom';
    if (W >= 420) ctx.fillText('E(4s) < E(3d) < E(4p)', p3.x, p3.y - 4);
    void p4;
    hits.s = s;
    return hits;
  }

  // 径向分布曲线 P(r) = r²R²：list 为轨道 id，cols 为颜色
  function radial(ctx, W, H, list, cols) {
    ctx.clearRect(0, 0, W, H);
    var L = 34, Rr = 10, T = 10, B = 26, pw = W - L - Rr, ph = H - T - B;
    var uniq = [], cl = [];
    list.forEach(function (id, i) { var o = Or.ORBS[id], k = o.n + ',' + o.l; if (uniq.indexOf(k) < 0) { uniq.push(k); cl.push(cols[i]); } });
    var rmax = 0, pmax = 0, curves = uniq.map(function (k) {
      var n = +k[0], l = +k[2], r9 = Or.rWithin(n, l, 0.995);
      rmax = Math.max(rmax, r9);
      return { n: n, l: l };
    });
    var xm = niceMax(rmax * Or.A0);
    var M = 240, data = curves.map(function (c) {
      var a = [];
      for (var i = 0; i <= M; i++) { var r = xm / Or.A0 * i / M, p = Or.P(c.n, c.l, r); a.push(p); pmax = Math.max(pmax, p); }
      return a;
    });
    ctx.strokeStyle = C.line; ctx.lineWidth = 1;
    ctx.strokeRect(L + 0.5, T + 0.5, pw, ph);
    font(ctx, 10.5); ctx.fillStyle = C.muted; ctx.textAlign = 'center'; ctx.textBaseline = 'top';
    var step = xm / 4;
    for (var g = 0; g <= 4; g++) {
      var gx = L + pw * g / 4;
      ctx.fillText(Math.round(g * step), gx, T + ph + 4);
      if (g && g < 4) { ctx.strokeStyle = 'rgba(42,52,70,.6)'; ctx.beginPath(); ctx.moveTo(gx + 0.5, T); ctx.lineTo(gx + 0.5, T + ph); ctx.stroke(); }
    }
    ctx.textAlign = 'right'; ctx.fillText('r/pm', W - 2, T + ph + 14);
    ctx.save(); ctx.translate(11, T + ph / 2); ctx.rotate(-Math.PI / 2); ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText('径向概率', 0, 0); ctx.restore();
    data.forEach(function (a, j) {
      ctx.strokeStyle = cl[j]; ctx.lineWidth = 1.8;
      ctx.beginPath();
      a.forEach(function (p, i) { var x = L + pw * i / M, y = T + ph - p / pmax * ph * 0.94; if (i) ctx.lineTo(x, y); else ctx.moveTo(x, y); });
      ctx.stroke();
    });
    // 单个轨道：标出最大值位置与 90% 半径
    if (curves.length === 1) {
      var c = curves[0], best = 0, br = 0;
      data[0].forEach(function (p, i) { if (p > best) { best = p; br = i; } });
      var bx = L + pw * br / M, rp = xm * br / M;
      ctx.strokeStyle = 'rgba(255,201,74,.7)'; ctx.setLineDash([3, 3]);
      ctx.beginPath(); ctx.moveTo(bx, T + ph); ctx.lineTo(bx, T + ph * 0.06); ctx.stroke();
      var r90 = Or.rWithin(c.n, c.l, 0.9) * Or.A0, x9 = L + pw * r90 / xm;
      ctx.strokeStyle = 'rgba(141,153,171,.8)';
      ctx.beginPath(); ctx.moveTo(x9, T + ph); ctx.lineTo(x9, T + ph * 0.3); ctx.stroke();
      ctx.setLineDash([]);
      font(ctx, 10.5); ctx.textBaseline = 'top';
      ctx.fillStyle = C.gold; ctx.textAlign = bx > L + pw * 0.6 ? 'right' : 'left';
      ctx.fillText(' 最大 ' + Math.round(rp) + ' pm ', bx, T + 2);
      ctx.fillStyle = C.muted; ctx.textAlign = x9 > L + pw * 0.7 ? 'right' : 'left';
      ctx.fillText(' 90% 在 ' + Math.round(r90) + ' pm 内 ', x9, T + ph * 0.3);
    }
  }
  function niceMax(v) {
    var e = Math.pow(10, Math.floor(Math.log10(v))), m = v / e;
    return (m <= 1 ? 1 : m <= 2 ? 2 : m <= 4 ? 4 : m <= 5 ? 5 : m <= 8 ? 8 : 10) * e;
  }

  // 元素卡片（练习题未作答时）
  function card(ctx, W, H, Z, text) {
    var w = Math.min(220, W * 0.5), h = w * 1.05, x = (W - w) / 2, y = Math.max(60, H * 0.36 - h / 2);
    rr(ctx, x, y, w, h, 16);
    ctx.fillStyle = '#111723'; ctx.fill(); ctx.strokeStyle = C.line; ctx.lineWidth = 1.5; ctx.stroke();
    ctx.textAlign = 'left'; ctx.textBaseline = 'top'; ctx.fillStyle = C.muted; font(ctx, w * 0.11);
    ctx.fillText(Z ? String(Z) : '', x + w * 0.1, y + w * 0.08);
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = C.text; font(ctx, w * 0.36, '600');
    ctx.fillText(Z ? Or.SYM[Z - 1] : text || '?', x + w / 2, y + h * 0.5);
    font(ctx, w * 0.1); ctx.fillStyle = C.muted;
    if (Z) ctx.fillText(Or.NAME[Z - 1], x + w / 2, y + h * 0.82);
  }

  window.OrbDraw = { ladder: ladder, orbRow: orbRow, radial: radial, card: card, arrows: arrows, C: C };
})();
