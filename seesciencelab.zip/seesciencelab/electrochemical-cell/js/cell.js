/* 电化学计量：恒定电流示意，电荷 C、时间 s、物质的量 mol、质量 g。 */
(function () {
  'use strict';
  const F = 96485, MAX_Q = 1930;
  const scenes = {
    galvanic: {name:'铜锌原电池', left:'Zn', right:'Cu', leftRole:'负极 · 氧化', rightRole:'正极 · 还原', leftEq:'Zn − 2e⁻ → Zn²⁺', rightEq:'Cu²⁺ + 2e⁻ → Cu', total:'Zn + Cu²⁺ → Zn²⁺ + Cu', energy:'化学能 → 电能', leftSign:'−', rightSign:'+'},
    electrolysis: {name:'电解 CuCl₂', left:'石墨', right:'石墨', leftRole:'阳极 · 氧化', rightRole:'阴极 · 还原', leftEq:'2Cl⁻ − 2e⁻ → Cl₂↑', rightEq:'Cu²⁺ + 2e⁻ → Cu', total:'CuCl₂ →（通电）Cu + Cl₂↑', energy:'电能 → 化学能', leftSign:'+', rightSign:'−'}
  };
  function clamp(x,a,b) {return Math.max(a,Math.min(b,x));}
  function sample(scene,q) {
    q = clamp(Number.isFinite(q)?q:0,0,MAX_Q);
    const n = q/(2*F), galvanic = scene === 'galvanic';
    return {q,n,e:q/F,cuMass:n*63.5,znMass:galvanic?-n*65.4:0,gas:galvanic?0:n,cuLeft:0.02-n,progress:q/MAX_Q};
  }
  function active(s) {return s.closed && (s.scene !== 'galvanic' || s.bridge) && s.q < MAX_Q;}
  function step(s,dt) {return active(s)?clamp(s.q+s.current*Math.max(0,dt),0,MAX_Q):s.q;}
  window.Cell = {F,MAX_Q,scenes,clamp,sample,active,step};
}());
