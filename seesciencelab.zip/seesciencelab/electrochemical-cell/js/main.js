(function () {
  'use strict';
  const $ = id => document.getElementById(id);
  const params = new URLSearchParams(location.search);
  const reduced = matchMedia('(prefers-reduced-motion: reduce)');
  const narrow = matchMedia('(max-width: 760px)');
  const sceneButtons = document.querySelectorAll('[data-scene]');
  const canvas = $('canvas'), panel = $('panel');
  const toggles = {
    closed: {input: $('closed'), button: $('wireControl')},
    bridge: {input: $('bridge'), button: $('bridgeControl')},
    electrons: {input: $('electrons')},
    ions: {input: $('ions')}
  };

  function number(key, fallback, min, max) {
    const raw = params.get(key);
    const value = raw?.trim() ? Number(raw) : NaN;
    return Number.isFinite(value) ? Cell.clamp(value, min, max) : fallback;
  }

  const state = {
    scene: params.get('scene') === 'electrolysis' ? 'electrolysis' : 'galvanic',
    q: number('q', 386, 0, Cell.MAX_Q),
    current: number('i', 2, .5, 5),
    closed: params.get('closed') !== '0',
    bridge: params.get('bridge') !== '0',
    play: reduced.matches ? params.get('play') === '1' : params.get('play') !== '0',
    electrons: true,
    ions: true,
    phase: 0
  };

  function track(action, label = state.scene) {
    if (window.Analytics) Analytics.track('原电池与电解池', action, label);
  }

  function preset(scene) {
    if (!Object.hasOwn(Cell.scenes, scene)) return;
    Object.assign(state, {scene, q: 0, phase: 0, closed: true, bridge: true});
    sync();
  }

  function text(id, value) {
    const node = $(id);
    if (node.textContent !== value) node.textContent = value;
  }

  function sync() {
    const model = Cell.scenes[state.scene];
    const galvanic = state.scene === 'galvanic';
    for (const button of sceneButtons) button.setAttribute('aria-pressed', button.dataset.scene === state.scene);
    for (const [key, {input, button}] of Object.entries(toggles)) {
      input.checked = state[key];
      button?.setAttribute('aria-pressed', state[key]);
    }
    $('bridgeRow').hidden = $('bridgeControl').hidden = !galvanic;
    $('current').value = state.current;
    text('play', state.play ? '暂停' : '播放');
    text('energy', model.energy);
    text('leftRole', `阳极 ${model.leftSign} · 氧化`);
    text('rightRole', `阴极 ${model.rightSign} · 还原`);
    text('leftEq', model.leftEq);
    text('rightEq', model.rightEq);
    text('total', model.total);
    text('otherLabel', galvanic ? '锌极质量变化' : '生成 Cl₂');
    canvas.setAttribute('aria-label', galvanic
      ? '铜锌原电池，电子由锌极流向铜极，硝酸根迁向锌侧，钾离子迁向铜侧'
      : '石墨电极电解氯化铜，阳极接电源正极并生成氯气，阴极接负极并析铜');
    render();
  }

  function render() {
    const galvanic = state.scene === 'galvanic';
    const value = Cell.sample(state.scene, state.q);
    const charge = `${value.q.toFixed(0)} C`;
    const copper = `${value.cuMass.toFixed(3)} g`;
    text('chargeValue', charge);
    text('stageCharge', `Q = ${charge}`);
    text('currentValue', `${state.current.toFixed(1)} A`);
    text('amount', `${(value.e * 1000).toFixed(2)} mmol`);
    text('copper', copper);
    text('stageCopper', `析铜 ${copper}`);
    text('remaining', `${(value.cuLeft * 1000).toFixed(2)} mmol`);
    text('other', galvanic ? `${value.znMass.toFixed(3)} g` : `${(value.gas * 1000).toFixed(2)} mmol`);
    const status = $('status');
    const active = Cell.active(state);
    const message = !state.closed ? '导线断开，反应停止'
      : galvanic && !state.bridge ? '盐桥移除，反应停止'
      : !active ? '已达演示终点'
      : state.play ? '反应进行中' : '已暂停';
    text('status', message);
    status.dataset.state = !active ? 'blocked' : state.play ? 'running' : 'paused';
    $('charge').value = Math.round(state.q);
    CellDraw.draw(canvas, state, reduced.matches);
  }

  function setToggle(key, value) {
    state[key] = value;
    sync();
    track('显示与回路', key + ':' + value);
  }

  for (const button of sceneButtons) {
    button.onclick = () => {
      if (button.dataset.scene === state.scene) return;
      preset(button.dataset.scene);
      track('切换场景');
    };
  }
  for (const [key, {input, button}] of Object.entries(toggles)) {
    input.onchange = () => setToggle(key, input.checked);
    if (button) button.onclick = () => setToggle(key, !state[key]);
  }

  $('current').oninput = () => {
    state.current = Number($('current').value);
    render();
  };
  $('current').onchange = () => track('改变电流', String(state.current));
  $('charge').oninput = () => {
    state.q = Number($('charge').value);
    state.play = false;
    sync();
  };
  $('charge').onchange = () => track('回看电荷', state.q.toFixed(0));
  $('play').onclick = () => {
    state.play = !state.play;
    sync();
    track('播放暂停');
  };
  $('reset').onclick = () => {
    state.q = state.phase = 0;
    sync();
    track('重新开始');
  };

  function showPanel(open, focus = false) {
    panel.classList.toggle('collapsed', !open);
    panel.inert = narrow.matches && !open;
    $('panelToggle').setAttribute('aria-expanded', open);
    if (focus) $(open ? 'panelClose' : 'panelToggle').focus();
  }

  showPanel(!narrow.matches);
  narrow.addEventListener('change', () => showPanel(!narrow.matches));
  $('panelToggle').onclick = () => showPanel(panel.classList.contains('collapsed'), true);
  $('panelClose').onclick = () => showPanel(false, true);
  panel.addEventListener('keydown', event => {
    if (event.key === 'Escape' && narrow.matches) showPanel(false, true);
  });

  $('share').onclick = async () => {
    const snapshot = new URLSearchParams({
      scene: state.scene, q: state.q.toFixed(0), i: state.current,
      closed: state.closed ? '1' : '0', bridge: state.bridge ? '1' : '0', play: '0'
    });
    const url = location.origin + location.pathname + '?' + snapshot;
    try {
      await navigator.clipboard.writeText(url);
      text('shareStatus', '已复制当前实验链接');
      track('复制链接');
    } catch (_) {
      text('shareStatus', url);
    }
  };

  let last = 0;
  function frame(now) {
    const elapsed = last ? Math.min((now - last) / 1000, .1) : 0;
    last = now;
    if (state.play && Cell.active(state)) {
      state.phase += elapsed;
      state.q = Cell.step(state, elapsed * 20);
      render();
    }
    requestAnimationFrame(frame);
  }

  window.__model = {state, preset, sync, sample: () => Cell.sample(state.scene, state.q)};
  new ResizeObserver(render).observe(canvas);
  reduced.addEventListener('change', render);
  sync();
  requestAnimationFrame(frame);
}());
