/* 等比例装置剖视图，所有标注与交互位置使用 640×410 坐标。 */
(function () {
  'use strict';
  const GOLD = '#ffc94a', BLUE = '#75d8fb', PURPLE = '#d4b9ff', GREEN = '#8ae7ae';
  const leftWire = [[138, 172], [138, 64], [273, 64]];
  const rightWire = [[367, 64], [502, 64], [502, 172]];
  const nitratePath = [[304, 158], [243, 158], [226, 175], [226, 269]];
  const potassiumPath = [[336, 158], [397, 158], [414, 175], [414, 269]];
  const chloridePath = [[288, 283], [167, 283]];
  const copperPath = [[350, 283], [472, 283]];
  let ctx;

  function label(value, x, y, size = 20, color = '#e6ebf2', weight = 500) {
    ctx.fillStyle = color;
    ctx.font = `${weight} ${size}px -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(value, x, y);
  }

  function stroke(points, color, width = 2) {
    ctx.beginPath();
    ctx.moveTo(...points[0]);
    for (const point of points.slice(1)) ctx.lineTo(...point);
    ctx.strokeStyle = color;
    ctx.lineWidth = width;
    ctx.stroke();
  }

  function rounded(x, y, w, h, r, fill, edge) {
    ctx.beginPath();
    ctx.roundRect(x, y, w, h, r);
    ctx.fillStyle = fill;
    ctx.fill();
    if (edge) {
      ctx.strokeStyle = edge;
      ctx.lineWidth = 1.5;
      ctx.stroke();
    }
  }

  function ellipse(x, y, rx, ry, fill, edge) {
    ctx.beginPath();
    ctx.ellipse(x, y, rx, ry, 0, 0, Math.PI * 2);
    if (fill) {
      ctx.fillStyle = fill;
      ctx.fill();
    }
    if (edge) {
      ctx.strokeStyle = edge;
      ctx.lineWidth = 1.5;
      ctx.stroke();
    }
  }

  function gradient(x1, y1, x2, y2, colors) {
    const paint = ctx.createLinearGradient(x1, y1, x2, y2);
    colors.forEach((color, i) => paint.addColorStop(i / (colors.length - 1), color));
    return paint;
  }

  function arrow(points, color) {
    const [a, b] = points;
    const angle = Math.atan2(b[1] - a[1], b[0] - a[0]);
    stroke(points, color, 2);
    stroke([-.58, 0, .58].map((offset, i) => i === 1 ? b : [
      b[0] - 9 * Math.cos(angle + offset), b[1] - 9 * Math.sin(angle + offset)
    ]), color, 2);
  }

  function particles(points, phase, count, color) {
    const lengths = points.slice(1).map(([x, y], i) => Math.hypot(x - points[i][0], y - points[i][1]));
    const length = lengths.reduce((sum, part) => sum + part, 0);
    for (let i = 0; i < count; i++) {
      const progress = (phase % 1 + i / count) % 1;
      let distance = progress * length;
      for (const [segment, part] of lengths.entries()) {
        if (distance <= part) {
          const [x, y] = points[segment], [endX, endY] = points[segment + 1];
          const fraction = distance / part;
          const opacity = Math.min(1, Math.min(progress, 1 - progress) * 16);
          ctx.globalAlpha = opacity;
          ellipse(x + (endX - x) * fraction, y + (endY - y) * fraction, 4.4, 4.4, color, '#0a111a');
          ctx.globalAlpha = 1;
          break;
        }
        distance -= part;
      }
    }
  }

  function circuit(s, galvanic, active, moving) {
    const leftContact = [170, 64], rightContact = [208, 64];
    stroke([...leftWire.slice(0, 2), leftContact], '#687f96', 7);
    stroke([rightContact, leftWire[2]], '#687f96', 7);
    stroke(rightWire, '#687f96', 7);
    stroke([leftContact, s.closed ? rightContact : [207, 46]], s.closed ? '#afc3d6' : GOLD, 4);
    for (const [x, y] of [leftContact, rightContact]) ellipse(x, y, 5, 5, '#839bb2', '#c6d4e1');
    label(s.closed ? '导线接通' : '导线断开', 189, 92, 19, GOLD);

    rounded(269, 40, 102, 49, 9, gradient(0, 40, 0, 89, ['#293849', '#131c29']), '#52677e');
    if (galvanic) {
      stroke([[282, 60], [291, 60], [296, 53], [304, 67], [312, 53], [320, 67],
        [328, 53], [336, 67], [344, 53], [349, 60], [358, 60]], '#e4ba79');
      label('负载', 320, 78, 16);
    } else {
      label('+', 284, 65, 24, '#ffb5a6');
      label('直流电源', 320, 65, 17);
      label('−', 356, 65, 24, BLUE);
    }

    if (!active || !s.electrons) return;
    label(galvanic ? 'e⁻  锌极 → 铜极' : 'e⁻  阳极 → 电源正极    ·    电源负极 → 阴极', 320, 21, 20, GOLD);
    arrow([[221, 49], [255, 49]], GOLD);
    arrow([[389, 49], [428, 49]], GOLD);
    if (moving) {
      particles(leftWire, s.phase / 3.1, 3, GOLD);
      particles(rightWire, s.phase / 3.1 + .12, 3, GOLD);
    }
  }

  function glass(x, w, color) {
    const rim = 203, bottom = 358;
    ellipse(x + w / 2, bottom + 3, w * .52, 12, '#02050a99');
    rounded(x, rim, w, bottom - rim, 17,
      gradient(x, rim, x + w, rim, ['#293a4b72', '#101c2655', '#26364870']));
    rounded(x + 5, 240, w - 10, 113, 13,
      gradient(0, 240, 0, 353, color));
    ellipse(x + w / 2, 240, w / 2 - 5, 8, color[0], color[1]);
  }

  function glassFront(x, w) {
    const right = x + w;
    ctx.beginPath();
    ctx.moveTo(x, 203);
    ctx.lineTo(x, 338);
    ctx.quadraticCurveTo(x, 358, x + 19, 358);
    ctx.lineTo(right - 19, 358);
    ctx.quadraticCurveTo(right, 358, right, 338);
    ctx.lineTo(right, 203);
    ctx.strokeStyle = '#92b1c98a';
    ctx.lineWidth = 2;
    ctx.stroke();
    ellipse(x + w / 2, 203, w / 2, 9, null, '#a7c6dc79');
    stroke([[x + 11, 222], [x + 11, 332]], '#b6dbed48', 3);
    stroke([[right - 9, 248], [right - 9, 331]], '#85c0e035', 2);
  }

  function electrode(x, side, galvanic, model, progress) {
    const left = side === 'left';
    const labelX = x + (left ? -54 : 54);
    const width = galvanic && left ? 31 - progress * 11 : 31;
    const colors = galvanic
      ? (left ? ['#68798b', '#d1dce4', '#637384'] : ['#7d412d', '#df9c69', '#915637'])
      : ['#27303b', '#657185', '#303948'];
    ellipse(x, 171, 8, 8, '#8099ae', '#bad0df');
    const metal = gradient(x - 15.5, 170, x + 15.5, 170, colors);
    if (galvanic && left) {
      rounded(x - 15.5, 170, 31, 70, [4, 4, 0, 0], metal, '#a9bed154');
      rounded(x - width / 2, 239, width, 94, [0, 0, 4, 4], metal, '#a9bed154');
    } else {
      rounded(x - 15.5, 170, 31, 163, 4, metal, '#a9bed154');
    }
    if (!left && progress > 0) {
      const growth = progress * 11;
      const height = galvanic ? 82 : 82 * Math.sqrt(progress);
      rounded(x - width / 2 - growth, 330 - height, width + 2 * growth, height, Math.min(6, height / 2),
        gradient(x - width, 248, x + width, 248, ['#9c5836', '#efad79', '#a65e3b']), '#ffbc8480');
      for (let i = 0; i < 11; i++) {
        ellipse(x + ((i * 13) % 29 - 14) * (.8 + progress * .55), 330 - height * (.10 + i * .075),
          Math.min(1.5 + progress, height / 8), Math.min(1.3 + progress, height / 8), i % 2 ? '#f7c194' : '#945134');
      }
    }
    rounded(labelX - 16, 157, 32, 28, 7, '#182231', left ? PURPLE : BLUE);
    label(model[side + 'Sign'], labelX, 171, 22, left ? PURPLE : BLUE);
    label(model[side], x, 145, 22, '#e6ebf2', 650);
  }

  function saltBridge(s, active, moving) {
    if (!s.bridge) {
      rounded(239, 133, 162, 44, 10, '#171e29', '#826c42');
      label('插回盐桥', 320, 155, 21, GOLD);
      return;
    }
    const tube = [[226, 267], [226, 177], [245, 158], [395, 158], [414, 177], [414, 267]];
    stroke(tube, '#5a8d93', 22);
    stroke(tube, '#23454b', 18);
    stroke(tube, '#7fbab766', 6);
    for (const x of [226, 414]) stroke([[x - 7, 265], [x + 7, 265]], '#bacdd0', 5);
    label('KNO₃ 盐桥', 320, 130, 20, GOLD);
    if (!active || !s.ions) return;
    label('NO₃⁻', 265, 193, 21, PURPLE);
    label('K⁺', 375, 193, 21, GREEN);
    arrow([[288, 158], [247, 158]], PURPLE);
    arrow([[352, 158], [393, 158]], GREEN);
    if (moving) {
      particles(nitratePath, s.phase / 3.6, 2, PURPLE);
      particles(potassiumPath, s.phase / 3.6, 2, GREEN);
    }
  }

  function solutionIons(s, moving) {
    label('Cl⁻', 253, 260, 22, PURPLE, 650);
    label('Cu²⁺', 389, 260, 22, BLUE, 650);
    arrow([[270, 283], [179, 283]], PURPLE);
    arrow([[369, 283], [459, 283]], BLUE);
    if (moving) {
      particles(chloridePath, s.phase / 2.6, 2, PURPLE);
      particles(copperPath, s.phase / 2.6, 2, BLUE);
    }
  }

  function chlorine(phase) {
    for (let i = 0; i < 7; i++) {
      const u = (phase * .46 + i / 7) % 1;
      const radius = 3 + u * 3;
      ellipse(120 - u * 13 + Math.sin(i * 4 + u * 6) * 5, 328 - u * 88,
        radius, radius, '#91d99024', '#a6e49e');
    }
    label('Cl₂ ↑', 77, 275, 20, GREEN);
  }

  function draw(canvas, s, reducedMotion) {
    const width = canvas.clientWidth, height = canvas.clientHeight;
    if (!width || !height) return;
    const dpr = Math.min(devicePixelRatio || 1, 2);
    const pixelWidth = Math.round(width * dpr), pixelHeight = Math.round(height * dpr);
    if (canvas.width !== pixelWidth || canvas.height !== pixelHeight) {
      canvas.width = pixelWidth;
      canvas.height = pixelHeight;
    }
    ctx = canvas.getContext('2d');
    ctx.setTransform(pixelWidth / 640, 0, 0, pixelHeight / 410, 0, 0);
    ctx.clearRect(0, 0, 640, 410);
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    const galvanic = s.scene === 'galvanic', model = Cell.scenes[s.scene];
    const v = Cell.sample(s.scene, s.q), active = Cell.active(s);
    const moving = !reducedMotion;
    const blue = [`rgba(51,162,214,${.30 - v.progress * .10})`,
      `rgba(40,142,201,${.50 - v.progress * .20})`, `rgba(19,82,130,${.65 - v.progress * .25})`];

    circuit(s, galvanic, active, moving);
    if (galvanic) {
      glass(37, 219, ['#718e9a45', '#7396ac42', '#3a617743']);
      glass(384, 219, blue);
      saltBridge(s, active, moving);
    } else {
      glass(37, 566, blue);
    }
    electrode(138, 'left', galvanic, model, v.progress);
    electrode(502, 'right', galvanic, model, v.progress);
    if (galvanic) {
      glassFront(37, 219);
      glassFront(384, 219);
      label('ZnSO₄ 溶液', 146, 386, 23, '#c4d0db');
      label('CuSO₄ 溶液', 494, 386, 23, BLUE);
    } else {
      if (active && s.ions) solutionIons(s, moving);
      if (v.q > 0 && s.closed && s.q < Cell.MAX_Q) chlorine(moving ? s.phase : 0);
      glassFront(37, 566);
      label('CuCl₂ 溶液', 320, 386, 23, BLUE);
    }
  }

  window.CellDraw = {draw};
}());
