/* 实验装置、接触纹理与受力图；采用跟随木块的观察窗口。 */
(function () {
  'use strict';
  const GOLD = '#ffc94a', BLUE = '#6bd4ff', TEXT = '#e6edf7';
  let ctx, hits = [], transform, compact = false;
  function text(str, x, y, size = 16, color = TEXT, align = 'left') {
    ctx.font = `${size}px -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif`;
    ctx.textAlign = align; ctx.textBaseline = 'middle'; ctx.fillStyle = color; ctx.fillText(str, x, y);
  }
  function line(x, y, xx, yy, color, width = 2) {
    ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(xx, yy); ctx.strokeStyle = color; ctx.lineWidth = width; ctx.stroke();
  }
  function box(x, y, w, h, fill, stroke, radius = 6) {
    ctx.beginPath(); ctx.roundRect(x, y, w, h, radius); ctx.fillStyle = fill; ctx.fill();
    if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = 1.5; ctx.stroke(); }
  }
  function arrow(x, y, length, color, label) {
    if (Math.abs(length) < 1) return;
    line(x, y, x + length, y, color, 3);
    const sign = Math.sign(length);
    ctx.beginPath(); ctx.moveTo(x + length, y); ctx.lineTo(x + length - sign * 9, y - 5); ctx.lineTo(x + length - sign * 9, y + 5); ctx.closePath(); ctx.fillStyle = color; ctx.fill();
    if (label) text(label, x + length / 2, y - 15, 12, color, 'center');
  }
  function surface(x, y, w, key, offset) {
    const material = Friction.surfaces[key];
    const gradient = ctx.createLinearGradient(0, y, 0, y + 32);
    gradient.addColorStop(0, material.color); gradient.addColorStop(1, '#273744');
    box(x, y, w, 32, gradient, '#6a7883', 3);
    ctx.save(); ctx.beginPath(); ctx.rect(x, y, w, 32); ctx.clip();
    if (key === 'wood') {
      for (let i = 0; i < 5; i++) {
        ctx.beginPath();
        for (let j = 0; j < w; j += 5) {
          const yy = y + 5 + i * 6 + Math.sin((j + offset * 50 + i * 43) / 37) * 1.8;
          if (!j) ctx.moveTo(x + j, yy); else ctx.lineTo(x + j, yy);
        }
        ctx.strokeStyle = '#3d2a2288'; ctx.lineWidth = 1; ctx.stroke();
      }
    } else if (key === 'cloth') {
      for (let j = -40; j < w + 40; j += 9) {
        const xx = x + j - (offset * 50 % 9);
        line(xx, y, xx + 22, y + 32, '#aac2c155');
        line(xx, y + 32, xx + 22, y, '#22384288');
      }
    } else {
      for (let j = 0; j < 230; j++) {
        const xx = x + ((j * 37.19 - offset * 50) % w + w) % w;
        const yy = y + 3 + (j * 17.71 % 26);
        ctx.fillStyle = j % 2 ? '#ead0a499' : '#4a3c3299'; ctx.fillRect(xx, yy, 2, 2);
      }
    }
    ctx.restore();
    line(x, y, x + w, y, '#d1c5a0', 2);
  }
  // 与桌面固连的实验室背景，和接触纹理使用同一位移，不制造视差速度。
  function laboratory(x, ground, width, offset) {
    ctx.save();
    ctx.beginPath(); ctx.rect(x, ground - 108, width, 140); ctx.clip();
    // 参照物退到背景层，避免高反差窗框抢过器材与读数。
    ctx.globalAlpha = 0.12;
    const spacing = 230, shift = ((offset * 50) % spacing + spacing) % spacing;
    for (let n = -1; n <= Math.ceil(width / spacing); n++) {
      const left = x + n * spacing - shift;
      // 窗台、四格窗框与墙柱提供容易辨认的固定参照。
      box(left + 20, ground - 98, 96, 75, '#21374a', '#607b8c', 3);
      ctx.fillStyle = '#87b4c333'; ctx.fillRect(left + 25, ground - 93, 86, 30);
      line(left + 68, ground - 96, left + 68, ground - 25, '#607b8c', 1.5);
      line(left + 22, ground - 61, left + 114, ground - 61, '#607b8c', 1.5);
      line(left + 15, ground - 21, left + 121, ground - 21, '#607b8c', 2);
      line(left + 190, ground - 108, left + 190, ground, '#486273', 1);
    }
    ctx.restore();
  }
  function block(c, x, ground) {
    const w = c.edge ? (compact ? 42 : 58) : (compact ? 84 : 116), h = c.edge ? 94 : 47;
    const g = ctx.createLinearGradient(x, ground - h, x, ground);
    g.addColorStop(0, '#dca86a'); g.addColorStop(1, '#8e582e');
    box(x, ground - h, w, h, g, '#edc88d', 3);
    for (let i = 0; i < 4; i++) {
      ctx.beginPath(); ctx.moveTo(x + 5, ground - h + 10 + i * 11);
      ctx.bezierCurveTo(x + w * 0.3, ground - h + 5 + i * 11, x + w * 0.6, ground - h + 17 + i * 11, x + w - 5, ground - h + 8 + i * 11);
      ctx.strokeStyle = '#6c432b66'; ctx.lineWidth = 1; ctx.stroke();
    }
    text('0.5 kg', x + w / 2, ground - h / 2, 12, '#352c20', 'center');
    line(x, ground, x + w, ground, BLUE, 4);
    for (let n = 0; n < c.load; n++) {
      const yy = ground - h - 13 * (n + 1);
      const metal = ctx.createLinearGradient(0, yy, 0, yy + 11);
      metal.addColorStop(0, '#bfcbd5'); metal.addColorStop(0.4, '#637382'); metal.addColorStop(1, '#a5b6c4');
      box(x + w / 2 - 24, yy, 48, 12, metal, '#d8e3ec', 3);
      text('0.5', x + w / 2, yy + 6, 9, '#142333', 'center');
    }
    // 即使没有砝码，也可点选木块上方的砝码位置。
    hits.push({ type: 'load', x: x - 5, y: ground - h - 56, w: w + 10, h: 53 });
    hits.push({ type: 'edge', x: x - 5, y: ground - h - 3, w: w + 10, h: h + 6 });
    return { x: x + w, y: ground - h / 2 };
  }
  function scale(x, y, force, manual) {
    const extension = force * (compact ? 1.4 : 3);
    line(x, y, x + 30 + extension, y, '#d2dce7', 2);
    const start = x + 28 + extension;
    box(start, y - 21, 150, 42, '#1d3348', GOLD, 12);
    // 可辨认的弹簧、刻度与游标。
    ctx.beginPath(); ctx.moveTo(start + 8, y - 6);
    for (let i = 0; i < 18; i++) ctx.lineTo(start + 8 + i * 3.5, y - 6 + (i % 2 ? 5 : -5));
    ctx.strokeStyle = '#b5c8d8'; ctx.lineWidth = 1.4; ctx.stroke();
    for (let n = 0; n <= 16; n++) line(start + 13 + n * 7.5, y + 6, start + 13 + n * 7.5, y + (n % 4 ? 10 : 14), '#96a9bd', 1);
    line(start + 13 + force * 7.5, y + 2, start + 13 + force * 7.5, y + 16, GOLD, 3);
    ctx.beginPath(); ctx.ellipse(start + 166, y, 17, 12, 0, 0, Math.PI * 2); ctx.strokeStyle = GOLD; ctx.lineWidth = 3; ctx.stroke();
    text(force.toFixed(2) + ' N', start + 75, y - 36, 18, GOLD, 'center');
    if (manual) hits.push({ type: 'force', x: start - 7, y: y - 28, w: 201, h: 56 });
  }
  function render(canvas, s) {
    ctx = canvas.getContext('2d');
    const w = canvas.clientWidth, h = canvas.clientHeight, dpr = window.devicePixelRatio || 1;
    if (canvas.width !== Math.round(w * dpr) || canvas.height !== Math.round(h * dpr)) {
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
    }
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.fillStyle = '#05070d'; ctx.fillRect(0, 0, w, h);
    compact = w < 600;
    const virtualW = compact ? 430 : 820;
    const rows = Friction.rows(s), tall = rows.some(c => c.edge);
    // 侧放宽度减半、高度加倍；为最上方砝码保留标题间距。
    const groundY = Math.max(compact ? 132 : 145, tall ? 94 + Math.max(...rows.map(c => c.load)) * 13 + 34 : 0);
    const rowH = groundY + (compact ? 57 : 62);
    const manual = s.scene === 'manual';
    const virtualH = rows.length * rowH + (manual ? 132 : 0);
    const availableH = Math.max(160, h - 318);
    const k = Math.min((w - (compact ? 20 : 40)) / virtualW, availableH / virtualH, compact ? 1.12 : 1.18);
    const ox = (w - virtualW * k) / 2, oy = 172 + (availableH - virtualH * k) / 2;
    ctx.translate(ox, oy); ctx.scale(k, k); hits = []; transform = { k, ox, oy };
    const largest = Math.max(1, ...rows.map(c => Math.max(c.kinetic, manual ? s.force : c.kinetic)));
    const forceScale = compact ? Math.min(14, 58 / largest) : Math.min(20, 120 / largest);
    rows.forEach((c, i) => {
      const top = i * rowH, ground = top + groundY;
      const f = manual ? Friction.forces(c, s.force, s.v) : { force: c.kinetic, friction: c.kinetic };
      box(0, top, virtualW, rowH - 9, '#0b111c', '#202f40', 10);
      text('0' + (i + 1), 16, top + 21, 11, '#536c85');
      const label = s.scene === 'pressure' ? c.load + ' 个砝码' : s.scene === 'area' ? (c.edge ? '侧放 · 面积减半' : '平放 · 面积较大') : Friction.surfaces[c.surface].name;
      text(label, 44, top + 21, 13, '#c1cede');
      text('压力 ' + c.normal + ' N', virtualW - 16, top + 21, 12, '#8d9fb5', 'right');
      const x = compact ? 70 : 215, offset = manual ? s.x : s.phase;
      laboratory(14, ground, virtualW - 28, offset);
      surface(14, ground, virtualW - 28, c.surface, offset);
      const markerShift = ((offset * 50) % 230 + 230) % 230;
      ctx.save(); ctx.beginPath(); ctx.rect(14, ground, virtualW - 28, 32); ctx.clip();
      for (let n = -1; n <= Math.ceil(virtualW / 230); n++) {
        ctx.globalAlpha = 0.45;
        box(14 + n * 230 - markerShift + 151, ground + 8, 4, 14, '#c2b39a', null, 1);
      }
      ctx.restore();
      const hitStart = hits.length;
      const hook = block(c, x, ground);
      scale(hook.x, hook.y, f.force, true);
      hits.slice(hitStart).forEach(hit => { hit.row = i; });
      arrow(hook.x + 42, top + 51, f.force * forceScale, GOLD, 'F');
      // 力按同一比例画在接触装置两侧，数值标在独立受力层。
      const forceY = ground - 21, origin = compact ? 66 : 178;
      arrow(origin, forceY, -f.friction * forceScale, BLUE, '');
      text('f ' + f.friction.toFixed(2) + ' N', 17, ground + 43, 12, BLUE);
      text(manual ? (s.v > 0.001 ? '向右滑动 →' : '静止') : '匀速向右 →', virtualW - 16, ground + 43, 11, '#9bbdaf', 'right');
    });
    if (s.hover) {
      const hit = hits.find(hit => hit.row === s.hover.row && hit.type === s.hover.type);
      if (hit) { ctx.beginPath(); ctx.roundRect(hit.x, hit.y, hit.w, hit.h, 6); ctx.strokeStyle = '#b8daed99'; ctx.lineWidth = 1.5; ctx.stroke(); }
    }
    if (manual) {
      const c = Friction.conditions(s.load, s.surface, s.edge), y = rowH + 12;
      const f = Friction.forces(c, s.force, s.v), barX = 77, barW = virtualW - 106;
      text('水平受力对照', 16, y, 13, '#c1cede');
      [s.force, f.friction].forEach((value, i) => {
        const yy = y + 28 + i * 28, color = i ? BLUE : GOLD;
        text(i ? '摩擦力' : '拉力', 16, yy + 5, 12, color);
        box(barX, yy, barW, 9, '#172232', null, 3);
        if (value > 0) box(barX, yy, barW * value / 16, 9, color, null, 3);
      });
      const thresholdX = barX + barW * c.maximum / 16;
      line(thresholdX, y + 22, thresholdX, y + 75, '#8e9eb4', 1);
      text('起动需超过 ' + c.maximum.toFixed(2) + ' N · 滑动摩擦 ' + c.kinetic.toFixed(2) + ' N', 16, y + 99, 12, '#8d9fb5');
    }
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    return transform;
  }
  function hit(x, y) {
    if (!transform) return null;
    x = (x - transform.ox) / transform.k; y = (y - transform.oy) / transform.k;
    return hits.find(r => x >= r.x && x <= r.x + r.w && y >= r.y && y <= r.y + r.h);
  }
  window.FrictionDraw = { render, hit };
})();
