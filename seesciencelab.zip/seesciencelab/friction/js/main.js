(function () {
  'use strict';
  const $ = id => document.getElementById(id), q = new URLSearchParams(location.search);
  function number(key, fallback, lo, hi) {
    const n = Number(q.get(key));
    return q.has(key) && Number.isFinite(n) ? Friction.clamp(n, lo, hi) : fallback;
  }
  const scenes = ['pressure', 'surface', 'area', 'manual'];
  const state = {
    scene: scenes.includes(q.get('scene')) ? q.get('scene') : 'pressure',
    load: Math.round(number('load', 1, 0, 3)),
    surface: Friction.surfaces[q.get('surface')] ? q.get('surface') : 'wood',
    edge: q.get('edge') === '1', force: number('force', 1, 0, 16),
    v: number('v', 0, 0, 1000000), x: 0, t: 0, phase: 0, play: q.has('play') ? q.get('play') !== '0' : !matchMedia('(prefers-reduced-motion: reduce)').matches
  };
  const records = [], canvas = $('canvas');
  function track(action, label) { if (window.Analytics) Analytics.track('摩擦力影响因素', action, String(label)); }
  function reset() { state.hover = null; state.v = 0; state.x = 0; state.t = 0; state.phase = 0; }
  function sync() {
    const pressure = state.scene === 'pressure';
    $('load').min = pressure ? 1 : 0; $('load').max = pressure ? 2 : 3;
    $('load').value = pressure ? (state.load >= 2 ? 2 : 1) : state.load;
    $('loadLabel').textContent = pressure ? '砝码组' : '砝码数';
    $('surface').value = state.surface;
    $('edge').checked = state.edge; $('force').value = state.force;
    $('loadOut').textContent = pressure ? (state.load >= 2 ? '1 / 2 / 3' : '0 / 1 / 2') : state.load + ' 个'; $('forceOut').textContent = state.force.toFixed(2) + ' N';
    $('play').textContent = state.play ? '暂停实验' : '继续实验';
    $('play').setAttribute('aria-pressed', String(state.play));
    $('forceSection').hidden = state.scene !== 'manual';
    const copy = {pressure:['加上砝码，摩擦力会怎样？','只改变压力，保持接触面与木块摆放相同。','压力越大，滑动摩擦力越大。'],surface:['换个表面，拉起来一样费力吗？','只改变接触面，保持压力与木块摆放相同。','同样的压力，本组表面越粗糙，摩擦力越大。'],area:['同一木块，翻面后示数会变吗？','只改变接触面积，保持压力与接触面性质相同。','接触面积改变，两组匀速示数相同。'],manual:['有拉力，木块就一定会动吗？','拖动金色测力计，观察从静止到滑动的变化。','静止时，静摩擦力随拉力变化。']}[state.scene];
    $('sceneTitle').textContent = copy[0]; $('sceneDesc').textContent = copy[1];
    $('conclusion').textContent = copy[2];
    $('hint').textContent = state.scene === 'manual' ? '向右拖测力计加力 · 向左拖减力' : state.scene === 'pressure' ? '点砝码切换对照组 · 点木块翻面 · 拖测力计进入手动实验' : '点砝码加重 · 点木块翻面 · 拖测力计进入手动实验';
    document.querySelectorAll('[data-scene]').forEach(b => { b.classList.toggle('on', b.dataset.scene === state.scene); b.setAttribute('aria-pressed', String(b.dataset.scene === state.scene)); });
  }
  function setScene(scene) { if (!scenes.includes(scene)) return; state.scene = scene; reset(); sync(); track('切换实验', scene); }
  function readouts() {
    const c = Friction.conditions(state.load, state.surface, state.edge);
    const f = state.scene === 'manual' ? Friction.forces(c, state.force, state.v) : { force: c.kinetic, friction: c.kinetic };
    $('status').textContent = state.scene === 'manual' ? (state.v > 0.001 ? '滑动中' : (state.force > c.maximum ? '即将起动' : '静止')) : '匀速对照实验';
    $('pullRead').textContent = state.scene === 'manual' ? f.force.toFixed(2) + ' N' : Friction.rows(state).map(r => r.kinetic.toFixed(2)).join(' / ') + ' N';
    $('frictionRead').textContent = state.scene === 'manual' ? f.friction.toFixed(2) + ' N' : Friction.rows(state).map(r => r.kinetic.toFixed(2)).join(' / ') + ' N';
    $('normalRead').textContent = state.scene === 'pressure' ? Friction.rows(state).map(r => r.normal).join(' / ') + ' N' : c.normal.toFixed(0) + ' N';
    $('speedRead').textContent = (state.scene === 'manual' ? state.v.toFixed(2) : '0.12') + ' m/s';
    $('explain').textContent = state.scene === 'manual' ? (state.v < 0.001 && state.force <= c.maximum ? '静摩擦力平衡拉力。起动需超过 ' + c.maximum.toFixed(2) + ' N。' : '滑动摩擦力为 ' + c.kinetic.toFixed(2) + ' N；拉力与它不相等时，速度发生变化。') : '这里只展示稳定匀速阶段，各组拉力等于滑动摩擦力。改变条件只比较一个因素。';
    if (state.scene === 'manual') $('conclusion').textContent = state.v > 0.001 ? (f.force > f.friction ? '拉力大于摩擦力，木块向右加速。' : f.force < f.friction ? '拉力小于摩擦力，木块减速。' : '拉力与摩擦力平衡，木块匀速滑动。') : state.force > c.maximum ? '拉力超过静摩擦上限，木块即将起动。' : '拉力与静摩擦力平衡，木块保持静止。';
  }
  document.querySelectorAll('[data-scene]').forEach(b => b.onclick = () => setScene(b.dataset.scene));
  ['load', 'surface', 'edge'].forEach(id => $(id).oninput = () => {
    state[id] = id === 'load' ? Number($(id).value) : id === 'edge' ? $(id).checked : $(id).value;
    reset(); sync(); track('改变条件', id + ':' + state[id]);
  });
  function setForce(force) {
    if (state.scene !== 'manual') setScene('manual');
    state.force = Friction.clamp(force, 0, 16); sync();
  }
  $('force').oninput = () => setForce(Number($('force').value));
  $('force').onchange = () => track('调整拉力', state.force.toFixed(2));
  $('play').onclick = () => { state.play = !state.play; sync(); track('播放', state.play); };
  $('reset').onclick = () => { reset(); sync(); track('重做', state.scene); };
  $('record').onclick = () => {
    if (state.scene === 'manual') { $('message').textContent = '请在匀速对照模式记录；手动拉动时示数未必等于摩擦力。'; return; }
    Friction.rows(state).forEach(c => records.push(c));
    while (records.length > 18) records.shift();
    $('records').innerHTML = '<table><tr><th>表面</th><th>压力 N</th><th>摆放</th><th>示数 N</th></tr>' + records.map(c => `<tr><td>${Friction.surfaces[c.surface].name}</td><td>${c.normal}</td><td>${c.edge ? '侧' : '平'}</td><td>${c.kinetic.toFixed(2)}</td></tr>`).join('') + '</table>';
    document.querySelector('.record-details').open = true;
    $('message').textContent = '已记录当前对照组。'; track('记录', state.scene);
  };
  function link() {
    const p = new URLSearchParams({ scene: state.scene, load: state.load, surface: state.surface, edge: state.edge ? 1 : 0, force: state.force.toFixed(2), v: state.v.toFixed(6), play: '0' });
    return location.origin + location.pathname + '?' + p;
  }
  $('share').onclick = async () => {
    try { await navigator.clipboard.writeText(link()); $('message').textContent = '状态链接已复制（暂停打开）。'; }
    catch (_) { $('message').textContent = link(); }
    track('分享', state.scene);
  };
  $('panelToggle').onclick = () => {
    const closed = $('panel').classList.toggle('collapsed');
    $('panelToggle').textContent = closed ? '条件设置' : '收起设置';
    $('panelToggle').setAttribute('aria-expanded', String(!closed));
    $('panelToggle').setAttribute('aria-label', closed ? '显示控制面板' : '收起控制面板');
    document.querySelector('.stage-tools').classList.toggle('drawer-open', !closed);
  };
  if (matchMedia('(max-width:760px)').matches) $('panel').classList.add('collapsed');
  let drag = null;
  function point(e) { const r = canvas.getBoundingClientRect(); return { x: e.clientX - r.left, y: e.clientY - r.top }; }
  canvas.onpointerdown = e => {
    const p = point(e), h = FrictionDraw.hit(p.x, p.y);
    if (!h) return;
    if (h.type === 'force') { if (state.scene !== 'manual') { const initial = Friction.rows(state)[h.row]; state.load = initial.load; state.surface = initial.surface; state.edge = initial.edge; setScene('manual'); state.force = initial.kinetic; sync(); } drag = { x: p.x, force: state.force }; canvas.setPointerCapture(e.pointerId); canvas.style.cursor = 'grabbing'; }
    else if (h.type === 'edge') { state.edge = !state.edge; reset(); sync(); track('点木块翻面', state.edge); }
    else if (h.type === 'load') { const c = Friction.rows(state)[h.row]; state.load = state.scene === 'pressure' ? (state.load >= 2 ? 1 : 2) : (c.load + 1) % 4; reset(); sync(); track('点砝码', state.load); }
  };
  canvas.onpointermove = e => {
    const p = point(e);
    if (drag) setForce(drag.force + (p.x - drag.x) * 16 / Math.min(250, canvas.clientWidth * 0.6));
    else { state.hover = FrictionDraw.hit(p.x, p.y); canvas.style.cursor = state.hover ? 'grab' : 'default'; }
  };
  canvas.onpointerleave = () => { state.hover = null; };
  canvas.onpointerup = () => { if (drag) track('拖测力计', state.force.toFixed(2)); drag = null; canvas.style.cursor = 'default'; };
  canvas.onpointercancel = () => { drag = null; canvas.style.cursor = 'default'; };
  canvas.onlostpointercapture = () => { drag = null; canvas.style.cursor = 'default'; };
  document.addEventListener('keydown', e => {
    if (e.code === 'Space' && !/INPUT|SELECT|BUTTON/.test(document.activeElement.tagName)) { e.preventDefault(); $('play').click(); }
  });
  let before = null;
  function frame(now) {
    const dt = before === null ? 0 : Math.min((now - before) / 1000, 0.05); before = now;
    if (state.play) {
      if (state.scene === 'manual') {
        for (let i = 0; i < 10; i++) Friction.step(state, dt / 10);
      } else { state.phase += dt * 0.8; }
    }
    FrictionDraw.render(canvas, state); readouts(); requestAnimationFrame(frame);
  }
  window.__model = { state, setScene, setForce, reset, update: sync, link };
  sync(); requestAnimationFrame(frame);
})();
