/* 水平干摩擦计算；坐标向右为正，SI 单位。 */
(function () {
  'use strict';
  const surfaces = {
    wood: { name: '木板', mu: 0.2, color: '#a57951' },
    cloth: { name: '棉布', mu: 0.35, color: '#688a95' },
    sand: { name: '砂纸', mu: 0.5, color: '#b49b74' }
  };
  const clamp = (x, a, b) => Math.max(a, Math.min(b, x));
  function conditions(load, surface, edge) {
    const mass = 0.5 * (1 + load), normal = mass * 10;
    const mu = surfaces[surface].mu;
    return { load, surface, edge, mass, normal, kinetic: mu * normal, maximum: mu * normal * 1.25 };
  }
  function forces(c, force, velocity) {
    const moving = velocity > 1e-8 || force > c.maximum + 1e-8;
    const friction = moving ? c.kinetic : force;
    return { force, friction, acceleration: (force - friction) / c.mass, moving };
  }
  function step(s, dt) {
    const c = conditions(s.load, s.surface, s.edge);
    const f = forces(c, s.force, s.v);
    const v = Math.max(0, s.v + f.acceleration * dt);
    s.x += (s.v + v) * 0.5 * dt;
    s.v = v;
    s.t += dt;
    return forces(c, s.force, s.v);
  }
  function rows(s) {
    if (s.scene === 'manual') return [conditions(s.load, s.surface, s.edge)];
    if (s.scene === 'pressure') return (s.load >= 2 ? [1, 2, 3] : [0, 1, 2]).map(n => conditions(n, s.surface, s.edge));
    if (s.scene === 'surface') return Object.keys(surfaces).map(k => conditions(s.load, k, s.edge));
    return [s.edge, !s.edge].map(e => conditions(s.load, s.surface, e));
  }
  window.Friction = { surfaces, clamp, conditions, forces, step, rows };
})();
