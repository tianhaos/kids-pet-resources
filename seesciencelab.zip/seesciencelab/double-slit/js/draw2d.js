// 2D 绘制：双缝干涉俯视示意图（波面 / 光强、加强线与减弱线、光程差）、屏上条纹（实际尺寸）与光强曲线、
// 测量光的波长的装置图 + 目镜视野 + 手轮读数、练习题画面
// 示意图中波长、缝距、缝宽按同一比例放大（λ 每 600 nm 约 7 px，缝距每 0.1 mm 约 30 px），L 按屏的位置缩放，只保持 Δx ∝ Lλ/d 的关系；
// 屏上条纹按实际尺寸画（mm）。示意图里的波场预先算出复振幅 C = Σ e^{ikr}/√r，每帧只算 Re(C·e^{−iωt})
(function () {
  var S = window.Slit, f = S.f;
  var MUTED = '#8d99ab', TEXT = '#e6ebf2', LINE = '#2a3446', BAR = '#5b6a85', DR = '#ff7a59', GOLD = '#ffc94a';
  var FONT = '-apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", sans-serif';

  function font(px, w) { return (w ? w + ' ' : '') + px + 'px ' + FONT; }
  function label(ctx, s, x, y, o) {
    o = o || {};
    ctx.font = font(o.size || 12, o.bold ? 600 : null);
    ctx.textAlign = o.align || 'center'; ctx.textBaseline = o.base || 'middle';
    ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(5,7,13,.85)'; ctx.strokeText(s, x, y);
    ctx.fillStyle = o.color || TEXT; ctx.fillText(s, x, y);
  }
  function line(ctx, x1, y1, x2, y2, color, o) {
    o = o || {};
    ctx.strokeStyle = color; ctx.lineWidth = o.width || 1.2; ctx.setLineDash(o.dash || []);
    ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke(); ctx.setLineDash([]);
  }
  function head(ctx, x, y, a, size, color) {
    ctx.fillStyle = color; ctx.beginPath(); ctx.moveTo(x, y);
    ctx.lineTo(x - size * Math.cos(a - 0.45), y - size * Math.sin(a - 0.45));
    ctx.lineTo(x - size * Math.cos(a + 0.45), y - size * Math.sin(a + 0.45)); ctx.closePath(); ctx.fill();
  }
  // 尺寸标注：两端带箭头的线段，文字在中间
  function dim(ctx, x1, y1, x2, y2, text, color, o) {
    o = o || {};
    color = color || MUTED;
    var a = Math.atan2(y2 - y1, x2 - x1), len = Math.hypot(x2 - x1, y2 - y1);
    line(ctx, x1, y1, x2, y2, color);
    if (len > 12) { head(ctx, x2, y2, a, 7, color); head(ctx, x1, y1, a + Math.PI, 7, color); }
    if (text) label(ctx, text, (x1 + x2) / 2 + (o.dx || 0), (y1 + y2) / 2 + (o.dy == null ? -10 : o.dy), { color: o.tc || color, size: o.size || 12, align: o.align, bold: o.bold });
  }
  function rgbStr(c, k) {
    k = k == null ? 1 : k;
    return 'rgb(' + Math.min(255, c[0] * k * 255 | 0) + ',' + Math.min(255, c[1] * k * 255 | 0) + ',' + Math.min(255, c[2] * k * 255 | 0) + ')';
  }

  // ---------- 屏上条纹（实际尺寸）----------
  // 一行像素的颜色，按参数缓存。X 为半宽（mm），n 为像素数
  var stripCache = {};
  function stripRow(o, X, n) {
    var key = [o.white, o.lam, o.d, o.a, o.L, o.mode, o.water, o.filters, X, n, o.tilt || 0].join('|');
    if (stripCache[key]) return stripCache[key];
    var data = new Uint8ClampedArray(n * 4), I = new Float32Array(n);
    for (var i = 0; i < n; i++) {
      var x = (i + 0.5) / n * 2 * X - X, c;
      if (o.filters) {   // 两缝分别加红、绿滤光片：不相干，两束衍射光的光强直接相加
        var r = S.intensity(x, { lam: 650, L: o.L, mode: 'one' }), g = S.intensity(x, { lam: 530, L: o.L, mode: 'one' });
        var cr = S.lamRGB(650), cg = S.lamRGB(530);
        c = [(cr[0] * r + cg[0] * g) * 0.5, (cr[1] * r + cg[1] * g) * 0.5, (cr[2] * r + cg[2] * g) * 0.5];
      } else c = S.screenRGB(x, { white: o.white, lam: o.lam, water: o.water, d: o.d, a: o.a, L: o.L, mode: o.mode });
      I[i] = o.white || o.filters ? (c[0] + c[1] + c[2]) / 3 : S.intensity(x, { lam: S.lamIn(o.lam, o.water), d: o.d, a: o.a, L: o.L, mode: o.mode });
      for (var j = 0; j < 3; j++) data[i * 4 + j] = Math.pow(Math.min(1, c[j]), 0.6) * 255;
      data[i * 4 + 3] = 255;
    }
    var keys = Object.keys(stripCache);
    if (keys.length > 24) delete stripCache[keys[0]];
    return (stripCache[key] = { data: data, I: I });
  }
  var tmpCv = document.createElement('canvas'), tmpCtx = tmpCv.getContext('2d');
  // 把一行像素拉伸画到矩形里
  function drawRow(ctx, row, n, x, y, w, h) {
    tmpCv.width = n; tmpCv.height = 1;
    tmpCtx.putImageData(new ImageData(row.data, n, 1), 0, 0);
    ctx.save(); ctx.imageSmoothingEnabled = true; ctx.drawImage(tmpCv, x, y, w, h); ctx.restore();
  }
  // 条纹带 + 尺子 + 可选光强曲线。B：矩形；X：半宽 mm。返回 mm → 屏幕 x 的换算
  function fringeStrip(ctx, dpr, B, o, X, opt) {
    opt = opt || {};
    var n = Math.max(64, Math.round(B.w * dpr)), row = stripRow(o, X, n);
    var cH = opt.curve ? Math.min(60, B.h * 0.32) : 0, rulerH = opt.ruler === false ? 0 : 22;
    var sy = B.y + cH + (cH ? 6 : 0), sh = B.h - cH - (cH ? 6 : 0) - rulerH;
    var px = function (mm) { return B.x + (mm + X) / (2 * X) * B.w; };
    ctx.fillStyle = '#000'; ctx.fillRect(B.x, sy, B.w, sh);
    drawRow(ctx, row, n, B.x, sy, B.w, sh);
    ctx.strokeStyle = LINE; ctx.lineWidth = 1; ctx.strokeRect(B.x + 0.5, sy + 0.5, B.w - 1, sh - 1);
    if (cH) {
      var base = B.y + cH, col = o.white || o.filters ? '#e6ebf2' : S.lamCSS(o.lam);
      line(ctx, B.x, base, B.x + B.w, base, LINE);
      ctx.strokeStyle = col; ctx.lineWidth = 1.6; ctx.beginPath();
      for (var i = 0; i < n; i += Math.max(1, Math.floor(n / 600))) {
        var xx = B.x + (i + 0.5) / n * B.w, yy = base - row.I[i] * (cH - 6);
        if (i) ctx.lineTo(xx, yy); else ctx.moveTo(xx, yy);
      }
      ctx.stroke();
      label(ctx, '光强', B.x + 2, B.y + 6, { size: 11, color: MUTED, align: 'left' });
    }
    if (rulerH) {
      var ry = sy + sh, step = B.w / (2 * X) < 9 ? 2 : 1;
      ctx.strokeStyle = MUTED; ctx.lineWidth = 1; ctx.beginPath();
      for (var m = -Math.floor(X / step) * step; m <= X + 1e-9; m += step) {
        var big = m % 5 === 0, x = px(m);
        ctx.moveTo(x, ry); ctx.lineTo(x, ry + (big ? 8 : 4));
      }
      ctx.stroke();
      for (var mm = -Math.floor(X / 5) * 5; mm <= X + 1e-9; mm += 5) label(ctx, String(mm), px(mm), ry + 15, { size: 10, color: MUTED });
    }
    return { px: px, sy: sy, sh: sh, base: B.y + cH, cH: cH };
  }

  // ---------- 示意图的波场 ----------
  // spec：{ w, h, cell, xS, xD, xP, yc, beam, srcs: [{y, w}], lams: [λpx…] }，坐标相对波场左上角
  function buildField(spec) {
    var cols = Math.ceil(spec.w / spec.cell), rows = Math.ceil(spec.h / spec.cell), nl = spec.lams.length;
    var re = [], im = [], i, j, l, s;
    for (l = 0; l < nl; l++) { re.push(new Float32Array(cols * rows)); im.push(new Float32Array(cols * rows)); }
    var reg = new Uint8Array(cols * rows);
    var r1ref = Math.max(20, (spec.xD - spec.xS) / 2), r2ref = Math.max(30, (spec.xP - spec.xD) / 2), wsum = 0;
    for (s = 0; s < spec.srcs.length; s++) wsum += spec.srcs[s].w;
    for (j = 0; j < rows; j++) {
      var y = (j + 0.5) * spec.cell;
      for (i = 0; i < cols; i++) {
        var x = (i + 0.5) * spec.cell, idx = j * cols + i;
        if (x < spec.xS) {
          if (Math.abs(y - spec.yc) > spec.beam) continue;
          reg[idx] = 1;
          for (l = 0; l < nl; l++) { var ph0 = 2 * Math.PI * x / spec.lams[l]; re[l][idx] = 0.75 * Math.cos(ph0); im[l][idx] = 0.75 * Math.sin(ph0); }
        } else if (x < spec.xD) {
          reg[idx] = 2;
          var r = Math.hypot(x - spec.xS, y - spec.yc);
          for (l = 0; l < nl; l++) {
            var A = 0.75 * Math.sqrt(r1ref / (r + 2 * spec.lams[l])), ph = 2 * Math.PI * (r + spec.xS) / spec.lams[l];
            re[l][idx] = A * Math.cos(ph); im[l][idx] = A * Math.sin(ph);
          }
        } else if (x <= spec.xP) {
          reg[idx] = 3;
          for (l = 0; l < nl; l++) {
            var sr = 0, si = 0, lam = spec.lams[l];
            for (s = 0; s < spec.srcs.length; s++) {
              if (spec.perLam && s !== l) continue;
              var rr = Math.hypot(x - spec.xD, y - spec.srcs[s].y), a = spec.srcs[s].w * Math.sqrt(r2ref / (rr + 2 * lam)) / (spec.perLam ? 1 : wsum), p = 2 * Math.PI * (rr + spec.xD) / lam;
              sr += a * Math.cos(p); si += a * Math.sin(p);
            }
            re[l][idx] = sr; im[l][idx] = si;
          }
        }
      }
    }
    return { cols: cols, rows: rows, re: re, im: im, reg: reg };
  }

  function View(canvas) {
    var ctx = canvas.getContext('2d'), W = 0, H = 0, dpr = 1, narrow = false, geo = null;
    var fieldCv = document.createElement('canvas'), fieldCtx = fieldCv.getContext('2d'), field = null, fieldKey = '', fieldImg = null;
    function resize(w, h) {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      W = w; H = h; narrow = w < 640;
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
      canvas.style.width = w + 'px'; canvas.style.height = h + 'px';
    }
    function bg() {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      var g = ctx.createLinearGradient(0, 0, 0, H);
      g.addColorStop(0, '#04060c'); g.addColorStop(1, '#0a1120');
      ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    }
    function area(bottomExtra) {
      var t0 = narrow ? 84 : 44, bottom = (narrow ? 44 : 50) + (bottomExtra || 0);
      return { x: 12, y: t0, w: W - 24, h: Math.max(160, H - t0 - bottom) };
    }

    // 挡板：竖直线段，在 gaps（[y0, y1]…）处断开
    function barrier(x, y0, y1, gaps, w) {
      ctx.fillStyle = BAR;
      var cur = y0;
      gaps.slice().sort(function (a, b) { return a[0] - b[0]; }).forEach(function (g) {
        if (g[0] > cur) ctx.fillRect(x - w / 2, cur, w, g[0] - cur);
        cur = Math.max(cur, g[1]);
      });
      if (y1 > cur) ctx.fillRect(x - w / 2, cur, w, y1 - cur);
    }
    function lamp(x, y, color) {
      var g = ctx.createRadialGradient(x, y, 1, x, y, 16);
      g.addColorStop(0, '#fff'); g.addColorStop(0.4, color); g.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, 16, 0, 7); ctx.fill();
    }

    // ---------- 场景一：双缝干涉 ----------
    // o：{ lam, white, water, mode, d, a, L, view: 'wave'|'int', lines, probe（光程差/λ，null 不显示）, t }
    function drawInterf(o) {
      bg();
      var R = area(), sH = Math.round(R.h * (narrow ? 0.56 : 0.6));
      var Sg = { x: R.x, y: R.y, w: R.w, h: sH };
      var B = { x: R.x + (narrow ? 4 : 30), y: R.y + sH + 26, w: R.w - (narrow ? 8 : 60), h: R.h - sH - 26 };
      var sch = schematic(Sg, o);
      // 屏上条纹
      var X = narrow ? 10 : 15, lamE = S.lamIn(o.lam, o.water);
      label(ctx, '正对光屏看到的条纹（实际尺寸，单位 mm）', B.x + B.w / 2, B.y - 12, { size: 12, color: MUTED });
      var st = fringeStrip(ctx, dpr, B, o, X, { curve: true });
      var stripGeo = { x0: B.x, x1: B.x + B.w, y0: B.y, y1: B.y + B.h, toMM: function (px) { return (px - B.x) / B.w * 2 * X - X; } };
      if (!o.white) {
        var cy = st.sy + st.sh * 0.5;
        if (o.mode === 'double') {
          var dx = S.spacing(lamE, o.d, o.L);
          var k0 = dx < 0.8 ? Math.ceil(1.5 / dx) : 1;  // 条纹太密时量多个间距
          if (k0 * dx < X * 0.95) {
            var yb = st.sy + 10;
            line(ctx, st.px(0), st.sy, st.px(0), st.sy + 16, GOLD, { width: 1 });
            line(ctx, st.px(k0 * dx), st.sy, st.px(k0 * dx), st.sy + 16, GOLD, { width: 1 });
            dim(ctx, st.px(0), yb, st.px(k0 * dx), yb, '', GOLD);
            label(ctx, (k0 > 1 ? k0 + 'Δx = ' + f(k0 * dx, 2) + ' mm，' : '') + 'Δx = ' + f(dx, dx < 1 ? 3 : 2) + ' mm', st.px(k0 * dx) + 8, yb, { color: GOLD, size: 12, align: 'left', bold: true });
          }
        } else {
          var cw = o.mode === 'single' ? S.centralWidth(lamE, o.a, o.L) : S.centralWidth(lamE, S.A_DOUBLE, o.L);
          if (cw / 2 < X) dim(ctx, st.px(-cw / 2), cy, st.px(cw / 2), cy, '中央亮纹宽 ' + f(cw, 1) + ' mm', GOLD, { tc: TEXT, bold: true });
          else label(ctx, '中央亮纹宽 ' + f(cw, 0) + ' mm，超出画面', B.x + B.w / 2, cy, { color: TEXT, bold: true });
        }
      }
      if (o.probe != null && o.mode === 'double' && !o.white) {
        var xm = o.probe * S.spacing(lamE, o.d, o.L);
        if (Math.abs(xm) < X) {
          var pxm = st.px(xm);
          line(ctx, pxm, st.base - st.cH, pxm, st.sy + st.sh, DR, { width: 1.4, dash: [4, 3] });
          head(ctx, pxm, st.sy + st.sh + 1, -Math.PI / 2, 8, DR);
          label(ctx, 'P', pxm, st.sy + st.sh + 14, { color: DR, bold: true });
        }
      }
      geo = { scene: 'interf', sch: sch, strip: stripGeo };
      return geo;
    }

    // 俯视示意图：光源 → 滤光片 → 单缝 S → 双缝 S1、S2 → 屏，右侧为屏上光强曲线
    function schematic(Sg, o) {
      var sc = Sg.h / 400, lamE = S.lamIn(o.lam, o.water);
      var curveW = Math.max(46, Sg.w * 0.09);
      var x0 = Sg.x + (narrow ? 10 : 18), xS = Sg.x + Math.max(60, Sg.w * 0.11), xD = Sg.x + Math.max(110, Sg.w * 0.27);
      var xMax = Sg.x + Sg.w - curveW - 14, xP = xD + (o.L / S.L_RANGE[1]) * (xMax - xD), yc = Sg.y + Sg.h / 2;
      var lamUnit = 9 * Math.max(sc, 0.8) / 600, dUnit = 300 * sc;
      var dpx = o.d * dUnit, apx = o.a * dUnit;
      var white = o.white || o.filters, cell = o.mode === 'single' || white ? 3 : 2;
      var MIX = o.filters ? [650, 530] : [430, 480, 530, 580, 640];   // 白光取五种色光；两缝加红、绿滤光片时各取一种
      var lams = white ? MIX.map(function (l) { return S.lamIn(l, o.water) * lamUnit; }) : [lamE * lamUnit];
      var srcs;
      if (o.mode === 'single') {
        var n = Math.max(3, Math.min(white ? 12 : 24, Math.ceil(apx / (lams[0] * 0.5))));
        srcs = [];
        for (var i = 0; i < n; i++) srcs.push({ y: yc - apx / 2 + apx * (i + 0.5) / n - Sg.y, w: 1 });
      } else if (o.mode === 'one') srcs = [{ y: yc - dpx / 2 - Sg.y, w: 1 }];
      else srcs = [{ y: yc - dpx / 2 - Sg.y, w: 1 }, { y: yc + dpx / 2 - Sg.y, w: 1 }];
      var fx = x0 + 22;   // 波场从滤光片右侧开始
      var spec = { w: xP - fx + 1, h: Sg.h, cell: cell, xS: xS - fx, xD: xD - fx, xP: xP - fx, yc: yc - Sg.y, beam: 26 * sc, srcs: srcs, lams: lams, perLam: !!o.filters };
      var key = JSON.stringify(spec);
      if (key !== fieldKey) {
        field = buildField(spec); fieldKey = key;
        fieldCv.width = field.cols; fieldCv.height = field.rows;
        fieldImg = fieldCtx.createImageData(field.cols, field.rows);
      }
      // 每帧着色
      var data = fieldImg.data, N = field.cols * field.rows, wt = 2 * Math.PI * o.t, cw = Math.cos(wt), sw = Math.sin(wt);
      var showWave = o.view === 'wave' && !white, rgb = S.lamRGB(o.lam);
      var wcols = null;
      if (white) {   // 五种色光的颜色归一化：各色光强都为 1 时叠加成白色
        wcols = MIX.map(function (l) { return S.lamRGB(l); });
        var sum = [0, 0, 0];
        wcols.forEach(function (c) { sum[0] += c[0]; sum[1] += c[1]; sum[2] += c[2]; });
        wcols = o.filters ? wcols.map(function (c) { return [c[0] * 0.5, c[1] * 0.5, c[2] * 0.5]; })
          : wcols.map(function (c) { return [c[0] / sum[0] * 0.9, c[1] / sum[1] * 0.9, c[2] / sum[2] * 0.9]; });
      }
      for (var p = 0; p < N; p++) {
        var rg = field.reg[p], q = p * 4;
        if (!rg || (o.hideRight && rg === 3)) { data[q] = data[q + 1] = data[q + 2] = 0; data[q + 3] = 0; continue; }
        var r, g, b;
        if (white) {
          r = g = b = 0;
          for (var l = 0; l < wcols.length; l++) {
            var I = field.re[l][p] * field.re[l][p] + field.im[l][p] * field.im[l][p];
            r += wcols[l][0] * I; g += wcols[l][1] * I; b += wcols[l][2] * I;
          }
        } else {
          var k;
          if (showWave) { var v = field.re[0][p] * cw + field.im[0][p] * sw; k = Math.max(0, 0.5 + 0.5 * v); k = k * k; }
          else k = field.re[0][p] * field.re[0][p] + field.im[0][p] * field.im[0][p];
          r = rgb[0] * k; g = rgb[1] * k; b = rgb[2] * k;
        }
        data[q] = Math.min(255, r * 255); data[q + 1] = Math.min(255, g * 255); data[q + 2] = Math.min(255, b * 255); data[q + 3] = 255;
      }
      fieldCtx.putImageData(fieldImg, 0, 0);
      ctx.save();
      ctx.beginPath(); ctx.rect(Sg.x, Sg.y, Sg.w, Sg.h); ctx.clip();
      ctx.imageSmoothingEnabled = true;
      ctx.drawImage(fieldCv, fx, Sg.y, field.cols * cell, field.rows * cell);

      // 加强线、减弱线（双曲线）
      var lam0 = lams[0], S1 = { x: xD, y: yc - dpx / 2 }, S2 = { x: xD, y: yc + dpx / 2 };
      function yOn(x, m) {   // 在横坐标 x 处找 r2 − r1 = m·λ 的点
        var target = m * lam0, lo = Sg.y - Sg.h, hi = Sg.y + 2 * Sg.h;
        var fn = function (y) { return Math.hypot(x - S2.x, y - S2.y) - Math.hypot(x - S1.x, y - S1.y) - target; };
        // fn 随 y 减小（P 向上靠近 S1）而增大
        if (fn(lo) < 0 || fn(hi) > 0) return null;
        for (var it = 0; it < 40; it++) { var mid = (lo + hi) / 2; if (fn(mid) > 0) lo = mid; else hi = mid; }
        return (lo + hi) / 2;
      }
      if (o.lines && o.mode === 'double' && !white) {
        var mMax = Math.floor(dpx / lam0 * 2) / 2;
        for (var m2 = -mMax * 2; m2 <= mMax * 2; m2++) {
          var m = m2 / 2, bright = m2 % 2 === 0;
          if (Math.abs(m) >= dpx / lam0) continue;
          ctx.strokeStyle = bright ? 'rgba(255,255,255,.55)' : 'rgba(140,160,190,.55)';
          ctx.lineWidth = bright ? 1.2 : 1; ctx.setLineDash(bright ? [] : [4, 4]);
          ctx.beginPath();
          var started = false;
          for (var xx = xD + 2; xx <= xP; xx += 4) {
            var yy = yOn(xx, m);
            if (yy == null || yy < Sg.y - 5 || yy > Sg.y + Sg.h + 5) { started = false; continue; }
            if (started) ctx.lineTo(xx, yy); else { ctx.moveTo(xx, yy); started = true; }
          }
          ctx.stroke(); ctx.setLineDash([]);
          if (Math.abs(m) <= 3 && bright) {
            var ye = yOn(xP, m);
            var yPr = o.probe != null ? yOn(xP, o.probe) : null;
            if (ye != null && ye > Sg.y + 8 && ye < Sg.y + Sg.h - 8 && (yPr == null || Math.abs(ye - yPr) > 16)) label(ctx, m === 0 ? '0' : (m > 0 ? '+' : '−') + Math.abs(m), xP - 10, ye, { size: 10, color: '#fff', align: 'right' });
          }
        }
      }
      ctx.restore();

      // 光源、滤光片、挡板、屏
      var col = white ? '#ffffff' : S.lamCSS(o.lam);
      lamp(x0, yc, col);
      if (!white) { ctx.fillStyle = S.lamCSS(o.lam, 0.75); ctx.fillRect(x0 + 16, yc - 30 * sc, 6, 60 * sc); }
      var gapS = Math.max(3, 4 * sc), gapD = Math.max(2.5, 3 * sc), bw = 4;
      barrier(xS, Sg.y + 4, Sg.y + Sg.h - 4, [[yc - gapS / 2, yc + gapS / 2]], bw);
      var gaps;
      if (o.mode === 'single') gaps = [[yc - apx / 2, yc + apx / 2]];
      else if (o.mode === 'one') gaps = [[S1.y - gapD / 2, S1.y + gapD / 2]];
      else gaps = [[S1.y - gapD / 2, S1.y + gapD / 2], [S2.y - gapD / 2, S2.y + gapD / 2]];
      barrier(xD, Sg.y + 4, Sg.y + Sg.h - 4, gaps, bw);
      if (o.mode === 'one') { ctx.fillStyle = '#9aa7bd'; ctx.fillRect(xD - 7, S2.y - 8, 5, 16); }
      if (o.filters) { ctx.fillStyle = S.lamCSS(650); ctx.fillRect(xD - 8, S1.y - 8, 4, 16); ctx.fillStyle = S.lamCSS(530); ctx.fillRect(xD - 8, S2.y - 8, 4, 16); }
      // 屏：按示意图里的光强着色（练习未作答时不画双缝右侧）
      if (o.hideRight) {
        label(ctx, '？', (xD + xP) / 2, yc, { size: 30, color: MUTED, bold: true });
        label(ctx, '双缝', xD, Sg.y + Sg.h - 12, { size: 11, color: MUTED });
        label(ctx, '屏', xP + 4, Sg.y + Sg.h - 12, { size: 11, color: MUTED });
        line(ctx, xP + 3, Sg.y + 4, xP + 3, Sg.y + Sg.h - 4, '#6f7d96', { width: 2 });
        return { x0: xD, x1: xP, y0: Sg.y, y1: Sg.y + Sg.h, xP: xP, P: null, toM: function () { return 0; } };
      }
      var ci = Math.min(field.cols - 1, Math.floor((xP - fx) / cell)), Iscr = [];
      while (ci > 0 && !field.reg[Math.floor(field.rows / 2) * field.cols + ci]) ci--;
      for (var jr = 0; jr < field.rows; jr++) {
        var pi = jr * field.cols + ci, Iv, cc;
        if (white) {
          cc = [0, 0, 0];
          for (var l2 = 0; l2 < wcols.length; l2++) { var I2 = field.re[l2][pi] * field.re[l2][pi] + field.im[l2][pi] * field.im[l2][pi]; cc[0] += wcols[l2][0] * I2; cc[1] += wcols[l2][1] * I2; cc[2] += wcols[l2][2] * I2; }
          Iv = (cc[0] + cc[1] + cc[2]) / 3;
        } else { Iv = field.re[0][pi] * field.re[0][pi] + field.im[0][pi] * field.im[0][pi]; cc = [rgb[0] * Iv, rgb[1] * Iv, rgb[2] * Iv]; }
        Iscr.push(Iv);
        ctx.fillStyle = rgbStr(cc); ctx.fillRect(xP, Sg.y + jr * cell, 7, cell + 0.5);
      }
      ctx.strokeStyle = '#6f7d96'; ctx.lineWidth = 1; ctx.strokeRect(xP + 0.5, Sg.y + 4.5, 7, Sg.h - 9);
      // 光强曲线（横向）
      var cx0 = xP + 14, Imax = 0;
      Iscr.forEach(function (v) { Imax = Math.max(Imax, v); });
      line(ctx, cx0, Sg.y + 6, cx0, Sg.y + Sg.h - 6, LINE);
      ctx.strokeStyle = white ? '#e6ebf2' : col; ctx.lineWidth = 1.4; ctx.beginPath();
      Iscr.forEach(function (v, jj) { var xx = cx0 + v / (Imax || 1) * (curveW - 6), yy = Sg.y + (jj + 0.5) * cell; if (jj) ctx.lineTo(xx, yy); else ctx.moveTo(xx, yy); });
      ctx.stroke();
      label(ctx, '光强', cx0 + 2, Sg.y + 10, { size: 11, color: MUTED, align: 'left' });

      // 标注
      var ly = Sg.y + Sg.h - 12;
      label(ctx, white ? '白光' : '光源', x0 + 6, yc + 26 * sc + 16, { size: 11, color: MUTED });
      label(ctx, '单缝 S', xS, ly, { size: 11, color: MUTED });
      label(ctx, o.mode === 'single' ? '单缝' : '双缝', xD, ly, { size: 11, color: MUTED });
      label(ctx, '屏', xP + 4, ly, { size: 11, color: MUTED });
      if (o.mode !== 'single') {
        label(ctx, 'S₁', xD - 14, S1.y, { size: 12, bold: true });
        label(ctx, 'S₂', xD - 14, S2.y, { size: 12, bold: true, color: o.mode === 'one' ? MUTED : TEXT });
        var dX = xD - 30;
        if (dpx > 16) dim(ctx, dX, S1.y, dX, S2.y, 'd', MUTED, { dx: -8, dy: 0 });
      } else label(ctx, 'a', xD - 14, yc, { size: 12, bold: true });
      var Ly = Sg.y + 16;
      dim(ctx, xD, Ly, xP, Ly, 'L', MUTED, { dy: -1, dx: 0 });
      label(ctx, '示意图：波长、缝距按比例放大', Sg.x + 4, Sg.y + 10, { size: 11, color: MUTED, align: 'left' });

      // P 点与光程差
      var Pg = null;
      if (o.probe != null && o.mode === 'double' && !white) {
        var yP = yOn(xP, o.probe);
        if (yP != null && yP > Sg.y && yP < Sg.y + Sg.h) {
          var P = { x: xP, y: yP }, r1 = Math.hypot(P.x - S1.x, P.y - S1.y), r2 = Math.hypot(P.x - S2.x, P.y - S2.y);
          var near = r1 < r2 ? S1 : S2, far = r1 < r2 ? S2 : S1, rn = Math.min(r1, r2), rf = Math.max(r1, r2);
          var M = { x: P.x + (far.x - P.x) * rn / rf, y: P.y + (far.y - P.y) * rn / rf };
          line(ctx, S1.x, S1.y, P.x, P.y, '#fff', { width: 1.2 });
          line(ctx, S2.x, S2.y, P.x, P.y, '#fff', { width: 1.2 });
          if (Math.abs(o.probe) > 0.02) {
            line(ctx, near.x, near.y, M.x, M.y, MUTED, { dash: [3, 3] });
            line(ctx, far.x, far.y, M.x, M.y, DR, { width: 3.5 });
            label(ctx, 'Δr', (far.x + M.x) / 2 + 4, (far.y + M.y) / 2 + (o.probe > 0 ? 12 : -12), { color: DR, bold: true, size: 12, align: 'left' });
          }
          ctx.fillStyle = DR; ctx.beginPath(); ctx.arc(P.x + 3, P.y, 4.5, 0, 7); ctx.fill();
          label(ctx, 'P', P.x - 10, P.y - 10, { color: DR, bold: true });
          Pg = P;
        }
      }
      return { x0: xD, x1: xP + curveW, y0: Sg.y, y1: Sg.y + Sg.h, xP: xP, P: Pg,
        toM: function (y) { var p = { x: xP, y: y }; return (Math.hypot(p.x - S2.x, p.y - S2.y) - Math.hypot(p.x - S1.x, p.y - S1.y)) / lam0; } };
    }

    // ---------- 手轮（螺旋测微器式）----------
    // Bx：矩形；R：读数（mm）
    function drum(Bx, R, o) {
      o = o || {};
      var cy = Bx.y + Bx.h / 2, xt = Bx.x + Bx.w * 0.58, x0 = Bx.x + 6, k = (xt - x0) / 7.5;
      var hs = Math.min(30, Bx.h * 0.13), rc = Math.min(Bx.h * 0.4, 120), tw = Math.min(Bx.w * 0.34, 150);
      // 固定套管
      var g = ctx.createLinearGradient(0, cy - hs, 0, cy + hs);
      g.addColorStop(0, '#5f6b80'); g.addColorStop(0.5, '#c9d1dd'); g.addColorStop(1, '#5f6b80');
      ctx.fillStyle = g; ctx.fillRect(x0, cy - hs, xt - x0 + 4, hs * 2);
      line(ctx, x0, cy, xt + 2, cy, '#111', { width: 1.3 });
      ctx.strokeStyle = '#111'; ctx.lineWidth = 1.2; ctx.beginPath();
      var p = S.wheelParts(R);
      for (var h2 = Math.ceil((R - 7.4) * 2); h2 / 2 <= R + 1e-9; h2++) {
        var v = h2 / 2, x = xt - (R - v) * k;
        if (x < x0 + 2) continue;
        if (h2 % 2 === 0) { var big = v % 5 === 0; ctx.moveTo(x, cy); ctx.lineTo(x, cy - (big ? hs * 0.85 : hs * 0.55)); }
        else { ctx.moveTo(x, cy); ctx.lineTo(x, cy + hs * 0.55); }
      }
      ctx.stroke();
      // 固定刻度的数字（每 5 mm 一个）标在套管上方
      for (var mm2 = Math.ceil((R - 7.4) / 5) * 5; mm2 <= R + 1e-9; mm2 += 5) {
        var xm2 = xt - (R - mm2) * k;
        if (xm2 > x0 + 6 && xm2 < xt - 4) label(ctx, String(mm2), xm2, cy - hs - 9, { size: Math.max(11, hs * 0.55), bold: true });
      }
      // 微分筒
      var tg = ctx.createLinearGradient(0, cy - rc, 0, cy + rc);
      tg.addColorStop(0, '#3a4252'); tg.addColorStop(0.5, '#d9dee7'); tg.addColorStop(1, '#3a4252');
      ctx.fillStyle = tg; ctx.fillRect(xt, cy - rc, tw, rc * 2);
      ctx.fillStyle = 'rgba(0,0,0,.25)'; ctx.fillRect(xt, cy - rc, 3, rc * 2);
      // 滚花
      ctx.strokeStyle = 'rgba(0,0,0,.25)'; ctx.lineWidth = 1; ctx.beginPath();
      for (var kx = xt + tw * 0.55; kx < xt + tw; kx += 4) { ctx.moveTo(kx, cy - rc + 2); ctx.lineTo(kx, cy + rc - 2); }
      ctx.stroke();
      // 可动刻度：50 格一周，比当前格大的在基准线上方
      var cur = (R - p.main) * 100;
      ctx.strokeStyle = '#111'; ctx.lineWidth = 1.2;
      for (var j = Math.floor(cur) - 14; j <= Math.ceil(cur) + 14; j++) {
        var phi = (j - cur) * 2 * Math.PI / 50, c = Math.cos(phi);
        if (c < 0.12) continue;
        var y = cy - rc * Math.sin(phi), i = ((j % 50) + 50) % 50, five = i % 5 === 0;
        ctx.globalAlpha = Math.min(1, c * 1.4);
        ctx.beginPath(); ctx.moveTo(xt, y); ctx.lineTo(xt + (five ? 18 : 10), y); ctx.stroke();
        if (five) { ctx.fillStyle = '#111'; ctx.font = font(Math.max(10, Math.min(13, rc * 0.17)) * (0.6 + 0.4 * c), 600); ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.fillText(String(i), xt + 21, y); }
      }
      ctx.globalAlpha = 1;
      if (o.caption) label(ctx, o.caption, Bx.x + Bx.w / 2, Bx.y + Bx.h - 6, { size: 12, color: MUTED });
      if (o.reading) label(ctx, o.reading, Bx.x + Bx.w / 2, Bx.y + 10, { size: 13, color: GOLD, bold: true });
      return { x0: Bx.x, x1: Bx.x + Bx.w, y0: cy - rc, y1: cy + rc };
    }

    // ---------- 目镜视野 ----------
    var eyeCv = document.createElement('canvas'), eyeCtx = eyeCv.getContext('2d'), eyeKey = '';
    // o：{ lam, d, L(mm), s0（中心刻线对着的屏上位置 mm）, tilt（°） }
    function eyepiece(cx, cy, r, o) {
      var n = Math.max(40, Math.round(2 * r * Math.min(dpr, 1.5))), key = [n, o.lam, o.d, o.L, o.s0.toFixed(4), o.tilt].join('|');
      if (key !== eyeKey) {
        eyeKey = key; eyeCv.width = eyeCv.height = n;
        var img = eyeCtx.createImageData(n, n), d = img.data, rgb = S.lamRGB(o.lam), F = S.RIG.field;
        var th = o.tilt * Math.PI / 180, ct = Math.cos(th), st = Math.sin(th), q = { lam: o.lam, d: o.d, L: o.L / 1000, mode: 'double' };
        for (var j = 0; j < n; j++) for (var i = 0; i < n; i++) {
          var u = (i + 0.5) / n - 0.5, v = (j + 0.5) / n - 0.5, rr = Math.hypot(u, v), idx = (j * n + i) * 4;
          if (rr > 0.5) { d[idx + 3] = 0; continue; }
          var sx = o.s0 + u * F, sy = -v * F, s = sx * ct + sy * st;
          // 双缝的缝宽用测量装置的数值 RIG.a
          var kk = Math.PI * s / (o.lam * 1e-3 * q.L), cc = Math.cos(kk * o.d), e = S.RIG.a, sn = Math.abs(kk * e) < 1e-6 ? 1 : Math.sin(kk * e) / (kk * e);
          var I = cc * cc * sn * sn, vig = 1 - Math.pow(rr * 2, 6) * 0.5;
          var bri = Math.pow(I, 0.8) * vig * 0.95 + 0.03;
          d[idx] = rgb[0] * bri * 255; d[idx + 1] = rgb[1] * bri * 255; d[idx + 2] = rgb[2] * bri * 255; d[idx + 3] = 255;
        }
        eyeCtx.putImageData(img, 0, 0);
      }
      ctx.fillStyle = '#000'; ctx.beginPath(); ctx.arc(cx, cy, r + 6, 0, 7); ctx.fill();
      ctx.drawImage(eyeCv, cx - r, cy - r, 2 * r, 2 * r);
      ctx.strokeStyle = '#3d4860'; ctx.lineWidth = 6; ctx.beginPath(); ctx.arc(cx, cy, r + 3, 0, 7); ctx.stroke();
      // 分划板：中心竖线 + 水平线与刻度
      ctx.save(); ctx.beginPath(); ctx.arc(cx, cy, r, 0, 7); ctx.clip();
      line(ctx, cx, cy - r, cx, cy + r, 'rgba(255,255,255,.95)', { width: 1.3 });
      line(ctx, cx - r, cy, cx + r, cy, 'rgba(255,255,255,.7)', { width: 1 });
      ctx.strokeStyle = 'rgba(255,255,255,.7)'; ctx.lineWidth = 1; ctx.beginPath();
      for (var t = -8; t <= 8; t++) { if (!t) continue; var tx = cx + t * r / 8; ctx.moveTo(tx, cy - (t % 2 ? 4 : 7)); ctx.lineTo(tx, cy + (t % 2 ? 4 : 7)); }
      ctx.stroke();
      ctx.restore();
      return { cx: cx, cy: cy, r: r, kf: 2 * r / S.RIG.field };
    }

    // ---------- 场景二：测量光的波长 ----------
    // o：{ lam, d, L（mm）, R, C（中央亮纹对应的读数）, tilt, filterName, reading（显示的读数文字或 ''）, passed（已移过的亮纹数，null 不显示） }
    function drawMeasure(o) {
      bg();
      var R0 = area(), bandH = Math.min(narrow ? 92 : 130, R0.h * 0.26);
      apparatus({ x: R0.x, y: R0.y, w: R0.w, h: bandH }, o);
      var top = R0.y + bandH + 14, hh = R0.h - bandH - 14, eg, dg;
      if (narrow) {
        var rr = Math.min(R0.w * 0.36, hh * 0.27);
        label(ctx, '目镜中看到的', R0.x + R0.w / 2, top + 4, { size: 12, color: MUTED });
        eg = eyepiece(R0.x + R0.w / 2, top + 16 + rr, rr, { lam: o.lam, d: o.d, L: o.L, s0: o.R - o.C, tilt: o.tilt });
        var dTop = top + 16 + 2 * rr + 16;
        dg = drum({ x: R0.x + R0.w * 0.08, y: dTop, w: R0.w * 0.84, h: Math.max(110, R0.y + R0.h - dTop) }, o.R, { caption: '手轮（放大）', reading: o.reading });
      } else {
        var r = Math.min(hh * 0.4, R0.w * 0.2);
        var ex = R0.x + R0.w * 0.28;
        label(ctx, '目镜中看到的（分划板中心刻线 + 干涉条纹）', ex, top + 4, { size: 12, color: MUTED });
        eg = eyepiece(ex, top + 22 + r, r, { lam: o.lam, d: o.d, L: o.L, s0: o.R - o.C, tilt: o.tilt });
        dg = drum({ x: R0.x + R0.w * 0.54, y: top + 10, w: R0.w * 0.42, h: Math.min(hh - 16, 2 * r + 36) }, o.R, { caption: '手轮读数（放大）：固定刻度 + 可动刻度格数 × 0.01 mm', reading: o.reading });
      }
      if (o.passed != null) label(ctx, '从第 1 次记录起已移过 ' + o.passed + ' 个条纹间距', eg.cx, eg.cy + eg.r + 18, { size: 12, color: GOLD });
      geo = { scene: 'measure', eye: eg, drum: dg };
      return geo;
    }
    // 装置示意图（侧视）：光源、凸透镜、滤光片、单缝、双缝、遮光筒、毛玻璃屏、测量头
    function apparatus(B, o) {
      var cy = B.y + B.h * 0.42, s = B.h / 130, xs = function (t) { return B.x + t * B.w; };
      var benchY = cy + 26 * s;
      ctx.fillStyle = '#2b3346'; ctx.fillRect(B.x, benchY, B.w, 6 * s);
      var col = S.lamCSS(o.lam), parts = [];
      // 光束
      ctx.fillStyle = S.lamCSS(o.lam, 0.18); ctx.fillRect(xs(0.2), cy - 4 * s, xs(0.82) - xs(0.2), 8 * s);
      ctx.fillStyle = 'rgba(255,240,200,.15)'; ctx.fillRect(xs(0.05), cy - 10 * s, xs(0.2) - xs(0.05), 20 * s);
      lamp(xs(0.04), cy, '#fff3c8'); parts.push([0.04, '光源']);
      // 凸透镜
      ctx.strokeStyle = '#8fd3ff'; ctx.lineWidth = 2; ctx.beginPath(); ctx.ellipse(xs(0.12), cy, 4 * s, 18 * s, 0, 0, 7); ctx.stroke(); parts.push([0.12, '凸透镜']);
      ctx.fillStyle = col; ctx.fillRect(xs(0.2) - 3, cy - 16 * s, 6, 32 * s); parts.push([0.2, o.filterName || '滤光片']);
      ctx.fillStyle = BAR; ctx.fillRect(xs(0.27) - 2, cy - 20 * s, 4, 17 * s); ctx.fillRect(xs(0.27) - 2, cy + 3 * s, 4, 17 * s); parts.push([0.27, '单缝']);
      ctx.fillRect(xs(0.34) - 2, cy - 20 * s, 4, 16 * s); ctx.fillRect(xs(0.34) - 2, cy - 2 * s, 4, 4 * s); ctx.fillRect(xs(0.34) - 2, cy + 4 * s, 4, 16 * s); parts.push([0.34, '双缝']);
      // 遮光筒
      ctx.strokeStyle = '#6f7d96'; ctx.lineWidth = 1.5; ctx.strokeRect(xs(0.36), cy - 14 * s, xs(0.82) - xs(0.36), 28 * s); parts.push([0.59, '遮光筒']);
      ctx.fillStyle = '#c8ccd4'; ctx.fillRect(xs(0.82) - 2, cy - 18 * s, 4, 36 * s); parts.push([0.82, '屏']);
      // 测量头：目镜 + 手轮
      ctx.fillStyle = '#4b5568'; ctx.fillRect(xs(0.84), cy - 10 * s, xs(0.93) - xs(0.84), 20 * s);
      ctx.fillStyle = '#7d889c'; ctx.fillRect(xs(0.93), cy - 6 * s, xs(0.97) - xs(0.93), 12 * s);
      ctx.fillStyle = '#9aa5b8'; ctx.beginPath(); ctx.arc(xs(0.88), cy + 16 * s, 8 * s, 0, 7); ctx.fill(); parts.push([0.9, '测量头']);
      parts.forEach(function (p) { label(ctx, p[1], xs(p[0]), benchY + 20 * s + 4, { size: narrow ? 10 : 11, color: MUTED }); });
      // d、L
      label(ctx, 'd = ' + o.d.toFixed(2) + ' mm', xs(0.34), cy - 30 * s, { size: 11, color: TEXT });
      dim(ctx, xs(0.34), cy - 22 * s, xs(0.82), cy - 22 * s, '', MUTED);
      label(ctx, 'L = ' + o.L + ' mm', xs(0.6), cy - 30 * s, { size: 11, color: TEXT });
    }

    // ---------- 练习 ----------
    function drawQuiz(q, answered, o) {
      bg();
      var R = area((o.quizH || 180) + 8);
      ctx.save(); ctx.beginPath(); ctx.rect(R.x - 6, R.y - 6, R.w + 12, R.h + 12); ctx.clip();
      if (q.type === 'change') quizChange(R, q, answered);
      else if (q.type === 'calc') quizCalc(R, q, answered);
      else if (q.type === 'point') quizPoint(R, q, answered);
      else quizConcept(R, q, answered);
      ctx.restore();
      geo = { scene: 'quiz' };
      return geo;
    }
    function stripBox(R, i, n, name, o, X, unknown) {
      var gap = 18, h = Math.min(110, (R.h - gap * (n - 1)) / n - 18), y = R.y + 18 + i * (h + gap + 18);
      var B = { x: R.x + 40, y: y, w: R.w - 60, h: h };
      label(ctx, name, R.x + 20, y + h / 2 - 11, { size: 14, bold: true });
      if (unknown) {
        ctx.fillStyle = '#0b1222'; ctx.fillRect(B.x, y, B.w, h - 22);
        ctx.strokeStyle = LINE; ctx.strokeRect(B.x + 0.5, y + 0.5, B.w - 1, h - 23);
        label(ctx, '？', B.x + B.w / 2, y + (h - 22) / 2, { size: 26, color: MUTED, bold: true });
        return null;
      }
      return fringeStrip(ctx, dpr, B, o, X);
    }
    function quizChange(R, q, answered) {
      var X = narrow ? 8 : 12, mk = function (p) { return { lam: p.lam, d: p.d, L: p.L, water: p.water, a: S.A_DOUBLE, mode: 'double' }; };
      stripBox(R, 0, 2, '甲', mk(q.base), X);
      stripBox(R, 1, 2, '乙', mk(q.after), X, !answered);
    }
    function quizCalc(R, q, answered) {
      if (q.sub === 'read') {
        var w = narrow ? R.w : R.w / 2 - 10, h = narrow ? R.h / 2 - 8 : Math.min(R.h, 300), y0 = narrow ? R.y : R.y + (R.h - h) / 2;
        drum({ x: R.x, y: y0, w: w, h: h }, q.a1, { caption: '甲：对齐第 1 条亮纹', reading: answered ? q.a1.toFixed(3) + ' mm' : '' });
        drum(narrow ? { x: R.x, y: R.y + h + 16, w: w, h: h } : { x: R.x + w + 20, y: y0, w: w, h: h }, q.a2,
          { caption: '乙：对齐第 ' + q.n + ' 条亮纹', reading: answered ? q.a2.toFixed(3) + ' mm' : '' });
        return;
      }
      var o = { lam: q.lam, d: q.d, L: q.L, a: S.A_DOUBLE, mode: 'double', view: 'int', t: 0 };
      var hS = answered ? R.h * 0.6 : R.h;
      schematic({ x: R.x, y: R.y, w: R.w, h: hS }, o);
      if (answered) {
        var B = { x: R.x + 30, y: R.y + hS + 14, w: R.w - 60, h: R.h - hS - 14 }, X = narrow ? 8 : 12;
        var st = fringeStrip(ctx, dpr, B, o, X), dx = S.spacing(q.lam, q.d, q.L);
        if (dx < X) { dim(ctx, st.px(0), st.sy + 12, st.px(dx), st.sy + 12, '', GOLD); label(ctx, 'Δx = ' + f(dx, 2) + ' mm', st.px(dx) + 8, st.sy + 12, { color: GOLD, bold: true, align: 'left' }); }
      }
    }
    function quizPoint(R, q, answered) {
      var o = { lam: q.lam, d: 0.25, L: 1, a: S.A_DOUBLE, mode: 'double', view: 'int', t: 0, probe: q.m, lines: answered };
      schematic(R, o);
    }
    function quizConcept(R, q, answered) {
      var sh = q.show || {}, base = { lam: 590, d: 0.25, L: 1, a: S.A_DOUBLE, mode: 'double', view: 'int', t: 0 };
      if (sh.white) base.white = true;
      if (sh.mode) base.mode = sh.mode;
      var hS = R.h * 0.58;
      schematic({ x: R.x, y: R.y, w: R.w, h: hS }, Object.assign({}, base, { filters: !!sh.filters, hideRight: !answered }));
      var B = { x: R.x + 30, y: R.y + hS + 26, w: R.w - 60, h: R.h - hS - 26 };
      if (!answered) {
        ctx.fillStyle = '#0b1222'; ctx.fillRect(B.x, B.y, B.w, B.h - 22);
        label(ctx, '答题后显示屏上的图样', B.x + B.w / 2, B.y + (B.h - 22) / 2, { color: MUTED });
        return;
      }
      label(ctx, '屏上的图样', B.x + B.w / 2, B.y - 12, { size: 12, color: MUTED });
      fringeStrip(ctx, dpr, B, Object.assign({}, base, { filters: !!sh.filters }), narrow ? 8 : 12);
    }

    return { resize: resize, drawInterf: drawInterf, drawMeasure: drawMeasure, drawQuiz: drawQuiz,
      geo: function () { return geo; }, narrow: function () { return narrow; } };
  }

  window.SlitDraw = { View: View };
})();
