// 双缝干涉的计算：条纹间距、屏上光强、光程差与条纹级次、波长颜色与白光叠加、测量头手轮读数、练习题
// 单位：波长 λ 用 nm，缝距 d、缝宽 a、屏上位置 x、手轮读数用 mm，双缝到屏的距离 L 用 m
// 屏上位置 x 以中央亮纹为原点；小角度近似 sinθ ≈ tanθ = x/L
(function () {
  var N_WATER = 1.33;
  var LAM_RANGE = [400, 700], D_RANGE = [0.1, 0.5], L_RANGE = [0.3, 1.5], A_RANGE = [0.05, 0.5];
  var A_DOUBLE = 0.03;   // 双缝每条缝的缝宽（mm），决定条纹亮度向两侧逐渐减弱的包络
  var LIGHTS = { red: { lam: 650, name: '红光' }, green: { lam: 530, name: '绿光' }, violet: { lam: 430, name: '紫光' } };

  function clamp(x, a, b) { return Math.max(a, Math.min(b, x)); }
  function f(x, n) { return (+x.toFixed(n == null ? 2 : n)).toString(); }
  function pick(rand, arr) { return arr[Math.floor(rand() * arr.length) % arr.length]; }

  // 介质中的波长：放入折射率为 n 的液体中 λ' = λ/n
  function lamIn(lam, water) { return water ? lam / N_WATER : lam; }

  // 相邻亮（暗）条纹间距 Δx = Lλ/d（mm）
  function spacing(lam, d, L) { return L * lam * 1e-3 / d; }
  // 单缝衍射中央亮纹宽度 2Lλ/a（mm）
  function centralWidth(lam, a, L) { return 2 * L * lam * 1e-3 / a; }
  // 由条纹间距反求波长 λ = dΔx/L（nm）
  function lamFrom(dx, d, L) { return dx * d / L * 1e3; }

  function sinc(u) { return Math.abs(u) < 1e-6 ? 1 : Math.sin(u) / u; }
  // 屏上 x 处的相对光强（中央为 1）。mode：'double' 双缝、'one' 遮住一条缝、'single' 单缝衍射
  function intensity(x, o) {
    var k = Math.PI * x / (o.lam * 1e-3 * o.L);  // 乘以缝距/缝宽（mm）得到相位的一半
    if (o.mode === 'single') { var s = sinc(k * o.a); return s * s; }
    var e = sinc(k * A_DOUBLE);
    if (o.mode === 'one') return e * e;
    var c = Math.cos(k * o.d);
    return c * c * e * e;
  }

  // 两缝到屏上 x 处的光程差 r2 − r1（nm，精确值；S1 在上 y = +d/2，S2 在下）
  function pathDiff(x, d, L) {
    var Lmm = L * 1e3, r1 = Math.hypot(Lmm, x - d / 2), r2 = Math.hypot(Lmm, x + d / 2);
    return (r2 - r1) * 1e6;
  }
  // 光程差为 m 个波长时的条纹描述：m 为整数是亮纹，半整数是暗纹
  // 亮纹：中央亮纹（m = 0）、第 k 条亮纹（m = ±k）；暗纹：m = ±(k − ½) 为第 k 条暗纹
  function fringeName(m) {
    var am = Math.abs(m), r = Math.round(am * 2) / 2, side = m > 0 ? '上方' : '下方';
    if (Math.abs(am - r) > 0.06) return { kind: 'mid', text: '介于亮纹与暗纹之间', m: m };
    if (r === 0) return { kind: 'bright', k: 0, text: '中央亮纹', m: 0 };
    if (r % 1 === 0) return { kind: 'bright', k: r, text: side + '第 ' + r + ' 条亮纹', m: m > 0 ? r : -r };
    return { kind: 'dark', k: r + 0.5, text: side + '第 ' + (r + 0.5) + ' 条暗纹', m: m > 0 ? r : -r };
  }

  // ---------- 颜色 ----------
  // 波长（nm）→ [r, g, b]（0–1），常用的分段近似，两端变暗
  function lamRGB(lam) {
    var r = 0, g = 0, b = 0;
    if (lam < 440) { r = -(lam - 440) / 60; b = 1; }
    else if (lam < 490) { g = (lam - 440) / 50; b = 1; }
    else if (lam < 510) { g = 1; b = -(lam - 510) / 20; }
    else if (lam < 580) { r = (lam - 510) / 70; g = 1; }
    else if (lam < 645) { r = 1; g = -(lam - 645) / 65; }
    else r = 1;
    var k = lam < 420 ? 0.35 + 0.65 * (lam - 380) / 40 : lam > 680 ? 0.35 + 0.65 * (750 - lam) / 70 : 1;
    k = clamp(k, 0.2, 1);
    return [Math.pow(r * k, 0.8), Math.pow(g * k, 0.8), Math.pow(b * k, 0.8)];
  }
  function css(rgb, a) {
    return 'rgba(' + Math.round(rgb[0] * 255) + ',' + Math.round(rgb[1] * 255) + ',' + Math.round(rgb[2] * 255) + ',' + (a == null ? 1 : a) + ')';
  }
  function lamCSS(lam, a) { return css(lamRGB(lam), a); }
  function colorName(lam) {
    return lam < 450 ? '紫' : lam < 490 ? '蓝' : lam < 500 ? '青' : lam < 570 ? '绿' : lam < 590 ? '黄' : lam < 620 ? '橙' : '红';
  }

  // 白光：400–700 nm 等间隔取样叠加，归一化使中央亮纹为白色
  var WHITE = [];
  (function () {
    var sum = [0, 0, 0], i, c;
    for (i = 0; i <= 30; i++) { c = lamRGB(400 + i * 10); WHITE.push({ lam: 400 + i * 10, rgb: c }); sum[0] += c[0]; sum[1] += c[1]; sum[2] += c[2]; }
    WHITE.forEach(function (w) { w.rgb = [w.rgb[0] / sum[0], w.rgb[1] / sum[1], w.rgb[2] / sum[2]]; });
  })();
  // 屏上 x 处的颜色与亮度：返回 [r, g, b]（0–1，可能略大于 1，绘制时截断）
  // o.lam 为真空中的波长：颜色由频率决定，放入水中颜色不变，只是波长变短、条纹变密
  function screenRGB(x, o) {
    if (!o.white) {
      var I = intensity(x, { lam: lamIn(o.lam, o.water), d: o.d, a: o.a, L: o.L, mode: o.mode }), c = lamRGB(o.lam);
      return [c[0] * I, c[1] * I, c[2] * I];
    }
    var out = [0, 0, 0];
    for (var i = 0; i < WHITE.length; i++) {
      var w = WHITE[i], q = { lam: lamIn(w.lam, o.water), d: o.d, a: o.a, L: o.L, mode: o.mode }, I = intensity(x, q);
      out[0] += w.rgb[0] * I; out[1] += w.rgb[1] * I; out[2] += w.rgb[2] * I;
    }
    return out;
  }

  // ---------- 测量头（手轮读数，与螺旋测微器相同：固定刻度 0.5 mm 一格，可动刻度 50 格、每格 0.01 mm）----------
  var WHEEL = [0, 25];
  // 读数拆成固定刻度与可动刻度：固定刻度读到 0.5 mm，可动刻度格数估读到 0.1 格
  function wheelParts(R) {
    var main = Math.floor(R * 2 + 1e-9) / 2, div = (R - main) * 100;
    if (div > 49.95) { main += 0.5; div = 0; }
    return { main: main, div: Math.round(div * 10) / 10, reading: main + Math.round(div * 10) / 1000 };
  }
  function wheelText(R) { return wheelParts(R).reading.toFixed(3) + ' mm'; }

  // 测量实验的装置：缝距 d（mm）可选，双缝到屏 L（mm）可选；滤光片对应的真实波长
  var RIG = {
    ds: [0.20, 0.25, 0.30], Ls: [600, 700, 800],
    filters: { red: { lam: 660, name: '红色滤光片' }, green: { lam: 530, name: '绿色滤光片' } },
    field: 8,           // 目镜视野直径对应屏上的宽度（mm）
    a: 0.02,            // 测量用双缝的缝宽（mm）
    tilt: 12            // “条纹与分划板不平行”时的夹角（°）
  };

  // ---------- 练习 ----------
  function options(rand, ans, pool, n) {
    n = n || 4;
    var out = [ans];
    pool = pool.slice();
    while (out.length < n && pool.length) {
      var c = pool.splice(Math.floor(rand() * pool.length), 1)[0];
      if (out.indexOf(c) < 0) out.push(c);
    }
    for (var i = out.length - 1; i > 0; i--) { var j = Math.floor(rand() * (i + 1)), t = out[i]; out[i] = out[j]; out[j] = t; }
    return out;
  }

  // 条纹间距怎样变化
  var CHANGES = [
    { what: '增大双缝间距 d', ans: '变小', why: 'Δx = Lλ/d，d 增大，Δx 变小。', set: { d: 1.5 } },
    { what: '减小双缝间距 d', ans: '变大', why: 'Δx = Lλ/d，d 减小，Δx 变大。', set: { d: 0.6 } },
    { what: '增大双缝到屏的距离 L', ans: '变大', why: 'Δx = Lλ/d，L 增大，Δx 变大。', set: { L: 1.5 } },
    { what: '把屏向双缝移近一些', ans: '变小', why: '屏移近即 L 减小，Δx = Lλ/d 变小。', set: { L: 0.6 } },
    { what: '把绿色滤光片换成红色滤光片', ans: '变大', why: '红光波长比绿光长，Δx = Lλ/d 变大。', set: { lam: 650 }, base: { lam: 530 } },
    { what: '把红色滤光片换成蓝色滤光片', ans: '变小', why: '蓝光波长比红光短，Δx = Lλ/d 变小。', set: { lam: 460 }, base: { lam: 650 } },
    { what: '把整个装置浸入水中', ans: '变小', why: '光在水中的波长 λ\' = λ/n 变短，Δx = Lλ\'/d 变小。', set: { water: true } },
    { what: '增大单缝到双缝的距离', ans: '不变', why: 'Δx = Lλ/d 只与双缝到屏的距离 L、双缝间距 d、波长 λ 有关，与单缝到双缝的距离无关。', set: {} },
    { what: '换用功率更大的光源（光的颜色不变）', ans: '不变', why: '条纹更亮，但波长不变，Δx = Lλ/d 不变。', set: {} }
  ];
  function quizChange(rand) {
    var c = pick(rand, CHANGES), base = { lam: 590, d: 0.25, L: 1, water: false };
    if (c.base) for (var k in c.base) base[k] = c.base[k];
    var after = { lam: base.lam, d: base.d, L: base.L, water: base.water };
    if (c.set.d) after.d = base.d * c.set.d;
    if (c.set.L) after.L = base.L * c.set.L;
    if (c.set.lam) after.lam = c.set.lam;
    if (c.set.water) after.water = true;
    return { type: 'change', base: base, after: after, answer: c.ans, options: ['变大', '变小', '不变'],
      prompt: '用单色光做双缝干涉实验，屏上得到等间距的明暗条纹（图甲）。若只' + c.what + '，屏上相邻亮条纹的间距将：',
      explain: c.why };
  }

  // 计算：求条纹间距，或由手轮读数求波长
  function quizCalc(rand) {
    if (rand() < 0.45) {
      var d = pick(rand, [0.2, 0.25, 0.4, 0.5]), L = pick(rand, [0.8, 1, 1.2]), lam = pick(rand, [480, 500, 600, 640]);
      var dx = spacing(lam, d, L);
      var ans = f(dx, 2) + ' mm';
      var pool = [dx * 10, dx / 10, lam * 1e-3 * d / L, dx * 2, dx / 2, d / (L * lam * 1e-3)].map(function (x) { return f(x, 2) + ' mm'; });
      return { type: 'calc', sub: 'dx', d: d, L: L, lam: lam, answer: ans, options: options(rand, ans, pool),
        prompt: '双缝间距 d = ' + f(d) + ' mm，双缝到屏的距离 L = ' + f(L) + ' m，用波长 ' + lam + ' nm 的光照射，屏上相邻亮条纹的间距是？',
        explain: 'Δx = Lλ/d = ' + f(L) + ' m × ' + lam + '×10⁻⁹ m ÷ (' + f(d) + '×10⁻³ m) = ' + f(dx, 2) + '×10⁻³ m = ' + f(dx, 2) + ' mm。注意先把单位统一成 m（1 nm = 10⁻⁹ m，1 mm = 10⁻³ m）。' };
    }
    // 由测量头读数求波长：第 1 条与第 n 条亮纹
    var d2 = pick(rand, RIG.ds), L2 = pick(rand, RIG.Ls), lam2 = pick(rand, [480, 540, 600, 630, 660]), n = pick(rand, [4, 5, 6, 7]);
    var dx2 = spacing(lam2, d2, L2 / 1000);
    var a1 = Math.round((1 + rand() * 2.5) * 1000) / 1000;
    var a2 = Math.round((a1 + (n - 1) * dx2) * 1000) / 1000;
    var real = (a2 - a1) / (n - 1), lamR = lamFrom(real, d2, L2 / 1000);
    var ans2 = Math.round(lamR) + ' nm';
    var pool2 = [lamFrom((a2 - a1) / n, d2, L2 / 1000), lamFrom((a2 - a1) / (n - 2), d2, L2 / 1000), lamFrom(a2 - a1, d2, L2 / 1000) / 10, lamR * 2]
      .map(function (x) { return Math.round(x) + ' nm'; });
    return { type: 'calc', sub: 'read', d: d2, L: L2, n: n, a1: a1, a2: a2, lam: lam2, answer: ans2, options: options(rand, ans2, pool2),
      prompt: '用双缝干涉测光的波长：d = ' + d2.toFixed(2) + ' mm，L = ' + L2 + ' mm。分划板中心刻线对齐第 1 条亮纹中央时手轮读数如图甲，对齐第 ' + n + ' 条亮纹中央时如图乙。所测光的波长约为？',
      explain: '读数：甲 ' + a1.toFixed(3) + ' mm，乙 ' + a2.toFixed(3) + ' mm（固定刻度 + 可动刻度格数 × 0.01 mm）。第 1 条到第 ' + n + ' 条之间有 ' + (n - 1) + ' 个间距，Δx = (' + a2.toFixed(3) + ' − ' + a1.toFixed(3) + ')/' + (n - 1) + ' = ' + f(real, 3) + ' mm，λ = dΔx/L = ' + Math.round(lamR) + ' nm。' };
  }

  // 屏上某点是亮纹还是暗纹
  function quizPoint(rand) {
    var lam = pick(rand, [500, 600, 400]), dark = rand() < 0.5, k = pick(rand, [1, 2, 3]);
    var m = dark ? k - 0.5 : k, dr = m * lam;     // nm
    var um = f(dr / 1000, 2) + ' μm';
    var name = function (kind, kk) { return '第 ' + kk + ' 条' + (kind === 'b' ? '亮' : '暗') + '条纹'; };
    var ans = dark ? name('d', k) : name('b', k);
    var pool = [name('b', k), name('d', k), name('b', k + 1), name('d', k + 1), name('b', Math.max(1, k - 1)), name('d', Math.max(1, k - 1)), '中央亮条纹'];
    pool = pool.filter(function (s) { return s !== ans; });
    return { type: 'point', lam: lam, m: m, dr: dr, answer: ans, options: options(rand, ans, pool),
      prompt: '用波长 ' + lam + ' nm 的单色光做双缝干涉实验，屏上 P 点到两缝的距离之差 S₂P − S₁P = ' + um + '。P 点处是（从中央亮纹向上数）：',
      explain: '光程差 Δr = ' + um + ' = ' + f(m, 1) + 'λ。Δr = kλ 处是亮纹，Δr = (k − ½)λ 处是暗纹（第 1 条暗纹 Δr = λ/2）。' +
        (dark ? 'Δr = (' + k + ' − ½)λ，所以是第 ' + k + ' 条暗条纹。' : 'Δr = ' + k + 'λ，所以是第 ' + k + ' 条亮条纹（中央亮纹 Δr = 0 不算）。') };
  }

  // 概念：白光、滤光片、遮缝、单缝和双缝的作用
  var CONCEPTS = [
    { id: 'whiteC', q: '用白光做双缝干涉实验，屏上中央亮条纹的颜色是：', a: '白色', o: ['红色', '紫色', '黑色'], show: { white: true },
      why: '中央亮纹处各种色光的光程差都为 0，都是亮纹，叠加起来仍是白色。' },
    { id: 'whiteIn', q: '用白光做双缝干涉实验，中央亮纹两侧是彩色条纹，每一级彩色条纹中离中央亮纹最近的是：', a: '紫色', o: ['红色', '白色', '绿色'], show: { white: true },
      why: '紫光波长最短，条纹间距 Δx = Lλ/d 最小，所以彩色条纹内侧是紫色、外侧是红色。' },
    { id: 'filters', q: '用白光做双缝干涉实验时，在一条缝前放红色滤光片、另一条缝前放绿色滤光片，屏上将：', a: '没有干涉条纹，但仍有光亮', o: ['出现红绿相间的干涉条纹', '一片黑暗', '只有红色干涉条纹'], show: { filters: true },
      why: '通过两条缝的红光和绿光频率不同，不是相干光，不能产生干涉条纹，但屏上仍有光照到。' },
    { id: 'cover', q: '用单色光做双缝干涉实验时，把其中一条缝遮住，屏上将：', a: '出现中央宽、两侧窄的衍射条纹', o: ['仍是等间距的干涉条纹，只是变暗', '一片黑暗', '条纹间距变为原来的 2 倍'], show: { mode: 'one' },
      why: '只剩一条缝，没有两列相干光叠加，不再有干涉条纹；光通过狭缝发生衍射，屏上是中央亮纹宽而亮、两侧窄而暗的衍射图样（缝很窄时中央亮纹很宽，几乎是一片均匀的亮区）。' },
    { id: 'double', q: '在双缝干涉实验中，双缝的作用是：', a: '获得两个振动情况相同的相干光源', o: ['增大光的亮度', '把白光分解成单色光', '使光发生折射'], show: {},
      why: '一束光通过双缝被分成两束，它们来自同一光源，频率相同、相位差恒定，是相干光，叠加后才会出现稳定的干涉条纹。' },
    { id: 'single', q: '在“用双缝干涉测量光的波长”实验中，滤光片和单缝的作用分别是：', a: '获得单色光；获得线光源', o: ['获得线光源；获得单色光', '使光变亮；使光变暗', '获得相干光；使光发生折射'], show: {},
      why: '滤光片只让某种颜色的光通过，得到单色光；单缝相当于一个线光源，使射到双缝上的光成为相干光。单缝与双缝要互相平行。' },
    { id: 'center', q: '双缝干涉中，屏上中央亮纹所在位置到两缝的光程差为：', a: '0', o: ['λ/2', 'λ', '2λ'], show: {},
      why: '中央亮纹在两缝的中垂线上，到两缝距离相等，光程差为 0，两列光波总是同相叠加，振动加强。' }
  ];
  function quizConcept(rand, avoidId) {
    var c, tries = 0;
    do { c = pick(rand, CONCEPTS); } while (c.id === avoidId && ++tries < 8);
    return { type: 'concept', cid: c.id, show: c.show, answer: c.a, options: options(rand, c.a, c.o), prompt: c.q, explain: c.why };
  }

  var TYPES = ['change', 'calc', 'point', 'concept'];
  function quiz(rand, avoid, only) {
    var gen = { change: quizChange, calc: quizCalc, point: quizPoint, concept: quizConcept }, q, tries = 0;
    do {
      var t = only || pick(rand, TYPES);
      q = gen[t](rand, avoid && avoid.cid);
      q.id = q.type + '|' + q.prompt;
    } while (avoid && q.id === avoid.id && ++tries < 10);
    return q;
  }

  window.Slit = {
    N_WATER: N_WATER, LAM_RANGE: LAM_RANGE, D_RANGE: D_RANGE, L_RANGE: L_RANGE, A_RANGE: A_RANGE, A_DOUBLE: A_DOUBLE,
    LIGHTS: LIGHTS, RIG: RIG, WHEEL: WHEEL, WHITE: WHITE, TYPES: TYPES,
    clamp: clamp, f: f, lamIn: lamIn, spacing: spacing, centralWidth: centralWidth, lamFrom: lamFrom,
    intensity: intensity, pathDiff: pathDiff, fringeName: fringeName,
    lamRGB: lamRGB, css: css, lamCSS: lamCSS, colorName: colorName, screenRGB: screenRGB,
    wheelParts: wheelParts, wheelText: wheelText, quiz: quiz
  };
})();
