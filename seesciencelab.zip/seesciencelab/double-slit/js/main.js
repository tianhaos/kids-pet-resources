(function () {
  var S = window.Slit, D = window.SlitDraw, f = S.f;
  var $ = function (id) { return document.getElementById(id); };
  var qa = function (sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); };
  var NAME = '双缝干涉';

  var state = {
    scene: 'interf',
    light: 'red', lam: 650, mode: 'double', d: 0.2, a: 0.1, L: 1, water: false,
    view: 'wave', lines: false, probe: 1, t: 0, paused: false,
    // 测量：滤光片、缝距、L（mm）、手轮读数 R、中央亮纹对应的读数 C、记录
    filter: 'red', lamM: 660, dM: 0.2, LM: 700, R: 4, C: 12.6, tilt: false, showRead: false, helper: true, rec: [],
    quiz: null, quizOnly: null, answered: false, correct: false, choice: null, score: { n: 0, ok: 0 }
  };

  var HINTS = {
    interf: '拖动光屏（或下方条纹）上的 P 点，看两列光的光程差',
    measure: '左右拖动目镜视野（或上下拖动手轮）移动分划板，对齐亮纹后记录读数',
    quiz: '双缝干涉 · 判断练习'
  };
  var MODES = { double: '双缝干涉', one: '遮住一条缝', single: '单缝衍射' };

  var stage = $('stage'), panel = $('panel'), cv = $('view');
  var view = D.View(cv);
  function setSeg(attr, val) { qa('[data-' + attr + ']').forEach(function (b) { b.classList.toggle('on', b.dataset[attr] === String(val)); }); }
  function lamE() { return S.lamIn(state.lam, state.water); }
  function dxM() { return S.spacing(state.lamM, state.dM, state.LM / 1000); }
  function cosT() { return Math.cos((state.tilt ? S.RIG.tilt : 0) * Math.PI / 180); }

  // ---------- 场景 ----------
  qa('[data-scene]').forEach(function (b) {
    b.addEventListener('click', function () { setScene(b.dataset.scene); Analytics.track(NAME, '场景', b.textContent); });
  });
  function setScene(sc) {
    state.scene = sc;
    if (sc === 'quiz' && !state.quiz) newQuiz();
    $('rName').className = '';
    syncUI();
  }

  // ---------- 场景一控件 ----------
  qa('[data-light]').forEach(function (b) {
    b.addEventListener('click', function () {
      state.light = b.dataset.light;
      if (S.LIGHTS[state.light]) state.lam = S.LIGHTS[state.light].lam;
      syncUI(); Analytics.track(NAME, '光源', b.textContent);
    });
  });
  qa('[data-mode]').forEach(function (b) {
    b.addEventListener('click', function () { state.mode = b.dataset.mode; syncUI(); Analytics.track(NAME, '缝', b.textContent); });
  });
  qa('[data-view]').forEach(function (b) {
    b.addEventListener('click', function () { state.view = b.dataset.view; syncUI(); Analytics.track(NAME, '显示', b.textContent); });
  });
  function bindSlider(id, get, set) {
    var el = $(id);
    el.addEventListener('input', function () { set(parseFloat(el.value)); });
    el.addEventListener('change', function () { Analytics.track(NAME, '滑块', id); });
    return { el: el, get: get };
  }
  var sliders = [
    bindSlider('lam', function () { return state.lam; }, function (x) { state.lam = x; if (state.light !== 'white') state.light = 'custom'; syncUI(); }),
    bindSlider('d', function () { return state.d; }, function (x) { state.d = x; }),
    bindSlider('a', function () { return state.a; }, function (x) { state.a = x; }),
    bindSlider('L', function () { return state.L; }, function (x) { state.L = x; })
  ];
  $('water').addEventListener('change', function () { state.water = $('water').checked; Analytics.track(NAME, '放入水中', String(state.water)); });
  $('lines').addEventListener('change', function () { state.lines = $('lines').checked; Analytics.track(NAME, '加强线', String(state.lines)); });
  $('probeOn').addEventListener('change', function () { state.probe = $('probeOn').checked ? 1 : null; Analytics.track(NAME, '光程差', String(state.probe != null)); });
  function togglePause() { state.paused = !state.paused; syncUI(); }
  qa('.pause').forEach(function (b) { b.addEventListener('click', togglePause); });

  // ---------- 场景二控件 ----------
  function resetMeasure() {
    state.rec = [];
    // 中央亮纹位置不取整，初始读数在它左边约三个半间距处
    var dx = dxM();
    state.C = 12.3 + Math.random() * 0.8;
    state.R = S.clamp(state.C - (3.3 + Math.random() * 0.4) * dx / cosT(), 0.5, 24);
  }
  function setFilter(fl) {
    state.filter = fl;
    state.lamM = fl === 'unknown' ? Math.round(450 + Math.random() * 230) : S.RIG.filters[fl].lam;
    resetMeasure();
  }
  qa('[data-filter]').forEach(function (b) {
    b.addEventListener('click', function () { setFilter(b.dataset.filter); syncUI(); Analytics.track(NAME, '滤光片', b.textContent); });
  });
  qa('[data-dm]').forEach(function (b) {
    b.addEventListener('click', function () { state.dM = parseFloat(b.dataset.dm); resetMeasure(); syncUI(); Analytics.track(NAME, '缝距', b.textContent); });
  });
  qa('[data-lm]').forEach(function (b) {
    b.addEventListener('click', function () { state.LM = parseFloat(b.dataset.lm); resetMeasure(); syncUI(); Analytics.track(NAME, '双缝到屏', b.textContent); });
  });
  function moveR(dR) { state.R = S.clamp(state.R + dR, S.WHEEL[0], S.WHEEL[1]); }
  qa('[data-step]').forEach(function (b) {
    b.addEventListener('click', function () { moveR(parseFloat(b.dataset.step)); });
  });
  $('tilt').addEventListener('change', function () { state.tilt = $('tilt').checked; state.rec = []; Analytics.track(NAME, '不平行', String(state.tilt)); });
  $('showRead').addEventListener('change', function () { state.showRead = $('showRead').checked; });
  $('helper').addEventListener('change', function () { state.helper = $('helper').checked; });
  $('record').addEventListener('click', function () {
    if (state.rec.length >= 2) state.rec = [];
    var reading = S.wheelParts(state.R).reading;
    if (!state.rec.length) state.rec.push({ R: reading, n: 1, off: alignOff() });
    else {
      var n = 1 + Math.round(Math.abs(reading - state.rec[0].R) * cosT() / dxM());
      state.rec.push({ R: reading, n: n, off: alignOff() });
    }
    Analytics.track(NAME, '记录读数', String(state.rec.length));
  });
  $('remeasure').addEventListener('click', function () { resetMeasure(); Analytics.track(NAME, '重新测量', state.filter); });
  // 中心刻线到最近亮纹中央的偏差（以条纹间距为单位，−0.5 ~ 0.5）
  function alignOff() {
    var m = (state.R - state.C) * cosT() / dxM();
    return m - Math.round(m);
  }

  // ---------- 画布拖动 ----------
  var drag = null;
  function local(e) { var r = cv.getBoundingClientRect(); return { x: e.clientX - r.left, y: e.clientY - r.top }; }
  function inBox(p, b) { return b && p.x >= b.x0 - 10 && p.x <= b.x1 + 10 && p.y >= b.y0 - 10 && p.y <= b.y1 + 10; }
  function snapM(m) { var r = Math.round(m * 2) / 2; return Math.abs(m - r) < 0.07 ? r : m; }
  function probeAt(p, where) {
    var g = view.geo(), m;
    if (where === 'sch') m = g.sch.toM(p.y);
    else m = g.strip.toMM(p.x) / S.spacing(lamE(), state.d, state.L);
    state.probe = Math.max(-12, Math.min(12, snapM(m)));
  }
  cv.addEventListener('pointerdown', function (e) {
    if (e.button !== 0) return;
    var p = local(e), g = view.geo();
    if (!g || g.scene === 'quiz') return;
    if (g.scene === 'interf') {
      if (state.mode !== 'double' || state.light === 'white') return;
      if (inBox(p, g.sch) && p.x > g.sch.xP - 60) drag = { kind: 'sch' };
      else if (inBox(p, g.strip)) drag = { kind: 'strip' };
      else return;
      probeAt(p, drag.kind);
      syncUI();
    } else {
      var eg = g.eye;
      if (Math.hypot(p.x - eg.cx, p.y - eg.cy) < eg.r + 10) drag = { kind: 'eye', x: p.x, kf: eg.kf };
      else if (inBox(p, g.drum)) drag = { kind: 'drum', y: p.y, rc: (g.drum.y1 - g.drum.y0) / 2 };
      else return;
    }
    try { cv.setPointerCapture(e.pointerId); } catch (err) { /* 合成事件 */ }
    Analytics.track(NAME, '拖动', drag.kind);
  });
  cv.addEventListener('pointermove', function (e) {
    var p = local(e);
    if (!drag) {
      var g = view.geo(), c = '';
      if (g && g.scene === 'interf' && state.mode === 'double' && state.light !== 'white' && ((inBox(p, g.sch) && p.x > g.sch.xP - 60) || inBox(p, g.strip))) c = 'ns-resize';
      if (g && g.scene === 'interf' && inBox(p, g.strip)) c = c && 'ew-resize';
      if (g && g.scene === 'measure') c = Math.hypot(p.x - g.eye.cx, p.y - g.eye.cy) < g.eye.r ? 'ew-resize' : inBox(p, g.drum) ? 'ns-resize' : '';
      cv.style.cursor = c;
      return;
    }
    if (drag.kind === 'sch' || drag.kind === 'strip') { probeAt(p, drag.kind); return; }
    // 视野里的条纹跟着手指走：向右拖，测量头向左移，读数减小
    if (drag.kind === 'eye') { moveR(-(p.x - drag.x) / drag.kf); drag.x = p.x; }
    // 微分筒转一周（表面走过 2π·r）读数变化 0.5 mm；向下拖读数增大
    else { moveR((p.y - drag.y) * 0.5 / (2 * Math.PI * drag.rc)); drag.y = p.y; }
  });
  function endDrag(e) {
    if (!drag) return;
    drag = null;
    if (cv.hasPointerCapture(e.pointerId)) cv.releasePointerCapture(e.pointerId);
  }
  cv.addEventListener('pointerup', endDrag);
  cv.addEventListener('pointercancel', endDrag);
  cv.addEventListener('wheel', function (e) {
    if (state.scene !== 'measure') return;
    e.preventDefault();
    moveR((e.deltaY > 0 ? 1 : -1) * (e.shiftKey ? 0.1 : 0.01));
  }, { passive: false });

  // ---------- 练习 ----------
  function newQuiz() {
    state.quiz = S.quiz(Math.random, state.quiz, state.quizOnly);
    state.answered = false; state.choice = null;
    var box = $('quizOpts');
    box.innerHTML = '';
    state.quiz.options.forEach(function (o) {
      var b = document.createElement('button');
      b.className = 'small';
      b.textContent = o;
      b.addEventListener('click', function () { answer(o); });
      box.appendChild(b);
    });
    $('quizOpts').classList.toggle('three', state.quiz.options.length === 3);
    syncUI();
  }
  function answer(o) {
    if (state.answered) return;
    state.answered = true;
    state.choice = o;
    state.correct = o === state.quiz.answer;
    state.score.n++; if (state.correct) state.score.ok++;
    Analytics.track(NAME, '练习', state.quiz.type + (state.correct ? ' 对' : ' 错'));
    syncUI();
  }
  $('nextQ').addEventListener('click', newQuiz);
  // 把题目的条件搬到模型里
  $('showQ').addEventListener('click', function () {
    var q = state.quiz;
    state.mode = 'double'; state.water = false; state.view = 'int'; state.lines = false; state.probe = null;
    function setLam(l) { state.lam = S.clamp(l, S.LAM_RANGE[0], S.LAM_RANGE[1]); state.light = 'custom'; }
    if (q.type === 'change') { setLam(q.after.lam); state.d = q.after.d; state.L = q.after.L; state.water = q.after.water; }
    else if (q.type === 'calc') {
      setLam(q.lam); state.d = q.d; state.L = q.sub === 'read' ? q.L / 1000 : q.L;
      if (q.sub === 'read') { state.lamM = Math.round(q.lam); state.dM = q.d; state.LM = q.L; state.filter = 'unknown'; resetMeasure(); setScene('measure'); return; }
    }
    else if (q.type === 'point') { setLam(q.lam); state.d = 0.25; state.L = 1; state.probe = q.m; state.lines = true; }
    else {
      var sh = q.show || {};
      if (sh.white || sh.filters) state.light = 'white'; else setLam(590);
      if (sh.mode) state.mode = sh.mode;
      state.d = 0.25; state.L = 1;
    }
    setScene('interf');
  });

  // ---------- 面板 ----------
  $('panelToggle').addEventListener('click', function () { panel.classList.toggle('collapsed'); });
  if (window.matchMedia('(max-width: 760px)').matches) panel.classList.add('collapsed');
  window.addEventListener('keydown', function (e) {
    var tg = e.target.tagName;
    if (tg === 'INPUT' || tg === 'SELECT' || tg === 'BUTTON' || tg === 'TEXTAREA') return;
    if (e.code === 'Space' && state.scene === 'interf') { e.preventDefault(); togglePause(); }
    if (state.scene === 'measure' && (e.code === 'ArrowLeft' || e.code === 'ArrowRight')) {
      e.preventDefault(); moveR((e.code === 'ArrowRight' ? 1 : -1) * (e.shiftKey ? 0.1 : 0.01));
    }
  });

  function syncUI() {
    var sc = state.scene;
    setSeg('scene', sc);
    qa('[data-for]').forEach(function (el) { el.hidden = el.dataset.for.split(' ').indexOf(sc) < 0; });
    qa('[data-mode-for]').forEach(function (el) { el.hidden = el.dataset.modeFor.split(' ').indexOf(state.mode) < 0; });
    $('hint').textContent = sc === 'interf' && (state.mode !== 'double' || state.light === 'white') ? '改变缝宽和 L，看衍射条纹的宽度' : HINTS[sc];
    if (sc === 'interf' && state.light === 'white') $('hint').textContent = '白光：各色光的条纹间距不同，叠加成彩色条纹';
    setSeg('light', state.light);
    setSeg('mode', state.mode);
    setSeg('view', state.view);
    setSeg('filter', state.filter);
    setSeg('dm', state.dM.toFixed(2));
    setSeg('lm', state.LM);
    $('lam').disabled = state.light === 'white';
    $('water').checked = state.water; $('lines').checked = state.lines; $('probeOn').checked = state.probe != null;
    $('tilt').checked = state.tilt; $('showRead').checked = state.showRead; $('helper').checked = state.helper;
    qa('.pause').forEach(function (b) { b.textContent = state.paused ? '▶ 继续' : '❚❚ 暂停'; });
    var q = state.quiz;
    if (q) {
      $('quizQ').textContent = q.prompt;
      qa('#quizOpts button').forEach(function (b) {
        b.disabled = state.answered;
        b.classList.toggle('on', state.answered && b.textContent === q.answer);
        b.classList.toggle('no', state.answered && b.textContent === state.choice && !state.correct);
      });
      $('quizMsg').innerHTML = !state.answered ? ''
        : '<b class="' + (state.correct ? 'ok">✓ 答对了' : 'bad">✗ 应选「' + q.answer + '」') + '</b>' + q.explain;
      $('nextQ').textContent = state.answered ? '下一题 →' : '换一题';
      $('showQ').hidden = !state.answered;
    }
  }

  // ---------- 读数 ----------
  var lastText = {};
  function setText(id, s) { if (lastText[id] !== s) { lastText[id] = s; $(id).textContent = s; } }
  function rows(list) {
    for (var k = 1; k <= 5; k++) {
      var r = list[k - 1] || ['', ''];
      setText('d' + k, r[0]); setText('r' + k, r[1]);
      $('d' + k).hidden = $('r' + k).hidden = !r[0];
    }
  }
  function lamText() {
    if (state.light === 'white') return '白光（约 400–700 nm）' + (state.water ? '，在水中各色光波长都变为 λ/n' : '');
    var s = 'λ = ' + Math.round(state.lam) + ' nm（' + S.colorName(state.lam) + '光）';
    return state.water ? s + '，水中 λ\' = λ/n = ' + Math.round(lamE()) + ' nm' : s;
  }

  function readInterf() {
    var L = state.L, d = state.d, lam = lamE(), white = state.light === 'white', list = [];
    var setup = 'L = ' + f(L) + ' m，' + (state.mode === 'single' ? '缝宽 a = ' + f(state.a) + ' mm' : 'd = ' + f(d) + ' mm');
    setText('rKind', MODES[state.mode] + (state.water ? ' · 水中' : ''));
    if (state.mode === 'double') {
      var dx = S.spacing(lam, d, L);
      setText('rName', white ? '白光干涉' : 'Δx = ' + f(dx, dx < 1 ? 3 : 2) + ' mm');
      setText('rTip', white ? '中央亮纹是白色（各色光光程差都为 0）；两侧是彩色条纹，内紫外红——波长越长，条纹间距越大。'
        : state.water ? '光在水中波长变短（λ\' = λ/n），条纹间距变小。'
          : '两缝发出的光是相干光：光程差为波长整数倍处振动加强（亮纹），为半波长奇数倍处振动减弱（暗纹）。');
      list.push(['条纹间距', white ? '红光 ' + f(S.spacing(S.lamIn(700, state.water), d, L), 2) + ' mm，紫光 ' + f(S.spacing(S.lamIn(400, state.water), d, L), 2) + ' mm'
        : 'Δx = Lλ/d = ' + f(L) + ' m × ' + Math.round(lam) + ' nm ÷ ' + f(d) + ' mm = ' + f(dx, 3) + ' mm']);
      list.push(['光', lamText()]);
      list.push(['装置', setup]);
      if (state.probe != null && !white) {
        var m = state.probe, fn = S.fringeName(m), x = m * dx;
        list.push(['P 点', 'Δr = ' + f(Math.abs(m) * lam / 1000, 2) + ' μm = ' + f(Math.abs(m), 2) + 'λ → ' + fn.text]);
        list.push(['P 的位置', '离中央亮纹 ' + f(Math.abs(x), 2) + ' mm' + (fn.kind === 'mid' ? '' : fn.kind === 'bright' ? '（Δr = kλ，加强）' : '（Δr = (k − ½)λ，减弱）')]);
      } else list.push(['亮纹位置', 'x = kΔx（k = 0, ±1, ±2…）']);
    } else {
      var a = state.mode === 'single' ? state.a : S.A_DOUBLE, cw = S.centralWidth(white ? S.lamIn(550, state.water) : lam, a, L);
      setText('rName', white ? '白光衍射' : '中央亮纹 ' + f(cw, cw < 10 ? 1 : 0) + ' mm');
      setText('rTip', state.mode === 'one'
        ? '只剩一条缝，没有两列相干光叠加，干涉条纹消失；这条缝很窄（' + S.A_DOUBLE + ' mm），衍射使光铺满一大片，中央亮纹很宽。'
        : '单缝衍射：中央亮纹最宽最亮，两侧条纹窄而暗、不等间距。缝越窄、波长越长、L 越大，中央亮纹越宽。');
      list.push(['中央亮纹', '宽度 2Lλ/a = ' + f(cw, 2) + ' mm（a 为缝宽）']);
      list.push(['光', lamText()]);
      list.push(['装置', state.mode === 'one' ? 'L = ' + f(L) + ' m，S₂ 被挡住，S₁ 宽 ' + S.A_DOUBLE + ' mm' : setup]);
      list.push(['对比', '双缝干涉：条纹等间距、亮度相近；单缝衍射：中央宽、两侧窄']);
    }
    rows(list);
  }

  function readMeasure() {
    var dx = dxM(), off = alignOff(), rec = state.rec, fl = state.filter;
    setText('rName', state.showRead ? '手轮 ' + S.wheelText(state.R) : '测量光的波长');
    setText('rKind', fl === 'unknown' ? '未知色光' : S.RIG.filters[fl].name);
    var aligned = Math.abs(off) < 0.06;
    var tip;
    if (rec.length === 0) tip = '转动手轮，使分划板中心刻线对齐某条亮纹的中央，点“记录读数”，把它记作第 1 条。';
    else if (rec.length === 1) tip = '沿同一方向继续转动手轮，移过若干条亮纹（条数多一些误差小），对齐第 n 条亮纹中央后再记录。';
    else tip = state.tilt ? '分划板中心刻线与条纹不平行，量出的间距 Δx 偏大，测得的波长偏大。转动测量头使两者平行再测。' : '测量完成：Δx = (a₂ − a₁)/(n − 1)，λ = dΔx/L。';
    if (state.helper && rec.length < 2) tip += aligned ? ' · 中心刻线已对齐亮纹中央' : Math.abs(off) > 0.4 ? ' · 现在对着暗纹附近' : '';
    setText('rTip', tip);
    var list = [['装置', 'd = ' + state.dM.toFixed(2) + ' mm，L = ' + state.LM + ' mm']];
    if (rec[0]) list.push(['第 1 条亮纹', 'a₁ = ' + rec[0].R.toFixed(3) + ' mm' + (Math.abs(rec[0].off) > 0.12 ? '（没对准亮纹中央）' : '')]);
    if (rec[1]) {
      var n = rec[1].n, dxm = Math.abs(rec[1].R - rec[0].R) / Math.max(1, n - 1);
      list.push(['第 ' + n + ' 条亮纹', 'a₂ = ' + rec[1].R.toFixed(3) + ' mm' + (Math.abs(rec[1].off) > 0.12 ? '（没对准亮纹中央）' : '')]);
      if (n < 2) list.push(['结果', '两次对齐的是同一条亮纹，请移过几条亮纹再记录']);
      else {
        var lamR = S.lamFrom(dxm, state.dM, state.LM / 1000), err = (lamR - state.lamM) / state.lamM * 100;
        list.push(['条纹间距', 'Δx = (a₂ − a₁)/(n − 1) = ' + f(Math.abs(rec[1].R - rec[0].R), 3) + '/' + (n - 1) + ' = ' + f(dxm, 4) + ' mm']);
        list.push(['波长', 'λ = dΔx/L = ' + Math.round(lamR) + ' nm（实际 ' + state.lamM + ' nm，误差 ' + (err >= 0 ? '+' : '') + f(err, 1) + '%）']);
      }
    } else if (rec[0] && state.helper) {
      list.push(['已移过', f(Math.abs(state.R - rec[0].R) * cosT() / dx, 1) + ' 个条纹间距']);
    }
    rows(list);
    $('record').textContent = rec.length >= 2 ? '↺ 重新记录' : rec.length ? '记录读数（第 n 条）' : '记录读数（第 1 条）';
  }

  function readQuiz() {
    var q = state.quiz, sc = state.score;
    setText('rName', !state.answered ? '判断练习' : state.correct ? '✓ 答对了' : '✗ 答错了');
    $('rName').className = !state.answered ? '' : state.correct ? 'ok' : 'bad';
    setText('rKind', '得分 ' + sc.ok + ' / ' + sc.n);
    setText('rTip', state.answered ? q.explain : q.prompt);
    rows([]);
  }

  // ---------- 尺寸与主循环 ----------
  function resize() { view.resize(stage.clientWidth, stage.clientHeight); }
  new ResizeObserver(resize).observe(stage);

  // 支持 ?scene=interf|measure|quiz；场景一 &light=red|green|violet|white、&lam=400~700（nm）、&mode=double|one|single、
  // &d=0.1~0.5（mm）、&a=0.05~0.5（mm，单缝）、&L=0.3~1.5（m）、&water=1、&view=wave|int、&lines=1、&p=（P 点光程差 / λ，none 不显示）；
  // 测量 &filter=red|green|unknown、&dm=0.2|0.25|0.3、&lm=600|700|800、&tilt=1、&read=1；练习 &q=change|calc|point|concept
  var qs = new URLSearchParams(location.search);
  function num(k, lo, hi) { var x = parseFloat(qs.get(k)); return isFinite(x) && x >= lo && x <= hi ? x : null; }
  var x;
  if (HINTS[qs.get('scene')]) state.scene = qs.get('scene');
  var lt = qs.get('light');
  if (lt === 'white' || S.LIGHTS[lt]) { state.light = lt; if (S.LIGHTS[lt]) state.lam = S.LIGHTS[lt].lam; }
  if ((x = num('lam', S.LAM_RANGE[0], S.LAM_RANGE[1])) != null) { state.lam = x; state.light = 'custom'; }
  if (MODES[qs.get('mode')]) state.mode = qs.get('mode');
  if ((x = num('d', S.D_RANGE[0], S.D_RANGE[1])) != null) state.d = x;
  if ((x = num('a', S.A_RANGE[0], S.A_RANGE[1])) != null) state.a = x;
  if ((x = num('L', S.L_RANGE[0], S.L_RANGE[1])) != null) state.L = x;
  if (qs.get('water') === '1') state.water = true;
  if (qs.get('view') === 'wave' || qs.get('view') === 'int') state.view = qs.get('view');
  if (qs.get('lines') === '1') state.lines = true;
  if (qs.get('p') === 'none') state.probe = null; else if ((x = num('p', -12, 12)) != null) state.probe = x;
  if (S.RIG.ds.indexOf(num('dm', 0, 1)) >= 0) state.dM = num('dm', 0, 1);
  if (S.RIG.Ls.indexOf(num('lm', 0, 2000)) >= 0) state.LM = num('lm', 0, 2000);
  if (qs.get('tilt') === '1') state.tilt = true;
  if (qs.get('read') === '1') state.showRead = true;
  setFilter(qs.get('filter') === 'green' || qs.get('filter') === 'unknown' ? qs.get('filter') : 'red');
  if (S.TYPES.indexOf(qs.get('q')) >= 0) state.quizOnly = qs.get('q');

  resize();
  setScene(state.scene);

  var lastT = performance.now();
  function frame(now) {
    var dt = Math.min((now - lastT) / 1000, 0.1);
    lastT = now;
    if (!state.paused) state.t += dt * 0.8;
    var sc = state.scene;
    sliders.forEach(function (s) { if (document.activeElement !== s.el) s.el.value = s.get(); });
    setText('lamOut', Math.round(state.lam) + ' nm');
    setText('dOut', state.d.toFixed(2) + ' mm');
    setText('aOut', state.a.toFixed(2) + ' mm');
    setText('LOut', state.L.toFixed(2) + ' m');

    if (sc === 'interf') {
      view.drawInterf({ lam: state.lam, white: state.light === 'white', water: state.water, mode: state.mode, d: state.d, a: state.a, L: state.L,
        view: state.view, lines: state.lines, probe: state.probe, t: state.t });
      readInterf();
    } else if (sc === 'measure') {
      var rec = state.rec;
      view.drawMeasure({ lam: state.lamM, d: state.dM, L: state.LM, R: state.R, C: state.C, tilt: state.tilt ? S.RIG.tilt : 0,
        filterName: state.filter === 'unknown' ? '滤光片（?）' : '滤光片',
        reading: state.showRead ? S.wheelText(state.R) : '',
        passed: state.helper && rec.length === 1 ? Math.round(Math.abs(state.R - rec[0].R) * cosT() / dxM()) : null });
      readMeasure();
    } else {
      view.drawQuiz(state.quiz, state.answered, { quizH: $('quizBar').offsetHeight });
      readQuiz();
    }
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // 调试用
  window.__model = {
    state: state, setScene: setScene, newQuiz: newQuiz, syncUI: syncUI,
    setLam: function (l) { state.lam = S.clamp(l, S.LAM_RANGE[0], S.LAM_RANGE[1]); state.light = 'custom'; syncUI(); },
    setR: function (r) { state.R = S.clamp(r, S.WHEEL[0], S.WHEEL[1]); },
    alignTo: function (k) { state.R = state.C + k * dxM() / cosT(); }
  };
})();
