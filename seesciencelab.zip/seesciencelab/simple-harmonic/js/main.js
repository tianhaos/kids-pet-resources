(function () {
  var S = window.SHM, D = window.ShmDraw, f = S.f, DEG = Math.PI / 180;
  var $ = function (id) { return document.getElementById(id); };
  var qa = function (sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); };
  var NAME = '简谐运动与单摆';

  var GS = {
    earth: { g: 9.8, name: '地球表面 g = 9.8 m/s²' }, moon: { g: 1.62, name: '月球表面 g = 1.62 m/s²' },
    mars: { g: 3.71, name: '火星表面 g = 3.71 m/s²' }, jupiter: { g: 24.8, name: '木星“表面” g = 24.8 m/s²' }
  };
  var state = {
    scene: 'spring',
    slows: { spring: 1, pendulum: 1, measure: 1 },
    t: { spring: 0, pendulum: 0 }, paused: false, dragging: false,
    // ① 弹簧振子（x0 为释放位置，m）
    k: 20, m: 0.5, x0: 0.06, v: true, F: true, E: true, ref: false, strobe: false, axis: 'down',
    // ② 单摆（th0 带符号，rad）
    L: 1.0, th0: 10 * DEG, gk: 'earth', ghost: true, forces: true, vel: false,
    // ③ 测 g：trials 为原始测量，按处理方式实时换算成表格
    l: 0.80, trials: [], radius: true, miscount: false, anim: 'fast', meas: null, last: -1
  };
  var ANIM = { real: 1, fast: 10 };
  var sp = null, pd = null;

  var HINTS = {
    spring: '拖动振子到某处松手，它就在平衡位置 O 两侧往复振动',
    pendulum: '拖动摆球改变摆角；摆长、g 和摆角不同，周期怎样变？',
    measure: '改变摆线长，测几组 30 次全振动的时间，作 T²-L 图像求 g'
  };

  var stage = $('stage'), panel = $('panel'), cv = $('view');
  var view = D.View(cv);
  function setSeg(attr, val) { qa('[data-' + attr + ']').forEach(function (b) { b.classList.toggle('on', b.dataset[attr] === String(val)); }); }

  function rebuildSpring() { sp = S.spring(state.k, state.m, state.x0); state.t.spring = 0; }
  function rebuildPend() { pd = S.pendulum(state.L, GS[state.gk].g, state.th0); state.t.pendulum = 0; }
  function rows() {
    return state.trials.map(function (tr) { return S.row(tr, { radius: state.radius, miscount: state.miscount }); });
  }
  function fitRows(rs) { return S.fit(rs.map(function (r) { return [r.L, r.T2]; })); }

  // ---------- 测量 ----------
  function startMeasure() {
    if (state.meas) return;
    var tr = S.trial(state.l, state.trials.length);
    if (state.anim === 'skip') { addTrial(tr); return; }
    state.meas = { tr: tr, t: 0 };
    syncUI();
    Analytics.track(NAME, '测量', (state.l * 100).toFixed(0) + ' cm');
  }
  function addTrial(tr) { state.trials.push(tr); state.last = state.trials.length - 1; state.meas = null; syncUI(); }
  function autoMeasure() {
    state.meas = null;
    [0.50, 0.60, 0.70, 0.80, 0.90, 1.00].forEach(function (l) { state.trials.push(S.trial(l, state.trials.length)); });
    state.last = state.trials.length - 1; syncUI();
    Analytics.track(NAME, '一键测 6 组', '');
  }
  // 测量动画：从 5° 由静止释放，摆球第一次经过最低点（T/4）时开始计时，完成 30 次全振动后停表
  function measView() {
    var m = state.meas;
    if (!m) return { th: 0, elapsed: 0, n: 0, timing: false };
    var T = m.tr.T, th = S.MEAS_TH * Math.cos(2 * Math.PI * m.t / T), e = Math.max(0, m.t - T / 4);
    return { th: th, elapsed: Math.min(e, S.N_OSC * T), n: Math.min(S.N_OSC, Math.floor(e / T + 1e-9)), timing: m.t > T / 4 };
  }

  // ---------- 控件 ----------
  qa('[data-scene]').forEach(function (b) {
    b.addEventListener('click', function () { setScene(b.dataset.scene); Analytics.track(NAME, '场景', b.textContent); });
  });
  function setScene(sc) { state.scene = sc; state.paused = false; syncUI(); }
  qa('[data-slow]').forEach(function (b) {
    b.addEventListener('click', function () { state.slows[state.scene] = parseFloat(b.dataset.slow); syncUI(); Analytics.track(NAME, '播放速度', b.textContent); });
  });
  qa('[data-axis]').forEach(function (b) {
    b.addEventListener('click', function () { state.axis = b.dataset.axis; syncUI(); Analytics.track(NAME, '图像方向', b.textContent); });
  });
  qa('[data-g]').forEach(function (b) {
    b.addEventListener('click', function () { state.gk = b.dataset.g; rebuildPend(); syncUI(); Analytics.track(NAME, '重力加速度', b.textContent); });
  });
  qa('[data-anim]').forEach(function (b) {
    b.addEventListener('click', function () { state.anim = b.dataset.anim; syncUI(); });
  });
  function slider(id, read, after, track) {
    var el = $(id);
    el.addEventListener('input', function () { read(parseFloat(el.value)); after(); syncUI(); });
    el.addEventListener('change', function () { Analytics.track(NAME, '滑块', track); });
  }
  slider('k', function (v) { state.k = v; }, rebuildSpring, '劲度系数');
  slider('mass', function (v) { state.m = v; }, rebuildSpring, '质量');
  slider('amp', function (v) { state.x0 = (state.x0 < 0 ? -1 : 1) * v / 100; }, rebuildSpring, '振幅');
  slider('len', function (v) { state.L = v; }, rebuildPend, '摆长');
  slider('ang', function (v) { state.th0 = (state.th0 < 0 ? -1 : 1) * v * DEG; }, rebuildPend, '摆角');
  slider('lline', function (v) { state.l = v / 100; }, function () {}, '摆线长');
  function check(id, key, after) {
    $(id).addEventListener('change', function () { state[key] = $(id).checked; if (after) after(); syncUI(); Analytics.track(NAME, '开关', id + '=' + state[key]); });
  }
  ['v', 'F', 'E', 'ref', 'strobe', 'ghost', 'forces', 'vel', 'radius', 'miscount'].forEach(function (k) { check('c_' + k, k); });

  qa('.play').forEach(function (b) { b.addEventListener('click', togglePause); });
  qa('.reset').forEach(function (b) { b.addEventListener('click', function () { state.t[state.scene] = 0; state.paused = false; syncUI(); }); });
  $('measure').addEventListener('click', startMeasure);
  $('auto').addEventListener('click', autoMeasure);
  $('clear').addEventListener('click', function () { state.trials = []; state.meas = null; state.last = -1; syncUI(); Analytics.track(NAME, '清空数据', ''); });
  function togglePause() { if (state.scene === 'measure') return; state.paused = !state.paused; syncUI(); }

  // 拖振子 / 摆球设定释放位置；其余位置点一下暂停/继续
  function pos(e) { var r = cv.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; }
  function dragTo(e) {
    var p = pos(e), h = view.lastHit();
    if (!h) return;
    if (h.kind === 'block') {
      var x = S.clamp((p[0] - h.cx) / h.s, -0.10, 0.10);
      if (Math.abs(x) < 0.01) x = x < 0 ? -0.01 : 0.01;
      state.x0 = Math.round(x * 200) / 200; rebuildSpring();
    } else {
      var th = Math.atan2(p[0] - h.ox, Math.max(1, p[1] - h.oy));
      th = S.clamp(Math.round(th / DEG), -60, 60);
      if (Math.abs(th) < 1) th = th < 0 ? -1 : 1;
      state.th0 = th * DEG; rebuildPend();
    }
    syncUI();
  }
  cv.addEventListener('pointerdown', function (e) {
    if (e.button !== 0) return;
    var p = pos(e), h = view.hitTest(p[0], p[1]);
    if (h && (h.kind === 'block' || h.kind === 'bob')) {
      state.dragging = true; cv.setPointerCapture(e.pointerId); dragTo(e); return;
    }
    togglePause();
  });
  cv.addEventListener('pointermove', function (e) {
    if (state.dragging) dragTo(e);
    else { var p = pos(e), h = view.hitTest(p[0], p[1]); cv.style.cursor = h ? 'grab' : 'default'; }
  });
  cv.addEventListener('pointerup', function () {
    if (!state.dragging) return;
    state.dragging = false; state.paused = false; state.t[state.scene] = 0; syncUI();
    Analytics.track(NAME, state.scene === 'spring' ? '拖动振子' : '拖动摆球', state.scene === 'spring' ? (state.x0 * 100).toFixed(1) + ' cm' : Math.round(state.th0 / DEG) + '°');
  });

  // ---------- 面板 ----------
  $('panelToggle').addEventListener('click', function () { panel.classList.toggle('collapsed'); });
  if (window.matchMedia('(max-width: 760px)').matches) panel.classList.add('collapsed');
  window.addEventListener('keydown', function (e) {
    var tg = e.target.tagName;
    if (tg === 'INPUT' || tg === 'SELECT' || tg === 'BUTTON' || tg === 'TEXTAREA') return;
    if (e.code === 'Space') { e.preventDefault(); togglePause(); }
  });

  function syncUI() {
    var sc = state.scene;
    setSeg('scene', sc);
    qa('[data-for]').forEach(function (el) { el.hidden = el.dataset.for.split(' ').indexOf(sc) < 0; });
    $('hint').textContent = HINTS[sc];
    setSeg('slow', state.slows[sc]); setSeg('axis', state.axis); setSeg('g', state.gk); setSeg('anim', state.anim);
    $('k').value = state.k; $('kOut').textContent = state.k + ' N/m';
    $('mass').value = state.m; $('massOut').textContent = f(state.m, 2) + ' kg';
    $('amp').value = Math.abs(state.x0) * 100; $('ampOut').textContent = f(Math.abs(state.x0) * 100, 1) + ' cm';
    $('len').value = state.L; $('lenOut').textContent = f(state.L, 2) + ' m';
    $('ang').value = Math.abs(state.th0) / DEG; $('angOut').textContent = Math.round(Math.abs(state.th0) / DEG) + '°';
    $('lline').value = Math.round(state.l * 100); $('llineOut').textContent = (state.l * 100).toFixed(0) + ' cm';
    ['v', 'F', 'E', 'ref', 'strobe', 'ghost', 'forces', 'vel', 'radius', 'miscount'].forEach(function (k) { $('c_' + k).checked = state[k]; });
    qa('.play').forEach(function (b) { b.textContent = state.paused ? '▶ 继续' : '❚❚ 暂停'; });
    $('measure').disabled = !!state.meas; $('measure').textContent = state.meas ? '测量中…' : '▶ 开始测量';
    $('lline').disabled = !!state.meas;
    renderTable();
  }

  function renderTable() {
    var rs = rows(), lab = state.radius ? 'L' : 'l';
    var html = '<thead><tr><th>#</th><th>l / cm</th><th>t₃₀ / s</th><th>T / s</th><th>T² / s²</th><th>g（' + lab + '）</th></tr></thead><tbody>';
    if (!rs.length) html += '<tr><td colspan="6" class="muted">还没有数据</td></tr>';
    rs.forEach(function (r, i) {
      html += '<tr' + (i === state.last ? ' class="hl"' : '') + '><td>' + (i + 1) + '</td><td>' + (r.l * 100).toFixed(1) + '</td><td>' + r.t.toFixed(2)
        + '</td><td>' + r.T.toFixed(3) + '</td><td>' + r.T2.toFixed(3) + '</td><td>' + r.g.toFixed(2) + '</td></tr>';
    });
    $('table').innerHTML = html + '</tbody>';
  }

  // ---------- 读数 ----------
  var lastText = {};
  function setText(id, s) { if (lastText[id] !== s) { lastText[id] = s; $(id).textContent = s; } }
  function list(items) {
    for (var k = 1; k <= 5; k++) {
      var r = items[k - 1] || ['', ''];
      setText('d' + k, r[0]); setText('r' + k, r[1]);
      $('d' + k).hidden = $('r' + k).hidden = !r[0];
    }
  }
  function phiText(phi) { return phi > 0 ? 'π/2' : '−π/2'; }

  function readSpring() {
    var st = sp.at(state.t.spring), x = st.x;
    setText('rName', 'x = ' + f(sp.A * 100, 1) + ' sin(' + f(sp.w, 2) + 't ' + (sp.phi > 0 ? '+' : '−') + ' π/2) cm');
    var at = Math.abs(x) > sp.A * 0.97 ? '最大位移处' : Math.abs(x) < sp.A * 0.03 ? '平衡位置' : x * st.v > 0 ? '远离平衡位置' : '靠近平衡位置';
    setText('rKind', at);
    var tip = at === '平衡位置' ? '经过平衡位置：位移、回复力、加速度为零，速度最大，动能最大、势能最小。'
      : at === '最大位移处' ? '最大位移处：速度为零，回复力和加速度最大且指向平衡位置，势能最大。'
      : at === '远离平衡位置' ? '远离平衡位置：速度方向与回复力方向相反，振子做加速度增大的减速运动。'
      : '靠近平衡位置：速度方向与回复力方向相同，振子做加速度减小的加速运动。';
    setText('rTip', tip + '回复力 F = −kx。');
    list([
      ['周期', 'T = 2π√(m/k) = ' + f(sp.T, 3) + ' s'],
      ['频率', 'f = ' + f(sp.f, 3) + ' Hz，ω = ' + f(sp.w, 2) + ' rad/s'],
      ['位移', 'x = ' + f(x * 100, 2) + ' cm，t = ' + f(state.t.spring, 2) + ' s'],
      ['速度', 'v = ' + f(st.v, 3) + ' m/s'],
      ['回复力', 'F = ' + f(st.F, 3) + ' N，a = ' + f(st.a, 2) + ' m/s²']
    ]);
  }
  function readPend() {
    var st = pd.at(state.t.pendulum), d = Math.abs(state.th0) / DEG, err = (pd.T / pd.T0 - 1) * 100;
    setText('rName', '单摆 · L = ' + f(state.L, 2) + ' m，θ₀ = ' + Math.round(d) + '°');
    setText('rKind', d <= 5 ? '可看作简谐运动' : err < 1 ? '近似简谐运动' : '不再是简谐运动');
    setText('rTip', d <= 5 ? '摆角很小时 sinθ ≈ θ ≈ x/L，回复力 F = −(mg/L)x，单摆做简谐运动，周期 T = 2π√(L/g)，与振幅、摆球质量无关。'
      : '摆角较大时 sinθ < θ，回复力比 (mg/L)x 小，周期比 2π√(L/g) 略长（误差 ' + f(err, 2) + '%），振动图像也不再是严格的正弦曲线。');
    list([
      ['实际周期', 'T = ' + f(pd.T, 3) + ' s'],
      ['2π√(L/g)', 'T₀ = ' + f(pd.T0, 3) + ' s'],
      ['摆角', 'θ = ' + f(st.th / DEG, 1) + '°，x = ' + f(st.x * 100, 1) + ' cm'],
      ['速度', 'v = ' + f(st.v, 3) + ' m/s'],
      ['回复力', 'F回 / m = −g sinθ = ' + f(st.tan, 3) + ' N/kg']
    ]);
  }
  function readMeasure() {
    var rs = rows(), ft = fitRows(rs), m = state.meas, mv = measView();
    var mean = rs.length ? rs.reduce(function (a, r) { return a + r.g; }, 0) / rs.length : 0;
    setText('rName', '用单摆测重力加速度');
    setText('rKind', m ? (mv.timing ? '计时中' : '释放摆球') : rs.length + ' 组数据');
    var tip = m ? (mv.timing ? '摆球经过最低点时开始计时，数 ' + S.N_OSC + ' 次全振动后停表，T = t/' + S.N_OSC + '。'
      : '把摆球拉开一个小角度（不超过 5°）由静止释放，等摆动稳定、摆球经过最低点时再按下秒表。')
      : !state.radius ? '把摆线长当作摆长：每组算出的 g 都偏小，但 T²-l 图线只是平移，斜率不变，图像法求出的 g 不受影响。'
      : state.miscount ? '把 29 次全振动记成 30 次，测得的周期偏小，算出的 g 偏大。'
      : '由 T = 2π√(L/g) 得 T² = (4π²/g)L：T²-L 图像是过原点的直线，斜率 k = 4π²/g，所以 g = 4π²/k。';
    setText('rTip', tip);
    list([
      ['摆长', 'L = l + d/2 = ' + ((state.l + S.BALL_D / 2) * 100).toFixed(1) + ' cm'],
      ['图像法', ft ? 'g = 4π²/k = ' + f(4 * Math.PI * Math.PI / ft.k, 3) + ' m/s²' : '至少需要 2 组'],
      ['平均值', rs.length ? 'g = ' + f(mean, 3) + ' m/s²' : '—'],
      ['真实值', 'g = ' + S.G_TRUE.toFixed(2) + ' m/s²'],
      ['误差', ft ? f((4 * Math.PI * Math.PI / ft.k / S.G_TRUE - 1) * 100, 1) + '%（图像法）' : '—']
    ]);
  }

  // ---------- 尺寸与主循环 ----------
  function resize() { view.resize(stage.clientWidth, stage.clientHeight); }
  new ResizeObserver(resize).observe(stage);

  // 支持 ?scene=spring|pendulum|measure；弹簧振子 &k=5~80、&m=0.1~2（kg）、&A=−10~10（cm，负号表示从左侧释放）、
  // &axis=down|right、&show=v,f,e,ref,strobe；单摆 &L=0.2~2（m）、&th=−60~60（°）、&g=earth|moon|mars|jupiter、&ghost=0、&forces=0、&vel=1；
  // 测 g &l=40~120（cm）、&auto=1（直接测 6 组）、&radius=0、&miscount=1；通用 &slow=1|0.5|0.25、&t=（秒，停在该时刻）
  var qs = new URLSearchParams(location.search), x;
  if (HINTS[qs.get('scene')]) state.scene = qs.get('scene');
  x = parseFloat(qs.get('k')); if (x >= 5 && x <= 80) state.k = Math.round(x);
  x = parseFloat(qs.get('m')); if (x >= 0.1 && x <= 2) state.m = Math.round(x * 20) / 20;
  x = parseFloat(qs.get('A')); if (Math.abs(x) >= 1 && Math.abs(x) <= 10) state.x0 = Math.round(x * 2) / 200;
  if (qs.get('axis') === 'right' || qs.get('axis') === 'down') state.axis = qs.get('axis');
  if (qs.get('show') != null) {
    var sh = qs.get('show').split(',');
    state.v = sh.indexOf('v') >= 0; state.F = sh.indexOf('f') >= 0; state.E = sh.indexOf('e') >= 0;
    state.ref = sh.indexOf('ref') >= 0; state.strobe = sh.indexOf('strobe') >= 0;
  }
  x = parseFloat(qs.get('L')); if (x >= 0.2 && x <= 2) state.L = Math.round(x * 20) / 20;
  x = parseFloat(qs.get('th')); if (Math.abs(x) >= 1 && Math.abs(x) <= 60) state.th0 = Math.round(x) * DEG;
  if (GS[qs.get('g')]) state.gk = qs.get('g');
  if (qs.get('ghost') === '0') state.ghost = false;
  if (qs.get('forces') === '0') state.forces = false;
  if (qs.get('vel') === '1') state.vel = true;
  x = parseFloat(qs.get('l')); if (x >= 40 && x <= 120) state.l = Math.round(x) / 100;
  if (qs.get('radius') === '0') state.radius = false;
  if (qs.get('miscount') === '1') state.miscount = true;
  x = parseFloat(qs.get('slow')); if ([1, 0.5, 0.25].indexOf(x) >= 0) state.slows[state.scene] = x;

  rebuildSpring(); rebuildPend();
  if (qs.get('auto') === '1') autoMeasure();
  resize();
  setScene(state.scene);
  x = parseFloat(qs.get('t'));
  if (x > 0 && state.scene !== 'measure') { state.t[state.scene] = x; state.paused = true; syncUI(); }

  var lastT = performance.now();
  function frame(now) {
    var raw = Math.min((now - lastT) / 1000, 0.1), sc = state.scene;
    lastT = now;
    if (sc === 'measure') {
      if (state.meas) {
        state.meas.t += raw * ANIM[state.anim];
        if (state.meas.t >= state.meas.tr.T * (S.N_OSC + 0.25)) addTrial(state.meas.tr);
      }
      var rs = rows(), mv = measView();
      view.drawMeasure({ l: state.l, th: mv.th, elapsed: mv.elapsed, n: mv.n, timing: mv.timing, rows: rs, fit: fitRows(rs), radius: state.radius, last: state.last });
      readMeasure();
    } else {
      if (!state.paused && !state.dragging) state.t[sc] += raw * state.slows[sc];
      if (sc === 'spring') {
        view.drawSpring({ sp: sp, x0: state.x0, t: state.t.spring, v: state.v, F: state.F, E: state.E, ref: state.ref, strobe: state.strobe, axis: state.axis });
        readSpring();
      } else {
        view.drawPendulum({ p: pd, t: state.t.pendulum, ghost: state.ghost, forces: state.forces, vel: state.vel, gName: GS[state.gk].name });
        readPend();
      }
    }
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // 调试用
  window.__model = {
    state: state, setScene: setScene, syncUI: syncUI,
    setSpring: function (k, m, Acm) { state.k = k; state.m = m; if (Acm != null) state.x0 = Acm / 100; rebuildSpring(); syncUI(); },
    setPendulum: function (L, deg, gk) { state.L = L; if (deg != null) state.th0 = deg * DEG; if (gk) state.gk = gk; rebuildPend(); syncUI(); },
    setT: function (t) { if (state.scene !== 'measure') { state.t[state.scene] = t; state.paused = true; syncUI(); } },
    measure: startMeasure, auto: autoMeasure
  };
})();
