// 简谐运动计算：弹簧振子（解析解）、单摆（RK4 数值解与完全椭圆积分周期）、用单摆测重力加速度（带误差的测量数据与 T²-L 拟合）
// 单位一律 SI：m、s、kg、N、rad；位移向右为正，摆角从竖直方向量起、向右为正。不碰 DOM，便于 node 测试。
(function () {
  var PI = Math.PI;

  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
  function f(v, d) {
    d = d == null ? 2 : d;
    var s = (Math.abs(v) < 0.5 * Math.pow(10, -d) ? 0 : v).toFixed(d);
    return s.replace('-', '−');
  }

  // ---------- 弹簧振子 ----------
  // 劲度系数 k、振子质量 m，从 x0 处由静止释放：x = x0 cos ωt，写成 x = A sin(ωt + φ)，A = |x0|，φ = ±π/2
  function spring(k, m, x0) {
    var w = Math.sqrt(k / m), A = Math.abs(x0), T = 2 * PI / w;
    return {
      k: k, m: m, A: A, w: w, T: T, f: 1 / T, phi: x0 >= 0 ? PI / 2 : -PI / 2, E: 0.5 * k * A * A,
      at: function (t) {
        var x = x0 * Math.cos(w * t), v = -x0 * w * Math.sin(w * t);
        return { x: x, v: v, a: -w * w * x, F: -k * x, Ek: 0.5 * m * v * v, Ep: 0.5 * k * x * x };
      }
    };
  }

  // ---------- 单摆 ----------
  // 算术几何平均：完全椭圆积分 K(k) = π / (2·AGM(1, √(1 − k²)))
  function agm(a, b) {
    for (var i = 0; i < 30 && Math.abs(a - b) > 1e-15; i++) { var c = (a + b) / 2; b = Math.sqrt(a * b); a = c; }
    return a;
  }
  function T0(L, g) { return 2 * PI * Math.sqrt(L / g); }
  // 任意振幅 θ0 的准确周期：T = T0 / AGM(1, cos(θ0/2))
  function period(L, g, th0) { return T0(L, g) / agm(1, Math.cos(Math.abs(th0) / 2)); }

  // 从 θ0 由静止释放：θ'' = −(g/L) sinθ，用 RK4 积分一个周期存表，之后按周期性插值
  var N_TAB = 2400;
  function pendulum(L, g, th0) {
    var T = period(L, g, th0), w0 = Math.sqrt(g / L), h = T / N_TAB;
    var th = new Float64Array(N_TAB + 1), om = new Float64Array(N_TAB + 1), q = th0, p = 0;
    function acc(x) { return -(g / L) * Math.sin(x); }
    th[0] = q; om[0] = p;
    for (var i = 1; i <= N_TAB; i++) {
      var k1q = p, k1p = acc(q);
      var k2q = p + h / 2 * k1p, k2p = acc(q + h / 2 * k1q);
      var k3q = p + h / 2 * k2p, k3p = acc(q + h / 2 * k2q);
      var k4q = p + h * k3p, k4p = acc(q + h * k3q);
      q += h / 6 * (k1q + 2 * k2q + 2 * k3q + k4q);
      p += h / 6 * (k1p + 2 * k2p + 2 * k3p + k4p);
      th[i] = q; om[i] = p;
    }
    function state(theta, omega) {
      var c = Math.cos(theta), s = Math.sin(theta);
      return {
        th: theta, om: omega, x: L * s, y: -L * c, v: L * omega,
        tan: -g * s,                       // 每千克的回复力（重力沿切线方向的分力），指向平衡位置
        rad: g * c,                        // 每千克重力沿摆线方向的分力
        tension: g * c + L * omega * omega, // 每千克的拉力
        ek: 0.5 * L * L * omega * omega, ep: g * L * (1 - c)   // 每千克的动能、势能
      };
    }
    return {
      L: L, g: g, th0: th0, T: T, T0: T0(L, g), w0: w0,
      at: function (t) {
        var u = ((t % T) + T) % T / h, i = Math.min(N_TAB - 1, Math.floor(u)), r = u - i;
        return state(th[i] + (th[i + 1] - th[i]) * r, om[i] + (om[i + 1] - om[i]) * r);
      },
      // 小角度近似（理想简谐运动）θ = θ0 cos(√(g/L) t)
      ideal: function (t) { return state(th0 * Math.cos(w0 * t), -th0 * w0 * Math.sin(w0 * t)); }
    };
  }

  // ---------- 用单摆测重力加速度 ----------
  var G_TRUE = 9.80, BALL_D = 0.0200, N_OSC = 30, MEAS_TH = 5 * PI / 180;
  // 固定种子的伪随机数，保证同一组的“读数误差”每次一样
  function rand(seed) {
    var a = (seed * 2654435761) >>> 0;
    return function () {
      a = (a + 0x6D2B79F5) >>> 0;
      var t = a;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  // 第 idx 次测量：摆线长 l（m），秒表记录 30 次全振动的时间；开始、停止各有一次按表反应误差（正态，标准差 0.08 s）
  function trial(l, idx) {
    var r = rand(idx + 1), L = l + BALL_D / 2, Tt = period(L, G_TRUE, MEAS_TH);
    var gauss = function () { return Math.sqrt(-2 * Math.log(1 - r())) * Math.cos(2 * PI * r()); };
    return { l: l, L: L, T: Tt, err: 0.08 * (gauss() - gauss()) };
  }
  // 按处理方式得到一行数据：radius 摆长是否加小球半径，miscount 把 29 次全振动记成 30 次
  function row(tr, opt) {
    var n = opt.miscount ? N_OSC - 1 : N_OSC;
    var t = Math.round((n * tr.T + tr.err) * 100) / 100;   // 电子秒表读到 0.01 s
    var L = opt.radius ? tr.L : tr.l, T = t / N_OSC;
    return { l: tr.l, L: L, t: t, T: T, T2: T * T, g: 4 * PI * PI * L / (T * T) };
  }
  // 最小二乘拟合 y = kx + b
  function fit(pts) {
    var n = pts.length;
    if (n < 2) return null;
    var sx = 0, sy = 0, sxx = 0, sxy = 0;
    pts.forEach(function (p) { sx += p[0]; sy += p[1]; sxx += p[0] * p[0]; sxy += p[0] * p[1]; });
    var d = n * sxx - sx * sx;
    if (Math.abs(d) < 1e-12) return null;
    var k = (n * sxy - sx * sy) / d;
    return { k: k, b: (sy - k * sx) / n };
  }

  window.SHM = {
    PI: PI, clamp: clamp, f: f,
    spring: spring, agm: agm, T0: T0, period: period, pendulum: pendulum,
    G_TRUE: G_TRUE, BALL_D: BALL_D, N_OSC: N_OSC, MEAS_TH: MEAS_TH,
    trial: trial, row: row, fit: fit
  };
})();
