// 2D 绘制：① 弹簧振子 + x-t 图像（t 轴向下与振子对齐，像频闪照片；或课本常见的 t 轴向右）、参考圆、能量柱
// ② 单摆（受力分解、小角度近似对比）+ x-t 图像 + 周期随摆角变化的曲线 ③ 用单摆测重力加速度（铁架台、米尺、秒表 + T²-L 图像）
// 屏幕坐标 y 向下；物理量在 shm.js 里是 SI 单位，这里只做换算
(function () {
  var S = window.SHM, f = S.f;
  var MUTED = '#8d99ab', TEXT = '#e6ebf2', GRID = 'rgba(141,153,171,.14)', LINE = '#4a5670';
  var GOLD = '#ffc94a', VEL = '#4fc3f7', FORCE = '#ff7a59', GREEN = '#7ee081', BLUE = '#6f86c9', GHOST = 'rgba(200,210,225,.45)';
  var FONT = '-apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", sans-serif';
  var DEG = Math.PI / 180;

  function font(px, w) { return (w ? w + ' ' : '') + px + 'px ' + FONT; }
  function label(ctx, s, x, y, o) {
    o = o || {};
    ctx.font = font(o.size || 12, o.bold ? 600 : null);
    ctx.textAlign = o.align || 'center'; ctx.textBaseline = o.base || 'middle';
    ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(5,7,13,.85)'; ctx.strokeText(s, x, y);
    ctx.fillStyle = o.color || TEXT; ctx.fillText(s, x, y);
  }
  function arrow(ctx, x1, y1, x2, y2, color, o) {
    o = o || {};
    var a = Math.atan2(y2 - y1, x2 - x1), len = Math.hypot(x2 - x1, y2 - y1), size = Math.min(o.size || 9, len * 0.6);
    if (len < 2) return;
    ctx.strokeStyle = ctx.fillStyle = color; ctx.lineWidth = o.width || 2.2; ctx.setLineDash(o.dash || []);
    ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2 - Math.cos(a) * size * 0.6, y2 - Math.sin(a) * size * 0.6); ctx.stroke();
    ctx.setLineDash([]);
    ctx.beginPath();
    ctx.moveTo(x2, y2);
    ctx.lineTo(x2 - size * Math.cos(a - 0.42), y2 - size * Math.sin(a - 0.42));
    ctx.lineTo(x2 - size * Math.cos(a + 0.42), y2 - size * Math.sin(a + 0.42));
    ctx.closePath(); ctx.fill();
  }
  function line(ctx, x1, y1, x2, y2, color, o) {
    o = o || {};
    ctx.strokeStyle = color; ctx.lineWidth = o.width || 1.2; ctx.setLineDash(o.dash || []);
    ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke(); ctx.setLineDash([]);
  }
  function dot(ctx, x, y, r, color) { ctx.fillStyle = color; ctx.beginPath(); ctx.arc(x, y, r, 0, 2 * Math.PI); ctx.fill(); }
  // 两端带箭头的标注线，文字放在中点外侧（nx, ny 为文字偏移）
  function dim(ctx, x1, y1, x2, y2, color, text, nx, ny) {
    var len = Math.hypot(x2 - x1, y2 - y1);
    if (len > 16) {
      var mx = (x1 + x2) / 2, my = (y1 + y2) / 2;
      arrow(ctx, mx, my, x1, y1, color, { width: 1, size: 6 }); arrow(ctx, mx, my, x2, y2, color, { width: 1, size: 6 });
    } else line(ctx, x1, y1, x2, y2, color);
    if (text) label(ctx, text, (x1 + x2) / 2 + (nx || 0), (y1 + y2) / 2 + (ny || 0), { size: 11, color: color });
  }
  function hatch(ctx, x1, y1, x2, y2, dir) {   // 墙面/天花板/地面的斜线阴影，dir 为阴影一侧的法向 [dx, dy]
    line(ctx, x1, y1, x2, y2, MUTED, { width: 1.6 });
    var len = Math.hypot(x2 - x1, y2 - y1), n = Math.floor(len / 9), ux = (x2 - x1) / len, uy = (y2 - y1) / len;
    for (var i = 0; i <= n; i++) {
      var px = x1 + ux * i * 9, py = y1 + uy * i * 9;
      line(ctx, px, py, px + dir[0] * 7 + ux * 5, py + dir[1] * 7 + uy * 5, 'rgba(141,153,171,.5)', { width: 1 });
    }
  }
  function niceStep(range, n) {
    var raw = range / n, p = Math.pow(10, Math.floor(Math.log10(raw))), m = raw / p;
    return (m < 1.5 ? 1 : m < 3.5 ? 2 : m < 7.5 ? 5 : 10) * p;
  }
  function dec(step) { return step >= 1 ? 0 : Math.min(3, Math.ceil(-Math.log10(step) - 1e-9)); }

  function View(canvas) {
    var ctx = canvas.getContext('2d'), W = 0, H = 0, dpr = 1, narrow = false;
    var hit = null;   // 当前可拖动对象 { kind, x, y, r, ... }，main.js 用来判断按下的位置
    function resize(w, h) {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      W = w; H = h; narrow = w < 640;
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
      canvas.style.width = w + 'px'; canvas.style.height = h + 'px';
    }
    function bg() {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      var g = ctx.createLinearGradient(0, 0, 0, H);
      g.addColorStop(0, '#04060c'); g.addColorStop(1, '#0a1120');
      ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
      hit = null;
    }
    function top0() { return narrow ? 50 : 44; }

    // 通用的直角坐标图：R 区域，o = { x0, x1, y0, y1, xl, yl, title, xs, ys }，返回 X(x)、Y(y)
    function axes(R, o) {
      var pl = 44, pr = 14, pt = o.title ? 26 : 12, pb = 28;
      var X = function (v) { return R.x + pl + (v - o.x0) / (o.x1 - o.x0) * (R.w - pl - pr); };
      var Y = function (v) { return R.y + R.h - pb - (v - o.y0) / (o.y1 - o.y0) * (R.h - pt - pb); };
      ctx.fillStyle = 'rgba(17,23,35,.55)'; ctx.fillRect(R.x, R.y, R.w, R.h);
      ctx.strokeStyle = LINE; ctx.lineWidth = 1; ctx.strokeRect(R.x + .5, R.y + .5, R.w - 1, R.h - 1);
      if (o.title) label(ctx, o.title, R.x + 10, R.y + 13, { align: 'left', size: 12, color: MUTED });
      var xs = o.xs || niceStep(o.x1 - o.x0, Math.max(3, Math.floor(R.w / 80))), ys = o.ys || niceStep(o.y1 - o.y0, Math.max(3, Math.floor(R.h / 50)));
      var v;
      for (v = Math.ceil(o.x0 / xs - 1e-9) * xs; v <= o.x1 + 1e-9; v += xs) {
        line(ctx, X(v), Y(o.y0), X(v), Y(o.y1), GRID);
        label(ctx, f(v, dec(xs)), X(v), Y(o.y0) + 11, { size: 10, color: MUTED });
      }
      for (v = Math.ceil(o.y0 / ys - 1e-9) * ys; v <= o.y1 + 1e-9; v += ys) {
        line(ctx, X(o.x0), Y(v), X(o.x1), Y(v), GRID);
        label(ctx, f(v, dec(ys)), X(o.x0) - 6, Y(v), { size: 10, color: MUTED, align: 'right' });
      }
      var y0 = o.y0 <= 0 && o.y1 >= 0 ? 0 : o.y0;
      arrow(ctx, X(o.x0), Y(y0), X(o.x1) + 8, Y(y0), MUTED, { width: 1, size: 6 });
      arrow(ctx, X(o.x0), Y(o.y0), X(o.x0), Y(o.y1) - 8, MUTED, { width: 1, size: 6 });
      if (o.xl) label(ctx, o.xl, X(o.x1) + 4, Y(y0) - 10, { size: 11, color: MUTED, align: 'right' });
      if (o.yl) label(ctx, o.yl, X(o.x0) + 6, Y(o.y1) - 2, { size: 11, color: MUTED, align: 'left' });
      return { X: X, Y: Y };
    }
    function curve(fn, t0, t1, n, color, o) {
      o = o || {};
      ctx.strokeStyle = color; ctx.lineWidth = o.width || 2; ctx.setLineDash(o.dash || []);
      ctx.beginPath();
      for (var i = 0; i <= n; i++) { var p = fn(t0 + (t1 - t0) * i / n); if (i) ctx.lineTo(p[0], p[1]); else ctx.moveTo(p[0], p[1]); }
      ctx.stroke(); ctx.setLineDash([]);
    }
    function bars(x, y, h, items) {   // 竖直能量柱：items = [{ name, v, max, color }]，底边在 y
      var bw = 22, gap = 12;
      label(ctx, '能量', x, y - h - 12, { align: 'left', size: 11, color: MUTED });
      items.forEach(function (it, i) {
        var bx = x + i * (bw + gap), bh = it.max > 0 ? h * it.v / it.max : 0;
        ctx.fillStyle = 'rgba(141,153,171,.12)'; ctx.fillRect(bx, y - h, bw, h);
        ctx.fillStyle = it.color; ctx.fillRect(bx, y - bh, bw, bh);
        label(ctx, it.name, bx + bw / 2, y + 10, { size: 11, color: it.color });
      });
    }

    // ---------- ① 弹簧振子 ----------
    // o = { sp, x0, t, v, F, E, ref, strobe, axis }
    function drawSpring(o) {
      bg();
      var sp = o.sp, st = sp.at(o.t), AMAX = 0.10;
      var top = top0(), Htop = S.clamp(H * 0.42, 170, 380), trackY = top + Htop * 0.58;
      var cx = W / 2, s = Math.min(W * 0.3, Htop * 0.48) / AMAX;
      var BW = 46, BH = 34, bx = cx + st.x * s, by = trackY - BH / 2;
      var wallX = Math.max(10, cx - BW / 2 - AMAX * s - 50);

      // 参考圆：匀速圆周运动在直径上的投影就是简谐运动
      if (o.ref && sp.A > 0) {
        var R = sp.A * s, ang = sp.w * o.t + (o.x0 >= 0 ? 0 : Math.PI), px = cx + R * Math.cos(ang), py = by - R * Math.sin(ang);
        ctx.strokeStyle = 'rgba(201,167,255,.5)'; ctx.lineWidth = 1.2; ctx.setLineDash([4, 4]);
        ctx.beginPath(); ctx.arc(cx, by, R, 0, 2 * Math.PI); ctx.stroke(); ctx.setLineDash([]);
        line(ctx, cx, by, px, py, '#c9a7ff', { width: 1.4 });
        line(ctx, px, py, px, by, '#c9a7ff', { dash: [3, 3] });
        dot(ctx, px, py, 5, '#c9a7ff');
        // x = A sin(ωt + φ)：相位从竖直向下的半径起逆时针量
        var ph = (((ang + Math.PI / 2) % (2 * Math.PI)) + 2 * Math.PI) % (2 * Math.PI), ra = Math.min(24, R * 0.45);
        line(ctx, cx, by, cx, by + R, 'rgba(201,167,255,.5)', { dash: [2, 3] });
        ctx.strokeStyle = '#c9a7ff'; ctx.lineWidth = 1; ctx.beginPath(); ctx.arc(cx, by, ra, Math.PI / 2, Math.PI / 2 - ph, true); ctx.stroke();
        label(ctx, '相位 ωt + φ', cx + (ra + 8) * Math.cos(Math.PI / 2 - ph / 2), by + (ra + 8) * Math.sin(Math.PI / 2 - ph / 2), { size: 11, color: '#c9a7ff', align: Math.cos(Math.PI / 2 - ph / 2) >= 0 ? 'left' : 'right' });
        label(ctx, '参考圆（半径 = 振幅 A）', cx, by - R - 12, { size: 11, color: '#c9a7ff' });
      }

      // 墙、光滑水平面、刻度
      hatch(ctx, wallX, trackY - BH - 28, wallX, trackY, [-1, 0]);
      hatch(ctx, wallX, trackY, W - 10, trackY, [0, 1]);
      label(ctx, '光滑水平面', W - 14, trackY - 10, { size: 11, color: MUTED, align: 'right' });
      var cm = AMAX * s / 10, stepCm = cm < 9 ? 2 : 1;
      for (var c = -10; c <= 10; c += stepCm) {
        var tx = cx + c * cm, big = c % (stepCm * 5) === 0 || c === 0;
        line(ctx, tx, trackY + 10, tx, trackY + (big ? 18 : 14), MUTED);
        if (c % 5 === 0) label(ctx, String(c).replace('-', '−'), tx, trackY + 27, { size: 10, color: MUTED });
      }
      label(ctx, 'x / cm', cx + AMAX * s + 18, trackY + 27, { size: 10, color: MUTED, align: 'left' });
      line(ctx, cx, trackY - BH - 40, cx, trackY + 8, MUTED, { dash: [4, 4] });
      label(ctx, 'O', cx, trackY - BH - 48, { size: 12, color: MUTED });
      [-1, 1].forEach(function (k) {
        var ax = cx + k * sp.A * s;
        line(ctx, ax, trackY - BH - 8, ax, trackY + 4, 'rgba(255,201,74,.35)', { dash: [2, 3] });
      });

      // 弹簧（固定圈数，随长度伸缩）
      var x1 = wallX, x2 = bx - BW / 2, n = 14, amp = 8, lead = 8;
      ctx.strokeStyle = '#b9c3d3'; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.moveTo(x1, by); ctx.lineTo(x1 + lead, by);
      for (var i = 0; i < n * 2; i++) ctx.lineTo(x1 + lead + (x2 - x1 - 2 * lead) * (i + 0.5) / (n * 2), by + (i % 2 ? amp : -amp));
      ctx.lineTo(x2 - lead, by); ctx.lineTo(x2, by); ctx.stroke();

      // 振子
      ctx.fillStyle = GOLD; ctx.fillRect(bx - BW / 2, trackY - BH, BW, BH);
      ctx.strokeStyle = '#a07a1f'; ctx.lineWidth = 1; ctx.strokeRect(bx - BW / 2 + .5, trackY - BH + .5, BW - 1, BH - 1);
      ctx.font = font(13, 600); ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#3a2a00'; ctx.fillText('m', bx, by);
      hit = { kind: 'block', x: bx, y: by, r: Math.max(BW, 44) / 2 + 10, cx: cx, s: s };

      var vmax = sp.A * sp.w, Fmax = sp.k * sp.A;
      if (o.v && vmax > 0 && Math.abs(st.v) > vmax * 0.02) {
        var lv = st.v / vmax * 70;
        arrow(ctx, bx, trackY - BH - 12, bx + lv, trackY - BH - 12, VEL);
        label(ctx, 'v', bx + lv + (lv > 0 ? 10 : -10), trackY - BH - 12, { color: VEL, bold: true });
      }
      if (o.F && Fmax > 0 && Math.abs(st.F) > Fmax * 0.02) {
        var lf = st.F / Fmax * 70, fy = trackY - BH - 30;
        arrow(ctx, bx, fy, bx + lf, fy, FORCE);
        label(ctx, 'F', bx + lf + (lf > 0 ? 10 : -10), fy, { color: FORCE, bold: true });
      }
      if (o.E) bars(14, trackY - BH - 44, Math.max(50, Math.min(150, trackY - BH - 44 - top - 22)), [
        { name: 'Ek', v: st.Ek, max: sp.E, color: VEL }, { name: 'Ep', v: st.Ep, max: sp.E, color: GREEN }, { name: 'E', v: sp.E, max: sp.E, color: GOLD }
      ]);

      // x-t 图像
      var gy0 = top + Htop + 14, gy1 = H - 52, gh = gy1 - gy0;
      var tWin = Math.max(6, 2.2 * sp.T), tOff = Math.max(0, o.t - tWin);
      var P, Rg;
      if (o.axis === 'down') {
        var pps = (gh - 38) / tWin, ty0 = gy0 + 26;
        P = function (t, x) { return [cx + x * s, ty0 + (t - tOff) * pps]; };
        ctx.fillStyle = 'rgba(233,226,204,.05)'; ctx.fillRect(cx - AMAX * s - 30, gy0, AMAX * s * 2 + 60, gh);
        label(ctx, 'x-t 图像：纸带匀速向下拉动，t 轴向下（顺时针转 90° 就是课本常见的图像）', cx, gy0 + 6, { size: 11, color: MUTED });
        arrow(ctx, cx - AMAX * s - 14, ty0, cx + AMAX * s + 22, ty0, MUTED, { width: 1, size: 6 });
        label(ctx, 'x', cx + AMAX * s + 22, ty0 - 9, { size: 11, color: MUTED });
        arrow(ctx, cx, ty0, cx, gy1 - 2, MUTED, { width: 1, size: 6 });
        label(ctx, 't / s', cx + 8, gy1 - 8, { size: 11, color: MUTED, align: 'left' });
        for (var tk = Math.ceil(tOff); tk <= tOff + tWin + 1e-9; tk++) {
          var yk = P(tk, 0)[1];
          line(ctx, cx - AMAX * s - 14, yk, cx + AMAX * s + 14, yk, GRID);
          if (tk) label(ctx, String(tk), cx - AMAX * s - 20, yk, { size: 10, color: MUTED, align: 'right' });
        }
        Rg = null;
      } else {
        var gx0 = narrow ? 44 : 60, gx1 = W - 24, gyc = (gy0 + gy1) / 2 + 6, ys = (gh / 2 - 24) / (AMAX * 1.1);
        var ppx = (gx1 - gx0) / tWin;
        P = function (t, x) { return [gx0 + (t - tOff) * ppx, gyc - x * ys]; };
        Rg = { x: gx0, y: gy0, w: gx1 - gx0, h: gh };
        ctx.fillStyle = 'rgba(17,23,35,.55)'; ctx.fillRect(gx0 - 40, gy0, gx1 - gx0 + 50, gh);
        label(ctx, 'x-t 图像（振动图像）', gx0 - 30, gy0 + 12, { size: 12, color: MUTED, align: 'left' });
        for (var tj = Math.ceil(tOff); tj <= tOff + tWin + 1e-9; tj++) {
          var xj = P(tj, 0)[0];
          line(ctx, xj, gyc - AMAX * 1.1 * ys, xj, gyc + AMAX * 1.1 * ys, GRID);
          label(ctx, String(tj), xj, gyc + AMAX * 1.1 * ys + 10, { size: 10, color: MUTED });
        }
        [-10, -5, 5, 10].forEach(function (c) {
          var yc = gyc - c / 100 * ys;
          line(ctx, gx0, yc, gx1, yc, GRID);
          label(ctx, String(c).replace('-', '−'), gx0 - 6, yc, { size: 10, color: MUTED, align: 'right' });
        });
        arrow(ctx, gx0, gyc, gx1 + 10, gyc, MUTED, { width: 1, size: 6 });
        arrow(ctx, gx0, gyc + AMAX * 1.1 * ys, gx0, gyc - AMAX * 1.1 * ys - 8, MUTED, { width: 1, size: 6 });
        label(ctx, 't / s', gx1 + 8, gyc - 10, { size: 11, color: MUTED, align: 'right' });
        label(ctx, 'x / cm', gx0 + 6, gyc - AMAX * 1.1 * ys - 6, { size: 11, color: MUTED, align: 'left' });
      }
      var fx = function (t) { return P(t, sp.at(t).x); };
      if (o.strobe) {
        var dS = sp.T > 1.2 ? 0.1 : 0.05;
        curve(fx, tOff, o.t, 400, 'rgba(255,201,74,.25)', { width: 1 });
        for (var ts = Math.ceil(tOff / dS - 1e-9) * dS; ts <= o.t + 1e-9; ts += dS) {
          var q = fx(ts);
          ctx.fillStyle = GOLD;
          if (o.axis === 'down') ctx.fillRect(q[0] - 6, q[1] - 2.5, 12, 5); else ctx.fillRect(q[0] - 2.5, q[1] - 6, 5, 12);
        }
      } else curve(fx, tOff, o.t, Math.max(40, Math.ceil(400 * (o.t - tOff) / tWin)), GOLD);
      // 周期、振幅标注（第一个周期画完后出现）
      if (o.t >= sp.T && tOff < 1e-9 && sp.A > 0.004) {
        var xp = o.x0, a1 = P(0, xp), a2 = P(sp.T, xp);
        if (o.axis === 'down') {
          var off = (xp >= 0 ? 1 : -1) * 22;
          dim(ctx, a1[0] + off, a1[1], a2[0] + off, a2[1], VEL, 'T', (xp >= 0 ? 10 : -10), 0);
        } else {
          var offy = (xp >= 0 ? -1 : 1) * 12;
          dim(ctx, a1[0], a1[1] + offy, a2[0], a2[1] + offy, VEL, 'T = ' + f(sp.T) + ' s', 0, xp >= 0 ? -10 : 10);
          var z = P(sp.T / 2, 0);
          dim(ctx, z[0] + 14, z[1], z[0] + 14, P(sp.T / 2, -xp)[1], GREEN, 'A', 12, 0);
        }
      }
      var pen = fx(o.t);
      if (o.axis === 'down') line(ctx, bx, trackY + 2, pen[0], pen[1], 'rgba(255,201,74,.4)', { dash: [3, 4] });
      dot(ctx, pen[0], pen[1], 4.5, GOLD);
      return Rg;
    }

    // ---------- ② 单摆 ----------
    function layoutTwo() {   // 返回摆所在区域与右侧/下方图像区域
      var top = top0(), bottom = 52;
      if (W >= 700 && W > H * 0.9) {
        var pw = Math.round(W * 0.46);
        return { A: { x: 0, y: top, w: pw, h: H - top - bottom }, G: { x: pw + 6, y: top + 4, w: W - pw - 20, h: H - top - bottom - 4 }, wide: true };
      }
      var ah = Math.round((H - top - bottom) * 0.48);
      return { A: { x: 0, y: top, w: W, h: ah }, G: { x: 12, y: top + ah + 6, w: W - 24, h: H - top - bottom - ah - 6 }, wide: false };
    }
    // o = { p, t, ghost, forces, vel, gName }
    function drawPendulum(o) {
      bg();
      var p = o.p, st = p.at(o.t), Lmax = 2.0, LY = layoutTwo(), A = LY.A;
      var sinM = Math.max(Math.sin(Math.abs(p.th0)), 0.35);
      var s = Math.min((A.h - 70) / Lmax, (A.w - 40) / (2 * Lmax * sinM));
      var ox = A.x + A.w / 2, oy = A.y + 26, Lp = p.L * s;
      var P = function (th) { return [ox + Lp * Math.sin(th), oy + Lp * Math.cos(th)]; };

      hatch(ctx, ox - 50, oy, ox + 50, oy, [0, -1]);
      line(ctx, ox, oy, ox, oy + Lp + 26, MUTED, { dash: [4, 4] });
      // 摆动范围
      ctx.strokeStyle = 'rgba(255,201,74,.3)'; ctx.lineWidth = 1; ctx.setLineDash([2, 4]);
      ctx.beginPath(); ctx.arc(ox, oy, Lp, Math.PI / 2 - Math.abs(p.th0), Math.PI / 2 + Math.abs(p.th0)); ctx.stroke(); ctx.setLineDash([]);
      label(ctx, 'O', ox + (st.x > 0 ? -10 : 10), oy + Lp + 16, { size: 11, color: MUTED });
      label(ctx, 'L = ' + f(p.L) + ' m', ox - 8, oy + Lp * 0.45, { size: 11, color: MUTED, align: 'right' });

      if (o.ghost) {
        var gs = p.ideal(o.t), gq = P(gs.th);
        line(ctx, ox, oy, gq[0], gq[1], GHOST, { width: 1, dash: [3, 3] });
        ctx.strokeStyle = GHOST; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(gq[0], gq[1], 10, 0, 2 * Math.PI); ctx.stroke();
      }
      var b = P(st.th), r = 11;
      line(ctx, ox, oy, b[0], b[1], '#d8dee8', { width: 1.4 });
      if (Math.abs(st.th) > 2 * DEG) {
        var ra = Math.min(46, Lp * 0.35);
        ctx.strokeStyle = MUTED; ctx.lineWidth = 1; ctx.beginPath();
        ctx.arc(ox, oy, ra, Math.PI / 2, Math.PI / 2 - st.th, st.th > 0); ctx.stroke();
        label(ctx, 'θ', ox + (ra + 10) * Math.sin(st.th / 2), oy + (ra + 10) * Math.cos(st.th / 2), { size: 12, color: MUTED });
      }
      // 水平位移 x
      if (Math.abs(st.x) * s > 10) {   // 水平位移画在最低点高度，避开受力箭头
        var xy = oy + Lp + r + 6;
        line(ctx, b[0], b[1] + r, b[0], xy + 4, 'rgba(255,201,74,.35)', { dash: [2, 3] });
        dim(ctx, ox, xy, b[0], xy, GOLD, 'x', 0, 10);
      }

      if (o.forces) {
        var k = 50 / p.g, gx = b[0], gy = b[1];
        var tg = [Math.cos(st.th), -Math.sin(st.th)];   // 切向单位向量（θ 增大方向），屏幕坐标
        var rd = [-Math.sin(st.th), -Math.cos(st.th)];  // 指向悬点
        var ft = st.tan * k, fr = st.rad * k;
        line(ctx, gx + tg[0] * ft, gy + tg[1] * ft, gx, gy + 50, 'rgba(126,224,129,.4)', { dash: [3, 3] });
        line(ctx, gx - rd[0] * fr, gy - rd[1] * fr, gx, gy + 50, 'rgba(126,224,129,.4)', { dash: [3, 3] });
        arrow(ctx, gx, gy, gx, gy + 50, GREEN); label(ctx, 'mg', gx + 14, gy + 54, { color: GREEN, size: 12, align: 'left' });
        arrow(ctx, gx, gy, gx - rd[0] * fr, gy - rd[1] * fr, MUTED, { width: 1.4, dash: [4, 3] });
        if (Math.abs(st.th) > 3 * DEG) label(ctx, 'mg cosθ', gx - rd[0] * fr + 10 * Math.sign(st.th || 1), gy - rd[1] * fr + 10, { size: 10, color: MUTED, align: st.th > 0 ? 'left' : 'right' });
        var tl = st.tension * k;
        arrow(ctx, gx, gy, gx + rd[0] * tl, gy + rd[1] * tl, VEL);
        label(ctx, 'F拉', gx + rd[0] * tl + (st.th >= 0 ? -14 : 14), gy + rd[1] * tl, { color: VEL, size: 12 });
        if (Math.abs(ft) > 3) {
          arrow(ctx, gx, gy, gx + tg[0] * ft, gy + tg[1] * ft, FORCE);
          label(ctx, 'F回 = mg sinθ', gx + tg[0] * ft + (ft > 0 ? 8 : -8), gy + tg[1] * ft - 12, { color: FORCE, size: 11, align: ft > 0 ? 'left' : 'right' });
        }
      }
      if (o.vel) {
        var vmax = p.L * Math.sqrt(2 * p.g * (1 - Math.cos(p.th0)) / p.L) || 1, lv = st.v / vmax * 60;
        if (Math.abs(lv) > 3) arrow(ctx, b[0], b[1], b[0] + Math.cos(st.th) * lv, b[1] - Math.sin(st.th) * lv, '#ffffff', { width: 1.8 });
      }
      dot(ctx, b[0], b[1], r, GOLD);
      ctx.strokeStyle = '#a07a1f'; ctx.lineWidth = 1; ctx.beginPath(); ctx.arc(b[0], b[1], r, 0, 2 * Math.PI); ctx.stroke();
      hit = { kind: 'bob', x: b[0], y: b[1], r: 26, ox: ox, oy: oy };
      label(ctx, o.gName, A.x + 14, A.y + 12, { size: 11, color: MUTED, align: 'left' });

      // 右侧/下方：x-t 图像 + 周期与摆角
      var G = LY.G, gh1 = Math.round(G.h * (LY.wide ? 0.6 : 0.58));
      var R1 = { x: G.x, y: G.y, w: G.w, h: gh1 - 6 }, R2 = { x: G.x, y: G.y + gh1, w: G.w, h: G.h - gh1 };
      var tWin = Math.max(8, 2.5 * p.T), tOff = Math.max(0, o.t - tWin), xa = Math.max(p.L * Math.sin(Math.abs(p.th0)), 0.005) * 100 * 1.5;
      var ax = axes(R1, { x0: tOff, x1: tOff + tWin, y0: -xa, y1: xa, xl: 't / s', yl: 'x / cm', title: 'x-t 图像（x 为摆球偏离平衡位置的水平位移）', xs: tWin > 12 ? 2 : 1 });
      var fx = function (t) { return [ax.X(t), ax.Y(p.at(t).x * 100)]; };
      if (o.ghost) curve(function (t) { return [ax.X(t), ax.Y(p.ideal(t).x * 100)]; }, tOff, o.t, 300, GHOST, { width: 1.4, dash: [5, 4] });
      curve(fx, tOff, o.t, 400, GOLD);
      var pen = fx(o.t); dot(ctx, pen[0], pen[1], 4, GOLD);
      if (o.t >= p.T && tOff < 1e-9) {
        var x0 = p.at(0).x * 100, sg = x0 >= 0 ? -1 : 1;
        dim(ctx, ax.X(0), ax.Y(x0) + sg * 10, ax.X(p.T), ax.Y(x0) + sg * 10, VEL, 'T = ' + f(p.T) + ' s', 0, sg * 10);
      }

      // 周期随摆角的变化 T/T0
      var a2 = axes(R2, { x0: 0, x1: 60, y0: 1, y1: 1.08, xl: 'θ₀ / °', yl: 'T / T₀', title: '振幅（最大摆角）对周期的影响：T₀ = 2π√(L/g)', xs: 10, ys: 0.02 });
      curve(function (d) { return [a2.X(d), a2.Y(1 / S.agm(1, Math.cos(d * DEG / 2)))]; }, 0, 60, 120, GOLD);
      line(ctx, a2.X(5), a2.Y(1), a2.X(5), a2.Y(1.08), 'rgba(126,224,129,.5)', { dash: [3, 3] });
      label(ctx, '5°', a2.X(5) + 4, a2.Y(1.07), { size: 10, color: GREEN, align: 'left' });
      var dg = Math.min(60, Math.abs(p.th0) / DEG), rt = p.T / p.T0, mk = [a2.X(dg), a2.Y(Math.min(rt, 1.08))];
      dot(ctx, mk[0], mk[1], 5, '#ffffff');
      label(ctx, 'θ₀ = ' + f(dg, 0) + '°：T/T₀ = ' + rt.toFixed(4), mk[0] + (dg > 40 ? -8 : 8), mk[1] - 12, { size: 11, align: dg > 40 ? 'right' : 'left' });
    }

    // ---------- ③ 用单摆测重力加速度 ----------
    // o = { l, th, elapsed, n, timing, rows, fit, radius, last }
    function drawMeasure(o) {
      bg();
      var LY = layoutTwo(), A = LY.A, Lmax = 1.25;
      var baseY = A.y + A.h - 12, s = (A.h - 70) / (Lmax + 0.12);
      var poleX = A.x + Math.max(28, A.w * 0.22), ox = A.x + A.w * (LY.wide ? 0.5 : 0.42), oy = A.y + 30;
      // 铁架台
      ctx.fillStyle = '#3a4458'; ctx.fillRect(poleX - 34, baseY - 8, 92, 8);
      ctx.fillStyle = '#8d99ab'; ctx.fillRect(poleX - 3, oy - 16, 6, baseY - 8 - oy + 16);
      ctx.fillRect(poleX - 3, oy - 3, ox - poleX + 12, 6);
      ctx.fillStyle = '#5c6880'; ctx.fillRect(poleX - 8, oy - 9, 16, 18); ctx.fillRect(ox - 7, oy - 7, 14, 14);
      var lp = o.l * s, rb = Math.max(S.BALL_D / 2 * s, 7), Lc = lp + rb, th = o.th || 0;
      var bx = ox + Lc * Math.sin(th), by = oy + Lc * Math.cos(th);
      line(ctx, ox, oy, bx - rb * Math.sin(th), by - rb * Math.cos(th), '#d8dee8', { width: 1.2 });
      dot(ctx, bx, by, rb, GOLD);
      line(ctx, ox, oy + 6, ox, oy + Lc + rb + 18, 'rgba(141,153,171,.35)', { dash: [3, 4] });
      // 米尺（从悬点量起）
      var rx = ox + 40;
      ctx.fillStyle = 'rgba(233,226,204,.12)'; ctx.fillRect(rx, oy, 16, Lmax * s);
      for (var c = 0; c <= Lmax * 100 + 1e-9; c += 1) {
        var yy = oy + c / 100 * s, big = c % 10 === 0;
        if (s / 100 < 2.2 && c % 5) continue;
        line(ctx, rx, yy, rx + (big ? 10 : c % 5 === 0 ? 7 : 4), yy, 'rgba(233,226,204,.6)', { width: 1 });
        if (big && c % 20 === 0) label(ctx, String(c), rx + 26, yy, { size: 9, color: MUTED, align: 'left' });
      }
      label(ctx, 'cm', rx + 26, oy + Lmax * s + 10, { size: 9, color: MUTED, align: 'left' });
      // 摆线长 l 与摆长 L
      var dx = ox - 26;
      dim(ctx, dx, oy, dx, oy + lp, o.radius ? MUTED : GOLD, 'l', -10, 0);
      dim(ctx, dx - 22, oy, dx - 22, oy + Lc, o.radius ? GOLD : MUTED, 'L', -10, 0);
      label(ctx, '摆线长 l = ' + (o.l * 100).toFixed(1) + ' cm', rx + 44, oy + Lc - 8, { size: 11, align: 'left' });
      label(ctx, '球径 d = ' + (S.BALL_D * 100).toFixed(2) + ' cm', rx + 44, oy + Lc + 8, { size: 11, color: MUTED, align: 'left' });
      // 秒表
      var swW = 128, swX = A.x + A.w - swW - 14, swY = A.y + 12;
      if (!LY.wide) { swX = A.x + A.w - swW - 10; swY = A.y + A.h - 70; }
      ctx.fillStyle = 'rgba(17,23,35,.9)'; ctx.fillRect(swX, swY, swW, 58);
      ctx.strokeStyle = o.timing ? GOLD : LINE; ctx.lineWidth = 1; ctx.strokeRect(swX + .5, swY + .5, swW - 1, 58);
      label(ctx, '秒表', swX + 8, swY + 11, { size: 10, color: MUTED, align: 'left' });
      ctx.font = '600 20px ' + 'ui-monospace, Menlo, Consolas, monospace'; ctx.fillStyle = o.timing ? GOLD : TEXT;
      ctx.textAlign = 'right'; ctx.textBaseline = 'middle'; ctx.fillText(o.elapsed.toFixed(2) + ' s', swX + swW - 8, swY + 28);
      label(ctx, '全振动 ' + o.n + ' / ' + S.N_OSC + ' 次', swX + swW - 8, swY + 48, { size: 11, color: MUTED, align: 'right' });

      // T²-L 图像
      var G = LY.G, rows = o.rows, xl = o.radius ? 'L / m' : 'l / m';
      var ax = axes(G, { x0: o.radius ? 0 : -0.05, x1: 1.3, y0: 0, y1: 5.5, xl: xl, yl: 'T² / s²', title: 'T² - ' + (o.radius ? 'L' : 'l') + ' 图像（每组测 ' + S.N_OSC + ' 次全振动）', xs: 0.2, ys: 1 });
      var kt = 4 * Math.PI * Math.PI / S.G_TRUE;
      line(ctx, ax.X(0), ax.Y(0), ax.X(1.3), ax.Y(kt * 1.3), 'rgba(141,153,171,.35)', { dash: [5, 5] });
      if (o.fit) {
        // 只用线长时把直线延长到与横轴相交，看出截距
        var ft = o.fit, xa = o.radius ? 0 : Math.max(-0.05, Math.min(0, -ft.b / ft.k)), xb = 1.3;
        line(ctx, ax.X(xa), ax.Y(ft.k * xa + ft.b), ax.X(xb), ax.Y(ft.k * xb + ft.b), VEL, { width: 1.8 });
        var gfit = 4 * Math.PI * Math.PI / ft.k;
        label(ctx, '斜率 k = ' + ft.k.toFixed(3) + ' s²/m', G.x + 56, G.y + 38, { size: 12, color: VEL, align: 'left' });
        label(ctx, 'g = 4π²/k = ' + gfit.toFixed(2) + ' m/s²', G.x + 56, G.y + 56, { size: 12, color: VEL, align: 'left', bold: true });
        label(ctx, '纵截距 ' + f(ft.b, 3) + ' s²', G.x + 56, G.y + 74, { size: 11, color: MUTED, align: 'left' });
      } else label(ctx, rows.length ? '再测一组就能拟合直线' : '选摆线长，点“开始测量”', G.x + 56, G.y + 38, { size: 12, color: MUTED, align: 'left' });
      rows.forEach(function (r, i) {
        var q = [ax.X(r.L), ax.Y(r.T2)];
        dot(ctx, q[0], q[1], i === o.last ? 5.5 : 4, i === o.last ? '#ffffff' : GOLD);
      });
      label(ctx, '灰色虚线：理论 T² = 4π²L/g（g = ' + S.G_TRUE.toFixed(2) + ' m/s²）', G.x + G.w - 10, G.y + G.h - 58, { size: 10, color: MUTED, align: 'right' });
    }

    function hitTest(x, y) { return hit && Math.hypot(x - hit.x, y - hit.y) <= hit.r ? hit : null; }
    function lastHit() { return hit; }
    return { resize: resize, drawSpring: drawSpring, drawPendulum: drawPendulum, drawMeasure: drawMeasure, hitTest: hitTest, lastHit: lastHit, isNarrow: function () { return narrow; } };
  }

  window.ShmDraw = { View: View };
})();
