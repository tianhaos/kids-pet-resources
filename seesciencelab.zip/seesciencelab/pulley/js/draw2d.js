/* 480×660（y=50…710） 示意坐标；各装置按可用行程选比例，同一装置的重物与绳端共用比例。 */
(function () {
  'use strict';
  const gold='#ffc94a', blue='#75d9f7',green='#8fe5ba', muted='#95a8b8';
  let geo={};
  function layout(s){const r=Pulley.solve(s),pixelsPerMeter={fixed:600,movable:300,tackle2:300,tackle3:200}[r.scene],y=565-r.h*pixelsPerMeter,x=r.rig.moving?(s.scene==='tackle3'?252:196):168;
    const endX=s.scene==='tackle2'||s.scene==='tackle3'?280:224;
    const endY=(r.rig.down?(s.scene==='fixed'?180:160):(s.scene==='movable'?500:510))+(r.rig.down?1:-1)*r.n*r.h*pixelsPerMeter;
    let segments=[];
    if(s.scene==='fixed')segments=[{x:168,top:100,bottom:y,id:1}];
    else if(s.scene==='tackle3')segments=[{x:168,top:100,bottom:y-48,id:1},{x:224,top:100,bottom:y,id:2},{x:280,top:endY,bottom:y,id:3}];
    else segments=[{x:168,top:75,bottom:y,id:1},{x:224,top:s.scene==='tackle2'?100:endY,bottom:y,id:2}];
    return {r,y,x,endX,endY,segments,pixelsPerMeter,loadY:y+(r.rig.moving?65:12)};
  }
  function render(canvas,state,hover){const rect=canvas.getBoundingClientRect(),dpr=Math.min(devicePixelRatio||1,2);if(canvas.width!==Math.round(rect.width*dpr)||canvas.height!==Math.round(rect.height*dpr)){canvas.width=Math.round(rect.width*dpr);canvas.height=Math.round(rect.height*dpr);}
    const c=canvas.getContext('2d'),mobile=matchMedia('(max-width:760px)').matches,top=mobile?148:(rect.width<825?152:100),bottom=155;
    const scale=Math.max(.15,Math.min((rect.width-16)/480,(rect.height-top-bottom)/660)),ox=(rect.width-480*scale)/2,oy=top+(rect.height-top-bottom-660*scale)/2-50*scale;
    const g=layout(state),{r,y,x,endX,endY}=g;geo={...g,scale,ox,oy,show:state.show};
    c.setTransform(dpr,0,0,dpr,0,0);c.fillStyle='#05070d';c.fillRect(0,0,rect.width,rect.height);
    // 淡蓝灰网格仅作空间参照，不代表真实长度刻度。
    c.beginPath();for(let gx=ox%32;gx<rect.width;gx+=32){c.moveTo(gx,top);c.lineTo(gx,rect.height-bottom);}for(let gy=top;gy<rect.height-bottom;gy+=32){c.moveTo(16,gy);c.lineTo(rect.width-16,gy);}c.strokeStyle='#101923';c.lineWidth=.6;c.stroke();
    c.translate(ox,oy);c.scale(scale,scale);
    function line(points,color,width=2,dash=[]){c.beginPath();points.forEach((p,i)=>i?c.lineTo(...p):c.moveTo(...p));c.strokeStyle=color;c.lineWidth=width;c.setLineDash(dash);c.stroke();c.setLineDash([]);}
    function text(t,px,py,color='#e5edf3',size=16,align='left'){c.fillStyle=color;c.font=`${size/scale}px -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif`;c.textAlign=align;c.fillText(t,px,py);}
    function box(bx,by,w,h,color,rad=7){c.beginPath();c.roundRect(bx,by,w,h,rad);c.fillStyle=color;c.fill();}
    function arrow(ax,ay,by,color){line([[ax,ay],[ax,by]],color,2);const d=by<ay?1:-1;line([[ax-5,by+d*8],[ax,by],[ax+5,by+d*8]],color,2);}
    function wheel(wx,wy,moving){const rr=28;c.save();c.translate(wx,wy);c.rotate((moving?(state.scene==='tackle3'?-2:-1):(state.scene==='tackle2'?2:1))*state.h*g.pixelsPerMeter/rr);const grad=c.createRadialGradient(-10,-10,3,0,0,rr);grad.addColorStop(0,'#c9d8e3');grad.addColorStop(.65,'#6c859a');grad.addColorStop(1,'#334c62');c.beginPath();c.arc(0,0,rr,0,Math.PI*2);c.fillStyle=grad;c.fill();c.strokeStyle='#bbc9d3';c.lineWidth=2;c.stroke();for(let i=0;i<4;i++){c.rotate(Math.PI/2);line([[8,0],[22,0]],'#273e51',4);}c.beginPath();c.arc(0,0,7,0,Math.PI*2);c.fillStyle='#182b3c';c.fill();c.restore();}
    // 工业起重架：固定横梁与立柱始终不动。
    box(57,59,344,16,'#425468',3);box(65,75,12,615,'#202e3f',3);box(382,75,12,615,'#202e3f',3);line([[58,60],[399,60]],'#8a9dae',1);
    for(const bx of [67,388]){box(bx-3,64,6,6,'#9aabb9',3);box(bx-3,694,6,6,'#71899e',3);}
    for(let i=0;i<12;i++)line([[65,95+i*46],[77,110+i*46]],'#3e5268',1);
    box(47,690,365,12,'#2a3b50',4);line([[35,705],[425,705]],'#263446',1);
    const fixed=state.scene==='fixed'||state.scene==='tackle2'||state.scene==='tackle3';const fx=state.scene==='tackle2'?252:196;
    if(fixed){line([[fx,75],[fx,100]],'#a8bac6',7);wheel(fx,100,false);}
    if(r.rig.moving){wheel(x,y,true);line([[x,y],[x,y+52]],'#adc2cf',6);line([[x-35,y+42],[x+35,y+42]],'#adc2cf',6);}
    // 一根连续的绳：固定端、上下半圆包络、自由端。
    c.beginPath();
    if(state.scene==='fixed'){c.moveTo(168,y+12);c.lineTo(168,100);c.arc(196,100,28,Math.PI,2*Math.PI);c.lineTo(224,endY);}
    else if(state.scene==='tackle3'){c.moveTo(168,y-48);c.lineTo(168,100);c.arc(196,100,28,Math.PI,2*Math.PI);c.lineTo(224,y);c.arc(252,y,28,Math.PI,0,true);c.lineTo(280,endY);}
    else {c.moveTo(168,75);c.lineTo(168,y);c.arc(196,y,28,Math.PI,0,true);if(state.scene==='tackle2'){c.lineTo(224,100);c.arc(252,100,28,Math.PI,2*Math.PI);c.lineTo(280,endY);}else c.lineTo(224,endY);}
    c.strokeStyle=gold;c.lineWidth=4;c.stroke();
    if(state.scene==='tackle3'){line([[168,y-48],[168,y+42],[252,y+42]],'#adc2cf',5);box(162,y-52,12,8,'#f2cd78',2);text('绳头在动架',159,y-67,muted,11,'center');}
    else if(r.rig.moving){box(160,69,16,10,gold,2);text('固定端',157,101,muted,11,'right');}
    if(fixed)text('定',fx+40,105,muted,11);
    if(r.rig.moving)text('动',x+40,y+15,muted,11);
    // 标注最短绳段也保持可点选，辅助箭头在绳旁。
    if(state.show)g.segments.forEach(seg=>{const mid=(seg.top+seg.bottom)/2,col=state.selected===seg.id||hover==='segment'+seg.id?blue:green;line([[seg.x-7,seg.top+7],[seg.x-7,seg.bottom-6]],col,2,[4,5]);arrow(seg.x-13,mid+17,mid-17,col);box(seg.x-39,mid-13,23,25,'#193c3d',8);text(String(seg.id),seg.x-27,mid+5/scale,col,12,'center');});
    const ly=g.loadY;
    if(r.rig.moving)line([[x,y+42],[x,ly]],'#bbc7cc',3);
    // 木箱与金属吊环，纹理随重物整体上升。
    if(hover==='load'||state.dragging==='load'){c.strokeStyle=blue;c.lineWidth=2/scale;c.beginPath();c.roundRect(x-49,ly-6,98,71,7);c.stroke();}
    box(x-43,ly,86,59,'#ad7b3d',4);box(x-39,ly+4,78,51,'#bf9554',2);
    line([[x-40,ly+20],[x+40,ly+20],[x+40,ly+39],[x-40,ly+39]],'#986e37',2);line([[x-32,ly+3],[x-32,ly+55],[x+32,ly+55],[x+32,ly+3]],'#e2b974',5);
    text(r.G.toFixed(0)+' N',x,ly+36,'#1d2730',13,'center');
    // 起点虚线仅代表位置参照。
    const base=565+(r.rig.moving?65:12)+59;
    line([[110,base],[325,base]],'#637184',1,[5,5]);
    if(state.h>.015){arrow(113,base,ly+59,blue);line([[107,base],[119,base]],blue,1);text('h',100,(base+ly+59)/2,blue,12,'right');}
    // 终端把手：方向与位移约束相符。
    const active=hover==='end'||state.dragging==='end';box(endX-18,endY-9,36,18,active?'#c9f5ff':blue,7);line([[endX-12,endY],[endX+12,endY]],'#215467',3);
    const dx=endX+41;arrow(dx,endY+(r.rig.down?-30:30),endY+(r.rig.down?28:-28),blue);text('F',dx+10,endY+5,blue,13);
    text('拖绳端',endX,endY+(r.rig.down?48:-42),blue,11,'center');

  }
  function hit(px,py){
    const g=geo;if(!g.r)return null;
    // 命中范围按屏幕像素保持至少44px，细绳与编号均可直接点选。
    if(Math.abs(px-g.endX)<Math.max(29,23/g.scale)&&Math.abs(py-g.endY)<Math.max(29,23/g.scale))return 'end';
    if(Math.abs(px-g.x)<Math.max(52,23/g.scale)&&py>g.loadY-4&&py<g.loadY+65)return 'load';
    const badges=g.segments.map(a=>({id:a.id,d:Math.hypot(px-a.x+27,py-(a.top+a.bottom)/2)})).sort((a,b)=>a.d-b.d);
    if(g.show&&badges[0]&&badges[0].d<22/g.scale)return 'segment'+badges[0].id;
    const ropes=g.segments.filter(a=>Math.abs(px-a.x)<22/g.scale&&py>a.top+12&&py<a.bottom-12).sort((a,b)=>Math.abs(px-a.x)-Math.abs(px-b.x));
    return ropes.length?'segment'+ropes[0].id:null;
  }
  window.PulleyDraw={render,hit,layout,get geometry(){return geo;}};
})();
