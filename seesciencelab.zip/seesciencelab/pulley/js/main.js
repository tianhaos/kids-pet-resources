(function () {
  'use strict';
  const $=id=>document.getElementById(id),canvas=$('pulley'),p=new URLSearchParams(location.search);
  const state={...Pulley.clean({scene:p.get('scene'),G:p.has('G')?p.get('G'):90,P:p.has('P')?p.get('P'):0,h:p.has('h')?p.get('h'):.2}),play:p.get('play')==='1',show:p.get('show')!=='0',records:[],selected:0,dragging:null};
  let drag=null,hover=null,last=0;
  function track(a,b){if(window.Analytics)Analytics.track('滑轮与滑轮组',a,b);}
  function update(){Object.assign(state,Pulley.clean(state));const r=Pulley.solve(state);
    for(const k of ['h','G','P']){$(k).value=state[k];$(k+'Out').textContent=k==='h'?state.h.toFixed(2)+' m':state[k].toFixed(0)+' N';}
    $('P').disabled=!r.rig.moving;$('POut').textContent=r.P.toFixed(0)+' N';
    $('sceneNote').textContent=r.rig.note;$('reading').textContent=r.F.toFixed(1)+' N';$('segments').textContent=r.n+' 段';$('weight').textContent=r.G.toFixed(0)+' N';$('moving').textContent=r.P.toFixed(0)+' N';$('height').textContent=state.h.toFixed(2)+' m';$('distance').textContent=r.s.toFixed(2)+' m，向'+(r.rig.down?'下':'上');$('efficiency').textContent=(r.eta*100).toFixed(1)+'%'+(state.h===0?'（理论值）':'');$('equation').textContent=`F = (${r.G.toFixed(0)} + ${r.P.toFixed(0)}) / ${r.n} = ${r.F.toFixed(1)} N`;
    $('work').textContent=`输入 ${r.input.toFixed(2)} J = 有用 ${r.useful.toFixed(2)} J + 抬动装置 ${r.extra.toFixed(2)} J`;$('play').textContent=state.play?'❚❚ 暂停':'▶ 演示提升';$('show').checked=state.show;
    $('stageScene').value=state.scene;$('stagePlay').textContent=state.play?'❚❚ 暂停':'▶ 演示';
    $('stagePlay').setAttribute('aria-label',state.play?'暂停演示':'演示提升');
    $('stageN').textContent=r.n+' 段';$('stageForce').textContent=r.F.toFixed(1)+' N';
    $('stageDistance').textContent=state.h.toFixed(2)+' / '+r.s.toFixed(2)+' m';
    $('stageMessage').textContent=state.selected?`第 ${state.selected} 段向上拉${r.rig.moving?'动装置':'重物'}，张力 ${r.F.toFixed(1)} N`:`重物 ↑ ${state.h.toFixed(2)} m，绳端${r.rig.down?'向下 ↓':'向上 ↑'} ${r.s.toFixed(2)} m · ${r.n}F = ${r.G.toFixed(0)}${r.P?' + '+r.P.toFixed(0):''} N`;
    document.querySelectorAll('[data-scene]').forEach(b=>{b.classList.toggle('on',b.dataset.scene===state.scene);b.setAttribute('aria-pressed',String(b.dataset.scene===state.scene));});
    $('records').innerHTML=state.records.length?'<table><thead><tr><th>n</th><th>G/G动 N</th><th>F/N</th><th>h/s m</th><th>η</th></tr></thead><tbody>'+state.records.map(a=>`<tr><td>${a.n}</td><td>${a.G}/${a.P}</td><td>${a.F.toFixed(1)}</td><td>${a.h.toFixed(2)}/${a.s.toFixed(2)}</td><td>${(a.eta*100).toFixed(0)}%</td></tr>`).join('')+'</tbody></table>':'<p class="note">同物重、同高度，切换装置记录比较。</p>';
  }
  function setScene(scene){if(!Object.hasOwn(Pulley.rigs,scene))return;state.scene=scene;state.h=0;state.play=false;state.selected=0;drag=null;state.dragging=null;update();track('切换装置',scene);}
  function setHeight(h){state.h=h;update();}
  document.querySelectorAll('[data-scene]').forEach(b=>b.onclick=()=>setScene(b.dataset.scene));
  for(const k of ['h','G','P']){$(k).oninput=e=>{state.play=false;state[k]=Number(e.target.value);update();};$(k).onchange=()=>track('调整'+k,String(state[k]));}
  $('play').onclick=()=>{if(state.h>=.6)state.h=0;state.play=!state.play;update();track('演示',state.play?'播放':'暂停');};$('stagePlay').onclick=()=>$('play').click();$('stageScene').onchange=e=>setScene(e.target.value);$('reset').onclick=()=>{state.play=false;setHeight(0);track('回起点',state.scene);};$('show').onchange=e=>{state.show=e.target.checked;state.selected=0;update();track('标注',String(state.show));};
  $('record').onclick=()=>{state.records.push(Pulley.solve(state));if(state.records.length>8)state.records.shift();update();track('记录',state.scene);};$('clear').onclick=()=>{state.records=[];update();};
  function link(){const q=new URLSearchParams({scene:state.scene,G:state.G,P:state.P,h:state.h.toFixed(3),show:state.show?'1':'0',play:'0'});return location.origin+location.pathname+'?'+q;}
  $('share').onclick=async()=>{const url=link();try{await navigator.clipboard.writeText(url);$('shareNote').textContent='已复制，打开时暂停并保留当前条件。';track('分享',state.scene);}catch{$('shareNote').textContent=url;}};
  function point(e){const r=canvas.getBoundingClientRect(),g=PulleyDraw.geometry;return{x:(e.clientX-r.left-g.ox)/g.scale,y:(e.clientY-r.top-g.oy)/g.scale};}
  canvas.onpointerdown=e=>{const a=point(e),hit=PulleyDraw.hit(a.x,a.y);if(!hit)return;if(hit.startsWith('segment')){state.selected=Number(hit.slice(7));state.show=true;update();track('探测绳段',String(state.selected));return;}state.play=false;drag={type:hit,y:a.y,h:state.h};state.dragging=hit;canvas.setPointerCapture(e.pointerId);update();e.preventDefault();};
  canvas.onpointermove=e=>{const a=point(e);hover=PulleyDraw.hit(a.x,a.y);canvas.style.cursor=drag?'grabbing':hover?(hover.startsWith('segment')?'pointer':'grab'):'default';if(!drag)return;const delta=(a.y-drag.y)/PulleyDraw.geometry.pixelsPerMeter;setHeight(drag.type==='load'?drag.h-delta:Pulley.fromEnd(state,drag.h,delta));};
  function release(){if(drag)track('画面拖动',drag.type);drag=null;state.dragging=null;canvas.style.cursor='default';}
  canvas.onpointerup=release;canvas.onpointercancel=release;canvas.onlostpointercapture=release;
  $('panelToggle').onclick=()=>{const closed=$('panel').classList.toggle('collapsed');$('panelToggle').setAttribute('aria-expanded',String(!closed));};if(matchMedia('(max-width:760px)').matches)$('panel').classList.add('collapsed');else $('panelToggle').setAttribute('aria-expanded','true');
  function frame(t){const dt=Math.min((t-last)/1000,.05);last=t;if(state.play){state.h=Math.min(.6,state.h+dt*.09);if(state.h>=.6)state.play=false;update();}PulleyDraw.render(canvas,state,hover);requestAnimationFrame(frame);}
  window.__model={state,setScene,setHeight,update,solve:()=>Pulley.solve(state),link};update();requestAnimationFrame(frame);
})();
