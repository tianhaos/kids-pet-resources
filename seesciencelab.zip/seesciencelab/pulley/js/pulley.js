/* 理想滑轮的准静态计算。力 N，距离 m，功 J。 */
(function () {
  'use strict';
  const rigs = {
    fixed: {name:'定滑轮', n:1, down:true, moving:false, note:'轴固定：改变拉力方向，不省力。'},
    movable: {name:'动滑轮', n:2, down:false, moving:true, note:'绳头固定横梁，两段绳向上拉动滑轮。'},
    tackle2: {name:'滑轮组 · 绳头在横梁', n:2, down:true, moving:true, note:'定滑轮把自由端转向下方；承重仍是两段。'},
    tackle3: {name:'滑轮组 · 绳头在动架', n:3, down:false, moving:true, note:'动架上的绳头也向上拉：两段绕动轮，一段拉动架。'}
  };
  function clamp(v,a,b,d){v=Number(v);return Number.isFinite(v)?Math.max(a,Math.min(b,v)):d;}
  function clean(s){return {scene:Object.hasOwn(rigs,s.scene)?s.scene:'tackle2',G:clamp(s.G,30,180,90),P:clamp(s.P,0,30,0),h:clamp(s.h,0,.6,.2)};}
  function solve(s){const c=clean(s),rig=rigs[c.scene],P=rig.moving?c.P:0,F=(c.G+P)/rig.n,d=rig.n*c.h;return {...c,rig,P,F,n:rig.n,s:d,input:F*d,useful:c.G*c.h,extra:P*c.h,eta:c.G/(c.G+P)};}
  // 自由端向下为正；绳长不变意味着自由端位移为 ±nΔh。
  function fromEnd(s,startH,delta){const r=solve(s);return clamp(startH+(r.rig.down?delta:-delta)/r.n,0,.6,0);}
  window.Pulley={rigs,clean,solve,fromEnd};
})();
