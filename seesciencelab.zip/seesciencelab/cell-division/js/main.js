(function () {
  'use strict';
  const $ = id => document.getElementById(id), p = new URLSearchParams(location.search);
  const scene = p.get('scene') === 'mitosis' ? 'mitosis' : 'meiosis';
  const state = { scene, t: Division.clamp(p.has('t') ? p.get('t') : 3, 0, Division.stages(scene).length - 1), n: p.get('n') === '3' ? 3 : 2, flip: p.get('flip') === '1', labels: p.get('labels') !== '0', play: p.get('play') === '1' };
  const track = (action, label) => { if (window.Analytics) Analytics.track('有丝分裂与减数分裂', action, String(label)); };
  function timeline() {
    $('periods').replaceChildren();
    Division.stages(state.scene).forEach((v, i) => {
      const b = document.createElement('button'); b.textContent = v[0]; b.onclick = () => { setT(i); if (mobile.matches) togglePanel(false, true); track('选择时期', v[0]); }; $('periods').append(b);
    });
    $('progress').max = Division.stages(state.scene).length - 1;
  }
  const canvas = $('division'), chart = $('chart'), panel = $('panel');
  const mobile = matchMedia('(max-width:760px)');
  let questionKey = '', selected = null, hovered = null, regions = [];
  function probe() {
    const point = regions.find(g => g.key === (hovered || selected));
    $('stage').classList.toggle('probing', !!point);
    $('probe').hidden = !point;
    canvas.style.cursor = hovered ? 'pointer' : '';
    if (point) {
      const type = point.replicated ? '两条姐妹染色单体相连' : '一条染色体含一个 DNA 分子';
      const label = `第 ${point.pair + 1} 对 · ${point.ori ? '父' : '母'}方来源 · ${type}`;
      if ($('probe').textContent !== label) $('probe').textContent = label;
    }
  }
  function draw() {
    regions = DivisionDraw.render(canvas, state, hovered || selected);
    probe();
    if ($('chartDetails').open) DivisionDraw.chart(chart, state);
  }
  function nearest(event) {
    const box = canvas.getBoundingClientRect();
    let target = null, min = Infinity;
    for (const g of regions) {
      const d = Math.hypot(g.x - event.clientX + box.left, g.y - event.clientY + box.top);
      if (d <= g.r && d < min) { target = g.key; min = d; }
    }
    return target;
  }
  canvas.addEventListener('pointermove', event => {
    if (event.pointerType === 'touch') return;
    const key = nearest(event);
    if (key !== hovered) { hovered = key; draw(); }
  });
  canvas.addEventListener('pointerleave', () => { if (hovered) { hovered = null; draw(); } });
  canvas.addEventListener('click', event => {
    const key = nearest(event);
    selected = key === selected ? null : key;
    if (key && state.play) setT(state.t);
    else draw();
    if (selected) track('点选染色体', state.scene);
  });
  function scrubChart(event) {
    setT(DivisionDraw.chartTime(chart, event.clientX - chart.getBoundingClientRect().left, state.scene));
  }
  chart.addEventListener('pointerdown', event => {
    if (event.button !== 0) return;
    chart.setPointerCapture(event.pointerId);
    scrubChart(event);
  });
  chart.addEventListener('pointermove', event => {
    if (chart.hasPointerCapture(event.pointerId)) scrubChart(event);
  });
  chart.addEventListener('pointerup', () => track('拖动曲线', state.t.toFixed(1)));
  $('chartDetails').addEventListener('toggle', draw);
  function update() {
    const s = Division.sample(state.scene, state.t, state.n);
    const key = state.scene + ':' + s.k + ':' + state.n;
    if (key !== questionKey) { $('feedback').textContent = ''; $('answer').value = ''; questionKey = key; selected = hovered = null; }
    $('periodName').textContent = s.name; $('explain').textContent = s.note;
    $('parentCount').textContent = `亲代 2n = ${2 * s.n}`;
    $('timelineLabel').textContent = s.scene === 'meiosis' ? '减Ⅰ → 减Ⅱ' : '有丝分裂期';
    $('progress').setAttribute('aria-valuetext', s.name);
    canvas.setAttribute('aria-label', `${s.name}，每细胞染色体 ${s.chromosomes} 条，核 DNA ${s.dna.toFixed(s.k === 1 ? 1 : 0)} 个`);
    $('chromosomes').textContent = s.chromosomes + ' 条';
    $('dna').textContent = s.dna.toFixed(s.k === 1 ? 1 : 0) + ' 个';
    $('chromatids').textContent = s.chromatids === null ? '复制中' : s.chromatids + ' 条';
    $('cells').textContent = s.cells + ' 个'; $('progress').value = state.t;
    $('play').textContent = state.play ? '暂停' : '播放';
    $('prev').disabled = state.t <= 0; $('next').disabled = state.t >= Division.stages(state.scene).length - 1;
    $('orientation').hidden = state.scene !== 'meiosis'; $('flip').textContent = state.flip ? '组合 B：第二对反向' : '组合 A：同向排列';
    document.querySelectorAll('[data-scene]').forEach(b => { b.classList.toggle('on', b.dataset.scene === state.scene); b.setAttribute('aria-pressed', b.dataset.scene === state.scene); });
    [...$('periods').children].forEach((b, i) => { b.classList.toggle('on', i === s.k); b.setAttribute('aria-pressed', i === s.k); });
    $('pairs').value = state.n; $('labels').checked = state.labels;
    $('countNote').textContent = s.k === 1 ? 'S期 DNA 为连续相对量；只计核 DNA，不计细胞器 DNA。' : '按每个完整细胞计数，后期计两极的合计。';
    draw();
  }
  function setT(t) { state.t = Division.clamp(t, 0, Division.stages(state.scene).length - 1); state.play = false; update(); }
  function setScene(v) { if (v === state.scene) return; state.scene = v === 'mitosis' ? v : 'meiosis'; state.t = 3; state.play = false; timeline(); update(); }
  document.querySelectorAll('[data-scene]').forEach(b => b.onclick = () => { setScene(b.dataset.scene); track('切换分裂', state.scene); });
  $('progress').oninput = e => setT(+e.target.value);
  $('progress').onchange = () => track('拖动进度', state.t.toFixed(1));
  $('prev').onclick = () => setT(Math.max(0, Math.ceil(state.t) - 1));
  $('next').onclick = () => setT(Math.floor(state.t) + 1);
  $('play').onclick = () => {
    if (state.t >= Division.stages(state.scene).length - 1) state.t = 0;
    state.play = !state.play; track('播放暂停', state.play); update();
  };
  $('reset').onclick = () => { setT(0); if (mobile.matches) togglePanel(false, true); track('重置', state.scene); };
  $('pairs').onchange = e => { state.n = +e.target.value; update(); track('染色体组', state.n); };
  $('flip').onclick = () => { state.flip = !state.flip; update(); track('独立分配', state.flip); };
  $('labels').onchange = e => { state.labels = e.target.checked; update(); };
  $('share').onclick = async () => {
    const q = new URLSearchParams({ scene: state.scene, t: state.t.toFixed(2), n: state.n, flip: +state.flip, labels: +state.labels, play: 0 });
    const url = location.origin + location.pathname + '?' + q;
    try { await navigator.clipboard.writeText(url); $('shareStatus').textContent = '已复制当前时期链接'; }
    catch (_) { $('shareStatus').textContent = url; }
    track('复制链接', state.scene);
  };
  // 小练习直接引用当前计算结果，不另造一套计数规则。
  $('check').onclick = () => {
    const s = Division.sample(state.scene, state.t, state.n), answer = Number($('answer').value);
    $('feedback').textContent = $('answer').value === '' ? '先填写一个数。' : answer === s.chromosomes ? `正确：按着丝粒计数为 ${s.chromosomes} 条。${s.note}` : `应为 ${s.chromosomes} 条。${s.note}`;
    track('计数练习', answer === s.chromosomes ? '正确' : '再试');
  };
  function togglePanel(open, focus = false) {
    panel.classList.toggle('collapsed', !open);
    $('panelToggle').setAttribute('aria-expanded', String(open));
    if (focus) (open ? $('closePanel') : $('panelToggle')).focus();
  }
  $('panelToggle').onclick = () => togglePanel(panel.classList.contains('collapsed'), true);
  $('closePanel').onclick = () => togglePanel(false, true);
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape' && mobile.matches && !panel.classList.contains('collapsed')) togglePanel(false, true);
  });
  if (mobile.matches) togglePanel(false);
  else $('chartDetails').open = true;
  mobile.addEventListener('change', () => togglePanel(!mobile.matches));
  const resize = new ResizeObserver(draw);
  resize.observe(canvas);
  resize.observe(chart);
  let last = 0;
  function frame(now) {
    const dt = Math.min((now - last) / 1000 || 0, .08); last = now;
    if (state.play) {
      state.t = Math.min(state.t + dt / 3.5, Division.stages(state.scene).length - 1);
      if (state.t >= Division.stages(state.scene).length - 1) state.play = false;
      update();
    }
    requestAnimationFrame(frame);
  }
  window.__model = { state, update, setT, setScene, sample: () => Division.sample(state.scene, state.t, state.n) };
  timeline(); update(); requestAnimationFrame(frame);
})();
