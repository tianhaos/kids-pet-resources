// 纯计算：以一个正在分裂的细胞为统计单位，n 为一个染色体组的条数。
(function () {
  'use strict';
  const common = [
    ['G₁期', '复制前：每条染色体含一个 DNA 分子。'],
    ['S期（复制）', 'DNA 逐步复制；着丝粒数不变，染色体数不变。'],
    ['前期', '复制完成，每条染色体有两条姐妹染色单体。'],
    ['中期', '每条染色体的着丝粒排列在赤道板上。'],
    ['后期', '着丝粒分裂，姐妹染色单体分开，分别成为染色体。'],
    ['子细胞', '胞质分裂完成：两个子细胞各保留亲代的染色体数。']
  ];
  const meiosis = [common[0], common[1],
    ['减Ⅰ前期', '同源染色体联会，形成四分体；图中同形异色为一对同源染色体。'],
    ['减Ⅰ中期', '同源染色体成对排列；不同对的朝向可以不同。'],
    ['减Ⅰ后期', '同源染色体分离，着丝粒不分裂，姐妹染色单体仍相连。'],
    ['减Ⅰ子细胞', '形成两个细胞，每个只得到每对同源染色体中的一条。'],
    ['减Ⅱ前期', '两次分裂之间不再进行 DNA 复制。'],
    ['减Ⅱ中期', '每个细胞中，染色体的着丝粒排列在赤道板上。'],
    ['减Ⅱ后期', '着丝粒分裂，姐妹染色单体分开，染色体数暂时加倍。'],
    ['减Ⅱ子细胞', '形成四个单倍体细胞，每条染色体含一个 DNA 分子。']
  ];
  function stages(scene) { return scene === 'meiosis' ? meiosis : common; }
  function clamp(x, a, b) { return Math.min(b, Math.max(a, Number.isFinite(+x) ? +x : a)); }
  function sample(scene, t, n) {
    n = n === 3 ? 3 : 2;
    const seq = stages(scene), end = seq.length - 1;
    t = clamp(t, 0, end);
    const k = Math.floor(t), f = t - k, mei = scene === 'meiosis';
    let chromosomes = 2 * n, dna = 2 * n, chromatids = 0, cells = 1;
    if (k === 1) { dna = 2 * n * (1 + f); chromatids = null; }
    if (k >= 2) { dna = 4 * n; chromatids = 4 * n; }
    if (!mei && k === 4) { chromosomes = 4 * n; chromatids = 0; }
    if (!mei && k === 5) { cells = 2; chromosomes = dna = 2 * n; chromatids = 0; }
    if (mei && k >= 5) { cells = 2; chromosomes = n; dna = chromatids = 2 * n; }
    if (mei && k === 8) { chromosomes = 2 * n; chromatids = 0; }
    if (mei && k === 9) { cells = 4; chromosomes = dna = n; chromatids = 0; }
    return { scene, t, n, k, f, cells, chromosomes, dna, chromatids, name: seq[k][0], note: seq[k][1] };
  }
  // 不含交叉互换。第二对可调换极向，其余对采用固定朝向。
  function origin(pair, pole, flip) { return pole ^ ((pair === 1 && flip) ? 1 : 0); }
  window.Division = { stages, sample, clamp, origin };
})();
