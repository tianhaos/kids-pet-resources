// 细胞以局部坐标绘制，赤道板沿局部 y 轴，减Ⅱ视图将分裂轴旋转 90°。
(function () {
  'use strict';
  const TAU = 2 * Math.PI;
  const C = { gold: '#ffc470', blue: '#74d5ff', dna: '#83e4b5', muted: '#a3b0c8' };
  const stain = [
    ['#804633', '#eda554', '#ffe3a4'],
    ['#244b86', '#51b4e3', '#c5f6ff']
  ];
  const mix = (a, b, f) => a + (b - a) * f;
  const ease = f => { const t = Math.max(0, Math.min(1, f)); return t * t * (3 - 2 * t); };
  const random = i => ((Math.sin(i * 127.1 + 17.7) * 43758.5453) % 1 + 1) % 1;
  function prepare(canvas) {
    const { width: w, height: h } = canvas.getBoundingClientRect();
    if (!w || !h) return null;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    if (canvas.width !== Math.round(w * dpr)) canvas.width = Math.round(w * dpr);
    if (canvas.height !== Math.round(h * dpr)) canvas.height = Math.round(h * dpr);
    const ctx = canvas.getContext('2d');
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, w, h);
    return { ctx, w, h };
  }
  function write(ctx, text, x, y, size, color = C.muted, align = 'center') {
    ctx.fillStyle = color;
    ctx.font = `${size}px -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif`;
    ctx.textAlign = align;
    ctx.fillText(text, x, y);
  }
  function line(ctx, x1, y1, x2, y2, color, width = 1) {
    ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2);
    ctx.strokeStyle = color; ctx.lineWidth = width; ctx.stroke();
  }
  function dot(ctx, x, y, radius, fill) {
    ctx.beginPath(); ctx.arc(x, y, radius, 0, TAU);
    ctx.fillStyle = fill; ctx.fill();
  }
  function gradient(ctx, x, y, size, stops) {
    const g = ctx.createRadialGradient(x, y, 0, x, y, size);
    stops.forEach(([at, color]) => g.addColorStop(at, color));
    return g;
  }
  function outline(rx, ry, pinch, seed, inset = 1) {
    const p = new Path2D();
    for (let i = 0; i < 128; i++) {
      const a = i / 128 * TAU, cos = Math.cos(a);
      const ripple = 1 + .023 * Math.sin(3 * a + seed) + .015 * Math.cos(7 * a + seed);
      const waist = 1 - pinch * Math.exp(-cos * cos * 8);
      const x = rx * cos * ripple * inset, y = ry * Math.sin(a) * ripple * waist * inset;
      if (i === 0) p.moveTo(x, y); else p.lineTo(x, y);
    }
    p.closePath();
    return p;
  }
  function body(ctx, rx, ry, pinch, seed) {
    const p = outline(rx, ry, pinch, seed);
    ctx.shadowColor = '#8270d979'; ctx.shadowBlur = 20;
    ctx.fillStyle = '#181425'; ctx.fill(p);
    ctx.shadowBlur = 0;
    ctx.save(); ctx.clip(p);
    ctx.fillStyle = gradient(ctx, -rx * .28, -ry * .42, rx * 1.25,
      [[0, '#514365'], [.49, '#302742'], [.8, '#201b35'], [1, '#141322']]);
    ctx.fillRect(-rx * 1.08, -ry * 1.08, rx * 2.16, ry * 2.16);
    for (let i = 0; i < 270; i++) {
      const key = i * 13 + seed * 3, a = random(key + 1) * TAU, r = Math.sqrt(random(key + 2));
      const x = Math.cos(a) * rx * r, y = Math.sin(a) * ry * r;
      const size = .3 + random(key + 4) * 1.18;
      dot(ctx, x, y, size, i % 3 === 0 ? '#d0b1ed49' : '#120e2880');
      if (i % 37 === 0) {
        ctx.save(); ctx.translate(x, y); ctx.rotate(a);
        ctx.beginPath(); ctx.moveTo(-5, 1); ctx.bezierCurveTo(-3, -4, 3, -4, 6, 0);
        ctx.strokeStyle = '#ac89c66d'; ctx.lineWidth = 2.4; ctx.lineCap = 'round'; ctx.stroke();
        ctx.restore();
      }
    }
    ctx.restore();
    ctx.strokeStyle = '#9986c664'; ctx.lineWidth = 3; ctx.stroke(p);
    ctx.strokeStyle = '#b8a5e33d'; ctx.lineWidth = 1; ctx.stroke(outline(rx, ry, pinch, seed, .955));
    ctx.strokeStyle = '#e0c9ff85'; ctx.lineWidth = .8; ctx.stroke(p);
    return p;
  }
  function nucleus(ctx, x, y, rx, ry, alpha, seed, nucleolus) {
    if (alpha <= 0.01) return;
    ctx.save(); ctx.translate(x, y); ctx.globalAlpha = alpha;
    const p = outline(rx, ry, 0, seed);
    ctx.fillStyle = gradient(ctx, -rx * .27, -ry * .2, rx * 1.35,
      [[0, '#41315f'], [.78, '#252043'], [1, '#18172b']]);
    ctx.fill(p);
    for (let i = 0; i < 95; i++) {
      const a = random(i * 3 + 7) * TAU, r = Math.sqrt(random(i * 3 + 8)) * .93;
      dot(ctx, rx * r * Math.cos(a), ry * r * Math.sin(a), .3 + random(i * 3 + 9),
        i % 2 ? '#c6a1f340' : '#14071c76');
    }
    ctx.strokeStyle = '#b699ed85'; ctx.lineWidth = 1.6; ctx.stroke(p);
    ctx.strokeStyle = '#ad99e343'; ctx.lineWidth = .75; ctx.stroke(outline(rx, ry, 0, seed, .94));
    if (nucleolus) {
      const nx = -rx * .19, ny = ry * .15, r = Math.min(rx, ry) * .15;
      dot(ctx, nx, ny, r, gradient(ctx, nx - r * .23, ny - r * .25, r * 1.3, [[0, '#b780be'], [1, '#593b78']]));
    }
    ctx.restore();
  }
  function chromatin(ctx, g, amount) {
    const { x, y, len, ori, tilt, j } = g;
    ctx.save(); ctx.translate(x, y); ctx.rotate(tilt);
    for (let copy = 0; copy < 2; copy++) {
      ctx.globalAlpha *= copy ? amount : 1;
      ctx.beginPath();
      for (let i = 0; i <= 30; i++) {
        const t = i / 30, u = (t - .5) * len * 1.32;
        const v = len * (.26 * Math.sin(t * 11 + j) + .10 * Math.sin(t * 28)) + copy * 4;
        if (i) ctx.lineTo(u, v); else ctx.moveTo(u, v);
      }
      ctx.strokeStyle = stain[ori][1]; ctx.lineWidth = 1.35; ctx.stroke();
    }
    ctx.restore();
  }
  function chromosome(ctx, g) {
    const { x, y, len, ori, replicated, direction, tilt, active } = g;
    const [shade, mid, light] = stain[ori], spread = len * .21;
    ctx.save(); ctx.translate(x, y); ctx.rotate(tilt);
    ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    const sides = replicated ? [-1, 1] : [direction || 1];
    const tube = ctx.createLinearGradient(-spread, -len * .32, spread, len * .63);
    tube.addColorStop(0, light); tube.addColorStop(.50, mid); tube.addColorStop(1, light);
    for (const side of sides) {
      const p = new Path2D();
      p.moveTo(side * spread * .88, -len * .40);
      p.bezierCurveTo(side * spread * 1.23, -len * .2, side * spread * .30, -len * .15, 0, 0);
      p.bezierCurveTo(side * spread * .36, len * .17, side * spread * 1.38, len * .36, side * spread, len * .60);
      ctx.shadowColor = active ? light : mid; ctx.shadowBlur = active ? 14 : 5;
      ctx.strokeStyle = shade; ctx.lineWidth = Math.max(4.6, len * .21); ctx.stroke(p);
      ctx.shadowBlur = 0;
      ctx.strokeStyle = tube; ctx.lineWidth = Math.max(2.9, len * .14); ctx.stroke(p);
    }
    const r = Math.max(1.75, len * .071);
    if (active) {
      ctx.beginPath(); ctx.arc(0, 0, r + 5, 0, TAU);
      ctx.strokeStyle = '#f3edffbd'; ctx.lineWidth = 1; ctx.stroke();
    }
    dot(ctx, 0, 0, r + .7, shade); dot(ctx, 0, 0, r, '#f3edff');
    ctx.restore();
  }
  function spindle(ctx, rx, ry, genes, strength, paired, separating, seed, attachment) {
    if (strength <= 0.01) return;
    ctx.save(); ctx.globalAlpha = strength;
    for (const pole of [-1, 1]) {
      const x = pole * rx * .78;
      for (let i = 0; i < 21; i++) {
        const angle = i / 21 * TAU + seed, len = Math.min(rx, ry) * (.13 + random(i + seed) * .24);
        line(ctx, x, 0, x + len * Math.cos(angle), len * Math.sin(angle), '#80ded745', .75);
      }
      ctx.globalAlpha = strength * attachment;
      for (const g of genes) {
        if ((paired || separating) && g.pole !== pole) continue;
        for (let i = -1; i <= 1; i++) {
          ctx.beginPath(); ctx.moveTo(x, i * 1.8);
          ctx.quadraticCurveTo(mix(x, g.x, .52), g.y * .36 + i * 5, g.x + pole * 2, g.y + i * 1.35);
          ctx.strokeStyle = i ? '#71c7ca36' : '#98ebdf90'; ctx.lineWidth = i ? .7 : 1; ctx.stroke();
        }
      }
      ctx.globalAlpha = strength;
      dot(ctx, x, 0, 10, gradient(ctx, x, 0, 10, [[0, '#cff9e9b8'], [1, '#8be5cb00']]));
      line(ctx, x - 3, -1, x + 3, 1, '#d0ffee', 2.6);
      line(ctx, x - 1, 2.5, x + 2, 5, '#7de7d7', 1.8);
    }
    ctx.restore();
  }
  function specimen(ctx, w, h, state, options = {}) {
    const s = Division.sample(state.scene, state.t, state.n);
    const mei = s.scene === 'meiosis', second = mei && s.k >= 5;
    const final = s.k === (mei ? 9 : 5), resting = s.k < 2 || final;
    const early = s.k === 2 || s.k === 6;
    const aligned = s.k === 3 || s.k === 7;
    const separating = s.k === 4 || s.k === 8;
    const homologs = mei && !second && s.k >= 2;
    const split = separating && !homologs;
    const afterFirst = mei && s.k === 5;
    const vertical = second && !afterFirst && !final;
    const count = s.cells, cols = count > 1 ? 2 : 1, rows = count === 4 ? 2 : 1;
    const logicalH = h - (options.legend === false ? 4 : 28);
    const parentScale = Math.min(w / 344, logicalH / 275, options.maxScale || 1.65);
    const colWidth = count === 1 ? w : Math.min(w / cols, parentScale * 225, logicalH * .88);
    const rowHeight = logicalH / rows;
    const rowGap = Math.min(rowHeight, parentScale * 151);
    const width = vertical ? rowHeight : colWidth;
    const height = vertical ? colWidth : rowHeight;
    const scale = Math.min(width / (count === 1 ? 332 : 300), height / 268,
      parentScale * (count === 1 ? 1 : count === 2 ? .74 : .54));
    const travel = separating ? ease(s.f / .70) : 0;
    const furrow = separating ? ease((s.f - .58) / .42) : 0;
    const regions = [];
    ctx.fillStyle = gradient(ctx, w * .5, logicalH * .51, Math.max(w * .43, h * .68),
      [[0, '#101222'], [.58, '#0b0d17'], [1, '#05070d']]);
    ctx.fillRect(0, 0, w, h);
    for (let i = 0; i < 68; i++) {
      const x = random(i * 11 + 1) * w, y = random(i * 11 + 3) * logicalH;
      dot(ctx, x, y, .26 + random(i * 11 + 4) * .65, '#786a9b25');
    }
    for (let cell = 0; cell < count; cell++) {
      const col = cell % cols, row = Math.floor(cell / cols);
      const x = w / 2 + (col - (cols - 1) / 2) * colWidth;
      const y = logicalH * .51 + (row - (rows - 1) / 2) * rowGap;
      const rx = 139 + 19 * travel, ry = 114 - 11 * travel;
      const seed = cell * 19 + 5;
      ctx.save(); ctx.translate(x, y); ctx.scale(scale, scale);
      if (vertical) ctx.rotate(Math.PI / 2);
      const boundary = body(ctx, rx, ry, .90 * furrow, seed);
      ctx.save(); ctx.clip(boundary);
      const intact = resting ? 1 : afterFirst ? .92 : early ? mix(.78, .06, ease(s.f)) : 0;
      nucleus(ctx, 0, 0, rx * .60, ry * .69, intact, seed, resting);
      for (const pole of [-1, 1]) {
        nucleus(ctx, pole * rx * .50, 0, rx * .36, ry * .71, furrow * .92, seed + pole, false);
      }
      const base = second ? s.n : s.n * 2, genes = [];
      for (let j = 0; j < base; j++) {
        const pair = second ? j : Math.floor(j / 2), slots = homologs ? s.n : base;
        const slot = homologs ? pair : j;
        const rowStep = Math.min(62, ry * 1.43 / slots);
        const rowY = (slot - (slots - 1) / 2) * rowStep;
        const available = slots > 3 && !resting ? rowStep * .86 / 49 : 1;
        const len = [49, 39, 31][pair] * Math.min(1, ry / 109, available);
        const ori = second ? Division.origin(pair, col, state.flip) :
          homologs ? Division.origin(pair, j % 2, state.flip) : j % 2;
        const pole = j % 2 ? 1 : -1;
        const g = { j, pair, ori, len, pole, x: homologs ? pole * 16 : 0, y: rowY,
          tilt: 0, replicated: !resting };
        if (early) {
          g.x += (homologs ? Math.sin(pair * 2.6) : Math.sin(j * 2.4)) * rx * .31;
          g.tilt = Math.sin((homologs ? pair : j) * 2 + .6) * .47;
          const align = ease(s.f);
          g.x = mix(g.x, homologs ? pole * 16 : 0, align);
          g.tilt *= 1 - align;
        }
        if (resting || afterFirst) {
          const a = j * TAU / base + .55;
          g.x = Math.cos(a) * rx * .38;
          g.y = Math.sin(a) * ry * .43;
          g.tilt = a * .87;
          if (afterFirst) g.len *= .76;
        }
        if (separating && homologs) g.x = pole * mix(16, rx * .61, travel);
        if (split) {
          for (const side of [-1, 1]) genes.push({ ...g, x: side * mix(7, rx * .61, travel),
            pole: side, replicated: false, direction: -side });
        } else genes.push(g);
      }
      if (aligned || separating) {
        ctx.setLineDash([4, 5]);
        line(ctx, 0, -ry * .97, 0, ry * .97, `rgba(192,198,243,${.43 * (1 - furrow)})`);
        ctx.setLineDash([]);
      }
      const field = early ? .42 + .58 * ease(s.f) : aligned || separating ? 1 : 0;
      spindle(ctx, rx, ry, genes, field * (1 - furrow), homologs, split, seed, early ? ease((s.f - .36) / .64) : 1);
      for (const g of genes) {
        const key = `${cell}:${g.j}:${split ? g.pole : 0}`;
        if (resting) {
          ctx.save(); ctx.globalAlpha = .62;
          chromatin(ctx, g, s.k === 1 ? s.f * .85 : 0); ctx.restore();
        } else {
          ctx.save(); ctx.globalAlpha = 1 - .46 * furrow;
          chromosome(ctx, { ...g, active: options.active === key }); ctx.restore();
          const gx = x + (vertical ? -g.y : g.x) * scale;
          const gy = y + (vertical ? g.x : g.y) * scale;
          regions.push({ key, x: gx, y: gy, r: Math.max(13, g.len * scale * .38),
            ori: g.ori, pair: g.pair, replicated: g.replicated });
        }
      }
      ctx.restore(); ctx.restore();
      if (state.labels && aligned && !options.thumbnail) {
        const lx = vertical ? x + ry * scale * .84 : x;
        const ly = vertical ? y - 6 : y + ry * scale + 15;
        write(ctx, '赤道板', lx, ly, 11);
      }
    }
    return regions;
  }
  function render(canvas, state, active) {
    const surface = prepare(canvas);
    return surface ? specimen(surface.ctx, surface.w, surface.h, state, { active }) : [];
  }
  function chartGeometry(w, h) { return { x: 23, y: 8, w: w - 36, h: h - 31 }; }
  function chartTime(canvas, x, scene) {
    const g = chartGeometry(canvas.getBoundingClientRect().width, canvas.getBoundingClientRect().height);
    return (x - g.x) / g.w * (Division.stages(scene).length - 1);
  }
  function chart(canvas, state) {
    const surface = prepare(canvas);
    if (!surface) return;
    const { ctx, w, h } = surface, g = chartGeometry(w, h);
    const s = Division.sample(state.scene, state.t, state.n), max = 4 * s.n;
    const end = Division.stages(state.scene).length - 1;
    const X = t => g.x + t / end * g.w, Y = v => g.y + g.h - v / max * g.h;
    for (let v = 0; v <= max; v += s.n) {
      line(ctx, g.x, Y(v), g.x + g.w, Y(v), '#30394b');
      write(ctx, v, g.x - 7, Y(v) + 3, 10, C.muted, 'right');
    }
    line(ctx, X(s.t), g.y, X(s.t), Y(0), '#b1c2e286');
    for (const [key, color, dash] of [['dna', C.dna, []], ['chromosomes', C.gold, [4, 3]]]) {
      // 只有 S 期为斜线。其余节点以垂直阶跃表示计数在阶段边界切换。
      for (const [limit, alpha] of [[end, .30], [s.t, 1]]) {
        ctx.beginPath(); ctx.setLineDash(dash); ctx.globalAlpha = alpha;
        ctx.moveTo(X(0), Y(Division.sample(s.scene, 0, s.n)[key]));
        for (let k = 0; k < limit; k++) {
          const stop = Math.min(k + 1, limit);
          const value = Division.sample(s.scene, stop, s.n)[key];
          const prior = Division.sample(s.scene, k, s.n)[key];
          ctx.lineTo(X(stop), Y(k === 1 ? value : prior));
          if (stop === k + 1) ctx.lineTo(X(stop), Y(value));
        }
        ctx.strokeStyle = color; ctx.lineWidth = 2; ctx.stroke();
        ctx.setLineDash([]); ctx.globalAlpha = 1;
      }
      const same = s.dna === s.chromosomes;
      dot(ctx, X(s.t), Y(s[key]), key === 'dna' && same ? 5 : 2.9, color);
    }
    const names = end === 9 ? ['G₁', 'S', '', 'Ⅰ中', 'Ⅰ后', 'Ⅰ末', '', 'Ⅱ中', 'Ⅱ后', 'Ⅱ末'] : ['G₁', 'S', '', '中期', '后期', '子细胞'];
    names.forEach((name, k) => { if (name) write(ctx, name, X(k), Y(0) + 16, 10); });
  }
  window.DivisionDraw = { render, chart, chartTime, specimen };
})();
