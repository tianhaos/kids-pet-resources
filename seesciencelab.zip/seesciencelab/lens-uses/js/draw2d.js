// 2D 画面：上方两个"所见"小窗（底片与照片 / 投影片与屏幕 / 直接看与透过放大镜看），下方光路图
// 世界坐标单位 cm，凸透镜光心在原点，x 向右、y 向上。
// 视觉约定与凸透镜模型一致：三条特殊光线 平行 #ff7a59、过光心 #4fc3f7、过焦点 #7ee081；
// 实物、实像金色 #ffc94a 实线，虚像紫色 #c9a7ff 虚线，反向延长线一律虚线。
(function () {
  var L = window.LensUse;

  var C = {
    axis: '#5b677b', text: '#c9d2df', muted: '#8d99ab', grid: 'rgba(255,255,255,0.035)',
    lens: 'rgba(120,190,255,0.20)', lensEdge: '#8fd0ff',
    r1: '#ff7a59', r2: '#4fc3f7', r3: '#7ee081', cone: 'rgba(255,209,102,0.13)',
    real: '#ffc94a', virt: '#c9a7ff', focus: '#ffc94a', ok: '#7ee081', bad: '#ff7a59',
    body: '#2a3446', bodyEdge: '#55627a', frame: '#3a4558', paper: '#efe6d2', ink: '#2b2722'
  };
  var RAYC = [C.r1, C.r2, C.r3];

  function UseDraw(canvas) {
    var ctx = canvas.getContext('2d');
    var W = 1, H = 1, dpr = 1, narrow = false;
    var P = null;                       // 光路图窗格 { x, y, w, h, s, cx, cy }
    var off = document.createElement('canvas'), octx = off.getContext('2d');
    var hasFilter = typeof ctx.filter === 'string';

    function X(x) { return P.cx + x * P.s; }
    function Y(y) { return P.cy - y * P.s; }
    function xl() { return (P.x - P.cx) / P.s; }
    function xr() { return (P.x + P.w - P.cx) / P.s; }

    function resize(w, h) {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      W = w; H = h;
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
      canvas.style.width = w + 'px'; canvas.style.height = h + 'px';
      narrow = w < 640;
    }

    // 上方小窗与下方光路图的位置
    function layout() {
      var top = narrow ? 84 : 44;
      var ih = narrow ? Math.max(96, Math.min(140, H * 0.2)) : Math.max(120, Math.min(220, H * 0.27));
      var py = top + ih + 12;
      return { top: top, ih: ih, py: py, ph: Math.max(120, H - py - 40) };
    }

    // 光路图窗格：横向显示 [x0, x1]，竖直至少 ±hv（cm）
    function pane(y, h, x0, x1, hv) {
      var s = Math.min((W - 16) / (x1 - x0), h / (2 * hv));
      var cx = (W - (x1 - x0) * s) / 2 - x0 * s;
      P = { x: 0, y: y, w: W, h: h, s: s, cx: cx, cy: y + h / 2 };
    }

    // ---------- 基本绘图 ----------
    function line(x1, y1, x2, y2, color, width, dash) {
      ctx.beginPath();
      ctx.setLineDash(dash || []);
      ctx.strokeStyle = color; ctx.lineWidth = width || 1.5;
      ctx.moveTo(X(x1), Y(y1)); ctx.lineTo(X(x2), Y(y2));
      ctx.stroke();
      ctx.setLineDash([]);
    }
    function arrowHead(x1, y1, x2, y2, color) {
      var ax = X(x1), ay = Y(y1), bx = X(x2), by = Y(y2);
      if (Math.hypot(bx - ax, by - ay) < 36) return;
      ctx.save();
      ctx.translate((ax + bx) / 2, (ay + by) / 2); ctx.rotate(Math.atan2(by - ay, bx - ax));
      ctx.beginPath(); ctx.moveTo(6, 0); ctx.lineTo(-4, -4); ctx.lineTo(-4, 4); ctx.closePath();
      ctx.fillStyle = color; ctx.fill();
      ctx.restore();
    }
    function font(size, weight) {
      ctx.font = (weight || '') + ' ' + (size || 12) + 'px -apple-system, "PingFang SC", "Microsoft YaHei", sans-serif';
    }
    function text(str, px, py, color, align, size, weight) {
      font(size, weight);
      ctx.fillStyle = color || C.text;
      ctx.textAlign = align || 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(str, px, py);
    }
    function roundRect(c, x, y, w, h, r) {
      c.beginPath();
      c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r);
      c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath();
    }
    function tag(str, px, py, color) {
      font(12);
      var w = ctx.measureText(str).width + 12;
      px = Math.max(w / 2 + 4, Math.min(W - w / 2 - 4, px));
      ctx.fillStyle = 'rgba(11,15,23,0.85)';
      ctx.strokeStyle = color; ctx.lineWidth = 1;
      roundRect(ctx, px - w / 2, py - 10, w, 20, 10);
      ctx.fill(); ctx.stroke();
      text(str, px, py, color);
    }
    function dim(x1, x2, py, label, color) {
      var a = X(x1), b = X(x2);
      if (b - a < 28) return;
      ctx.strokeStyle = color; ctx.globalAlpha = 0.6; ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(a, py); ctx.lineTo(b, py);
      ctx.moveTo(a, py - 4); ctx.lineTo(a, py + 4);
      ctx.moveTo(b, py - 4); ctx.lineTo(b, py + 4);
      ctx.stroke(); ctx.globalAlpha = 1;
      font(12);
      var w = ctx.measureText(label).width + 8;
      ctx.fillStyle = '#05070d'; ctx.fillRect((a + b) / 2 - w / 2, py - 8, w, 16);
      text(label, (a + b) / 2, py, color, 'center', 12);
    }

    function background() {
      ctx.strokeStyle = C.grid; ctx.lineWidth = 1;
      ctx.beginPath();
      for (var gx = Math.ceil(xl() / 5) * 5; gx <= xr(); gx += 5) { ctx.moveTo(X(gx), P.y); ctx.lineTo(X(gx), P.y + P.h); }
      for (var gy = -40; gy <= 40; gy += 5) { var py = Y(gy); if (py > P.y && py < P.y + P.h) { ctx.moveTo(0, py); ctx.lineTo(W, py); } }
      ctx.stroke();
      line(xl(), 0, xr(), 0, C.axis, 1);
    }

    // 凸透镜：焦距越短越鼓；extendTo > R 时按教材画法把透镜用虚线延长
    function lens(f, R, extendTo) {
      var top = Y(R), bot = Y(-R), x0 = X(0);
      var half = Math.max(Math.min(Math.max(14 / f, 0.5), 2.4) * P.s, 3);
      ctx.beginPath();
      ctx.moveTo(x0, top);
      ctx.quadraticCurveTo(x0 + half * 2, P.cy, x0, bot);
      ctx.quadraticCurveTo(x0 - half * 2, P.cy, x0, top);
      ctx.fillStyle = C.lens; ctx.fill();
      ctx.strokeStyle = C.lensEdge; ctx.lineWidth = 1.5; ctx.stroke();
      if (extendTo > R) {
        line(0, R, 0, extendTo + 0.5, 'rgba(143,208,255,0.55)', 1.2, [4, 4]);
        line(0, -R, 0, -extendTo - 0.5, 'rgba(143,208,255,0.55)', 1.2, [4, 4]);
      }
    }

    function foci(f, labels) {
      [[-f, 'F'], [f, 'F′'], [-2 * f, '2F'], [2 * f, '2F′']].forEach(function (p) {
        if (p[0] < xl() || p[0] > xr()) return;
        var minor = p[1].charAt(0) === '2';
        ctx.beginPath(); ctx.arc(X(p[0]), P.cy, minor ? 3 : 3.8, 0, Math.PI * 2);
        ctx.fillStyle = minor ? '#9aa6b8' : C.focus; ctx.fill();
        if (labels) text(p[1], X(p[0]), P.cy + 14, minor ? '#9aa6b8' : C.focus, 'center', 12, '600');
      });
    }

    // 竖直箭头（物或像），从 y0 指向 y1
    function arrow(x, y0, y1, color, dash, alpha) {
      ctx.save();
      ctx.globalAlpha = alpha || 1;
      line(x, y0, x, y1, color, 2.4, dash);
      var px = X(x), py = Y(y1), dir = y1 > y0 ? 1 : -1;
      ctx.beginPath(); ctx.moveTo(px, py); ctx.lineTo(px - 6, py + dir * 10); ctx.lineTo(px + 6, py + dir * 10); ctx.closePath();
      if (dash) { ctx.setLineDash([3, 2]); ctx.strokeStyle = color; ctx.lineWidth = 1.5; ctx.stroke(); ctx.setLineDash([]); }
      else { ctx.fillStyle = color; ctx.fill(); }
      ctx.restore();
    }

    // 朝左看的眼睛，(px, py) 为瞳孔中心
    function eye(px, py, sc) {
      ctx.save();
      ctx.translate(px, py); ctx.scale(sc, sc);
      ctx.beginPath();
      ctx.moveTo(-2, 0); ctx.quadraticCurveTo(14, -16, 30, -2); ctx.quadraticCurveTo(14, 14, -2, 0);
      ctx.fillStyle = '#e9eef5'; ctx.fill();
      ctx.strokeStyle = '#9aa6b8'; ctx.lineWidth = 1.5 / sc; ctx.stroke();
      ctx.beginPath(); ctx.arc(6, -1, 6, 0, Math.PI * 2); ctx.fillStyle = '#4b6a8a'; ctx.fill();
      ctx.beginPath(); ctx.arc(4, -1, 2.6, 0, Math.PI * 2); ctx.fillStyle = '#0b0f17'; ctx.fill();
      ctx.restore();
    }

    // ---------- 物体图案（单位高度，中心在原点，y 向下为画布方向） ----------
    // 树：左边挂一个红苹果，用来看出像"左右也相反"
    function treeShape(c) {
      c.fillStyle = '#8a5a36'; c.fillRect(-0.05, 0.05, 0.1, 0.45);
      c.fillStyle = '#3f9b52';
      [[0, -0.2, 0.3], [-0.19, -0.02, 0.2], [0.19, -0.02, 0.2], [0, 0.04, 0.2]].forEach(function (b) {
        c.beginPath(); c.arc(b[0], b[1], b[2], 0, Math.PI * 2); c.fill();
      });
      c.fillStyle = '#5cbf6d'; c.beginPath(); c.arc(-0.08, -0.3, 0.12, 0, Math.PI * 2); c.fill();
      c.fillStyle = '#e8463a'; c.beginPath(); c.arc(-0.2, 0.02, 0.065, 0, Math.PI * 2); c.fill();
    }
    // 字母 F（高 1、宽 0.62）
    function letterF(c) {
      c.beginPath();
      c.rect(-0.31, -0.5, 0.18, 1);
      c.rect(-0.31, -0.5, 0.62, 0.17);
      c.rect(-0.31, -0.08, 0.48, 0.16);
      c.fill();
    }
    function draw2(c, shape, cx, cy, size, rot) {
      c.save();
      c.translate(cx, cy); c.scale(size, size);
      if (rot) c.rotate(Math.PI);
      shape(c);
      c.restore();
    }

    // 在矩形里画内容并模糊 r 像素（ctx.filter 不可用时用多次平移叠加近似）
    function withBlur(x, y, w, h, r, fn) {
      ctx.save();
      ctx.beginPath(); ctx.rect(x, y, w, h); ctx.clip();
      if (r < 0.4) { ctx.translate(x, y); fn(ctx, w, h); ctx.restore(); return; }
      off.width = Math.ceil(w * dpr); off.height = Math.ceil(h * dpr);
      octx.setTransform(dpr, 0, 0, dpr, 0, 0); octx.clearRect(0, 0, w, h);
      fn(octx, w, h);
      if (hasFilter) {
        ctx.filter = 'blur(' + Math.min(r, 40).toFixed(1) + 'px)';
        ctx.drawImage(off, x, y, w, h);
        ctx.filter = 'none';
      } else {
        var n = 12;
        for (var i = 0; i < n; i++) {
          var a = i * 2.4, rr = r * Math.sqrt((i + 0.5) / n);
          ctx.globalAlpha = 1 / (i + 1);
          ctx.drawImage(off, x + Math.cos(a) * rr, y + Math.sin(a) * rr, w, h);
        }
      }
      ctx.restore();
    }

    // 小窗：标题在框上方；round 为圆形（放大镜）
    function insetFrame(x, y, w, h, title, round, color) {
      text(title, x + w / 2, y - 9, color || C.muted, 'center', narrow ? 11 : 12, '600');
      ctx.save();
      ctx.beginPath();
      if (round) ctx.arc(x + w / 2, y + h / 2, Math.min(w, h) / 2, 0, Math.PI * 2);
      else roundRect(ctx, x, y, w, h, 6);
      ctx.clip();
    }
    function insetEnd(x, y, w, h, round, color) {
      ctx.restore();
      ctx.beginPath();
      if (round) ctx.arc(x + w / 2, y + h / 2, Math.min(w, h) / 2, 0, Math.PI * 2);
      else roundRect(ctx, x, y, w, h, 6);
      ctx.strokeStyle = color || C.frame; ctx.lineWidth = round ? 4 : 1.5; ctx.stroke();
    }
    // 两个小窗并排居中，宽高比 ar
    function insetBoxes(lay, ar) {
      var h = lay.ih - 18, w = h * ar, gap = narrow ? 14 : 28;
      if (2 * w + gap > W - 24) { w = (W - 24 - gap) / 2; h = w / ar; }
      var x0 = (W - 2 * w - gap) / 2, y = lay.top + 18;
      return [{ x: x0, y: y, w: w, h: h }, { x: x0 + w + gap, y: y, w: w, h: h }];
    }
    function center(b, str, color, size) { text(str, b.x + b.w / 2, b.y + b.h / 2, color, 'center', size || 12, '600'); }

    // ---------- 光路：特殊光线、光束 ----------
    // T 物体顶端；s 求解结果；stop 光线终止的 x（底片/光屏），null 则画到画面右缘
    function cone(T, s, stop) {
      var R = s.R, I = s.none ? null : [s.v, s.hi], end = stop != null ? stop : xr() + 5;
      if (!I) return;
      function at(yl) {                     // 透镜上 yl 处的光线到 end 处的高度
        if (s.real) return yl + (I[1] - yl) * end / I[0];
        return yl + (yl - I[1]) / (-I[0]) * end;
      }
      ctx.beginPath();
      ctx.moveTo(X(T[0]), Y(T[1])); ctx.lineTo(X(0), Y(R)); ctx.lineTo(X(end), Y(at(R)));
      ctx.lineTo(X(end), Y(at(-R))); ctx.lineTo(X(0), Y(-R)); ctx.closePath();
      ctx.fillStyle = C.cone; ctx.fill();
    }

    function specialRays(T, s, stop) {
      var I = s.none ? null : [s.v, s.hi], f = s.f, u = s.u;
      s.rays.forEach(function (r, j) {
        if (!isFinite(r.y)) return;
        var c = RAYC[j];
        if (j === 2 && u < f) line(-f, 0, T[0], T[1], c, 1.2, [5, 5]);    // 好像从 F 发出
        line(T[0], T[1], 0, r.y, c, 2);
        arrowHead(T[0], T[1], 0, r.y, c);
        var end = stop != null ? stop : xr() + 5;
        line(0, r.y, end, r.y + r.ko * end, c, 2);
        arrowHead(0, r.y, Math.min(end, 30), r.y + r.ko * Math.min(end, 30), c);
        if (I && !s.real) line(0, r.y, I[0], I[1], c, 1.2, [5, 5]);       // 反向延长线
      });
    }
    function rayExtent(s, T) {
      var m = Math.abs(T[1]);
      s.rays.forEach(function (r) { if (isFinite(r.y)) m = Math.max(m, Math.abs(r.y)); });
      return Math.min(m, 60);
    }

    // ---------- 场景一：照相机 ----------
    function drawCamera(st, s) {
      var lay = layout(), f = st.f, K = L.CAM, d = s.d, half = K.H / 2;
      pane(lay.py, lay.ph, narrow ? -48 : -63, K.dMax * f + 4, half + 3);
      background();

      // 相机机身：底片固定在机身后部，镜筒随对焦伸缩
      var front = Math.max(d * 0.42, 1.6), bh = 4.4;
      ctx.fillStyle = C.body; ctx.strokeStyle = C.bodyEdge; ctx.lineWidth = 1.5;
      roundRect(ctx, X(front), Y(bh), (d + 0.9 - front) * P.s, 2 * bh * P.s, 6); ctx.fill(); ctx.stroke();
      roundRect(ctx, X(d - 2.4), Y(bh + 1.1), 1.6 * P.s, 1.1 * P.s, 2); ctx.fill(); ctx.stroke();   // 快门键
      ctx.fillRect(X(-0.5), Y(K.R + 0.7), (front + 0.5) * P.s, 2 * (K.R + 0.7) * P.s);
      ctx.strokeRect(X(-0.5), Y(K.R + 0.7), (front + 0.5) * P.s, 2 * (K.R + 0.7) * P.s);
      // 暗箱内部
      ctx.fillStyle = '#0b0f17';
      ctx.fillRect(X(front + 0.3), Y(bh - 0.4), (d - front - 0.3) * P.s, 2 * (bh - 0.4) * P.s);

      var T = [-s.u, half];
      if (st.show.beam) cone(T, s, d);
      lens(f, K.R, st.show.rays ? rayExtent(s, T) : 0);
      foci(f, st.show.labels);
      if (st.show.rays) specialRays(T, s, d);

      // 底片
      ctx.fillStyle = s.sharp ? 'rgba(126,224,129,0.85)' : 'rgba(141,153,171,0.85)';
      ctx.fillRect(X(d) - 2, Y(K.film), 4, 2 * K.film * P.s);

      // 树与像
      if (-s.u > xl() + 1) draw2(ctx, treeShape, X(-s.u), P.cy, K.H * P.s, false);
      else tag('← 树在 ' + s.u.toFixed(0) + ' cm 处', 90, P.cy - 40, C.text);
      if (s.sharp) {                                    // 对准焦时像落在底片上；没对准只看光线会聚在哪里
        ctx.save(); ctx.globalAlpha = 0.9;
        ctx.beginPath(); ctx.rect(X(d) - 40, Y(K.film), 80, 2 * K.film * P.s); ctx.clip();
        draw2(ctx, treeShape, X(d), P.cy, Math.abs(s.m) * K.H * P.s, true);
        ctx.restore();
      }

      if (st.show.labels) {
        text('照相机', X((front + d) / 2 - 0.6), Y(bh + 1.1) - 12, C.lensEdge, 'center', 12, '600');
        text(s.sharp ? '底片：像清晰' : '底片', X(d) + 8, Y(-K.film) + 12, s.sharp ? C.ok : C.muted, 'left', 12);
        var base = Math.min(P.y + P.h - 14, P.cy + half * P.s + 18);
        dim(Math.max(-s.u, xl()), 0, base, 'u = ' + s.u.toFixed(1) + ' cm', C.text);
        if (s.real && s.v < xr()) dim(0, s.v, Math.min(P.y + P.h - 14, P.cy + bh * P.s + 18), 'v = ' + s.v.toFixed(2) + ' cm', C.real);
      }

      // 小窗：底片上的像、照片
      var bx = insetBoxes(lay, 1.5), sc = bx[0].h / (2 * K.film), br = s.blur / 2 * sc;
      var tsz = Math.abs(s.m) * K.H * sc;
      [0, 1].forEach(function (i) {
        var b = bx[i];
        insetFrame(b.x, b.y, b.w, b.h, i ? '洗出的照片（转正后看）' : '底片上的像（从相机背后看）');
        var g = ctx.createLinearGradient(0, b.y, 0, b.y + b.h);
        g.addColorStop(i ? 0 : 1, '#2c4a6e'); g.addColorStop(i ? 1 : 0, '#1a2a3a');
        ctx.fillStyle = g; ctx.fillRect(b.x, b.y, b.w, b.h);
        if (s.real) withBlur(b.x, b.y, b.w, b.h, br, function (c, w, h) { draw2(c, treeShape, w / 2, h / 2, tsz, !i); });
        if (!s.fit && s.real) center(b, '拍不全', C.bad, 13);
        insetEnd(b.x, b.y, b.w, b.h, false, s.sharp && s.fit ? 'rgba(126,224,129,0.6)' : C.frame);
      });
    }

    // ---------- 场景二：投影仪 ----------
    function drawProjector(st, s) {
      var lay = layout(), f = st.f, K = L.PROJ, d = s.d, half = K.h / 2;
      pane(lay.py, lay.ph, -(2.5 * f + 7), K.xMax + 3, K.screen + 1);
      background();

      // 光源与聚光镜（跟投影片一起移动）
      var sx = -s.u;
      ctx.beginPath(); ctx.arc(X(sx - 4), P.cy, 0.9 * P.s + 3, 0, Math.PI * 2);
      ctx.fillStyle = '#fff3b0'; ctx.shadowColor = '#ffb347'; ctx.shadowBlur = 18; ctx.fill(); ctx.shadowBlur = 0;
      ctx.fillStyle = 'rgba(255,240,190,0.08)';
      ctx.beginPath(); ctx.moveTo(X(sx - 4), P.cy); ctx.lineTo(X(sx), Y(half + 0.6)); ctx.lineTo(X(sx), Y(-half - 0.6)); ctx.closePath(); ctx.fill();

      // 屏幕
      ctx.fillStyle = '#d9dee6';
      ctx.fillRect(X(d), Y(K.screen), 5, 2 * K.screen * P.s);

      var T = [sx, half];
      if (st.show.beam) cone(T, s, d);
      lens(f, K.R, st.show.rays ? rayExtent(s, T) : 0);
      foci(f, st.show.labels);
      if (st.show.rays) specialRays(T, s, d);

      // 投影片（物）与像
      ctx.fillStyle = 'rgba(200,220,255,0.18)'; ctx.fillRect(X(sx) - 3, Y(half + 0.6), 6, (2 * half + 1.2) * P.s);
      arrow(sx, -half, half, C.real);
      if (s.real && s.v < xr() - 1) arrow(s.v, -s.hi, s.hi, C.real, null, s.sharp ? 1 : 0.55);
      else if (!s.real && !s.none && s.v > xl()) arrow(s.v, -s.hi, s.hi, C.virt, [5, 4], 0.9);

      if (st.show.labels) {
        text('投影片', X(sx), Y(-half - 0.6) + 14, C.text, 'center', 12);
        if (!narrow) text('光源', X(sx - 4), Y(half + 0.6) - 12, C.muted, 'center', 12);
        text('屏幕', X(d) + 2, Y(-K.screen) + 12, C.text, 'center', 12);
        var base = Math.min(P.y + P.h - 14, P.cy + Math.max((half + 0.6) * P.s + 34, (K.R + 2) * P.s + 10));
        dim(-s.u, 0, base, 'u = ' + s.u.toFixed(1) + ' cm', C.text);
        if (s.real && s.v < xr()) dim(0, s.v, base + 20, 'v = ' + s.v.toFixed(1) + ' cm', C.real);
        else if (s.real) tag('像在 ' + s.v.toFixed(0) + ' cm 处（画面外）→', W - 130, base + 20, C.real);
      }

      // 小窗：投影片、屏幕
      var bx = insetBoxes(lay, 1.15);
      var b0 = bx[0], sc0 = b0.h / (K.h * 1.7);
      insetFrame(b0.x, b0.y, b0.w, b0.h, '投影片（从投影仪后面朝屏幕看）');
      ctx.fillStyle = '#1a2231'; ctx.fillRect(b0.x, b0.y, b0.w, b0.h);
      ctx.fillStyle = 'rgba(220,235,255,0.85)';
      ctx.fillRect(b0.x + b0.w / 2 - K.h * 0.65 * sc0, b0.y + b0.h / 2 - K.h * 0.65 * sc0, K.h * 1.3 * sc0, K.h * 1.3 * sc0);
      ctx.fillStyle = C.ink; draw2(ctx, letterF, b0.x + b0.w / 2, b0.y + b0.h / 2, K.h * sc0, st.flip);
      insetEnd(b0.x, b0.y, b0.w, b0.h);

      var b1 = bx[1], sc1 = b1.h / (2 * K.screen);
      insetFrame(b1.x, b1.y, b1.w, b1.h, '屏幕上看到的');
      ctx.fillStyle = '#2a313d'; ctx.fillRect(b1.x, b1.y, b1.w, b1.h);
      if (s.real) {
        var m = Math.abs(s.m), patch = K.h * 1.3 * m * sc1, a = Math.min(1, 0.45 + 0.4 * s.bright);
        withBlur(b1.x, b1.y, b1.w, b1.h, s.blur / 2 * sc1, function (c, w, h) {
          c.fillStyle = 'rgba(255,246,220,' + a + ')';
          c.fillRect(w / 2 - patch / 2, h / 2 - patch / 2, patch, patch);
          c.fillStyle = 'rgba(43,39,34,0.92)';
          draw2(c, letterF, w / 2, h / 2, K.h * m * sc1, !st.flip);
        });
        if (!s.fit) center(b1, '像比屏幕还大', C.bad, 13);
      } else {
        var g = ctx.createRadialGradient(b1.x + b1.w / 2, b1.y + b1.h / 2, 0, b1.x + b1.w / 2, b1.y + b1.h / 2, b1.h * 0.45);
        g.addColorStop(0, 'rgba(255,246,220,0.35)'); g.addColorStop(1, 'rgba(255,246,220,0)');
        ctx.fillStyle = g; ctx.fillRect(b1.x, b1.y, b1.w, b1.h);
        center(b1, s.none ? '只有一片光，不成像' : '只有一片光，接不到像', C.text, 12);
      }
      insetEnd(b1.x, b1.y, b1.w, b1.h, false, s.sharp && s.fit ? 'rgba(126,224,129,0.6)' : C.frame);
    }

    // ---------- 场景三：放大镜 ----------
    function pageText(c, w, h, k, fs) {
      c.fillStyle = C.paper; c.fillRect(-w, -h, 3 * w, 3 * h);
      c.save();
      c.translate(w / 2, h / 2); c.scale(k, k);
      c.fillStyle = C.ink;
      c.font = '600 ' + fs + 'px "PingFang SC", "Microsoft YaHei", sans-serif';
      c.textAlign = 'center'; c.textBaseline = 'middle';
      var rows = ['透镜成像规律', '物近像远像变大', '照相机投影仪', '放大镜看蚂蚁', '凸透镜会聚光'];
      for (var i = 0; i < rows.length; i++) c.fillText(rows[i], 0, (i - 2) * fs * 1.6);
      c.restore();
    }

    function drawMagnifier(st, s) {
      var lay = layout(), f = st.f, K = L.MAG, e = st.eye;
      pane(lay.py, lay.ph, narrow ? -40 : -50, narrow ? 30 : 36, 12);
      background();

      var T = [-s.u, K.h], I = s.none ? null : [s.v, s.hi];
      // 进入瞳孔的光束：从像点（或好像从虚像点）射向瞳孔上下边缘的直线与透镜的交点
      if (st.show.beam && I && Math.abs(e - I[0]) > 0.5) {
        var pr = 0.6, ys = [pr, -pr].map(function (py) { return I[1] + (py - I[1]) * (0 - I[0]) / (e - I[0]); });
        if (Math.max(Math.abs(ys[0]), Math.abs(ys[1])) < K.R) {
          ctx.beginPath();
          ctx.moveTo(X(T[0]), Y(T[1])); ctx.lineTo(X(0), Y(ys[0])); ctx.lineTo(X(e), Y(pr));
          ctx.lineTo(X(e), Y(-pr)); ctx.lineTo(X(0), Y(ys[1])); ctx.closePath();
          ctx.fillStyle = 'rgba(255,209,102,0.22)'; ctx.fill();
          if (!s.real) ys.forEach(function (yy) { line(0, yy, I[0], I[1], 'rgba(201,167,255,0.55)', 1, [4, 4]); });
        }
      }
      lens(f, K.R, st.show.rays ? rayExtent(s, T) : 0);
      foci(f, st.show.labels);
      if (st.show.rays) specialRays(T, s, null);

      // 书页（物）
      ctx.fillStyle = 'rgba(239,230,210,0.25)'; ctx.fillRect(X(-s.u) - 4, Y(K.h + 2), 4, (K.h + 4) * P.s);
      arrow(-s.u, 0, K.h, C.real);
      var imgOn = I && I[0] > xl() && I[0] < xr();
      if (imgOn) arrow(I[0], 0, I[1], s.real ? C.real : C.virt, s.real ? null : [5, 4], s.real ? 0.9 : 1);
      eye(X(e), P.cy, Math.max(1, Math.min(1.7, P.s / 9)));

      if (st.show.labels) {
        text('书上的字', X(-s.u), P.cy + 30, C.text, 'center', 12);
        text('眼睛', X(e) + 14, P.cy + 22, C.muted, 'center', 12);
        if (imgOn) {
          var ty = Y(I[1]) + (I[1] > 0 ? -16 : 16);
          tag(s.real ? '倒立的实像' : '正立 · 放大 · 虚像', X(I[0]), Math.max(P.y + 12, Math.min(P.y + P.h - 12, ty)), s.real ? C.real : C.virt);
        } else if (s.none) tag('u = f：折射光平行，不成像', X(-f), Y(K.h) - 30, C.muted);
        else tag((s.real ? '实像在右侧 ' : '← 虚像在左侧 ') + Math.abs(s.v).toFixed(0) + ' cm 处（画面外）', s.real ? W - 150 : 150, Y(K.h) - 34, s.real ? C.real : C.virt);
        var base = Math.min(P.y + P.h - 14, Math.max(P.cy + 52, P.cy + (K.R + 1.6) * P.s));
        dim(-s.u, 0, base, 'u = ' + s.u.toFixed(1) + ' cm', C.text);
        if (imgOn) dim(Math.min(0, I[0]), Math.max(0, I[0]), base + 20, (s.real ? 'v = ' : '|v| = ') + Math.abs(s.v).toFixed(1) + ' cm', s.real ? C.real : C.virt);
      }

      // 小窗：直接看、透过放大镜看（按像的放大率缩放，超出眼睛调节范围就模糊）
      var bx = insetBoxes(lay, 1), fs = Math.max(9, bx[0].h / 11);
      var k = s.none ? 6 : Math.max(-6, Math.min(6, s.m));
      var b0 = bx[0];
      insetFrame(b0.x, b0.y, b0.w, b0.h, '直接看', true);
      withBlur(b0.x, b0.y, b0.w, b0.h, Math.min(8, s.excessNaked * 60), function (c, w, h) { pageText(c, w, h, 1, fs); });
      insetEnd(b0.x, b0.y, b0.w, b0.h, true, '#3a4558');
      var b1 = bx[1], col = s.status === 'virtual' ? C.virt : s.status === 'inverted' ? C.real : C.lensEdge;
      insetFrame(b1.x, b1.y, b1.w, b1.h, '透过放大镜看', true, col);
      withBlur(b1.x, b1.y, b1.w, b1.h, Math.min(16, s.excess * 60), function (c, w, h) { pageText(c, w, h, k, fs); });
      ctx.fillStyle = 'rgba(143,208,255,0.08)'; ctx.fillRect(b1.x, b1.y, b1.w, b1.h);
      insetEnd(b1.x, b1.y, b1.w, b1.h, true, '#8fd0ff');
    }

    // ---------- 主绘制 ----------
    function draw(st, s) {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, W, H);
      if (st.scene === 'camera') drawCamera(st, s);
      else if (st.scene === 'projector') drawProjector(st, s);
      else drawMagnifier(st, s);
    }

    // ---------- 命中与坐标 ----------
    function toWorld(px, py) { return { x: (px - P.cx) / P.s, y: (P.cy - py) / P.s }; }
    function hit(px, py, st, s) {
      if (!P || py < P.y) return null;
      var sc = st.scene, K = sc === 'camera' ? L.CAM : sc === 'projector' ? L.PROJ : L.MAG;
      if (sc === 'projector' && Math.abs(px - X(s.d) - 2) < 14 && Math.abs(py - P.cy) < K.screen * P.s) return { what: 'screen' };
      if (sc === 'magnifier' && Math.abs(px - X(st.eye) - 14) < 26 && Math.abs(py - P.cy) < 22) return { what: 'eye' };
      var top = sc === 'camera' ? K.H / 2 : sc === 'projector' ? K.h / 2 + 1 : K.h + 1;
      var bot = sc === 'magnifier' ? -1 : -top;
      var halfW = Math.max(16, (sc === 'camera' ? K.H * 0.3 : 0.8) * P.s);
      if (sc === 'projector' && Math.abs(px - X(-st.u + -5)) < 18 && Math.abs(py - P.cy) < 20) return { what: 'obj' };
      if (Math.abs(px - X(-st.u)) < halfW && py > Y(top) - 10 && py < Y(bot) + 10) return { what: 'obj' };
      return null;
    }

    return {
      resize: resize, draw: draw, hit: hit, toWorld: toWorld,
      xRange: function () { return P ? [xl(), xr()] : [-50, 50]; }
    };
  }

  window.UseDraw = UseDraw;
})();
