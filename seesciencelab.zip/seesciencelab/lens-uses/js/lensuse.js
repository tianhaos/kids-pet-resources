// 生活中的透镜：照相机、投影仪、放大镜的成像计算（纯函数，不碰 DOM）
// 世界单位 cm，凸透镜光心在原点，物在左（u > 0），v > 0 实像在右、v < 0 虚像在左（同 shared/optics.js）。
// 照相机的树、投影仪的投影片以主光轴为中心（只追踪顶端），放大镜下的字立在主光轴上。
(function () {
  var O = window.Optics;

  // 各场景参数：f 焦距范围、R 透镜半径（光束口径）、物体尺寸、可移动范围
  var CAM  = { f: [4, 8], f0: 6, R: 1.8, H: 12, film: 3, u: [1.3, 60], dMax: 3, sharp: 0.04 };
  var PROJ = { f: [6, 10], f0: 8, R: 2.6, h: 6, screen: 20, u: [0.5, 2.5], xMax: 64, sharp: 0.12 };
  var MAG  = { f: [6, 15], f0: 10, R: 4.5, h: 2.5, u: [0.2, 2.5], eye: [3, 40], near: 10 };

  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }

  // 物体顶端 (−u, h) 发出的三条特殊光线：k 入射斜率，y 打到透镜的高度，ko 出射斜率
  // ① 平行于主光轴 → 过右焦点；② 过光心 → 方向不变；③ 过左焦点（u < f 时"好像从 F 发出"）→ 平行于主光轴
  function rays(u, h, f) {
    var list = [
      { k: 0, y: h, ko: -h / f },
      { k: -h / u, y: 0, ko: -h / u }
    ];
    if (Math.abs(u - f) > 1e-6) { var k3 = -h / (u - f); list.push({ k: k3, y: h + k3 * u, ko: 0 }); }
    else list.push({ k: NaN, y: NaN, ko: 0 });
    return list;
  }

  // 一个物点成像在 v 处，光束（透镜半径 R）在 x = d 的屏上形成的光斑直径
  function spot(R, d, v) {
    if (!isFinite(v)) return 2 * R;
    return 2 * R * Math.abs(d - v) / Math.abs(v);
  }

  function base(u, h, f) {
    var im = O.image(u, f), z = O.zone(u, f);
    var none = !isFinite(im.v);
    return {
      u: u, f: f, h: h, v: im.v, m: none ? Infinity : im.m, none: none,
      real: !none && im.v > 0, hi: none ? Infinity : im.m * h, zone: z, rays: rays(u, h, f)
    };
  }

  // 照相机：st = { f, u, d（镜头到底片的距离）, auto（自动对焦）}
  function camera(st) {
    var f = st.f, s = base(st.u, CAM.H / 2, f), dMin = f, dMax = CAM.dMax * f;
    s.R = CAM.R;
    s.reach = s.real && s.v <= dMax;                    // 镜头能伸到像的位置
    s.d = st.auto ? (s.real ? clamp(s.v, dMin, dMax) : dMax) : clamp(st.d, dMin, dMax);
    s.dRange = [dMin, dMax];
    s.blur = s.none ? 2 * CAM.R : spot(CAM.R, s.d, s.v);
    s.sharp = s.real && s.blur < CAM.sharp;
    s.fit = s.real && Math.abs(s.hi) <= CAM.film + 1e-9;   // 像（以主光轴为中心）能否全部落在底片上
    s.status = !s.real ? 'virtual' : !s.reach && st.auto ? 'reach' : !s.sharp ? 'blur' : !s.fit ? 'crop' : 'ok';
    return s;
  }

  // 投影仪：st = { f, u, d（镜头到屏幕的距离）, auto }
  function projector(st) {
    var f = st.f, s = base(st.u, PROJ.h / 2, f), dMin = f + 1, dMax = PROJ.xMax;
    s.R = PROJ.R;
    s.reach = s.real && s.v <= dMax;
    s.d = st.auto ? (s.real ? clamp(s.v, dMin, dMax) : dMax * 0.6) : clamp(st.d, dMin, dMax);
    s.dRange = [dMin, dMax];
    s.blur = s.none ? 2 * PROJ.R : spot(PROJ.R, s.d, s.v);
    s.sharp = s.real && s.blur < PROJ.sharp;
    s.fit = s.real && Math.abs(s.hi) <= PROJ.screen;
    // 屏上亮度：同样的光摊在 m² 倍的面积上（以 m = 2 时为 1）
    s.bright = s.real ? clamp(4 / (s.m * s.m), 0.12, 1.6) : 0;
    s.status = s.none ? 'none' : !s.real ? 'virtual' : !s.reach && st.auto ? 'reach' : !s.sharp ? 'blur' : !s.fit ? 'crop' : 'ok';
    return s;
  }

  // 放大镜：st = { f, u, eye（眼睛到透镜的距离）}
  // 眼睛能看清：进入眼睛的光从 ≥ NEAR 处发散而来或平行（会聚度 Ve ∈ [−1/NEAR, 0]），超出部分换算成模糊。
  function magnifier(st) {
    var f = st.f, u = st.u, e = st.eye, s = base(u, MAG.h, f);
    s.R = MAG.R; s.eye = e;
    var Vl = 1 / f - 1 / u;                                        // 透镜后光的会聚度（1/cm，正为会聚）
    var q = 1 - e * Vl;
    var Ve = Math.abs(q) < 1e-6 ? Infinity : Vl / q;
    s.excess = Ve > 0 ? Ve : Ve < -1 / MAG.near ? -1 / MAG.near - Ve : 0;
    var Vn = -1 / (u + e);
    s.excessNaked = Vn < -1 / MAG.near ? -1 / MAG.near - Vn : 0;
    s.clear = s.excess < 0.02;
    s.status = s.none ? 'none' : !s.real ? 'virtual' : s.clear ? 'inverted' : 'blur';
    return s;
  }

  window.LensUse = {
    CAM: CAM, PROJ: PROJ, MAG: MAG,
    rays: rays, spot: spot, camera: camera, projector: projector, magnifier: magnifier, clamp: clamp
  };
})();
