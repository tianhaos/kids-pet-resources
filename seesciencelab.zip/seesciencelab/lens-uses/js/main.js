(function () {
  var L = window.LensUse;
  var $ = function (id) { return document.getElementById(id); };
  var qa = function (sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); };

  var state = {
    scene: 'camera',
    camera:    { f: L.CAM.f0, u: 30, d: 6, auto: true },
    projector: { f: L.PROJ.f0, u: 10.5, d: 40, auto: true, flip: true },
    magnifier: { f: L.MAG.f0, u: 6, eye: 8 },
    show: { rays: true, beam: true, labels: true },
    t: 0
  };
  var CFG = { camera: L.CAM, projector: L.PROJ, magnifier: L.MAG };
  var SOLVE = { camera: L.camera, projector: L.projector, magnifier: L.magnifier };
  var HINTS = {
    camera: '拖动树改变物距 · 看底片上的像怎样变',
    projector: '拖动投影片、屏幕 · 让屏幕上出现清晰、放大的像',
    magnifier: '拖动书上的字、眼睛 · 看放大镜里的像'
  };
  var SNAP_PX = 8;

  var stage = $('stage'), canvas = $('ray'), panel = $('panel');
  var view = window.UseDraw(canvas);
  var sol = null;

  function cur() { return state[state.scene]; }
  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
  function setSeg(attr, val) { qa('[data-' + attr + ']').forEach(function (b) { b.classList.toggle('on', b.dataset[attr] === val); }); }
  function uRange(sc) {
    var c = state[sc], K = CFG[sc];
    return sc === 'camera' ? [K.u[0] * c.f, K.u[1]] : [K.u[0] * c.f, K.u[1] * c.f];
  }
  function viewState() {
    var c = cur(), v = { scene: state.scene, show: state.show };
    for (var k in c) v[k] = c[k];
    return v;
  }
  function solve() { return SOLVE[state.scene](cur()); }
  function track(act, label) { if (window.Analytics) Analytics.track('生活中的透镜', act, label); }

  // ---------- 场景 ----------
  qa('[data-scene]').forEach(function (b) {
    b.addEventListener('click', function () { setScene(b.dataset.scene); track('场景', b.textContent); });
  });
  function setScene(sc) { state.scene = sc; syncUI(); }

  // ---------- 控件 ----------
  var uEl = $('u'), fEl = $('focal'), dEl = $('dist'), eyeEl = $('eyeX');
  uEl.addEventListener('input', function () { cur().u = parseFloat(uEl.value); syncUI(); });
  fEl.addEventListener('input', function () {
    var c = cur(), k = c.u / c.f;
    c.f = parseFloat(fEl.value);
    var r = uRange(state.scene);
    c.u = clamp(k * c.f, r[0], r[1]);                     // 保持 u/f，区间不跳
    syncUI();
  });
  dEl.addEventListener('input', function () { var c = cur(); c.d = parseFloat(dEl.value); c.auto = false; syncUI(); });
  eyeEl.addEventListener('input', function () { state.magnifier.eye = parseFloat(eyeEl.value); syncUI(); });
  $('autoOn').addEventListener('change', function () {
    cur().auto = $('autoOn').checked;
    if (cur().auto) track('自动对焦', state.scene);
    syncUI();
  });
  $('focusBtn').addEventListener('click', focusNow);
  function focusNow() {
    var c = cur(), s = solve();
    if (s.real) c.d = clamp(s.v, s.dRange[0], s.dRange[1]);
    track('对焦', state.scene);
    syncUI();
  }
  $('flip').addEventListener('change', function () { state.projector.flip = $('flip').checked; track('投影片倒放', String(state.projector.flip)); });
  qa('[data-k]').forEach(function (b) {
    b.addEventListener('click', function () {
      var c = cur(), r = uRange(state.scene);
      c.u = clamp(parseFloat(b.dataset.k) * c.f, r[0], r[1]);
      track('预设', b.textContent);
      syncUI();
    });
  });
  [['showRays', 'rays'], ['showBeam', 'beam'], ['showLabels', 'labels']].forEach(function (p) {
    $(p[0]).addEventListener('change', function () { state.show[p[1]] = $(p[0]).checked; });
  });

  // ---------- 拖动 ----------
  var drag = null;
  function localXY(e) { var r = canvas.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; }
  function snap(x, targets) {
    var tol = view.toWorld(SNAP_PX, 0).x - view.toWorld(0, 0).x;
    targets.forEach(function (t) { if (Math.abs(x - t) < tol) x = t; });
    return x;
  }
  function dragTo(px, py) {
    var w = view.toWorld(px, py), c = cur(), rg = view.xRange();
    if (drag.what === 'obj') {
      var r = uRange(state.scene);
      c.u = snap(clamp(-w.x - drag.off, r[0], Math.min(r[1], -rg[0] - 1)), [c.f, 2 * c.f]);
    } else if (drag.what === 'screen') {
      c.auto = false;
      c.d = clamp(w.x - drag.off, sol.dRange[0], sol.dRange[1]);
      if (sol.real && Math.abs(c.d - sol.v) < 0.6) c.d = sol.v;            // 靠近像的位置时吸附
    } else if (drag.what === 'eye') {
      c.eye = clamp(w.x - drag.off, L.MAG.eye[0], Math.min(L.MAG.eye[1], rg[1] - 3));
    }
    syncUI();
  }
  canvas.addEventListener('pointerdown', function (e) {
    var p = localXY(e);
    drag = view.hit(p[0], p[1], viewState(), sol);
    if (!drag) return;
    var w = view.toWorld(p[0], p[1]), c = cur();
    drag.off = drag.what === 'obj' ? -w.x - c.u : drag.what === 'screen' ? w.x - sol.d : w.x - c.eye;
    try { canvas.setPointerCapture(e.pointerId); } catch (err) { /* 合成事件无法捕获指针 */ }
    canvas.classList.add('grabbing');
    track('拖动', drag.what);
  });
  canvas.addEventListener('pointermove', function (e) {
    var p = localXY(e);
    if (!drag) { canvas.classList.toggle('grab', !!view.hit(p[0], p[1], viewState(), sol)); return; }
    dragTo(p[0], p[1]);
  });
  function endDrag(e) {
    if (!drag) return;
    drag = null;
    canvas.classList.remove('grabbing');
    if (canvas.hasPointerCapture(e.pointerId)) canvas.releasePointerCapture(e.pointerId);
  }
  canvas.addEventListener('pointerup', endDrag);
  canvas.addEventListener('pointercancel', endDrag);

  $('panelToggle').addEventListener('click', function () { panel.classList.toggle('collapsed'); });
  if (window.matchMedia('(max-width: 760px)').matches) panel.classList.add('collapsed');

  // ---------- 面板同步 ----------
  function syncUI() {
    var sc = state.scene, c = cur(), K = CFG[sc], r = uRange(sc);
    setSeg('scene', sc);
    qa('[data-for]').forEach(function (el) { el.hidden = el.dataset.for.split(' ').indexOf(sc) < 0; });
    $('hint').textContent = HINTS[sc];
    uEl.min = r[0].toFixed(1); uEl.max = r[1]; uEl.step = 0.1; uEl.value = c.u;
    $('uOut').textContent = c.u.toFixed(1) + ' cm';
    $('uLabel').textContent = sc === 'camera' ? '树到镜头' : sc === 'projector' ? '投影片' : '字到镜';
    fEl.min = K.f[0]; fEl.max = K.f[1]; fEl.value = c.f;
    $('focalOut').textContent = c.f.toFixed(1) + ' cm';
    if (sc !== 'magnifier') {
      var s = solve();
      dEl.min = s.dRange[0]; dEl.max = s.dRange[1]; dEl.step = sc === 'camera' ? 0.01 : 0.1;
      if (c.auto) c.d = s.d;
      dEl.value = c.d;
      setText('distOut', cm(c.d, sc === 'camera' ? 2 : 1));
      $('distLabel').textContent = sc === 'camera' ? '镜头到底片' : '屏幕位置';
      $('autoOn').checked = c.auto;
      $('autoText').textContent = sc === 'camera' ? '自动对焦' : '屏幕自动移到清晰处';
      $('focusBtn').textContent = sc === 'camera' ? '对焦一次' : '把屏幕移到像的位置';
    }
    $('flip').checked = state.projector.flip;
    eyeEl.value = state.magnifier.eye; $('eyeOut').textContent = state.magnifier.eye.toFixed(0) + ' cm';
    qa('[data-k]').forEach(function (b) { b.classList.toggle('on', Math.abs(parseFloat(b.dataset.k) * c.f - c.u) < 0.05); });
  }

  // ---------- 读数 ----------
  var last = {};
  function setText(id, s) { if (last[id] !== s) { last[id] = s; $(id).textContent = s; } }
  function rows(list) {
    for (var k = 1; k <= 5; k++) {
      var r = list[k - 1] || ['', ''];
      setText('d' + k, r[0]); setText('r' + k, r[1]);
      $('d' + k).hidden = $('r' + k).hidden = !r[0];
    }
  }
  function setBig(str, cls) { setText('rState', str); $('rState').className = cls || ''; }
  function cm(a, n) { return a.toFixed(n == null ? 1 : n) + ' cm'; }
  function times(m) {
    var a = Math.abs(m);
    if (!isFinite(a)) return '—';
    return a < 1 ? '缩小为物体的 1/' + (1 / a).toFixed(1) : '放大 ' + a.toFixed(1) + ' 倍';
  }
  function kf(s) { return '（= ' + (s.u / s.f).toFixed(2) + ' f）'; }
  function nature(s) { return s.none ? '不成像' : s.zone.nature; }

  function readCamera(s) {
    var c = state.camera, z = s.zone.key;
    setBig(nature(s), s.real ? 'real' : 'virt');
    var tip;
    if (s.status === 'reach') tip = '物体太近，像距超过了镜头能伸出的长度，对不上焦。照相机的物距要大于 2 倍焦距。';
    else if (s.status === 'blur') tip = '底片不在像的位置，照片模糊：像在底片' + (s.v > s.d ? '后方，镜头要往前伸（远离底片）' : '前方，镜头要往回缩（靠近底片）') + '，或打开「自动对焦」。';
    else if (s.status === 'crop') tip = '像比底片还大，拍不全。人要往后退（增大物距），像才会变小——物远像近像变小。';
    else if (z !== 'far') tip = '物体在 f 与 2f 之间时成放大的像，照相机一般不这样用；照相机的物距要大于 2f。';
    else tip = '物体在 2 倍焦距以外，底片上成倒立、缩小的实像，像距在 f 与 2f 之间。物体越远，像越小，像距越接近焦距。';
    setText('rTip', tip);
    rows([
      ['物距 u', cm(s.u) + kf(s)],
      ['像距 v', s.real ? cm(s.v, 2) + (z === 'far' ? '（f < v < 2f）' : '') : '—'],
      ['镜头到底片', cm(s.d, 2) + (s.sharp ? '（对准了，清晰）' : '（没对准，模糊）')],
      ['像的大小', times(s.m)],
      ['镜头焦距', cm(c.f) + (c.f >= 7 ? '（长焦：同样距离拍得更大）' : '')]
    ]);
  }

  function readProjector(s) {
    var c = state.projector, z = s.zone.key;
    setBig(nature(s), s.real ? 'real' : s.none ? '' : 'virt');
    var tip;
    if (s.status === 'none') tip = '投影片在焦点上，折射光平行射出，不成像，屏幕上只有一片光。';
    else if (s.status === 'virtual') tip = '投影片在焦点以内，成正立、放大的虚像，屏幕上接不到像（那是放大镜的用法）。';
    else if (s.status === 'reach') tip = '投影片离焦点太近，像距超过 ' + L.PROJ.xMax + ' cm，屏幕放不下：把投影片往远离镜头的方向移一点。';
    else if (s.status === 'blur') tip = '屏幕不在像的位置，像模糊：把屏幕往' + (s.v > s.d ? '后移（远离镜头）' : '前移（靠近镜头）') + '，或打开「屏幕自动移到清晰处」。';
    else if (s.status === 'crop') tip = '像比屏幕还大：把投影片往远离镜头的方向移，同时让屏幕靠近镜头。';
    else if (z === 'far' || z === 'double') tip = '投影片在 2f 或更远处，成' + (z === 'far' ? '缩小' : '等大') + '的像（照相机的用法）。投影仪的物距要在 f 与 2f 之间。';
    else if (!c.flip) tip = '投影片正着放，屏幕上的 F 是倒的（上下、左右都颠倒）——所以投影片要倒着放。';
    else tip = '投影片在 f 与 2f 之间，屏幕上成倒立、放大的实像。想让像更大：镜头靠近投影片（物距变小），屏幕离远一些（像距变大）——物近像远像变大。';
    setText('rTip', tip);
    rows([
      ['物距 u', cm(s.u) + kf(s)],
      ['像距 v', s.real ? cm(s.v) + (z === 'mid' ? '（v > 2f）' : '') : s.none ? '—' : '虚像，|v| = ' + cm(-s.v)],
      ['镜头到屏幕', cm(s.d) + (s.sharp ? '（清晰）' : '（模糊）')],
      ['像的大小', s.none ? '—' : times(s.m)],
      ['屏上亮度', s.real ? (s.bright * 100 / 1.6).toFixed(0) + '%（像越大越暗）' : '—']
    ]);
  }

  function readMagnifier(s) {
    var c = state.magnifier;
    setBig(nature(s), s.status === 'virtual' ? 'virt' : s.real ? 'real' : '');
    var tip;
    if (s.status === 'virtual') tip = '字在焦点以内，透过放大镜看到正立、放大的虚像，像和字在透镜同侧。字越靠近焦点，像越大、也离得越远。';
    else if (s.status === 'none') tip = '字正好在焦点上：折射光平行射出，不成像。放大镜要让物距小于焦距。';
    else if (s.status === 'inverted') tip = '字在焦点以外，成倒立的实像；眼睛离得足够远时能看到倒立的字。用放大镜时要让它靠近物体（物距小于焦距）。';
    else tip = '字在焦点以外，倒立的实像落在眼睛附近或眼睛后面，眼睛看到的是一片模糊。把放大镜移近字（u < f）。';
    setText('rTip', tip);
    rows([
      ['物距 u', cm(s.u) + kf(s)],
      ['像距', s.none ? '—' : s.real ? 'v = ' + cm(s.v) + '（实像，在透镜另一侧）' : '|v| = ' + cm(-s.v) + '（虚像，与字同侧）'],
      ['像的大小', s.none ? '—' : times(s.m) + (s.m < 0 ? '，倒立' : '，正立')],
      ['眼睛到镜', cm(c.eye, 0) + (s.clear ? '（看得清）' : '（看不清）')],
      ['焦距', cm(c.f) + '（焦距越短，放大作用越强）']
    ]);
  }

  // ---------- 尺寸与主循环 ----------
  function resize() { view.resize(stage.clientWidth, stage.clientHeight); }
  new ResizeObserver(resize).observe(stage);

  // 支持 ?scene=camera|projector|magnifier、&f=焦距、&u=物距(cm)、&flip=0、&auto=0
  var qs = new URLSearchParams(location.search);
  if (HINTS[qs.get('scene')]) state.scene = qs.get('scene');
  (function () {
    var c = cur(), K = CFG[state.scene], fq = parseFloat(qs.get('f')), uq = parseFloat(qs.get('u'));
    if (fq >= K.f[0] && fq <= K.f[1]) c.f = fq;
    var r = uRange(state.scene);
    if (uq > 0) c.u = clamp(uq, r[0], r[1]);
    if (qs.get('auto') === '0' && 'auto' in c) c.auto = false;
    if (qs.get('flip') === '0') state.projector.flip = false;
  })();

  resize();
  setScene(state.scene);

  var lastT = performance.now();
  function frame(t) {
    var dt = Math.min((t - lastT) / 1000, 0.1);
    lastT = t;
    state.t += dt;
    var c = cur(), rg = view.xRange();
    c.u = Math.min(c.u, -rg[0] - 1);                                  // 窄屏时物体别跑出画面
    if (state.scene === 'magnifier') c.eye = Math.min(c.eye, rg[1] - 3);
    sol = solve();
    if (c.auto) { c.d = sol.d; if (!drag) { dEl.value = c.d; setText('distOut', cm(c.d, state.scene === 'camera' ? 2 : 1)); } }
    view.draw(viewState(), sol);
    if (state.scene === 'camera') readCamera(sol);
    else if (state.scene === 'projector') readProjector(sol);
    else readMagnifier(sol);
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // 调试用
  window.__model = { state: state, setScene: setScene, solve: solve, focusNow: focusNow, syncUI: syncUI };
})();
