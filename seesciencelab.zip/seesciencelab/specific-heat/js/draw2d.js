/* 画布：宽屏、手机共用归一化装置布局；温度与曲线全部取自 Heat.sample。 */
(function () {
  'use strict';
  const colors = ['#6bd8ff', '#ffd087'];
  let ctx, w, h, layout;
  function text(str, x, y, size, color, align) {
    ctx.fillStyle = color || '#dce9f4';
    ctx.font = `${size || 13}px -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif`;
    ctx.textAlign = align || 'center'; ctx.fillText(str, x, y);
  }
  function line(points, color, width, dash) {
    ctx.beginPath(); points.forEach((p, i) => i ? ctx.lineTo(...p) : ctx.moveTo(...p));
    ctx.strokeStyle = color; ctx.lineWidth = width || 1; ctx.setLineDash(dash || []);
    ctx.stroke(); ctx.setLineDash([]);
  }
  function rect(x, y, rw, rh, radius, fill, stroke) {
    ctx.beginPath(); ctx.roundRect(x, y, rw, rh, radius); if (fill) { ctx.fillStyle = fill; ctx.fill(); }
    if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = 1; ctx.stroke(); }
  }
  function ellipse(x, y, rx, ry, fill, stroke) {
    ctx.beginPath(); ctx.ellipse(x, y, rx, ry, 0, 0, Math.PI * 2);
    if (fill) { ctx.fillStyle = fill; ctx.fill(); }
    if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = 1; ctx.stroke(); }
  }
  function geometry(width, height) {
    const compact = width < 600;
    const unit = Math.min(compact ? width / 390 : width / 950, (height - 330) / 368, 1.35);
    const cy = 125 + 118 * unit;
    const cupW = (compact ? 115 : 170) * unit;
    const cupH = 140 * unit;
    const centers = compact ? [width * .26, width * .74] : [width * .29, width * .71];
    const cups = centers.map(x => ({ x, y: cy, width: cupW, height: cupH, bottom: cy + cupH / 2 }));
    const graphTop = cy + cupH / 2 + 180 * unit;
    const graph = { x: compact ? 44 : 70, y: graphTop, width: width - (compact ? 68 : 110), height: Math.max(38, height - graphTop - (compact ? 178 : 143)) };
    return { compact, unit, cups, graph };
  }
  function cup(s, i, data, clock) {
    const { unit: u, cups, compact } = layout;
    const b = cups[i], x = b.x, y = b.y, cw = b.width, ch = b.height;
    const left = x - cw / 2, top = y - ch / 2, bottom = b.bottom;
    const fillHeight = ch * (i === 0 ? .56 : .35) * Math.pow(data.m / .2, .55);
    const surface = bottom - Math.min(fillHeight, ch * .87);
    // 玻璃器皿：背侧口沿、液体/沙体、前侧透明边缘。
    ellipse(x, top, cw / 2, 8 * u, '#8edaf006', '#8baab055');
    ctx.save();
    ctx.beginPath(); ctx.rect(left + 3, top + 1, cw - 6, ch - 2); ctx.clip();
    const grad = ctx.createLinearGradient(0, surface, 0, bottom);
    if (i === 0) { grad.addColorStop(0, '#46c4eb88'); grad.addColorStop(1, '#156788cc'); }
    else { grad.addColorStop(0, '#d2b17b'); grad.addColorStop(1, '#8d6339'); }
    ctx.fillStyle = grad; ctx.fillRect(left + 2, surface, cw - 4, bottom - surface);
    if (i === 0) {
      ctx.beginPath();
      for (let n = 0; n <= 60; n++) {
        const px = left + n / 60 * cw;
        const py = surface + Math.sin(n * .33 + s.t * .08) * 1.6 * u;
        n ? ctx.lineTo(px, py) : ctx.moveTo(px, py);
      }
      ctx.strokeStyle = '#b5f2ff'; ctx.lineWidth = 2; ctx.stroke();
      // 示意液面，不把装饰泡当作沸腾；本模型最高仅80℃。
      for (let k = 0; k < 4; k++) {
        line([[left + cw * .15, surface + (k + 1) * 14 * u], [left + cw * .4, surface + (k + 1) * 14 * u]], '#b3f0ff20');
      }
    } else {
      for (let k = 0; k < 160; k++) {
        const rx = ((k * 73 + 19) % 163) / 163;
        const ry = ((k * 47 + 7) % 157) / 157;
        ctx.fillStyle = k % 3 ? '#f4d89866' : '#60452f88';
        ctx.fillRect(left + rx * cw, surface + ry * (bottom - surface), 2 * u, 1.6 * u);
      }
    }
    ctx.restore();
    ctx.beginPath(); ctx.moveTo(left, top); ctx.lineTo(left, bottom - 8 * u);
    ctx.quadraticCurveTo(left, bottom + 5 * u, x, bottom + 5 * u);
    ctx.quadraticCurveTo(x + cw / 2, bottom + 5 * u, x + cw / 2, bottom - 8 * u);
    ctx.lineTo(x + cw / 2, top); ctx.strokeStyle = '#a9d7e9aa'; ctx.lineWidth = 2; ctx.stroke();
    line([[left + 8 * u, top + 10 * u], [left + 8 * u, bottom - 8 * u]], '#d6f4ff44', 3 * u);
    for (let tick = 1; tick < 5; tick++) {
      line([[left + cw - 17 * u, bottom - tick * ch / 5], [left + cw - 4 * u, bottom - tick * ch / 5]], '#c1d9df66');
    }
    // 酒精炉与三脚架；暂停冻结当前火焰，达到目标后该炉熄灭。
    const heating = data.on;
    const flameClock = s.play && !matchMedia('(prefers-reduced-motion: reduce)').matches ? clock : s.t * 100;
    const flicker = Math.sin(flameClock * .008 + i) * 1.5;
    // 支架、承托网先画在火焰后面，火焰位于烧杯正下方。
    line([[x - cw * .42, bottom + 7 * u], [x - cw * .48, bottom + 75 * u]], '#7e94a5', 3 * u);
    line([[x + cw * .42, bottom + 7 * u], [x + cw * .48, bottom + 75 * u]], '#7e94a5', 3 * u);
    line([[x - cw * .47, bottom + 7 * u], [x + cw * .47, bottom + 7 * u]], '#bdcdd5', 4 * u);
    for (let k = -4; k <= 4; k++) {
      line([[x + k * cw * .09, bottom + 4 * u], [x + k * cw * .09, bottom + 10 * u]], '#6c8293', u);
    }
    const fy = bottom + 44 * u;
    if (heating) {
      const glow = ctx.createRadialGradient(x, fy - 15 * u, 1, x, fy - 15 * u, 36 * u);
      glow.addColorStop(0, '#ffb54b33'); glow.addColorStop(1, '#ffb54b00');
      ctx.fillStyle = glow; ctx.fillRect(x - 38 * u, bottom + 4 * u, 76 * u, 60 * u);
      ctx.beginPath(); ctx.moveTo(x, fy);
      ctx.bezierCurveTo(x - 19 * u, fy - 6 * u, x - 8 * u, fy - 26 * u, x + flicker * u, fy - 37 * u);
      ctx.bezierCurveTo(x + 5 * u, fy - 23 * u, x + 19 * u, fy - 7 * u, x, fy);
      ctx.fillStyle = '#ffb54b'; ctx.fill();
      ctx.beginPath(); ctx.moveTo(x, fy);
      ctx.bezierCurveTo(x - 9 * u, fy - 3 * u, x - 5 * u, fy - 13 * u, x, fy - 21 * u);
      ctx.bezierCurveTo(x + 6 * u, fy - 12 * u, x + 9 * u, fy - 3 * u, x, fy);
      ctx.fillStyle = '#fff1ac'; ctx.fill();
      ellipse(x, fy - 1 * u, 6 * u, 3 * u, '#6dc9ff');
    }
    // 玻璃燃料壶、酒精液面、金属灯芯座和棉芯。
    const fuel = ctx.createLinearGradient(x - 26 * u, 0, x + 26 * u, 0);
    fuel.addColorStop(0, '#3e697b'); fuel.addColorStop(.4, '#7fabb8'); fuel.addColorStop(1, '#294b60');
    rect(x - 26 * u, bottom + 48 * u, 52 * u, 25 * u, 10 * u, fuel, '#b9d6de');
    rect(x - 22 * u, bottom + 61 * u, 44 * u, 9 * u, 4 * u, '#84d5e866');
    ellipse(x, bottom + 49 * u, 20 * u, 5 * u, '#bad2d9', '#d7e7ec');
    rect(x - 9 * u, bottom + 43 * u, 18 * u, 7 * u, 2 * u, '#95a7ad', '#d4e0e2');
    line([[x, bottom + 43 * u], [x, bottom + 39 * u]], '#e2cfaa', 3 * u);
    line([[x - 18 * u, bottom + 55 * u], [x - 18 * u, bottom + 63 * u]], '#d5f3fa77', 2 * u);
    const label = s.scene === 'rise' && data.seconds >= Heat.stopTimes(s)[i] - 1e-6
      ? '已达目标 · 熄火' : heating ? `酒精炉 · 吸收 ${s.power} W` : '实验结束 · 熄火';
    text(label, x, bottom + 84 * u, compact ? 11 : 12, heating ? '#e6c89d' : '#a9c6da');
    text(i === 0 ? '水' : '干沙', x, top - 48 * u, compact ? 16 : 18, colors[i]);
    text(`${data.m.toFixed(2)} kg`, x, top - 29 * u, 11, '#9fb7c7');
    text(`${data.temp.toFixed(1)}℃`, x, bottom + 112 * u, compact ? 18 : 20, colors[i]);
    text(`升高 ${data.rise.toFixed(1)}℃ · ${(data.q / 1000).toFixed(2)} kJ`, x, bottom + 133 * u, compact ? 11 : 12, '#b1c2d1');
  }
  function probe(s, i, data) {
    const p = s.probes[i], u = layout.unit;
    const x = p.x * w, y = p.y * h, len = 115 * u;
    ctx.save();
    ctx.shadowColor = '#7de1ff'; ctx.shadowBlur = s.drag === i ? 15 : 0;
    rect(x - 6 * u, y - len, 12 * u, len, 6 * u, '#e2f3f6e0', '#a8cee0');
    const temp = p.cup === null ? null : data[p.cup].temp;
    const f = temp === null ? .2 : temp / 100;
    rect(x - 2 * u, y - len * f, 4 * u, len * f, 2 * u, '#f56e62');
    ellipse(x, y, 8 * u, 8 * u, '#e9f4f5'); ellipse(x, y, 5 * u, 5 * u, '#f56e62');
    for (let t = 0; t <= 100; t += 20) {
      const ty = y - len * t / 100;
      line([[x + 7 * u, ty], [x + 12 * u, ty]], '#adcfdd');
    }
    ctx.restore();
    // 读数随探针移动；离开介质不报告环境温度。
    if (s.drag === i || temp === null) {
      const right = x > w - 85;
      text(temp === null ? '移入杯中' : `${temp.toFixed(1)}℃`, x + (right ? -18 : 18), y - len * .55, 11, '#f6c6ba', right ? 'right' : 'left');
    }
  }
  function curve(s, data) {
    const g = layout.graph, compact = layout.compact;
    const end = Heat.duration(s), ymax = s.scene === 'rise' ? 35 : 85;
    const px = t => g.x + t / end * g.width;
    const py = temp => g.y + g.height - (temp - 20) / (ymax - 20) * g.height;
    rect(g.x - 35, g.y - 25, g.width + 49, g.height + 60, 12, '#0b111c', '#243042');
    text('温度 / ℃', g.x, g.y - 10, 11, '#a4bbce', 'left');
    [20, s.scene === 'rise' ? 25 : 40, s.scene === 'rise' ? 30 : 60, s.scene === 'rise' ? 35 : 80].forEach(t => {
      line([[g.x, py(t)], [g.x + g.width, py(t)]], '#31455666');
      text(t.toString(), g.x - 10, py(t) + 4, 10, '#91a9bb', 'right');
    });
    for (let i = 0; i <= 4; i++) {
      const t = end * i / 4;
      text(t.toFixed(t % 1 ? 1 : 0), px(t), g.y + g.height + 19, 10, '#91a9bb');
    }
    text('时间 / s', g.x + g.width, g.y + g.height + 34, 10, '#a4bbce', 'right');
    [0, 1].forEach(i => {
      const points = [];
      for (let n = 0; n <= 100; n++) {
        const t = s.t * n / 100; points.push([px(t), py(Heat.sample(s, t)[i].temp)]);
      }
      line(points, colors[i], 2.5);
      ellipse(px(s.t), py(data[i].temp), 4, 4, colors[i]);
      text(i ? '干沙' : '水', g.x + g.width - (i ? 0 : 55), g.y - 10, 11, colors[i], 'right');
    });
    const t = s.hover === null ? s.t : s.hover;
    line([[px(t), g.y], [px(t), g.y + g.height]], '#c7e5f688', 1, [4, 4]);
    if (s.hover !== null) {
      const temps = Heat.sample(s, t);
      text(`${t.toFixed(1)}s  水 ${temps[0].temp.toFixed(1)}° / 沙 ${temps[1].temp.toFixed(1)}°`,
        g.x + g.width / 2, g.y - 34, compact ? 10 : 12, '#d6eaf5');
    }
  }
  function draw(canvas, s, clock) {
    const bounds = canvas.getBoundingClientRect(); w = bounds.width; h = bounds.height;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    if (canvas.width !== Math.round(w * dpr) || canvas.height !== Math.round(h * dpr)) {
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
    }
    ctx = canvas.getContext('2d'); ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.clearRect(0, 0, w, h);
    layout = geometry(w, h);
    const data = Heat.sample(s, s.t);
    // 台面透视、器皿阴影使装置容易辨认。
    const baseline = layout.cups[0].bottom + 76 * layout.unit;
    const gradient = ctx.createLinearGradient(0, baseline - 10, 0, baseline + 30);
    gradient.addColorStop(0, '#40566a44'); gradient.addColorStop(1, '#11223300');
    ctx.fillStyle = gradient; ctx.fillRect(0, baseline, w, 40);
    line([[20, baseline], [w - 20, baseline]], '#4b677855');
    layout.cups.forEach((b, i) => cup(s, i, data[i], clock));
    s.probes.forEach((p, i) => probe(s, i, data));
    curve(s, data);
    return layout;
  }
  function hitProbe(s, x, y) {
    const u = layout.unit;
    for (let i = s.probes.length - 1; i >= 0; i--) {
      const p = s.probes[i];
      if (Math.abs(x - p.x * w) < Math.max(22, 18 * u) && y > p.y * h - 130 * u && y < p.y * h + 22) return i;
    }
    return -1;
  }
  function hitCup(x, y) {
    return layout.cups.findIndex(b => Math.abs(x - b.x) < b.width / 2 && y > b.y - b.height / 2 && y < b.bottom + 5);
  }
  function homeProbe(s, i) {
    const b = layout.cups[i];
    s.probes[i] = { x: (b.x + b.width * .18) / w, y: (b.bottom - 27 * layout.unit) / h, cup: i };
  }
  function graphTime(s, x, y) {
    const g = layout.graph;
    return x >= g.x - 10 && x <= g.x + g.width + 10 && y >= g.y - 15 && y <= g.y + g.height + 25
      ? Heat.clamp((x - g.x) / g.width, 0, 1) * Heat.duration(s) : null;
  }
  window.HeatDraw = { draw, hitProbe, hitCup, homeProbe, graphTime };
})();
