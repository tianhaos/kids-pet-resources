(function () {
  'use strict';
  const $ = id => document.getElementById(id);
  const params = new URLSearchParams(location.search);
  const state = Heat.defaults(params.get('scene'));
  ['waterMass', 'sandMass'].forEach(k => state[k] = Heat.number(params.get(k), state[k], .1, .5));
  state.power = Heat.number(params.get('power'), state.power, 20, 100);
  state.t = Heat.number(params.get('t'), state.t, 0, Heat.duration(state));
  state.play = params.get('play') === '1';
  const canvas = $('experiment');
  let initialized = false, previous = 0, lastUI = 0, dragging = null, layout;
  const track = (action, label) => { if (window.Analytics) Analytics.track('比热容对比实验', action, String(label)); };
  function refresh() {
    state.t = Heat.clamp(state.t, 0, Heat.duration(state));
    const a = Heat.sample(state, state.t);
    $('time').max = Heat.duration(state);
    $('time').value = state.t;
    $('timeOut').textContent = `${state.t.toFixed(1)} s`;
    ['waterMass', 'sandMass', 'power'].forEach(k => {
      $(k).value = state[k];
      $(k + 'Out').textContent = k === 'power' ? `${state[k]} W` : `${state[k].toFixed(2)} kg`;
    });
    document.querySelectorAll('[data-scene]').forEach(b => { b.classList.toggle('on', b.dataset.scene === state.scene); b.setAttribute('aria-pressed', b.dataset.scene === state.scene); });
    $('sceneTitle').textContent = state.scene === 'rise' ? '都升高 10℃，谁需要更多热量？' : state.scene === 'mass' ? '改变质量，升温会怎样？' : '相同热量，水为什么升温更慢？';
    $('status').textContent = state.scene === 'rise' ? '两组到 30℃各自断热 · 比较吸热量与时间' : '相同吸收功率 · 点曲线读数，拖温度计探测';
    $('clock').textContent = `${state.t.toFixed(1)} / ${Heat.duration(state).toFixed(1)} s`;
    $('comparison').innerHTML = state.scene === 'rise' ? `<span>相同温升</span><b>各升高 10℃，分别停止供热</b><small>观察哪一杯先熄火</small>` : `<span>此刻的对照</span><b>水 +${a[0].rise.toFixed(1)}℃ <i>/</i> 干沙 +${a[1].rise.toFixed(1)}℃</b><small>${Math.abs(a[0].q-a[1].q)<.1 ? `各吸热 ${(a[0].q/1000).toFixed(2)} kJ` : '比较两组累计吸热'} · ${state.waterMass===state.sandMass ? '质量相同' : '质量不同'}</small>`;
    $('play').textContent = state.play ? '暂停加热' : state.t >= Heat.duration(state) ? '重新加热' : '继续加热';
    $('readings').innerHTML = a.map((v, i) => `<div class="${i ? 'sand' : 'water'}"><b>${i ? '干沙' : '水'} ${v.temp.toFixed(1)}℃</b><dl><dt>温升 / 吸热</dt><dd>${v.rise.toFixed(2)}℃ / ${v.q.toFixed(0)} J</dd><dt>加热时间</dt><dd>${v.seconds.toFixed(1)} s</dd><dt>热容量 mc</dt><dd>${(v.m * v.c).toFixed(0)} J/℃</dd></dl></div>`).join('');
  }
  function choose(scene) {
    Object.assign(state, Heat.defaults(scene));
    initialized = false; refresh(); track('切换实验', scene);
  }
  document.querySelectorAll('[data-scene]').forEach(b => b.onclick = () => choose(b.dataset.scene));
  ['waterMass', 'sandMass', 'power'].forEach(k => {
    $(k).oninput = () => {
      state[k] = Number($(k).value); state.t = 0; state.play = false;
      initialized = false; refresh();
    };
    $(k).onchange = () => track('改变条件', `${k}=${state[k]}`);
  });
  $('time').oninput = () => { state.t = Number($('time').value); state.play = false; refresh(); };
  $('time').onchange = () => track('进度', state.t.toFixed(1));
  $('play').onclick = () => {
    if (state.t >= Heat.duration(state) - 1e-6) state.t = 0;
    state.play = !state.play; refresh(); track('播放', state.play);
  };
  $('reset').onclick = () => { state.t = 0; state.play = false; refresh(); track('重做', state.scene); };
  $('target').onclick = () => choose('rise');
  if (matchMedia('(max-width:760px)').matches) $('panel').classList.add('collapsed');
  $('panelToggle').setAttribute('aria-expanded', !$('panel').classList.contains('collapsed'));
  $('panelToggle').onclick = () => { $('panel').classList.toggle('collapsed'); $('panelToggle').setAttribute('aria-expanded', !$('panel').classList.contains('collapsed')); };
  function url() {
    const u = new URL(location.href); u.hash = ''; u.search = '';
    ['scene', 'waterMass', 'sandMass', 'power'].forEach(k => u.searchParams.set(k, state[k]));
    u.searchParams.set('t', state.t.toFixed(2)); u.searchParams.set('play', '0'); return u.href;
  }
  $('share').onclick = async () => {
    const link = url();
    try { await navigator.clipboard.writeText(link); $('shareStatus').textContent = '已复制，可分享当前条件和时刻'; }
    catch { $('shareStatus').textContent = link; }
    track('复制链接', state.scene);
  };
  function point(e) { const r = canvas.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; }
  function probeCup(x, y) {
    const idx = HeatDraw.hitCup(x, y);
    if (idx < 0) return null;
    const b = layout.cups[idx], m = idx ? state.sandMass : state.waterMass;
    const depth = Math.min(b.height * (idx ? .35 : .56) * Math.pow(m / .2, .55), b.height * .87);
    return y >= b.bottom - depth ? idx : null;
  }
  canvas.onpointerdown = e => {
    const [x, y] = point(e), i = HeatDraw.hitProbe(state, x, y), t = HeatDraw.graphTime(state, x, y);
    if (i >= 0) {
      dragging = { type: 'probe', i, dx: state.probes[i].x * canvas.clientWidth - x, dy: state.probes[i].y * canvas.clientHeight - y };
      state.drag = i;
    } else if (t !== null) {
      dragging = { type: 'graph' }; state.t = t; state.play = false; state.hover = null; refresh();
    } else {
      const cup = HeatDraw.hitCup(x, y);
      if (cup >= 0) { HeatDraw.homeProbe(state, cup); track('点选烧杯', cup); }
    }
    if (dragging) { canvas.setPointerCapture(e.pointerId); canvas.style.cursor = 'grabbing'; e.preventDefault(); }
  };
  canvas.onpointermove = e => {
    const [x, y] = point(e);
    if (dragging && dragging.type === 'probe') {
      const px = Heat.clamp(x + dragging.dx, 25, canvas.clientWidth - 25);
      const py = Heat.clamp(y + dragging.dy, 100 + layout.unit * 110, layout.graph.y - 55);
      state.probes[dragging.i] = { x: px / canvas.clientWidth, y: py / canvas.clientHeight, cup: probeCup(px, py) };
    } else if (dragging) {
      const g = layout.graph; state.t = Heat.clamp((x - g.x) / g.width, 0, 1) * Heat.duration(state); refresh();
    } else {
      state.hover = HeatDraw.graphTime(state, x, y);
      canvas.style.cursor = HeatDraw.hitProbe(state, x, y) >= 0 ? 'grab' : state.hover !== null || HeatDraw.hitCup(x, y) >= 0 ? 'pointer' : 'default';
    }
  };
  function end() {
    if (dragging) track(dragging.type === 'probe' ? '拖动温度计' : '曲线读数', dragging.i ?? state.t.toFixed(1));
    dragging = null; state.drag = null; canvas.style.cursor = 'default';
  }
  canvas.onpointerup = end; canvas.onpointercancel = end;
  canvas.onpointerleave = () => { if (!dragging) state.hover = null; };
  let lastSize = '';
  function frame(now) {
    if (state.play) {
      state.t = Math.min(Heat.duration(state), state.t + Math.min((now - previous) / 1000, .1) * 12);
      if (state.t >= Heat.duration(state)) state.play = false;
    }
    previous = now;
    layout = HeatDraw.draw(canvas, state, now);
    const size = canvas.clientWidth + ':' + canvas.clientHeight;
    if (!initialized || size !== lastSize) {
      HeatDraw.homeProbe(state, 0); HeatDraw.homeProbe(state, 1);
      initialized = true; lastSize = size;
    }
    if (now - lastUI > 100) { refresh(); lastUI = now; }
    requestAnimationFrame(frame);
  }
  window.__model = { state, update: refresh, choose, url,
    setTime(t) { state.t = Heat.clamp(t, 0, Heat.duration(state)); state.play = false; refresh(); },
    advance(dt) { state.t = Math.min(Heat.duration(state), state.t + dt); refresh(); },
    get layout() { return layout; } };
  refresh(); requestAnimationFrame(frame);
})();
