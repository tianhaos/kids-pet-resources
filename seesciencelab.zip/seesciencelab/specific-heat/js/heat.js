/* 比热容教学计算；不访问 DOM。单位 kg、J、W、s、℃。 */
(function () {
  'use strict';
  const C = [4200, 840];
  const INITIAL = 20;
  const MAX = 80;
  const clamp = (x, a, b) => Math.max(a, Math.min(b, x));
  function number(value, fallback, min, max) {
    const n = Number(value);
    return value === null || value === '' || !Number.isFinite(n) ? fallback : clamp(n, min, max);
  }
  function masses(s) { return [s.waterMass, s.sandMass]; }
  function stopTimes(s) {
    const rise = s.scene === 'rise' ? 10 : MAX - INITIAL;
    return masses(s).map((m, i) => m * C[i] * rise / s.power);
  }
  function duration(s) {
    const times = stopTimes(s);
    return s.scene === 'rise' ? Math.max(...times) : Math.min(240, ...times);
  }
  function sample(s, time) {
    const t = clamp(time, 0, duration(s));
    const stops = stopTimes(s);
    return masses(s).map((m, i) => {
      const seconds = Math.min(t, stops[i]);
      const q = s.power * seconds;
      const rise = q / (m * C[i]);
      return { m, c: C[i], q, rise, temp: INITIAL + rise, seconds,
        on: t < stops[i] - 1e-7 && t < duration(s) - 1e-7 };
    });
  }
  function defaults(scene) {
    return { scene: ['heat', 'rise', 'mass'].includes(scene) ? scene : 'heat',
      waterMass: scene === 'mass' ? 0.4 : 0.2, sandMass: 0.2, power: 50,
      t: scene === 'heat' || !scene ? 120 : 0, play: false,
      probes: [{ x: 0.31, y: 0.36, cup: 0 }, { x: 0.77, y: 0.36, cup: 1 }], hover: null };
  }
  window.Heat = { C, INITIAL, MAX, clamp, number, masses, stopTimes, duration, sample, defaults };
})();
