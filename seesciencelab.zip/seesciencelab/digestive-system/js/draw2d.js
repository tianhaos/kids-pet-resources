(function () {
  'use strict';

  const closeups = {
    mouth: '110 32 104 102',
    esophagus: '130 74 108 109',
    stomach: '148 162 125 116',
    duodenum: '101 182 149 110',
    colon: '64 293 213 199'
  };

  function create(anatomy, closeup, villus) {
    const paths = new Map(Array.from(anatomy.querySelectorAll('[data-organ]'), path =>
      [path.dataset.organ, { path, length: path.getTotalLength() }]));
    const layeredHighlights = [...anatomy.querySelectorAll('[data-highlight]')];
    const labels = Array.from(anatomy.querySelectorAll('[data-pick]'));
    const food = anatomy.querySelector('#food');
    const pieces = Array.from(food.children);
    const flow = anatomy.querySelector('#process-flow');
    const squeeze = flow.querySelector('ellipse');
    const juices = [...flow.querySelectorAll('circle')];
    const routes = {
      毛细血管: villus.querySelector('#blood-route'),
      毛细淋巴管: villus.querySelector('#lymph-route')
    };
    const particles = Array.from(villus.querySelector('#absorbed').children);
    const lengths = new Map(Object.values(routes).map(path => [path, path.getTotalLength()]));
    let selected;

    // 画出食团后方的收缩和流入十二指肠的消化液，其余阶段隐藏。
    function paintProcess(stage, fraction, track) {
      squeeze.setAttribute('visibility', stage === 'esophagus' ? 'visible' : 'hidden');
      if (stage === 'esophagus') {
        const distance = track.length * Math.max(.02, fraction - .16);
        const p = track.path.getPointAtLength(distance);
        const q = track.path.getPointAtLength(Math.max(0, distance - 1));
        const angle = Math.atan2(p.y - q.y, p.x - q.x) * 180 / Math.PI - 90;
        squeeze.setAttribute('transform', `translate(${p.x} ${p.y}) rotate(${angle})`);
      }
      for (const [index, drop] of juices.entries()) {
        drop.setAttribute('visibility', stage === 'duodenum' ? 'visible' : 'hidden');
        if (stage === 'duodenum') {
          const duct = anatomy.querySelector(drop.dataset.duct);
          const p = duct.getPointAtLength(duct.getTotalLength() * ((fraction * 2.6 + index * .27) % 1));
          drop.setAttribute('cx', p.x);
          drop.setAttribute('cy', p.y);
        }
      }
    }

    function paintFood(stage, fraction) {
      const track = paths.get(stage);
      if (selected !== stage) {
        paths.forEach(({ path }, id) => path.classList.toggle('current', id === stage));
        layeredHighlights.forEach(path => path.setAttribute('opacity', path.dataset.highlight === stage ? '.42' : '0'));
        labels.forEach(label => label.classList.toggle('current', label.dataset.pick === stage));
        if (closeups[stage]) closeup.setAttribute('viewBox', closeups[stage]);
        selected = stage;
      }
      paintProcess(stage, fraction, track);
      const colon = stage === 'colon';
      const progress = colon ? Math.min(1, fraction / .91) : fraction;
      const exit = colon ? Math.max(0, (fraction - .91) / .09) : 0;
      const p = track.path.getPointAtLength(progress * track.length);
      const spread = stage === 'stomach' ? 1 + fraction * .55 : 1;
      const shrink = colon ? .82 - fraction * .23 : 1;
      food.setAttribute('transform', `translate(${p.x} ${p.y + 21 * exit}) scale(${shrink * spread} ${shrink / spread})`);
      food.setAttribute('opacity', 1 - exit);
      pieces[1].setAttribute('fill', colon ? '#be884d' : 'url(#bolus)');
      pieces[2].setAttribute('cx', 5 + (stage === 'stomach' ? 3 * Math.sin(fraction * 12) : 0));
    }

    function paintAbsorption(nutrient, progress) {
      const route = routes[nutrient.route];
      for (const path of Object.values(routes)) path.classList.toggle('current', path === route);
      for (const [index, particle] of particles.entries()) {
        // 相邻粒子错时进入。整段进度结束时停止在管道内。
        const fraction = window.Digestion.clamp(progress * 1.3 - index * .21, 0, 1);
        const p = route.getPointAtLength(fraction * lengths.get(route));
        particle.setAttribute('cx', p.x);
        particle.setAttribute('cy', p.y + (fraction === 0 ? index * 7 : 0));
        particle.setAttribute('fill', nutrient.color);
        particle.setAttribute('stroke', '#322333');
        const lipid = nutrient.route === '毛细淋巴管';
        particle.setAttribute('r', (lipid && fraction > .52 ? 5.1 : 3.8) - index * .45);
        particle.setAttribute('visibility', fraction === 1 && index < 2 ? 'hidden' : 'visible');
      }
    }
    return { paintFood, paintAbsorption };
  }
  window.DigestionDraw = { create };
})();
