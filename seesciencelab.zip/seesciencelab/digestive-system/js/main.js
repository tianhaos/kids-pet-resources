(function () {
  'use strict';

  const D = window.Digestion;
  const $ = id => document.getElementById(id);
  const byData = name => [...document.querySelectorAll(`[data-${name}]`)];
  const params = new URLSearchParams(location.search);
  const scenes = byData('scene');
  const stations = byData('station');
  const choices = byData('nutrient');
  const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)');
  const compact = matchMedia('(max-width: 760px)');
  const initialScene = params.get('scene') === 'absorption' ? 'absorption' : 'journey';
  const initialStage = D.stages.find(stage => stage.id === params.get('organ'));
  const initialNutrient = params.get('nutrient');
  const state = {
    scene: initialScene,
    nutrient: Object.hasOwn(D.nutrients, initialNutrient) ? initialNutrient : 'glucose',
    time: initialScene === 'absorption' ? 0 : (initialStage?.start ?? 0),
    playing: params.has('play') ? params.get('play') !== '0' : !reducedMotion.matches
  };

  const drawing = DigestionDraw.create($('anatomy'), $('organ-close'), $('villus'));
  const track = (action, label) => window.Analytics?.track('消化系统与营养吸收', action, label);
  const limit = () => state.scene === 'absorption' ? D.absorption.duration : D.duration;
  if (params.has('t') && Number.isFinite(Number(params.get('t')))) {
    state.time = D.clamp(Number(params.get('t')), 0, limit());
  }

  function setPressed(button, active) {
    button.classList.toggle('on', active);
    button.setAttribute('aria-pressed', active);
  }

  let displayedSelection;
  function render() {
    const absorptionOnly = state.scene === 'absorption';
    const { stage, fraction } = D.sample(absorptionOnly ? D.absorption.start + Math.min(state.time, D.absorption.duration - .001) : state.time);
    const showingVillus = stage === D.absorption;
    const nutrient = D.nutrients[state.nutrient];
    const expelled = !absorptionOnly && state.time >= D.duration;
    const selection = [state.scene, stage.id, state.nutrient, expelled].join(':');
    if (selection !== displayedSelection) {
      $('specimen-title').textContent = showingVillus ? '小肠绒毛' : stage.name;
      const action = $('action');
      action.textContent = expelled ? '残渣经肛门排出' : stage.action;
      if (showingVillus) {
        const destination = document.createElement('span');
        destination.textContent = '→ ' + nutrient.route;
        action.replaceChildren(nutrient.name + ' ', destination);
      }
      $('stage-note').textContent = showingVillus ? nutrient.description : stage.detail;
      $('organ-close').toggleAttribute('hidden', showingVillus);
      $('villus').toggleAttribute('hidden', !showingVillus);
      $('villus-legend').toggleAttribute('hidden', !showingVillus);
      $('nutrient-picker').toggleAttribute('hidden', !showingVillus);
      $('station-name').textContent = absorptionOnly ? '小肠绒毛' : stage.name;
      $('detail').textContent = stage.detail;
      $('contents-label').textContent = absorptionOnly ? '进入' : '内容物';
      $('contents').textContent = absorptionOnly ? nutrient.route : expelled ? '残渣已排出' : stage.contents;
      scenes.forEach(button => setPressed(button, button.dataset.scene === state.scene));
      stations.forEach(button => setPressed(button, button.dataset.station === stage.id));
      choices.forEach(button => setPressed(button, button.dataset.nutrient === state.nutrient));
      displayedSelection = selection;
    }
    $('play').textContent = state.playing ? '暂停' : state.time >= limit() ? '回放' : '播放';
    $('next').textContent = absorptionOnly ? '换物质' : stage === D.stages.at(-1) ? '回口腔' : '下一站';
    $('timeline').max = limit();
    $('timeline').value = state.time;
    $('timeline').setAttribute('aria-valuetext',
      (absorptionOnly ? nutrient.name : stage.name) + '，进度 ' + Math.round(state.time / limit() * 100) + '%');
    drawing.paintFood(stage.id, fraction);
    if (showingVillus) drawing.paintAbsorption(nutrient, fraction);
  }

  function setTime(value) {
    state.time = D.clamp(value, 0, limit());
    state.playing = false;
    render();
  }

  function setPanel(open) {
    $('panel').classList.toggle('collapsed', !open);
    $('panelToggle').setAttribute('aria-expanded', open);
    $('panelToggle').textContent = open ? '收起面板' : '实验面板';
  }
  setPanel(!compact.matches);
  compact.addEventListener('change', event => setPanel(!event.matches));
  $('panelToggle').addEventListener('click', () => setPanel($('panel').classList.contains('collapsed')));
  reducedMotion.addEventListener('change', event => {
    if (event.matches) state.playing = false;
    render();
  });

  function setScene(scene) {
    if (scene === state.scene) return;
    state.scene = scene;
    state.time = 0;
    state.playing = !reducedMotion.matches;
    render();
    track('切换场景', scene);
  }

  function selectStation(id) {
    const stage = D.stages.find(item => item.id === id);
    if (!stage) return;
    state.scene = 'journey';
    setTime(stage.start + (stage.id === 'intestine' ? stage.duration * .3 : stage.duration * .32));
    if (compact.matches) {
      const focusWasInPanel = $('panel').contains(document.activeElement);
      setPanel(false);
      if (focusWasInPanel) $('panelToggle').focus();
    }
    track('点选器官', id);
  }

  function selectNutrient(id) {
    state.nutrient = id;
    state.scene = 'absorption';
    state.time = reducedMotion.matches ? limit() * .55 : 0;
    state.playing = !reducedMotion.matches;
    render();
    track('对照吸收物质', id);
  }

  scenes.forEach(button => button.addEventListener('click', () => setScene(button.dataset.scene)));
  stations.forEach(button => button.addEventListener('click', () => selectStation(button.dataset.station)));
  choices.forEach(button => button.addEventListener('click', () => selectNutrient(button.dataset.nutrient)));
  $('anatomy').addEventListener('click', event => {
    const organ = event.target.closest('[data-organ], [data-pick]');
    if (organ) selectStation(organ.dataset.organ || organ.dataset.pick);
  });

  $('play').addEventListener('click', () => {
    if (state.time >= limit()) state.time = 0;
    state.playing = !state.playing;
    render();
    track('切换播放', state.playing ? '播放' : '暂停');
  });
  $('reset').addEventListener('click', () => {
    state.time = 0;
    state.playing = !reducedMotion.matches;
    render();
    track('重做实验', state.scene);
  });
  $('next').addEventListener('click', () => {
    if (state.scene === 'absorption') {
      const ids = Object.keys(D.nutrients);
      selectNutrient(ids[(ids.indexOf(state.nutrient) + 1) % ids.length]);
    } else {
      const index = D.stages.indexOf(D.sample(state.time).stage);
      selectStation(D.stages[(index + 1) % D.stages.length].id);
    }
  });
  $('timeline').addEventListener('input', event => setTime(Number(event.target.value)));
  $('timeline').addEventListener('change', () => track('拖动进度', state.scene));

  $('share').addEventListener('click', async () => {
    const url = new URL(location.pathname, location.origin);
    url.search = new URLSearchParams({ scene: state.scene, t: state.time.toFixed(1), nutrient: state.nutrient, play: '0' });
    try {
      await navigator.clipboard.writeText(url.href);
      $('feedback').textContent = '已复制当前实验链接。';
      track('分享实验', state.scene);
    } catch {
      window.prompt('复制当前实验链接', url.href);
    }
  });

  let previous;
  function animate(now) {
    const delta = Math.min(.06, (now - (previous ?? now)) / 1000);
    previous = now;
    if (state.playing) {
      state.time = Math.min(limit(), state.time + delta * 5);
      if (state.time >= limit()) state.playing = false;
      render();
    }
    requestAnimationFrame(animate);
  }

  if (state.time >= limit()) state.playing = false;
  window.__model = { state, setTime, setScene, selectStation, selectNutrient };
  render();
  requestAnimationFrame(animate);
})();
