(function () {
  'use strict';

  // 进度在每个阶段内插值，长度是演示节奏单位。
  const stages = [
    { id: 'mouth', name: '口腔', duration: 14, action: '咀嚼并初步消化淀粉',
      detail: '牙齿把食物切碎、磨碎。舌搅拌食物，唾液淀粉酶开始分解淀粉。', contents: '碎食物与唾液形成食团' },
    { id: 'esophagus', name: '食管', duration: 12, action: '蠕动把食团送进胃',
      detail: '食团后方的管壁依次收缩，前方舒张，食团沿管腔推进。', contents: '食团' },
    { id: 'stomach', name: '胃', duration: 23, action: '搅拌并初步消化蛋白质',
      detail: '胃壁收缩，将食物与胃液混合。胃蛋白酶在酸性环境下把蛋白质分解成较短的肽。', contents: '半流体的食糜' },
    { id: 'duodenum', name: '十二指肠', duration: 16, action: '食糜与胆汁、胰液汇合',
      detail: '肝脏分泌的胆汁可由胆囊释放到十二指肠，使脂肪分散成小滴。胰液中的酶参与消化。', contents: '食糜与消化液' },
    { id: 'intestine', name: '小肠', duration: 28, action: '完成主要消化并吸收营养',
      detail: '消化产物跨过绒毛表面的上皮进入血液或淋巴，剩余内容物继续向大肠推进。', contents: '消化产物与剩余内容物' },
    { id: 'colon', name: '大肠', duration: 24, action: '回收部分剩余的水和无机盐',
      detail: '结肠吸收部分剩余的水和无机盐，内容物逐渐形成粪便。随后经过直肠，由肛门排出。', contents: '残渣逐渐形成粪便' }
  ];
  let elapsed = 0;
  for (const stage of stages) {
    stage.start = elapsed;
    elapsed += stage.duration;
    stage.end = elapsed;
  }

  const nutrients = {
    glucose: { name: '葡萄糖', route: '毛细血管', color: '#ffd36f',
      description: '淀粉经消化最终产生葡萄糖。葡萄糖跨过小肠上皮进入绒毛内的毛细血管。' },
    amino: { name: '氨基酸', route: '毛细血管', color: '#9bdcff',
      description: '蛋白质经消化最终产生氨基酸。氨基酸跨过小肠上皮进入绒毛内的毛细血管。' },
    lipid: { name: '长链脂肪消化产物', route: '毛细淋巴管', color: '#dcb5ff',
      description: '多数长链脂肪消化产物进入上皮细胞后重新组成脂肪，包装成乳糜微粒，经毛细淋巴管转运，随后汇入血液。' }
  };

  const clamp = (value, min, max) => Number.isFinite(value) ? Math.min(max, Math.max(min, value)) : min;
  function sample(value) {
    const time = clamp(value, 0, elapsed);
    const stage = stages.find(item => time < item.end) || stages[stages.length - 1];
    return { stage, fraction: (time - stage.start) / stage.duration };
  }

  const absorption = stages.find(stage => stage.id === 'intestine');
  window.Digestion = { stages, nutrients, duration: elapsed, absorption, clamp, sample };
})();
