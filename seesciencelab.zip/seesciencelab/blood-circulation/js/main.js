(function () {
  var B = window.Blood;
  var $ = function (id) { return document.getElementById(id); };
  var qa = function (sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); };

  var state = {
    mode: 'all', colors: 'book', show: { labels: true, gas: true, cells: true },
    bpm: 75, speed: 0.5, paused: false,
    sel: null, selGroup: null, hover: null, tip: null,
    phaseT: 0, t: 0
  };

  // 结构说明：名称、血液、作用
  var GROUP = { ivc1: 'ivc', ivc2: 'ivc', ivc3: 'ivc', ao: 'ao', ao_up: 'ao', ao_dn1: 'ao', ao_dn2: 'ao', ao_dn3: 'ao', avR: 'av', avL: 'av', svP: 'svP', svA: 'svA' };
  var MEMBERS = { ivc: ['ivc1', 'ivc2', 'ivc3'], ao: ['ao', 'ao_up', 'ao_dn1', 'ao_dn2', 'ao_dn3'] };
  var INFO = {
    ra:  ['右心房', '静脉血', '接收上、下腔静脉从全身流回的静脉血，收缩时把血液经房室瓣压入右心室。'],
    rv:  ['右心室', '静脉血', '肺循环的起点：把静脉血泵入肺动脉送往肺部。只把血液送到肺，壁比左心室薄。'],
    la:  ['左心房', '动脉血', '接收肺静脉从肺部流回的动脉血，收缩时把血液经房室瓣压入左心室。'],
    lv:  ['左心室', '动脉血', '体循环的起点：把动脉血泵入主动脉送往全身。输送距离最远，心肌最发达，壁最厚。'],
    av:  ['房室瓣', '', '位于心房和心室之间，只能朝心室方向开。心室收缩时关闭，防止血液倒流回心房。'],
    svP: ['动脉瓣（肺动脉瓣）', '', '位于右心室和肺动脉之间，只能朝动脉方向开。心室舒张时关闭，防止血液倒流回心室。'],
    svA: ['动脉瓣（主动脉瓣）', '', '位于左心室和主动脉之间，只能朝动脉方向开。心室舒张时关闭，防止血液倒流回心室。'],
    svc: ['上腔静脉', '静脉血', '收集头部、上肢等身体上部的静脉血，送回右心房。'],
    ivc: ['下腔静脉', '静脉血', '收集躯干、内脏和下肢等身体下部的静脉血，送回右心房。'],
    vc:  ['上、下腔静脉', '静脉血', '上腔静脉和下腔静脉都连通右心房，把全身的静脉血送回心脏。'],
    pa:  ['肺动脉', '静脉血', '从右心室发出，把静脉血送到肺。名字叫"动脉"，里面流的却是静脉血。'],
    pv:  ['肺静脉', '动脉血', '把在肺部变成的动脉血送回左心房。名字叫"静脉"，里面流的却是动脉血。'],
    ao:  ['主动脉', '动脉血', '从左心室发出，是人体最粗的动脉，经各级动脉把动脉血送往全身。'],
    a_gut: ['小肠动脉', '动脉血', '动脉把血液从心脏送到身体各处：管壁厚、弹性大，血流速度快。'],
    a_kid: ['肾动脉', '动脉血', '把动脉血送入肾。肾动脉里的血尿素等废物较多。'],
    v_gut: ['小肠静脉', '静脉血', '血液流经小肠后营养物质增多，经静脉汇入下腔静脉（实际先经肝门静脉流入肝脏）。'],
    v_kid: ['肾静脉', '静脉血', '血液流经肾后，尿素等废物减少，是全身含尿素最少的血液。'],
    v_leg: ['下肢静脉', '静脉血', '静脉把血液从身体各处送回心脏：管壁较薄、弹性小，血流较慢；四肢静脉内有防止倒流的静脉瓣。'],
    lung: ['肺部毛细血管网', '静脉血 → 动脉血', '包绕在肺泡外面。肺泡中的氧扩散进入血液，血液中的二氧化碳扩散进入肺泡，静脉血变成动脉血。'],
    head: ['头部和上肢的毛细血管网', '动脉血 → 静脉血', '毛细血管管壁只有一层上皮细胞，血流最慢：血液把氧和营养物质交给组织细胞，带走二氧化碳等废物。'],
    gut:  ['小肠的毛细血管网', '动脉血 → 静脉血', '小肠绒毛内的毛细血管吸收葡萄糖、氨基酸等营养物质。流经小肠后：氧减少，二氧化碳和营养物质增多。'],
    kid:  ['肾内的毛细血管网', '动脉血 → 静脉血', '肾形成尿液，排出尿素等废物。流经肾后：氧减少，二氧化碳增多，尿素等废物减少。'],
    leg:  ['下肢的毛细血管网', '动脉血 → 静脉血', '肌肉细胞利用氧分解有机物、释放能量，产生二氧化碳。流经后：氧减少，二氧化碳增多。']
  };

  var CIRC = {
    all: '体循环和肺循环同时进行，在心脏处连通在一起，组成一条完整的循环途径。',
    sys: '体循环：左心室 → 主动脉 → 各级动脉 → 全身各处的毛细血管网 → 各级静脉 → 上、下腔静脉 → 右心房。血液由动脉血变成静脉血。',
    pul: '肺循环：右心室 → 肺动脉 → 肺部毛细血管网 → 肺静脉 → 左心房。血液由静脉血变成动脉血。'
  };

  var stage = $('stage'), canvas = $('blood'), panel = $('panel');
  var view = window.BloodDraw(canvas);
  var sim = B.Sim(340);
  var tracer = null;
  var vo = { avR: 1, avL: 1, svP: 0, svA: 0 };

  function setSeg(attr, val) { qa('[data-' + attr + ']').forEach(function (b) { b.classList.toggle('on', b.dataset[attr] === String(val)); }); }

  // ---------- 循环途径 ----------
  qa('[data-mode]').forEach(function (b) {
    b.addEventListener('click', function () { state.mode = b.dataset.mode; syncUI(); Analytics.track('血液循环', '途径', b.textContent); });
  });

  // ---------- 心跳 ----------
  var bpmEl = $('bpm');
  bpmEl.addEventListener('input', function () { state.bpm = parseFloat(bpmEl.value); syncUI(); });
  qa('[data-bpm]').forEach(function (b) { b.addEventListener('click', function () { state.bpm = +b.dataset.bpm; syncUI(); }); });
  qa('[data-speed]').forEach(function (b) { b.addEventListener('click', function () { state.speed = +b.dataset.speed; syncUI(); }); });
  $('pause').addEventListener('click', function () { state.paused = !state.paused; syncUI(); });

  // ---------- 显示 ----------
  [['showLabels', 'labels'], ['showGas', 'gas'], ['showCells', 'cells']].forEach(function (p) {
    $(p[0]).addEventListener('change', function () { state.show[p[1]] = $(p[0]).checked; });
  });
  qa('[data-colors]').forEach(function (b) { b.addEventListener('click', function () { state.colors = b.dataset.colors; syncUI(); }); });

  // ---------- 追踪 ----------
  var STEP_NAME = {
    svc: '上腔静脉', vc: null, ivc1: '下腔静脉', ivc2: '下腔静脉', ivc3: '下腔静脉',
    v_gut: '小肠静脉', v_kid: '肾静脉', v_leg: '下肢静脉',
    ra: '右心房', rv: '右心室', pa: '肺动脉', lung: '肺部毛细血管', pv: '肺静脉', la: '左心房', lv: '左心室',
    ao: '主动脉', ao_up: '主动脉', ao_dn1: '主动脉', ao_dn2: '主动脉', ao_dn3: '主动脉',
    a_gut: '小肠动脉', a_kid: '肾动脉', head: '头部毛细血管', gut: '小肠毛细血管', kid: '肾内毛细血管', leg: '下肢毛细血管'
  };
  var steps = [];     // 合并同名路段后的步骤：{ name, from（route 中的起始下标）}
  function buildSteps(ids) {
    steps = [];
    ids.forEach(function (id, i) {
      var n = STEP_NAME[id];
      if (n && (!steps.length || steps[steps.length - 1].name !== n)) steps.push({ name: n, from: i, id: id });
    });
    var ol = $('traceSteps');
    ol.innerHTML = '';
    steps.forEach(function (s) {
      var li = document.createElement('li'), e = B.E[s.id];
      var blood = e.type === 'cap' ? (e.o2 ? '静脉血 → 动脉血' : '动脉血 → 静脉血') : B.oxy(s.id) ? '动脉血' : '静脉血';
      li.innerHTML = s.name + ' <small>' + blood + '</small>';
      ol.appendChild(li);
    });
  }
  function heartPasses(ids, upto) {
    var n = 0, inHeart = false;
    for (var i = 0; i <= upto && i < ids.length; i++) {
      var ch = B.E[ids[i]].type === 'ch';
      if (ch && !inHeart) n++;
      inHeart = ch;
    }
    return n;
  }
  function startTrace(key) {
    tracer = B.Tracer(key);
    buildSteps(tracer.route.ids);
    $('traceNote').textContent = B.ROUTES[key].note;
    setSeg('trace', key);
    $('traceCard').hidden = false;
    $('traceStop').hidden = false;
    if (state.paused) { state.paused = false; syncUI(); }
    Analytics.track('血液循环', '追踪', B.ROUTES[key].name);
  }
  function stopTrace() {
    tracer = null;
    $('traceSteps').innerHTML = ''; $('traceNote').textContent = '';
    setSeg('trace', '');
    $('traceCard').hidden = true;
    $('traceStop').hidden = true;
  }
  qa('[data-trace]').forEach(function (b) { b.addEventListener('click', function () { startTrace(b.dataset.trace); }); });
  $('traceStop').addEventListener('click', stopTrace);
  $('traceAgain').addEventListener('click', function () { if (tracer) startTrace(tracer.key); });

  // ---------- 点选结构 ----------
  function select(id) {
    if (!id) { state.sel = null; state.selGroup = null; return; }
    var key = GROUP[id] || id, info = INFO[key];
    state.sel = id;
    state.selGroup = MEMBERS[key] || null;
    $('partName').textContent = info[0];
    $('partBlood').textContent = info[1];
    $('partBlood').className = info[1] === '动脉血' ? 'art' : info[1] === '静脉血' ? 'ven' : 'mix';
    $('partInfo').textContent = info[2];
  }
  function localXY(e) { var r = canvas.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; }
  canvas.addEventListener('pointermove', function (e) {
    var p = localXY(e), id = view.hit(p[0], p[1]);
    state.hover = id;
    state.tip = id && e.pointerType === 'mouse' ? { text: INFO[GROUP[id] || id][0], x: p[0], y: p[1] } : null;
    canvas.classList.toggle('point', !!id);
  });
  canvas.addEventListener('pointerleave', function () { state.hover = null; state.tip = null; });
  canvas.addEventListener('click', function (e) {
    var p = localXY(e), id = view.hit(p[0], p[1]);
    select(id);
    if (id) Analytics.track('血液循环', '点选结构', INFO[GROUP[id] || id][0]);
  });

  // ---------- 面板同步 ----------
  function syncUI() {
    setSeg('mode', state.mode);
    $('circNote').textContent = CIRC[state.mode];
    bpmEl.value = state.bpm;
    $('bpmOut').textContent = state.bpm + ' 次/分';
    setSeg('bpm', state.bpm);
    setSeg('speed', state.speed);
    setSeg('colors', state.colors);
    $('pause').textContent = state.paused ? '▶ 继续' : '❚❚ 暂停';
    qa('.lg-art').forEach(function (el) { el.style.background = state.colors === 'book' ? '#ff4d5e' : '#ff3344'; });
    qa('.lg-ven').forEach(function (el) { el.style.background = state.colors === 'book' ? '#4f7dff' : '#96243a'; });
  }

  $('panelToggle').addEventListener('click', function () { panel.classList.toggle('collapsed'); });
  if (window.matchMedia('(max-width: 760px)').matches) panel.classList.add('collapsed');

  // ---------- 读数 ----------
  var last = {};
  function setText(id, s) { if (last[id] !== s) { last[id] = s; $(id).textContent = s; } }
  function updateReadouts(h) {
    setText('rState', h.name);
    $('rState').className = h.key;
    // 三段说明叠放在同一格里，只切换显示哪一段：高度始终按最长的一段，心跳时下方内容不会上下跳动
    if (last.tip !== h.key) {
      last.tip = h.key;
      qa('#rTip [data-ph]').forEach(function (el) { el.classList.toggle('on', el.dataset.ph === h.key); });
    }
    var T = 60 / state.bpm;
    setText('rRate', state.bpm + ' 次/分（每个心动周期 ' + T.toFixed(2) + ' s）');
    setText('rAV', h.av ? '打开（心房 → 心室）' : '关闭');
    setText('rSL', h.sl ? '打开（心室 → 动脉）' : '关闭');
    setText('rTime', '心房收缩 ' + (T * 0.125).toFixed(2) + ' s · 心室收缩 ' + (T * 0.375).toFixed(2) + ' s · 全心舒张 ' + (T * 0.5).toFixed(2) + ' s');
    if (tracer) {
      var ri = tracer.route.i, cur = 0;
      for (var i = 0; i < steps.length; i++) if (steps[i].from <= ri) cur = i;
      var lis = $('traceSteps').children;
      for (i = 0; i < lis.length; i++) {
        var cls = i < cur || (tracer.done && i === cur) ? 'done' : i === cur ? 'cur' : '';
        if (lis[i].className !== cls) lis[i].className = cls;
      }
      var n = heartPasses(tracer.route.ids, ri);
      setText('tcTitle', B.ROUTES[tracer.key].name);
      setText('tcNow', tracer.done ? '✓ 到达：' + steps[steps.length - 1].name : '第 ' + (cur + 1) + ' / ' + steps.length + ' 步：' + steps[cur].name);
      setText('tcHeart', '经过心脏 ' + n + ' 次 · 含氧 ' + (tracer.p.s > 0.5 ? '丰富（动脉血）' : '较少（静脉血）'));
      $('traceAgain').hidden = !tracer.done;
    }
  }

  // ---------- 尺寸与主循环 ----------
  function resize() { view.resize(stage.clientWidth, stage.clientHeight); }
  new ResizeObserver(resize).observe(stage);
  if (window.matchMedia('(max-width: 640px)').matches) $('hint').textContent = '点结构看说明 · 可追踪血细胞';

  // 支持 ?trace=oral 这样的链接直接开始追踪
  var q = /[?&]trace=(\w+)/.exec(location.search);
  resize();
  syncUI();
  if (q && B.ROUTES[q[1]]) startTrace(q[1]);

  var lastT = performance.now();
  function frame(t) {
    var rdt = Math.min((t - lastT) / 1000, 0.1);
    lastT = t;
    var dt = state.paused ? 0 : rdt * state.speed;
    var rate = state.bpm / 75;
    state.phaseT += dt * state.bpm / 60;
    state.t += dt;
    var h = B.heart(state.phaseT % 1);
    // 瓣膜开合需要一点时间
    var kv = 1 - Math.exp(-dt / 0.03);
    vo.avR += ((h.av ? 1 : 0) - vo.avR) * kv; vo.avL = vo.avR;
    vo.svP += ((h.sl ? 1 : 0) - vo.svP) * kv; vo.svA = vo.svP;
    if (dt > 0) {
      sim.step(dt, h, rate);
      if (tracer) tracer.step(dt, h, rate);
    }
    view.draw({ mode: state.mode, colors: state.colors, show: state.show, sel: state.sel, selGroup: state.selGroup,
      hover: state.hover, tip: state.tip, paused: state.paused }, sim, tracer, h, vo, dt, state.t);
    updateReadouts(h);
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // 调试用
  window.__model = { state: state, view: view, sim: sim, startTrace: startTrace, stopTrace: stopTrace, select: select, tracer: function () { return tracer; } };
})();
