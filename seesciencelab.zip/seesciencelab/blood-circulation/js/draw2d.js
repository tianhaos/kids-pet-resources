// 血液循环示意图：心脏四腔与瓣膜、血管、毛细血管网、血细胞粒子、气体交换、追踪路线
// 绘制在 Blood 的虚拟坐标（1000×1000）中，按画布大小等比缩放。
(function () {
  var B = window.Blood, E = B.E;
  var VB = { x0: 196, x1: 824, y0: 30, y1: 948 };

  var PAL = {
    book: { art: [255, 77, 94], ven: [79, 125, 255] },
    real: { art: [255, 51, 68], ven: [150, 36, 58] }
  };
  var C = {
    text: '#c9d2df', muted: '#8d99ab', line: '#2a3446', bg: '#05070d', accent: '#ffc94a',
    heart: '#2a141b', heartEdge: '#6e3443', valve: '#f1e6d6', lung: 'rgba(143,208,255,0.05)', lungEdge: 'rgba(143,208,255,0.28)',
    o2: '#7fe3ff', co2: '#b8c0cc', food: '#ffd166', urea: '#c9a7ff', trace: '#ffd166'
  };
  var BEDS = {
    head: { x0: 318, x1: 682, y0: 54, y1: 126, label: '头部和上肢', cell: 'rgba(214,190,170,' },
    gut:  { x0: 370, x1: 630, y0: 650, y1: 710, label: '小肠', cell: 'rgba(255,209,102,' },
    kid:  { x0: 370, x1: 630, y0: 752, y1: 808, label: '肾', cell: 'rgba(201,167,255,' },
    leg:  { x0: 370, x1: 630, y0: 860, y1: 920, label: '下肢', cell: 'rgba(255,138,128,' }
  };
  var LUNGS = [{ x: 441, y: 252, r: 68 }, { x: 559, y: 252, r: 68 }];

  function BloodDraw(canvas) {
    var ctx = canvas.getContext('2d');
    var W = 1, H = 1, dpr = 1, sc = 1, ox = 0, oy = 0, narrow = false;
    var pal = null, palKey = '', gas = [], alveoli = [];

    function resize(w, h) {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      W = w; H = h;
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
      canvas.style.width = w + 'px'; canvas.style.height = h + 'px';
      narrow = w < 640;
      var top = narrow ? 84 : 40, bot = narrow ? 112 : 44, side = narrow ? 4 : 16;
      sc = Math.min((w - 2 * side) / (VB.x1 - VB.x0), (h - top - bot) / (VB.y1 - VB.y0));
      ox = (w - (VB.x1 - VB.x0) * sc) / 2 - VB.x0 * sc;
      oy = top + (h - top - bot - (VB.y1 - VB.y0) * sc) / 2 - VB.y0 * sc;
    }
    function X(x) { return ox + x * sc; }
    function Y(y) { return oy + y * sc; }
    function toV(px, py) { return { x: (px - ox) / sc, y: (py - oy) / sc }; }

    // ---------- 颜色 ----------
    function palette(key) {
      if (palKey === key) return pal;
      var p = PAL[key], list = [];
      for (var i = 0; i <= 32; i++) {
        var s = i / 32;
        list.push('rgb(' + [0, 1, 2].map(function (k) { return Math.round(p.ven[k] + (p.art[k] - p.ven[k]) * s); }).join(',') + ')');
      }
      palKey = key; pal = { list: list, art: p.art, ven: p.ven };
      return pal;
    }
    function col(s) { return pal.list[Math.max(0, Math.min(32, Math.round(s * 32)))]; }
    function rgba(c, a) { return 'rgba(' + c[0] + ',' + c[1] + ',' + c[2] + ',' + a + ')'; }

    function font(size, weight) {
      ctx.font = (weight || '') + ' ' + size + 'px -apple-system, "PingFang SC", "Microsoft YaHei", sans-serif';
    }
    function fs(v) { return Math.max(10, Math.min(v * 1.25, v * sc * 1.15)); }   // 字号随缩放，但不小于 10px
    function label(str, x, y, color, align, size, weight, halo) {
      font(size, weight);
      ctx.textAlign = align || 'center'; ctx.textBaseline = 'middle';
      if (halo !== false) { ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(5,7,13,0.85)'; ctx.strokeText(str, x, y); }
      ctx.fillStyle = color; ctx.fillText(str, x, y);
    }
    function path(pts) {
      ctx.beginPath(); ctx.moveTo(X(pts[0]), Y(pts[1]));
      for (var i = 2; i < pts.length; i += 2) ctx.lineTo(X(pts[i]), Y(pts[i + 1]));
    }
    function rrect(x0, y0, x1, y1, r) {
      ctx.beginPath();
      if (ctx.roundRect) ctx.roundRect(X(x0), Y(y0), (x1 - x0) * sc, (y1 - y0) * sc, r * sc);
      else ctx.rect(X(x0), Y(y0), (x1 - x0) * sc, (y1 - y0) * sc);
    }
    function dimFor(st, e) { return st.mode !== 'all' && e.circ !== st.mode ? 0.16 : 1; }

    // ---------- 背景：肺、器官 ----------
    function drawLungs(st) {
      var a = st.mode === 'sys' ? 0.35 : 1;
      ctx.globalAlpha = a;
      // 气管与支气管
      ctx.strokeStyle = '#3c4a62'; ctx.lineCap = 'round'; ctx.lineWidth = 9 * sc;
      path([500, 150, 500, 196]); ctx.stroke();
      path([500, 196, 470, 218]); ctx.stroke();
      path([500, 196, 530, 218]); ctx.stroke();
      LUNGS.forEach(function (L) {
        ctx.beginPath(); ctx.arc(X(L.x), Y(L.y), L.r * sc, 0, 7);
        ctx.fillStyle = C.lung; ctx.fill(); ctx.strokeStyle = C.lungEdge; ctx.lineWidth = 1; ctx.stroke();
      });
      // 肺泡
      if (!alveoli.length) {
        LUNGS.forEach(function (L) {
          for (var y = L.y - L.r + 10; y < L.y + L.r; y += 17)
            for (var x = L.x - L.r + 10; x < L.x + L.r; x += 17) {
              var xx = x + ((y / 17) % 2) * 8;
              if (Math.hypot(xx - L.x, y - L.y) < L.r - 9) alveoli.push(xx, y);
            }
        });
      }
      ctx.fillStyle = 'rgba(143,208,255,0.07)'; ctx.strokeStyle = 'rgba(143,208,255,0.2)'; ctx.lineWidth = 1;
      for (var i = 0; i < alveoli.length; i += 2) {
        ctx.beginPath(); ctx.arc(X(alveoli[i]), Y(alveoli[i + 1]), 7 * sc, 0, 7); ctx.fill(); ctx.stroke();
      }
      ctx.globalAlpha = 1;
    }
    function drawBeds(st) {
      Object.keys(BEDS).forEach(function (id) {
        var b = BEDS[id];
        ctx.globalAlpha = st.mode === 'pul' ? 0.3 : 1;
        rrect(b.x0, b.y0, b.x1, b.y1, 10);
        ctx.fillStyle = 'rgba(255,255,255,0.025)'; ctx.fill();
        ctx.strokeStyle = st.sel === id || st.hover === id ? C.accent : '#253047'; ctx.lineWidth = 1; ctx.stroke();
        // 组织细胞
        var ym = (b.y0 + b.y1) / 2;
        ctx.fillStyle = b.cell + '0.10)'; ctx.strokeStyle = b.cell + '0.28)';
        for (var x = b.x0 + 22; x < b.x1 - 14; x += 24) {
          [b.y0 + 8, b.y1 - 20].forEach(function (y) {
            rrect(x - 8, y, x + 8, y + 12, 3); ctx.fill(); ctx.stroke();
          });
        }
        ctx.globalAlpha = 1;
      });
    }

    // ---------- 血管 ----------
    function drawVessels(st) {
      // 先画同一层所有血管的黑色描边，再画填充，分叉处才不会出现断缝；动脉层在上，跨过静脉处像立交桥
      ['vein', 'art'].forEach(function (type) {
        var ids = Object.keys(E).filter(function (id) { return E[id].type === type; });
        ctx.lineJoin = 'round'; ctx.lineCap = 'round';
        ids.forEach(function (id) {
          var e = E[id];
          ctx.globalAlpha = dimFor(st, e);
          path(e.pts); ctx.strokeStyle = C.bg; ctx.lineWidth = (e.w + 6) * sc; ctx.stroke();
        });
        ids.forEach(function (id) {
          var e = E[id], c = B.oxy(id) ? pal.art : pal.ven;
          ctx.globalAlpha = dimFor(st, e);
          path(e.pts); ctx.strokeStyle = rgba(c, 0.3); ctx.lineWidth = e.w * sc; ctx.stroke();
          if (st.sel === id || st.hover === id || (st.selGroup && st.selGroup.indexOf(id) >= 0)) {
            path(e.pts); ctx.strokeStyle = C.accent; ctx.lineWidth = Math.max(1.5, 2 * sc); ctx.setLineDash([6, 4]); ctx.stroke(); ctx.setLineDash([]);
          }
        });
        ctx.globalAlpha = 1;
      });
    }
    function drawCaps(st) {
      ['lung', 'head', 'gut', 'kid', 'leg'].forEach(function (id) {
        var e = E[id], pts0 = e.polys[0].pts;
        var xa = pts0[0], xb = pts0[pts0.length - 2];
        var g = ctx.createLinearGradient(X(xa), 0, X(xb), 0);
        var c0 = e.o2 ? pal.ven : pal.art, c1 = e.o2 ? pal.art : pal.ven;
        g.addColorStop(0, rgba(c0, 0.7)); g.addColorStop(0.2, rgba(c0, 0.55)); g.addColorStop(0.8, rgba(c1, 0.55)); g.addColorStop(1, rgba(c1, 0.7));
        ctx.globalAlpha = dimFor(st, e);
        ctx.strokeStyle = g; ctx.lineWidth = Math.max(1.2, 2.4 * sc); ctx.lineJoin = 'round';
        e.polys.forEach(function (p) { path(p.pts); ctx.stroke(); });
        ctx.globalAlpha = 1;
      });
    }

    // ---------- 心脏 ----------
    function cavity(ch, k) {
      var cx = (ch.x0 + ch.x1) / 2, cy = (ch.y0 + ch.y1) / 2;
      return { x0: cx + (ch.x0 - cx) * k, x1: cx + (ch.x1 - cx) * k, y0: cy + (ch.y0 - cy) * k, y1: cy + (ch.y1 - cy) * k, cx: cx, cy: cy };
    }
    function squeeze(id, h) { return id === 'ra' || id === 'la' ? 1 - 0.1 * h.aSq : 1 - 0.13 * h.vSq; }
    function drawHeart(st, h) {
      var k = 1 - 0.025 * h.vSq;
      ctx.save();
      ctx.translate(X(500), Y(480)); ctx.scale(k, k); ctx.translate(-X(500), -Y(480));
      ctx.beginPath();
      ctx.moveTo(X(392), Y(400)); ctx.quadraticCurveTo(X(392), Y(388), X(404), Y(388));
      ctx.lineTo(X(598), Y(388)); ctx.quadraticCurveTo(X(610), Y(388), X(610), Y(400));
      ctx.lineTo(X(610), Y(540)); ctx.quadraticCurveTo(X(607), Y(584), X(562), Y(596));
      ctx.quadraticCurveTo(X(518), Y(606), X(468), Y(588)); ctx.quadraticCurveTo(X(392), Y(562), X(392), Y(522));
      ctx.closePath();
      ctx.fillStyle = C.heart; ctx.fill(); ctx.strokeStyle = C.heartEdge; ctx.lineWidth = 1.5; ctx.stroke();
      ctx.restore();
      ['ra', 'rv', 'la', 'lv'].forEach(function (id) {
        var cv = cavity(B.CHAMBER[id], squeeze(id, h)), e = E[id];
        var c = B.oxy(id) ? pal.art : pal.ven;
        ctx.globalAlpha = dimFor(st, e);
        rrect(cv.x0, cv.y0, cv.x1, cv.y1, 10);
        ctx.fillStyle = rgba(c, 0.2); ctx.fill();
        ctx.strokeStyle = st.sel === id || st.hover === id ? C.accent : rgba(c, 0.45); ctx.lineWidth = st.sel === id ? 2 : 1; ctx.stroke();
        ctx.globalAlpha = 1;
      });
    }
    function drawValves(st, vo) {
      ctx.lineCap = 'round'; ctx.lineWidth = Math.max(2, 3 * sc);
      Object.keys(B.VALVE).forEach(function (id) {
        var v = B.VALVE[id], o = vo[id], on = st.sel === id || st.hover === id;
        ctx.strokeStyle = on ? C.accent : C.valve;
        var ang = o * 1.2;    // 开放时瓣叶转动约 70°
        if (v.kind === 'av') {
          var half = (v.x1 - v.x0) / 2;
          // 两片瓣叶分别铰接在两端，开向下方（心室）
          ctx.beginPath();
          ctx.moveTo(X(v.x0), Y(v.y)); ctx.lineTo(X(v.x0 + Math.cos(ang) * half * 0.96), Y(v.y + Math.sin(ang) * half * 0.96));
          ctx.moveTo(X(v.x1), Y(v.y)); ctx.lineTo(X(v.x1 - Math.cos(ang) * half * 0.96), Y(v.y + Math.sin(ang) * half * 0.96));
          ctx.stroke();
        } else {
          var hl = (v.y1 - v.y0) / 2;
          ctx.beginPath();
          ctx.moveTo(X(v.x), Y(v.y0)); ctx.lineTo(X(v.x + v.dir * Math.sin(ang) * hl * 0.96), Y(v.y0 + Math.cos(ang) * hl * 0.96));
          ctx.moveTo(X(v.x), Y(v.y1)); ctx.lineTo(X(v.x + v.dir * Math.sin(ang) * hl * 0.96), Y(v.y1 - Math.cos(ang) * hl * 0.96));
          ctx.stroke();
        }
      });
    }

    // ---------- 血细胞 ----------
    function posOf(p, h) {
      var e = E[p.e], q = B.at(e.polys[p.k], p.t);
      var off = e.type === 'cap' ? 0 : p.lane * Math.max(0, e.w / 2 - 3.5);
      var x = q.x - q.dy * off, y = q.y + q.dx * off;
      if (e.type === 'ch') {
        var cv = cavity(B.CHAMBER[p.e], squeeze(p.e, h));
        var k = squeeze(p.e, h);
        x = cv.cx + (x - cv.cx) * k; y = cv.cy + (y - cv.cy) * k;
      }
      return { x: x, y: y };
    }
    function drawCells(st, sim, h) {
      var r = Math.max(1.6, 3.4 * sc), parts = sim.parts;
      for (var i = 0; i < parts.length; i++) {
        var p = parts[i], e = E[p.e], q = posOf(p, h);
        ctx.globalAlpha = dimFor(st, e) < 1 ? 0.12 : 0.95;
        ctx.fillStyle = col(p.s);
        ctx.beginPath(); ctx.arc(X(q.x), Y(q.y), e.type === 'cap' ? r * 0.8 : r, 0, 7); ctx.fill();
      }
      ctx.globalAlpha = 1;
    }

    // ---------- 气体与物质交换 ----------
    function spawnGas(dt, st) {
      var rate = st.paused ? 0 : 1;
      function emit(id, color, inward, n) {
        var e = E[id];
        for (var i = 0; i < n; i++) {
          if (Math.random() > dt * rate * 6) continue;
          var p = e.polys[Math.floor(Math.random() * e.polys.length)], u = 0.15 + Math.random() * 0.7;
          var q = B.at(p, u * p.len), side = Math.random() < 0.5 ? -1 : 1, d = 14 + Math.random() * 12;
          var ax = q.x - q.dy * side * d, ay = q.y + q.dx * side * d;
          gas.push(inward ? { x0: ax, y0: ay, x1: q.x, y1: q.y, t: 0, c: color } : { x0: q.x, y0: q.y, x1: ax, y1: ay, t: 0, c: color });
        }
      }
      emit('lung', C.o2, true, 3); emit('lung', C.co2, false, 3);
      ['head', 'gut', 'kid', 'leg'].forEach(function (id) { emit(id, C.o2, false, 1); emit(id, C.co2, true, 1); });
      emit('gut', C.food, true, 1); emit('kid', C.urea, false, 1);
      for (var i = gas.length - 1; i >= 0; i--) { gas[i].t += dt * rate / 1.1; if (gas[i].t >= 1) gas.splice(i, 1); }
      if (gas.length > 600) gas.splice(0, gas.length - 600);
    }
    function drawGas(st) {
      var r = Math.max(1.4, 2.6 * sc);
      gas.forEach(function (g) {
        var lungG = Math.abs(g.y0 - 250) < 80;
        if (st.mode === 'sys' && lungG || st.mode === 'pul' && !lungG) return;
        var a = Math.sin(Math.PI * g.t);
        ctx.globalAlpha = a * 0.9;
        ctx.fillStyle = g.c;
        ctx.beginPath(); ctx.arc(X(g.x0 + (g.x1 - g.x0) * g.t), Y(g.y0 + (g.y1 - g.y0) * g.t), r, 0, 7); ctx.fill();
      });
      ctx.globalAlpha = 1;
    }

    // ---------- 追踪 ----------
    function drawRoute(tr) {
      var ids = tr.route.ids;
      ctx.lineJoin = 'round'; ctx.lineCap = 'round';
      ids.forEach(function (id, i) {
        var e = E[id], done = i < tr.route.i, cur = i === tr.route.i;
        ctx.strokeStyle = 'rgba(255,209,102,' + (cur ? 0.32 : done ? 0.2 : 0.12) + ')';
        if (e.type === 'ch') {
          var ch = B.CHAMBER[id];
          rrect(ch.x0 - 3, ch.y0 - 3, ch.x1 + 3, ch.y1 + 3, 12); ctx.lineWidth = 4 * sc; ctx.stroke();
        } else if (e.type === 'cap') {
          ctx.lineWidth = 10 * sc; path(e.polys[tr.p.k].pts); ctx.stroke();
        } else {
          ctx.lineWidth = (e.w + 12) * sc; path(e.pts); ctx.stroke();
        }
      });
    }
    function drawTracer(tr, h, t) {
      var q = posOf(tr.p, h), x = X(q.x), y = Y(q.y), r = Math.max(5, 8 * sc);
      ctx.beginPath(); ctx.arc(x, y, r * (1.8 + 0.4 * Math.sin(t * 6)), 0, 7);
      ctx.fillStyle = 'rgba(255,209,102,0.18)'; ctx.fill();
      ctx.beginPath(); ctx.arc(x, y, r, 0, 7);
      ctx.fillStyle = col(tr.p.s); ctx.fill();
      ctx.lineWidth = 2.5; ctx.strokeStyle = '#fff'; ctx.stroke();
    }

    // ---------- 文字 ----------
    function drawLabels(st) {
      var f = fs(13), fsm = fs(11.5);
      // 心腔
      [['ra', '右心房'], ['rv', '右心室'], ['la', '左心房'], ['lv', '左心室']].forEach(function (a) {
        var ch = B.CHAMBER[a[0]];
        label(a[1], X((ch.x0 + ch.x1) / 2), Y(a[0] === 'ra' || a[0] === 'la' ? ch.y0 + 14 : ch.y1 - 14), '#fff', 'center', f, '600');
      });
      var vl = [
        ['上腔静脉', 290, 250, 'right'], ['下腔静脉', 290, 600, 'right'], ['肺动脉', 357, 365, 'left'],
        ['肺静脉', 633, 365, 'right'], ['主动脉', 710, 330, 'left']
      ];
      vl.forEach(function (a) { label(a[0], X(a[1]), Y(a[2]), C.text, a[3], f); });
      // 瓣膜（只标左心一侧）
      if (!narrow) {
        ctx.strokeStyle = 'rgba(141,153,171,0.6)'; ctx.lineWidth = 1;
        ctx.beginPath(); ctx.moveTo(X(612), Y(476)); ctx.lineTo(X(586), Y(474)); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(X(612), Y(548)); ctx.lineTo(X(604), Y(530)); ctx.stroke();
        label('房室瓣', X(614), Y(477), C.muted, 'left', fsm);
        label('动脉瓣', X(614), Y(550), C.muted, 'left', fsm);
      }
      // 器官
      label('头部和上肢的毛细血管网', X(500), Y(42), C.muted, 'center', fsm);
      label('右肺', X(398), Y(196), C.muted, 'center', fsm);
      label('左肺', X(602), Y(196), C.muted, 'center', fsm);
      label('气管', X(512), Y(160), C.muted, 'left', fsm);
      label('肺部毛细血管网（肺泡外）', X(500), Y(336), C.muted, 'center', fsm);
      ['gut', 'kid', 'leg'].forEach(function (id) {
        var b = BEDS[id];
        label(b.label, X(b.x0 + 10), Y(b.y0 + 12), C.muted, 'left', fsm, '600');
      });
      // 体循环、肺循环
      font(fs(18), '700'); ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillStyle = st.mode === 'pul' ? 'rgba(255,201,74,0.75)' : 'rgba(141,153,171,0.4)';
      ctx.fillText('肺循环', X(500), Y(372));
      ctx.fillStyle = st.mode === 'sys' ? 'rgba(255,201,74,0.75)' : 'rgba(141,153,171,0.4)';
      ctx.fillText('体循环', X(500), Y(622));
    }

    function drawTip(st) {
      if (!st.tip) return;
      font(13, '600');
      var w = ctx.measureText(st.tip.text).width + 16, x = Math.min(st.tip.x + 14, W - w - 6), y = Math.max(st.tip.y - 30, 6);
      ctx.fillStyle = 'rgba(17,23,35,0.92)'; ctx.strokeStyle = '#2a3446'; ctx.lineWidth = 1;
      ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(x, y, w, 24, 6); else ctx.rect(x, y, w, 24); ctx.fill(); ctx.stroke();
      ctx.fillStyle = C.accent; ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
      ctx.fillText(st.tip.text, x + 8, y + 12);
    }

    // ---------- 主绘制 ----------
    function draw(st, sim, tracer, h, vo, dt, t) {
      palette(st.colors);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, W, H);
      drawLungs(st);
      drawBeds(st);
      if (tracer) drawRoute(tracer);
      drawVessels(st);
      drawCaps(st);
      drawHeart(st, h);
      if (st.show.gas) { spawnGas(dt, st); drawGas(st); }
      if (st.show.cells) drawCells(st, sim, h);
      drawValves(st, vo);
      if (tracer) drawTracer(tracer, h, t);
      if (st.show.labels) drawLabels(st);
      drawTip(st);
    }

    // ---------- 命中测试 ----------
    function distSeg(px, py, x0, y0, x1, y1) {
      var dx = x1 - x0, dy = y1 - y0, l2 = dx * dx + dy * dy, u = l2 ? ((px - x0) * dx + (py - y0) * dy) / l2 : 0;
      u = Math.max(0, Math.min(1, u));
      return Math.hypot(px - x0 - dx * u, py - y0 - dy * u);
    }
    function hit(px, py) {
      var v = toV(px, py), x = v.x, y = v.y, pad = 5 / sc;
      var vk = Object.keys(B.VALVE);
      for (var i = 0; i < vk.length; i++) {
        var va = B.VALVE[vk[i]];
        if (va.kind === 'av' ? x >= va.x0 - 2 && x <= va.x1 + 2 && Math.abs(y - va.y) < 7 + pad
          : y >= va.y0 - 2 && y <= va.y1 + 2 && Math.abs(x - va.x) < 7 + pad) return vk[i];
      }
      var ck = ['ra', 'rv', 'la', 'lv'];
      for (i = 0; i < ck.length; i++) {
        var c = B.CHAMBER[ck[i]];
        if (x >= c.x0 && x <= c.x1 && y >= c.y0 && y <= c.y1) return ck[i];
      }
      var best = null, bd = 1e9;
      Object.keys(E).forEach(function (id) {
        var e = E[id];
        if (e.type === 'ch' || e.type === 'cap') return;
        var p = e.pts;
        for (var j = 2; j < p.length; j += 2) {
          var d = distSeg(x, y, p[j - 2], p[j - 1], p[j], p[j + 1]);
          if (d < e.w / 2 + pad && d < bd) { bd = d; best = id; }
        }
      });
      if (best) return best;
      for (i = 0; i < LUNGS.length; i++) if (Math.hypot(x - LUNGS[i].x, y - LUNGS[i].y) < LUNGS[i].r) return 'lung';
      var bk = Object.keys(BEDS);
      for (i = 0; i < bk.length; i++) {
        var b = BEDS[bk[i]];
        if (x >= b.x0 && x <= b.x1 && y >= b.y0 && y <= b.y1) return bk[i];
      }
      return null;
    }

    return { resize: resize, draw: draw, hit: hit };
  }

  window.BloodDraw = BloodDraw;
})();
