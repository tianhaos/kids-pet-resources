// 人体血液循环的"管网"与血流模拟（纯计算，不涉及绘图）
// 虚拟坐标 1000×1000，y 向下；面对人体绘制：图的左侧是人体的右侧（右心房、右心室在左）。
// 血液由许多"血细胞"粒子表示：沿管道（边）流动，在分叉处按血流比例选路；s = 含氧程度（1 动脉血，0 静脉血），
// 在肺部毛细血管里升到 1，在全身毛细血管里降到 0。心脏的瓣膜按心动周期开闭，关闭时粒子在心腔内等待。
(function () {
  // ---------- 心腔与瓣膜 ----------
  var CHAMBER = {
    ra: { x0: 404, x1: 486, y0: 399, y1: 464 },
    rv: { x0: 404, x1: 486, y0: 480, y1: 556 },
    la: { x0: 514, x1: 596, y0: 399, y1: 464 },
    lv: { x0: 522, x1: 590, y0: 482, y1: 562 }
  };
  // 房室瓣水平放置（a、b 为两端，开向心室）；动脉瓣竖直放置（开向动脉）
  var VALVE = {
    avR: { kind: 'av', x0: 410, x1: 480, y: 472 },
    avL: { kind: 'av', x0: 520, x1: 590, y: 472 },
    svP: { kind: 'sl', x: 396, y0: 516, y1: 544, dir: -1 },   // 肺动脉瓣，开向左
    svA: { kind: 'sl', x: 604, y0: 506, y1: 534, dir: 1 }      // 主动脉瓣，开向右
  };

  // ---------- 毛细血管网：在入口与出口之间铺几条弯曲的细管 ----------
  function capPaths(xa, xb, y, spread, n, seed) {
    var out = [];
    for (var k = 0; k < n; k++) {
      var off = (k / (n - 1) - 0.5) * 2 * spread, ph = seed + k * 1.7, pts = [];
      for (var i = 0; i <= 28; i++) {
        var u = i / 28, bell = Math.sin(Math.PI * u);
        var x = xa + (xb - xa) * u;
        var yy = y + off * Math.pow(bell, 0.6) + Math.sin(u * Math.PI * 7 + ph) * 6 * bell;
        pts.push(x, yy);
      }
      out.push(pts);
    }
    return out;
  }

  // ---------- 管道（边） ----------
  // type: art 动脉 / vein 静脉 / cap 毛细血管网 / ch 心腔；circ: sys 体循环 / pul 肺循环
  // w 管径；next 下游 [边, 权重]；gate 末端的瓣膜；o2 毛细血管网中含氧量的去向
  var E = {};
  function edge(id, o) { o.id = id; E[id] = o; return o; }

  edge('svc',   { type: 'vein', circ: 'sys', w: 18, name: '上腔静脉', pts: [330, 90, 300, 90, 300, 440], next: [['vc', 1]] });
  edge('v_gut', { type: 'vein', circ: 'sys', w: 11, name: '小肠静脉', pts: [380, 680, 300, 680], next: [['ivc1', 1]] });
  edge('v_kid', { type: 'vein', circ: 'sys', w: 11, name: '肾静脉', pts: [380, 780, 300, 780], next: [['ivc2', 1]] });
  edge('v_leg', { type: 'vein', circ: 'sys', w: 12, name: '下肢静脉', pts: [380, 890, 300, 890], next: [['ivc3', 1]] });
  edge('ivc3',  { type: 'vein', circ: 'sys', w: 15, name: '下腔静脉', pts: [300, 890, 300, 780], next: [['ivc2', 1]] });
  edge('ivc2',  { type: 'vein', circ: 'sys', w: 17, name: '下腔静脉', pts: [300, 780, 300, 680], next: [['ivc1', 1]] });
  edge('ivc1',  { type: 'vein', circ: 'sys', w: 18, name: '下腔静脉', pts: [300, 680, 300, 440], next: [['vc', 1]] });
  edge('vc',    { type: 'vein', circ: 'sys', w: 20, name: '上、下腔静脉', pts: [300, 440, 404, 440], next: [['ra', 1]] });
  edge('ra',    { type: 'ch', circ: 'sys', w: 40, name: '右心房', pts: [404, 440, 430, 448, 445, 468], gate: 'av', next: [['rv', 1]] });
  edge('rv',    { type: 'ch', circ: 'pul', w: 40, name: '右心室', pts: [445, 476, 452, 522, 436, 532, 404, 530], gate: 'sl', next: [['pa', 1]] });
  edge('pa',    { type: 'art', circ: 'pul', w: 16, name: '肺动脉', pts: [396, 530, 350, 530, 350, 250, 380, 250], next: [['lung', 1]] });
  edge('lung',  { type: 'cap', circ: 'pul', w: 3, name: '肺部毛细血管', paths: capPaths(380, 620, 250, 46, 6, 0.3), o2: 1, next: [['pv', 1]] });
  edge('pv',    { type: 'vein', circ: 'pul', w: 15, name: '肺静脉', pts: [620, 250, 640, 250, 640, 430, 596, 430], next: [['la', 1]] });
  edge('la',    { type: 'ch', circ: 'pul', w: 40, name: '左心房', pts: [596, 430, 572, 440, 555, 468], gate: 'av', next: [['lv', 1]] });
  edge('lv',    { type: 'ch', circ: 'sys', w: 40, name: '左心室', pts: [555, 476, 550, 534, 572, 532, 596, 520], gate: 'sl', next: [['ao', 1]] });
  edge('ao',    { type: 'art', circ: 'sys', w: 19, name: '主动脉', pts: [604, 520, 700, 520], next: [['ao_up', 0.25], ['ao_dn1', 0.75]] });
  edge('ao_up', { type: 'art', circ: 'sys', w: 14, name: '主动脉', pts: [700, 520, 700, 90, 670, 90], next: [['head', 1]] });
  edge('head',  { type: 'cap', circ: 'sys', w: 3, name: '头部和上肢的毛细血管', paths: capPaths(670, 330, 90, 30, 6, 1.1), o2: 0, next: [['svc', 1]] });
  edge('ao_dn1', { type: 'art', circ: 'sys', w: 17, name: '主动脉', pts: [700, 520, 700, 680], next: [['a_gut', 0.35], ['ao_dn2', 0.65]] });
  edge('a_gut', { type: 'art', circ: 'sys', w: 11, name: '小肠动脉', pts: [700, 680, 620, 680], next: [['gut', 1]] });
  edge('gut',   { type: 'cap', circ: 'sys', w: 3, name: '小肠的毛细血管', paths: capPaths(620, 380, 680, 22, 5, 2.3), o2: 0, next: [['v_gut', 1]] });
  edge('ao_dn2', { type: 'art', circ: 'sys', w: 15, name: '主动脉', pts: [700, 680, 700, 780], next: [['a_kid', 0.4], ['ao_dn3', 0.6]] });
  edge('a_kid', { type: 'art', circ: 'sys', w: 11, name: '肾动脉', pts: [700, 780, 620, 780], next: [['kid', 1]] });
  edge('kid',   { type: 'cap', circ: 'sys', w: 3, name: '肾内的毛细血管', paths: capPaths(620, 380, 780, 20, 5, 0.7), o2: 0, next: [['v_kid', 1]] });
  edge('ao_dn3', { type: 'art', circ: 'sys', w: 13, name: '主动脉', pts: [700, 780, 700, 890, 620, 890], next: [['leg', 1]] });
  edge('leg',   { type: 'cap', circ: 'sys', w: 3, name: '下肢的毛细血管', paths: capPaths(620, 380, 890, 22, 5, 1.9), o2: 0, next: [['v_leg', 1]] });

  // 折线长度预计算
  function prep(pts) {
    var L = [0];
    for (var i = 2; i < pts.length; i += 2) L.push(L[L.length - 1] + Math.hypot(pts[i] - pts[i - 2], pts[i + 1] - pts[i - 1]));
    return { pts: pts, L: L, len: L[L.length - 1] };
  }
  Object.keys(E).forEach(function (id) {
    var e = E[id];
    e.polys = (e.paths || [e.pts]).map(prep);
    e.len = e.polys.reduce(function (a, p) { return a + p.len; }, 0) / e.polys.length;
  });

  // 折线上距起点 t 处的点与切线方向
  function at(poly, t) {
    var L = poly.L, p = poly.pts, n = L.length;
    if (t <= 0) t = 0;
    if (t >= poly.len) t = poly.len - 1e-6;
    var i = 1;
    while (i < n - 1 && L[i] < t) i++;
    var a = (t - L[i - 1]) / ((L[i] - L[i - 1]) || 1);
    var x0 = p[2 * i - 2], y0 = p[2 * i - 1], x1 = p[2 * i], y1 = p[2 * i + 1], d = Math.hypot(x1 - x0, y1 - y0) || 1;
    return { x: x0 + (x1 - x0) * a, y: y0 + (y1 - y0) * a, dx: (x1 - x0) / d, dy: (y1 - y0) / d };
  }

  // ---------- 心动周期（心率 75 次/分时：心房收缩 0.1 s，心室收缩 0.3 s，全心舒张 0.4 s） ----------
  var PH_A = 0.125, PH_V = 0.5;
  function heart(phase) {
    var h = { phase: phase };
    if (phase < PH_A) {
      var a = phase / PH_A;
      h.key = 'atrial'; h.name = '心房收缩'; h.av = true; h.sl = false;
      h.aSq = Math.sin(Math.PI * a); h.vSq = 0; h.eject = 0;
    } else if (phase < PH_V) {
      var v = (phase - PH_A) / (PH_V - PH_A);
      h.key = 'ventricular'; h.name = '心室收缩'; h.av = false; h.sl = v > 0.06;    // 等容收缩期很短
      h.aSq = 0; h.vSq = Math.sin(Math.PI * Math.min(1, v * 1.15)); h.eject = h.sl ? Math.sin(Math.PI * v) : 0;
    } else {
      h.key = 'diastole'; h.name = '全心舒张'; h.av = true; h.sl = false;
      h.aSq = 0; h.vSq = 0; h.eject = 0;
    }
    return h;
  }

  // ---------- 血流模拟 ----------
  var SPEED = { art: 260, vein: 170, cap: 70, ch: 130 };
  // 这一段里流的是动脉血吗（毛细血管网除外）
  function oxy(id) { var e = E[id]; return (e.circ === 'sys' && (e.type === 'art' || id === 'lv')) || id === 'pv' || id === 'la' ? 1 : 0; }
  function smooth(u) { u = Math.max(0, Math.min(1, u)); return u * u * (3 - 2 * u); }
  function pick(next, R) {
    if (next.length === 1) return next[0][0];
    var r = R(), acc = 0;
    for (var i = 0; i < next.length; i++) { acc += next[i][1]; if (r <= acc) return next[i][0]; }
    return next[next.length - 1][0];
  }

  // 一个粒子沿边前进 dist；route 为追踪路线（只走指定的边）。返回 false 表示走到了路线终点
  function advance(p, dt, h, rate, R, route) {
    var guard = 0;
    while (dt > 1e-6 && guard++ < 8) {
      var e = E[p.e], sp = SPEED[e.type] * rate;
      if (e.type === 'art') sp *= 0.45 + 1.7 * h.eject;
      var open = !e.gate || (e.gate === 'av' ? h.av : h.sl);
      if (e.type === 'ch') {
        if (open) sp *= e.gate === 'av' ? 1.4 + 1.6 * h.aSq : 1.2 + 2.2 * h.eject;
      }
      var len = e.polys[p.k].len;
      var limit = open ? Infinity : len - 6 - p.q * len * 0.62;    // 瓣膜关闭：在心腔里排队等待
      if (route && route.stopAt === route.i && p.t >= route.stopT * len) return false;
      var nt = p.t + sp * dt;
      if (nt < len || nt > limit) {
        p.t = Math.min(nt, Math.max(p.t, limit));
        if (route && route.stopAt === route.i) p.t = Math.min(p.t, route.stopT * len);
        if (e.type === 'cap') {
          var f = smooth(p.t / len);
          p.s = e.o2 ? p.s0 + (1 - p.s0) * f : p.s0 * (1 - f);
        }
        return true;
      }
      // 进入下一段
      dt -= (len - p.t) / sp;
      if (e.type === 'cap') p.s = e.o2;
      var nx;
      if (route) {
        if (route.i >= route.ids.length - 1) { p.t = len - 1e-3; return false; }
        nx = route.ids[++route.i];
      } else nx = pick(e.next, R);
      p.e = nx; p.t = 0;
      p.k = E[nx].polys.length > 1 ? Math.floor(R() * E[nx].polys.length) : 0;
      p.s0 = p.s;
    }
    return true;
  }

  function Sim(n) {
    var seed = 12345;
    function R() { seed = (seed * 16807) % 2147483647; return (seed - 1) / 2147483646; }
    var ids = Object.keys(E), total = 0;
    ids.forEach(function (id) { total += E[id].len; });
    var parts = [];
    for (var i = 0; i < n; i++) {
      // 按长度随机撒在各段上
      var r = R() * total, id = ids[0];
      for (var j = 0; j < ids.length; j++) { r -= E[ids[j]].len; if (r <= 0) { id = ids[j]; break; } }
      var e = E[id], k = e.polys.length > 1 ? Math.floor(R() * e.polys.length) : 0;
      var s = e.type === 'cap' ? 0.5 : oxy(id);
      parts.push({ e: id, k: k, t: R() * e.polys[k].len, q: R(), lane: R() * 2 - 1, s: s, s0: s });
    }
    var sim = {
      parts: parts, R: R,
      step: function (dt, h, rate) { for (var i = 0; i < parts.length; i++) advance(parts[i], dt, h, rate, R); }
    };
    // 预热：先模拟一会儿，让血细胞的分布稳定下来
    for (var t = 0; t < 24; t += 0.04) sim.step(0.04, heart((t / 0.8) % 1), 1);
    return sim;
  }

  // ---------- 追踪路线 ----------
  var SYS_LEG = ['ao', 'ao_dn1', 'ao_dn2', 'ao_dn3'];
  var ROUTES = {
    sys: { name: '体循环', ids: ['lv'].concat(SYS_LEG, ['leg', 'v_leg', 'ivc3', 'ivc2', 'ivc1', 'vc', 'ra']),
      note: '左心室 → 主动脉 → 各级动脉 → 身体各处的毛细血管网 → 各级静脉 → 上、下腔静脉 → 右心房。流经组织处的毛细血管后，动脉血变成静脉血。' },
    pul: { name: '肺循环', ids: ['rv', 'pa', 'lung', 'pv', 'la'],
      note: '右心室 → 肺动脉 → 肺部毛细血管网 → 肺静脉 → 左心房。流经肺部毛细血管后，静脉血变成动脉血。' },
    whole: { name: '红细胞走完一圈', ids: ['lv', 'ao', 'ao_up', 'head', 'svc', 'vc', 'ra', 'rv', 'pa', 'lung', 'pv', 'la', 'lv'],
      note: '体循环和肺循环同时进行，在心脏处连通：红细胞从左心室出发，经体循环回到右心房，再经肺循环回到左心房、左心室。' },
    inject: { name: '手臂静脉注射 → 肺', ids: ['svc', 'vc', 'ra', 'rv', 'pa', 'lung'], start: 0.05, stopT: 0.5,
      note: '从手臂静脉注射的药物经上腔静脉最先到达右心房，再经右心室、肺动脉到达肺部。治疗肺炎时药物经过心脏 1 次。' },
    oral: { name: '小肠吸收的药物 → 脑', ids: ['gut', 'v_gut', 'ivc1', 'vc', 'ra', 'rv', 'pa', 'lung', 'pv', 'la', 'lv', 'ao', 'ao_up', 'head'], start: 0.45, stopT: 0.5,
      note: '口服药物在小肠被吸收进入血液，经下腔静脉回到右心房，经肺循环回到左心，再经主动脉到达头部。途中经过心脏 2 次。' },
    o2: { name: '肺泡中的氧 → 下肢肌肉', ids: ['lung', 'pv', 'la', 'lv'].concat(SYS_LEG, ['leg']), start: 0.45, stopT: 0.5,
      note: '氧从肺泡扩散进入肺部毛细血管，与红细胞中的血红蛋白结合，经肺静脉 → 左心房 → 左心室 → 主动脉，送到下肢的毛细血管，再扩散进入肌肉细胞。' },
    co2: { name: '下肢的二氧化碳 → 呼出', ids: ['leg', 'v_leg', 'ivc3', 'ivc2', 'ivc1', 'vc', 'ra', 'rv', 'pa', 'lung'], start: 0.45, stopT: 0.5,
      note: '肌肉细胞产生的二氧化碳扩散进入毛细血管，经下肢静脉 → 下腔静脉 → 右心房 → 右心室 → 肺动脉，到达肺部毛细血管后扩散进入肺泡，随呼气排出体外。' }
  };

  function Tracer(key) {
    var r = ROUTES[key], ids = r.ids;
    var route = { ids: ids, i: 0, stopAt: r.stopT != null ? ids.length - 1 : -1, stopT: r.stopT };
    var e0 = E[ids[0]];
    var s = oxy(ids[0]);
    var p = { e: ids[0], k: Math.floor(e0.polys.length / 2), t: (r.start || 0) * e0.polys[0].len, q: 0.15, lane: 0, s: s, s0: s };
    if (e0.type === 'cap') {   // 从毛细血管网中途出发时，含氧量按位置折算
      var f = smooth(r.start || 0);
      p.s0 = e0.o2 ? 0 : 1;
      p.s = e0.o2 ? f : 1 - f;
    }
    var R = function () { return 0.5; };
    return {
      key: key, route: route, p: p, done: false,
      step: function (dt, h, rate) { if (!this.done && !advance(p, dt, h, rate, R, route)) this.done = true; }
    };
  }

  window.Blood = {
    CHAMBER: CHAMBER, VALVE: VALVE, E: E, ROUTES: ROUTES,
    at: at, heart: heart, oxy: oxy, Sim: Sim, Tracer: Tracer
  };
})();
