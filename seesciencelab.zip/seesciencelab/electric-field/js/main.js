(function () {
  var F = window.Field, D = window.FieldDraw;
  var $ = function (id) { return document.getElementById(id); };
  var qa = function (sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); };
  var NAME = '电场线与等势面';

  var state = {
    scene: 'field', preset: 'dipole', cfg: F.preset('dipole'),
    density: 12, du: 20, show: { lines: true, eq: true, heat: false, nulls: true, probe: true }, plot: 'off',
    probe: { x: 0, y: 5 }, sel: -1, tool: 'move',
    A: { x: -4, y: 6 }, B: { x: 5, y: -5 }, sg: 1, path: 'line', t: 0, playing: false,
    quiz: null, quizOnly: null, answered: false, correct: false, choice: null, score: { n: 0, ok: 0 }
  };

  var HINTS = {
    field: '拖动电荷或 P 点 · 面板里可以放置、删除电荷',
    work: '拖动 A、B 两点 · 点「移动试探电荷」看做功',
    quiz: '电场线与等势面 · 判断练习'
  };
  var TIPS = {
    pos: '正点电荷的电场线从电荷出发向外辐射；等势面是一簇以电荷为球心的球面，越靠近电荷越密。E = kQ/r²，φ = kQ/r。',
    neg: '负点电荷的电场线从无穷远指向电荷；越靠近负电荷电势越低（为负值）。等势线处处与电场线垂直。',
    dipole: '等量异种：连线上中点场强最小，中垂线上中点场强最大；中垂线是一条等势线，电势与无穷远相同，为零。',
    same: '等量同种：连线中点场强为零，但电势不为零；中垂线上从中点向外，场强先增大后减小。',
    unequal: '不等量异种：+2Q 发出的电场线只有一半终止于 −Q，其余延伸到无穷远；在 −Q 外侧连线上有一点场强为零。',
    plates: '平行板之间（远离边缘处）是匀强电场：电场线平行、等距，等势面是一组与板平行的平面，E = U/d；边缘处电场线弯曲。',
    custom: '电场线从正电荷出发、终止于负电荷或无穷远，不相交、不闭合；等势线处处与电场线垂直；沿电场线方向电势降低。',
    empty: '画面里还没有电荷：在面板「工具」里选「放 +Q」或「放 −Q」，再点画面放置。'
  };
  var PRESET_KEYS = ['pos', 'neg', 'dipole', 'same', 'unequal', 'plates'];

  var stage = $('stage'), panel = $('panel'), cv = $('view');
  var view = D.View(cv), fr = null, geo = null, dirty = true, work = null, workDirty = true;
  function setSeg(attr, val) { qa('[data-' + attr + ']').forEach(function (b) { b.classList.toggle('on', b.dataset[attr] === String(val)); }); }
  function touch() { dirty = true; workDirty = true; state.playing = false; state.t = 0; }
  function curCfg() { return state.scene === 'quiz' && state.quiz ? state.quiz.cfg : state.cfg; }
  function custom() { state.preset = state.cfg.charges.length || state.cfg.plates ? 'custom' : 'empty'; }

  // ---------- 场景 ----------
  qa('[data-scene]').forEach(function (b) {
    b.addEventListener('click', function () { setScene(b.dataset.scene); Analytics.track(NAME, '场景', b.textContent); });
  });
  function setScene(sc) {
    state.scene = sc;
    if (sc === 'quiz' && !state.quiz) newQuiz();
    $('rName').className = '';
    touch(); syncUI();
  }

  // ---------- 电荷 ----------
  function setPreset(k) {
    state.preset = k; state.cfg = k === 'empty' ? { charges: [], plates: false } : F.preset(k); state.sel = -1;
    if (k === 'plates' && Math.abs(state.probe.x) > 5) state.probe = { x: 0, y: 5 };
    touch(); syncUI();
  }
  qa('[data-preset]').forEach(function (b) {
    b.addEventListener('click', function () { setPreset(b.dataset.preset); Analytics.track(NAME, '电荷分布', b.textContent); });
  });
  qa('[data-tool]').forEach(function (b) {
    b.addEventListener('click', function () { state.tool = b.dataset.tool; syncUI(); Analytics.track(NAME, '工具', b.textContent); });
  });
  qa('[data-qsign]').forEach(function (b) {
    b.addEventListener('click', function () {
      var c = state.cfg.charges[state.sel]; if (!c) return;
      c.q = (b.dataset.qsign === '+' ? 1 : -1) * Math.abs(c.q); custom(); touch(); syncUI();
    });
  });
  $('qmag').addEventListener('input', function () {
    var c = state.cfg.charges[state.sel]; if (!c) return;
    c.q = (c.q > 0 ? 1 : -1) * parseInt($('qmag').value, 10); custom(); touch(); syncUI();
  });
  $('qmag').addEventListener('change', function () { Analytics.track(NAME, '滑块', '电荷量'); });
  $('delSel').addEventListener('click', function () {
    if (state.sel < 0) return;
    state.cfg.charges.splice(state.sel, 1); state.sel = -1; custom(); touch(); syncUI();
  });

  // ---------- 显示 ----------
  [['showLines', 'lines'], ['showEq', 'eq'], ['showHeat', 'heat'], ['showNulls', 'nulls'], ['showProbe', 'probe']].forEach(function (p) {
    $(p[0]).addEventListener('change', function () {
      state.show[p[1]] = $(p[0]).checked;
      if (p[1] === 'probe' && !state.show.probe) state.plot = 'off';   // 图像画的是过 P 的直线
      touch(); syncUI(); Analytics.track(NAME, '显示', p[1] + (state.show[p[1]] ? ' 开' : ' 关'));
    });
  });
  $('density').addEventListener('input', function () { state.density = parseInt($('density').value, 10); touch(); });
  $('density').addEventListener('change', function () { Analytics.track(NAME, '滑块', '电场线密度'); });
  qa('[data-du]').forEach(function (b) {
    b.addEventListener('click', function () { state.du = +b.dataset.du; touch(); syncUI(); Analytics.track(NAME, '等势线间隔', b.textContent); });
  });
  qa('[data-plot]').forEach(function (b) {
    b.addEventListener('click', function () {
      state.plot = b.dataset.plot; if (state.plot !== 'off') state.show.probe = true;
      touch(); syncUI(); Analytics.track(NAME, '图像', b.textContent);
    });
  });

  // ---------- 电场力做功 ----------
  qa('[data-sg]').forEach(function (b) {
    b.addEventListener('click', function () { state.sg = b.dataset.sg === '+' ? 1 : -1; workDirty = true; state.t = 0; state.playing = false; syncUI(); Analytics.track(NAME, '试探电荷', b.textContent); });
  });
  qa('[data-path]').forEach(function (b) {
    b.addEventListener('click', function () { state.path = b.dataset.path; workDirty = true; state.t = 0; state.playing = false; syncUI(); Analytics.track(NAME, '路径', b.textContent); });
  });
  $('play').addEventListener('click', function () {
    if (state.t >= 1) state.t = 0;
    state.playing = !state.playing; syncUI();
    if (state.playing) Analytics.track(NAME, '移动试探电荷', state.path);
  });
  $('toEquip').addEventListener('click', function () {
    var cfg = state.cfg, v = fr.view;
    function inside(p) { return p.x > v.x0 + 1 && p.x < v.x1 - 1 && p.y > v.y0 + 1 && p.y < v.y1 - 1; }
    var best = null;
    [1, -1].forEach(function (s) {
      var pts = F.alongEquipotential(cfg, state.A, 10, s), e = null;
      for (var i = pts.length - 1; i > 0; i--) if (inside(pts[i])) { e = pts[i]; break; }
      if (e && (!best || Math.hypot(e.x - state.A.x, e.y - state.A.y) > Math.hypot(best.x - state.A.x, best.y - state.A.y))) best = e;
    });
    if (best) { state.B = best; workDirty = true; state.t = 0; state.playing = false; }
    Analytics.track(NAME, '一键', 'B 移到等势面');
  });

  // ---------- 画布交互 ----------
  var drag = null;
  function local(e) { var r = cv.getBoundingClientRect(); return { x: e.clientX - r.left, y: e.clientY - r.top }; }
  function hitCharge(p) {
    var cs = state.cfg.charges, best = -1, bd = 1e9;
    for (var i = 0; i < cs.length; i++) {
      var s = fr.p(cs[i].x, cs[i].y), d = Math.hypot(s.x - p.x, s.y - p.y), r = 11 + Math.abs(cs[i].q) * 1.2 + 8;
      if (d < r && d < bd) { bd = d; best = i; }
    }
    return best;
  }
  function hitPt(p, w) { var s = fr.p(w.x, w.y); return Math.hypot(s.x - p.x, s.y - p.y) < 20; }
  function snap(w) {
    var v = fr.view;
    return { x: F.clamp(Math.round(w.x * 2) / 2, v.x0 + 0.5, v.x1 - 0.5), y: F.clamp(Math.round(w.y * 2) / 2, v.y0 + 0.5, v.y1 - 0.5) };
  }
  function msg(s) { $('hint').textContent = s; clearTimeout(msg.t); msg.t = setTimeout(syncUI, 2500); }
  cv.addEventListener('pointerdown', function (e) {
    if (e.button !== 0 || !fr || state.scene === 'quiz') return;
    var p = local(e); if (p.y > fr.R.h) return;
    var w = snap(fr.w(p.x, p.y)), hit = hitCharge(p), cs = state.cfg.charges;
    if (state.tool === 'del') {
      if (hit >= 0) { cs.splice(hit, 1); state.sel = -1; custom(); touch(); syncUI(); Analytics.track(NAME, '删除电荷', ''); }
      return;
    }
    if (state.tool === 'add+' || state.tool === 'add-') {
      if (cs.length >= F.MAX_CHARGES) { msg('最多放 ' + F.MAX_CHARGES + ' 个点电荷'); return; }
      if (hit < 0) {
        cs.push({ x: w.x, y: w.y, q: state.tool === 'add+' ? 1 : -1, th0: 0 });
        state.sel = cs.length - 1; state.preset = 'custom'; touch(); syncUI(); Analytics.track(NAME, '放电荷', state.tool);
        return;
      }
    }
    if (hit >= 0) { drag = { type: 'charge', i: hit }; state.sel = hit; syncUI(); }
    else if (state.scene === 'work') {
      if (hitPt(p, state.A)) drag = { type: 'A' };
      else if (hitPt(p, state.B)) drag = { type: 'B' };
      else return;
    } else {
      if (!state.show.probe) { state.show.probe = true; syncUI(); }
      drag = { type: 'probe' }; state.probe = w;
    }
    try { cv.setPointerCapture(e.pointerId); } catch (err) { /* 合成事件 */ }
    Analytics.track(NAME, '拖动', drag.type);
  });
  cv.addEventListener('pointermove', function (e) {
    if (!fr) return;
    var p = local(e);
    if (!drag) {
      var over = state.scene !== 'quiz' && (hitCharge(p) >= 0 || (state.scene === 'work' && (hitPt(p, state.A) || hitPt(p, state.B))));
      cv.style.cursor = state.scene === 'quiz' ? '' : state.tool === 'move' ? (over ? 'grab' : state.scene === 'field' ? 'crosshair' : '') : 'copy';
      if (state.tool === 'del') cv.style.cursor = hitCharge(p) >= 0 ? 'not-allowed' : '';
      return;
    }
    var w = snap(fr.w(p.x, p.y));
    if (drag.type === 'charge') {
      var c = state.cfg.charges[drag.i];
      if (c.x !== w.x || c.y !== w.y) { c.x = w.x; c.y = w.y; custom(); touch(); }
    } else if (drag.type === 'probe') state.probe = w;
    else { state[drag.type] = w; workDirty = true; state.t = 0; state.playing = false; }
  });
  function endDrag(e) {
    if (!drag) return;
    drag = null;
    if (cv.hasPointerCapture(e.pointerId)) cv.releasePointerCapture(e.pointerId);
    syncUI();
  }
  cv.addEventListener('pointerup', endDrag);
  cv.addEventListener('pointercancel', endDrag);

  // ---------- 练习 ----------
  function newQuiz() {
    state.quiz = F.quiz(state.quizOnly); state.answered = false; state.choice = null;
    var box = $('quizOpts'); box.innerHTML = '';
    box.className = 'answer' + (state.quiz.options.length === 4 ? '' : ' three');
    state.quiz.options.forEach(function (s) {
      var b = document.createElement('button'); b.textContent = s;
      b.addEventListener('click', function () { answer(s); });
      box.appendChild(b);
    });
    touch(); syncUI();
  }
  function answer(s) {
    if (state.answered) return;
    state.answered = true; state.choice = s; state.correct = s === state.quiz.answer;
    state.score.n++; if (state.correct) state.score.ok++;
    Analytics.track(NAME, '练习', state.quiz.type + (state.correct ? ' 对' : ' 错'));
    touch(); syncUI();
  }
  $('nextQ').addEventListener('click', newQuiz);
  $('showQ').addEventListener('click', function () {
    var q = state.quiz;
    state.cfg = { charges: q.cfg.charges.map(function (c) { return { x: c.x, y: c.y, q: c.q, th0: c.th0 }; }), plates: q.cfg.plates };
    var c0 = q.cfg.charges[0], c1 = q.cfg.charges[1];
    state.preset = q.key || (c0.q > 0 && c1.q < 0 ? 'dipole' : c0.q > 0 && c1.q > 0 ? 'same' : 'custom');
    state.sel = -1;
    if (q.A) {
      state.A = { x: q.A.x, y: q.A.y }; state.B = { x: q.B.x, y: q.B.y }; state.sg = q.sg || 1; state.path = 'line';
      setScene(q.type === 'E' ? 'field' : 'work');
      if (q.type === 'E') state.probe = { x: q.A.x, y: q.A.y };
    } else setScene('field');
  });

  // ---------- 面板 ----------
  $('panelToggle').addEventListener('click', function () { panel.classList.toggle('collapsed'); });
  if (window.matchMedia('(max-width: 760px)').matches) panel.classList.add('collapsed');
  window.addEventListener('keydown', function (e) {
    var tg = e.target.tagName;
    if (tg === 'INPUT' || tg === 'SELECT' || tg === 'BUTTON' || tg === 'TEXTAREA') return;
    if (e.code === 'Space' && state.scene === 'work') { e.preventDefault(); $('play').click(); }
    if ((e.code === 'Delete' || e.code === 'Backspace') && state.sel >= 0 && state.scene !== 'quiz') { e.preventDefault(); $('delSel').click(); }
  });

  function syncUI() {
    var sc = state.scene;
    setSeg('scene', sc);
    qa('[data-for]').forEach(function (el) { el.hidden = el.dataset.for.split(' ').indexOf(sc) < 0; });
    $('hint').textContent = HINTS[sc];
    setSeg('preset', state.preset);
    setSeg('tool', state.tool);
    var c = state.cfg.charges[state.sel];
    $('selBox').hidden = !c || sc === 'quiz';
    if (c) {
      setSeg('qsign', c.q > 0 ? '+' : '-');
      $('qmag').value = Math.abs(c.q);
      $('qmagOut').textContent = D.qLabel(c.q).replace(/^[+−]/, '') + ' = ' + Math.abs(c.q).toFixed(1) + '×10⁻⁹ C';
    }
    [['showLines', 'lines'], ['showEq', 'eq'], ['showHeat', 'heat'], ['showNulls', 'nulls'], ['showProbe', 'probe']].forEach(function (p) { $(p[0]).checked = state.show[p[1]]; });
    $('density').value = state.density;
    $('densityOut').textContent = '每 Q ' + state.density + ' 条';
    setSeg('du', state.du);
    setSeg('plot', state.plot);
    setSeg('sg', state.sg > 0 ? '+' : '-');
    setSeg('path', state.path);
    $('play').textContent = state.playing ? '❚❚ 暂停' : state.t > 0 && state.t < 1 ? '▶ 继续' : '▶ 移动试探电荷';
    var q = state.quiz;
    if (q) {
      $('quizQ').textContent = q.prompt;
      qa('#quizOpts button').forEach(function (b) {
        b.disabled = state.answered;
        b.classList.toggle('on', state.answered && b.textContent === q.answer);
        b.classList.toggle('no', state.answered && b.textContent === state.choice && !state.correct);
      });
      $('quizMsg').innerHTML = !state.answered ? ''
        : '<b class="' + (state.correct ? 'ok">✓ 答对了' : 'bad">✗ 应选「' + q.answer + '」') + '</b>' + q.explain;
      $('nextQ').textContent = state.answered ? '下一题 →' : '换一题';
      $('showQ').hidden = !state.answered;
    }
  }

  // ---------- 计算缓存 ----------
  function rebuild() {
    var sc = state.scene, quiz = sc === 'quiz';
    var cfg = curCfg();
    fr = view.layout({ plot: sc === 'field' && state.plot !== 'off', bottom: quiz ? $('quizBar').offsetHeight + 8 : 0, zoom: cfg.plates ? 1.4 : 1 });
    var v = fr.view, sz = view.size();
    var box = { x0: v.x0 - 0.5, x1: v.x1 + 0.5, y0: v.y0 - 0.5, y1: v.y1 + 0.5 };
    var nx = Math.ceil(sz.w / 5) + 2, ny = Math.ceil(fr.R.h / 5) + 2;
    var G = F.grid(cfg, box, nx, ny);
    var bw = v.x1 - v.x0, bh = v.y1 - v.y0;
    var tbox = { x0: v.x0 - bw * 0.6, x1: v.x1 + bw * 0.6, y0: v.y0 - bh * 0.6, y1: v.y1 + bh * 0.6 };
    geo = {
      G: G,
      eqs: !quiz && state.show.eq ? F.equipotentials(G, state.du, Math.min(30, Math.round(300 / state.du))) : [],
      lines: quiz || state.show.lines ? F.fieldLines(cfg, quiz ? 10 : state.density, tbox) : [],
      nulls: quiz ? [] : F.nullPoints(cfg, G)
    };
    dirty = false; workDirty = true;
  }
  function rebuildWork() {
    var cfg = state.cfg, A = state.A, B = state.B, q = state.sg * F.Q_TEST;
    var p1 = F.path(A, B, 'line'), p2 = F.path(A, B, 'curve');
    var w1 = F.workAlong(cfg, p1, q), w2 = F.workAlong(cfg, p2, q);
    var pA = F.phi(cfg, A.x, A.y), pB = F.phi(cfg, B.x, B.y);
    work = {
      pA: pA, pB: pB, W: q * (pA - pB), line: { pts: p1, acc: w1 }, curve: { pts: p2, acc: w2 },
      eqA: F.contour(geo.G, pA), eqB: Math.abs(pA - pB) < 0.05 ? null : F.contour(geo.G, pB)
    };
    workDirty = false;
  }

  // ---------- 读数 ----------
  var lastText = {};
  function setText(id, s) { if (lastText[id] !== s) { lastText[id] = s; $(id).textContent = s; } }
  function rows(list) {
    for (var k = 1; k <= 5; k++) {
      var r = list[k - 1] || ['', ''];
      setText('d' + k, r[0]); setText('r' + k, r[1]);
      $('d' + k).hidden = $('r' + k).hidden = !r[0];
    }
  }
  function dirName(E) {
    var a = Math.atan2(E.y, E.x) * 180 / Math.PI;
    if (a < 0) a += 360;
    var names = ['向右', '向右上', '向上', '向左上', '向左', '向左下', '向下', '向右下'];
    var k = Math.round(a / 45) % 8, off = Math.abs(a - Math.round(a / 45) * 45);
    return names[k] + (off > 3 ? ' ' + Math.round(a) + '°' : '');
  }
  function fx(v) { var t = v.toFixed(1); return t === '-0.0' ? '0.0' : t.replace('-', '−'); }
  function presetName() {
    return state.preset === 'custom' ? '自定义电荷' : state.preset === 'empty' ? '没有电荷' : F.PRESETS[state.preset].name;
  }
  function readField() {
    var cfg = state.cfg, cs = cfg.charges;
    setText('rName', presetName());
    setText('rKind', cfg.plates ? '平行板' + (cs.length ? ' + ' + cs.length + ' 个点电荷' : '') : cs.length ? cs.length + ' 个点电荷' : '');
    setText('rTip', TIPS[state.preset]);
    var list = [];
    if (state.show.probe && (cs.length || cfg.plates)) {
      var P = state.probe, E = F.field(cfg, P.x, P.y), m = F.mag(E);
      list.push(['P 点场强', 'E = ' + F.fmtE(m) + (m * 100 >= 0.5 ? '，' + dirName(E) : '')]);
      list.push(['P 点电势', 'φ = ' + F.fmtV(F.phi(cfg, P.x, P.y)) + '（无穷远为 0）']);
      list.push(['+q 受力', 'F = qE = ' + (m * 100 < 0.5 ? '0' : F.sci(m * 100 * F.Q_TEST))   /* 与 fmtE 的“0 N/C”阈值一致 */ + ' N']);
    }
    var nul = geo.nulls.filter(function (n) { var v = fr.view; return n.x > v.x0 && n.x < v.x1 && n.y > v.y0 && n.y < v.y1; });
    if (cs.length > 1) list.push(['E = 0 的点', nul.length ? nul.slice(0, 2).map(function (n) { return '(' + fx(n.x) + ', ' + fx(n.y) + ') cm'; }).join('、') + (nul.length > 2 ? ' 等' : '') : '画面内没有']);
    if (cfg.plates) list.push(['平行板', 'U = ' + F.PLATE.U + ' V，d = ' + F.PLATE.d + ' cm，E ≈ U/d = ' + Math.round(F.PLATE.U / F.PLATE.d * 100) + ' N/C']);
    rows(list.slice(0, 5));
  }
  function readWork() {
    var w = work, U = w.pA - w.pB, sgn = state.sg > 0 ? '正' : '负', cur = w[state.path];
    var idx = Math.round(state.t * (cur.pts.length - 1));
    setText('rName', 'W_AB = ' + F.fmtJ(w.W));
    setText('rKind', sgn + '试探电荷');
    var zero = Math.abs(U) < 0.5;
    setText('rTip', zero ? 'A、B 在同一等势面上（U_AB = 0）：在等势面上移动电荷，电场力不做功。'
      : 'W_AB = qU_AB，只与始末位置的电势差有关，与路径无关。电场力做' + (w.W > 0 ? '正功，电势能减少' : '负功，电势能增加') + '了 ' + F.sci(Math.abs(w.W)) + ' J。');
    var done = state.t >= 1;
    rows([
      ['电势', 'φ_A = ' + F.fmtV(w.pA) + '，φ_B = ' + F.fmtV(w.pB)],
      ['电势差', 'U_AB = φ_A − φ_B = ' + F.fmtV(U, true)],
      ['电场力做功', 'W_AB = qU_AB = ' + (state.sg > 0 ? '+' : '−') + '1.0×10⁻¹⁰ C × ' + F.fmtV(U, true).replace(/^\+/, '') + ' = ' + F.fmtJ(w.W)],
      ['电势能', 'ΔEp = −W_AB = ' + F.fmtJ(-w.W)],
      ['沿路径累计', done ? '直线 ' + F.fmtJ(w.line.acc[w.line.acc.length - 1]) + '，曲线 ' + F.fmtJ(w.curve.acc[w.curve.acc.length - 1])
        : (state.path === 'line' ? '直线' : '曲线') + '：' + F.fmtJ(cur.acc[idx])]
    ]);
  }
  function readQuiz() {
    var q = state.quiz, sc = state.score;
    setText('rName', !state.answered ? '判断练习' : state.correct ? '✓ 答对了' : '✗ 答错了');
    $('rName').className = !state.answered ? '' : state.correct ? 'ok' : 'bad';
    setText('rKind', '得分 ' + sc.ok + ' / ' + sc.n);
    setText('rTip', state.answered ? q.explain : q.prompt);
    rows([]);
  }

  // 过 P 的水平（h）或竖直（v）直线上的 φ、E 分布
  function plotData(kind) {
    var cfg = state.cfg, v = fr.view, P = state.probe, n = 320, h = kind === 'h';
    var s0 = h ? v.x0 : v.y0, s1 = h ? v.x1 : v.y1, d = { s: [], phi: [], Epar: [], Emag: [], marks: [], sP: h ? P.x : P.y };
    var ps = [], es = [];
    for (var i = 0; i <= n; i++) {
      var s = s0 + (s1 - s0) * i / n, x = h ? s : P.x, y = h ? P.y : s;
      var dmin = cfg.charges.reduce(function (m, c) { return Math.min(m, Math.hypot(c.x - x, c.y - y)); }, 1e9);
      d.s.push(s);
      if (dmin < 0.6 || (cfg.plates && F.onPlate(x, y, 0.05))) { d.phi.push(null); d.Epar.push(null); d.Emag.push(null); continue; }
      var p = F.phi(cfg, x, y), E = F.field(cfg, x, y), m = F.mag(E);
      d.phi.push(p); d.Epar.push(h ? E.x : E.y); d.Emag.push(m);
      if (dmin > 1.5) { ps.push(Math.abs(p)); es.push(m); }
    }
    cfg.charges.forEach(function (c) { if (Math.abs(h ? c.y - P.y : c.x - P.x) < 1) d.marks.push({ s: h ? c.x : c.y, q: c.q }); });
    // 纵轴范围取 85% 分位数，避免电荷附近的极大值把其余部分压扁
    function pct(a) { if (!a.length) return 0; a.sort(function (u, w) { return u - w; }); return a[Math.floor(a.length * 0.85)]; }
    d.Pscale = Math.max(5, niceUp(pct(ps) * 1.25)); d.Escale = Math.max(0.5, niceUp(pct(es) * 1.25 * 100) / 100);
    return d;
  }
  function niceUp(x) {
    if (x <= 0) return 1;
    var e = Math.pow(10, Math.floor(Math.log10(x))), m = x / e;
    return (m <= 1 ? 1 : m <= 2 ? 2 : m <= 5 ? 5 : 10) * e;
  }

  // ---------- 尺寸与主循环 ----------
  // 改尺寸会清空画布，立即重画一帧，不等下一个 requestAnimationFrame
  var started = false;
  function resize() { view.resize(stage.clientWidth, stage.clientHeight); dirty = true; if (started) render(0); }
  new ResizeObserver(resize).observe(stage);

  // 支持 ?scene=field|work|quiz；&preset=pos|neg|dipole|same|unequal|plates|empty；&c=x,y,q;x,y,q（自定义点电荷，cm、Q）；
  // &d=4~20（每 Q 电场线条数）；&du=10|20|40（等势线间隔 V）；&lines=0 &eq=0 &heat=1 &nulls=0 &probe=0；&plot=h|v；&px= &py=（P 点）；
  // 电场力做功 &ax= &ay= &bx= &by=、&neg=1（负试探电荷）、&path=line|curve、&play=1（打开即移动）；练习 &q=E|phi|work|sign
  var qs = new URLSearchParams(location.search);
  function num(k, lo, hi) { var x = parseFloat(qs.get(k)); return isFinite(x) && x >= lo && x <= hi ? x : null; }
  var x;
  if (HINTS[qs.get('scene')]) state.scene = qs.get('scene');
  if (PRESET_KEYS.indexOf(qs.get('preset')) >= 0 || qs.get('preset') === 'empty') setPreset(qs.get('preset'));
  if (qs.get('c')) {
    var cs = qs.get('c').split(';').map(function (t) { var a = t.split(',').map(parseFloat); return { x: a[0], y: a[1], q: Math.round(a[2]), th0: 0 }; })
      .filter(function (c) { return isFinite(c.x) && isFinite(c.y) && c.q && Math.abs(c.q) <= 4 && Math.abs(c.x) < 40 && Math.abs(c.y) < 30; }).slice(0, F.MAX_CHARGES);
    if (cs.length) { state.cfg = { charges: cs, plates: state.cfg.plates && state.preset === 'plates' }; state.preset = 'custom'; }
  }
  if ((x = num('d', 4, 20)) != null) state.density = Math.round(x);
  if ([10, 20, 40].indexOf(+qs.get('du')) >= 0) state.du = +qs.get('du');
  if (qs.get('lines') === '0') state.show.lines = false;
  if (qs.get('eq') === '0') state.show.eq = false;
  if (qs.get('heat') === '1') state.show.heat = true;
  if (qs.get('nulls') === '0') state.show.nulls = false;
  if (qs.get('probe') === '0') state.show.probe = false;
  if (qs.get('plot') === 'h' || qs.get('plot') === 'v') { state.plot = qs.get('plot'); state.show.probe = true; }
  if ((x = num('px', -40, 40)) != null) state.probe.x = x;
  if ((x = num('py', -30, 30)) != null) state.probe.y = x;
  if ((x = num('ax', -40, 40)) != null) state.A.x = x;
  if ((x = num('ay', -30, 30)) != null) state.A.y = x;
  if ((x = num('bx', -40, 40)) != null) state.B.x = x;
  if ((x = num('by', -30, 30)) != null) state.B.y = x;
  if (qs.get('neg') === '1') state.sg = -1;
  if (qs.get('path') === 'curve') state.path = 'curve';
  if (F.TYPES.indexOf(qs.get('q')) >= 0) state.quizOnly = qs.get('q');

  resize();
  setScene(state.scene);
  if (qs.get('play') === '1' && state.scene === 'work') { state.playing = true; syncUI(); }

  var lastT = performance.now();
  function frame(now) {
    render(Math.max(0, Math.min((now - lastT) / 1000, 0.1)));   // rAF 的时间戳可能早于 lastT
    lastT = now;
    requestAnimationFrame(frame);
  }
  function render(dt) {
    var sc = state.scene;
    if (dirty || !fr) rebuild();
    var o = { fr: fr, cfg: curCfg(), geo: geo, show: state.show, sel: sc === 'quiz' ? -1 : state.sel, labelMax: Math.max(120, state.du * 6) };
    if (sc === 'field') {
      if (state.show.probe || state.plot !== 'off') { o.probe = state.probe; o.probeE = F.field(state.cfg, state.probe.x, state.probe.y); }
      if (state.plot !== 'off') o.plot = { kind: state.plot, data: plotData(state.plot) };
      view.draw(o);
      readField();
    } else if (sc === 'work') {
      if (workDirty) rebuildWork();
      if (state.playing) { state.t = Math.min(1, state.t + dt / 3); if (state.t >= 1) { state.playing = false; syncUI(); } }
      var cur = work[state.path], idx = Math.round(state.t * (cur.pts.length - 1)), pos = cur.pts[idx], E = F.field(state.cfg, pos.x, pos.y);
      o.show = { lines: state.show.lines, eq: state.show.eq, heat: state.show.heat, nulls: false };
      o.work = {
        A: state.A, B: state.B, sg: state.sg, path: cur.pts, other: work[state.path === 'line' ? 'curve' : 'line'].pts, done: idx, pos: pos,
        force: { x: state.sg * E.x, y: state.sg * E.y }, eqA: work.eqA, eqB: work.eqB
      };
      view.draw(o);
      readWork();
    } else {
      var q = state.quiz;
      o.show = { lines: true, eq: false, heat: false, nulls: false };
      o.quiz = q; o.hideSign = !!q.hideSign;
      view.draw(o);
      readQuiz();
    }
  }
  started = true;
  requestAnimationFrame(frame);

  // 调试用
  window.__model = {
    state: state, setScene: setScene, setPreset: setPreset, newQuiz: newQuiz, syncUI: syncUI,
    setProbe: function (x, y) { state.probe = { x: x, y: y }; },
    setAB: function (ax, ay, bx, by) { state.A = { x: ax, y: ay }; state.B = { x: bx, y: by }; workDirty = true; state.t = 0; },
    addCharge: function (x, y, q) { state.cfg.charges.push({ x: x, y: y, q: q, th0: 0 }); state.preset = 'custom'; touch(); syncUI(); },
    play: function () { state.t = 0; state.playing = true; syncUI(); },
    geo: function () { return geo; }
  };
})();
