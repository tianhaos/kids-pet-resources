// 2D 绘制：电势色图、等势线（虚线，标电势值）、电场线（带箭头）、点电荷与平行板、场强为零的点、
// 试探点 P 的场强箭头、A/B 两点与移动路径、过 P 的直线上的 φ、E 图像、练习题画面
// 世界坐标同 Field：x 右、y 上，单位 cm；frame(R, box) 把世界范围 box 等比放进屏幕矩形 R
(function () {
  var F = window.Field;
  var POS = '#ff7a59', NEG = '#4fc3f7', LINE = '#ffc94a', EQ = '#7fd8c8', E_COL = '#7ee081', ALT = '#c9a7ff';
  var MUTED = '#8d99ab', TEXT = '#e6ebf2';
  var FONT = '-apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", sans-serif';

  function font(px, w) { return (w ? w + ' ' : '') + px + 'px ' + FONT; }
  function label(ctx, s, x, y, o) {
    o = o || {};
    ctx.font = font(o.size || 12, o.bold ? 600 : null);
    ctx.textAlign = o.align || 'center'; ctx.textBaseline = o.base || 'middle';
    ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(5,7,13,.85)'; ctx.setLineDash([]); ctx.strokeText(s, x, y);
    ctx.fillStyle = o.color || TEXT; ctx.fillText(s, x, y);
  }
  function arrowHead(ctx, x, y, a, size, color) {
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.moveTo(x + Math.cos(a) * size * 0.6, y + Math.sin(a) * size * 0.6);
    ctx.lineTo(x - size * Math.cos(a - 0.45), y - size * Math.sin(a - 0.45));
    ctx.lineTo(x - size * Math.cos(a + 0.45), y - size * Math.sin(a + 0.45));
    ctx.closePath(); ctx.fill();
  }
  function arrow(ctx, x1, y1, x2, y2, size, color, width) {
    var a = Math.atan2(y2 - y1, x2 - x1);
    ctx.strokeStyle = color; ctx.lineWidth = width || 2.4; ctx.setLineDash([]);
    ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2 - Math.cos(a) * size * 0.6, y2 - Math.sin(a) * size * 0.6); ctx.stroke();
    arrowHead(ctx, x2 - Math.cos(a) * size * 0.6, y2 - Math.sin(a) * size * 0.6, a, size, color);
  }
  function chargeColor(q) { return q > 0 ? POS : NEG; }
  function qLabel(q) { var a = Math.abs(q); return (q > 0 ? '+' : '−') + (a === 1 ? '' : a) + 'Q'; }
  // 场强箭头长度（px）按对数缩放，弱场也看得见、强场不至于太长
  function eLen(eVcm) { return Math.min(90, 20 * Math.log(1 + eVcm / 2)); }

  // ---------- 世界 ⇄ 屏幕 ----------
  function frame(R, box) {
    var k = Math.min(R.w / (box.x1 - box.x0), R.h / (box.y1 - box.y0));
    var cx = R.x + R.w / 2, cy = R.y + R.h / 2, mx = (box.x0 + box.x1) / 2, my = (box.y0 + box.y1) / 2;
    return {
      k: k, R: R,
      p: function (x, y) { return { x: cx + (x - mx) * k, y: cy - (y - my) * k }; },
      w: function (sx, sy) { return { x: mx + (sx - cx) / k, y: my - (sy - cy) / k }; },
      view: { x0: mx - R.w / 2 / k, x1: mx + R.w / 2 / k, y0: my - R.h / 2 / k, y1: my + R.h / 2 / k }
    };
  }

  // 电势色图：正电势偏红、负电势偏蓝，用 tanh 压缩
  function heatCanvas(G) {
    var c = document.createElement('canvas'); c.width = G.nx; c.height = G.ny;
    var g = c.getContext('2d'), img = g.createImageData(G.nx, G.ny), d = img.data;
    for (var j = 0; j < G.ny; j++) for (var i = 0; i < G.nx; i++) {
      var v = G.v[j * G.nx + i], t = Math.tanh(v / 120), o = ((G.ny - 1 - j) * G.nx + i) * 4;
      var col = t > 0 ? [255, 122, 89] : [79, 195, 247];
      d[o] = col[0]; d[o + 1] = col[1]; d[o + 2] = col[2]; d[o + 3] = Math.round(Math.abs(t) * 120);
    }
    g.putImageData(img, 0, 0);
    return c;
  }

  function View(canvas) {
    var ctx = canvas.getContext('2d'), W = 0, H = 0, dpr = 1, narrow = false;
    function resize(w, h) {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      W = w; H = h; narrow = w < 640;
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
      canvas.style.width = w + 'px'; canvas.style.height = h + 'px';
    }
    function bg() {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      var g = ctx.createLinearGradient(0, 0, 0, H);
      g.addColorStop(0, '#04060c'); g.addColorStop(1, '#0a1120');
      ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    }
    // 画面布局：o.plot 时下方留出图像区；o.bottom 额外底部留白（练习题条）；o.zoom > 1 时看到更大范围（平行板）
    function layout(o) {
      var t0 = narrow ? 84 : 44, bottom = (narrow ? 44 : 50) + (o.bottom || 0);
      var ph = o.plot ? Math.round(Math.min(210, Math.max(140, H * 0.26))) : 0;
      // 场景区 R 占满图像区以上的整个画布；缩放与中心由去掉上下留白后的 fit 决定
      var R = { x: 0, y: 0, w: W, h: o.plot ? H - bottom - ph : H };
      var fit = { x: 0, y: t0, w: W, h: Math.max(100, R.h - t0 - (o.plot ? 8 : bottom)) };
      var z = o.zoom || 1, hw = (narrow ? 14 : 21) * z, hh = 13 * z, fr = frame(fit, { x0: -hw, x1: hw, y0: -hh, y1: hh });
      fr.R = R;
      fr.view = { x0: fr.w(0, 0).x, x1: fr.w(W, 0).x, y0: fr.w(0, R.h).y, y1: fr.w(0, 0).y };
      fr.plotRect = o.plot ? { x: narrow ? 46 : 64, y: R.h + 14, w: W - (narrow ? 92 : 136), h: ph - 40 } : null;
      return fr;
    }

    // ---------- 图层 ----------
    function drawHeat(fr, geo) {
      if (!geo.heatImg) geo.heatImg = heatCanvas(geo.G);
      var b = geo.G.box, a = fr.p(b.x0, b.y1), c = fr.p(b.x1, b.y0);
      ctx.imageSmoothingEnabled = true;
      ctx.drawImage(geo.heatImg, a.x, a.y, c.x - a.x, c.y - a.y);
    }
    function drawEquip(fr, geo, o) {
      ctx.save();
      ctx.lineWidth = 1.3; ctx.setLineDash([5, 4]);
      var labels = [];
      geo.eqs.forEach(function (e) {
        var zero = Math.abs(e.level) < 1e-9;
        ctx.strokeStyle = zero ? 'rgba(230,235,242,.75)' : 'rgba(127,216,200,.7)';
        ctx.beginPath();
        // 只给离电荷较远的若干条标电势值，近处太密
        var s = e.segs, best = null, bs = -1e9, lab = Math.abs(e.level) <= o.labelMax + 1e-9;
        for (var i = 0; i < s.length; i += 4) {
          var a = fr.p(s[i], s[i + 1]), b = fr.p(s[i + 2], s[i + 3]);
          ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y);
          // 标注位置：偏右上方、离画面边缘有距离的点
          var mx = (a.x + b.x) / 2, my = (a.y + b.y) / 2;
          if (lab && i % 12 === 0 && mx > 40 && mx < W - 60 && my > fr.R.y + (narrow ? 96 : 56) && my < fr.R.h - 20) {
            var sc = mx * 0.5 - my;
            if (sc > bs && !labels.some(function (l) { return Math.abs(l.x - mx) < 52 && Math.abs(l.y - my) < 26; })) { bs = sc; best = { x: mx, y: my }; }
          }
        }
        ctx.stroke();
        if (best && o.eqLabels) labels.push({ x: best.x, y: best.y, s: F.fmtV(e.level, true), zero: zero });
      });
      ctx.restore();
      labels.forEach(function (l) { label(ctx, l.s, l.x, l.y, { size: 10.5, color: l.zero ? TEXT : EQ }); });
    }
    function drawLines(fr, lines, o) {
      ctx.save();
      ctx.strokeStyle = o.color || 'rgba(255,201,74,.85)'; ctx.lineWidth = 1.6; ctx.setLineDash([]);
      var heads = [];
      lines.forEach(function (ln) {
        var pts = ln.pts.map(function (p) { return fr.p(p.x, p.y); });
        ctx.beginPath();
        for (var i = 0; i < pts.length; i++) i ? ctx.lineTo(pts[i].x, pts[i].y) : ctx.moveTo(pts[i].x, pts[i].y);
        ctx.stroke();
        // 画面内这段的长度，按长度放 1～3 个箭头
        var acc = [0], tot = 0;
        for (i = 1; i < pts.length; i++) {
          var a = pts[i - 1], b = pts[i], inView = b.x > 0 && b.x < W && b.y > 0 && b.y < fr.R.h;
          tot += inView ? Math.hypot(b.x - a.x, b.y - a.y) : 0; acc.push(tot);
        }
        var n = tot > 420 ? 3 : tot > 200 ? 2 : tot > 40 ? 1 : 0;
        for (var k = 1; k <= n; k++) {
          var target = tot * k / (n + 1);
          for (i = 1; i < pts.length; i++) if (acc[i] >= target && acc[i] > acc[i - 1]) {
            var p = pts[i - 1], q = pts[i];
            heads.push({ x: (p.x + q.x) / 2, y: (p.y + q.y) / 2, a: Math.atan2(q.y - p.y, q.x - p.x) });
            break;
          }
        }
      });
      heads.forEach(function (h) { arrowHead(ctx, h.x, h.y, h.a, 8, o.color || LINE); });
      ctx.restore();
    }
    function drawPlates(fr, hide) {
      var P = F.PLATE;
      [-1, 1].forEach(function (s) {
        var a = fr.p(s * P.d / 2, P.L / 2), b = fr.p(s * P.d / 2, -P.L / 2), col = s < 0 ? POS : NEG;
        ctx.fillStyle = col; ctx.globalAlpha = 0.9;
        ctx.fillRect(a.x - 3, a.y, 6, b.y - a.y);
        ctx.globalAlpha = 1;
        if (hide) return;
        for (var i = 0; i < 7; i++) {
          var y = a.y + (b.y - a.y) * (i + 0.5) / 7;
          label(ctx, s < 0 ? '+' : '−', a.x + s * -12, y, { size: 13, bold: true, color: col });
        }
      });
    }
    function drawCharges(fr, cfg, o) {
      cfg.charges.forEach(function (c, i) {
        var p = fr.p(c.x, c.y), r = 11 + Math.abs(c.q) * 1.2, col = o.hideSign ? '#9aa6b8' : chargeColor(c.q);
        if (o.sel === i) {
          ctx.strokeStyle = 'rgba(255,255,255,.75)'; ctx.lineWidth = 1.5; ctx.setLineDash([3, 3]);
          ctx.beginPath(); ctx.arc(p.x, p.y, r + 6, 0, 7); ctx.stroke(); ctx.setLineDash([]);
        }
        var g = ctx.createRadialGradient(p.x - r * 0.35, p.y - r * 0.35, r * 0.1, p.x, p.y, r);
        g.addColorStop(0, '#fff'); g.addColorStop(0.35, col); g.addColorStop(1, 'rgba(0,0,0,.55)');
        ctx.fillStyle = g; ctx.beginPath(); ctx.arc(p.x, p.y, r, 0, 7); ctx.fill();
        if (o.hideSign) { label(ctx, o.names[i], p.x, p.y, { size: 13, bold: true, color: '#111' }); return; }
        ctx.strokeStyle = '#111'; ctx.lineWidth = 2.2;
        ctx.beginPath(); ctx.moveTo(p.x - r * 0.45, p.y); ctx.lineTo(p.x + r * 0.45, p.y);
        if (c.q > 0) { ctx.moveTo(p.x, p.y - r * 0.45); ctx.lineTo(p.x, p.y + r * 0.45); }
        ctx.stroke();
        label(ctx, qLabel(c.q), p.x, p.y + r + 10, { size: 11, color: col });
      });
    }
    function drawNulls(fr, nulls) {
      nulls.forEach(function (n) {
        var p = fr.p(n.x, n.y);
        ctx.strokeStyle = '#fff'; ctx.lineWidth = 2; ctx.setLineDash([]);
        ctx.beginPath(); ctx.moveTo(p.x - 5, p.y - 5); ctx.lineTo(p.x + 5, p.y + 5); ctx.moveTo(p.x + 5, p.y - 5); ctx.lineTo(p.x - 5, p.y + 5); ctx.stroke();
        label(ctx, 'E = 0', p.x + 8, p.y + 15, { size: 11, align: 'left' });
      });
    }
    // 试探点：小圆环 + 场强箭头（对数长度）
    function drawPoint(fr, pt, name, color, E, o) {
      o = o || {};
      var p = fr.p(pt.x, pt.y);
      if (E) {
        var m = F.mag(E), L = eLen(m);
        if (L > 4) arrow(ctx, p.x, p.y, p.x + E.x / m * L, p.y - E.y / m * L, 9, o.arrowColor || E_COL, 2.4);
      }
      ctx.fillStyle = 'rgba(5,7,13,.6)'; ctx.strokeStyle = color; ctx.lineWidth = 2; ctx.setLineDash([]);
      ctx.beginPath(); ctx.arc(p.x, p.y, 6, 0, 7); ctx.fill(); ctx.stroke();
      ctx.fillStyle = color; ctx.beginPath(); ctx.arc(p.x, p.y, 2, 0, 7); ctx.fill();
      label(ctx, name, p.x - 13, p.y - 13, { size: 13, bold: true, color: color });
    }
    function drawTestCharge(fr, pt, sg, F0) {
      var p = fr.p(pt.x, pt.y);
      if (F0) {
        var m = F.mag(F0), L = eLen(m);
        if (L > 4) arrow(ctx, p.x, p.y, p.x + F0.x / m * L, p.y - F0.y / m * L, 9, E_COL, 2.4);
      }
      var col = sg > 0 ? POS : NEG;
      ctx.fillStyle = col; ctx.beginPath(); ctx.arc(p.x, p.y, 7, 0, 7); ctx.fill();
      ctx.strokeStyle = '#111'; ctx.lineWidth = 1.8;
      ctx.beginPath(); ctx.moveTo(p.x - 3.5, p.y); ctx.lineTo(p.x + 3.5, p.y);
      if (sg > 0) { ctx.moveTo(p.x, p.y - 3.5); ctx.lineTo(p.x, p.y + 3.5); }
      ctx.stroke();
    }
    function polyline(fr, pts, color, width, dash) {
      ctx.strokeStyle = color; ctx.lineWidth = width; ctx.setLineDash(dash || []);
      ctx.beginPath();
      pts.forEach(function (q, i) { var p = fr.p(q.x, q.y); i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y); });
      ctx.stroke(); ctx.setLineDash([]);
    }

    // ---------- 过 P 的直线上的 φ、E 图像 ----------
    function drawPlot(fr, pl) {
      var C = fr.plotRect, d = pl.data;
      ctx.fillStyle = 'rgba(10,15,26,.92)'; ctx.fillRect(0, fr.R.h, W, C.h + 40);
      ctx.strokeStyle = 'rgba(141,153,171,.35)'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(0, fr.R.h + 0.5); ctx.lineTo(W, fr.R.h + 0.5); ctx.stroke();
      var s0 = d.s[0], s1 = d.s[d.s.length - 1];
      function X(s) { return C.x + (s - s0) / (s1 - s0) * C.w; }
      var y0 = C.y + C.h / 2;
      ctx.strokeStyle = 'rgba(141,153,171,.5)';
      ctx.beginPath(); ctx.moveTo(C.x, y0); ctx.lineTo(C.x + C.w, y0); ctx.moveTo(C.x, C.y); ctx.lineTo(C.x, C.y + C.h); ctx.moveTo(C.x + C.w, C.y); ctx.lineTo(C.x + C.w, C.y + C.h); ctx.stroke();
      function curve(arr, scale, color, dash, width) {
        ctx.save(); ctx.beginPath(); ctx.rect(C.x, C.y - 2, C.w, C.h + 4); ctx.clip();
        ctx.strokeStyle = color; ctx.lineWidth = width || 2; ctx.setLineDash(dash || []);
        ctx.beginPath();
        var pen = false;
        for (var i = 0; i < arr.length; i++) {
          if (arr[i] == null) { pen = false; continue; }
          var y = y0 - Math.max(-1.08, Math.min(1.08, arr[i] / scale)) * C.h / 2;
          if (pen) ctx.lineTo(X(d.s[i]), y); else { ctx.moveTo(X(d.s[i]), y); pen = true; }
        }
        ctx.stroke(); ctx.restore();
      }
      curve(d.Emag, d.Escale, 'rgba(255,201,74,.45)', [3, 4], 1.3);
      curve(d.Epar, d.Escale, LINE, null, 2);
      curve(d.phi, d.Pscale, EQ, null, 2);
      // 电荷所在位置
      d.marks.forEach(function (m) {
        var x = X(m.s); ctx.strokeStyle = m.q > 0 ? POS : NEG; ctx.setLineDash([2, 3]);
        ctx.beginPath(); ctx.moveTo(x, C.y); ctx.lineTo(x, C.y + C.h); ctx.stroke(); ctx.setLineDash([]);
      });
      var px = X(d.sP);
      ctx.strokeStyle = 'rgba(126,224,129,.8)'; ctx.beginPath(); ctx.moveTo(px, C.y); ctx.lineTo(px, C.y + C.h); ctx.stroke();
      label(ctx, 'P', px, C.y + 6, { size: 11, color: E_COL, bold: true });
      var sm = narrow ? 10 : 11;
      label(ctx, 'φ', C.x - 8, C.y + 4, { size: 12, color: EQ, bold: true, align: 'right' });
      label(ctx, F.fmtV(d.Pscale, true), C.x - 4, C.y + 18, { size: sm, color: EQ, align: 'right' });
      label(ctx, '0', C.x - 4, y0, { size: sm, color: MUTED, align: 'right' });
      label(ctx, 'E' + (pl.kind === 'h' ? 'x' : 'y'), C.x + C.w + 6, C.y + 4, { size: 12, color: LINE, bold: true, align: 'left' });
      if (!narrow) label(ctx, Math.round(d.Escale * 100) + ' N/C', C.x + C.w + 4, C.y + 18, { size: sm, color: LINE, align: 'left' });
      label(ctx, pl.kind === 'h' ? 'x →' : 'y →', C.x + C.w - 4, y0 + 12, { size: sm, color: MUTED, align: 'right' });
      label(ctx, pl.kind === 'h' ? '过 P 的水平线上：φ（实线）、Ex（实线，向右为正）、|E|（虚线）' : '过 P 的竖直线上：φ（实线）、Ey（实线，向上为正）、|E|（虚线）',
        C.x + 6, C.y + C.h + 13, { size: sm, color: MUTED, align: 'left' });
    }

    // ---------- 场景 ----------
    // o: { fr, cfg, geo, show, sel, probe, probeE, plot, work, quiz }
    function draw(o) {
      bg();
      var fr = o.fr, cfg = o.cfg, geo = o.geo, show = o.show;
      ctx.save(); ctx.beginPath(); ctx.rect(0, 0, W, fr.R.h); ctx.clip();
      if (show.heat) drawHeat(fr, geo);
      if (show.eq) drawEquip(fr, geo, { eqLabels: true, labelMax: o.labelMax || 1e9 });
      if (o.work) {
        var wk = o.work;
        // A、B 所在的等势线加粗
        [['A', wk.eqA], ['B', wk.eqB]].forEach(function (p) {
          if (!p[1]) return;
          ctx.save(); ctx.strokeStyle = 'rgba(201,167,255,.9)'; ctx.lineWidth = 2; ctx.setLineDash([6, 4]);
          ctx.beginPath();
          for (var i = 0; i < p[1].length; i += 4) { var a = fr.p(p[1][i], p[1][i + 1]), b = fr.p(p[1][i + 2], p[1][i + 3]); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); }
          ctx.stroke(); ctx.restore();
        });
      }
      if (show.lines) drawLines(fr, geo.lines, {});
      if (cfg.plates) drawPlates(fr, o.hideSign);
      if (o.plot) {
        var ln = o.plot.kind === 'h' ? [fr.p(fr.view.x0, o.probe.y), fr.p(fr.view.x1, o.probe.y)] : [fr.p(o.probe.x, fr.view.y0), fr.p(o.probe.x, fr.view.y1)];
        ctx.strokeStyle = 'rgba(126,224,129,.45)'; ctx.lineWidth = 1; ctx.setLineDash([2, 4]);
        ctx.beginPath(); ctx.moveTo(ln[0].x, ln[0].y); ctx.lineTo(ln[1].x, ln[1].y); ctx.stroke(); ctx.setLineDash([]);
      }
      if (o.work) {
        var w = o.work;
        if (w.other) polyline(fr, w.other, 'rgba(230,235,242,.25)', 1.5, [4, 5]);
        polyline(fr, w.path, 'rgba(230,235,242,.8)', 2, [6, 5]);
        if (w.done > 0) polyline(fr, w.path.slice(0, w.done + 1), E_COL, 2.6);
      }
      if (show.nulls) drawNulls(fr, geo.nulls);
      drawCharges(fr, cfg, { sel: o.sel, hideSign: o.hideSign, names: ['a', 'b'] });
      if (o.probe && !o.plotOnly) drawPoint(fr, o.probe, 'P', E_COL, o.probeE);
      if (o.work) {
        drawPoint(fr, o.work.A, 'A', ALT, null);
        drawPoint(fr, o.work.B, 'B', ALT, null);
        drawTestCharge(fr, o.work.pos, o.work.sg, o.work.force);
      }
      if (o.quiz) {
        var q = o.quiz;
        if (q.A) { drawPoint(fr, q.A, 'A', ALT, null); drawPoint(fr, q.B, 'B', ALT, null); }
      }
      ctx.restore();
      if (o.plot) drawPlot(fr, o.plot);
    }

    return { resize: resize, layout: layout, draw: draw, narrow: function () { return narrow; }, size: function () { return { w: W, h: H }; } };
  }

  window.FieldDraw = { View: View, frame: frame, eLen: eLen, qLabel: qLabel, COLORS: { POS: POS, NEG: NEG, LINE: LINE, EQ: EQ, E: E_COL, ALT: ALT } };
})();
