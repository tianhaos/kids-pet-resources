// 电场线与等势面的计算：点电荷 + 平行板（均匀带电矩形板）的电势与场强叠加、电场线追踪、等势线（marching squares）、
// 场强为零的点、沿路径的电场力做功、练习题。不碰 DOM，可在 node 里单独测试。
// 世界坐标 x 右 y 上，单位 cm；画面所在平面为 z = 0。电荷量单位 Q0 = 1×10⁻⁹ C；电势单位 V；
// 场强内部用 V/cm，显示时 ×100 换成 N/C（= V/m）。取无穷远处电势为零。
(function () {
  var TAU = Math.PI * 2;
  var Q0 = 1e-9;           // 电荷量单位（C）
  var K = 900;             // k·Q0 / 1 cm = 9×10⁹ × 10⁻⁹ / 0.01 = 900 V·cm：φ = K q / r（r 以 cm 计）
  var Q_TEST = 1e-10;      // 试探电荷 ±1.0×10⁻¹⁰ C
  var R_CHARGE = 0.7;      // 电荷小球半径（cm），电场线在此起止
  var MAX_CHARGES = 8;

  function clamp(x, a, b) { return x < a ? a : x > b ? b : x; }

  // ---------- 平行板：两块竖直放置的均匀带电正方形板 ----------
  // 板面在 x = ±d/2，沿 y 长 L、沿 z（垂直纸面）深 L；左板带正电。面电荷密度按两板电压 U 标定。
  var PLATE = { d: 12, L: 30, U: 240 };
  // 均匀面电荷矩形 u∈[u1,u2]、v∈[v1,v2]，在距板面 h 处的 ∫∫dA/r（cm）。原函数中只依赖 u 或只依赖 v 的项在二重差分中抵消，
  // 所以用 asinh 形式代替 ln，数值上更稳。
  function Fprim(u, v, h) {
    var ru = Math.sqrt(u * u + h * h), rv = Math.sqrt(v * v + h * h), R = Math.sqrt(u * u + v * v + h * h);
    var s = 0;
    if (ru > 1e-12) s += u * Math.asinh(v / ru);
    if (rv > 1e-12) s += v * Math.asinh(u / rv);
    if (h !== 0 && R > 1e-12) s -= Math.abs(h) * Math.atan(u * v / (Math.abs(h) * R));
    return s;
  }
  function rectInt(x0, x, y) {
    var h = x - x0, a = PLATE.L / 2;
    var u1 = -a - y, u2 = a - y, v1 = -a, v2 = a;
    return Fprim(u2, v2, h) - Fprim(u1, v2, h) - Fprim(u2, v1, h) + Fprim(u1, v1, h);
  }
  function platePhiRaw(x, y) { return rectInt(-PLATE.d / 2, x, y) - rectInt(PLATE.d / 2, x, y); }
  // 标定：使正板中心与负板中心的电势差为 U
  var PLATE_C = PLATE.U / (platePhiRaw(-PLATE.d / 2, 0) - platePhiRaw(PLATE.d / 2, 0));

  // ---------- 叠加 ----------
  // cfg: { charges: [{ x, y, q }], plates: bool }
  function phi(cfg, x, y) {
    var s = 0, cs = cfg.charges;
    for (var i = 0; i < cs.length; i++) {
      var dx = x - cs[i].x, dy = y - cs[i].y, r = Math.sqrt(dx * dx + dy * dy);
      s += K * cs[i].q / Math.max(r, 1e-6);
    }
    if (cfg.plates) s += PLATE_C * platePhiRaw(x, y);
    return s;
  }
  // 返回 { x, y }（V/cm）
  function field(cfg, x, y) {
    var ex = 0, ey = 0, cs = cfg.charges;
    for (var i = 0; i < cs.length; i++) {
      var dx = x - cs[i].x, dy = y - cs[i].y, r2 = dx * dx + dy * dy, r = Math.sqrt(r2);
      if (r < 1e-6) continue;
      var k = K * cs[i].q / (r2 * r);
      ex += k * dx; ey += k * dy;
    }
    if (cfg.plates) {
      var h = 0.004;
      ex -= PLATE_C * (platePhiRaw(x + h, y) - platePhiRaw(x - h, y)) / (2 * h);
      ey -= PLATE_C * (platePhiRaw(x, y + h) - platePhiRaw(x, y - h)) / (2 * h);
    }
    return { x: ex, y: ey };
  }
  function mag(e) { return Math.sqrt(e.x * e.x + e.y * e.y); }
  // 点在平行板上或紧贴板面（板厚视为 0）
  function onPlate(x, y, tol) {
    return Math.abs(y) <= PLATE.L / 2 + tol && Math.abs(Math.abs(x) - PLATE.d / 2) < tol;
  }
  function crossesPlate(p, q, sign) {
    var x0 = sign > 0 ? -PLATE.d / 2 : PLATE.d / 2;
    if ((p.x - x0) * (q.x - x0) > 0) return false;
    var t = (x0 - p.x) / ((q.x - p.x) || 1e-12), y = p.y + (q.y - p.y) * t;
    return Math.abs(y) <= PLATE.L / 2;
  }

  // ---------- 电场线 ----------
  // 从 p0 沿 dir（+1 顺着场强、−1 逆着）用 RK4 追踪；box 为追踪范围（世界坐标），越界、到达异号电荷/极板或场强为零时停止。
  function trace(cfg, p0, dir, box) {
    var pts = [{ x: p0.x, y: p0.y }], p = { x: p0.x, y: p0.y }, len = 0, end = null;
    var cs = cfg.charges, maxLen = 4 * ((box.x1 - box.x0) + (box.y1 - box.y0));
    function d(x, y) { var e = field(cfg, x, y), m = mag(e); return m < 1e-12 ? null : { x: dir * e.x / m, y: dir * e.y / m, m: m }; }
    for (var n = 0; n < 4000; n++) {
      // 步长：离电荷越近越小
      var dmin = 1e9;
      for (var i = 0; i < cs.length; i++) dmin = Math.min(dmin, Math.hypot(p.x - cs[i].x, p.y - cs[i].y));
      var h = clamp(dmin * 0.12, 0.05, 0.6);
      var k1 = d(p.x, p.y); if (!k1) { end = 'null'; break; }
      var k2 = d(p.x + k1.x * h / 2, p.y + k1.y * h / 2); if (!k2) { end = 'null'; break; }
      var k3 = d(p.x + k2.x * h / 2, p.y + k2.y * h / 2); if (!k3) { end = 'null'; break; }
      var k4 = d(p.x + k3.x * h, p.y + k3.y * h); if (!k4) { end = 'null'; break; }
      var q = { x: p.x + h / 6 * (k1.x + 2 * k2.x + 2 * k3.x + k4.x), y: p.y + h / 6 * (k1.y + 2 * k2.y + 2 * k3.y + k4.y) };
      // 场强很弱且来回折返（场强为零的点附近）时停止
      if (k1.x * k4.x + k1.y * k4.y < 0) { end = 'null'; break; }
      // 到达终点电荷（顺着场强找负电荷，逆着找正电荷）
      var hit = -1;
      for (i = 0; i < cs.length; i++) {
        if (cs[i].q * dir < 0 && Math.hypot(q.x - cs[i].x, q.y - cs[i].y) < R_CHARGE) { hit = i; break; }
      }
      if (hit >= 0) {
        var c = cs[hit], a = Math.atan2(q.y - c.y, q.x - c.x);
        pts.push({ x: c.x + Math.cos(a) * R_CHARGE, y: c.y + Math.sin(a) * R_CHARGE });
        end = { charge: hit, angle: a };
        break;
      }
      if (cfg.plates && crossesPlate(p, q, -dir)) {
        var x0 = dir > 0 ? PLATE.d / 2 : -PLATE.d / 2, t = (x0 - p.x) / ((q.x - p.x) || 1e-12);
        pts.push({ x: x0, y: p.y + (q.y - p.y) * t });
        end = 'plate';
        break;
      }
      pts.push(q); p = q; len += h;
      if (p.x < box.x0 || p.x > box.x1 || p.y < box.y0 || p.y > box.y1) { end = 'out'; break; }
      if (len > maxLen) { end = 'len'; break; }
    }
    return { pts: pts, end: end };
  }

  // 每单位电荷画 density 条电场线：正电荷均匀向外出发；负电荷上不够数的部分（来自无穷远或板外）从最大空隙处反向补齐。
  // 返回 [{ pts（顺着场强方向）, from, to }]
  function fieldLines(cfg, density, box) {
    var cs = cfg.charges, lines = [], arrive = cs.map(function () { return []; });
    function add(tr, dir, from) {
      var pts = dir > 0 ? tr.pts : tr.pts.slice().reverse();
      lines.push({ pts: pts });
      if (tr.end && tr.end.charge != null) arrive[tr.end.charge].push(tr.end.angle);
    }
    cs.forEach(function (c, i) {
      if (c.q <= 0) return;
      var n = Math.max(1, Math.round(density * c.q)), th0 = c.th0 || 0;
      for (var k = 0; k < n; k++) {
        var a = th0 + TAU * k / n;
        add(trace(cfg, { x: c.x + Math.cos(a) * R_CHARGE, y: c.y + Math.sin(a) * R_CHARGE }, 1, box), 1, i);
      }
    });
    if (cfg.plates) {
      var nP = Math.round(density * 2.2), x0 = -PLATE.d / 2 + 0.16;
      for (var k = 0; k < nP; k++) {
        var y = -PLATE.L / 2 + PLATE.L * (k + 0.5) / nP;
        var tr = trace(cfg, { x: x0, y: y }, 1, box);
        tr.pts.unshift({ x: -PLATE.d / 2, y: y });
        add(tr, 1);
      }
    }
    cs.forEach(function (c, i) {
      if (c.q >= 0) return;
      var n = Math.max(1, Math.round(density * -c.q)), have = arrive[i].slice(), miss = n - have.length;
      var seeds = [];
      if (!have.length) for (var k = 0; k < n; k++) seeds.push((c.th0 || 0) + TAU * k / n);
      else {
        for (; miss > 0; miss--) {
          var all = have.concat(seeds).map(function (a) { return ((a % TAU) + TAU) % TAU; }).sort(function (a, b) { return a - b; });
          var best = 0, at = 0;
          for (var j = 0; j < all.length; j++) {
            var nx = j + 1 < all.length ? all[j + 1] : all[0] + TAU, gap = nx - all[j];
            if (gap > best) { best = gap; at = all[j] + gap / 2; }
          }
          // 空隙已不足一条线的间距就不再补
          if (best < TAU / n * 1.5) break;
          seeds.push(at);
        }
      }
      seeds.forEach(function (a) {
        add(trace(cfg, { x: c.x + Math.cos(a) * R_CHARGE, y: c.y + Math.sin(a) * R_CHARGE }, -1, box), -1);
      });
    });
    return lines;
  }

  // ---------- 电势网格与等势线 ----------
  // 在 box 上取 nx × ny 个格点
  function grid(cfg, box, nx, ny) {
    var g = new Float64Array(nx * ny), dx = (box.x1 - box.x0) / (nx - 1), dy = (box.y1 - box.y0) / (ny - 1);
    for (var j = 0; j < ny; j++) for (var i = 0; i < nx; i++) g[j * nx + i] = phi(cfg, box.x0 + i * dx, box.y0 + j * dy);
    return { v: g, nx: nx, ny: ny, box: box, dx: dx, dy: dy };
  }
  // marching squares：返回线段 [x1, y1, x2, y2, …]（世界坐标）
  function contour(G, level) {
    var out = [], nx = G.nx, ny = G.ny, v = G.v, b = G.box, dx = G.dx, dy = G.dy;
    function ip(x1, y1, a, x2, y2, c) { var t = (level - a) / (c - a); return [x1 + (x2 - x1) * t, y1 + (y2 - y1) * t]; }
    for (var j = 0; j < ny - 1; j++) for (var i = 0; i < nx - 1; i++) {
      var a = v[j * nx + i], bb = v[j * nx + i + 1], c = v[(j + 1) * nx + i + 1], d = v[(j + 1) * nx + i];
      var idx = (a > level ? 1 : 0) | (bb > level ? 2 : 0) | (c > level ? 4 : 0) | (d > level ? 8 : 0);
      if (idx === 0 || idx === 15) continue;
      var x0 = b.x0 + i * dx, y0 = b.y0 + j * dy, x1 = x0 + dx, y1 = y0 + dy;
      var eB = function () { return ip(x0, y0, a, x1, y0, bb); }, eR = function () { return ip(x1, y0, bb, x1, y1, c); },
        eT = function () { return ip(x0, y1, d, x1, y1, c); }, eL = function () { return ip(x0, y0, a, x0, y1, d); };
      var segs;
      switch (idx) {
        case 1: case 14: segs = [eL(), eB()]; break;
        case 2: case 13: segs = [eB(), eR()]; break;
        case 3: case 12: segs = [eL(), eR()]; break;
        case 4: case 11: segs = [eR(), eT()]; break;
        case 6: case 9: segs = [eB(), eT()]; break;
        case 7: case 8: segs = [eL(), eT()]; break;
        case 5: case 10:
          var mid = (a + bb + c + d) / 4 > level;
          if ((idx === 5) === mid) segs = [eL(), eT(), eB(), eR()];
          else segs = [eL(), eB(), eR(), eT()];
          break;
      }
      // 跳过跨越电荷奇点的格子（电势值相差悬殊，插值无意义）
      var mx = Math.max(a, bb, c, d), mn = Math.min(a, bb, c, d);
      if (mx - mn > Math.abs(level) * 3 + 2000) continue;
      for (var s = 0; s < segs.length; s += 2) out.push(segs[s][0], segs[s][1], segs[s + 1][0], segs[s + 1][1]);
    }
    return out;
  }
  // 以 step 为间隔的各条等势线：[{ level, segs }]，|level| ≤ kmax·step
  function equipotentials(G, step, kmax) {
    var res = [];
    for (var k = -kmax; k <= kmax; k++) {
      var segs = contour(G, k * step);
      if (segs.length) res.push({ level: k * step, segs: segs });
    }
    return res;
  }

  // ---------- 场强为零的点 ----------
  // 在网格上找 |∇φ| 的局部极小，再用牛顿法在 E = 0 上收敛
  function nullPoints(cfg, G) {
    var nx = G.nx, ny = G.ny, v = G.v, m = new Float64Array(nx * ny), res = [];
    for (var j = 1; j < ny - 1; j++) for (var i = 1; i < nx - 1; i++) {
      var gx = (v[j * nx + i + 1] - v[j * nx + i - 1]) / (2 * G.dx), gy = (v[(j + 1) * nx + i] - v[(j - 1) * nx + i]) / (2 * G.dy);
      m[j * nx + i] = gx * gx + gy * gy;
    }
    for (j = 2; j < ny - 2; j++) for (i = 2; i < nx - 2; i++) {
      var c = m[j * nx + i], isMin = true;
      for (var dj = -1; dj <= 1 && isMin; dj++) for (var di = -1; di <= 1; di++) {
        if ((di || dj) && m[(j + dj) * nx + i + di] < c) { isMin = false; break; }
      }
      if (!isMin) continue;
      var p = newton(cfg, G.box.x0 + i * G.dx, G.box.y0 + j * G.dy);
      if (!p) continue;
      if (res.some(function (r) { return Math.hypot(r.x - p.x, r.y - p.y) < 0.5; })) continue;
      if (cfg.charges.some(function (q) { return Math.hypot(q.x - p.x, q.y - p.y) < R_CHARGE * 2; })) continue;
      if (cfg.plates && onPlate(p.x, p.y, 0.3)) continue;   // 板面两侧场强不连续，不算
      res.push(p);
    }
    return res;
  }
  function newton(cfg, x, y) {
    var h = 1e-3;
    for (var n = 0; n < 40; n++) {
      var e = field(cfg, x, y);
      if (mag(e) < 1e-7) return { x: x, y: y };
      var ex1 = field(cfg, x + h, y), ey1 = field(cfg, x, y + h);
      var a = (ex1.x - e.x) / h, b = (ey1.x - e.x) / h, c = (ex1.y - e.y) / h, d = (ey1.y - e.y) / h, det = a * d - b * c;
      if (!isFinite(det) || Math.abs(det) < 1e-14) return null;
      var sx = (d * e.x - b * e.y) / det, sy = (-c * e.x + a * e.y) / det, s = Math.hypot(sx, sy);
      if (s > 2) { sx *= 2 / s; sy *= 2 / s; }
      x -= sx; y -= sy;
    }
    return null;
  }

  // ---------- 沿等势面走、沿路径做功 ----------
  // 从 p 出发沿等势线（垂直于 E 的方向）走 len cm，每步把点拉回原来的电势上
  function alongEquipotential(cfg, p, len, sgn) {
    var target = phi(cfg, p.x, p.y), x = p.x, y = p.y, h = 0.1, pts = [{ x: x, y: y }];
    for (var s = 0; s < len; s += h) {
      var e = field(cfg, x, y), m = mag(e);
      if (m < 1e-9) break;
      x += sgn * -e.y / m * h; y += sgn * e.x / m * h;
      for (var it = 0; it < 3; it++) {
        var e2 = field(cfg, x, y), m2 = e2.x * e2.x + e2.y * e2.y, dphi = phi(cfg, x, y) - target;
        if (m2 < 1e-18) break;
        // φ 沿 E 方向降低：∇φ = −E
        x += dphi * e2.x / m2; y += dphi * e2.y / m2;
      }
      pts.push({ x: x, y: y });
    }
    return pts;
  }
  // 路径 pts 上电场力对试探电荷 q（单位 C）做的功 W = q ∫ E·dl，返回逐点累计值（J）
  function workAlong(cfg, pts, q) {
    var acc = [0], W = 0;
    for (var i = 1; i < pts.length; i++) {
      var a = pts[i - 1], b = pts[i], m = { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 };
      var e = field(cfg, m.x, m.y);
      W += q * (e.x * (b.x - a.x) + e.y * (b.y - a.y));   // V/cm × cm = V
      acc.push(W);
    }
    return acc;
  }
  // 从 A 到 B 的路径：直线，或向一侧鼓出的弧线（二次贝塞尔）
  function path(A, B, kind, n) {
    n = n || 600;
    var pts = [], cx = (A.x + B.x) / 2, cy = (A.y + B.y) / 2, dx = B.x - A.x, dy = B.y - A.y;
    var bulge = kind === 'curve' ? 0.75 : 0, ox = cx - dy * bulge, oy = cy + dx * bulge;
    for (var i = 0; i <= n; i++) {
      var t = i / n, u = 1 - t;
      pts.push({ x: u * u * A.x + 2 * u * t * ox + t * t * B.x, y: u * u * A.y + 2 * u * t * oy + t * t * B.y });
    }
    return pts;
  }

  // ---------- 预设 ----------
  var PRESETS = {
    pos: { name: '正点电荷', charges: [{ x: 0, y: 0, q: 1 }] },
    neg: { name: '负点电荷', charges: [{ x: 0, y: 0, q: -1 }] },
    dipole: { name: '等量异种电荷', charges: [{ x: -8, y: 0, q: 1 }, { x: 8, y: 0, q: -1, th0: Math.PI }] },
    same: { name: '等量同种电荷', charges: [{ x: -8, y: 0, q: 1 }, { x: 8, y: 0, q: 1, th0: Math.PI }] },
    unequal: { name: '不等量异种电荷', charges: [{ x: -3, y: 0, q: 2 }, { x: 3, y: 0, q: -1, th0: Math.PI }] },
    plates: { name: '平行板（匀强电场）', charges: [], plates: true }
  };
  function preset(key) {
    var p = PRESETS[key];
    return { charges: p.charges.map(function (c) { return { x: c.x, y: c.y, q: c.q, th0: c.th0 || 0 }; }), plates: !!p.plates };
  }
  function totalQ(cfg) { return cfg.charges.reduce(function (s, c) { return s + c.q; }, 0); }

  // ---------- 格式 ----------
  var SUP = { '-': '⁻', '0': '⁰', '1': '¹', '2': '²', '3': '³', '4': '⁴', '5': '⁵', '6': '⁶', '7': '⁷', '8': '⁸', '9': '⁹' };
  function sci(x, d) {
    if (x === 0) return '0';
    var e = Math.floor(Math.log10(Math.abs(x))), m = x / Math.pow(10, e);
    if (Math.abs(m) >= 9.995) { m /= 10; e += 1; }
    var ms = m.toFixed(d == null ? 2 : d);
    if (e === 0) return ms;
    return ms + '×10' + String(e).split('').map(function (ch) { return SUP[ch]; }).join('');
  }
  function fmtE(eVcm) {   // 场强 N/C
    var v = eVcm * 100;
    if (v < 0.5) return '0 N/C';
    return (v < 1e4 ? Math.round(v).toString() : sci(v)) + ' N/C';
  }
  function fmtV(v, sign) {
    var a = Math.abs(v), s = a < 9.95 ? a.toFixed(1) : Math.round(a).toString();
    if (s === '0' || s === '0.0') return '0 V';
    return (v < 0 ? '−' : sign ? '+' : '') + s + ' V';
  }
  function fmtQ(q) { return (q > 0 ? '+' : '−') + Math.abs(q).toFixed(1) + '×10⁻⁹ C'; }
  function fmtJ(w) {
    if (Math.abs(w) < 5e-12) return '0 J';
    return (w < 0 ? '−' : '+') + sci(Math.abs(w)) + ' J';
  }

  // ---------- 练习 ----------
  // 四类题：E 比较场强大小，phi 比较电势高低，work 判断电场力做功正负，sign 由电场线判断电性
  var TYPES = ['E', 'phi', 'work', 'sign'];
  function pick(a) { return a[Math.floor(Math.random() * a.length)]; }
  function rnd(a, b) { return a + Math.random() * (b - a); }
  function farFrom(cfg, p, r) {
    if (cfg.plates && onPlate(p.x, p.y, 1.2)) return false;
    return cfg.charges.every(function (c) { return Math.hypot(c.x - p.x, c.y - p.y) > r; });
  }
  function randPt(cfg, R) {
    for (var n = 0; n < 200; n++) {
      var p = { x: Math.round(rnd(-R.x, R.x) * 2) / 2, y: Math.round(rnd(-R.y, R.y) * 2) / 2 };
      if (farFrom(cfg, p, 3)) return p;
    }
    return { x: 0, y: R.y };
  }
  // 两点关系相同（等号）的对称点对
  function equalPair(key, kind) {
    var a;
    if (key === 'plates') {
      a = { x: rnd(-4, 4), y: rnd(-10, 10) };
      return kind === 'E' ? [{ x: Math.round(rnd(-4, 4)), y: Math.round(rnd(-7, -1)) }, { x: Math.round(rnd(-4, 4)), y: Math.round(rnd(1, 7)) }]
        : [{ x: Math.round(a.x), y: -7 }, { x: Math.round(a.x), y: 7 }];
    }
    if (key === 'pos' || key === 'neg') {
      var r = Math.round(rnd(5, 10)), t1 = rnd(0, TAU), t2 = t1 + rnd(1.2, 3.0);
      return [{ x: r * Math.cos(t1), y: r * Math.sin(t1) }, { x: r * Math.cos(t2), y: r * Math.sin(t2) }];
    }
    if (key === 'dipole' && kind !== 'E') { var y1 = Math.round(rnd(-10, -3)), y2 = Math.round(rnd(3, 10)); return [{ x: 0, y: y1 }, { x: 0, y: y2 }]; }
    // 等量异种的 E、等量同种的 E 与 φ：关于中垂线（或连线）镜像对称
    a = { x: Math.round(rnd(2, 12)), y: Math.round(rnd(3, 9)) };
    return Math.random() < 0.5 ? [a, { x: -a.x, y: a.y }] : [a, { x: a.x, y: -a.y }];
  }
  function quiz(only) {
    var type = only || pick(TYPES), q = { type: type };
    if (type === 'sign') {
      var kinds = [[1, -1, 'a 正、b 负'], [-1, 1, 'a 负、b 正'], [1, 1, 'a、b 都带正电'], [-1, -1, 'a、b 都带负电']], k = pick(kinds);
      q.cfg = { charges: [{ x: -8, y: 0, q: k[0], th0: 0 }, { x: 8, y: 0, q: k[1], th0: Math.PI }], plates: false };
      q.hideSign = true;
      q.prompt = '图中 a、b 两个点电荷的电荷量大小相等，根据电场线的分布和方向，判断它们的电性：';
      q.options = kinds.map(function (x) { return x[2]; });
      q.answer = k[2];
      q.explain = (k[0] * k[1] < 0 ? '电场线从一个电荷出发、终止于另一个电荷，是异种电荷；' : '电场线互相“排斥”、不相连，中点附近没有电场线，是同种电荷；') +
        '电场线从正电荷（或无穷远）出发，终止于负电荷（或无穷远），看箭头：' +
        (k[0] > 0 ? 'a 处电场线向外发出，a 带正电；' : 'a 处电场线指向 a，a 带负电；') + (k[1] > 0 ? 'b 带正电。' : 'b 带负电。');
      return q;
    }
    var key = pick(type === 'E' ? ['pos', 'neg', 'dipole', 'same', 'plates'] : ['pos', 'neg', 'dipole', 'same', 'plates', 'unequal']);
    var cfg = preset(key), A, B, eq = Math.random() < 0.25 && key !== 'unequal';
    var box = { x: key === 'plates' ? 4.5 : 14, y: key === 'plates' ? 7 : 10 };
    if (eq) { var pr = equalPair(key, type); A = pr[0]; B = pr[1]; }
    else {
      for (var n = 0; n < 400; n++) {
        A = randPt(cfg, box); B = randPt(cfg, box);
        if (Math.hypot(A.x - B.x, A.y - B.y) < 5) continue;
        if (type === 'E') {
          if (key === 'plates') { eq = true; break; }
          var r = mag(field(cfg, A.x, A.y)) / mag(field(cfg, B.x, B.y));
          if (r > 1.6 || r < 1 / 1.6) break;
        } else {
          var d = phi(cfg, A.x, A.y) - phi(cfg, B.x, B.y);
          if (Math.abs(d) > 12) break;
        }
      }
    }
    q.cfg = cfg; q.key = key; q.A = A; q.B = B;
    var EA = mag(field(cfg, A.x, A.y)), EB = mag(field(cfg, B.x, B.y)), pA = phi(cfg, A.x, A.y), pB = phi(cfg, B.x, B.y);
    q.EA = EA; q.EB = EB; q.pA = pA; q.pB = pB;
    var nm = PRESETS[key].name.replace('（匀强电场）', '间');
    if (type === 'E') {
      q.prompt = nm + '的电场中，比较 A、B 两点电场强度的大小：';
      q.options = ['E_A > E_B', 'E_A < E_B', 'E_A = E_B'];
      var same = key === 'plates' || Math.abs(EA - EB) / Math.max(EA, EB) < 0.03;   // 两板间按匀强电场处理（边缘效应忽略）
      q.answer = same ? q.options[2] : EA > EB ? q.options[0] : q.options[1];
      q.explain = same ? (key === 'plates' ? '两板之间是匀强电场，电场线平行等距，各点场强大小、方向都相同。' : 'A、B 两点关于电荷的位置对称，电场线的疏密程度相同，场强大小相等（方向不一定相同）。')
        : '电场线越密的地方场强越大：' + (EA > EB ? 'A' : 'B') + ' 处电场线更密。';
      q.explain += 'E_A ≈ ' + fmtE(EA) + '，E_B ≈ ' + fmtE(EB) + '。';
    } else if (type === 'phi') {
      q.prompt = nm + '的电场中，比较 A、B 两点电势的高低：';
      q.options = ['φ_A > φ_B', 'φ_A < φ_B', 'φ_A = φ_B'];
      var sameP = Math.abs(pA - pB) < 1;
      q.answer = sameP ? q.options[2] : pA > pB ? q.options[0] : q.options[1];
      q.explain = (sameP ? 'A、B 在同一个等势面上，电势相等。' : '沿电场线方向电势逐渐降低：从 ' + (pA > pB ? 'A 到 B' : 'B 到 A') + ' 整体上是顺着电场线走的。') +
        'φ_A ≈ ' + fmtV(pA) + '，φ_B ≈ ' + fmtV(pB) + '（取无穷远处电势为零）。';
    } else {
      var sg = Math.random() < 0.5 ? 1 : -1, W = sg * Q_TEST * (pA - pB);
      q.sg = sg;
      q.prompt = nm + '的电场中，把一个' + (sg > 0 ? '正' : '负') + '试探电荷从 A 移到 B，电场力：';
      q.options = ['做正功，电势能减少', '做负功，电势能增加', '不做功，电势能不变'];
      var zero = Math.abs(pA - pB) < 1;
      q.answer = zero ? q.options[2] : W > 0 ? q.options[0] : q.options[1];
      q.explain = 'W_AB = qU_AB = q(φ_A − φ_B)，U_AB ≈ ' + fmtV(pA - pB) + '，q 为' + (sg > 0 ? '正' : '负') + '，' +
        (zero ? 'U_AB = 0，W = 0。电荷在等势面上移动，电场力不做功。' : 'W ' + (W > 0 ? '> 0' : '< 0') + '；电场力做多少正功，电势能就减少多少。');
    }
    return q;
  }

  window.Field = {
    TAU: TAU, Q0: Q0, K: K, Q_TEST: Q_TEST, R_CHARGE: R_CHARGE, MAX_CHARGES: MAX_CHARGES, PLATE: PLATE, PRESETS: PRESETS, TYPES: TYPES,
    clamp: clamp, phi: phi, field: field, mag: mag, onPlate: onPlate, trace: trace, fieldLines: fieldLines, grid: grid, contour: contour,
    equipotentials: equipotentials, nullPoints: nullPoints, alongEquipotential: alongEquipotential, workAlong: workAlong, path: path,
    preset: preset, totalQ: totalQ, sci: sci, fmtE: fmtE, fmtV: fmtV, fmtQ: fmtQ, fmtJ: fmtJ, quiz: quiz
  };
})();
