// 2D 绘制：光照强度曲线（叶肉细胞气体交换示意 + 曲线与 A/B/C 点）、多因素曲线（光照 / CO₂ / 温度为横轴）、夏季一昼夜净光合速率与有机物积累
// 示意图在虚拟坐标 300×250 里画，按区域等比缩放居中；曲线直接画在屏幕坐标
(function () {
  var P = window.PCurve;
  var GOLD = '#ffc94a', O2C = '#4fc3f7', CO2C = '#ff9a62', PHO = '#7ee081', RES = '#ff7a59', CMP = '#9ad0ff';
  var MUTED = '#8d99ab', TEXT = '#e6ebf2', LINE = 'rgba(141,153,171,.55)', GRID = 'rgba(141,153,171,.14)';
  var FAM = ['#7fb4ff', GOLD, '#ff8fb1'];      // 多因素：三条曲线（低 → 高）
  var FONT = '-apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", sans-serif';

  function font(px, w) { return (w ? w + ' ' : '') + px + 'px ' + FONT; }
  function label(ctx, s, x, y, o) {
    o = o || {};
    ctx.font = font(o.size || 12, o.bold ? 600 : null);
    ctx.textAlign = o.align || 'center'; ctx.textBaseline = o.base || 'middle';
    ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(5,7,13,.85)'; ctx.strokeText(s, x, y);
    ctx.fillStyle = o.color || TEXT; ctx.fillText(s, x, y);
  }
  function arrow(ctx, x1, y1, x2, y2, size, color, width) {
    var a = Math.atan2(y2 - y1, x2 - x1), len = Math.hypot(x2 - x1, y2 - y1);
    if (len < 1) return;
    size = Math.min(size, len * 0.7);
    ctx.strokeStyle = ctx.fillStyle = color; ctx.lineWidth = width || 2; ctx.setLineDash([]);
    ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2 - Math.cos(a) * size * 0.6, y2 - Math.sin(a) * size * 0.6); ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(x2, y2);
    ctx.lineTo(x2 - size * Math.cos(a - 0.45), y2 - size * Math.sin(a - 0.45));
    ctx.lineTo(x2 - size * Math.cos(a + 0.45), y2 - size * Math.sin(a + 0.45));
    ctx.closePath(); ctx.fill();
  }
  function rrect(ctx, x, y, w, h, r) {
    ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
  }
  function fit(box, vw, vh) {
    var k = Math.min(box.w / vw, box.h / vh);
    return { k: k, ox: box.x + (box.w - vw * k) / 2, oy: box.y + (box.h - vh * k) / 2 };
  }
  function fmt(v, d) { return (+v).toFixed(d == null ? 0 : d); }
  function hm(t) { var mm = Math.round(t * 60), h = Math.floor(mm / 60), m = mm % 60; return h + ':' + (m < 10 ? '0' : '') + m; }
  function dot(ctx, x, y, r, color, hollow) {
    ctx.beginPath(); ctx.arc(x, y, r, 0, 7);
    if (hollow) { ctx.fillStyle = '#05070d'; ctx.fill(); ctx.strokeStyle = color; ctx.lineWidth = 1.6; ctx.stroke(); }
    else { ctx.fillStyle = color; ctx.fill(); }
  }
  function vguide(ctx, a, x, y, color) {
    ctx.strokeStyle = color; ctx.lineWidth = 1; ctx.setLineDash([3, 3]);
    ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x, a.sy(0)); ctx.stroke(); ctx.setLineDash([]);
  }

  function tile(ctx, box, background) {
    rrect(ctx, box.x, box.y, box.w, box.h, 13);
    ctx.fillStyle = background; ctx.fill();
    ctx.strokeStyle = '#253446'; ctx.lineWidth = 1; ctx.stroke();
  }
  function legend(ctx, items, x, y) {
    items.forEach(function (item) {
      ctx.strokeStyle = item[1]; ctx.lineWidth = 2; ctx.setLineDash(item[2] ? [3, 2] : []);
      ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + 11, y); ctx.stroke();
      ctx.setLineDash([]);
      label(ctx, item[0], x + 16, y, { align: 'left', size: 11, color: item[1] });
      x += 27 + ctx.measureText(item[0]).width;
    });
  }
  function marker(ctx, x, y, color) {
    ctx.fillStyle = color + '28';
    ctx.beginPath(); ctx.arc(x, y, 10, 0, 7); ctx.fill();
    dot(ctx, x, y, 5, color, true);
  }

  // ---------- 通用曲线坐标系 ----------
  // box：区域；o：{ x0,x1,y0,y1, xTicks, yTicks, xName, yName, title }；纵轴有负值时在 0 处画横轴
  function axes(ctx, box, o) {
    var L = box.x + 39, R = box.x + box.w - 20, T = box.y + (o.legend ? 58 : 35), B = box.y + box.h - (o.xName ? 39 : 25);
    var sx = function (v) { return L + (v - o.x0) / (o.x1 - o.x0) * (R - L); };
    var sy = function (v) { return B - (v - o.y0) / (o.y1 - o.y0) * (B - T); };
    tile(ctx, box, '#0b121c');
    ctx.font = font(11); ctx.textBaseline = 'top'; ctx.textAlign = 'center';
    (o.xTicks || []).forEach(function (v) {
      var x = sx(v);
      ctx.strokeStyle = GRID; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(x, T); ctx.lineTo(x, B); ctx.stroke();
      ctx.fillStyle = MUTED; ctx.fillText(o.xFmt ? o.xFmt(v) : String(v), x, B + 4);
    });
    ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
    (o.yTicks || []).forEach(function (v) {
      var y = sy(v);
      ctx.strokeStyle = GRID; ctx.beginPath(); ctx.moveTo(L, y); ctx.lineTo(R, y); ctx.stroke();
      ctx.fillStyle = MUTED; ctx.fillText(String(v), L - 5, y);
    });
    ctx.strokeStyle = LINE; ctx.lineWidth = 1.2;
    ctx.beginPath(); ctx.moveTo(L, T - 4); ctx.lineTo(L, B); ctx.lineTo(R + 4, B); ctx.stroke();
    if (o.y0 < 0) {
      ctx.strokeStyle = 'rgba(230,235,242,.5)'; ctx.beginPath(); ctx.moveTo(L, sy(0)); ctx.lineTo(R + 4, sy(0)); ctx.stroke();
    }
    label(ctx, o.title, box.x + 13, box.y + 17, { align: 'left', size: 13, bold: true, color: GOLD });
    if (o.yName) label(ctx, o.yName, box.x + box.w - 12, box.y + 17, { align: 'right', size: 11, color: MUTED });
    if (o.legend) legend(ctx, o.legend, box.x + 13, box.y + 39);
    if (o.xName) label(ctx, o.xName, R, B + 28, { align: 'right', size: 11, color: MUTED });
    return { L: L, R: R, T: T, B: B, sx: sx, sy: sy, x0: o.x0, x1: o.x1, y0: o.y0, y1: o.y1 };
  }
  function ticks(lo, hi, step) { var r = []; for (var v = Math.ceil(lo / step) * step; v <= hi + 1e-9; v += step) r.push(Math.round(v * 100) / 100); return r; }
  // 画 y = f(x)（x 在 [x0, x1]），超出纵轴范围的部分裁掉
  function curve(ctx, a, f, x0, x1, color, width, dash) {
    ctx.save();
    ctx.beginPath(); ctx.rect(a.L, a.T - 6, a.R - a.L + 6, a.B - a.T + 6); ctx.clip();
    ctx.strokeStyle = color; ctx.lineWidth = width; ctx.setLineDash(dash || []);
    ctx.beginPath();
    var n = Math.max(60, Math.round(a.R - a.L) / 2);
    for (var i = 0; i <= n; i++) {
      var x = x0 + (x1 - x0) * i / n, px = a.sx(x), py = a.sy(f(x));
      if (i) ctx.lineTo(px, py); else ctx.moveTo(px, py);
    }
    ctx.stroke();
    ctx.restore();
  }
  // 小太阳：亮度 0～1
  function sun(ctx, x, y, r, lum) {
    if (lum <= 0) {
      ctx.strokeStyle = MUTED; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(x, y, r * 0.8, 0, 7); ctx.stroke();
      return;
    }
    var g = ctx.createRadialGradient(x, y, 0, x, y, r * 2.6);
    g.addColorStop(0, 'rgba(255,220,110,' + (0.25 + 0.4 * lum) + ')'); g.addColorStop(1, 'rgba(255,220,110,0)');
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r * 2.6, 0, 7); ctx.fill();
    ctx.fillStyle = 'rgba(255,214,90,' + (0.45 + 0.55 * lum) + ')'; ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.fill();
    ctx.strokeStyle = ctx.fillStyle; ctx.lineWidth = 2;
    for (var i = 0; i < 8; i++) {
      var an = i * Math.PI / 4, l2 = r * (1.35 + 0.5 * lum);
      ctx.beginPath(); ctx.moveTo(x + Math.cos(an) * r * 1.25, y + Math.sin(an) * r * 1.25); ctx.lineTo(x + Math.cos(an) * l2, y + Math.sin(an) * l2); ctx.stroke();
    }
  }

  // ---------- 叶肉细胞：叶绿体与线粒体之间、与外界的气体交换 ----------
  // p：总光合速率，r：呼吸速率（mg CO₂/(100 cm²·h)），L：光照 klx
  function cell(ctx, p, r, L) {
    label(ctx, '叶肉细胞 · 气体交换', 16, 18, { align: 'left', size: 14, bold: true, color: GOLD });
    sun(ctx, 211, 18, 6, Math.min(1, L / 30));
    label(ctx, L > 0 ? fmt(L, L < 10 ? 1 : 0) + ' klx' : '黑暗', 226, 18, { align: 'left', size: 11, color: L > 0 ? GOLD : MUTED });

    // 不规则细胞壁、贴壁液泡与细胞质。突出一对参与交换的细胞器。
    var sap = ctx.createLinearGradient(35, 50, 270, 205);
    sap.addColorStop(0, L > 0 ? '#355a3e' : '#273c37');
    sap.addColorStop(1, '#102627');
    ctx.beginPath();
    ctx.moveTo(57, 64);
    ctx.bezierCurveTo(94, 42, 110, 62, 146, 55);
    ctx.bezierCurveTo(179, 47, 228, 51, 247, 79);
    ctx.bezierCurveTo(267, 105, 252, 124, 259, 149);
    ctx.bezierCurveTo(268, 186, 233, 202, 194, 196);
    ctx.bezierCurveTo(158, 190, 147, 214, 110, 204);
    ctx.bezierCurveTo(80, 196, 50, 200, 40, 174);
    ctx.bezierCurveTo(23, 144, 34, 91, 57, 64);
    ctx.closePath();
    ctx.fillStyle = sap; ctx.fill();
    ctx.strokeStyle = '#304f43'; ctx.lineWidth = 8; ctx.stroke();
    ctx.strokeStyle = '#82aa76'; ctx.lineWidth = 2; ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(69, 87);
    ctx.bezierCurveTo(108, 65, 146, 90, 177, 73);
    ctx.bezierCurveTo(217, 59, 241, 101, 225, 131);
    ctx.bezierCurveTo(211, 154, 247, 164, 220, 177);
    ctx.bezierCurveTo(187, 195, 148, 169, 117, 187);
    ctx.bezierCurveTo(59, 201, 43, 143, 69, 87);
    var vacuole = ctx.createLinearGradient(90, 80, 192, 190);
    vacuole.addColorStop(0, '#315347'); vacuole.addColorStop(1, '#1c3a35');
    ctx.fillStyle = vacuole; ctx.fill();
    ctx.strokeStyle = '#496f5b'; ctx.lineWidth = 1; ctx.stroke();

    var glow = Math.min(1, p / 15);
    function plastid(x, y, scale, angle) {
      ctx.save(); ctx.translate(x, y); ctx.rotate(angle); ctx.scale(scale, scale);
      var pigment = ctx.createLinearGradient(0, -18, 0, 18);
      pigment.addColorStop(0, glow > 0 ? '#9fcc76' : '#668466');
      pigment.addColorStop(1, '#2b5c40');
      ctx.fillStyle = pigment; ctx.beginPath(); ctx.ellipse(0, 0, 29, 17, 0, 0, 7); ctx.fill();
      ctx.strokeStyle = '#a3c78e'; ctx.lineWidth = 1.2; ctx.stroke();
      for (var i = -2; i <= 2; i++) {
        for (var j = -1; j <= 1; j++) {
          ctx.fillStyle = j === 0 ? '#294f34' : '#3b6740';
          rrect(ctx, i * 9 - 3.5, j * 4 - 1.4, 7, 2.8, 1); ctx.fill();
        }
      }
      ctx.restore();
    }
    ctx.save(); ctx.globalAlpha = 0.52;
    plastid(68, 83, 0.42, -0.5); plastid(139, 67, 0.42, -0.12);
    plastid(223, 77, 0.42, 0.48); plastid(231, 173, 0.45, -0.55);
    plastid(133, 191, 0.47, -0.15); plastid(58, 166, 0.4, 0.7);
    ctx.restore();
    var cx = 92, cy = 127, mx = 209, my = 127;
    plastid(cx, cy, 1, -0.16);
    ctx.save(); ctx.translate(mx, my); ctx.rotate(0.15);
    var matrix = ctx.createLinearGradient(0, -16, 0, 16);
    matrix.addColorStop(0, '#e7ad80'); matrix.addColorStop(1, '#824939');
    ctx.fillStyle = matrix; ctx.beginPath(); ctx.ellipse(0, 0, 27, 14, 0, 0, 7); ctx.fill();
    ctx.strokeStyle = '#f4bea0'; ctx.lineWidth = 1.2; ctx.stroke();
    ctx.strokeStyle = '#7a3c37'; ctx.lineWidth = 1.8; ctx.beginPath(); ctx.moveTo(-21, 0);
    for (var i = -20; i < 20; i += 10) ctx.bezierCurveTo(i + 3, -15, i + 7, 15, i + 10, 0);
    ctx.stroke(); ctx.restore();
    label(ctx, '叶绿体', cx, 154, { size: 12, color: PHO });
    label(ctx, '线粒体', mx, 154, { size: 12, color: RES });

    function width(rate) { return 1.4 + 4 * Math.sqrt(Math.min(1, rate / 24)); }
    var inner = Math.min(p, r), net = p - r;
    var equal = Math.abs(net) <= 0.05;
    if (inner > 0.05) {
      arrow(ctx, 178, 118, 124, 118, 7, CO2C, width(inner));
      arrow(ctx, 124, 136, 178, 136, 7, O2C, width(inner));
      label(ctx, 'CO₂', 150, 105, { size: 11, color: CO2C });
      label(ctx, 'O₂', 150, 149, { size: 11, color: O2C });
    }
    if (net > 0.05) {
      arrow(ctx, 27, 82, 66, 117, 8, CO2C, width(net));
      arrow(ctx, 67, 137, 26, 176, 8, O2C, width(net));
      label(ctx, '吸收 CO₂', 14, 71, { align: 'left', size: 11, color: CO2C });
      label(ctx, '释放 O₂', 14, 190, { align: 'left', size: 11, color: O2C });
    } else if (net < -0.05) {
      arrow(ctx, 230, 117, 272, 82, 8, CO2C, width(-net));
      arrow(ctx, 274, 176, 232, 137, 8, O2C, width(-net));
      label(ctx, '释放 CO₂', 285, 71, { align: 'right', size: 11, color: CO2C });
      label(ctx, '吸收 O₂', 285, 190, { align: 'right', size: 11, color: O2C });
    }
    var status = L <= 0 ? '黑暗 · 仅细胞呼吸' : equal ? '接近补偿点 · 净交换近零' : net < 0 ? '光合 < 呼吸' : '光合 > 呼吸';
    label(ctx, status, 150, 229, { size: 13, bold: true, color: equal ? GOLD : net < 0 ? RES : PHO });
  }

  // ---------- 视图 ----------
  function View(canvas) {
    var ctx = canvas.getContext('2d'), W = 0, H = 0, dpr = 1, narrow = false, geo = {};
    function resize(w, h) {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      W = w; H = h; narrow = w < 640;
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
      canvas.style.width = w + 'px'; canvas.style.height = h + 'px';
    }
    function begin() {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, W, H);
    }
    function split(day) {
      var gap = 12, edge = narrow ? 12 : 18, w = W - edge * 2;
      var h = Math.min(H - 16, 650), top = (H - h) / 2;
      if (narrow) {
        var ha = Math.min(day ? 228 : 268, h * (day ? 0.38 : 0.46));
        return { a: { x: edge, y: top, w: w, h: ha }, b: { x: edge, y: top + ha + gap, w: w, h: h - ha - gap } };
      }
      var wa = Math.min(w * 0.38, 418), sceneH = Math.min(h, wa * (day ? 1.05 : 0.9));
      return { a: { x: edge, y: top + (h - sceneH) / 2, w: wa, h: sceneH }, b: { x: edge + wa + gap, y: top, w: w - wa - gap, h: h } };
    }
    function full() {
      var w = Math.min(W - 24, 1000), h = Math.min(H - 16, 650);
      return { x: (W - w) / 2, y: (H - h) / 2, w: w, h: h };
    }
    function diagram(box, height, paint) {
      tile(ctx, box, '#0b181a');
      var f = fit(box, 300, height);
      ctx.save(); ctx.translate(f.ox, f.oy); ctx.scale(f.k, f.k);
      paint();
      ctx.restore();
    }

    // ===== 场景一：光照强度与光合速率 =====
    // 阴生植物单独观察时放大纵轴，取样超过 30 klx 时保留完整横轴。
    function lightRange(s) {
      var x1 = s.axMax || (s.L > 30 ? 70 : 30);
      return s.plant === 'shade' && !s.compare ? { x1: x1, y0: -3, y1: 12, xs: x1 === 70 ? 10 : 5, ys: 3 } : { x1: 70, y0: -8, y1: 32, xs: 10, ys: 8 };
    }
    function drawLight(s) {
      begin();
      var sp = split(false), cond = s.cond, k = P.params(cond), g = P.gross(s.L, cond), R = k.R;
      diagram(sp.a, 250, function () { cell(ctx, g, R, s.L); });
      var other = cond.plant === 'shade' ? 'sun' : 'shade';
      var lines = [['净光合', GOLD]];
      if (s.gross) lines.push(['总光合', PHO]);
      if (s.compare) lines.push([P.PLANTS[other].name, CMP, true]);
      if (s.refOn) lines.push(['参照', MUTED, true]);
      var rg = lightRange(s);
      var a = axes(ctx, sp.b, {
        x0: 0, x1: rg.x1, y0: rg.y0, y1: rg.y1, xTicks: ticks(0, rg.x1, rg.xs), yTicks: ticks(rg.y0, rg.y1, rg.ys),
        title: P.PLANTS[cond.plant].name + '光照响应', xName: '光照强度 (klx)', yName: 'mg CO₂/(100 cm²·h)', legend: lines
      });
      geo = { scene: 'light', plot: a };
      var pts = P.lightPoints(cond);
      var netF = function (x) { return P.net(x, cond); }, grossF = function (x) { return P.gross(x, cond); };
      // 参照曲线（CO₂ 400 ppm、25 °C、不缺镁），条件改变时显示，并标出 B、C 点的移动
      if (s.refOn) {
        var rc = { plant: cond.plant, co2: P.STD.co2, temp: P.STD.temp, mg: true }, rp = P.lightPoints(rc);
        curve(ctx, a, function (x) { return P.net(x, rc); }, 0, rg.x1, 'rgba(230,235,242,.45)', 1.5, [6, 5]);
        if (rp.comp != null) dot(ctx, a.sx(rp.comp), a.sy(0), 3.5, 'rgba(230,235,242,.7)', true);
        dot(ctx, a.sx(rp.sat), a.sy(P.net(rp.sat, rc)), 3.5, 'rgba(230,235,242,.7)', true);
        dot(ctx, a.sx(0), a.sy(-rp.k.R), 3.5, 'rgba(230,235,242,.7)', true);
        var shift = function (x0, x1, y) {
          if (x0 == null || x1 == null || x0 > a.x1 || x1 > a.x1 || Math.abs(a.sx(x1) - a.sx(x0)) < 6) return;
          arrow(ctx, a.sx(x0), y, a.sx(x1), y, 7, 'rgba(230,235,242,.8)', 1.4);
        };
        shift(rp.comp, pts.comp, a.sy(0) + 14);
        shift(rp.sat, pts.sat, a.sy(0) + 14);
      }
      // 对比另一种植物
      if (s.compare) {
        var oc = { plant: other, co2: cond.co2, temp: cond.temp, mg: cond.mg }, op = P.lightPoints(oc);
        curve(ctx, a, function (x) { return P.net(x, oc); }, 0, rg.x1, CMP, 1.8, [7, 4]);
        if (op.comp != null) dot(ctx, a.sx(op.comp), a.sy(0), 3.5, CMP);
        dot(ctx, a.sx(op.sat), a.sy(P.net(op.sat, oc)), 3.5, CMP);
      }
      // 总光合速率 = 净光合速率 + 呼吸速率
      if (s.gross) {
        curve(ctx, a, grossF, 0, rg.x1, PHO, 2, []);
        // 呼吸速率是两个取样点的纵向差值。
        var x = P.clamp(a.sx(s.L) + (s.L > rg.x1 * 0.9 ? -11 : 11), a.L, a.R);
        var y1 = a.sy(g), y2 = a.sy(g - R);
        if (y2 - y1 > 12) {
          arrow(ctx, x, (y1 + y2) / 2, x, y1 + 1, 5, RES, 1.4);
          arrow(ctx, x, (y1 + y2) / 2, x, y2 - 1, 5, RES, 1.4);
        }
      }
      curve(ctx, a, netF, 0, rg.x1, GOLD, 2.6, []);
      // A：只进行呼吸；B：光补偿点；C：光饱和点
      var Ay = a.sy(-R);
      dot(ctx, a.sx(0), Ay, 4.5, RES);
      label(ctx, 'A 呼吸', a.sx(0) + 8, Ay + 10, { align: 'left', size: 11, color: RES });
      if (pts.comp != null && pts.comp < rg.x1) {
        var bx = a.sx(pts.comp);
        dot(ctx, bx, a.sy(0), 4.5, GOLD);
        label(ctx, 'B 光补偿点', bx + (bx > a.R - 72 ? -8 : 8), a.sy(0) - 12, { align: bx > a.R - 72 ? 'right' : 'left', size: 11, color: GOLD });
      }
      if (pts.sat < rg.x1) {
        var cxp = a.sx(pts.sat), cyp = a.sy(netF(pts.sat));
        vguide(ctx, a, cxp, cyp, 'rgba(255,201,74,.5)');
        ctx.strokeStyle = 'rgba(255,201,74,.35)'; ctx.setLineDash([3, 3]); ctx.lineWidth = 1;
        ctx.beginPath(); ctx.moveTo(a.L, cyp); ctx.lineTo(cxp, cyp); ctx.stroke(); ctx.setLineDash([]);
        dot(ctx, cxp, cyp, 4.5, GOLD);
        var nearB = pts.comp != null && Math.abs(cxp - a.sx(pts.comp)) < 80 && Math.abs(cyp - a.sy(0)) < 20;
        label(ctx, 'C 光饱和点', P.clamp(cxp, a.L + 34, a.R - 34), cyp + (nearB ? 17 : -15), { size: 11, color: GOLD });
      }
      // 当前光照
      var px = a.sx(s.L), py = a.sy(netF(s.L));
      ctx.strokeStyle = 'rgba(230,235,242,.45)'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(px, a.T - 4); ctx.lineTo(px, a.B); ctx.stroke();
      marker(ctx, px, py, TEXT);
      if (s.gross) marker(ctx, px, a.sy(g), PHO);
    }

    // ===== 场景二：多因素对光合速率的影响 =====
    function drawFactor(s) {
      begin();
      var box = full(), cond = s.cond, a, cur;
      geo = { scene: 'factor', x: s.xv };
      var conditions = s.family.map(function (m, i) { return [m.name, FAM[i]]; });
      if (s.xv === 'light') {
        a = axes(ctx, box, { x0: 0, x1: 70, y0: -8, y1: 32, xTicks: ticks(0, 70, 10), yTicks: ticks(-8, 32, 8),
          title: '净光合 · 光照 × ' + (s.by === 'temp' ? '温度' : 'CO₂'), xName: '光照强度 (klx)', yName: 'mg CO₂/(100 cm²·h)', legend: conditions });
        cur = s.L;
        var fam = s.family;
        // 光照弱时三条线几乎重合（限制因素是光照），光强以后分开（限制因素是另一个因素）
        var lowSat = P.lightPoints(fam[0].cond).sat;
        ctx.fillStyle = 'rgba(126,224,129,.05)'; ctx.fillRect(a.L, a.T, a.sx(Math.min(70, lowSat)) - a.L, a.B - a.T);
        fam.forEach(function (m, i) {
          curve(ctx, a, function (x) { return P.net(x, m.cond); }, 0, 70, FAM[i], i === 1 ? 2.6 : 2, []);
          var lp = P.lightPoints(m.cond);
          if (lp.sat < 70) dot(ctx, a.sx(lp.sat), a.sy(P.net(lp.sat, m.cond)), 4, FAM[i]);
          var y = a.sy(P.net(cur, m.cond));
          dot(ctx, a.sx(cur), y, 4, FAM[i], true);
        });
      } else if (s.xv === 'co2') {
        a = axes(ctx, box, { x0: 0, x1: 1600, y0: -8, y1: 32, xTicks: ticks(0, 1600, narrow ? 400 : 200), yTicks: ticks(-8, 32, 8),
          title: '净光合 · CO₂ × 光照', xName: 'CO₂ 浓度 (ppm)', yName: 'mg CO₂/(100 cm²·h)', legend: conditions });
        cur = s.co2;
        s.family.forEach(function (m, i) {
          var f = function (c) { return P.net(m.L, { plant: cond.plant, co2: c, temp: cond.temp, mg: cond.mg }); };
          curve(ctx, a, f, 0, 1600, FAM[i], i === 1 ? 2.6 : 2, []);
          var cp = P.co2Points(m.L, cond);
          if (cp.comp != null) dot(ctx, a.sx(cp.comp), a.sy(0), 4, FAM[i]);
          if (cp.sat != null && cp.sat < 1600) dot(ctx, a.sx(cp.sat), a.sy(f(cp.sat)), 4, FAM[i]);
          dot(ctx, a.sx(cur), a.sy(f(cur)), 4, FAM[i], true);
        });
        var mid = P.co2Points(s.family[1].L, cond);
        if (mid.comp != null) label(ctx, 'CO₂ 补偿点', a.sx(mid.comp) + 6, a.sy(0) + 14, { align: 'left', size: 11, color: GOLD });
        if (mid.sat != null && mid.sat < 1600) label(ctx, 'CO₂ 饱和点', a.sx(mid.sat), a.sy(P.net(s.family[1].L, { plant: cond.plant, co2: mid.sat, temp: cond.temp, mg: cond.mg })) - 14, { size: 11, color: GOLD });
        // 大气 CO₂ 浓度
        ctx.strokeStyle = 'rgba(255,154,98,.45)'; ctx.setLineDash([4, 4]); ctx.lineWidth = 1;
        ctx.beginPath(); ctx.moveTo(a.sx(400), a.T); ctx.lineTo(a.sx(400), a.B); ctx.stroke(); ctx.setLineDash([]);
        label(ctx, '大气约 400', a.sx(400) + 4, a.T + 8, { align: 'left', size: 11, color: CO2C });
      } else {
        a = axes(ctx, box, { x0: 0, x1: 50, y0: -8, y1: 32, xTicks: ticks(0, 50, narrow ? 10 : 5), yTicks: ticks(-8, 32, 8),
          title: '温度响应', xName: '温度 (°C)', yName: 'mg CO₂/(100 cm²·h)', legend: [['总光合', PHO], ['呼吸', RES], ['净光合', GOLD]] });
        cur = s.T;
        var at = function (T) { return { plant: cond.plant, co2: cond.co2, temp: T, mg: cond.mg }; };
        var gF = function (T) { return P.gross(cond.L, at(T)); }, rF = function (T) { return P.resp(at(T)); };
        var nF = function (T) { return gF(T) - rF(T); }, tp = P.tempPoints(cond.L, cond);
        if (tp.hot != null) {
          ctx.fillStyle = 'rgba(255,122,89,.07)'; ctx.fillRect(a.sx(tp.hot), a.T, a.R - a.sx(tp.hot), a.B - a.T);
          dot(ctx, a.sx(tp.hot), a.sy(0), 4, RES);
          label(ctx, '净光合 < 0', a.sx(tp.hot) - 6, a.sy(0) + 18, { align: 'right', size: 11, color: RES });
        }
        curve(ctx, a, gF, 0, 50, PHO, 2.2, []);
        curve(ctx, a, rF, 0, 50, RES, 2.2, []);
        curve(ctx, a, nF, 0, 50, GOLD, 2.6, []);
        [[tp.gOpt, gF, PHO, '光合最适 ' + tp.gOpt + ' °C', -14], [tp.rOpt, rF, RES, '呼吸最适 ' + tp.rOpt + ' °C', -14], [tp.nOpt, nF, GOLD, '净光合最适 ' + fmt(tp.nOpt) + ' °C', 16]].forEach(function (q) {
          var x = a.sx(q[0]), y = a.sy(q[1](q[0]));
          vguide(ctx, a, x, y, q[2].length === 7 ? q[2] + '88' : q[2]);
          dot(ctx, x, y, 4, q[2]);
          if (!narrow) label(ctx, q[3], P.clamp(x, a.L + 54, a.R - 54), y + q[4], { size: 11, color: q[2] });
        });
        dot(ctx, a.sx(cur), a.sy(gF(cur)), 4, PHO, true); dot(ctx, a.sx(cur), a.sy(rF(cur)), 4, RES, true); dot(ctx, a.sx(cur), a.sy(nF(cur)), 4, GOLD, true);
      }
      geo.plot = a;
      var px = a.sx(cur);
      ctx.strokeStyle = 'rgba(230,235,242,.45)'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(px, a.T - 4); ctx.lineTo(px, a.B); ctx.stroke();
    }

    // ===== 场景三：夏季一昼夜 =====
    // 左：天空与太阳、一个气孔（开放程度）、进出气孔的 CO₂；右上：净光合速率（正负面积）；右下：有机物积累量
    function stomaView(ctx, c, s) {
      var day = c.L > 0, lum = Math.min(1, c.L / 60);
      ctx.save();
      rrect(ctx, 0, 0, 300, 106, 11); ctx.clip();
      var sky = ctx.createLinearGradient(0, 0, 0, 106);
      sky.addColorStop(0, day ? (s.weather === 'cloudy' ? '#3b5368' : '#254c73') : '#101a31');
      sky.addColorStop(1, day ? (s.weather === 'cloudy' ? '#738e96' : '#679aa1') : '#182939');
      ctx.fillStyle = sky; ctx.fillRect(0, 0, 300, 106);
      if (day) {
        var an = Math.PI * (1 - (c.t - P.DAY.RISE) / (P.DAY.SET - P.DAY.RISE));
        sun(ctx, 160 + Math.cos(an) * 119, 82 - Math.sin(an) * 43, s.weather === 'cloudy' ? 7 : 9, lum);
      } else {
        [[128, 27], [173, 52], [197, 21], [254, 47], [268, 17]].forEach(function (p) { dot(ctx, p[0], p[1], 1, '#8dabc2'); });
      }
      if (s.weather === 'cloudy' && day) {
        ctx.fillStyle = 'rgba(196,218,222,.46)';
        [[78, 52, 59], [170, 33, 50], [239, 58, 56]].forEach(function (p) {
          ctx.beginPath(); ctx.ellipse(p[0], p[1], p[2], 7, 0, 0, 7); ctx.fill();
          ctx.beginPath(); ctx.ellipse(p[0] - 15, p[1] - 4, p[2] * 0.61, 9, 0, 0, 7); ctx.fill();
        });
      }
      ctx.fillStyle = day ? '#325b52' : '#1c3537';
      ctx.beginPath(); ctx.moveTo(0, 89); ctx.bezierCurveTo(55, 58, 95, 97, 161, 88);
      ctx.bezierCurveTo(207, 85, 240, 57, 300, 83); ctx.lineTo(300, 106); ctx.lineTo(0, 106); ctx.fill();
      ctx.fillStyle = day ? '#254839' : '#142b2c';
      ctx.beginPath(); ctx.moveTo(0, 101); ctx.bezierCurveTo(91, 72, 116, 106, 201, 96);
      ctx.quadraticCurveTo(246, 85, 300, 95); ctx.lineTo(300, 106); ctx.lineTo(0, 106); ctx.fill();
      ctx.restore();
      label(ctx, hm(c.t), 14, 16, { align: 'left', size: 16, bold: true });
      label(ctx, fmt(c.T, 1) + ' °C  ·  ' + (day ? fmt(c.L) + ' klx' : '无光'), 286, 16, { align: 'right', size: 11 });

      // 叶表皮俯视，两个保卫细胞围出的开口随开放程度变化。
      ctx.save(); rrect(ctx, 0, 106, 300, 144, 10); ctx.clip();
      var tissue = ctx.createRadialGradient(150, 176, 15, 150, 176, 158);
      tissue.addColorStop(0, '#305742'); tissue.addColorStop(1, '#142929');
      ctx.fillStyle = tissue; ctx.fillRect(0, 106, 300, 144);
      ctx.strokeStyle = '#4a715c'; ctx.lineWidth = 1.3;
      for (var i = -1; i <= 5; i++) {
        var x = i * 56;
        ctx.beginPath(); ctx.moveTo(x, 106); ctx.bezierCurveTo(x - 19, 139, x + 34, 132, x + 12, 169);
        ctx.bezierCurveTo(x - 10, 202, x + 28, 218, x + 14, 253); ctx.stroke();
      }
      [144, 202].forEach(function (y) {
        ctx.beginPath(); ctx.moveTo(0, y);
        for (var x = 0; x < 300; x += 60) ctx.bezierCurveTo(x + 15, y - 24, x + 41, y + 24, x + 60, y);
        ctx.stroke();
      });
      ctx.restore();

      var x0 = 144, y0 = 173, open = c.open, gap = 2 + 16 * open;
      ctx.save(); ctx.translate(x0, y0);
      ctx.fillStyle = '#0a1919'; ctx.beginPath(); ctx.ellipse(0, 0, gap, 31, 0, 0, 7); ctx.fill();
      [-1, 1].forEach(function (sd) {
        ctx.save(); ctx.scale(sd, 1);
        var guard = ctx.createLinearGradient(0, 5, 54, -12);
        guard.addColorStop(0, '#97ba72'); guard.addColorStop(0.55, '#6b9d60'); guard.addColorStop(1, '#305e4a');
        ctx.beginPath(); ctx.moveTo(1, -39);
        ctx.bezierCurveTo(61, -41, 61, 41, 1, 39);
        ctx.bezierCurveTo(gap * 1.35, 20, gap * 1.35, -20, 1, -39);
        ctx.fillStyle = guard; ctx.fill();
        ctx.strokeStyle = '#a2c58b'; ctx.lineWidth = 1.5; ctx.stroke();
        [[15, -27], [31, -16], [37, 2], [31, 18], [16, 27]].forEach(function (p) {
          ctx.fillStyle = '#345e40'; ctx.beginPath(); ctx.ellipse(p[0], p[1], 4.5, 2.3, p[1] * 0.026, 0, 7); ctx.fill();
        });
        ctx.restore();
      });
      ctx.restore();
      var n = c.net;
      if (Math.abs(n) > 0.3) {
        var wv = 1.2 + 3 * Math.sqrt(Math.min(1, Math.abs(n) / 18));
        if (n > 0) arrow(ctx, 217, 123, x0 + 2, y0 - 5, 8, CO2C, wv);
        else arrow(ctx, x0 + 2, y0 - 5, 217, 123, 8, CO2C, wv);
        label(ctx, (n > 0 ? '吸收' : '释放') + ' CO₂', 283, 125, { align: 'right', size: 11, color: CO2C });
      }
      label(ctx, '气孔开放 ' + Math.round(open * 100) + '%', x0, 233, { size: 13, bold: true, color: c.g < 0.8 ? GOLD : day ? PHO : TEXT });
    }
    function drawDay(s) {
      begin();
      var sp = split(true), ser = s.series, c = P.sampleAt(ser, s.t), keys = s.keys;
      diagram(sp.a, 250, function () { stomaView(ctx, c, s); });

      var B = sp.b, h1 = Math.round(B.h * 0.54);
      var box1 = { x: B.x, y: B.y, w: B.w, h: h1 - 5 }, box2 = { x: B.x, y: B.y + h1 + 5, w: B.w, h: B.h - h1 - 5 };
      var xt = narrow ? [0, 6, 12, 18, 24] : [0, 3, 6, 9, 12, 15, 18, 21, 24], xf = function (v) { return v + '时'; };
      var a1 = axes(ctx, box1, { x0: 0, x1: 24, y0: -6, y1: 22, xTicks: xt, xFmt: xf, yTicks: ticks(-6, 22, narrow ? 8 : 4), title: '净光合速率', yName: 'mg/(100 cm²·h)' });
      var accMax = Math.max(40, Math.ceil(keys.accMax.acc / 40) * 40 + 20), accMin = -40;
      var a2 = axes(ctx, box2, { x0: 0, x1: 24, y0: accMin, y1: accMax, xTicks: xt, xFmt: xf, yTicks: ticks(accMin, accMax, accMax > 100 ? (narrow ? 80 : 40) : 20), title: '有机物积累量（以 CO₂ 计）', yName: 'mg/100 cm²' });
      geo = { scene: 'day', plots: [a1, a2] };
      [a1, a2].forEach(function (a) {
        ctx.fillStyle = 'rgba(0,0,0,.28)';
        ctx.fillRect(a.sx(0), a.T, a.sx(P.DAY.RISE) - a.sx(0), a.B - a.T);
        ctx.fillRect(a.sx(P.DAY.SET), a.T, a.sx(24) - a.sx(P.DAY.SET), a.B - a.T);
      });
      // 正面积（有机物积累）、负面积（消耗），只填到当前时刻
      var z = a1.sy(0);
      for (var i = 1; i < ser.length; i++) {
        var p0 = ser[i - 1], p1 = ser[i];
        if (p1.t > s.t + 1e-9) break;
        var m = (p0.net + p1.net) / 2;
        ctx.fillStyle = m > 0 ? 'rgba(126,224,129,.22)' : 'rgba(255,122,89,.22)';
        ctx.beginPath(); ctx.moveTo(a1.sx(p0.t), z); ctx.lineTo(a1.sx(p0.t), a1.sy(p0.net)); ctx.lineTo(a1.sx(p1.t), a1.sy(p1.net)); ctx.lineTo(a1.sx(p1.t), z); ctx.closePath(); ctx.fill();
      }
      function line(a, key, color, width, upto) {
        ctx.strokeStyle = color; ctx.lineWidth = width; ctx.setLineDash([]);
        ctx.beginPath();
        for (var i = 0; i < ser.length; i++) {
          var p = ser[i];
          if (p.t > upto + 1e-9) break;
          if (i) ctx.lineTo(a.sx(p.t), a.sy(p[key])); else ctx.moveTo(a.sx(p.t), a.sy(p[key]));
        }
        ctx.stroke();
      }
      ctx.globalAlpha = 0.22; line(a1, 'net', GOLD, 1.5, 24); line(a2, 'acc', PHO, 1.5, 24); ctx.globalAlpha = 1;
      line(a1, 'net', GOLD, 2.6, s.t); line(a2, 'acc', PHO, 2.4, s.t);
      // 关键点
      var marks = [];
      if (!narrow) marks.push({ t: P.DAY.RISE, y: P.sampleAt(ser, P.DAY.RISE).net, txt: '开始光合', dy: 14, al: 'left', dx: 4 });
      var tight = a1.R - a1.L < 620;   // 窄屏两处“光合 = 呼吸”会撞在一起：只写时刻
      keys.cross.forEach(function (kp) { marks.push({ t: kp.t, y: 0, txt: (tight ? '' : '光合 = 呼吸 ') + hm(kp.t), dy: -12, al: kp.up ? 'left' : 'right', dx: kp.up ? 6 : -6 }); });
      if (keys.dip && keys.dip.g < 0.8) marks.push({ t: keys.dip.t, y: keys.dip.net, txt: '“午休” ' + hm(keys.dip.t), dy: 15, al: 'center', dx: 0 });
      if (!narrow) marks.push({ t: P.DAY.SET, y: P.sampleAt(ser, P.DAY.SET).net, txt: '光合停止', dy: 14, al: 'left', dx: 4 });
      marks.forEach(function (mk) {
        if (mk.t > s.t + 1e-6) return;
        dot(ctx, a1.sx(mk.t), a1.sy(mk.y), 4, GOLD);
        label(ctx, mk.txt, a1.sx(mk.t) + mk.dx, a1.sy(mk.y) + mk.dy, { align: mk.al, size: 11, color: GOLD });
      });
      if (s.t >= keys.accMax.t) {
        var am = keys.accMax;
        dot(ctx, a2.sx(am.t), a2.sy(am.acc), 4.5, PHO);
        label(ctx, '积累最多 ' + hm(am.t), P.clamp(a2.sx(am.t), a2.L + 51, a2.R - 51), a2.sy(am.acc) + 15, { size: 11, color: PHO });
      }
      // 时间指针
      [a1, a2].forEach(function (a) {
        var x = a.sx(s.t);
        ctx.strokeStyle = 'rgba(230,235,242,.55)'; ctx.lineWidth = 1;
        ctx.beginPath(); ctx.moveTo(x, a.T - 4); ctx.lineTo(x, a.B); ctx.stroke();
      });
      marker(ctx, a1.sx(s.t), a1.sy(c.net), TEXT);
      marker(ctx, a2.sx(s.t), a2.sy(c.acc), TEXT);
    }

    return {
      resize: resize, drawLight: drawLight, drawFactor: drawFactor, drawDay: drawDay,
      geo: function () { return geo; }, narrow: function () { return narrow; }, lightRange: lightRange
    };
  }

  window.PCurveDraw = { View: View, hm: hm };
})();
