(function () {
  var P = window.PCurve, PD = window.PCurveDraw;
  var $ = function (id) { return document.getElementById(id); };
  var qa = function (sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); };
  var NAME = '光合作用曲线';

  var state = {
    scene: 'light',
    // 叶片条件：植物类型、光照 klx、CO₂ ppm、温度 °C、是否缺镁
    plant: 'sun', L: 30, co2: 400, T: 25, mg: true,
    gross: true, compare: false,
    // 多因素：横轴变量、光照为横轴时的另一因素
    xv: 'light', by: 'co2', family: [],
    // 一昼夜
    t: 0, weather: 'sunny', noon: true, playing: !window.matchMedia('(prefers-reduced-motion: reduce)').matches, series: null, keys: null
  };
  var GESTURES = {
    light: '拖动曲线改变光照',
    factor: '拖动曲线移动取样线',
    day: '拖动曲线查看时刻'
  };
  var DAY_SPEED = 1.2;       // 一昼夜：每秒走 1.2 小时
  var RANGE = { L: [0, 70], co2: [100, 1500], T: [5, 45] };

  var visual = $('visual'), panel = $('panel'), cv = $('view');
  var view = PD.View(cv);
  function setSeg(attr, val) {
    qa('[data-' + attr + ']').forEach(function (b) {
      var active = b.dataset[attr] === String(val);
      b.classList.toggle('on', active);
      b.setAttribute('aria-pressed', active);
    });
  }
  function cond() { return { plant: state.plant, co2: state.co2, temp: state.T, mg: state.mg, L: state.L }; }
  function refOn() { return state.co2 !== P.STD.co2 || state.T !== P.STD.temp || !state.mg; }

  // ---------- 场景 ----------
  qa('[data-scene]').forEach(function (b) {
    b.addEventListener('click', function () { setScene(b.dataset.scene); Analytics.track(NAME, '场景', b.textContent); });
  });
  function setScene(sc) {
    state.scene = Object.hasOwn(GESTURES, sc) ? sc : 'light';
    if (state.scene === 'day' && !state.series) setDay();
    syncUI();
  }

  // ---------- 多因素：三条曲线 ----------
  function buildFamily() {
    var base = { plant: state.plant, mg: state.mg };
    function c(o) { return Object.assign({}, base, { co2: state.co2, temp: state.T }, o); }
    if (state.xv === 'light' && state.by === 'temp') {
      state.family = [15, 25, 35].map(function (T) { return { name: T + ' °C', cond: c({ temp: T }) }; });
    } else if (state.xv === 'light') {
      state.family = [200, 400, 1000].map(function (v) { return { name: v + ' ppm', cond: c({ co2: v }) }; });
    } else if (state.xv === 'co2') {
      state.family = [5, 15, 50].map(function (L) { return { name: L + ' klx', L: L }; });
    } else state.family = [];
  }

  // ---------- 一昼夜 ----------
  function setDay() {
    state.series = P.simDay({ weather: state.weather, noon: state.noon, plant: state.plant });
    state.keys = P.dayKeys(state.series);
  }
  function stepDay(dt) {
    if (!state.playing) return;
    state.t = Math.min(24, state.t + dt * DAY_SPEED);
    if (state.t >= 24) { state.playing = false; syncUI(); }
  }

  // ---------- 控件 ----------
  function setVar(key, v) {
    var r = RANGE[key];
    state[key] = P.clamp(v, r[0], r[1]);
  }
  var sliders = [
    { el: $('sL'), key: 'L', out: 'sLOut', fmt: function (v) { return (v < 10 ? v.toFixed(1) : Math.round(v)) + ' klx'; }, name: '光照强度' },
    { el: $('sC'), key: 'co2', out: 'sCOut', fmt: function (v) { return v + ' ppm'; }, name: 'CO₂ 浓度' },
    { el: $('sT'), key: 'T', out: 'sTOut', fmt: function (v) { return v + ' °C'; }, name: '温度' }
  ];
  sliders.forEach(function (s) {
    s.el.addEventListener('input', function () { setVar(s.key, parseFloat(s.el.value)); });
    s.el.addEventListener('change', function () { Analytics.track(NAME, '滑块', s.name + ' ' + s.el.value); });
  });
  qa('[data-plant]').forEach(function (b) {
    b.addEventListener('click', function () {
      state.plant = b.dataset.plant;
      if (state.series) setDay();
      syncUI(); Analytics.track(NAME, '植物', b.textContent);
    });
  });
  $('mg').addEventListener('change', function () { state.mg = !$('mg').checked; Analytics.track(NAME, '开关', state.mg ? '正常' : '缺镁'); });
  $('gross').addEventListener('change', function () { state.gross = $('gross').checked; Analytics.track(NAME, '开关', '总光合' + (state.gross ? '开' : '关')); });
  $('compare').addEventListener('change', function () { state.compare = $('compare').checked; Analytics.track(NAME, '开关', '对比植物' + (state.compare ? '开' : '关')); });
  $('reset').addEventListener('click', function () { state.co2 = P.STD.co2; state.T = P.STD.temp; state.mg = true; syncUI(); Analytics.track(NAME, '恢复参照条件', ''); });
  qa('[data-xv]').forEach(function (b) { b.addEventListener('click', function () { state.xv = b.dataset.xv; syncUI(); Analytics.track(NAME, '横轴', b.textContent); }); });
  qa('[data-by]').forEach(function (b) { b.addEventListener('click', function () { state.by = b.dataset.by; syncUI(); Analytics.track(NAME, '另一因素', b.textContent); }); });

  qa('[data-weather]').forEach(function (b) { b.addEventListener('click', function () { state.weather = b.dataset.weather; setDay(); syncUI(); Analytics.track(NAME, '天气', b.textContent); }); });
  $('noon').addEventListener('change', function () { state.noon = $('noon').checked; setDay(); Analytics.track(NAME, '开关', '午休' + (state.noon ? '开' : '关')); });
  $('dayPlay').addEventListener('click', function () {
    if (state.t >= 24) state.t = 0;
    state.playing = !state.playing; syncUI();
    Analytics.track(NAME, '一昼夜', state.playing ? '播放' : '暂停');
  });
  $('dayRestart').addEventListener('click', function () { state.t = 0; state.playing = true; syncUI(); Analytics.track(NAME, '一昼夜', '从0时开始'); });
  var sTime = $('sTime');
  sTime.addEventListener('input', function () { state.t = parseFloat(sTime.value); state.playing = false; syncUI(); });
  sTime.addEventListener('change', function () { Analytics.track(NAME, '滑块', '时刻'); });

  // ---------- 画布：在曲线上拖动 ----------
  function pos(e) { var r = cv.getBoundingClientRect(); return { x: e.clientX - r.left, y: e.clientY - r.top }; }
  function plotAt(p) {
    var g = view.geo(), list = g.plots || (g.plot ? [g.plot] : []);
    for (var i = 0; i < list.length; i++) { var a = list[i]; if (p.x >= a.L - 8 && p.x <= a.R + 8 && p.y >= a.T - 12 && p.y <= a.B + 12) return a; }
    return null;
  }
  function axisKey() {
    if (state.scene === 'light' || state.xv === 'light') return 'L';
    return state.xv === 'co2' ? 'co2' : 'T';
  }
  // 横坐标 → 当前场景的变量
  function dragTo(a, p) {
    var v = a.x0 + P.clamp((p.x - a.L) / (a.R - a.L), 0, 1) * (a.x1 - a.x0), sc = state.scene;
    if (sc === 'day') { state.t = v; state.playing = false; return; }
    var key = axisKey();
    v = key === 'L' ? (v < 10 ? Math.round(v * 2) / 2 : Math.round(v)) : key === 'co2' ? Math.round(v / 50) * 50 : Math.round(v);
    setVar(key, v);
  }
  var drag = null, pointer = null;
  cv.addEventListener('pointerdown', function (e) {
    if (e.button !== 0 || pointer != null) return;
    var p = pos(e), a = plotAt(p);
    if (!a) return;
    drag = a; pointer = e.pointerId; cv.classList.add('scrubbing'); cv.setPointerCapture(e.pointerId); dragTo(a, p);
    if (state.scene === 'day') syncUI();
    e.preventDefault();
  });
  cv.addEventListener('pointermove', function (e) {
    var p = pos(e);
    if (drag) { if (e.pointerId === pointer) dragTo(drag, p); return; }
    cv.style.cursor = plotAt(p) ? 'col-resize' : 'default';
  });
  function endDrag(e) {
    if (e.pointerId !== pointer) return;
    Analytics.track(NAME, '拖动曲线', state.scene);
    drag = null; pointer = null; cv.classList.remove('scrubbing');
  }
  cv.addEventListener('pointerup', endDrag);
  cv.addEventListener('pointercancel', endDrag);
  cv.addEventListener('lostpointercapture', endDrag);
  cv.addEventListener('keydown', function (e) {
    if (e.key !== 'ArrowLeft' && e.key !== 'ArrowRight') return;
    var dir = e.key === 'ArrowLeft' ? -1 : 1;
    if (state.scene === 'day') {
      state.t = P.clamp(state.t + dir * 0.25, 0, 24);
      state.playing = false; syncUI();
    } else {
      var key = axisKey();
      setVar(key, state[key] + dir * (key === 'co2' ? 50 : key === 'L' ? 0.5 : 1));
    }
    e.preventDefault();
  });

  // ---------- 面板 ----------
  var mobile = window.matchMedia('(max-width: 760px)');
  var panelToggle = $('panelToggle');
  function setPanel(open) {
    panel.classList.toggle('collapsed', !open);
    panelToggle.setAttribute('aria-expanded', open);
  }
  panelToggle.addEventListener('click', function () { setPanel(panel.classList.contains('collapsed')); });
  $('closePanel').addEventListener('click', function () { setPanel(false); panelToggle.focus(); });
  mobile.addEventListener('change', function () { setPanel(!mobile.matches); });
  setPanel(!mobile.matches);
  window.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && mobile.matches && !panel.classList.contains('collapsed')) {
      setPanel(false); panelToggle.focus();
    }
    var tg = e.target.tagName;
    if (tg === 'INPUT' || tg === 'SELECT' || tg === 'BUTTON' || tg === 'TEXTAREA') return;
    if (e.code === 'Space' && state.scene === 'day') { e.preventDefault(); $('dayPlay').click(); }
  });

  function syncUI() {
    var sc = state.scene;
    setSeg('scene', sc);
    qa('[data-for]').forEach(function (el) { el.hidden = el.dataset.for.split(' ').indexOf(sc) < 0; });
    $('byRow').hidden = sc !== 'factor' || state.xv !== 'light';
    $('lightControl').hidden = sc === 'factor' && state.xv === 'co2';
    $('co2Control').hidden = sc === 'factor' && state.xv === 'light' && state.by === 'co2';
    $('tempControl').hidden = sc === 'factor' && state.xv === 'light' && state.by === 'temp';
    $('gesture').textContent = GESTURES[sc];
    cv.setAttribute('aria-label', GESTURES[sc] + '，也可使用左右方向键');
    $('rateUnit').hidden = sc === 'factor';
    setSeg('plant', state.plant); setSeg('xv', state.xv); setSeg('by', state.by); setSeg('weather', state.weather);
    $('mg').checked = !state.mg; $('gross').checked = state.gross; $('compare').checked = state.compare; $('noon').checked = state.noon;
    $('noonRow').hidden = state.weather !== 'sunny';
    $('dayPlay').textContent = state.playing ? '❚❚ 暂停' : state.t >= 24 ? '↻ 再看一天' : '▶ 播放';
    buildFamily();
  }

  // ---------- 读数 ----------
  var lastText = {};
  function setText(id, s) { if (lastText[id] !== s) { lastText[id] = s; $(id).textContent = s; } }
  function rows(list) {
    for (var k = 1; k <= 5; k++) {
      var r = list[k - 1] || ['', ''];
      setText('d' + k, r[0]); setText('r' + k, r[1]);
      $('d' + k).hidden = $('r' + k).hidden = !r[0];
    }
  }
  var U = ' mg/(100 cm²·h)';
  function f1(v) { return (Math.abs(v) < 0.05 ? 0 : v).toFixed(1); }
  function klx(v) { return v == null ? '无' : (v < 10 ? v.toFixed(1) : v.toFixed(0)) + ' klx'; }
  function move(d, pos, neg, eps) { return Math.abs(d) < (eps || 0.05) ? '不变' : d > 0 ? pos : neg; }
  function readLight() {
    var c = cond(), k = P.params(c), g = P.gross(state.L, c), n = g - k.R, pts = P.lightPoints(c);
    setText('rName', '净光合 ' + f1(n));
    setText('rKind', state.L === 0 ? '只有呼吸' : Math.abs(n) <= 0.05 ? '接近补偿点' : n < 0 ? '光合 < 呼吸' : state.L >= pts.sat ? '已达光饱和' : '光合 > 呼吸');
    var tip;
    if (refOn()) {
      var rc = { plant: c.plant, co2: P.STD.co2, temp: P.STD.temp, mg: true }, rp = P.lightPoints(rc);
      var why = [];
      if (state.co2 !== P.STD.co2) why.push('CO₂ ' + (state.co2 > P.STD.co2 ? '升高' : '降低'));
      if (state.T !== P.STD.temp) why.push('温度' + (state.T > P.STD.temp ? '升高' : '降低'));
      if (!state.mg) why.push('缺镁');
      tip = why.join('、') + '（与虚线相比）：A 点' + move(rp.k.R - k.R, '上移', '下移') +
        '，B 点' + (pts.comp == null ? '消失（光合始终 < 呼吸）' : move(pts.comp - rp.comp, '右移', '左移', 0.05)) +
        '，C 点' + move(pts.sat - rp.sat, '右移', '左移', 0.2) + '，最大净光合' + move(pts.max - k.R - (rp.max - rp.k.R), '增大', '减小') + '。';
    } else if (state.L === 0) tip = '没有光，叶片只进行细胞呼吸，释放的 CO₂ 量就是呼吸速率（A 点）。';
    else if (n < -0.05) tip = '光照弱于光补偿点：光合作用产生的 O₂ 不够线粒体用，叶片仍从外界吸收 O₂、释放 CO₂。';
    else if (Math.abs(n) <= 0.05) tip = '光补偿点：叶绿体固定的 CO₂ 接近线粒体放出的量，叶片与外界的净气体交换接近零。';
    else if (state.L < pts.sat) tip = '光补偿点与光饱和点之间：光照越强，光合速率越大，限制因素主要是光照强度。';
    else tip = '超过光饱和点：再增强光照，光合速率增长趋缓，主要限制因素变为 CO₂ 浓度、温度等（以及色素、酶的数量）。';
    setText('rTip', tip);
    rows([
      ['总光合速率', f1(g) + '（= 净 + 呼吸，CO₂ 固定量）'],
      ['呼吸速率', f1(k.R) + '（黑暗中 CO₂ 释放量）'],
      ['净光合速率', f1(n) + '（CO₂ 吸收量）'],
      ['光补偿点 B', klx(pts.comp)],
      ['光饱和点 C', klx(pts.sat) + '（此时净光合 ' + f1(pts.max - k.R) + '）']
    ]);
  }
  function readFactor() {
    var c = cond(), xv = state.xv;
    if (xv === 'light') {
      var fam = state.family, nets = fam.map(function (m) { return P.net(state.L, m.cond); });
      var sats = fam.map(function (m) { return P.lightPoints(m.cond).sat; });
      var spread = Math.max.apply(null, nets) - Math.min.apply(null, nets), other = state.by === 'temp' ? '温度' : 'CO₂ 浓度';
      setText('rName', '光照 ' + klx(state.L));
      setText('rKind', state.L < sats[0] * 0.5 ? '限制因素：光照' : state.L >= sats[0] ? '限制因素：' + other : '两者都有影响');
      setText('rTip', state.L < sats[0] * 0.5
        ? '光照较弱，增强光照三条曲线都明显上升：此时限制光合速率的主要是光照强度' + (state.by === 'temp' ? '（温度高时呼吸也强，曲线有一点错开）。' : '，三条线几乎重合。')
        : state.L >= sats[0] ? '光照已经较强，再增加光照曲线变平，而三条曲线高低不同：此时限制光合速率的主要是' + other + '。'
        : '光照增强，光合速率还在上升，但三条曲线已经分开：光照强度和' + other + '共同限制光合速率。');
      rows(fam.map(function (m, i) { return [m.name, '净光合 ' + f1(nets[i]) + '，光饱和点 ' + klx(sats[i])]; }).concat([['三线高差', f1(spread) + U]]));
    } else if (xv === 'co2') {
      setText('rName', 'CO₂ 浓度 ' + state.co2 + ' ppm');
      var cps = state.family.map(function (m) { return P.co2Points(m.L, c); });
      var cr = cps.map(function (cp, i) { return P.net(state.family[i].L, c); });
      setText('rKind', state.co2 < (cps[1].comp || 0) ? '低于 CO₂ 补偿点' : '');
      setText('rTip', '光照越强，CO₂ 补偿点越低、CO₂ 饱和点越高；大棚增施 CO₂（“气肥”）要配合足够的光照才有效。CO₂ 低于补偿点时，叶片净释放 CO₂。');
      rows(state.family.map(function (m, i) {
        return [m.name, '净光合 ' + f1(cr[i]) + '，补偿点 ' + (cps[i].comp == null ? '—' : Math.round(cps[i].comp) + ' ppm') + '，饱和点 ' + (cps[i].sat == null ? '—' : Math.round(cps[i].sat) + ' ppm')];
      }).concat([['温度', state.T + ' °C（面板里调）']]));
    } else {
      var g = P.gross(state.L, c), r = P.resp(c), tp = P.tempPoints(state.L, c);
      setText('rName', '温度 ' + state.T + ' °C');
      setText('rKind', g - r < 0 ? '净光合 < 0' : Math.abs(state.T - tp.nOpt) <= 1 ? '净光合最大' : '');
      setText('rTip', '光合作用的最适温度（' + tp.gOpt + ' °C）比呼吸作用（' + tp.rOpt + ' °C）低，所以净光合速率在 ' + Math.round(tp.nOpt) + ' °C 左右最大；温度再升高，呼吸消耗多而光合减弱，净光合下降' + (tp.hot ? '，约 ' + Math.round(tp.hot) + ' °C 以上降到 0 以下。' : '。'));
      rows([
        ['总光合速率', f1(g) + U],
        ['呼吸速率', f1(r) + U],
        ['净光合速率', f1(g - r) + U],
        ['光照 / CO₂', klx(state.L) + '，' + state.co2 + ' ppm（面板里调）'],
        ['大棚管理', '白天适当升温到净光合最适附近，夜间适当降温减少呼吸消耗']
      ]);
    }
  }
  function readDay() {
    var c = P.sampleAt(state.series, state.t), keys = state.keys, A = P.dayAreas(state.series);
    setText('rName', PD.hm(state.t) + ' · 净光合 ' + f1(c.net));
    setText('rKind', c.P < 0.05 ? '只有呼吸' : Math.abs(c.net) < 0.3 ? '光合 = 呼吸' : c.net < 0 ? '光合 < 呼吸' : c.g < 0.8 ? '“午休”' : '光合 > 呼吸');
    var tip;
    if (c.P < 0.05) tip = '夜间没有光，只进行细胞呼吸，净光合速率为负，有机物在减少。';
    else if (c.net < -0.3) tip = '有光，已经开始光合作用，但光合速率小于呼吸速率，有机物仍在减少。';
    else if (Math.abs(c.net) <= 0.3) tip = '光合速率 = 呼吸速率：' + (state.t < 12 ? '此后有机物开始积累。' : '此时有机物积累量达到一天中的最大值。');
    else if (c.g < 0.8) tip = '中午气温高、光照强、蒸腾作用强，部分气孔关闭，CO₂ 吸收减少，暗反应减弱：C₃ 生成减少、C₅ 消耗减少而增多，净光合速率下降。';
    else if (state.t > 15) tip = '下午光照逐渐减弱，净光合速率下降，但仍大于 0，有机物继续积累。';
    else tip = '光合速率大于呼吸速率，叶片从外界吸收 CO₂，有机物积累。';
    setText('rTip', tip);
    rows([
      ['光照 / 温度', (c.L > 0 ? klx(c.L) : '无光') + '，' + c.T.toFixed(1) + ' °C，气孔开放 ' + Math.round(c.open * 100) + '%'],
      ['总光合 / 呼吸', f1(c.P) + ' / ' + f1(c.R) + U],
      ['光合 = 呼吸', keys.cross.map(function (k) { return PD.hm(k.t); }).join('、') + '（积累最多在 ' + PD.hm(keys.accMax.t) + '）'],
      ['有机物积累', (c.acc >= 0 ? '+' : '') + c.acc.toFixed(1) + ' mg/100 cm²（从 0 时算）'],
      ['全天', '白天净积累 ' + A.pos.toFixed(0) + ' − 消耗 ' + A.neg.toFixed(0) + ' = ' + (A.pos - A.neg).toFixed(0)]
    ]);
  }

  // ---------- 尺寸与主循环 ----------
  var sizeVersion = 0;
  function resize() {
    view.resize(visual.clientWidth, visual.clientHeight);
    sizeVersion++;
  }
  resize();
  new ResizeObserver(resize).observe(visual);

  // 支持 ?scene=light|factor|day
  // 通用：&plant=sun|shade、&L=0~70（klx）、&co2=100~1500（ppm）、&temp=5~45（°C）、&mg=0（缺镁）
  // 光照曲线：&gross=0、&compare=1；多因素：&x=light|co2|temp、&by=co2|temp
  // 一昼夜：&t=0~24、&weather=sunny|cloudy、&noon=0、&play=0
  var qs = new URLSearchParams(location.search);
  function num(k, lo, hi) { var x = parseFloat(qs.get(k)); return isFinite(x) && x >= lo && x <= hi ? x : null; }
  var x;
  if (Object.hasOwn(GESTURES, qs.get('scene'))) state.scene = qs.get('scene');
  if (Object.hasOwn(P.PLANTS, qs.get('plant'))) state.plant = qs.get('plant');
  if ((x = num('L', 0, 70)) != null) state.L = x;
  if ((x = num('co2', 100, 1500)) != null) state.co2 = Math.round(x / 50) * 50;
  if ((x = num('temp', 5, 45)) != null) state.T = Math.round(x);
  if (qs.get('mg') === '0') state.mg = false;
  if (qs.get('gross') === '0') state.gross = false;
  if (qs.get('compare') === '1') state.compare = true;
  if (['light', 'co2', 'temp'].indexOf(qs.get('x')) >= 0) state.xv = qs.get('x');
  if (qs.get('by') === 'temp') state.by = 'temp';
  if (qs.get('weather') === 'cloudy') state.weather = 'cloudy';
  if (qs.get('noon') === '0') state.noon = false;

  resize();
  setScene(state.scene);
  if (state.scene === 'day') {
    if ((x = num('t', 0, 24)) != null) state.t = x;
    if (qs.has('play')) state.playing = qs.get('play') !== '0';
    if (state.t >= 24) state.playing = false;
    syncUI();
  }

  var lastT = performance.now(), lastDraw = '';
  function frame(now) {
    var dt = Math.min((now - lastT) / 1000, 0.1), sc = state.scene;
    lastT = now;
    if (sc === 'day') stepDay(dt);
    var axMax = drag && sc === 'light' ? drag.x1 : null;
    var key = [sizeVersion, sc, state.plant, state.L, state.co2, state.T, state.mg, state.gross, state.compare,
      state.xv, state.by, state.t, state.weather, state.noon, axMax].join();
    requestAnimationFrame(frame);
    if (key === lastDraw) return;
    lastDraw = key;
    sliders.forEach(function (s) {
      var v = state[s.key];
      s.el.value = v;
      setText(s.out, s.fmt(v));
    });
    sTime.value = state.t;
    setText('sTimeOut', PD.hm(state.t));
    if (sc === 'factor') buildFamily();
    if (sc === 'light') {
      view.drawLight({ cond: cond(), L: state.L, plant: state.plant, gross: state.gross, compare: state.compare, refOn: refOn(), axMax: axMax });
      readLight();
    } else if (sc === 'factor') {
      view.drawFactor({ cond: cond(), L: state.L, co2: state.co2, T: state.T, xv: state.xv, by: state.by, family: state.family });
      readFactor();
    } else {
      view.drawDay(state);
      readDay();
    }
  }
  requestAnimationFrame(frame);

  // 调试用
  window.__model = {
    state: state, geo: view.geo, setScene: setScene, syncUI: syncUI, setDay: setDay,
    setL: function (v) { setVar('L', v); }, setCO2: function (v) { setVar('co2', v); }, setT: function (v) { setVar('T', v); },
    // 一昼夜按固定步长推进 sec 秒（录屏用）
    step: function (sec) { for (var t = 0; t < sec; t += 0.02) stepDay(0.02); }
  };
})();
