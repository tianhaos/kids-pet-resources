// 光合作用曲线：计算模块（不碰 DOM）
// 速率模型是教学示意：光响应用非直角双曲线（θ 接近 1，拐弯明显），CO₂ 响应同型并带 CO₂ 补偿浓度以下不能固定 CO₂；
// 温度：光合作用最适 25 °C、呼吸作用最适 30 °C（两侧不对称钟形）。
// 单位：光照强度 klx，CO₂ 浓度 ppm（μmol/mol），温度 °C，速率 mg CO₂/(100 cm²·h)（叶片 CO₂ 吸收或释放量）
(function () {
  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }

  // 非直角双曲线：h(0) = 0，h(∞) = 1，起始斜率 1；θ 越接近 1，拐弯越“方”
  function hyp(x, th) {
    if (x <= 0) return 0;
    var s = x + 1;
    return (s - Math.sqrt(Math.max(0, s * s - 4 * th * x))) / (2 * th);
  }
  // 反函数：h(x) = y 时的 x（0 ≤ y < 1）
  function hypInv(y, th) { return y <= 0 ? 0 : y >= 1 ? Infinity : y * (1 - th * y) / (1 - y); }

  var TH_L = 0.95, TH_C = 0.9;
  var GAMMA = 50, KC = 345;        // CO₂ 低于 50 ppm 不能固定 CO₂；约 1000 ppm 时达到 95%
  var SAT = 0.95;                  // 饱和点：总光合速率达到最大值的 95% 时
  var T_P = 25, T_R = 30;          // 光合作用、呼吸作用的最适温度

  // 两种植物（总光合的最大值 PMAX 指 CO₂、温度都最适时；PHI 弱光下每 klx 的总光合；R25 为 25 °C 的呼吸速率）
  var PLANTS = {
    sun: { name: '阳生植物', PMAX: 30, PHI: 1.0, R25: 4 },
    shade: { name: '阴生植物', PMAX: 10, PHI: 1.3, R25: 1 }
  };
  var MG_LOW = 0.55;               // 缺镁：叶绿素合成受阻，光合能力打折
  var STD = { co2: 400, temp: 25, mg: true };   // 参照条件

  function fC(c) { return hyp(Math.max(0, c - GAMMA) / KC, TH_C); }
  function fTP(T) { return Math.exp(-Math.pow((T - T_P) / (T < T_P ? 13 : 11), 2)); }
  function gR(T) { return Math.exp(-Math.pow((T - T_R) / (T < T_R ? 15 : 14), 2)); }

  function plantOf(p) { return PLANTS[p] || PLANTS.sun; }
  // 条件 cond = { plant, co2, temp, mg }；返回该条件下光响应曲线的参数
  function params(cond) {
    var pl = plantOf(cond.plant), f = fC(cond.co2) * fTP(cond.temp) * (cond.mg === false ? MG_LOW : 1);
    return { Pm: pl.PMAX * f, phi: pl.PHI * Math.sqrt(f), R: pl.R25 * gR(cond.temp) / gR(25) };
  }
  // 总光合速率（真正光合速率）
  function gross(L, cond, k) {
    k = k || params(cond);
    if (k.Pm <= 0 || L <= 0) return 0;
    return k.Pm * hyp(k.phi * L / k.Pm, TH_L);
  }
  function resp(cond) { return params(cond).R; }
  function net(L, cond) { var k = params(cond); return gross(L, cond, k) - k.R; }
  // 光补偿点、光饱和点（klx）；总光合到不了呼吸速率时没有补偿点（返回 null）
  function lightPoints(cond) {
    var k = params(cond);
    if (k.Pm <= 0) return { comp: null, sat: null, k: k };
    var u = k.Pm / k.phi;
    return { comp: k.R < k.Pm ? u * hypInv(k.R / k.Pm, TH_L) : null, sat: u * hypInv(SAT, TH_L), max: k.Pm * SAT, k: k };
  }

  // 单调函数 f(x) 在 [a, b] 上取值 y 的位置（二分）
  function solve(f, y, a, b) {
    var fa = f(a) - y, fb = f(b) - y;
    if (fa * fb > 0) return null;
    for (var i = 0; i < 60; i++) {
      var m = (a + b) / 2, fm = f(m) - y;
      if (fa * fm <= 0) { b = m; } else { a = m; fa = fm; }
    }
    return (a + b) / 2;
  }
  // CO₂ 响应：光照 L、温度 T 下，CO₂ 补偿点（净光合 = 0）和 CO₂ 饱和点（总光合达到 CO₂ 无限充足时的 95%）
  var C_RANGE = [0, 1600];
  function co2Points(L, cond) {
    var at = function (c) { return gross(L, { plant: cond.plant, co2: c, temp: cond.temp, mg: cond.mg }); };
    var R = resp(cond), top = gross(L, { plant: cond.plant, co2: 1e7, temp: cond.temp, mg: cond.mg });
    return { comp: solve(at, R, GAMMA, 1e5), sat: solve(at, top * SAT, GAMMA, 1e5), top: top, R: R };
  }
  // 温度曲线上的关键温度：总光合最适、净光合最适、净光合降到 0 的高温
  function tempPoints(L, cond) {
    var best = { g: -1, n: -1e9 }, tg = 0, tn = 0, hot = null, prev = null;
    for (var T = 0; T <= 50.001; T += 0.05) {
      var c = { plant: cond.plant, co2: cond.co2, temp: T, mg: cond.mg }, g = gross(L, c), n = g - resp(c);
      if (g > best.g) { best.g = g; tg = T; }
      if (n > best.n) { best.n = n; tn = T; }
      if (prev != null && prev > 0 && n <= 0 && T > T_P) hot = T;
      prev = n;
    }
    return { gOpt: Math.round(tg * 10) / 10, nOpt: Math.round(tn * 10) / 10, rOpt: T_R, hot: hot };
  }

  // ---------- 一昼夜（夏季） ----------
  var DAY = {
    RISE: 6, SET: 18,
    LMAX: { sunny: 70, cloudy: 18 },
    TMID: { sunny: 23, cloudy: 21 }, TAMP: { sunny: 5, cloudy: 2.5 },
    CA: 400,
    NOON: 0.55, NOON_T: 12.5, NOON_W: 1.4      // “午休”：中午部分气孔关闭的程度、时刻、持续宽度
  };
  function dayLight(t, w) {
    if (t <= DAY.RISE || t >= DAY.SET) return 0;
    return (DAY.LMAX[w] || DAY.LMAX.sunny) * Math.sin(Math.PI * (t - DAY.RISE) / (DAY.SET - DAY.RISE));
  }
  function dayTemp(t, w) { w = DAY.TMID[w] ? w : 'sunny'; return DAY.TMID[w] + DAY.TAMP[w] * Math.cos(2 * Math.PI * (t - 14) / 24); }
  // 气孔开放程度 0～1：只有晴天且开启“午休”时中午部分关闭
  function stoma(t, w, noon) {
    if (w !== 'sunny' || !noon) return 1;
    return 1 - DAY.NOON * Math.exp(-Math.pow((t - DAY.NOON_T) / DAY.NOON_W, 2));
  }
  // 预先算出一整天：每 dt 小时一个样本 { t, L, T, g, open, ci, P, R, net, acc }；g 只含“午休”的关闭，open 是画面上显示的开放程度（夜间气孔大多关闭）；acc 为从 0 时起的有机物净积累（以 CO₂ 计，mg/100 cm²）
  function simDay(o) {
    o = o || {};
    var w = o.weather === 'cloudy' ? 'cloudy' : 'sunny', dt = o.dt || 0.05, n = Math.round(24 / dt), out = [], acc = 0;
    for (var i = 0; i <= n; i++) {
      var t = i * dt, L = dayLight(t, w), T = dayTemp(t, w), g = stoma(t, w, o.noon !== false);
      var ci = GAMMA + (DAY.CA - GAMMA) * g, c = { plant: o.plant, co2: ci, temp: T, mg: true };
      var P = gross(L, c), R = resp(c);
      if (i) acc += (P - R + out[i - 1].net) / 2 * dt;
      out.push({ t: t, L: L, T: T, g: g, open: g * (0.2 + 0.8 * clamp(L / 8, 0, 1)), ci: ci, P: P, R: R, net: P - R, acc: acc });
    }
    return out;
  }
  // 关键时刻：净光合由负变正、由正变负（光合 = 呼吸），中午低谷（午休），一天中净光合最大
  function dayKeys(ser) {
    var cross = [], dip = null, peaks = [];
    for (var i = 1; i < ser.length; i++) {
      var a = ser[i - 1], b = ser[i];
      if ((a.net <= 0) !== (b.net <= 0)) {
        var f = a.net / (a.net - b.net);
        cross.push({ t: a.t + (b.t - a.t) * f, up: b.net > 0 });
      }
      if (i < ser.length - 1) {
        var c = ser[i + 1];
        if (b.L > 0 && b.net > a.net && b.net >= c.net) peaks.push(b);
        if (b.L > 0 && b.net < a.net && b.net <= c.net && b.t > 9 && b.t < 16) dip = b;
      }
    }
    var acc = ser.reduce(function (m, s) { return s.acc > m.acc ? s : m; }, ser[0]);
    return { cross: cross, dip: dip, peaks: peaks, accMax: acc, end: ser[ser.length - 1] };
  }
  // 正、负面积：白天净积累 S₂ 与夜间（含清晨、傍晚光合 < 呼吸的时段）消耗 S₁ + S₃
  function dayAreas(ser) {
    var pos = 0, neg = 0;
    for (var i = 1; i < ser.length; i++) {
      var m = (ser[i].net + ser[i - 1].net) / 2 * (ser[i].t - ser[i - 1].t);
      if (m > 0) pos += m; else neg -= m;
    }
    return { pos: pos, neg: neg };
  }
  function sampleAt(ser, t) {
    var dt = ser[1].t - ser[0].t, i = clamp(Math.floor(t / dt), 0, ser.length - 2), f = clamp((t - ser[i].t) / dt, 0, 1);
    var a = ser[i], b = ser[i + 1], o = {};
    Object.keys(a).forEach(function (k) { o[k] = a[k] + (b[k] - a[k]) * f; });
    return o;
  }

  window.PCurve = {
    clamp: clamp, hyp: hyp, hypInv: hypInv, TH_L: TH_L, SAT: SAT, GAMMA: GAMMA, T_P: T_P, T_R: T_R,
    PLANTS: PLANTS, STD: STD, MG_LOW: MG_LOW, C_RANGE: C_RANGE,
    fC: fC, fTP: fTP, gR: gR, params: params, gross: gross, resp: resp, net: net,
    lightPoints: lightPoints, co2Points: co2Points, tempPoints: tempPoints, solve: solve,
    DAY: DAY, dayLight: dayLight, dayTemp: dayTemp, stoma: stoma, simDay: simDay, dayKeys: dayKeys, dayAreas: dayAreas, sampleAt: sampleAt
  };
})();
