(function () {
  var P = window.Periodic, D = window.PeriodicDraw;
  var $ = function (id) { return document.getElementById(id); };
  var qa = function (sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); };
  var NAME = '元素周期表与周期律';

  var state = {
    prop: 'radius',
    sel: P.BYSYM['Na'],
    seriesKind: 'period',
    hover: null,
    quiz: null, answered: false, choice: false, score: { n: 0, ok: 0 }
  };

  var stage = $('stage'), panel = $('panel'), cv = $('view');
  var view = D.View(cv);
  var dirty = true;

  function seriesKey() { return state.seriesKind === 'period' ? state.sel.p : state.sel.g; }
  function seriesLabel() { return P.seriesLabel(state.seriesKind, seriesKey()); }

  // ---------- 选择 ----------
  function selectEl(e, opts) {
    if (!e) return;
    state.sel = e;
    if (opts && opts.kind) state.seriesKind = opts.kind;
    syncAll();
    view.ensureVisible(e);
    dirty = true;
  }
  function pickOf(kind, key) {
    var list = P.series(kind, key);
    var withVal = list.filter(function (e) { return P.val(e, state.prop) != null; });
    return (withVal[0] || list[0]);
  }
  function selectPeriod(p) {
    if (!(p >= 1 && p <= 7)) return;
    var e = pickOf('period', p);
    if (e) { selectEl(e, { kind: 'period' }); Analytics.track(NAME, '选周期', P.periodName(p)); }
  }
  function selectGroup(g) {
    if (!(g >= 1 && g <= 18)) return;
    var e = pickOf('group', g);
    if (e) { selectEl(e, { kind: 'group' }); Analytics.track(NAME, '选族', P.groupName(g) + '族'); }
  }

  // ---------- 面板 ----------
  var last = {};
  function setText(id, t) { if (last[id] !== t) { last[id] = t; $(id).textContent = t; } }
  function shortVal(e) {
    if (state.prop === 'cat') return '';
    var v = P.val(e, state.prop);
    return v == null ? '—' : P.fmtNum(v, state.prop);
  }

  function syncAll() {
    var e = state.sel, prop = P.PMAP[state.prop], cat = P.CAT[e.cat];
    state.seriesKey = seriesKey();
    setText('rSym', e.sym); setText('rName', e.name); setText('rCat', cat.name);
    $('rCat').style.color = cat.c; $('rCat').style.borderColor = cat.c;
    setText('rZ', String(e.z));
    setText('rPG', P.periodName(e.p) + ' · ' + P.groupName(e.g) + '族' + (e.f ? (e.f === 'lan' ? '（镧系）' : '（锕系）') : ''));
    setText('rShells', e.sh.length + ' 层');
    setText('rConfig', e.sh.join(', '));
    setText('rOuter', String(e.sh[e.sh.length - 1]) + ' 个');
    setText('rBlock', blockName(e));
    setText('rRadius', P.fmt(e, 'radius'));
    setText('rEN', P.fmt(e, 'en'));
    setText('rIE', P.fmt(e, 'ie'));
    var v = P.valence(e);
    $('dtVal').hidden = $('rVal').hidden = !v;
    if (v) {
      if (v.pos == null) setText('rVal', v.note || '—');
      else {
        var s = ['最高 ＋' + v.pos];
        if (v.neg != null) s.push('最低 －' + Math.abs(v.neg));
        setText('rVal', s.join('，'));
      }
    }

    // 这个元素在本周期/本族里的位置（整条曲线的规律写在下面的趋势曲线里）
    var kind = state.seriesKind, key = seriesKey();
    var rk = P.rank(e, kind, key, state.prop), tip;
    if (state.prop === 'cat') {
      tip = '按金属、非金属、准金属、稀有气体着色，颜色只表示分类。';
    } else if (rk && rk.i) {
      var word = rk.i === rk.n ? '最大' : rk.i === 1 ? '最小' : '第 ' + rk.i + ' 小';
      tip = e.sym + ' 的' + prop.name + ' ' + P.fmt(e, state.prop) + '，在' + seriesLabel() + '中' + word + '。';
    } else {
      tip = e.sym + ' 的' + prop.name + '没有收录可靠数据，不参与比较。';
    }
    setText('rTip', tip);

    setText('seriesTitle', seriesLabel() + '（' + P.series(kind, key).length + ' 种元素）');

    // 属性按钮 / 曲线按钮
    qa('[data-prop]').forEach(function (b) { b.classList.toggle('on', b.dataset.prop === state.prop); });
    qa('[data-kind]').forEach(function (b) { b.classList.toggle('on', b.dataset.kind === state.seriesKind); });

    buildLegend();
    buildChips();
    var tr2 = P.trend(kind, key, state.prop);
    setText('trendNote', (tr2 ? tr2.text : '') + (state.prop === 'cat' ? '' : ' ' + P.note(kind, state.prop, key) + '。'));
  }

  function blockName(e) {
    var b = P.block(e);
    var m = { s: 's 区（ⅠA、ⅡA）', p: 'p 区（ⅢA～0 族）', d: 'd 区（ⅢB～Ⅷ族）', ds: 'ds 区（ⅠB、ⅡB）', f: 'f 区（镧系、锕系）' };
    return m[b];
  }

  function buildLegend() {
    var prop = P.PMAP[state.prop], box = $('legend');
    if (prop.kind === 'cat') {
      var keys = Object.keys(P.CAT), html = '<div class="cat-legend">';
      keys.forEach(function (k) {
        html += '<span><i style="background:' + P.CAT[k].c + '"></i>' + P.CAT[k].name + '</span>';
      });
      box.innerHTML = html + '</div>';
    } else {
      box.innerHTML = '<div class="scale"><span>' + prop.min + '</span><i></i><span>' + prop.max + (prop.unit ? ' ' + prop.unit : '') + '</span></div>' +
        '<p class="scale-label">' + prop.name + (prop.unit ? ' / ' + prop.unit : '') + '</p>';
    }
  }

  function buildChips() {
    var kind = state.seriesKind, key = seriesKey();
    var list = P.series(kind, key), html = '';
    list.forEach(function (e) {
      var v = shortVal(e);
      html += '<button class="chip' + (e.z === state.sel.z ? ' on' : '') + '" data-z="' + e.z + '">' +
        e.sym + (v ? '<small>' + v + '</small>' : '') + '</button>';
    });
    var box = $('seriesChips');
    box.innerHTML = html;
    qa('#seriesChips .chip').forEach(function (b) {
      b.addEventListener('click', function () {
        var el = P.BY[+b.dataset.z];
        selectEl(el);
        Analytics.track(NAME, '曲线点选', el.sym);
      });
    });
  }

  // ---------- 练习 ----------
  function pick(a) { return a[Math.floor(Math.random() * a.length)]; }
  function sample(list, n) {
    var a = list.slice(), out = [];
    while (out.length < n && a.length) out.push(a.splice(Math.floor(Math.random() * a.length), 1)[0]);
    return out;
  }
  function uniq(list, key) {
    var seen = {}, out = [];
    list.forEach(function (e) {
      var v = P.val(e, key);
      if (v == null || seen[v] != null) return;
      seen[v] = 1; out.push(e);
    });
    return out;
  }
  function optsOf(list) { return list.map(function (e) { return e.sym + '（' + e.name + '）'; }); }
  function best(list, key, max) {
    return list.reduce(function (a, b) {
      return (max ? P.val(b, key) > P.val(a, key) : P.val(b, key) < P.val(a, key)) ? b : a;
    });
  }

  function makeQuiz() {
    var r = Math.random(), q = null;
    if (r < 0.42) {
      var p = pick([2, 3, 4, 5]);
      var pool = uniq(P.series('period', p).filter(function (e) { return e.r != null; }), 'radius');
      if (pool.length < 4) return makeQuiz();
      var max = Math.random() < 0.5, opts = sample(pool, 4), ans = best(opts, 'radius', max);
      q = {
        prompt: '下列元素中，原子半径' + (max ? '最大' : '最小') + '的是？',
        options: optsOf(opts), answer: ans.sym + '（' + ans.name + '）',
        explain: '同周期从左到右，电子层数相同、核电荷数增大，原子半径逐渐减小。' + P.periodName(p) + '中 ' +
          opts.map(function (e) { return e.sym + ' ' + e.r + ' pm'; }).join('、') + '，所以 ' + ans.sym + ' 的原子半径' + (max ? '最大' : '最小') + '。'
      };
    } else if (r < 0.72) {
      var g = pick([1, 2, 16, 17]);
      var pool2 = uniq(P.series('group', g).filter(function (e) { return e.en != null && e.p >= 2; }), 'en');
      if (pool2.length < 4) return makeQuiz();
      var max2 = Math.random() < 0.5, opts2 = sample(pool2, 4), ans2 = best(opts2, 'en', max2);
      q = {
        prompt: '下列元素中，电负性' + (max2 ? '最大' : '最小') + '的是？',
        options: optsOf(opts2), answer: ans2.sym + '（' + ans2.name + '）',
        explain: (max2 ? '同主族从上到下，电子层数增多、原子半径增大，电负性逐渐减小。' : '同主族从上到下，电子层数增多、原子半径增大，电负性逐渐减小，所以越靠上的元素电负性越大。') +
          P.groupName(g) + '族中 ' + opts2.map(function (e) { return e.sym + ' ' + e.en.toFixed(2); }).join('、') +
          '，所以 ' + ans2.sym + ' 的电负性' + (max2 ? '最大' : '最小') + '。'
      };
    } else {
      var pool3 = uniq(P.ELS.filter(function (e) { return e.en != null && !e.f && e.p >= 2 && e.p <= 4 && e.g <= 17; }), 'en');
      if (pool3.length < 4) return makeQuiz();
      var metal = Math.random() < 0.5, opts3 = sample(pool3, 4), ans3 = best(opts3, 'en', !metal);
      q = {
        prompt: '下列元素中，' + (metal ? '金属性最强' : '非金属性最强') + '的是？',
        options: optsOf(opts3), answer: ans3.sym + '（' + ans3.name + '）',
        explain: '电负性越小，原子在化合物中吸引电子的能力越弱，金属性越强；电负性越大，非金属性越强。' +
          opts3.map(function (e) { return e.sym + ' ' + e.en.toFixed(2); }).join('、') + '，所以 ' + ans3.sym + ' 的' +
          (metal ? '金属性最强' : '非金属性最强') + '。'
      };
    }
    state.quiz = q; state.answered = false; state.choice = false;
    var box = $('quizOpts');
    box.innerHTML = '';
    q.options.forEach(function (o) {
      var b = document.createElement('button');
      b.className = 'small';
      b.textContent = o;
      b.addEventListener('click', function () { answer(o); });
      box.appendChild(b);
    });
    box.classList.toggle('one', q.options.some(function (o) { return o.length > 10; }));
    syncQuiz();
  }
  function answer(o) {
    if (state.answered) return;
    state.answered = true; state.choice = o;
    state.correct = o === state.quiz.answer;
    state.score.n++; if (state.correct) state.score.ok++;
    Analytics.track(NAME, '练习', (state.correct ? '对' : '错'));
    syncQuiz();
  }
  function syncQuiz() {
    var q = state.quiz;
    if (!q) return;
    setText('quizQ', q.prompt);
    qa('#quizOpts button').forEach(function (b) {
      b.disabled = state.answered;
      b.classList.toggle('on', state.answered && b.textContent === q.answer);
      b.classList.toggle('no', state.answered && b.textContent === state.choice && !state.correct);
    });
    var msg = $('quizMsg');
    msg.className = 'quiz-msg' + (state.answered ? (state.correct ? ' ok' : ' bad') : '');
    msg.innerHTML = !state.answered ? '' : (state.correct ? '✓ 答对了。' : '✗ 应选「' + q.answer + '」。') + q.explain;
    setText('quizScore', '答对 ' + state.score.ok + ' / ' + state.score.n);
    $('nextQ').textContent = state.answered ? '下一题 →' : '换一题';
  }

  // ---------- 事件 ----------
  qa('[data-prop]').forEach(function (b) {
    b.addEventListener('click', function () {
      state.prop = b.dataset.prop; dirty = true; syncAll();
      Analytics.track(NAME, '着色属性', P.PMAP[state.prop].name);
    });
  });
  qa('[data-kind]').forEach(function (b) {
    b.addEventListener('click', function () {
      state.seriesKind = b.dataset.kind; dirty = true; syncAll();
      Analytics.track(NAME, '曲线类型', state.seriesKind === 'period' ? '同一周期' : '同一族');
    });
  });
  $('nextQ').addEventListener('click', makeQuiz);

  function handleHit(h) {
    if (!h) return;
    if (h.type === 'el') { selectEl(h.el); Analytics.track(NAME, '选元素', h.el.sym); }
    else if (h.type === 'period') selectPeriod(h.p);
    else if (h.type === 'group') selectGroup(h.g);
    else if (h.type === 'f') selectEl(P.BYSYM[h.f === 'lan' ? 'La' : 'Ac'], { kind: 'period' });
    state.hover = null;
    dirty = true;
  }
  function hitAt(cx, cy) {
    var r = cv.getBoundingClientRect();
    return view.hit(cx - r.left, cy - r.top);
  }
  var drag = null;
  cv.addEventListener('pointerdown', function (e) {
    if (!view.isNarrow()) return;
    drag = { x: e.clientX, y: e.clientY, pan: view.panX(), moved: false };
    try { cv.setPointerCapture(e.pointerId); } catch (err) { }
  });
  cv.addEventListener('pointermove', function (e) {
    if (drag) {
      var dx = e.clientX - drag.x, dy = e.clientY - drag.y;
      if (!drag.moved && Math.abs(dx) > 5 && Math.abs(dx) > Math.abs(dy)) drag.moved = true;
      if (drag.moved && view.setPan(drag.pan + dx)) dirty = true;
      return;
    }
    if (e.pointerType === 'touch') return;
    var h = hitAt(e.clientX, e.clientY);
    var el = h && h.type === 'el' ? h.el : null;
    if ((state.hover && state.hover.z) !== (el && el.z)) { state.hover = el; dirty = true; }
    cv.style.cursor = h ? 'pointer' : 'default';
  });
  cv.addEventListener('pointerup', function (e) {
    if (!drag) return;
    var moved = drag.moved; drag = null;
    if (!moved) handleHit(hitAt(e.clientX, e.clientY));
  });
  cv.addEventListener('pointercancel', function () { drag = null; });
  cv.addEventListener('mouseleave', function () { if (state.hover) { state.hover = null; dirty = true; } });
  cv.addEventListener('click', function (e) {
    if (view.isNarrow()) return;
    handleHit(hitAt(e.clientX, e.clientY));
  });

  $('panelToggle').addEventListener('click', function () { panel.classList.toggle('collapsed'); });
  if (window.matchMedia('(max-width: 760px)').matches) panel.classList.add('collapsed');

  function resize() { view.resize(stage.clientWidth, stage.clientHeight); dirty = true; }
  new ResizeObserver(resize).observe(stage);

  // ---------- 启动 ----------
  var qs = new URLSearchParams(location.search);
  if (P.PMAP[qs.get('prop')]) state.prop = qs.get('prop');
  if (qs.get('chart') === 'group' || qs.get('chart') === 'period') state.seriesKind = qs.get('chart');
  if (P.BYSYM[qs.get('el')]) state.sel = P.BYSYM[qs.get('el')];
  var qp = parseInt(qs.get('period'), 10);
  if (qp >= 1 && qp <= 7) {
    state.seriesKind = 'period';
    var e1 = pickOf('period', qp); if (e1) state.sel = e1;
  }
  var qg = parseInt(qs.get('group'), 10);
  if (qg >= 1 && qg <= 18) {
    state.seriesKind = 'group';
    var e2 = pickOf('group', qg); if (e2) state.sel = e2;
  }

  resize();
  syncAll();
  if (view.ensureVisible(state.sel)) dirty = true;
  if (!state.quiz) makeQuiz();

  function frame() {
    if (dirty) { view.draw(state); dirty = false; }
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  window.__model = {
    state: state, P: P, view: view, selectEl: selectEl, selectPeriod: selectPeriod, selectGroup: selectGroup,
    setProp: function (k) { if (P.PMAP[k]) { state.prop = k; syncAll(); dirty = true; } },
    setKind: function (k) { if (k === 'period' || k === 'group') { state.seriesKind = k; syncAll(); dirty = true; } },
    quiz: function () { return state.quiz; }, answer: answer, newQuiz: makeQuiz
  };
})();
