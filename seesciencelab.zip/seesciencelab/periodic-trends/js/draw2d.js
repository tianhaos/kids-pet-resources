// 2D 绘制：周期表热力图（118 个格子）、选中/悬停、镧系锕系、族与周期标签、下方趋势曲线、悬停提示
// 颜色：数值越大越暖（蓝 → 青 → 绿 → 黄 → 红）；无数据为暗灰格
(function () {
  var P = window.Periodic;
  var TAU = Math.PI * 2;
  var FONT = '-apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", sans-serif';
  var C = {
    text: '#e6ebf2', muted: '#8d99ab', line: '#2a3446', panel: '#111723', panel2: '#1a2231',
    gold: '#ffc94a', blue: '#4fc3f7', dim: 'rgba(255,255,255,.05)'
  };
  // 暖色 = 数值大
  var RAMP = [[0, [38, 96, 142]], [0.32, [79, 195, 247]], [0.58, [126, 224, 129]], [0.8, [255, 201, 74]], [1, [255, 107, 74]]];

  function font(px, w) { return (w ? w + ' ' : '') + px + 'px ' + FONT; }
  function rgb(c, a) { return 'rgba(' + c[0] + ',' + c[1] + ',' + c[2] + ',' + (a == null ? 1 : a) + ')'; }
  function heat(t) {
    for (var i = 1; i < RAMP.length; i++) {
      if (t <= RAMP[i][0]) {
        var a = RAMP[i - 1], b = RAMP[i], u = (t - a[0]) / (b[0] - a[0]);
        return [Math.round(a[1][0] + (b[1][0] - a[1][0]) * u), Math.round(a[1][1] + (b[1][1] - a[1][1]) * u), Math.round(a[1][2] + (b[1][2] - a[1][2]) * u)];
      }
    }
    return RAMP[RAMP.length - 1][1];
  }
  function label(ctx, s, x, y, o) {
    o = o || {};
    ctx.font = font(o.size || 12, o.bold ? 600 : null);
    ctx.textAlign = o.align || 'center'; ctx.textBaseline = o.base || 'middle';
    if (o.stroke !== false) { ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(5,7,13,.8)'; ctx.strokeText(s, x, y); }
    ctx.fillStyle = o.color || C.text; ctx.fillText(s, x, y);
  }
  function rrect(ctx, x, y, w, h, r) {
    r = Math.min(r, w / 2, h / 2);
    ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
  }
  function nice(lo, hi, n) {
    if (!isFinite(lo) || !isFinite(hi)) { lo = 0; hi = 1; }
    if (hi - lo < 1e-9) { hi = lo + 1; }
    var span = hi - lo, step = Math.pow(10, Math.floor(Math.log(span / n) / Math.LN10));
    var err = span / n / step;
    if (err >= 7.5) step *= 10; else if (err >= 3.5) step *= 5; else if (err >= 1.5) step *= 2;
    return { min: Math.floor(lo / step) * step, max: Math.ceil(hi / step) * step, step: step };
  }
  function tickFmt(v, key) {
    if (key === 'en') return v.toFixed(1);
    return String(Math.round(v));
  }

  function View(canvas) {
    var ctx = canvas.getContext('2d');
    var W = 0, H = 0, dpr = 1, narrow = false;
    var G = null, pan = 0;
    var cellHits = [], bandHits = [];
    var NCW = 32, NGAP = 2;      // 窄屏：格子固定大小，整张表可以左右拖动

    function tableWidth() { return 18 * NCW + 17 * NGAP; }
    function clampPan(p) {
      if (!narrow) return 0;
      var tw = tableWidth();
      if (tw <= W - 16) return Math.round((W - tw) / 2 - 8);
      return Math.round(Math.max(W - 16 - tw, Math.min(0, p)));
    }
    function resize(w, h) {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      W = Math.max(1, w); H = Math.max(1, h); narrow = W < 720;
      canvas.width = Math.round(W * dpr); canvas.height = Math.round(H * dpr);
      canvas.style.width = W + 'px'; canvas.style.height = H + 'px';
      pan = clampPan(pan);
      G = null;
    }

    // ---------- 布局 ----------
    function geom() {
      if (G && G.w === W && G.h === H && G.pan === pan) return G;
      var gap, cw, ch, fh, x0, y0, tableW, tableH, chartTop, chartBottom;
      if (narrow) {
        gap = NGAP; cw = NCW; ch = 28; fh = 25;
        x0 = 8 + pan;
        y0 = 51;
        tableW = tableWidth();
        tableH = 7 * (ch + gap) + ch * 0.3 + 2 * (fh + gap) - gap;
        chartTop = y0 + tableH + 14;
        chartBottom = H - 54;
      } else {
        gap = 3;
        var left = 28, top = 44;
        var availW = W - left - 22;
        cw = Math.max(14, (availW - gap * 17) / 18);
        var chartReserve = Math.max(150, Math.min(230, H * 0.27));
        var availH = H - top - 18 - chartReserve - 58;
        var unitH = 7 + 0.3 + 2 * 0.84;
        ch = Math.max(14, Math.min(cw * 0.92, (availH - gap * 8) / unitH));
        fh = ch * 0.84;
        tableW = 18 * cw + gap * 17;
        x0 = left + Math.max(0, (availW - tableW) / 2);
        y0 = top + 17;
        tableH = 7 * (ch + gap) + ch * 0.3 + 2 * (fh + gap) - gap;
        chartTop = y0 + tableH + 26;
        chartBottom = H - 36;
      }
      G = {
        w: W, h: H, pan: pan, gap: gap, cw: cw, ch: ch, fh: fh, x0: x0, y0: y0,
        tableW: tableW, tableH: tableH, bottom: y0 + tableH, chartTop: chartTop, chartBottom: chartBottom,
        narrow: narrow
      };
      return G;
    }
    function cellRect(row, col) {
      var g = G;
      var x = g.x0 + (col - 1) * (g.cw + g.gap), y;
      if (row <= 7) y = g.y0 + (row - 1) * (g.ch + g.gap);
      else y = g.y0 + 7 * (g.ch + g.gap) + g.ch * 0.3 + (row - 8) * (g.fh + g.gap);
      return { x: x, y: y, w: g.cw, h: row <= 7 ? g.ch : g.fh };
    }

    function bg() {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      var gr = ctx.createLinearGradient(0, 0, 0, H);
      gr.addColorStop(0, '#04060c'); gr.addColorStop(1, '#0a1120');
      ctx.fillStyle = gr; ctx.fillRect(0, 0, W, H);
    }

    // ---------- 周期表 ----------
    function drawTable(st) {
      var g = geom(), i;
      cellHits = []; bandHits = [];
      var inSeries = {};
      P.series(st.seriesKind, st.seriesKey).forEach(function (e) { inSeries[e.z] = 1; });

      // 族标签：第 8～10 列合称 Ⅷ 族
      for (i = 1; i <= 18; i++) {
        var r = cellRect(1, i);
        bandHits.push({ type: 'group', g: i, x: r.x, y: r.y - 18, w: g.cw, h: 17 });
        if (i === 9 || i === 10) continue;
        if (i === 8) {
          var x8 = r.x, x10 = cellRect(1, 10).x + g.cw;
          var mid = (x8 + x10) / 2;
          label(ctx, 'Ⅷ', mid, r.y - 9, { size: narrow ? 8 : 10.5, color: C.muted, bold: true });
          bandHits.push({ type: 'group', g: 8, x: x8, y: r.y - 18, w: x10 - x8, h: 17 });
          continue;
        }
        label(ctx, P.groupName(i), r.x + g.cw / 2, r.y - 9, { size: narrow ? 7.5 : 10.5, color: C.muted, bold: true });
      }
      if (!narrow) {
        // 周期标签（点它切换曲线）
        for (i = 1; i <= 7; i++) {
          var rp = cellRect(i, 1);
          bandHits.push({ type: 'period', p: i, x: 0, y: rp.y, w: rp.x - 2, h: g.ch });
          label(ctx, String(i), rp.x - 16, rp.y + g.ch / 2, { size: 12, color: C.muted, bold: true });
        }
        // 镧系、锕系标签
        [['lan', 8, '镧系'], ['act', 9, '锕系']].forEach(function (f) {
          var rf = cellRect(f[1], 3);
          bandHits.push({ type: 'f', f: f[0], x: 0, y: rf.y, w: rf.x - 2, h: g.fh });
          label(ctx, f[2], rf.x - 22, rf.y + g.fh / 2, { size: 11, color: C.muted });
        });
      } else {
        // 窄屏：整张表可以左右拖动，镧系标签写在 f 行左侧空出来的两列里
        [['lan', 8, '镧系'], ['act', 9, '锕系']].forEach(function (f) {
          var rf = cellRect(f[1], 1);
          label(ctx, f[2], rf.x + g.cw, rf.y + g.fh / 2, { size: 9.5, color: C.muted });
        });
      }
      // 第 6、7 周期第 ⅢB 族：镧系、锕系占位
      [[6, 'lan', '57–71', '镧系'], [7, 'act', '89–103', '锕系']].forEach(function (ph) {
        var rc = cellRect(ph[0], 3);
        bandHits.push({ type: 'f', f: ph[1], x: rc.x, y: rc.y, w: rc.w, h: rc.h });
        ctx.setLineDash([3, 3]);
        ctx.strokeStyle = 'rgba(141,153,171,.35)'; ctx.lineWidth = 1;
        rrect(ctx, rc.x + 1, rc.y + 1, rc.w - 2, rc.h - 2, 4); ctx.stroke();
        ctx.setLineDash([]);
        if (narrow) {
          label(ctx, ph[3].slice(0, 1), rc.x + rc.w / 2, rc.y + rc.h / 2, { size: 8, color: 'rgba(141,153,171,.85)' });
        } else if (rc.h >= 30) {
          label(ctx, ph[2], rc.x + rc.w / 2, rc.y + rc.h / 2 - 6, { size: 9, color: 'rgba(141,153,171,.8)' });
          label(ctx, ph[3], rc.x + rc.w / 2, rc.y + rc.h / 2 + 7, { size: 9, color: 'rgba(141,153,171,.8)' });
        } else {
          label(ctx, ph[2] + ' ' + ph[3], rc.x + rc.w / 2, rc.y + rc.h / 2, { size: 8.5, color: 'rgba(141,153,171,.8)' });
        }
      });

      // 元素格
      P.ELS.forEach(function (e) {
        var p = P.pos(e), r = cellRect(p.row, p.col);
        cellHits.push({ el: e, x: r.x, y: r.y, w: r.w, h: r.h });
        drawCell(st, e, r, inSeries[e.z], st.sel && st.sel.z === e.z, st.hover && st.hover.z === e.z);
      });
    }

    function drawCell(st, e, r, inSeries, selected, hover) {
      var g = geom(), n = P.norm(e, st.prop), fill, bar = null;
      var cat = P.CAT[e.cat];
      if (st.prop === 'cat') {
        fill = rgb(hexToRgb(cat.c), 0.3);
      } else if (n == null) {
        fill = 'rgba(255,255,255,.035)';
      } else {
        var hc = heat(n);
        fill = rgb(hc, 0.28 + 0.44 * n);
        bar = hc;
      }
      rrect(ctx, r.x, r.y, r.w, r.h, Math.max(2, r.w * 0.08));
      ctx.fillStyle = fill; ctx.fill();
      if (bar) {
        ctx.save();
        rrect(ctx, r.x, r.y, r.w, r.h, Math.max(2, r.w * 0.08)); ctx.clip();
        ctx.fillStyle = rgb(bar, 0.9);
        ctx.fillRect(r.x, r.y + r.h - 2.5, r.w * Math.max(0.06, n), 2.5);
        ctx.restore();
      }
      if (selected) {
        ctx.save(); ctx.shadowColor = 'rgba(255,201,74,.75)'; ctx.shadowBlur = 12;
        ctx.strokeStyle = C.gold; ctx.lineWidth = 2.2;
        rrect(ctx, r.x + 1, r.y + 1, r.w - 2, r.h - 2, Math.max(2, r.w * 0.08)); ctx.stroke();
        ctx.restore();
      } else if (hover) {
        ctx.strokeStyle = 'rgba(255,255,255,.85)'; ctx.lineWidth = 1.6;
        rrect(ctx, r.x + 0.8, r.y + 0.8, r.w - 1.6, r.h - 1.6, Math.max(2, r.w * 0.08)); ctx.stroke();
      } else {
        if (inSeries) { ctx.strokeStyle = 'rgba(79,195,247,.45)'; ctx.lineWidth = 1.2; }
        else if (st.prop === 'cat') { ctx.strokeStyle = rgb(hexToRgb(cat.c), 0.5); ctx.lineWidth = 1; }
        else { ctx.strokeStyle = 'rgba(255,255,255,.09)'; ctx.lineWidth = 1; }
        rrect(ctx, r.x + 0.5, r.y + 0.5, r.w - 1, r.h - 1, Math.max(2, r.w * 0.08)); ctx.stroke();
      }

      var dim = st.prop !== 'cat' && n == null;
      var symSize = Math.max(7, Math.min(r.h * 0.44, r.w * 0.46));
      var cx = r.x + r.w / 2, cy = r.y + r.h * (g.ch >= 34 ? 0.46 : 0.5);
      if (g.ch >= 22) {
        ctx.font = font(Math.max(6.5, Math.min(9, r.w * 0.19)), 600);
        ctx.textAlign = 'left'; ctx.textBaseline = 'top';
        ctx.fillStyle = dim ? 'rgba(141,153,171,.5)' : 'rgba(230,235,242,.45)';
        ctx.fillText(String(e.z), r.x + r.w * 0.1, r.y + r.h * 0.07);
      }
      label(ctx, e.sym, cx, cy, { size: symSize, bold: true, color: dim ? 'rgba(230,235,242,.5)' : C.text, stroke: g.ch >= 24 });
      var showVal = st.prop !== 'cat' && n != null;
      if (narrow) {
        if (showVal) {
          ctx.font = font(6.2);
          ctx.textAlign = 'right'; ctx.textBaseline = 'top';
          ctx.fillStyle = 'rgba(230,235,242,.55)';
          ctx.fillText(P.fmtNum(P.val(e, st.prop), st.prop), r.x + r.w * 0.92, r.y + r.h * 0.06);
        }
      } else if (g.ch >= 34 && r.w >= 26) {
        ctx.font = font(Math.max(6.5, Math.min(9.5, r.w * 0.2)));
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillStyle = dim ? 'rgba(141,153,171,.55)' : 'rgba(230,235,242,.62)';
        ctx.fillText(e.name, cx, r.y + r.h * 0.8);
        if (g.ch >= 40 && r.w >= 40 && showVal) {
          ctx.font = font(Math.max(6.5, Math.min(8.5, r.w * 0.16)));
          ctx.textAlign = 'right'; ctx.textBaseline = 'top';
          ctx.fillStyle = 'rgba(141,153,171,.7)';
          ctx.fillText(P.fmtNum(P.val(e, st.prop), st.prop), r.x + r.w * 0.9, r.y + r.h * 0.07);
        }
      }
    }
    function hexToRgb(h) {
      var n = parseInt(h.slice(1), 16);
      return [n >> 16, (n >> 8) & 255, n & 255];
    }

    // ---------- 趋势曲线 ----------
    function drawChart(st) {
      var g = geom(), top = g.chartTop, bot = g.chartBottom;
      if (bot - top < 84) return;
      var pad = narrow ? 10 : 18, x0 = pad, w = W - pad * 2, h = bot - top;
      rrect(ctx, x0, top, w, h, 12);
      ctx.fillStyle = 'rgba(17,23,35,.72)'; ctx.fill();
      ctx.strokeStyle = 'rgba(42,52,70,.9)'; ctx.lineWidth = 1; ctx.stroke();

      var prop = P.PMAP[st.prop];
      var list = P.series(st.seriesKind, st.seriesKey);
      var title = st.prop === 'cat' ? '元素分类：金属、准金属、非金属、稀有气体'
        : P.seriesLabel(st.seriesKind, st.seriesKey) + ' · ' + prop.name + '的变化' + (prop.unit ? '（' + prop.unit + '）' : '');
      label(ctx, title, x0 + 14, top + 15, { size: narrow ? 12 : 13.5, bold: true, align: 'left', color: C.text, stroke: false });
      // 颜色图例
      if (w > 560 && prop.kind !== 'cat') {
        var lx = x0 + w - 156, ly = top + 10;
        var grd = ctx.createLinearGradient(lx, 0, lx + 96, 0);
        RAMP.forEach(function (s) { grd.addColorStop(s[0], rgb(s[1])); });
        ctx.fillStyle = grd; rrect(ctx, lx, ly, 96, 7, 3.5); ctx.fill();
        label(ctx, String(prop.max) + (prop.unit ? ' ' + prop.unit : ''), lx + 96 + 6, ly + 3.5,
          { size: 9.5, align: 'left', color: C.muted, stroke: false });
        label(ctx, String(prop.min), lx - 5, ly + 3.5, { size: 9.5, align: 'right', color: C.muted, stroke: false });
      } else if (w > 560) {
        var keys = Object.keys(P.CAT), lx2 = x0 + w - 20;
        for (var k = keys.length - 1; k >= 0; k--) {
          var nm = P.CAT[keys[k]].name;
          ctx.font = font(10);
          var tw = ctx.measureText(nm).width;
          lx2 -= tw;
          label(ctx, nm, lx2, top + 13, { size: 10, align: 'left', color: C.muted, stroke: false });
          lx2 -= 12;
          ctx.fillStyle = P.CAT[keys[k]].c;
          ctx.beginPath(); ctx.arc(lx2 + 4, top + 13, 4, 0, TAU); ctx.fill();
          lx2 -= 8;
        }
      }
      // 一句话规律
      var note = P.note(st.seriesKind, st.prop, st.seriesKey);
      if (note && h > 118) {
        ctx.font = font(narrow ? 10 : 11.5);
        ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
        ctx.fillStyle = C.muted;
        var maxW = w - 28, words = note, line = '', yy = top + (narrow ? 30 : 34);
        for (var ci = 0; ci < words.length; ci++) {
          var t2 = line + words[ci];
          if (ctx.measureText(t2).width > maxW && line) {
            ctx.fillText(line, x0 + 14, yy); line = words[ci]; yy += narrow ? 13 : 15;
          } else line = t2;
        }
        if (line && yy < top + h - 60) ctx.fillText(line, x0 + 14, yy);
      }

      var tall = h > 240;
      var pt = top + (tall ? (narrow ? 56 : 62) : 44), pb = bot - (narrow ? 24 : (tall ? 42 : 32));
      var pl = x0 + (narrow ? 34 : 46), pr = x0 + w - (narrow ? 12 : 22);
      var vals = [], i;
      for (i = 0; i < list.length; i++) { var v = P.val(list[i], st.prop); if (v != null && st.prop !== 'cat') vals.push(v); }
      if (st.prop === 'cat') { drawCatSummary(x0, w, top, h, pl, pr); return; }
      if (vals.length < 2) {
        label(ctx, '这一类元素的数据不足，换一个周期或族看看',
          x0 + w / 2, (pt + pb) / 2, { size: 11, color: C.muted, stroke: false });
        return;
      }
      var lo = Math.min.apply(null, vals), hi = Math.max.apply(null, vals);
      var padV = (hi - lo) * 0.12 || 1;
      var sc = nice(lo - padV, hi + padV, tall ? 4 : 3);
      while ((sc.max - sc.min) / sc.step > 6) {
        sc.step *= 2;
        sc.min = Math.floor((lo - padV) / sc.step) * sc.step;
        sc.max = Math.ceil((hi + padV) / sc.step) * sc.step;
      }
      // 数据都远大于 0 时纵轴不从 0 起（如第一电离能），免得把曲线压扁、多出一个无意义的 0
      if (sc.min === 0 && lo > sc.step * 0.6) sc.min = sc.step;
      function X(i2) { return pl + (pr - pl) * (list.length === 1 ? 0.5 : i2 / (list.length - 1)); }
      function Y(v2) { return pb - (v2 - sc.min) / (sc.max - sc.min) * (pb - pt); }

      // 网格
      ctx.font = font(narrow ? 8.5 : 10);
      for (var t = sc.min; t <= sc.max + 1e-6; t += sc.step) {
        var y = Y(t);
        ctx.strokeStyle = 'rgba(255,255,255,.06)'; ctx.lineWidth = 1;
        ctx.beginPath(); ctx.moveTo(pl, y); ctx.lineTo(pr, y); ctx.stroke();
        label(ctx, tickFmt(t, st.prop), pl - 6, y, { size: narrow ? 8.5 : 10, align: 'right', color: C.muted, stroke: false });
      }
      // 选中元素的竖线
      var selIdx = -1;
      for (i = 0; i < list.length; i++) if (st.sel && list[i].z === st.sel.z) selIdx = i;
      if (selIdx >= 0) {
        ctx.setLineDash([3, 4]); ctx.strokeStyle = 'rgba(255,201,74,.35)'; ctx.lineWidth = 1;
        ctx.beginPath(); ctx.moveTo(X(selIdx), pt - 4); ctx.lineTo(X(selIdx), pb); ctx.stroke(); ctx.setLineDash([]);
      }
      // 折线（跳过无数据的点）
      ctx.strokeStyle = 'rgba(79,195,247,.85)'; ctx.lineWidth = narrow ? 1.6 : 2;
      ctx.beginPath();
      var started = false;
      for (i = 0; i < list.length; i++) {
        var vv = P.val(list[i], st.prop);
        if (vv == null) { started = false; continue; }
        if (!started) { ctx.moveTo(X(i), Y(vv)); started = true; } else ctx.lineTo(X(i), Y(vv));
      }
      ctx.stroke();
      // 点与读数
      var spacing = (pr - pl) / Math.max(1, list.length - 1);
      for (i = 0; i < list.length; i++) {
        var e = list[i], vl = P.val(e, st.prop), px = X(i);
        if (vl == null) {
          label(ctx, e.sym, px, pb + (narrow ? 10 : 13), { size: narrow ? 8.5 : 10, color: 'rgba(141,153,171,.55)', stroke: false });
          continue;
        }
        var nv = P.norm(e, st.prop), isSel = selIdx === i, py = Y(vl), col = heat(nv);
        if (isSel) {
          ctx.fillStyle = 'rgba(255,201,74,.22)';
          ctx.beginPath(); ctx.arc(px, py, narrow ? 8 : 10, 0, TAU); ctx.fill();
        }
        ctx.fillStyle = rgb(col); ctx.beginPath(); ctx.arc(px, py, isSel ? 5 : 3.6, 0, TAU); ctx.fill();
        ctx.strokeStyle = isSel ? C.gold : 'rgba(5,7,13,.7)'; ctx.lineWidth = isSel ? 1.8 : 1; ctx.stroke();
        if (spacing > (narrow ? 44 : 42)) {
          var vx = px, va = 'center';
          if (i === 0) { vx = px + 7; va = 'left'; }
          else if (i === list.length - 1) { vx = px - 7; va = 'right'; }
          label(ctx, P.fmtNum(vl, st.prop), vx, py - (narrow ? 11 : 13),
            { size: narrow ? 8.5 : 9.5, color: isSel ? C.gold : C.muted, stroke: false, align: va });
        }
        // x 轴元素符号
        var every = spacing < (narrow ? 18 : 22) ? 2 : 1;
        if (i % every === 0 || isSel) {
          label(ctx, e.sym, px, pb + (narrow ? 10 : 13), { size: isSel ? (narrow ? 9.5 : 11) : (narrow ? 8.5 : 10), bold: isSel, color: isSel ? C.gold : C.muted, stroke: false });
          if (!narrow && tall && spacing > 46) {
            label(ctx, e.name, px, pb + 27, { size: 9, color: 'rgba(141,153,171,.7)', stroke: false });
          }
        }
      }
    }

    // 分类着色时：用一条堆叠条汇总金属 / 非金属 / 准金属 / 稀有气体的种数
    function drawCatSummary(x0, w, top, h, pl, pr) {
      var counts = P.catCounts(), keys = Object.keys(P.CAT), total = 0, i;
      keys.forEach(function (k) { total += counts[k]; });
      var by = top + (h > 190 ? 96 : 78), bh = h > 190 ? 42 : 30;
      var x = pl, full = pr - pl;
      ctx.font = font(narrow ? 10 : 12, 600);
      keys.forEach(function (k) {
        var cw = full * counts[k] / total;
        ctx.fillStyle = P.CAT[k].c;
        ctx.fillRect(x, by, Math.max(2, cw - 2), bh);
        if (cw > (narrow ? 34 : 62)) {
          label(ctx, counts[k] + ' 种', x + cw / 2, by + bh / 2 + 1, { size: narrow ? 9.5 : 12, bold: true, color: '#11161f', stroke: false });
        }
        x += cw;
      });
      // 图例（色块 + 名称 + 种数）
      var ly = by + bh + (narrow ? 16 : 26), lx = pl;
      ctx.font = font(narrow ? 10 : 11.5);
      keys.forEach(function (k) {
        var t = P.CAT[k].name + ' ' + counts[k];
        if (lx + 12 + ctx.measureText(t).width > pr) { lx = pl; ly += narrow ? 14 : 18; }
        ctx.fillStyle = P.CAT[k].c;
        ctx.beginPath(); ctx.arc(lx + 4, ly, 4, 0, TAU); ctx.fill();
        label(ctx, t, lx + 12, ly, { size: narrow ? 10 : 11.5, align: 'left', color: C.muted, stroke: false });
        lx += 12 + ctx.measureText(t).width + (narrow ? 14 : 22);
      });
      if (!narrow && h > 190) {
        label(ctx, '金属与非金属的分界线大致在 ' + P.metalloids() + ' 附近（准金属，半导体材料多来自这一带）',
          pl, ly + 28, { size: 11, align: 'left', color: 'rgba(141,153,171,.85)', stroke: false });
      }
    }

    // ---------- 悬停提示 ----------
    function drawTip(st) {
      var e = st.hover;
      if (!e) return;
      var g = geom(), p = P.pos(e), r = cellRect(p.row, p.col);
      var prop = P.PMAP[st.prop];
      var lines = [e.sym + ' ' + e.name + '　' + e.z, P.periodName(e.p) + ' · ' + P.groupName(e.g) + '族',
        prop.name + '：' + P.fmt(e, st.prop)];
      ctx.font = font(narrow ? 10 : 11.5, 600);
      var wmax = 0;
      lines.forEach(function (s, i) { ctx.font = font(narrow ? 10 : 11.5, i === 0 ? 600 : null); wmax = Math.max(wmax, ctx.measureText(s).width); });
      var pw = wmax + 20, ph = lines.length * (narrow ? 15 : 17) + 12;
      var tx = r.x + r.w + 8, ty = r.y - 4;
      if (tx + pw > W - 8) tx = r.x - pw - 8;
      if (tx < 8) tx = Math.min(W - pw - 8, r.x + 4);
      if (ty < 8) ty = 8;
      if (ty + ph > H - 8) ty = H - ph - 8;
      rrect(ctx, tx, ty, pw, ph, 8);
      ctx.fillStyle = 'rgba(9,14,24,.96)'; ctx.fill();
      ctx.strokeStyle = 'rgba(255,201,74,.5)'; ctx.lineWidth = 1; ctx.stroke();
      lines.forEach(function (s, i) {
        label(ctx, s, tx + 10, ty + 10 + i * (narrow ? 15 : 17), {
          size: narrow ? 10 : 11.5, align: 'left', bold: i === 0, color: i === 0 ? C.text : i === 2 ? C.gold : C.muted, stroke: false
        });
      });
    }

    function draw(st) {
      bg();
      drawTable(st);
      drawChart(st);
      drawTip(st);
    }

    // 点在格子上 / 族标签 / 周期标签 / 镧系锕系标签
    function hit(x, y) {
      var i, h;
      for (i = 0; i < cellHits.length; i++) {
        h = cellHits[i];
        if (x >= h.x && x <= h.x + h.w && y >= h.y && y <= h.y + h.h) return { type: 'el', el: h.el };
      }
      for (i = 0; i < bandHits.length; i++) {
        h = bandHits[i];
        if (x >= h.x && x <= h.x + h.w && y >= h.y && y <= h.y + h.h) return h;
      }
      return null;
    }
    function rectOf(e) { var g = geom(), p = P.pos(e); return cellRect(p.row, p.col); }

    return {
      resize: resize, draw: draw, hit: hit, rectOf: rectOf, geom: geom,
      isNarrow: function () { return narrow; },
      panX: function () { return pan; },
      setPan: function (p) { var np = clampPan(p); if (np !== pan) { pan = np; G = null; return true; } return false; },
      ensureVisible: function (e) {
        if (!narrow || !e) return false;
        var r = rectOf(e), np = pan;
        if (r.x < 8) np = pan + (8 - r.x);
        else if (r.x + r.w > W - 8) np = pan - (r.x + r.w - (W - 8));
        return this.setPan(np);
      }
    };
  }

  window.PeriodicDraw = { View: View, heat: heat };
})();
