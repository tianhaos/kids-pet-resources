// 元素数据与周期律计算（不碰 DOM，可单独用 node 测试）
// 每条：[原子序数, 符号, 中文名, 周期, 族, 分类, 原子半径 pm, 电负性, 第一电离能 kJ/mol, 电子层排布]
// 半径：金属用金属半径（配位数 12）、非金属用共价半径，与教材数据一致；稀有气体测定方法不同，
//       以及部分放射性元素的半径数据不全，留空 null（不参与比较）。
// 电负性：鲍林标度；稀有气体不参与比较，104 号以后的超重元素性质为理论预测，本模型不录。
// 第一电离能：kJ/mol。
// 族：1～18 为周期表中的列，镧系（57～71）与锕系（89～103）都属于第 ⅢB 族。
(function () {
  var CAT = {
    metal: { name: '金属', c: '#ff9f6b' },
    nonmetal: { name: '非金属', c: '#4fc3f7' },
    metalloid: { name: '准金属', c: '#7ee081' },
    noble: { name: '稀有气体', c: '#c9a7ff' }
  };
  // 列 1～18 对应的族（第 8、9、10 列合称 Ⅷ 族）
  var GROUP_NAMES = ['ⅠA', 'ⅡA', 'ⅢB', 'ⅣB', 'ⅤB', 'ⅥB', 'ⅦB', 'Ⅷ', 'Ⅷ', 'Ⅷ', 'ⅠB', 'ⅡB', 'ⅢA', 'ⅣA', 'ⅤA', 'ⅥA', 'ⅦA', '0'];
  var CN = ['', '一', '二', '三', '四', '五', '六', '七'];

  // 属性：min / max 是热力图配色的固定范围
  var PROPS = [
    { key: 'cat', name: '元素分类', short: '分类', unit: '', kind: 'cat' },
    { key: 'radius', name: '原子半径', short: '原子半径', unit: 'pm', min: 30, max: 270 },
    { key: 'en', name: '电负性', short: '电负性', unit: '', min: 0.7, max: 4.0 },
    { key: 'ie', name: '第一电离能', short: '第一电离能', unit: 'kJ/mol', min: 370, max: 2400 }
  ];

  var RAW = [
    [1, 'H', '氢', 1, 1, 'nonmetal', 37, 2.20, 1312, [1]],
    [2, 'He', '氦', 1, 18, 'noble', null, null, 2372, [2]],
    [3, 'Li', '锂', 2, 1, 'metal', 152, 0.98, 520, [2, 1]],
    [4, 'Be', '铍', 2, 2, 'metal', 111, 1.57, 899, [2, 2]],
    [5, 'B', '硼', 2, 13, 'metalloid', 88, 2.04, 801, [2, 3]],
    [6, 'C', '碳', 2, 14, 'nonmetal', 77, 2.55, 1086, [2, 4]],
    [7, 'N', '氮', 2, 15, 'nonmetal', 70, 3.04, 1402, [2, 5]],
    [8, 'O', '氧', 2, 16, 'nonmetal', 66, 3.44, 1314, [2, 6]],
    [9, 'F', '氟', 2, 17, 'nonmetal', 64, 3.98, 1681, [2, 7]],
    [10, 'Ne', '氖', 2, 18, 'noble', null, null, 2081, [2, 8]],
    [11, 'Na', '钠', 3, 1, 'metal', 186, 0.93, 496, [2, 8, 1]],
    [12, 'Mg', '镁', 3, 2, 'metal', 160, 1.31, 738, [2, 8, 2]],
    [13, 'Al', '铝', 3, 13, 'metal', 143, 1.61, 578, [2, 8, 3]],
    [14, 'Si', '硅', 3, 14, 'metalloid', 117, 1.90, 786, [2, 8, 4]],
    [15, 'P', '磷', 3, 15, 'nonmetal', 110, 2.19, 1012, [2, 8, 5]],
    [16, 'S', '硫', 3, 16, 'nonmetal', 104, 2.58, 1000, [2, 8, 6]],
    [17, 'Cl', '氯', 3, 17, 'nonmetal', 99, 3.16, 1251, [2, 8, 7]],
    [18, 'Ar', '氩', 3, 18, 'noble', null, null, 1521, [2, 8, 8]],
    [19, 'K', '钾', 4, 1, 'metal', 227, 0.82, 419, [2, 8, 8, 1]],
    [20, 'Ca', '钙', 4, 2, 'metal', 197, 1.00, 590, [2, 8, 8, 2]],
    [21, 'Sc', '钪', 4, 3, 'metal', 161, 1.36, 633, [2, 8, 9, 2]],
    [22, 'Ti', '钛', 4, 4, 'metal', 145, 1.54, 659, [2, 8, 10, 2]],
    [23, 'V', '钒', 4, 5, 'metal', 132, 1.63, 651, [2, 8, 11, 2]],
    [24, 'Cr', '铬', 4, 6, 'metal', 125, 1.66, 653, [2, 8, 13, 1]],
    [25, 'Mn', '锰', 4, 7, 'metal', 124, 1.55, 717, [2, 8, 13, 2]],
    [26, 'Fe', '铁', 4, 8, 'metal', 124, 1.83, 762, [2, 8, 14, 2]],
    [27, 'Co', '钴', 4, 9, 'metal', 125, 1.88, 760, [2, 8, 15, 2]],
    [28, 'Ni', '镍', 4, 10, 'metal', 124, 1.91, 737, [2, 8, 16, 2]],
    [29, 'Cu', '铜', 4, 11, 'metal', 128, 1.90, 745, [2, 8, 18, 1]],
    [30, 'Zn', '锌', 4, 12, 'metal', 134, 1.65, 906, [2, 8, 18, 2]],
    [31, 'Ga', '镓', 4, 13, 'metal', 135, 1.81, 579, [2, 8, 18, 3]],
    [32, 'Ge', '锗', 4, 14, 'metalloid', 122, 2.01, 762, [2, 8, 18, 4]],
    [33, 'As', '砷', 4, 15, 'metalloid', 121, 2.18, 945, [2, 8, 18, 5]],
    [34, 'Se', '硒', 4, 16, 'nonmetal', 117, 2.55, 941, [2, 8, 18, 6]],
    [35, 'Br', '溴', 4, 17, 'nonmetal', 114, 2.96, 1140, [2, 8, 18, 7]],
    [36, 'Kr', '氪', 4, 18, 'noble', null, null, 1351, [2, 8, 18, 8]],
    [37, 'Rb', '铷', 5, 1, 'metal', 248, 0.82, 403, [2, 8, 18, 8, 1]],
    [38, 'Sr', '锶', 5, 2, 'metal', 215, 0.95, 550, [2, 8, 18, 8, 2]],
    [39, 'Y', '钇', 5, 3, 'metal', 182, 1.22, 600, [2, 8, 18, 9, 2]],
    [40, 'Zr', '锆', 5, 4, 'metal', 160, 1.33, 640, [2, 8, 18, 10, 2]],
    [41, 'Nb', '铌', 5, 5, 'metal', 146, 1.60, 652, [2, 8, 18, 12, 1]],
    [42, 'Mo', '钼', 5, 6, 'metal', 139, 2.16, 684, [2, 8, 18, 13, 1]],
    [43, 'Tc', '锝', 5, 7, 'metal', 136, 1.90, 702, [2, 8, 18, 13, 2]],
    [44, 'Ru', '钌', 5, 8, 'metal', 134, 2.20, 710, [2, 8, 18, 15, 1]],
    [45, 'Rh', '铑', 5, 9, 'metal', 134, 2.28, 720, [2, 8, 18, 16, 1]],
    [46, 'Pd', '钯', 5, 10, 'metal', 137, 2.20, 804, [2, 8, 18, 18]],
    [47, 'Ag', '银', 5, 11, 'metal', 144, 1.93, 731, [2, 8, 18, 18, 1]],
    [48, 'Cd', '镉', 5, 12, 'metal', 151, 1.69, 868, [2, 8, 18, 18, 2]],
    [49, 'In', '铟', 5, 13, 'metal', 167, 1.78, 558, [2, 8, 18, 18, 3]],
    [50, 'Sn', '锡', 5, 14, 'metal', 140, 1.96, 709, [2, 8, 18, 18, 4]],
    [51, 'Sb', '锑', 5, 15, 'metalloid', 141, 2.05, 834, [2, 8, 18, 18, 5]],
    [52, 'Te', '碲', 5, 16, 'metalloid', 137, 2.10, 869, [2, 8, 18, 18, 6]],
    [53, 'I', '碘', 5, 17, 'nonmetal', 133, 2.66, 1008, [2, 8, 18, 18, 7]],
    [54, 'Xe', '氙', 5, 18, 'noble', null, null, 1170, [2, 8, 18, 18, 8]],
    [55, 'Cs', '铯', 6, 1, 'metal', 265, 0.79, 376, [2, 8, 18, 18, 8, 1]],
    [56, 'Ba', '钡', 6, 2, 'metal', 217, 0.89, 503, [2, 8, 18, 18, 8, 2]],
    [57, 'La', '镧', 6, 3, 'metal', 187, 1.10, 538, [2, 8, 18, 18, 9, 2]],
    [58, 'Ce', '铈', 6, 3, 'metal', 182, 1.12, 534, [2, 8, 18, 19, 9, 2]],
    [59, 'Pr', '镨', 6, 3, 'metal', 183, 1.13, 527, [2, 8, 18, 21, 8, 2]],
    [60, 'Nd', '钕', 6, 3, 'metal', 182, 1.14, 533, [2, 8, 18, 22, 8, 2]],
    [61, 'Pm', '钷', 6, 3, 'metal', 181, 1.13, 540, [2, 8, 18, 23, 8, 2]],
    [62, 'Sm', '钐', 6, 3, 'metal', 180, 1.17, 545, [2, 8, 18, 24, 8, 2]],
    [63, 'Eu', '铕', 6, 3, 'metal', 204, 1.20, 547, [2, 8, 18, 25, 8, 2]],
    [64, 'Gd', '钆', 6, 3, 'metal', 180, 1.20, 593, [2, 8, 18, 25, 9, 2]],
    [65, 'Tb', '铽', 6, 3, 'metal', 178, 1.20, 566, [2, 8, 18, 27, 8, 2]],
    [66, 'Dy', '镝', 6, 3, 'metal', 177, 1.22, 573, [2, 8, 18, 28, 8, 2]],
    [67, 'Ho', '钬', 6, 3, 'metal', 177, 1.23, 581, [2, 8, 18, 29, 8, 2]],
    [68, 'Er', '铒', 6, 3, 'metal', 176, 1.24, 589, [2, 8, 18, 30, 8, 2]],
    [69, 'Tm', '铥', 6, 3, 'metal', 175, 1.25, 597, [2, 8, 18, 31, 8, 2]],
    [70, 'Yb', '镱', 6, 3, 'metal', 194, 1.10, 603, [2, 8, 18, 32, 8, 2]],
    [71, 'Lu', '镥', 6, 3, 'metal', 174, 1.27, 524, [2, 8, 18, 32, 9, 2]],
    [72, 'Hf', '铪', 6, 4, 'metal', 159, 1.30, 659, [2, 8, 18, 32, 10, 2]],
    [73, 'Ta', '钽', 6, 5, 'metal', 146, 1.50, 761, [2, 8, 18, 32, 11, 2]],
    [74, 'W', '钨', 6, 6, 'metal', 139, 2.36, 770, [2, 8, 18, 32, 12, 2]],
    [75, 'Re', '铼', 6, 7, 'metal', 137, 1.90, 760, [2, 8, 18, 32, 13, 2]],
    [76, 'Os', '锇', 6, 8, 'metal', 135, 2.20, 840, [2, 8, 18, 32, 14, 2]],
    [77, 'Ir', '铱', 6, 9, 'metal', 136, 2.20, 880, [2, 8, 18, 32, 15, 2]],
    [78, 'Pt', '铂', 6, 10, 'metal', 139, 2.28, 870, [2, 8, 18, 32, 17, 1]],
    [79, 'Au', '金', 6, 11, 'metal', 144, 2.54, 890, [2, 8, 18, 32, 18, 1]],
    [80, 'Hg', '汞', 6, 12, 'metal', 151, 2.00, 1007, [2, 8, 18, 32, 18, 2]],
    [81, 'Tl', '铊', 6, 13, 'metal', 170, 1.62, 589, [2, 8, 18, 32, 18, 3]],
    [82, 'Pb', '铅', 6, 14, 'metal', 175, 2.33, 716, [2, 8, 18, 32, 18, 4]],
    [83, 'Bi', '铋', 6, 15, 'metal', 155, 2.02, 703, [2, 8, 18, 32, 18, 5]],
    [84, 'Po', '钋', 6, 16, 'metalloid', null, 2.00, 812, [2, 8, 18, 32, 18, 6]],
    [85, 'At', '砹', 6, 17, 'metalloid', null, 2.20, 899, [2, 8, 18, 32, 18, 7]],
    [86, 'Rn', '氡', 6, 18, 'noble', null, null, 1037, [2, 8, 18, 32, 18, 8]],
    [87, 'Fr', '钫', 7, 1, 'metal', null, 0.70, 380, [2, 8, 18, 32, 18, 8, 1]],
    [88, 'Ra', '镭', 7, 2, 'metal', 215, 0.90, 509, [2, 8, 18, 32, 18, 8, 2]],
    [89, 'Ac', '锕', 7, 3, 'metal', 188, 1.10, 499, [2, 8, 18, 32, 18, 9, 2]],
    [90, 'Th', '钍', 7, 3, 'metal', 180, 1.30, 587, [2, 8, 18, 32, 18, 10, 2]],
    [91, 'Pa', '镤', 7, 3, 'metal', 163, 1.50, 568, [2, 8, 18, 32, 20, 9, 2]],
    [92, 'U', '铀', 7, 3, 'metal', 156, 1.38, 598, [2, 8, 18, 32, 21, 9, 2]],
    [93, 'Np', '镎', 7, 3, 'metal', null, 1.36, 605, [2, 8, 18, 32, 22, 9, 2]],
    [94, 'Pu', '钚', 7, 3, 'metal', null, 1.28, 585, [2, 8, 18, 32, 24, 8, 2]],
    [95, 'Am', '镅', 7, 3, 'metal', null, 1.13, 578, [2, 8, 18, 32, 25, 8, 2]],
    [96, 'Cm', '锔', 7, 3, 'metal', null, 1.28, 581, [2, 8, 18, 32, 25, 9, 2]],
    [97, 'Bk', '锫', 7, 3, 'metal', null, 1.30, 601, [2, 8, 18, 32, 27, 8, 2]],
    [98, 'Cf', '锎', 7, 3, 'metal', null, 1.30, 608, [2, 8, 18, 32, 28, 8, 2]],
    [99, 'Es', '锿', 7, 3, 'metal', null, 1.30, 619, [2, 8, 18, 32, 29, 8, 2]],
    [100, 'Fm', '镄', 7, 3, 'metal', null, 1.30, 627, [2, 8, 18, 32, 30, 8, 2]],
    [101, 'Md', '钔', 7, 3, 'metal', null, 1.30, 635, [2, 8, 18, 32, 31, 8, 2]],
    [102, 'No', '锘', 7, 3, 'metal', null, 1.30, 642, [2, 8, 18, 32, 32, 8, 2]],
    [103, 'Lr', '铹', 7, 3, 'metal', null, 1.30, 470, [2, 8, 18, 32, 32, 8, 3]],
    [104, 'Rf', '𬬻', 7, 4, 'metal', null, null, null, [2, 8, 18, 32, 32, 10, 2]],
    [105, 'Db', '𬭊', 7, 5, 'metal', null, null, null, [2, 8, 18, 32, 32, 11, 2]],
    [106, 'Sg', '𬭳', 7, 6, 'metal', null, null, null, [2, 8, 18, 32, 32, 12, 2]],
    [107, 'Bh', '𬭛', 7, 7, 'metal', null, null, null, [2, 8, 18, 32, 32, 13, 2]],
    [108, 'Hs', '𬭶', 7, 8, 'metal', null, null, null, [2, 8, 18, 32, 32, 14, 2]],
    [109, 'Mt', '鿏', 7, 9, 'metal', null, null, null, [2, 8, 18, 32, 32, 15, 2]],
    [110, 'Ds', '𨭎', 7, 10, 'metal', null, null, null, [2, 8, 18, 32, 32, 16, 2]],
    [111, 'Rg', '𬬭', 7, 11, 'metal', null, null, null, [2, 8, 18, 32, 32, 17, 2]],
    [112, 'Cn', '鿔', 7, 12, 'metal', null, null, null, [2, 8, 18, 32, 32, 18, 2]],
    [113, 'Nh', '鿭', 7, 13, 'metal', null, null, null, [2, 8, 18, 32, 32, 18, 3]],
    [114, 'Fl', '𫓧', 7, 14, 'metal', null, null, null, [2, 8, 18, 32, 32, 18, 4]],
    [115, 'Mc', '镆', 7, 15, 'metal', null, null, null, [2, 8, 18, 32, 32, 18, 5]],
    [116, 'Lv', '𫟼', 7, 16, 'metal', null, null, null, [2, 8, 18, 32, 32, 18, 6]],
    [117, 'Ts', '鿬', 7, 17, 'metal', null, null, null, [2, 8, 18, 32, 32, 18, 7]],
    [118, 'Og', '鿫', 7, 18, 'noble', null, null, null, [2, 8, 18, 32, 32, 18, 8]]
  ];

  var ELS = RAW.map(function (r) {
    var e = { z: r[0], sym: r[1], name: r[2], p: r[3], g: r[4], cat: r[5], r: r[6], en: r[7], ie: r[8], sh: r[9] };
    if (e.z >= 57 && e.z <= 71) e.f = 'lan';
    else if (e.z >= 89 && e.z <= 103) e.f = 'act';
    return e;
  });
  var BY = {}, BYSYM = {};
  ELS.forEach(function (e) { BY[e.z] = e; BYSYM[e.sym] = e; });

  var PMAP = {};
  PROPS.forEach(function (p) { PMAP[p.key] = p; });

  function val(e, key) {
    if (key === 'cat') return e.cat;
    return e[key === 'radius' ? 'r' : key];
  }
  function fmt(e, key) {
    var v = val(e, key);
    if (key === 'cat') return CAT[v].name;
    if (v == null) return '—';
    if (key === 'radius') return v + ' pm';
    if (key === 'en') return v.toFixed(2);
    return Math.round(v) + ' kJ/mol';
  }
  function fmtNum(v, key) {
    if (v == null) return '—';
    if (key === 'radius') return String(v);
    if (key === 'en') return v.toFixed(2);
    return String(Math.round(v));
  }
  // 热力图位置 0～1；无数据返回 null
  function norm(e, key) {
    var p = PMAP[key], v = val(e, key);
    if (p.kind === 'cat' || v == null) return null;
    return Math.max(0, Math.min(1, (v - p.min) / (p.max - p.min)));
  }
  // 周期表中的位置：返回 {row, col}；镧系、锕系在第 8、9 行
  function pos(e) {
    if (e.f === 'lan') return { row: 8, col: e.z - 57 + 3 };
    if (e.f === 'act') return { row: 9, col: e.z - 89 + 3 };
    return { row: e.p, col: e.g };
  }
  function groupName(g) { return GROUP_NAMES[g - 1] || ''; }
  function periodName(p) { return '第' + CN[p] + '周期'; }
  function seriesLabel(kind, key) {
    if (kind === 'period') return periodName(key);
    var s = groupName(key) + '族';
    if (key === 3) s += '（含镧系、锕系）';
    return s;
  }
  function series(kind, key) {
    return ELS.filter(function (e) { return kind === 'period' ? e.p === key : e.g === key; });
  }
  function block(e) {
    if (e.f) return 'f';
    if (e.g <= 2) return 's';
    if (e.g >= 13) return 'p';
    if (e.g <= 10) return 'd';
    return 'ds';
  }
  // 主族元素的最高正价、最低负价（副族与 0 族返回 null）
  function valence(e) {
    if (e.f || e.g === 18) return null;
    if (e.sym === 'H') return { pos: 1, neg: -1, note: '' };
    if (e.g <= 2) return { pos: e.g, neg: null, note: '' };
    if (e.g >= 13) {
      var hi = e.g - 10;
      if (e.sym === 'O') return { pos: null, neg: -2, note: '一般无正价，负价 －2' };
      if (e.sym === 'F') return { pos: null, neg: -1, note: '无正价，负价 －1' };
      return { pos: hi, neg: hi - 8, note: '' };
    }
    return null;
  }
  function rank(e, kind, key, prop) {
    if (prop === 'cat') return null;
    var list = series(kind, key).filter(function (x) { return val(x, prop) != null; });
    list.sort(function (a, b) { return val(a, prop) - val(b, prop); });
    var i = list.indexOf(e);
    return i < 0 ? null : { i: i + 1, n: list.length, list: list };
  }
  // 同一周期 / 同一族的递变方向与说明
  function trend(kind, key, prop) {
    if (prop === 'cat') return null;
    var list = series(kind, key).filter(function (e) { return val(e, prop) != null; });
    if (list.length < 2) return null;
    var a = list[0], b = list[list.length - 1];
    var va = val(a, prop), vb = val(b, prop);
    return {
      from: a, to: b, va: va, vb: vb, dir: vb > va ? '增大' : '减小',
      text: seriesLabel(kind, key) + '：' + a.sym + ' → ' + b.sym + '，' + PMAP[prop].name + '由 ' + fmt(a, prop) +
        ' 变为 ' + fmt(b, prop) + '，总体' + (vb > va ? '增大' : '减小') + '。'
    };
  }
  // 曲线下方/上方的一句话规律（按属性与周期/族）
  var NOTES = {
    radius: {
      period: '同一周期从左到右：核电荷数增大、电子层数不变，核对外层电子的吸引增强，原子半径逐渐减小',
      group: '同一主族从上到下：电子层数增多，原子半径逐渐增大'
    },
    en: {
      period: '同一周期从左到右：原子半径减小，原子核对外层电子的吸引增强，电负性逐渐增大',
      group: '同一主族从上到下：原子半径增大，电负性逐渐减小，金属性增强'
    },
    ie: {
      period: '同一周期从左到右：第一电离能总体增大；ⅡA > ⅢA、ⅤA > ⅥA 出现反常',
      group: '同一主族从上到下：电子层数增多、原子半径增大，第一电离能总体减小'
    },
    cat: {
      period: '同一周期从左到右：金属性减弱、非金属性增强，分界在硼、硅、锗、锑、碲附近',
      group: '同一主族从上到下：金属性增强、非金属性减弱'
    }
  };
  function note(kind, prop, key) {
    if (kind === 'group' && key === 3) return 'ⅢB 族含全部镧系、锕系元素，同一周期内性质变化缓慢（镧系收缩），跨周期比较时才符合主族规律';
    return NOTES[prop] ? NOTES[prop][kind] : '';
  }
  // 按分类统计元素种数（用于“分类”着色时下方的汇总条）
  function catCounts() {
    var o = { metal: 0, nonmetal: 0, metalloid: 0, noble: 0 };
    ELS.forEach(function (e) { o[e.cat]++; });
    return o;
  }
  function metalloids() {
    return ELS.filter(function (e) { return e.cat === 'metalloid'; }).map(function (e) { return e.sym; }).join('、');
  }

  window.Periodic = {
    ELS: ELS, BY: BY, BYSYM: BYSYM, CAT: CAT, PROPS: PROPS, PMAP: PMAP,
    GROUP_NAMES: GROUP_NAMES, CN: CN,
    val: val, fmt: fmt, fmtNum: fmtNum, norm: norm, pos: pos,
    groupName: groupName, periodName: periodName, seriesLabel: seriesLabel, series: series, block: block,
    valence: valence, rank: rank, trend: trend, note: note, catCounts: catCounts, metalloids: metalloids
  };
})();
