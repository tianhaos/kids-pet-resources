// 声音的特性：用 Web Audio 发声。持续音（场景一，随频率、振幅实时变化）+ 单个音符（音色对比、练习）
(function () {
  var S = window.Sound;
  var ac = null, waves = {}, tone = null;

  function ensure() {
    if (!ac) {
      var AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return null;
      ac = new AC();
    }
    if (ac.state === 'suspended') ac.resume();
    return ac;
  }
  // sin(nθ + φ) = cosφ·sin nθ + sinφ·cos nθ → imag 为正弦分量、real 为余弦分量
  function periodic(key) {
    if (waves[key]) return waves[key];
    var t = S.TIMBRES[key], n = t.h.length + 1;
    var re = new Float32Array(n), im = new Float32Array(n);
    for (var i = 0; i < t.h.length; i++) { re[i + 1] = t.h[i] * Math.sin(t.ph[i]); im[i + 1] = t.h[i] * Math.cos(t.ph[i]); }
    return (waves[key] = ac.createPeriodicWave(re, im));
  }
  // 振幅（0～2，示波器上的值）→ 增益；次声、超声人耳听不到，直接静音
  function gainOf(f, amp) { return S.band(f) === 'audible' ? 0.16 * Math.min(amp, 2) : 0; }

  // ---------- 持续音 ----------
  function setTone(on, f, key, amp) {
    if (!on) { stopTone(); return; }
    if (!ensure()) return;
    if (!tone || tone.key !== key) {
      stopTone();
      var osc = ac.createOscillator(), g = ac.createGain();
      osc.setPeriodicWave(periodic(key)); g.gain.value = 0;
      osc.connect(g).connect(ac.destination); osc.start();
      tone = { osc: osc, g: g, key: key };
    }
    var t = ac.currentTime;
    tone.osc.frequency.setTargetAtTime(Math.max(f, 1), t, 0.02);
    tone.g.gain.setTargetAtTime(gainOf(f, amp), t, 0.04);
  }
  function stopTone() {
    if (!tone) return;
    var tn = tone; tone = null;
    tn.g.gain.setTargetAtTime(0, ac.currentTime, 0.03);
    setTimeout(function () { try { tn.osc.stop(); } catch (e) {} }, 200);
  }

  // ---------- 单个音符：包络按发声体类型（敲击后衰减 / 持续） ----------
  function note(key, f, amp, dur) {
    if (!ensure()) return;
    dur = dur || 1.2;
    var t = ac.currentTime, env = S.TIMBRES[key].env, peak = gainOf(f, amp);
    var osc = ac.createOscillator(), g = ac.createGain();
    osc.setPeriodicWave(periodic(key)); osc.frequency.value = f;
    g.gain.setValueAtTime(0, t);
    if (env === 'hold') {
      g.gain.linearRampToValueAtTime(peak, t + 0.06);
      g.gain.setValueAtTime(peak, t + dur - 0.12);
      g.gain.linearRampToValueAtTime(0, t + dur);
    } else {
      g.gain.linearRampToValueAtTime(peak, t + 0.008);
      g.gain.setTargetAtTime(0, t + 0.01, env === 'ring' ? dur * 0.45 : dur * 0.28);
    }
    osc.connect(g).connect(ac.destination);
    osc.start(t); osc.stop(t + dur + 0.6);
  }

  window.SoundAudio = { setTone: setTone, stopTone: stopTone, note: note, ensure: ensure };
})();
