// 声音的特性：纯计算（发声体频率、波长、响度、音色的泛音组成、听觉范围、波形判断练习出题），不碰 DOM
(function () {
  var TAU = Math.PI * 2;
  var V = 340;                 // 15 °C 空气中的声速 m/s
  var HEAR = [20, 20000];      // 人耳听觉范围 Hz

  // ---------- 钢尺：一端压在桌边的悬臂梁，基频 f = (1.875² / 2π) · (h / L²) · √(E / 12ρ) ----------
  // 钢 E ≈ 2×10¹¹ Pa、ρ ≈ 7.85×10³ kg/m³，尺厚 h = 1 mm → f ≈ 0.815 / L²（L 单位 m）
  var RULER = { h: 0.001, E: 2e11, rho: 7850, Lmin: 3, Lmax: 25 };   // 伸出长度 cm
  var RULER_K = 1.875 * 1.875 / TAU * Math.sqrt(RULER.E / (12 * RULER.rho)) * RULER.h;
  function rulerFreq(Lcm) { var L = Lcm / 100; return RULER_K / (L * L); }
  function rulerLen(f) { return Math.sqrt(RULER_K / f) * 100; }

  // ---------- 音叉：一套 C 调音叉（课堂常用 256 Hz 一组） ----------
  var FORKS = [
    { name: 'C', solfa: 'do', f: 256 }, { name: 'D', solfa: 're', f: 288 }, { name: 'E', solfa: 'mi', f: 320 },
    { name: 'F', solfa: 'fa', f: 341.3 }, { name: 'G', solfa: 'sol', f: 384 }, { name: 'A', solfa: 'la', f: 426.7 },
    { name: 'B', solfa: 'si', f: 480 }, { name: 'C¹', solfa: 'do', f: 512 }
  ];

  // ---------- 音色：各发声体的泛音组成（第 n 项是第 n 次谐波的相对振幅，相位单位 rad） ----------
  // 数值是示意性的：保留各乐器波形的典型特征（音叉近似正弦、小提琴近似锯齿、单簧管以奇次谐波为主）
  var TIMBRES = {
    fork:     { name: '音叉', h: [1], ph: [0], env: 'ring',
                note: '几乎只有基音，波形接近正弦曲线，声音"纯净"。' },
    flute:    { name: '长笛', h: [1, 0.42, 0.14, 0.07, 0.035], ph: [0, 0.4, 0.9, 0.3, 1.2], env: 'hold',
                note: '泛音少而弱，波形圆滑，接近正弦，声音柔和。' },
    piano:    { name: '钢琴', h: [1, 0.62, 0.44, 0.26, 0.2, 0.12, 0.08, 0.05], ph: [0, 0.6, 1.9, 0.9, 2.6, 1.4, 0.3, 2.1], env: 'decay',
                note: '琴槌敲弦，泛音丰富，声音一出来最响、随后逐渐减弱。' },
    violin:   { name: '小提琴', h: [1, 0.5, 0.33, 0.25, 0.2, 0.17, 0.14, 0.12, 0.11, 0.1], ph: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0], env: 'hold',
                note: '琴弓摩擦琴弦，泛音很多，波形接近锯齿形，声音明亮。' },
    clarinet: { name: '单簧管', h: [1, 0, 0.38, 0, 0.22, 0, 0.12, 0, 0.06], ph: [0, 0, 0, 0, 0, 0, 0, 0, 0], env: 'hold',
                note: '以奇次泛音为主，波形接近方波，声音浑厚。' },
    voice:    { name: '人声"啊"', h: [0.7, 1, 0.78, 0.36, 0.3, 0.18, 0.1, 0.05], ph: [0, 1.1, 2.3, 0.4, 1.7, 2.9, 0.8, 2.2], env: 'hold',
                note: '声带振动加上口腔、鼻腔共鸣，每个人的泛音组成不同，所以"闻其声知其人"。' },
    ruler:    { name: '钢尺', h: [1, 0.22, 0.07], ph: [0, 0.5, 1.3], env: 'decay', note: '' }
  };
  var TIMBRE_KEYS = ['fork', 'flute', 'piano', 'violin', 'clarinet', 'voice'];

  // 归一化系数：让每种音色的波形峰值都为 1（振幅相同 ⇒ 响度相同）
  var PEAK = {};
  function peak(key) {
    if (PEAK[key]) return PEAK[key];
    var t = TIMBRES[key], m = 0;
    for (var i = 0; i < 1024; i++) m = Math.max(m, Math.abs(raw(t, i / 1024 * TAU)));
    return (PEAK[key] = m || 1);
  }
  function raw(t, th) {
    var y = 0;
    for (var n = 0; n < t.h.length; n++) if (t.h[n]) y += t.h[n] * Math.sin((n + 1) * th + t.ph[n]);
    return y;
  }
  // 波形：th 为相位（一个周期 2π），返回峰值为 1 的位移
  function wave(key, th) { return raw(TIMBRES[key], th) / peak(key); }
  // 第 n 次谐波单独的曲线（同一归一化），用于"泛音分解"
  function harmonic(key, n, th) { var t = TIMBRES[key]; return (t.h[n] || 0) * Math.sin((n + 1) * th + t.ph[n]) / peak(key); }

  // ---------- 响度：示意值。振幅 a ∈ (0, 1]，距离 r（m）；a = 1、r = 1 m 时约 80 dB，距离加倍减 6 dB ----------
  function loudness(a, r) {
    if (a <= 0) return 0;
    return Math.max(0, 80 + 20 * Math.log10(a) - 20 * Math.log10(Math.max(r, 0.1)));
  }
  function loudWord(dB) {
    return dB < 1 ? '无声' : dB < 30 ? '很轻' : dB < 50 ? '较轻' : dB < 70 ? '适中' : dB < 90 ? '较响' : '很响';
  }
  // 听者处的相对振幅（示意）：与距离成反比，1 m 处等于发声体振幅（与上面 dB 的算法一致）
  function ampAt(a, r) { return a / Math.max(r, 0.1); }

  // ---------- 频率分类与听觉范围 ----------
  function band(f) { return f < HEAR[0] ? 'infra' : f > HEAR[1] ? 'ultra' : 'audible'; }
  function bandName(f) { var b = band(f); return b === 'infra' ? '次声波' : b === 'ultra' ? '超声波' : '可听声'; }
  function pitchWord(f) {
    if (f < HEAR[0]) return '低于 20 Hz，人耳听不到';
    return f < 100 ? '很低沉' : f < 250 ? '低沉' : f < 600 ? '中等' : f < 2000 ? '较高、尖细' : '很尖细';
  }
  // 人教版八年级上册"一些动物的听觉频率范围"（大象为常见补充数据）
  var HEARING = [
    { name: '人', lo: 20, hi: 20000 },
    { name: '狗', lo: 15, hi: 50000 },
    { name: '猫', lo: 60, hi: 65000 },
    { name: '蝙蝠', lo: 1000, hi: 120000 },
    { name: '海豚', lo: 150, hi: 150000 },
    { name: '大象', lo: 1, hi: 20000 }
  ];
  function hearers(f) { return HEARING.filter(function (h) { return f >= h.lo && f <= h.hi; }).map(function (h) { return h.name; }); }

  // 动画放慢：真实频率 f 映射到肉眼能看清的动画频率（单调递增，频率越高看起来振动越快）
  function visFreq(f) { return 0.55 * Math.pow(Math.max(f, 1) / 20, 0.5); }

  // ---------- 波形判断练习：两幅波形甲、乙，判断音调、响度、音色是否相同 ----------
  var QUIZ_TIMBRES = ['fork', 'violin', 'clarinet', 'piano', 'flute'];
  function pick(arr, r) { return arr[Math.floor(r() * arr.length)]; }
  function quiz(r) {
    r = r || Math.random;
    for (var tries = 0; tries < 50; tries++) {
      var cA = pick([2, 3, 4], r);
      var ratio = pick([1, 1, 1, 2, 0.5, 1.5], r);
      var cB = cA * ratio;
      if (cB < 1.5 || cB > 8 || cB !== Math.round(cB * 2) / 2) continue;
      var aA = pick([1, 0.5], r), aB = r() < 0.5 ? aA : (aA === 1 ? 0.5 : 1);
      var tA = pick(QUIZ_TIMBRES, r), tB = r() < 0.5 ? tA : pick(QUIZ_TIMBRES, r);
      var q = { a: { cyc: cA, amp: aA, tim: tA }, b: { cyc: cB, amp: aB, tim: tB } };
      q.ans = { pitch: Math.sign(cA - cB), loud: Math.sign(aA - aB), timbre: tA === tB ? 0 : 1 };   // 1：甲高/甲大/不同
      if (q.ans.pitch === 0 && q.ans.loud === 0 && q.ans.timbre === 0 && r() < 0.8) continue;  // 少出"全都相同"
      return q;
    }
    return { a: { cyc: 3, amp: 1, tim: 'fork' }, b: { cyc: 6, amp: 1, tim: 'fork' }, ans: { pitch: -1, loud: 0, timbre: 0 } };
  }

  window.Sound = {
    V: V, HEAR: HEAR, RULER: RULER, FORKS: FORKS, TIMBRES: TIMBRES, TIMBRE_KEYS: TIMBRE_KEYS, HEARING: HEARING,
    rulerFreq: rulerFreq, rulerLen: rulerLen,
    wave: wave, harmonic: harmonic, peak: peak,
    period: function (f) { return 1 / f; },
    wavelength: function (f) { return V / f; },
    loudness: loudness, loudWord: loudWord, ampAt: ampAt,
    band: band, bandName: bandName, pitchWord: pitchWord, hearers: hearers,
    visFreq: visFreq, quiz: quiz
  };
})();
