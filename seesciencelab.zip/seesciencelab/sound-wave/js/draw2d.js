// 声音的特性绘图：发声体（钢尺 / 音叉）振动 + 空气粒子疏密 + 示波器波形 + 听觉频率范围；音色对比；波形判断练习
(function () {
  var S = window.Sound;
  var PI = Math.PI, TAU = PI * 2;
  var C = { text: '#e6ebf2', muted: '#8d99ab', line: '#2a3446', grid: '#1f2938', panel: '#111723', panel2: '#1a2231',
    accent: '#ffc94a', blue: '#4fc3f7', green: '#7ee081', red: '#ff7a59', violet: '#c9a7ff',
    metal: '#aeb9c8', wood: '#6b4f36', woodTop: '#8a6a4a', screen: '#07120d', trace: '#7ee081' };
  var AB = ['#ffc94a', '#4fc3f7'];                          // 甲 / 乙
  var HCOL = ['#ffc94a', '#ff7a59', '#7ee081', '#4fc3f7', '#c9a7ff', '#ff9bd2', '#9be7ff', '#ffe08a', '#b0f2a0', '#ffb38a'];
  var VV = 120;                                             // 动画里的"声速" px/s
  var WINDOWS = [2, 5, 10, 20, 50, 100, 200, 500];          // 示波器扫描时间 ms（10 格）

  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
  function fmtHz(f) { return f >= 10000 ? (f / 1000).toFixed(0) + ' kHz' : f >= 1000 ? (f / 1000).toFixed(1) + ' kHz' : f >= 100 ? f.toFixed(0) + ' Hz' : f.toFixed(1) + ' Hz'; }
  function fmtMs(ms) { return ms >= 10 ? ms.toFixed(0) : ms >= 1 ? ms.toFixed(1) : ms.toFixed(2); }

  // 示波器扫描时间：至少显示 2.2 个周期
  function pickWindow(f) {
    var T = 1000 / f;
    for (var i = 0; i < WINDOWS.length; i++) if (WINDOWS[i] >= T * 2.2) return WINDOWS[i];
    return WINDOWS[WINDOWS.length - 1];
  }

  function SoundDraw(canvas) {
    var ctx = canvas.getContext('2d');
    var W = 0, H = 0, dpr = 1, narrow = false;
    var geo = {};                                           // 本帧几何，供拖动命中

    function resize(w, h) {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      W = w; H = h;
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
      canvas.style.width = w + 'px'; canvas.style.height = h + 'px';
      narrow = w < 640;
    }
    function font(size, weight, mono) {
      ctx.font = (weight || '') + ' ' + size + 'px ' + (mono ? '"SF Mono", Menlo, Consolas, monospace' : '-apple-system, "PingFang SC", "Microsoft YaHei", sans-serif');
    }
    function label(str, x, y, color, align, size, weight, halo, mono) {
      font(size || 12, weight, mono);
      ctx.textAlign = align || 'center'; ctx.textBaseline = 'middle';
      if (halo !== false) { ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(5,7,13,0.85)'; ctx.strokeText(str, x, y); }
      ctx.fillStyle = color; ctx.fillText(str, x, y);
    }
    function line(x0, y0, x1, y1) { ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke(); }
    function rrect(x, y, w, h, r) { ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(x, y, w, h, r); else ctx.rect(x, y, w, h); }
    function arrow(x0, y0, x1, y1, color, head) {
      head = head || 6;
      ctx.strokeStyle = color; ctx.fillStyle = color; ctx.lineWidth = 1.3;
      line(x0, y0, x1, y1);
      var a = Math.atan2(y1 - y0, x1 - x0);
      ctx.beginPath(); ctx.moveTo(x1, y1);
      ctx.lineTo(x1 - head * Math.cos(a - 0.4), y1 - head * Math.sin(a - 0.4));
      ctx.lineTo(x1 - head * Math.cos(a + 0.4), y1 - head * Math.sin(a + 0.4));
      ctx.closePath(); ctx.fill();
    }
    function dimH(x0, x1, y, text, color) {                // 双箭头水平标注
      arrow((x0 + x1) / 2, y, x0, y, color, 5); arrow((x0 + x1) / 2, y, x1, y, color, 5);
      label(text, (x0 + x1) / 2, y - 9, color, 'center', 11);
    }
    function box(x, y, w, h, title) {
      rrect(x, y, w, h, 10); ctx.fillStyle = 'rgba(17,23,35,0.55)'; ctx.fill();
      ctx.strokeStyle = C.line; ctx.lineWidth = 1; ctx.stroke();
      if (title) label(title, x + 10, y + 13, C.muted, 'left', 12, '600', false);
    }

    // ================= 场景一：音调与响度 =================
    function layoutTone() {
      var top = narrow ? 84 : 44, side = narrow ? 8 : 18, bot = 44;
      var aH = H - top - bot, aW = W - 2 * side;
      var fh = narrow ? 112 : clamp(aH * 0.2, 118, 150);
      var rest = aH - fh - 16;
      var appH = Math.round(rest * (narrow ? 0.5 : 0.46));
      return {
        app: { x: side, y: top, w: aW, h: appH },
        scope: { x: side, y: top + appH + 8, w: aW, h: rest - appH },
        freq: { x: side, y: H - bot - fh, w: aW, h: fh }
      };
    }

    // 钢尺：一端压在桌面上，伸出桌边 L cm；振型近似悬臂梁一阶振型
    function drawRuler(st, b, disp) {
      var srcW = Math.min(b.w * (narrow ? 0.5 : 0.36), 420);
      var tableR = b.x + srcW * 0.34, yT = b.y + b.h * 0.5;
      var s = (srcW * 0.62) / S.RULER.Lmax;                // px / cm
      var Lpx = st.L * s, back = Math.min(60, tableR - b.x - 10);
      // 桌子
      ctx.fillStyle = C.wood; ctx.fillRect(b.x + 6, yT + 3, tableR - b.x - 6, b.h * 0.3);
      ctx.fillStyle = C.woodTop; ctx.fillRect(b.x + 6, yT + 3, tableR - b.x - 6, 6);
      // 钢尺
      var tipAmp = disp * 48 * clamp(st.L / 12, 0.6, 1.5);
      var pts = [];
      for (var i = 0; i <= 24; i++) {
        var xi = i / 24, sh = xi * xi * (3 - xi) / 2;      // 悬臂梁形状（端点为 1）
        pts.push([tableR + Lpx * xi, yT - tipAmp * sh]);
      }
      ctx.strokeStyle = C.metal; ctx.lineWidth = 5; ctx.lineCap = 'round';
      line(tableR - back, yT, tableR, yT);
      ctx.beginPath(); pts.forEach(function (p, k) { k ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]); }); ctx.stroke();
      ctx.lineCap = 'butt';
      // 刻度
      ctx.strokeStyle = 'rgba(5,7,13,0.6)'; ctx.lineWidth = 1;
      for (var c = 1; c < st.L; c++) {
        var p = pts[Math.round(c / st.L * 24)];
        if (p) line(p[0], p[1] - 2, p[0], p[1] + (c % 5 ? 0 : 2));
      }
      // 压住钢尺的手
      var hx = tableR - back * 0.55;
      ctx.fillStyle = '#e8b896';
      rrect(hx - 16, yT - 15, 32, 13, 6); ctx.fill();
      ctx.fillStyle = '#d9a383'; rrect(hx - 6, yT - 23, 12, 10, 5); ctx.fill();
      // 伸出长度标注
      dimH(tableR, tableR + Lpx, yT + 34, '伸出 ' + st.L.toFixed(1) + ' cm', C.accent);
      // 尺端拖动点
      var tip = pts[24];
      ctx.beginPath(); ctx.arc(tip[0], tip[1], st.drag ? 9 : 7, 0, TAU);
      ctx.fillStyle = 'rgba(255,201,74,0.25)'; ctx.fill(); ctx.strokeStyle = C.accent; ctx.lineWidth = 1.5; ctx.stroke();
      if (!st.vib.on && !st.drag) label(narrow ? '拖尺端：左右改长度，上下拨动' : '拖动尺端：左右改长度，上下拨动后松手', tip[0], tip[1] - 22, C.accent, 'center', 11);
      geo.ruler = { tableR: tableR, yT: yT, s: s, tip: { x: tableR + Lpx, y: yT } };
      return { src: tableR + Lpx + 8, cy: yT, srcW: srcW };
    }

    // 音叉 + 悬挂的乒乓球（转换法：把微小的振动放大）
    function drawFork(st, b, disp, now) {
      var srcW = Math.min(b.w * (narrow ? 0.42 : 0.3), 260);
      var cx = b.x + srcW * 0.42, top = b.y + b.h * 0.18, h = b.h * 0.66, gap = clamp(h * 0.14, 12, 22);
      var d = disp * 4.5;
      ctx.strokeStyle = C.metal; ctx.lineWidth = 6; ctx.lineCap = 'round';
      var yb = top + h * 0.62;
      ctx.beginPath();
      ctx.moveTo(cx - gap - d, top); ctx.quadraticCurveTo(cx - gap - d * 0.4, yb - 4, cx - gap, yb);
      ctx.quadraticCurveTo(cx, yb + gap * 1.2, cx + gap, yb);
      ctx.quadraticCurveTo(cx + gap + d * 0.4, yb - 4, cx + gap + d, top);
      ctx.stroke();
      ctx.lineWidth = 5; line(cx, yb + gap * 0.6, cx, top + h);
      ctx.lineCap = 'butt';
      label(S.FORKS[st.fork].f.toFixed(S.FORKS[st.fork].f % 1 ? 1 : 0) + ' Hz', cx, top + h + 12, C.muted, 'center', 11);
      // 乒乓球：贴着右侧叉股悬挂，音叉振动时被弹开，振幅越大弹得越远
      var px = cx + gap + 3, hangX = px + 26, hangY = top - 22, ballR = 8;
      var kick = st.vib.on ? st.vib.a * 46 * Math.abs(Math.sin(now * 2.2)) : 0;
      var bx = px + ballR + kick, by = top + 16 - kick * 0.12;
      ctx.strokeStyle = C.muted; ctx.lineWidth = 1;
      line(hangX - 18, hangY, hangX + 18, hangY);
      line(hangX, hangY, bx, by - ballR);
      ctx.beginPath(); ctx.arc(bx, by, ballR, 0, TAU); ctx.fillStyle = '#f2f2ec'; ctx.fill();
      label('乒乓球', bx + 14, by + 16, C.muted, 'left', 11);
      if (!st.vib.on) label('点"敲击音叉"', cx, top - 12, C.accent, 'center', 11);
      geo.ruler = null;
      return { src: cx + gap + 92, cy: b.y + b.h * 0.42, srcW: srcW };
    }

    // 听者位置：距离 r 在 0.5～10 m 之间按对数映射到空气区域
    function listenerX(r, x0, x1) { return x0 + (x1 - x0) * (0.3 + 0.7 * Math.log(r / 0.5) / Math.log(20)); }

    function drawTone(st, now) {
      var L = layoutTone(), b = L.app, f = st.f;
      box(b.x, b.y, b.w, b.h, '');
      var fv = S.visFreq(f), disp = st.vib.on ? st.vib.a * Math.sin(st.phase) : 0;
      if (st.drag && st.drag.mode === 'pull') disp = st.drag.pull;
      var src = st.src === 'ruler' ? drawRuler(st, b, disp) : drawFork(st, b, disp, now);
      // ---- 空气粒子 ----
      var x0 = src.src, x1 = b.x + b.w - (narrow ? 44 : 64);
      var lx = listenerX(st.r, x0, x1);
      var lam = VV / fv;                                   // 动画中的波长 px
      var front = st.vib.on ? (now - st.vib.t0) * VV : -1;
      var rows = b.h < 260 ? 6 : narrow ? 7 : 9, gapY = clamp(b.h * 0.055, 8, 15), gapX = narrow ? 8 : 9;
      var cy = src.cy, yTop = cy - (rows - 1) / 2 * gapY;
      if (st.showAir) {
        ctx.fillStyle = 'rgba(79,195,247,0.85)';
        for (var x = x0 + 4, k = 0; x < x1 + 30; x += gapX, k++) {
          var dist = x - x0, dx = 0;
          if (dist < front) {
            dx = 1.25 * gapX * st.vib.at(now - dist / VV) * Math.sin(st.phase - TAU * dist / lam) / (1 + dist / 900);
          }
          for (var j = 0; j < rows; j++) {
            var jit = ((k * 7 + j * 13) % 5 - 2) * 0.6;
            ctx.beginPath(); ctx.arc(x + dx + jit * 0.4, yTop + j * gapY + jit, 1.7, 0, TAU); ctx.fill();
          }
        }
        // 标出一个密部和一个疏部
        if (front > lam * 1.2 && st.vib.on) {
          // 位移 ξ = A·sin(φ − kx)，相位 φ − kx = 2πm 处粒子从两侧向中间挤：密部
          var fr = st.phase / TAU, xd = x0 + (fr - Math.floor(fr)) * lam;
          while (xd < x0 + 20) xd += lam;
          if (xd < Math.min(front, x1) - 10) label('密部', xd, yTop - 11, C.blue, 'center', 11);
          var xs = xd + lam / 2;
          if (xs > Math.min(front, x1) - 10) xs = xd - lam / 2;
          if (xs > x0 + 10) label('疏部', xs, yTop - 11, C.muted, 'center', 11);
          if (lam < (x1 - x0) * 0.8 && xd + lam < Math.min(front, x1)) dimH(xd, xd + lam, yTop + (rows - 1) * gapY + 34, '波长 λ（示意）', C.blue);
        }
        label(narrow ? '空气（示意）' : '空气粒子（左右振动，形成疏密相间的声波，示意）', x0 + 6, b.y + 14, C.muted, 'left', 11, '', false);
      }
      // ---- 听者 + 话筒 ----
      var heard = S.band(f) === 'audible' && st.vib.on;
      ctx.fillStyle = '#334055'; rrect(lx - 4, cy - 10, 8, 20, 4); ctx.fill();
      ctx.strokeStyle = C.text; ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.arc(lx, cy - 10, 6, PI, TAU); ctx.stroke();
      var yBot = yTop + (rows - 1) * gapY;
      label('话筒', lx, yBot + 13, C.muted, 'center', 11);
      // 到示波器的导线
      ctx.strokeStyle = 'rgba(141,153,171,0.5)'; ctx.lineWidth = 1.2;
      ctx.beginPath(); ctx.moveTo(lx, cy + 10); ctx.bezierCurveTo(lx, b.y + b.h + 2, lx + 20, b.y + b.h - 6, lx + 10, L.scope.y + 4); ctx.stroke();
      // 距离标注
      var ydim = b.y + b.h - 14;
      dimH(src.src - 8, lx, ydim, '距离 ' + st.r.toFixed(st.r < 2 ? 1 : 0) + ' m', C.muted);
      // 人能否听到
      var dB = st.vib.on ? S.loudness(st.vib.a, st.r) : 0;
      var msg = !st.vib.on ? '' : S.band(f) === 'infra' ? '次声：人耳听不到' : Math.round(dB) + ' dB · ' + S.loudWord(dB);
      if (msg) label(msg, lx, Math.max(yTop - 30, b.y + 34), heard ? C.accent : C.red, 'center', 12, '600');
      // 慢放提示
      label('动画已放慢', b.x + b.w - 8, b.y + 14, C.muted, 'right', 11, '', false);

      drawScope(st, L.scope, now);
      drawFreqBar(st, L.freq);
    }

    // ---- 示波器：横轴时间（10 格），纵轴振幅（8 格，每格 0.25） ----
    function drawScope(st, b) {
      box(b.x, b.y, b.w, b.h, '');
      var padL = narrow ? 10 : 16, padT = 26, padB = 22;
      var gx = b.x + padL, gy = b.y + padT, gw = b.w - padL * 2, gh = b.h - padT - padB;
      label('示波器（话筒处空气的振动）', b.x + 10, b.y + 13, C.muted, 'left', 12, '600', false);
      ctx.fillStyle = C.screen; rrect(gx, gy, gw, gh, 6); ctx.fill();
      ctx.strokeStyle = 'rgba(126,224,129,0.13)'; ctx.lineWidth = 1;
      for (var i = 1; i < 10; i++) line(gx + gw * i / 10, gy, gx + gw * i / 10, gy + gh);
      for (var j = 1; j < 8; j++) line(gx, gy + gh * j / 8, gx + gw, gy + gh * j / 8);
      ctx.strokeStyle = 'rgba(126,224,129,0.3)'; line(gx, gy + gh / 2, gx + gw, gy + gh / 2);
      var win = st.ref ? st.ref.win : pickWindow(st.f);
      label('每格 ' + fmtMs(win / 10) + ' ms', gx + gw, b.y + 13, C.muted, 'right', 11, '', false, true);
      var yc = gy + gh / 2, ys = gh / 2 / 2;               // 满屏 ±2
      function trace(f, amp, key, color, dash, ph0) {
        ctx.save(); ctx.beginPath(); ctx.rect(gx, gy, gw, gh); ctx.clip();
        ctx.strokeStyle = color; ctx.lineWidth = dash ? 1.4 : 2; ctx.setLineDash(dash ? [5, 4] : []);
        ctx.beginPath();
        var n = Math.max(200, Math.min(1600, gw * 2));
        for (var k = 0; k <= n; k++) {
          var t = win / 1000 * k / n, y = yc - ys * amp * S.wave(key, TAU * f * t + ph0);
          k ? ctx.lineTo(gx + gw * k / n, y) : ctx.moveTo(gx + gw * k / n, y);
        }
        ctx.stroke(); ctx.restore();
      }
      if (st.ref) {
        trace(st.ref.f, st.ref.amp, st.ref.key, 'rgba(201,167,255,0.85)', true, 0);
        label('参考：' + st.ref.name, gx + 8, gy + 12, C.violet, 'left', 11, '', true);
      }
      var amp = st.vib.on ? S.ampAt(st.vib.a, st.r) : 0;
      var key = st.src === 'ruler' ? 'ruler' : 'fork';
      if (amp > 0.002) {
        trace(st.f, amp, key, C.trace, false, 0);
        // 标注：一个周期 T 和振幅 A
        var T = 1000 / st.f, px = gw * T / win;
        var x0 = gx + gw * (T * 0.25) / win;               // 第一个波峰
        if (px > 26 && x0 + px < gx + gw - 4) {
          var ytop = Math.max(gy + 10, yc - ys * amp - 12);
          var tt = '周期 T = ' + fmtMs(T) + ' ms';
          if (px >= 110) dimH(x0, x0 + px, ytop, tt, C.accent);
          else {                                           // 周期太短：文字写在箭头右边
            arrow((x0 + x0 + px) / 2, ytop, x0, ytop, C.accent, 4); arrow((x0 + x0 + px) / 2, ytop, x0 + px, ytop, C.accent, 4);
            label(tt, x0 + px + 6, ytop, C.accent, 'left', 11);
          }
        }
        if (ys * amp > 14) {
          var xa = gx + gw * Math.min(T * 1.25, win * 0.9) / win;
          if (px <= 26) xa = gx + gw - 30;
          arrow(xa, yc, xa, yc - ys * amp + 2, C.red, 5);
          label('振幅', xa + 6, yc - ys * amp / 2, C.red, 'left', 11);
        }
        if (amp > 2) label('超出屏幕：离得太近', gx + gw / 2, gy + 12, C.red, 'center', 11);
      } else {
        ctx.strokeStyle = C.trace; ctx.lineWidth = 2; line(gx, yc, gx + gw, yc);
        label(st.src === 'ruler' ? '拨动钢尺后这里显示声波的波形' : '敲击音叉后这里显示声波的波形', gx + gw / 2, yc - 14, C.muted, 'center', 12);
      }
      label('时间 →', gx + gw - 4, gy + gh + 11, C.muted, 'right', 11, '', false);
      label(narrow ? '每秒振动次数越多，波形越密，音调越高' : '同样的时间里波形越密（周期越短、频率越高）音调越高；波形越"高"（振幅越大）响度越大', gx, gy + gh + 11, C.muted, 'left', 11, '', false);
    }

    // ---- 听觉频率范围：对数横轴 1 Hz～200 kHz ----
    function drawFreqBar(st, b) {
      box(b.x, b.y, b.w, b.h, '');
      var padL = narrow ? 40 : 54, padR = narrow ? 10 : 18;
      var x0 = b.x + padL, x1 = b.x + b.w - padR, y0 = b.y + 24, y1 = b.y + b.h - 20;
      var lg0 = 0, lg1 = Math.log10(200000);
      function X(f) { return x0 + (x1 - x0) * (Math.log10(f) - lg0) / (lg1 - lg0); }
      // 三个区
      ctx.fillStyle = 'rgba(79,195,247,0.07)'; ctx.fillRect(x0, y0, X(20) - x0, y1 - y0);
      ctx.fillStyle = 'rgba(126,224,129,0.08)'; ctx.fillRect(X(20), y0, X(20000) - X(20), y1 - y0);
      ctx.fillStyle = 'rgba(201,167,255,0.08)'; ctx.fillRect(X(20000), y0, x1 - X(20000), y1 - y0);
      label('次声波', (x0 + X(20)) / 2, b.y + 12, C.blue, 'center', 11, '600', false);
      // "可听声"区名与当前频率标签重叠时，挪到标签的另一侧
      var aud = '可听声 20 Hz～20 kHz', ac = (X(20) + X(20000)) / 2, xf0 = X(st.f);
      font(11, '600'); var aw = ctx.measureText(aud).width;
      if (Math.abs(xf0 - ac) < aw / 2 + 40) ac = xf0 < ac ? xf0 + 40 + aw / 2 : xf0 - 40 - aw / 2;
      label(aud, ac, b.y + 12, C.green, 'center', 11, '600', false);
      label('超声波', (X(20000) + x1) / 2, b.y + 12, C.violet, 'center', 11, '600', false);
      // 动物听觉范围
      var n = S.HEARING.length, rh = (y1 - y0) / n;
      S.HEARING.forEach(function (h, i) {
        var y = y0 + rh * (i + 0.5), on = st.f >= h.lo && st.f <= h.hi && st.vib.on;
        label(h.name, x0 - 6, y, on ? C.text : C.muted, 'right', 11, '', false);
        ctx.fillStyle = on ? 'rgba(255,201,74,0.75)' : 'rgba(141,153,171,0.35)';
        rrect(X(h.lo), y - rh * 0.3, X(h.hi) - X(h.lo), rh * 0.6, 3); ctx.fill();
      });
      // 刻度
      ctx.strokeStyle = C.line; ctx.lineWidth = 1;
      [1, 10, 100, 1000, 10000, 100000].forEach(function (f) {
        var x = X(f); line(x, y1, x, y1 + 4);
        label(f >= 1000 ? f / 1000 + 'k' : String(f), x, y1 + 11, C.muted, 'center', 10, '', false);
      });
      label('Hz', x1, y1 + 11, C.muted, 'right', 10, '', false);
      // 当前频率
      var xf = X(st.f);
      ctx.strokeStyle = C.accent; ctx.lineWidth = 2; line(xf, y0 - 2, xf, y1);
      font(11, '700'); var tw = ctx.measureText(fmtHz(st.f)).width + 10;
      ctx.fillStyle = C.accent; rrect(clamp(xf - tw / 2, x0 - 4, x1 - tw), b.y + 4, tw, 16, 8); ctx.fill();
      label(fmtHz(st.f), clamp(xf, x0 - 4 + tw / 2, x1 - tw / 2), b.y + 12, '#111', 'center', 11, '700', false);
    }

    // ================= 场景二：音色 =================
    function drawTimbre(st, now) {
      var top = narrow ? 84 : 44, side = narrow ? 8 : 18, bot = 44;
      var aW = W - 2 * side, aH = H - top - bot;
      var head = narrow ? 40 : 34;
      label('音调相同（周期相同） · 响度相同（振幅相同） · ' + (st.tA === st.tB ? '音色相同（波形相同）' : '音色不同（波形形状不同）'),
        W / 2, top + 10, C.accent, 'center', narrow ? 11 : 13, '600');
      var ph = (aH - head - 10) / 2;
      [st.tA, st.tB].forEach(function (key, i) {
        drawTimbrePane(key, i, { x: side, y: top + head + i * (ph + 10), w: aW, h: ph }, st, now);
      });
    }
    function drawTimbrePane(key, idx, b, st, now) {
      var t = S.TIMBRES[key], col = AB[idx];
      box(b.x, b.y, b.w, b.h, '');
      label((idx ? '乙：' : '甲：') + t.name, b.x + 12, b.y + 15, col, 'left', 14, '700', false);
      var specW = narrow ? 0 : clamp(b.w * 0.3, 150, 300);
      var gx = b.x + 12, gy = b.y + 32, gw = b.w - 24 - (specW ? specW + 14 : 0), gh = b.h - 32 - (narrow ? 62 : 26);
      ctx.fillStyle = C.screen; rrect(gx, gy, gw, gh, 6); ctx.fill();
      ctx.strokeStyle = 'rgba(126,224,129,0.12)'; ctx.lineWidth = 1;
      for (var i = 1; i < 12; i++) line(gx + gw * i / 12, gy, gx + gw * i / 12, gy + gh);
      for (var j = 1; j < 4; j++) line(gx, gy + gh * j / 4, gx + gw, gy + gh * j / 4);
      var yc = gy + gh / 2, ys = gh / 2 * 0.8 * st.tAmp, cyc = 3, shift = st.tPhase;
      ctx.save(); ctx.beginPath(); ctx.rect(gx, gy, gw, gh); ctx.clip();
      if (st.harm && t.h.length > 1) {
        ctx.lineWidth = 1; ctx.globalAlpha = 0.55;
        t.h.forEach(function (hn, n) {
          if (!hn) return;
          ctx.strokeStyle = HCOL[n % HCOL.length]; ctx.beginPath();
          for (var k = 0; k <= 400; k++) {
            var y = yc - ys * S.harmonic(key, n, TAU * cyc * k / 400 + shift);
            k ? ctx.lineTo(gx + gw * k / 400, y) : ctx.moveTo(gx, y);
          }
          ctx.stroke();
        });
        ctx.globalAlpha = 1;
      }
      ctx.strokeStyle = col; ctx.lineWidth = 2.2; ctx.beginPath();
      for (var k2 = 0; k2 <= 600; k2++) {
        var y2 = yc - ys * S.wave(key, TAU * cyc * k2 / 600 + shift);
        k2 ? ctx.lineTo(gx + gw * k2 / 600, y2) : ctx.moveTo(gx, y2);
      }
      ctx.stroke(); ctx.restore();
      // 周期与振幅标注（两幅图位置一致，便于对比）
      dimH(gx + gw / 3, gx + gw * 2 / 3, gy + 11, '一个周期', C.muted);
      ctx.setLineDash([3, 3]); ctx.strokeStyle = 'rgba(255,122,89,0.6)'; ctx.lineWidth = 1;
      line(gx, yc - ys, gx + gw, yc - ys); line(gx, yc + ys, gx + gw, yc + ys); ctx.setLineDash([]);
      label('振幅', gx + gw - 4, yc - ys - 8, C.red, 'right', 11);
      // 泛音柱状图
      var sx, sy, sw, sh;
      if (specW) { sx = b.x + b.w - specW - 12; sy = gy; sw = specW; sh = gh; }
      else { sx = gx; sy = gy + gh + 8; sw = gw; sh = 50; }
      drawSpectrum(key, sx, sy, sw, sh, col);
      if (!narrow) label(t.note, gx, b.y + b.h - 12, C.muted, 'left', 12, '', false);
    }
    function drawSpectrum(key, x, y, w, h, col) {
      var t = S.TIMBRES[key], n = 10, bw = w / n, hb = h - 26;
      label('基音和泛音（相对强弱）', x, y + 7, C.muted, 'left', 11, '', false);
      ctx.strokeStyle = C.line; ctx.lineWidth = 1; line(x, y + h - 12, x + w, y + h - 12);
      for (var i = 0; i < n; i++) {
        var v = t.h[i] || 0, bh = hb * v;
        if (v) {
          ctx.fillStyle = i ? HCOL[i % HCOL.length] : col; ctx.globalAlpha = i ? 0.8 : 1;
          ctx.fillRect(x + bw * i + bw * 0.18, y + h - 12 - bh, bw * 0.64, bh); ctx.globalAlpha = 1;
        }
        label(i ? String(i + 1) : '基', x + bw * (i + 0.5), y + h - 4, C.muted, 'center', 10, '', false);
      }
    }

    // ================= 场景三：波形判断练习 =================
    function drawQuiz(st) {
      var q = st.quiz.q; if (!q) return;
      var top = narrow ? 84 : 44, side = narrow ? 8 : 18, bot = 44;
      var aW = W - 2 * side, aH = H - top - bot;
      label('两段声音的波形（横轴时间、纵轴振幅，坐标的比例相同）', W / 2, top + 10, C.muted, 'center', narrow ? 11 : 13, '600', false);
      var ph = (aH - 30 - 10) / 2;
      [q.a, q.b].forEach(function (w, i) {
        var b = { x: side, y: top + 30 + i * (ph + 10), w: aW, h: ph };
        box(b.x, b.y, b.w, b.h, '');
        label(i ? '乙' : '甲', b.x + 14, b.y + 16, AB[i], 'left', 15, '700', false);
        var gx = b.x + 36, gy = b.y + 10, gw = b.w - 50, gh = b.h - 20;
        ctx.fillStyle = C.screen; rrect(gx, gy, gw, gh, 6); ctx.fill();
        ctx.strokeStyle = 'rgba(126,224,129,0.13)'; ctx.lineWidth = 1;
        for (var k = 1; k < 16; k++) line(gx + gw * k / 16, gy, gx + gw * k / 16, gy + gh);
        for (var j = 1; j < 6; j++) line(gx, gy + gh * j / 6, gx + gw, gy + gh * j / 6);
        var yc = gy + gh / 2, ys = gh / 6 * 2 * w.amp;     // 纵向 6 格：振幅 1 → 2 格，0.5 → 1 格
        ctx.strokeStyle = AB[i]; ctx.lineWidth = 2.2; ctx.beginPath();
        for (var m = 0; m <= 800; m++) {
          var y = yc - ys * S.wave(w.tim, TAU * w.cyc * m / 800);
          m ? ctx.lineTo(gx + gw * m / 800, y) : ctx.moveTo(gx, y);
        }
        ctx.stroke();
        if (st.quiz.checked) {
          var tag = '同样时间内 ' + w.cyc + ' 个周期 · 振幅 ' + (w.amp === 1 ? '2' : '1') + ' 格 · ' + S.TIMBRES[w.tim].name;
          label(tag, gx + gw - 8, gy + 14, C.text, 'right', 12, '600');
          // 标一个周期
          var px = gw / w.cyc;
          ctx.setLineDash([3, 3]); ctx.strokeStyle = 'rgba(255,201,74,0.6)';
          line(gx + px, gy, gx + px, gy + gh); ctx.setLineDash([]);
        }
      });
    }

    function draw(st, now) {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, W, H);
      ctx.fillStyle = '#05070d'; ctx.fillRect(0, 0, W, H);
      if (st.scene === 'tone') drawTone(st, now);
      else if (st.scene === 'timbre') drawTimbre(st, now);
      else drawQuiz(st);
    }

    return { resize: resize, draw: draw, geo: function () { return geo; }, pickWindow: pickWindow };
  }

  window.SoundDraw = SoundDraw;
  window.SoundDraw.pickWindow = pickWindow;
})();
