(function () {
  var S = window.Sound, A = window.SoundAudio;
  var $ = function (id) { return document.getElementById(id); };
  var qa = function (sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); };

  var NOTES = [{ name: 'do', f: 262 }, { name: 'mi', f: 330 }, { name: 'sol', f: 392 }, { name: 'la', f: 440 }, { name: 'do¹', f: 523 }];
  var TAU_DECAY = { ruler: 1.6, fork: 5 };    // 振动减弱的时间常数 s

  var state = {
    scene: 'tone',
    src: 'ruler', L: 10, fork: 0, force: 0.6, r: 1, decay: false, showAir: true, sound: false,
    f: 0, phase: 0, vib: null, drag: null, ref: null,
    tA: 'piano', tB: 'violin', note: 3, tAmp: 0.85, harm: false, tPhase: 0,
    quiz: { q: null, pick: {}, checked: false, right: 0, total: 0 },
    now: 0
  };

  var stage = $('stage'), canvas = $('snd'), panel = $('panel');
  var view = window.SoundDraw(canvas);

  function setSeg(attr, val, root) {
    qa((root || '') + ' [data-' + attr + ']').forEach(function (b) { b.classList.toggle('on', b.dataset[attr] === String(val)); });
  }
  function fmtHz(f) { return f >= 100 ? f.toFixed(0) + ' Hz' : f.toFixed(1) + ' Hz'; }
  function srcName() { return state.src === 'ruler' ? '钢尺' : S.FORKS[state.fork].f.toFixed(S.FORKS[state.fork].f % 1 ? 1 : 0) + ' Hz 音叉'; }
  function curFreq() { return state.src === 'ruler' ? S.rulerFreq(state.L) : S.FORKS[state.fork].f; }

  // ---------- 振动：开始时间 t0、初始振幅 a0；勾选"逐渐减弱"时按指数衰减 ----------
  function makeVib(a0, on) {
    var v = { on: on, a0: a0, a: on ? a0 : 0, t0: state.now, decay: state.decay, tau: TAU_DECAY[state.src] };
    v.at = function (t) {
      if (!v.on || t < v.t0) return 0;
      return v.decay ? v.a0 * Math.exp(-(t - v.t0) / v.tau) : v.a0;
    };
    return v;
  }
  function pluck(a0, phase) {
    state.vib = makeVib(a0 == null ? state.force : a0, true);
    state.phase = phase == null ? 0 : phase;
    Analytics.track('声音的特性', state.src === 'ruler' ? '拨动钢尺' : '敲击音叉', srcName());
    syncPanel();
  }
  function stop() { state.vib = makeVib(0, false); syncPanel(); }

  // ---------- 场景 ----------
  function setScene(sc) {
    state.scene = sc;
    if (sc === 'quiz' && !state.quiz.q) newQuiz();
    Analytics.track('声音的特性', '场景', sc);
    syncPanel();
  }
  qa('[data-scene]').forEach(function (b) { b.addEventListener('click', function () { setScene(b.dataset.scene); }); });

  // ---------- 场景一控件 ----------
  qa('[data-src]').forEach(function (b) {
    b.addEventListener('click', function () {
      if (state.src === b.dataset.src) return;
      state.src = b.dataset.src; state.vib = makeVib(0, false); state.ref = null;
      syncPanel();
    });
  });
  $('forks').innerHTML = S.FORKS.map(function (fk, i) {
    return '<button data-fork="' + i + '"><b>' + fk.name + '</b><small>' + fk.f.toFixed(fk.f % 1 ? 1 : 0) + '</small></button>';
  }).join('');
  qa('[data-fork]').forEach(function (b) {
    b.addEventListener('click', function () { state.fork = +b.dataset.fork; pluck(); });
  });
  $('len').addEventListener('input', function () { state.L = +$('len').value; syncPanel(); });
  $('force').addEventListener('input', function () {
    state.force = +$('force').value;
    if (state.vib.on && !state.vib.decay) { state.vib.a0 = state.force; }
    syncPanel();
  });
  $('dist').addEventListener('input', function () { state.r = +$('dist').value; syncPanel(); });
  $('pluckBtn').addEventListener('click', function () { pluck(); });
  $('stopBtn').addEventListener('click', stop);
  $('refBtn').addEventListener('click', function () {
    if (state.ref) { state.ref = null; }
    else if (state.vib.on) {
      state.ref = { f: state.f, amp: S.ampAt(state.vib.a, state.r), key: state.src === 'ruler' ? 'ruler' : 'fork',
        win: view.pickWindow(state.f), name: srcName() + (state.src === 'ruler' ? ' ' + state.L + ' cm' : '') + ' · ' + fmtHz(state.f) };
      Analytics.track('声音的特性', '参考波形');
    }
    syncPanel();
  });
  $('decay').addEventListener('change', function () {
    state.decay = $('decay').checked;
    if (state.vib.on) pluck(state.vib.a, state.phase);
  });
  $('air').addEventListener('change', function () { state.showAir = $('air').checked; });

  // 拖动钢尺端点：左右改伸出长度，上下拨动后松手开始振动
  function ptr(e) { var r = canvas.getBoundingClientRect(); return { x: e.clientX - r.left, y: e.clientY - r.top }; }
  canvas.addEventListener('pointerdown', function (e) {
    var g = view.geo().ruler;
    if (state.scene !== 'tone' || state.src !== 'ruler' || !g) return;
    var p = ptr(e), d = Math.hypot(p.x - g.tip.x, p.y - g.tip.y);
    if (d > 26) return;
    state.drag = { mode: null, x0: p.x, y0: p.y, L0: state.L, pull: 0, s: g.s };
    state.vib = makeVib(0, false);
    canvas.setPointerCapture(e.pointerId);
    e.preventDefault();
  });
  canvas.addEventListener('pointermove', function (e) {
    var dr = state.drag; if (!dr) return;
    var p = ptr(e), dx = p.x - dr.x0, dy = p.y - dr.y0;
    if (!dr.mode && Math.hypot(dx, dy) > 6) dr.mode = Math.abs(dx) > Math.abs(dy) ? 'len' : 'pull';
    if (dr.mode === 'len') {
      state.L = Math.round(Math.max(S.RULER.Lmin, Math.min(S.RULER.Lmax, dr.L0 + dx / dr.s)) * 2) / 2;
      syncPanel();
    } else if (dr.mode === 'pull') {
      dr.pull = Math.max(-1, Math.min(1, -dy / 40));
    }
  });
  function endDrag() {
    var dr = state.drag; if (!dr) return;
    state.drag = null;
    if (dr.mode === 'pull' && Math.abs(dr.pull) > 0.08) {
      state.force = Math.round(Math.abs(dr.pull) * 20) / 20;
      pluck(Math.abs(dr.pull), dr.pull > 0 ? Math.PI / 2 : -Math.PI / 2);
    } else syncPanel();
  }
  canvas.addEventListener('pointerup', endDrag);
  canvas.addEventListener('pointercancel', endDrag);
  canvas.addEventListener('pointermove', function (e) {
    var g = view.geo().ruler;
    var near = state.scene === 'tone' && state.src === 'ruler' && g && !state.drag &&
      Math.hypot(ptr(e).x - g.tip.x, ptr(e).y - g.tip.y) < 26;
    canvas.style.cursor = state.drag ? 'grabbing' : near ? 'grab' : '';
  });

  // ---------- 场景二控件 ----------
  qa('.tims').forEach(function (box) {
    var side = box.dataset.side;
    box.innerHTML = S.TIMBRE_KEYS.map(function (k) { return '<button data-tim="' + k + '">' + S.TIMBRES[k].name + '</button>'; }).join('');
    qa('.tims[data-side="' + side + '"] [data-tim]').forEach(function (b) {
      b.addEventListener('click', function () {
        state['t' + side] = b.dataset.tim;
        if (state.sound) playTimbre(side);
        Analytics.track('声音的特性', '音色', S.TIMBRES[b.dataset.tim].name);
        syncPanel();
      });
    });
  });
  $('notes').innerHTML = NOTES.map(function (n, i) { return '<button data-note="' + i + '">' + n.name + '</button>'; }).join('');
  qa('[data-note]').forEach(function (b) {
    b.addEventListener('click', function () { state.note = +b.dataset.note; syncPanel(); });
  });
  $('tAmp').addEventListener('input', function () { state.tAmp = +$('tAmp').value; syncPanel(); });
  $('harm').addEventListener('change', function () { state.harm = $('harm').checked; });
  function playTimbre(side) { A.note(state['t' + side], NOTES[state.note].f, state.tAmp * 1.2, 1.4); }
  $('playA').addEventListener('click', function () { playTimbre('A'); });
  $('playB').addEventListener('click', function () { playTimbre('B'); });

  // ---------- 场景三：练习 ----------
  function newQuiz() {
    state.quiz.q = S.quiz();
    state.quiz.pick = {}; state.quiz.checked = false;
    $('quizMsg').textContent = '看两幅波形，分别判断音调、响度、音色，然后点"检查答案"。';
    syncPanel();
  }
  qa('[data-q]').forEach(function (grp) {
    var key = grp.dataset.q;
    qa('[data-q="' + key + '"] button').forEach(function (b) {
      b.addEventListener('click', function () {
        if (state.quiz.checked) return;
        state.quiz.pick[key] = +b.dataset.v; syncPanel();
      });
    });
  });
  $('checkBtn').addEventListener('click', function () {
    var qz = state.quiz, q = qz.q, pk = qz.pick;
    if (qz.checked) return;
    if (pk.pitch == null || pk.loud == null || pk.timbre == null) { $('quizMsg').textContent = '三项都选好再检查。'; return; }
    qz.checked = true; qz.total++;
    var ok = pk.pitch === q.ans.pitch && pk.loud === q.ans.loud && pk.timbre === q.ans.timbre;
    if (ok) qz.right++;
    var why = [
      '音调：同样时间内甲有 ' + q.a.cyc + ' 个波、乙有 ' + q.b.cyc + ' 个波' + (q.ans.pitch ? '，' + (q.ans.pitch > 0 ? '甲' : '乙') + '的频率高、音调高' : '，频率相同、音调相同'),
      '响度：' + (q.ans.loud ? (q.ans.loud > 0 ? '甲' : '乙') + '的振幅大、响度大' : '振幅相同、响度相同'),
      '音色：波形形状' + (q.ans.timbre ? '不同（甲是' + S.TIMBRES[q.a.tim].name + '，乙是' + S.TIMBRES[q.b.tim].name + '）' : '相同') + '，音色' + (q.ans.timbre ? '不同' : '相同')
    ];
    $('quizMsg').innerHTML = (ok ? '<b class="ok">✓ 全对！</b>' : '<b class="bad">✗ 有错，看看正确答案：</b>') + '<br>' + why.join('<br>');
    Analytics.track('声音的特性', '练习', ok ? '对' : '错');
    syncPanel();
  });
  $('nextBtn').addEventListener('click', newQuiz);
  function playQuiz(w) { A.note(w.tim, 110 * w.cyc, w.amp * 1.1, 1.2); }
  $('qPlayA').addEventListener('click', function () { playQuiz(state.quiz.q.a); });
  $('qPlayB').addEventListener('click', function () { playQuiz(state.quiz.q.b); });

  // ---------- 声音开关 ----------
  $('sound').addEventListener('change', function () {
    state.sound = $('sound').checked;
    if (state.sound) { A.ensure(); Analytics.track('声音的特性', '播放声音'); }
    syncPanel();
  });

  // ---------- 面板 ----------
  var HINTS = {
    tone: '拨动钢尺：伸出越短音调越高，拨得越用力响度越大',
    timbre: '音调、响度相同，波形形状不同 → 音色不同',
    quiz: '看波形：疏密比音调，高低比响度，形状比音色'
  };
  function syncPanel() {
    var sc = state.scene, f = curFreq();
    state.f = f;
    setSeg('scene', sc);
    $('toneOut').hidden = $('toneBox').hidden = sc !== 'tone';
    $('timbreBox').hidden = sc !== 'timbre';
    $('quizBox').hidden = sc !== 'quiz';
    $('hint').textContent = state.src === 'fork' && sc === 'tone' ? '敲击音叉：换不同的音叉比较音调，敲得越重响度越大' : HINTS[sc];

    // 场景一
    setSeg('src', state.src);
    setSeg('fork', state.fork);
    var ruler = state.src === 'ruler';
    $('rowL').hidden = !ruler; $('forks').hidden = ruler;
    $('len').value = state.L; $('lenOut').textContent = state.L.toFixed(1) + ' cm';
    $('force').value = state.force; $('forceOut').textContent = Math.round(state.force * 100) + '%';
    $('forceName').textContent = ruler ? '拨动力度' : '敲击力度';
    $('dist').value = state.r; $('distOut').textContent = state.r.toFixed(1) + ' m';
    $('pluckBtn').textContent = ruler ? '🎵 拨动钢尺' : '🎵 敲击音叉';
    $('refBtn').textContent = state.ref ? '✕ 清除参考波形' : '📌 保存为参考波形';
    $('refBtn').disabled = !state.ref && !state.vib.on;
    $('stopBtn').disabled = !state.vib.on;
    $('decay').checked = state.decay; $('air').checked = state.showAir;
    $('toneNote').textContent = ruler
      ? '也可以直接在画面上拖动钢尺的端点：左右拖改变伸出长度，向上或向下拉后松手就拨动了。'
      : '音叉上标的数字就是它的频率。乒乓球被弹开，说明发声的音叉在振动。';

    $('rName').textContent = srcName();
    var band = S.band(f);
    $('rKind').textContent = S.bandName(f);
    $('rKind').className = 'kind ' + band;
    $('rF').textContent = fmtHz(f) + '（每秒振动 ' + (f >= 100 ? Math.round(f) : f.toFixed(1)) + ' 次）';
    var T = 1000 / f;
    $('rT').textContent = (T >= 10 ? T.toFixed(1) : T.toFixed(2)) + ' ms';
    var lam = S.wavelength(f);
    $('rLam').textContent = lam.toFixed(lam >= 10 ? 1 : 2) + ' m（声速 340 m/s）';
    $('rPitch').textContent = S.pitchWord(f);
    lastLive = '';

    // 场景二
    setSeg('tim', state.tA, '.tims[data-side="A"]');
    setSeg('tim', state.tB, '.tims[data-side="B"]');
    setSeg('note', state.note);
    $('tAmp').value = state.tAmp; $('tAmpOut').textContent = Math.round(state.tAmp * 100) + '%';
    $('playA').textContent = '▶ 听甲：' + S.TIMBRES[state.tA].name;
    $('playB').textContent = '▶ 听乙：' + S.TIMBRES[state.tB].name;
    $('playA').disabled = $('playB').disabled = !state.sound;
    $('timbreNote').innerHTML = '<b style="color:#ffc94a">甲</b> ' + S.TIMBRES[state.tA].note + '<br><b style="color:#4fc3f7">乙</b> ' + S.TIMBRES[state.tB].note;

    // 场景三
    var qz = state.quiz;
    ['pitch', 'loud', 'timbre'].forEach(function (k) {
      qa('[data-q="' + k + '"] button').forEach(function (b) {
        var v = +b.dataset.v;
        b.classList.toggle('on', qz.pick[k] === v);
        b.classList.toggle('right', qz.checked && qz.q.ans[k] === v);
        b.classList.toggle('wrong', qz.checked && qz.pick[k] === v && qz.q.ans[k] !== v);
      });
    });
    $('score').textContent = qz.total ? '答对 ' + qz.right + ' / ' + qz.total + ' 题' : '';
    $('checkBtn').disabled = qz.checked;
    $('qPlayA').disabled = $('qPlayB').disabled = !state.sound;
  }

  // 每帧变化的读数（只在文字变化时写 DOM）
  var lastLive = '';
  function syncLive() {
    if (state.scene !== 'tone') return;
    var v = state.vib, dB = v.on ? S.loudness(v.a, state.r) : 0, f = state.f;
    var who = v.on ? S.hearers(f) : [];
    var proc = state.drag && state.drag.mode === 'pull' ? '松手后钢尺开始振动'
      : !v.on ? (state.src === 'ruler' ? '钢尺静止：不振动，不发声' : '音叉静止：不振动，不发声')
      : S.band(f) === 'infra' ? '在振动，但频率低于 20 Hz，是次声，人耳听不到'
      : '正在振动发声' + (v.decay ? '，振幅逐渐减小，声音越来越轻' : '');
    var sig = [Math.round(dB), who.join(), proc].join('|');
    if (sig === lastLive) return;
    lastLive = sig;
    $('rLoud').textContent = v.on ? (S.band(f) === 'audible' ? Math.round(dB) + ' dB，' + S.loudWord(dB) : '人耳听不到') : '无声';
    $('rWho').textContent = who.length ? who.join('、') : '—';
    $('rProc').textContent = proc;
    $('stopBtn').disabled = !v.on;
    $('refBtn').disabled = !state.ref && !v.on;
  }

  // ---------- 面板开合 ----------
  $('panelToggle').addEventListener('click', function () { panel.classList.toggle('collapsed'); });
  if (window.matchMedia('(max-width: 760px)').matches) panel.classList.add('collapsed');
  if (window.matchMedia('(max-width: 640px)').matches) $('hint').hidden = true;

  // ---------- 尺寸与主循环 ----------
  function resize() { view.resize(stage.clientWidth, stage.clientHeight); }
  new ResizeObserver(resize).observe(stage);
  resize();

  // 支持 ?scene=tone|timbre|quiz、&src=ruler|fork
  var qs = new URLSearchParams(location.search);
  if (/^(tone|timbre|quiz)$/.test(qs.get('scene'))) state.scene = qs.get('scene');
  if (/^(ruler|fork)$/.test(qs.get('src'))) state.src = qs.get('src');
  state.vib = makeVib(state.force, true);           // 打开页面时发声体已在振动，便于直接看到波形
  if (state.scene === 'quiz') newQuiz();
  syncPanel();

  document.addEventListener('keydown', function (e) {
    if (/INPUT|SELECT|TEXTAREA|BUTTON/.test(e.target.tagName)) return;
    if (e.key === ' ' && state.scene === 'tone') { e.preventDefault(); state.vib.on ? stop() : pluck(); }
  });

  var lastT = performance.now();
  function frame(t) {
    var dt = Math.min((t - lastT) / 1000, 0.1);
    lastT = t;
    state.now += dt;
    var v = state.vib;
    if (v.on) {
      v.a = v.at(state.now);
      if (v.decay && v.a < 0.01) { state.vib = makeVib(0, false); syncPanel(); }
    }
    state.phase += Math.PI * 2 * S.visFreq(state.f) * dt;
    state.tPhase -= dt * 0.6;
    A.setTone(state.sound && state.scene === 'tone' && state.vib.on, state.f, state.src === 'ruler' ? 'ruler' : 'fork', S.ampAt(state.vib.a, state.r));
    syncLive();
    view.draw(state, state.now);
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // 调试用
  window.__model = { state: state, view: view, pluck: pluck, stop: stop, setScene: setScene, newQuiz: newQuiz, sync: syncPanel, S: S };
})();
