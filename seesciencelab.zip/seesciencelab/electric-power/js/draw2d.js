(function () {
  'use strict';
  const C={text:'#e6edf5',muted:'#8e9fb5',wire:'#638da6',gold:'#ffc94a',blue:'#69cfff'};
  function render(canvas,s,q){
    const w=canvas.clientWidth,h=canvas.clientHeight,d=devicePixelRatio||1;
    if(canvas.width!==Math.round(w*d)||canvas.height!==Math.round(h*d)){canvas.width=Math.round(w*d);canvas.height=Math.round(h*d);}
    const wide=w>650, W=wide?720:480,H=wide?650:700;
    const scale=Math.min((w-16)/W,(h-110)/H),ox=(w-W*scale)/2,oy=78+Math.max(0,(h-110-H*scale)/2);
    const ctx=canvas.getContext('2d');ctx.setTransform(d,0,0,d,0,0);ctx.fillStyle='#05070d';ctx.fillRect(0,0,w,h);
    const bg=ctx.createRadialGradient(w/2,h*.42,0,w/2,h*.42,w*.65);bg.addColorStop(0,'#111c2a');bg.addColorStop(1,'#05070d');ctx.fillStyle=bg;ctx.fillRect(0,0,w,h);
    ctx.translate(ox,oy);ctx.scale(scale,scale);
    function text(t,x,y,size=14,color=C.text,align='center'){ctx.fillStyle=color;ctx.font=`${size}px -apple-system,"PingFang SC",sans-serif`;ctx.textAlign=align;ctx.fillText(t,x,y);}
    function path(points,color=C.wire,width=3){ctx.beginPath();points.forEach((p,i)=>i?ctx.lineTo(...p):ctx.moveTo(...p));ctx.strokeStyle=color;ctx.lineWidth=width;ctx.lineJoin='round';ctx.lineCap='round';ctx.stroke();}
    function rect(x,y,w,h,fill,stroke,r=12){ctx.beginPath();ctx.roundRect(x,y,w,h,r);ctx.fillStyle=fill;ctx.fill();if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=1;ctx.stroke();}}
    const left=wide?145:112,right=wide?575:368,xs=q.scene==='single'?[W/2]:[left+28,right-28];
    const switchX=W-55,baseY=278,topY=81,bottomY=310,powerY=wide?430:455;
    // 完整线路在灯泡后方绘制，正负端通过独立导线与灯座相连。
    rect(20,28,W-40,366,'#0b111c','#233044',18);
    ctx.fillStyle='#233044';for(let x=36;x<W-30;x+=24)for(let y=44;y<380;y+=24){ctx.beginPath();ctx.arc(x,y,.65,0,Math.PI*2);ctx.fill();}
    text(q.scene==='series'?'串联 · 电流相同':q.scene==='parallel'?'并联 · 两端电压相同':'单灯 · 改变两端电压',38,54,13,C.muted,'left');
    const supplyX=76;
    if(q.scene==='series'){
      path([[supplyX,powerY],[supplyX,topY],[xs[0]-28,topY],[xs[0]-28,baseY]]);
      path([[xs[0]+28,baseY],[xs[0]+28,topY],[xs[1]-28,topY],[xs[1]-28,baseY]]);
      path([[xs[1]+28,baseY],[xs[1]+28,bottomY],[switchX-19,bottomY]]);
    }else{
      path([[supplyX,powerY],[supplyX,topY],[xs[xs.length-1]-28,topY]]);
      xs.forEach(x=>{path([[x-28,topY],[x-28,baseY]]);path([[x+28,baseY],[x+28,bottomY]]);});
      path([[xs[0]+28,bottomY],[switchX-19,bottomY]]);
    }
    path([[switchX+17,bottomY],[W-24,bottomY],[W-24,powerY-18],[164,powerY-18],[164,powerY]]);
    // 开关有独立底座与足够触摸范围。
    rect(switchX-33,bottomY-29,69,62,s.hover==='switch'?'#273449':'#142033','#33475e',9);
    path([[switchX-19,bottomY],[switchX+17,q.closed?bottomY:bottomY-23]],q.closed?C.gold:C.muted,4);
    for(const x of [switchX-19,switchX+17]){ctx.beginPath();ctx.arc(x,bottomY,4,0,Math.PI*2);ctx.fillStyle=C.gold;ctx.fill();}
    text(q.closed?'闭合':'断开',switchX,bottomY+23,11,C.muted);
    q.bulbs.forEach((b,i)=>{
      const x=xs[i],y=192,bright=Math.min(b.P/6,1),selected=s.selected===i;
      const glow=ctx.createRadialGradient(x,y,6,x,y,98);glow.addColorStop(0,`rgba(255,209,100,${bright*.7})`);glow.addColorStop(.45,`rgba(255,178,60,${bright*.23})`);glow.addColorStop(1,'rgba(255,170,60,0)');ctx.fillStyle=glow;ctx.fillRect(x-98,y-98,196,196);
      ctx.beginPath();ctx.moveTo(x-19,245);ctx.bezierCurveTo(x-18,227,x-46,224,x-46,190);ctx.bezierCurveTo(x-46,133,x+46,133,x+46,190);ctx.bezierCurveTo(x+46,224,x+18,227,x+19,245);ctx.closePath();
      const glass=ctx.createLinearGradient(x-46,0,x+46,0);glass.addColorStop(0,'rgba(157,194,221,.15)');glass.addColorStop(.4,`rgba(255,220,145,${.025+bright*.22})`);glass.addColorStop(1,'rgba(157,194,221,.12)');ctx.fillStyle=glass;ctx.fill();ctx.strokeStyle=s.hover==='bulb'+i?C.gold:'#8295a7';ctx.lineWidth=1.8;ctx.stroke();
      ctx.beginPath();ctx.ellipse(x-24,y-11,6,19,.35,0,Math.PI*2);ctx.strokeStyle='#c5d9e5';ctx.lineWidth=2;ctx.stroke();
      path([[x-12,245],[x-12,196],[x-20,188]],'#81909e',1.6);path([[x+12,245],[x+12,196],[x+20,188]],'#81909e',1.6);
      const filament=[];for(let j=0;j<=32;j++)filament.push([x-20+j*40/32,188+Math.sin(j*Math.PI/2)*4]);
      ctx.shadowColor='#ffb83f';ctx.shadowBlur=bright*18;ctx.globalAlpha=b.P?.3+bright*.7:1;path(filament,b.P?`rgb(255,${Math.round(95+bright*148)},${Math.round(35+bright*150)})`:'#5c6572',3);ctx.shadowBlur=0;ctx.globalAlpha=1;
      const metal=ctx.createLinearGradient(x-22,0,x+22,0);metal.addColorStop(0,'#3d4b5c');metal.addColorStop(.45,'#b8c2cd');metal.addColorStop(1,'#465365');rect(x-22,245,44,23,metal,null,3);
      for(let yy=250;yy<268;yy+=5)path([[x-21,yy],[x+21,yy-3]],'#425063',2);
      rect(x-37,269,74,21,'#94a2b1','#c4ced4',5);path([[x-28,baseY],[x-12,268]],'#d3d6ca',2);path([[x+28,baseY],[x+12,268]],'#d3d6ca',2);
      for(const xx of [x-28,x+28]){ctx.beginPath();ctx.arc(xx,baseY,4,0,Math.PI*2);ctx.fillStyle=C.gold;ctx.fill();}
      rect(x-68,98,136,28,selected?'#202b38':'#111a27',selected?'#697789':'#2b384a',7);
      text(`${b.name}   ${b.ratedU} V / ${b.ratedP} W`,x,117,13,C.gold);
      text(`${b.P.toFixed(2)} W`,x,350,23,b.ratio>1?'#ff9d83':C.text);
      text(`${b.U.toFixed(2)} V  ·  ${b.I.toFixed(2)} A`,x,373,12,C.muted);
      text(b.status,x,302,11,b.ratio>1?'#ff9d83':C.muted);
    });
    // 电源旋钮的角度编码电压，亮度直接使用实际功率，不叠加装饰脉动。
    rect(24,powerY,W-48,103,'#141f2d','#3c4d62',13);
    text('+',76,powerY-6,15,C.gold);text('−',164,powerY-6,15,C.blue);
    rect(40,powerY+15,149,72,'#070e16','#31465b',7);
    text('直流电源 / DC',52,powerY+34,11,C.muted,'left');text(`${q.U.toFixed(1)} V`,175,powerY+65,27,'#a8e7d4','right');
    const knob={x:wide?W-190:260,y:powerY+51,r:31};
    for(let i=0;i<=12;i++){const a=(-135+i/12*270)*Math.PI/180;path([[knob.x+Math.sin(a)*38,knob.y-Math.cos(a)*38],[knob.x+Math.sin(a)*41,knob.y-Math.cos(a)*41]],i<=q.U?C.gold:'#48566a',1.5);}
    const knobFill=ctx.createLinearGradient(0,knob.y-30,0,knob.y+30);knobFill.addColorStop(0,s.drag||s.hover==='knob'?'#65778b':'#39495c');knobFill.addColorStop(1,'#182333');ctx.beginPath();ctx.arc(knob.x,knob.y,29,0,Math.PI*2);ctx.fillStyle=knobFill;ctx.fill();ctx.strokeStyle='#718095';ctx.lineWidth=1.5;ctx.stroke();
    const angle=(-135+q.U/12*270)*Math.PI/180;path([[knob.x+Math.sin(angle)*13,knob.y-Math.cos(angle)*13],[knob.x+Math.sin(angle)*23,knob.y-Math.cos(angle)*23]],C.gold,3);
    text('0',knob.x-34,knob.y+43,10,C.muted);text('12 V',knob.x+37,knob.y+43,10,C.muted);
    text('左右拖动',W-85,powerY+46,12);text('调节电压',W-85,powerY+65,11,C.muted);
    const barY=powerY+137,barW=W-170;
    text('实际功率对照',30,barY-8,13,C.muted,'left');text('共用 0–12 W 标尺',W-30,barY-8,11,C.muted,'right');
    q.bulbs.forEach((b,i)=>{const y=barY+15+i*28;text(b.name,34,y+4,13,i?C.blue:C.gold);rect(55,y-6,barW,10,'#1d2939',null,5);rect(55,y-6,Math.max(.1,Math.min(barW,b.P/12*barW)),10,i?C.blue:C.gold,null,5);text(`${b.P.toFixed(2)} W`,W-30,y+4,13,C.text,'right');});
    return{scale,ox,oy,knob,bulbs:xs.map(x=>({x,y:192})),switch:{x:switchX,y:bottomY}};
  }
  function point(e,canvas,g){const r=canvas.getBoundingClientRect();return{x:(e.clientX-r.left-g.ox)/g.scale,y:(e.clientY-r.top-g.oy)/g.scale};}
  function hit(p,g){if(Math.hypot(p.x-g.knob.x,p.y-g.knob.y)<Math.max(43,24/g.scale))return'knob';if(Math.hypot(p.x-g.switch.x,p.y-g.switch.y)<Math.max(32,24/g.scale))return'switch';const i=g.bulbs.findIndex(b=>Math.hypot(p.x-b.x,p.y-b.y)<62);return i<0?'':'bulb'+i;}
  window.PowerDraw={render,point,hit};
}());
