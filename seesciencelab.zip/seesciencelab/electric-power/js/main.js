(function () {
  'use strict';
  const $=id=>document.getElementById(id), u=new URLSearchParams(location.search);
  const state={...Power.clean({scene:u.get('scene'),U:u.get('U')??undefined,closed:u.get('closed')!=='0'}),drag:false,hover:'',records:[],selected:0};
  const canvas=$('experiment');let geometry,dragX,dragU;
  const track=(a,v)=>{if(window.Analytics)Analytics.track('电功率与小灯泡亮度',a,String(v??state.scene));};
  if(matchMedia('(max-width:760px)').matches)$('panel').classList.add('collapsed');
  function solve(){return Power.solve(state);}
  function update(){
    Object.assign(state,Power.clean(state));const q=solve();
    $('U').value=state.U;$('UOut').textContent=state.U.toFixed(1)+' V';$('switch').textContent=state.closed?'断开开关':'闭合开关';
    $('insight').textContent=!q.closed?'开关断开：实际功率为 0。':q.totalP===0?'电源为 0 V：实际功率为 0。':q.bulbs.some(b=>b.P>6)?'过压理论值 · 光晕在 6 W 封顶，请比较读数。':q.scene==='single'?'同一只灯泡：电压越高，实际功率越大。':q.scene==='parallel'?'同电压：A 电阻更小，实际功率更大。':'同电流：B 电阻更大，实际功率更大。';
    $('reading').textContent=`总功率 ${q.totalP.toFixed(2)} W`;
    $('current').textContent=q.I.toFixed(3)+' A';$('resistance').textContent=q.totalR.toFixed(2)+' Ω';
    $('formula').textContent=q.bulbs.map(b=>`${b.name}：${b.U.toFixed(2)} V × ${b.I.toFixed(3)} A = ${b.P.toFixed(2)} W`).join('；');
    const b=q.bulbs[Math.min(state.selected,q.bulbs.length-1)];
    $('plate').textContent=`${b.name}：额定电压 ${b.ratedU} V，额定功率 ${b.ratedP} W；计算电阻 ${b.R} Ω。当前 ${b.status}，实际/额定功率 ${(b.ratio*100).toFixed(1)}%。`;
    $('warning').textContent=q.bulbs.some(b=>b.ratio>1.001)?'超过额定电压：只显示定电阻理论值。真实灯泡可能损坏，本模型不计算烧断阈值或寿命。':'亮度只在同类灯泡、相同发光效率假设下定性比较；不是流明或照度。';
    document.querySelectorAll('[data-scene]').forEach(b=>{b.classList.toggle('on',b.dataset.scene===state.scene);b.setAttribute('aria-pressed',String(b.dataset.scene===state.scene));});
    geometry=PowerDraw.render(canvas,state,q,0);
  }
  function setScene(scene){if(!Object.hasOwn(Power.presets,scene))return;Object.assign(state,{scene,U:Power.presets[scene],closed:true,selected:0});update();track('切换场景',scene);}
  document.querySelectorAll('[data-scene]').forEach(b=>b.onclick=()=>setScene(b.dataset.scene));
  $('U').oninput=()=>{state.U=Number($('U').value);update();};$('U').onchange=()=>track('电压',state.U);
  $('switch').onclick=()=>{state.closed=!state.closed;update();track('开关',state.closed);};
  $('rated').onclick=()=>{state.U=6;state.closed=true;update();track('设为6V');};
  $('record').onclick=()=>{const q=solve();state.records.push(`${{single:'单灯',parallel:'并联',series:'串联'}[q.scene]} / 电源${q.U.toFixed(1)}V${q.closed?'':'（断开）'}：`+q.bulbs.map(b=>`${b.name} ${b.U.toFixed(2)}V / ${b.P.toFixed(2)}W`).join('，'));if(state.records.length>6)state.records.shift();$('records').replaceChildren(...state.records.map(t=>{const p=document.createElement('p');p.textContent=t;return p;}));track('记录');};
  $('clear').onclick=()=>{state.records=[];$('records').replaceChildren();};
  function link(){const v=new URL(location.href);v.search='';v.hash='';v.searchParams.set('scene',state.scene);v.searchParams.set('U',state.U.toFixed(3));v.searchParams.set('closed',state.closed?'1':'0');return v.href;}
  $('share').onclick=async()=>{const v=link();try{await navigator.clipboard.writeText(v);$('shareNote').textContent='已复制当前电路与电压。';}catch{$('shareNote').textContent=v;}track('分享');};
  $('panelToggle').onclick=()=>{const open=!$('panel').classList.toggle('collapsed');$('panelToggle').setAttribute('aria-expanded',String(open));};
  // 点击完成后再展开抽屉，避免触摸抬手时误点刚出现在手指下的控件。
  canvas.onclick=e=>{const hit=PowerDraw.hit(PowerDraw.point(e,canvas,geometry),geometry);if(hit==='switch'){$('switch').click();return;}if(!hit.startsWith('bulb'))return;state.selected=Number(hit.slice(4));if(matchMedia('(max-width:760px)').matches){$('panel').classList.remove('collapsed');$('panelToggle').setAttribute('aria-expanded','true');}$('plate').scrollIntoView({block:'nearest'});track('查看铭牌',state.selected);update();};
  canvas.onpointerdown=e=>{const hit=PowerDraw.hit(PowerDraw.point(e,canvas,geometry),geometry);if(hit!=='knob')return;e.preventDefault();state.drag=true;dragX=e.clientX;dragU=state.U;canvas.setPointerCapture(e.pointerId);update();};
  canvas.onpointermove=e=>{const hit=PowerDraw.hit(PowerDraw.point(e,canvas,geometry),geometry);state.hover=hit;if(state.drag)state.U=Math.max(0,Math.min(12,dragU+(e.clientX-dragX)/geometry.scale*.06));canvas.style.cursor=state.drag?'grabbing':hit==='knob'?'grab':hit?'pointer':'default';update();};
  function release(){if(state.drag)track('拖动旋钮',state.U.toFixed(1));state.drag=false;update();}
  canvas.onpointerup=release;canvas.onpointercancel=release;canvas.onpointerleave=()=>{state.hover='';if(!state.drag)update();};
  window.addEventListener('resize',update);
  window.__model={state,solve,update,setScene,link,setVoltage(v){state.U=v;update();}};
  update();
}());
