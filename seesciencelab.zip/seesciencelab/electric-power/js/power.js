(function () {
  'use strict';
  // 教材定电阻近似；不把额定电阻误称为真实灯丝全程电阻。
  const lamps = [{ name: 'A', U: 6, P: 3 }, { name: 'B', U: 12, P: 6 }];
  const presets = { single: 3, parallel: 6, series: 12 };
  function clean(s) {
    const scene = Object.hasOwn(presets, s.scene) ? s.scene : 'parallel';
    let U = Number(s.U ?? presets[scene]);
    if (!Number.isFinite(U)) U = presets[scene];
    return { scene, U: Math.max(0, Math.min(12, U)), closed: s.closed !== false };
  }
  function solve(s) {
    const c = clean(s), supply = c.closed ? c.U : 0;
    const resistances = lamps.map(l => l.U * l.U / l.P);
    const totalR = c.scene === 'single' ? resistances[0] : c.scene === 'series' ? resistances[0] + resistances[1] : 1 / (1 / resistances[0] + 1 / resistances[1]);
    const I = supply / totalR;
    const bulbs = lamps.slice(0, c.scene === 'single' ? 1 : 2).map((l, i) => {
      const R = resistances[i], U = c.scene === 'series' ? I * R : supply;
      const current = U / R, P = U * current;
      return { ...l, ratedU: l.U, ratedP: l.P, R, U, I: current, P, ratio: P / l.P,
        status: U === 0 ? '不发光' : U > l.U + .001 ? '过压（理论）' : Math.abs(U - l.U) < .001 ? '正常发光' : '欠压' };
    });
    return { ...c, I, totalR, totalP: supply * I, bulbs };
  }
  window.Power = { lamps, presets, clean, solve };
}());
