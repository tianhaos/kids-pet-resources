// 公路与两种图像共用同一运动结果；屏幕坐标以CSS像素计。
(function () {
  'use strict';
  const M = window.Motion, gold = '#ffc94a', blue = '#64d6ff';
  let canvas, c, W, H, layout;
  function text(str, x, y, color, size, align) {
    c.fillStyle = color || '#dce9f3'; c.font = (size || 13) + 'px -apple-system, "PingFang SC", sans-serif';
    c.textAlign = align || 'left'; c.fillText(str, x, y);
  }
  function line(x, y, x2, y2, color, width, dash) {
    c.beginPath(); c.strokeStyle = color; c.lineWidth = width || 1; c.setLineDash(dash || []);
    c.moveTo(x, y); c.lineTo(x2, y2); c.stroke(); c.setLineDash([]);
  }
  function rounded(x, y, w, h, r, color) {
    c.fillStyle = color; c.beginPath(); c.roundRect(x, y, w, h, r); c.fill();
  }
  function car(x, y, scale, opacity, t) {
    c.save(); c.translate(x, y); c.scale(scale, scale); c.globalAlpha = opacity;
    c.fillStyle = '#0005'; c.beginPath(); c.ellipse(0, 12, 44, 9, 0, 0, Math.PI * 2); c.fill();
    c.fillStyle = '#e8ac34'; c.beginPath(); c.moveTo(-36, -3); c.lineTo(-25, -24); c.lineTo(13, -24); c.lineTo(30, -8); c.lineTo(42, -5); c.lineTo(44, 9); c.lineTo(-41, 9); c.closePath(); c.fill();
    rounded(-42, -5, 87, 16, 6, gold);
    c.fillStyle = '#183c56'; c.beginPath(); c.moveTo(-21, -20); c.lineTo(-3, -20); c.lineTo(-3, -7); c.lineTo(-27, -7); c.closePath(); c.fill();
    c.beginPath(); c.moveTo(2, -20); c.lineTo(12, -20); c.lineTo(26, -7); c.lineTo(2, -7); c.closePath(); c.fill();
    for (const ax of [-26, 27]) {
      c.fillStyle = '#101827'; c.beginPath(); c.arc(ax, 10, 11, 0, Math.PI * 2); c.fill();
      c.fillStyle = '#aabaca'; c.beginPath(); c.arc(ax, 10, 5, 0, Math.PI * 2); c.fill();
      line(ax + Math.cos(t * 3) * 4, 10 + Math.sin(t * 3) * 4, ax - Math.cos(t * 3) * 4, 10 - Math.sin(t * 3) * 4, '#40546c', 2);
    }
    rounded(36, -3, 8, 4, 2, '#fff6c4'); rounded(-42, -2, 5, 5, 2, '#f36e56');
    c.restore();
  }
  function road(s, now) {
    const r = layout.road, X = d => r.x + d / layout.maxS * r.w, top = r.top;
    const sky = c.createLinearGradient(0, top, 0, top + r.h);
    sky.addColorStop(0, '#0e1d2d'); sky.addColorStop(1, '#132b32');
    rounded(12, top, W - 24, r.h, 14, sky);
    c.save(); c.beginPath(); c.roundRect(12, top, W - 24, r.h, 14); c.clip();
    // 静止远山、树木和路灯提供参照；背景不参与物理计算。
    for (let layer = 0; layer < 2; layer++) {
      c.fillStyle = layer ? '#1c3b3e' : '#192f40'; c.beginPath(); c.moveTo(12, r.y);
      for (let i = 0; i <= 24; i++) c.lineTo(12 + i * W / 24, r.y - 32 - layer * 4 - Math.sin(i * .6 + layer * 2) * 15);
      c.lineTo(W, r.y + 6); c.lineTo(12, r.y + 6); c.fill();
    }
    for (let i = 0; i < (W < 650 ? 5 : 10); i++) {
      const x = 24 + i * (W - 48) / (W < 650 ? 4 : 9);
      line(x, r.y, x, r.y - 28, '#3f5756', 3);
      c.fillStyle = '#284b47'; c.beginPath(); c.ellipse(x, r.y - 32, 10, 17, 0, 0, Math.PI * 2); c.fill();
    }
    for (const x of [W * .44, W * .84]) {
      line(x, r.y, x, r.y - 48, '#486271', 2); line(x, r.y - 48, x + 14, r.y - 48, '#486271', 2);
      line(x + 8, r.y - 47, x + 16, r.y - 47, '#c7d3ad', 2);
    }
    c.fillStyle = '#1a2530'; c.fillRect(12, r.y, W - 24, 49);
    line(12, r.y + 2, W - 12, r.y + 2, '#6b848b', 1);
    line(12, r.y + 46, W - 12, r.y + 46, '#506875', 1);
    line(12, r.y + 31, W - 12, r.y + 31, '#91a3ad66', 2, [18, 18]);
    line(X(0), r.y + 17, X(now.s), r.y + 17, '#ffc94a55', 4);
    for (let d = 0; d <= layout.maxS; d += 15) {
      line(X(d), r.y + 50, X(d), r.y + 55, '#648095');
      text(d + (d === 60 ? ' m' : ''), X(d), r.y + 70, '#99aebf', 10, 'center');
    }
    if (s.marks) {
      const locations = new Map();
      for (let t = 0; t <= now.t + .001; t += 2) {
        const key = M.at(s, t).s;
        if (!locations.has(key)) locations.set(key, []);
        locations.get(key).push(t);
      }
      for (const [d, times] of locations) {
        const x = X(d);
        c.fillStyle = blue; c.beginPath(); c.arc(x, r.y + 40, 3, 0, Math.PI * 2); c.fill();
        if (times.length > 1 || times[0] % 4 === 0) text(times.join('/') + 's', x, r.y + 82, '#93bdcf', 10, 'center');
      }
    }
    const x = X(now.s), cy = r.y + 4;
    car(x, cy, W < 650 ? .6 : .85, 1, now.s);
    layout.car = { x: x, y: cy, radius: W < 650 ? 34 : 45 };
    c.restore();
    text('01  直路上的小车', 26, top + 24, '#cbd9e8', 12);
    text(now.v ? '向右行驶 →' : '停留 · 位置不变', W - 27, top + 24, now.v ? gold : blue, 11, 'right');
    const readY = top + r.h - 8;
    text('s  ' + now.s.toFixed(1) + ' m', 26, readY, gold, W < 650 ? 15 : 18);
    text('v  ' + now.v.toFixed(1) + ' m/s', W - 26, readY, blue, W < 650 ? 15 : 18, 'right');
  }
  function plot(s, now, box, kind) {
    const isS = kind === 's', max = isS ? layout.maxS : 6;
    const p = { x: box.x + 43, y: box.y + 55, w: box.w - 66, h: box.h - 88, kind: kind };
    const X = t => p.x + t / M.T * p.w, Y = v => p.y + p.h - v / max * p.h;
    rounded(box.x, box.y, box.w, box.h, 14, '#0d1420');
    text(isS ? '02  路程—时间' : '03  速度—时间', box.x + 15, box.y + 23, isS ? gold : blue, 12);
    text(isS ? 's / m · 陡缓看速度' : 'v / (m/s) · 面积看路程', box.x + 15, box.y + 41, '#869eb7', 10);
    text(isS ? (now.v ? '路程增加' : '路程不变') : (now.v ? '匀速行驶' : '速度为零'), box.x + box.w - 14, box.y + 23, '#a8bdce', 10, 'right');
    const gridSteps = p.h < 65 ? 2 : 4;
    for (let i = 0; i <= gridSteps; i++) {
      let v = i * max / gridSteps;
      line(p.x, Y(v), X(12), Y(v), '#233348'); text(Number(v.toFixed(1)).toString(), p.x - 8, Y(v) + 4, '#a0b4c4', 11, 'right');
    }
    for (let t = 0; t <= 12; t += 4) {
      line(X(t), p.y, X(t), Y(0), '#233348'); text('' + t, X(t), Y(0) + 17, '#a0b4c4', 11, 'center');
    }
    line(p.x, p.y, p.x, Y(0), '#849db0'); line(p.x, Y(0), X(12), Y(0), '#849db0');
    text('t / s', X(12), Y(0) + 30, '#b5c8d5', 11, 'right');
    for (const seg of M.segments(s)) {
      const end = Math.min(now.t, seg.b);
      if (!isS && end > seg.a) { c.fillStyle = '#4fc3f72c'; c.fillRect(X(seg.a), Y(seg.v), X(end) - X(seg.a), Y(0) - Y(seg.v)); }
      const y1 = isS ? Y(M.at(s, seg.a).s) : Y(seg.v), y2 = isS ? Y(M.at(s, seg.b).s) : Y(seg.v);
      if (s.future) line(X(seg.a), y1, X(seg.b), y2, '#6a879c', 2, [5, 5]);
      if (end >= seg.a && now.t >= seg.a) {
        const yEnd = isS ? Y(M.at(s, end).s) : Y(seg.v);
        line(X(seg.a), y1, X(end), yEnd, isS ? gold : blue, 3);
      }
      // 速度跳变用空/实端点表示，不用竖线暗示中间速度实际持续。
      if (!isS && s.future && seg.b < 12) { c.fillStyle = '#0d1420'; c.strokeStyle = '#6a879c'; c.lineWidth = 2; c.beginPath(); c.arc(X(seg.b), Y(seg.v), 3, 0, Math.PI * 2); c.fill(); c.stroke(); }
    }
    const y = Y(isS ? now.s : now.v), x = X(now.t);
    line(x, p.y, x, Y(0), '#e7effa88', 1, [4, 4]);
    c.fillStyle = isS ? gold : blue; c.beginPath(); c.arc(x, y, 5, 0, Math.PI * 2); c.fill();
    const label = (isS ? now.s.toFixed(1) + ' m' : now.v.toFixed(1) + ' m/s');
    const lx = Math.min(Math.max(x, p.x + 35), X(12) - 38);
    rounded(lx - 34, Math.max(p.y, y - 29), 68, 20, 5, '#223c51');
    text(label, lx, Math.max(p.y, y - 29) + 14, '#fff', 11, 'center');
    layout.plots.push(p);
  }
  function draw(s) {
    const r = canvas.getBoundingClientRect(), dpr = Math.min(devicePixelRatio || 1, 2);
    W = r.width; H = r.height;
    if (canvas.width !== Math.round(W * dpr) || canvas.height !== Math.round(H * dpr)) { canvas.width = Math.round(W * dpr); canvas.height = Math.round(H * dpr); }
    c.setTransform(dpr, 0, 0, dpr, 0, 0); c.clearRect(0, 0, W, H);
    c.fillStyle = '#05070d'; c.fillRect(0, 0, W, H);
    const narrow = W < 650, compact = H < 660;
    const topRoad = narrow ? 145 : 138;
    const roadH = compact ? 178 : narrow ? 207 : Math.min(266, H * .32);
    layout = { road: { x: narrow ? 47 : 65, w: W - (narrow ? 94 : 130), top: topRoad, y: topRoad + roadH - 113, h: roadH }, maxS: 60, plots: [] };
    const now = M.at(s, s.t); road(s, now);
    const top = topRoad + roadH + 12, avail = H - top - 121, gap = 12;
    if (narrow) {
      const h = (avail - gap) / 2;
      plot(s, now, { x: 12, y: top, w: W - 24, h: h }, 's');
      plot(s, now, { x: 12, y: top + h + gap, w: W - 24, h: h }, 'v');
    } else {
      const w = (W - 36) / 2;
      plot(s, now, { x: 12, y: top, w: w, h: avail }, 's');
      plot(s, now, { x: 24 + w, y: top, w: w, h: avail }, 'v');
    }
    text('实线 已发生   ·   虚线 预测   ·   蓝色面积 = ' + now.s.toFixed(1) + ' m', W / 2, H - 111, '#8da6bf', 10, 'center');
  }

  function hit(x, y) {
    if (!layout) return null;
    const car = layout.car;
    if (Math.abs(x - car.x) <= car.radius && Math.abs(y - car.y) <= 34) return { type: 'car' };
    for (const p of layout.plots) if (x >= p.x - 16 && x <= p.x + p.w + 16 && y >= p.y - 12 && y <= p.y + p.h + 25) return { type: 'time', plot: p };
    return null;
  }
  function timeFromX(x, p) { return M.clamp((x - p.x) / p.w * 12, 0, 12); }
  function distanceFromX(x) { return (x - layout.road.x) / layout.road.w * layout.maxS; }
  window.MotionDraw = { init(el) { canvas = el; c = el.getContext('2d'); }, draw: draw, hit: hit, timeFromX: timeFromX, distanceFromX: distanceFromX };
}());
