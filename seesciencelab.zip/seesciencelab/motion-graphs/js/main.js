(function () {
  'use strict';
  const M = window.Motion, D = window.MotionDraw, $ = id => document.getElementById(id), q = new URLSearchParams(location.search);
  function num(k, fallback, lo, hi) { const v = Number(q.get(k)); return q.has(k) && Number.isFinite(v) ? M.clamp(v, lo, hi) : fallback; }
  const state = { scene: M.scenes[q.get('scene')] ? q.get('scene') : 'stop', v1: num('v1', 2, 1, 5), v2: num('v2', 4, 1, 5), t: num('t', 6, 0, 12), play: q.get('play') === '1', future: q.get('future') !== '0', marks: q.get('marks') !== '0' };
  const canvas = $('motion'); D.init(canvas);
  function track(action, label) { if (window.Analytics) window.Analytics.track('速度与运动图像', action, String(label)); }
  function sync() {
    const p = M.at(state, state.t), full = M.at(state, 12);
    $('status').textContent = p.v ? '向右运动 · ' + p.v.toFixed(1) + ' m/s' : '停留中 · 速度为零';
    $('timeRead').textContent = p.t.toFixed(2) + ' s'; $('distanceRead').textContent = p.s.toFixed(2) + ' m';
    $('speedRead').textContent = p.v.toFixed(1) + ' m/s'; $('averageRead').textContent = full.s.toFixed(1) + ' ÷ 12 = ' + (full.s / 12).toFixed(2) + ' m/s';
    $('explain').textContent = p.v ? '路程图越陡，速度越大；速度图的高度就是当前速度。' : '同一段停留：s-t水平；v-t落在零线上。';
    $('sceneNote').textContent = M.scenes[state.scene].note;
    document.querySelector('.stage-head h2').textContent = state.scene === 'stop' ? '小车停下，图线会怎样？' : state.scene === 'uniform' ? '匀速行驶，两幅图怎样记录？' : '速度改变，图线怎样变化？';
    $('stagePlay').setAttribute('aria-label', state.play ? '暂停运动' : '播放运动');
    $('time').value = state.t; $('timeOut').textContent = state.t.toFixed(2);
    for (const key of ['v1', 'v2']) { $(key).value = state[key]; $(key + 'Out').textContent = state[key].toFixed(1); }
    $('v2Row').hidden = state.scene === 'uniform'; $('future').checked = state.future; $('marks').checked = state.marks;
    for (const el of document.querySelectorAll('[data-scene]')) { el.classList.toggle('on', el.dataset.scene === state.scene); el.setAttribute('aria-pressed', el.dataset.scene === state.scene); }
    $('stagePlay').textContent = state.play ? '❚❚ 暂停' : '▶ 播放';
  }
  function records() {
    $('records').innerHTML = '<table><thead><tr><th>时间 / s</th><th>速度 m/s</th><th>路程 / m</th></tr></thead><tbody>' + M.segments(state).map(p => '<tr><td>' + p.a + '–' + p.b + '</td><td>' + p.v.toFixed(1) + '</td><td>' + ((p.b - p.a) * p.v).toFixed(1) + '</td></tr>').join('') + '</tbody></table>';
  }
  function setTime(t) { state.t = M.clamp(t, 0, 12); state.play = false; sync(); }
  function setScene(scene) { if (!M.scenes[scene]) return; state.scene = scene; state.t = 0; state.play = false; records(); sync(); track('切换场景', scene); }
  function play() { if (state.t >= 12) state.t = 0; state.play = !state.play; track('播放', state.play); sync(); }
  function reset() { setTime(0); track('重置', state.scene); }
  document.querySelectorAll('[data-scene]').forEach(el => el.onclick = () => setScene(el.dataset.scene));
  $('time').oninput = e => setTime(Number(e.target.value)); $('time').onchange = () => track('时间探测', state.t.toFixed(2));
  for (const key of ['v1', 'v2']) {
    $(key).oninput = e => { state[key] = Number(e.target.value); setTime(0); records(); };
    $(key).onchange = () => track('改变速度', key + '=' + state[key]);
  }
  for (const key of ['future', 'marks']) $(key).onchange = e => { state[key] = e.target.checked; track('显示', key + '=' + state[key]); };
  $('stagePlay').onclick = play; $('stageReset').onclick = reset;
  $('panelToggle').onclick = () => { const closed = $('panel').classList.toggle('collapsed'); $('panelToggle').setAttribute('aria-expanded', String(!closed)); };
  $('panelToggle').setAttribute('aria-expanded', String(!matchMedia('(max-width:760px)').matches));
  if (matchMedia('(max-width:760px)').matches) $('panel').classList.add('collapsed');
  $('share').onclick = async () => {
    const params = new URLSearchParams({ scene: state.scene, v1: state.v1, v2: state.v2, t: state.t.toFixed(2), play: '0', future: state.future ? '1' : '0', marks: state.marks ? '1' : '0' });
    const url = location.origin + location.pathname + '?' + params;
    try { await navigator.clipboard.writeText(url); $('shareNote').textContent = '已复制当前时刻与参数。'; }
    catch (_) { $('shareNote').textContent = '请复制地址栏中的状态链接。'; history.replaceState(null, '', '?' + params); }
    track('复制链接', state.scene);
  };
  let drag = null;
  function point(e) { const r = canvas.getBoundingClientRect(); return { x: e.clientX - r.left, y: e.clientY - r.top }; }
  function move(e) {
    const p = point(e);
    if (!drag) { canvas.style.cursor = D.hit(p.x, p.y) ? 'grab' : 'default'; return; }
    canvas.style.cursor = 'grabbing';
    if (drag.type === 'time') setTime(D.timeFromX(p.x, drag.plot));

  }
  canvas.onpointerdown = e => {
    const p = point(e); drag = D.hit(p.x, p.y); if (!drag) return;
    state.play = false;
    // 车身任意处均可抓取，保留抓取偏移避免跳跃。
    if (drag.type === 'car') drag.offset = D.distanceFromX(p.x) - M.at(state, state.t).s;
    canvas.setPointerCapture(e.pointerId);
    if (drag.type === 'time') move(e); sync();
  };
  canvas.onpointermove = e => {
    if (drag && drag.type === 'car') {
      const p = point(e); setTime(M.timeAtDistance(state, D.distanceFromX(p.x) - drag.offset, state.t)); canvas.style.cursor = 'grabbing';
    } else move(e);
  };
  function end(e) { if (!drag) return; track('画面拖动', drag.type); drag = null; canvas.style.cursor = 'grab'; if (canvas.hasPointerCapture(e.pointerId)) canvas.releasePointerCapture(e.pointerId); }
  canvas.onpointerup = end; canvas.onpointercancel = end;
  document.addEventListener('keydown', e => { if (e.code === 'Space' && !/INPUT|BUTTON|SELECT|TEXTAREA/.test(document.activeElement.tagName)) { e.preventDefault(); play(); } });
  let last;
  function frame(now) {
    if (last !== undefined && state.play) { state.t = Math.min(12, state.t + Math.min((now - last) / 1000, 0.1)); if (state.t >= 12) state.play = false; }
    last = now; sync(); D.draw(state); requestAnimationFrame(frame);
  }
  window.__model = { state: state, setTime: setTime, setScene: setScene, update() { records(); sync(); D.draw(state); }, play: play };
  records(); sync(); requestAnimationFrame(frame);
}());
