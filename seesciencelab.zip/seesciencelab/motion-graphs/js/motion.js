// 单向分段匀速运动；计算层不依赖DOM，单位m、s、m/s。
(function () {
  'use strict';
  const T = 12;
  const scenes = {
    uniform: { name: '匀速直行', note: '12秒内速度保持不变，等时标记等间距。' },
    stop: { name: '停留再走', note: '前4秒行驶，中间4秒停留，最后4秒继续走。' },
    change: { name: '先慢后快', note: '前4秒用前段速度，后8秒用后段速度；也可设为先快后慢。' }
  };
  function clamp(x, lo, hi) { return Math.max(lo, Math.min(hi, x)); }
  function segments(s) {
    if (s.scene === 'stop') return [{ a: 0, b: 4, v: s.v1 }, { a: 4, b: 8, v: 0 }, { a: 8, b: T, v: s.v2 }];
    if (s.scene === 'change') return [{ a: 0, b: 4, v: s.v1 }, { a: 4, b: T, v: s.v2 }];
    return [{ a: 0, b: T, v: s.v1 }];
  }
  function at(s, t) {
    t = clamp(t, 0, T);
    const segs = segments(s);
    let distance = 0, v = segs[segs.length - 1].v;
    for (const p of segs) {
      distance += p.v * clamp(t - p.a, 0, p.b - p.a);
      if (t >= p.a && t < p.b) v = p.v;
    }
    return { t: t, s: distance, v: v };
  }
  // 停留平台没有唯一反函数：拖车时保留当前平台时刻，否则取到达时刻。
  function timeAtDistance(s, distance, previous) {
    distance = clamp(distance, 0, at(s, T).s);
    let walked = 0;
    for (const p of segments(s)) {
      const end = walked + p.v * (p.b - p.a);
      if (!p.v && Math.abs(distance - walked) < 0.05) return clamp(previous, p.a, p.b);
      if (p.v && distance <= end + 1e-8) {
        if (Math.abs(distance - end) < 0.05 && s.scene === 'stop' && p.b === 4) return clamp(previous, 4, 8);
        return p.a + (distance - walked) / p.v;
      }
      walked = end;
    }
    return T;
  }
  window.Motion = { T: T, scenes: scenes, clamp: clamp, segments: segments, at: at, timeAtDistance: timeAtDistance };
}());
