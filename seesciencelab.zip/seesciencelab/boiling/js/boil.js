/* 水的整体热量模型。所有量采用 kg、s、W、kPa、℃；计算不访问DOM。 */
(function () {
  'use strict';
  const C = 4200, VESSEL = 80, LOSS = 1.2, LATENT = 2260000, ROOM = 20;
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  // NIST Antoine：log10(P/bar)=A-B/(T/K+C)，344–373 K段。
  function boilingPoint(pressure) {
    return 1663.125 / (5.08354 - Math.log10(clamp(pressure, 60, 101.3) / 100)) + 45.622 - 273.15;
  }
  function initial(options) {
    const pressure = clamp(options.pressure || 101.3, 60, 101.3);
    return { t: 0, temp: 70, mass: 0.2, pressure, power: options.power || 500,
      heat: options.cut !== 0, cut: options.cut == null ? null : options.cut, vapor: 0, energy: 0 };
  }
  function net(s) { return (s.heat ? s.power : 0) - LOSS * (s.temp - ROOM); }
  function isBoiling(s) { return s.mass > 0.02 && s.temp >= boilingPoint(s.pressure) - 0.001 && net(s) > 0; }
  function step(s, dt) {
    // 以≤0.1s显式步长处理到达沸点与汽化之间的热量分配。
    let left = Math.max(0, dt);
    while (left > 1e-8) {
      let h = Math.min(0.1, left);
      if (s.cut !== null && s.t < s.cut && s.t + h > s.cut) h = s.cut - s.t;
      if (s.cut !== null && s.t >= s.cut - 1e-7) s.heat = false;
      if (s.mass <= 0.02) s.heat = false;
      const q = net(s) * h, cap = C * s.mass + VESSEL, bp = boilingPoint(s.pressure);
      const sensible = Math.max(0, (bp - s.temp) * cap);
      if (q > sensible) {
        s.temp = bp;
        const dm = Math.min(Math.max(0, s.mass - 0.02), (q - sensible) / LATENT);
        s.mass -= dm; s.vapor += dm;
      } else s.temp = Math.max(ROOM, s.temp + q / cap);
      s.energy += q; s.t += h; left -= h;
    }
    return s;
  }
  function sample(s) { return { t: s.t, temp: s.temp, mass: s.mass, heat: s.heat, boiling: isBoiling(s) }; }
  function simulate(options, t) {
    const s = initial(options), history = [sample(s)];
    t = clamp(Number(t) || 0, 0, 600);
    while (s.t < t - 1e-7) { step(s, Math.min(1, t - s.t)); history.push(sample(s)); }
    return { s, history };
  }
  function bubble(s, progress) {
    const u = clamp(progress, 0, 1), boiling = isBoiling(s);
    return { radius: boiling ? 3 + 9 * u : 5 * Math.max(0, 1 - u / 0.72),
      rise: boiling ? u : u * 0.78, visible: s.heat && (boiling || s.temp > boilingPoint(s.pressure) - 18) && (boiling || u < 0.72) };
  }
  window.Boil = { C, VESSEL, LOSS, LATENT, ROOM, clamp, boilingPoint, initial, net, isBoiling, step, sample, simulate, bubble };
})();
