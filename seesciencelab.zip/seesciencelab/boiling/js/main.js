/* 单一状态、场景预设、时间推进与直接操作。 */
(function () {
  'use strict';
  const $ = id => document.getElementById(id), canvas = $('canvas');
  const presets = { warm: { pressure: 101.3, t: 45, cut: null }, boil: { pressure: 101.3, t: 120, cut: null },
    low: { pressure: 70, t: 120, cut: null }, cool: { pressure: 101.3, t: 155, cut: 110 } };
  const params = new URLSearchParams(location.search);
  const number = (key, fallback, lo, hi) => { const v = Number(params.get(key)); return params.has(key) && Number.isFinite(v) ? Boil.clamp(v, lo, hi) : fallback; };
  const scene = Object.hasOwn(presets, params.get('scene')) ? params.get('scene') : 'boil';
  const state = { scene, pressure: number('pressure', presets[scene].pressure, 60, 101.3), power: number('power', 500, 200, 800),
    cut: number('cut', presets[scene].cut, 0, 600), playing: params.get('play') === '1', speed: 10,
    s: null, history: [], phase: 1.1, probe: null, hover: null };
  function track(action, label) { if (window.Analytics) Analytics.track('水的沸腾', action, String(label)); }
  function seek(t) {
    const result = Boil.simulate(state, t); state.s = result.s; state.history = result.history;
    state.probe = null; state.phase = 1.1; update();
  }
  function update() {
    const s = state.s, boiling = Boil.isBoiling(s);
    $('stageCause').textContent = boiling ? '继续吸热用于汽化：气泡上升变大，水温保持在沸点。' : s.heat ? '接近沸腾时，水蒸气泡向上缩小；热量使水温升高。' : '撤去热源后，水向环境散热，温度逐渐下降。';
    $('status').textContent = boiling ? '持续沸腾 · 温度平台' : s.heat ? '加热升温 · 尚未沸腾' : '热源已撤 · 散热降温';
    $('temp').textContent = s.temp.toFixed(1) + ' ℃'; $('bp').textContent = Boil.boilingPoint(s.pressure).toFixed(1) + ' ℃';
    $('time').textContent = s.t.toFixed(1) + ' s'; $('mass').textContent = (s.mass * 1000).toFixed(1) + ' g';
    $('net').textContent = (s.heat ? s.power.toFixed(0) : '0') + ' W';
    $('cause').textContent = boiling ? '继续净吸热 → 液态水汽化，水量减少；水温不再持续升高。' : s.heat ? '温度低于当前沸点，净热量主要用于升温。' : '装置向环境放热；本模型忽略器材余热维持沸腾的延迟。';
    ['heat', 'quickHeat'].forEach(id => $(id).textContent = s.heat ? '撤去热源' : '恢复加热');
    ['play', 'quickPlay'].forEach(id => $(id).textContent = state.playing ? '❚❚ 暂停' : '▶ 播放');
    $('power').value = state.power; $('powerOut').textContent = state.power.toFixed(0) + ' W';
    $('pressure').value = state.pressure; $('pressureOut').textContent = state.pressure.toFixed(1) + ' kPa';
    $('progress').value = s.t; $('progressOut').textContent = s.t.toFixed(0) + ' s';
    $('speedOut').textContent = state.speed + '×';
    document.querySelectorAll('[data-scene]').forEach(b => { b.classList.toggle('on', b.dataset.scene === state.scene); b.setAttribute('aria-pressed', b.dataset.scene === state.scene); });
  }
  function setScene(name) {
    if (!presets[name]) return;
    state.scene = name; Object.assign(state, presets[name]); state.power = 500; state.playing = false;
    seek(presets[name].t); track('场景', name);
  }
  function advance(seconds) {
    let dt = Math.min(Math.max(0, seconds), 600 - state.s.t);
    while (dt > 1e-7) {
      const h = Math.min(dt, 0.5); Boil.step(state.s, h); dt -= h;
      state.history.push(Boil.sample(state.s));
    }
    if (state.s.t >= 600 - 1e-6 || state.s.mass <= 0.02) state.playing = false;
    state.probe = null; update();
  }
  function togglePlay() {
    if (state.s.t >= 600) { $('message').textContent = '实验已结束，请从头加热或选择场景。'; return; }
    state.playing = !state.playing; update(); track('播放', state.playing);
  }
  function toggleHeat() {
    // 记录首次撤火时间，状态链接可重建这条单次撤火记录；恢复会清除此预设。
    const s = state.s; s.heat = !s.heat;
    if (!s.heat) { state.cut = s.t; s.cut = s.t; }
    else { state.cut = null; s.cut = null; }
    update(); track('热源', s.heat ? '恢复' : '撤去');
  }
  function setPower(v) { state.power = Math.round(Boil.clamp(v, 200, 800) / 10) * 10; state.s.power = state.power; update(); }
  document.querySelectorAll('[data-scene]').forEach(b => b.onclick = () => setScene(b.dataset.scene));
  ['play', 'quickPlay'].forEach(id => $(id).onclick = togglePlay);
  ['heat', 'quickHeat'].forEach(id => $(id).onclick = toggleHeat);
  $('reset').onclick = () => { state.cut = null; state.playing = false; seek(0); track('重做', state.scene); };
  $('power').oninput = e => setPower(+e.target.value);
  $('power').onchange = () => track('功率', state.power);
  $('pressure').oninput = e => { state.pressure = +e.target.value; state.cut = null; state.playing = false; seek(0); };
  $('pressure').onchange = () => track('气压', state.pressure);
  $('progress').oninput = e => { state.playing = false; state.cut = presets[state.scene].cut; seek(+e.target.value); };
  $('progress').onchange = () => track('进度', state.s.t.toFixed(0));
  $('speed').oninput = e => { state.speed = +e.target.value; update(); };
  function stateURL() {
    // 历史中途改变功率、撤火再恢复不能仅靠有限参数还原；链接明确重建当前参数实验。
    const q = new URLSearchParams({ scene: state.scene, t: state.s.t.toFixed(1), power: state.power, pressure: state.pressure, play: 0 });
    if (state.cut !== null) q.set('cut', state.cut.toFixed(1));
    return location.origin + location.pathname + '?' + q;
  }
  $('share').onclick = async () => {
    const url = stateURL();
    try { await navigator.clipboard.writeText(url); $('message').textContent = '链接已复制：按当前功率重建实验，保留最后撤火时间。'; }
    catch { $('message').textContent = '复制此链接（按当前功率重建）：' + url; }
    track('分享', state.scene);
  };
  const panel = $('panel');
  if (matchMedia('(max-width:760px)').matches) panel.classList.add('collapsed');
  $('panelToggle').setAttribute('aria-expanded', !panel.classList.contains('collapsed'));
  $('panelToggle').onclick = () => { panel.classList.toggle('collapsed'); $('panelToggle').setAttribute('aria-expanded', !panel.classList.contains('collapsed')); };
  let drag = null;
  const point = e => { const r = canvas.getBoundingClientRect(); return { x: e.clientX - r.left, y: e.clientY - r.top }; };
  function probe(x) { const p = BoilDraw.layout().chart; state.probe = Boil.clamp((x - p.x) / p.w * p.maxT, 0, state.s.t); }
  canvas.onpointerdown = e => {
    const p = point(e), hit = BoilDraw.hit(p.x, p.y);
    if (!hit) return;
    canvas.setPointerCapture(e.pointerId); drag = { hit, startX: p.x, power: state.power };
    if (hit === 'chart') probe(p.x);
  };
  canvas.onpointermove = e => {
    const p = point(e); state.hover = BoilDraw.hit(p.x, p.y); canvas.style.cursor = drag ? 'grabbing' : state.hover === 'flame' ? 'ew-resize' : state.hover ? 'crosshair' : 'default';
    if (!drag) return;
    if (drag.hit === 'flame') setPower(drag.power + (p.x - drag.startX) * 4);
    else probe(p.x);
  };
  function end() { if (drag) track('画面操作', drag.hit); drag = null; }
  canvas.onpointerup = end; canvas.onpointercancel = end;
  document.addEventListener('keydown', e => { if (e.code === 'Space' && !/INPUT|BUTTON|SELECT|TEXTAREA/.test(e.target.tagName)) { e.preventDefault(); togglePlay(); } });
  seek(number('t', presets[scene].t, 0, 600));
  let last = performance.now();
  function frame(now) {
    const dt = Math.min(0.1, Math.max(0, (now - last) / 1000)); last = now;
    if (state.playing) { advance(dt * state.speed); state.phase += dt; }
    BoilDraw.draw(canvas, state); requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
  window.__model = { state, setScene, seek, advance, setPower, toggleHeat, update, stateURL, solve: () => ({ bp: Boil.boilingPoint(state.pressure), boiling: Boil.isBoiling(state.s), net: Boil.net(state.s) }) };
})();
