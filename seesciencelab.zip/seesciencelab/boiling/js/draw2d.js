/* 装置绘图与曲线；气泡为教材现象示意，不求解流场。 */
(function () {
  'use strict';
  const gold = '#ffc94a', blue = '#6cd8ff', muted = '#9eafc2';
  let layout = {};
  function line(c, points, color, width) {
    c.beginPath(); points.forEach((p, i) => i ? c.lineTo(...p) : c.moveTo(...p));
    c.strokeStyle = color; c.lineWidth = width || 1; c.stroke();
  }
  function text(c, str, x, y, size, color, align) {
    c.fillStyle = color || '#e5eff9'; c.font = `${size || 14}px -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif`;
    c.textAlign = align || 'left'; c.fillText(str, x, y);
  }
  function round(c, x, y, w, h, r, fill, stroke) {
    c.beginPath(); c.roundRect(x, y, w, h, r);
    if (fill) { c.fillStyle = fill; c.fill(); }
    if (stroke) { c.strokeStyle = stroke; c.lineWidth = 1; c.stroke(); }
  }
  function apparatus(c, s, phase, width, height, hover) {
    const scale = Math.min(width / 500, height / 420), ox = (width - 500 * scale) / 2;
    const oy = (height - 420 * scale) / 2;
    c.save(); c.translate(ox, oy); c.scale(scale, scale); c.translate(-50, 0);
    const bp = Boil.boilingPoint(s.pressure), boiling = Boil.isBoiling(s), level = 310 - 150 * s.mass / 0.2;
    // 台面、支架、夹具和陶土网。
    const table = c.createLinearGradient(0, 325, 0, 415); table.addColorStop(0, '#182230'); table.addColorStop(1, '#080d15');
    round(c, 20, 325, 560, 80, 8, table);
    line(c, [[110, 326], [110, 35], [365, 35]], '#667f93', 7);
    line(c, [[72, 328], [150, 328]], '#7990a0', 9);
    line(c, [[315, 35], [315, 62]], '#a4b2b9', 5);
    round(c, 290, 56, 50, 12, 4, '#485a6c', '#8dacc3');
    line(c, [[180, 313], [410, 313]], '#9eacb8', 5);
    for (let x = 185; x < 410; x += 12) line(c, [[x, 310], [x + 8, 316]], '#4f6379');
    line(c, [[205, 317], [192, 370]], '#7d8c9b', 5);
    line(c, [[385, 317], [397, 370]], '#7d8c9b', 5);
    // 烧杯中的水，用液面高度呈现质量减少。
    c.save(); c.beginPath(); c.rect(194, 105, 212, 202); c.clip();
    const water = c.createLinearGradient(0, level, 0, 305); water.addColorStop(0, '#2c8eaf99'); water.addColorStop(1, '#184965dd');
    c.fillStyle = water; c.fillRect(194, level, 212, 150);
    c.beginPath();
    for (let x = 194; x <= 406; x += 3) {
      const y = level + (boiling ? 2.3 : 0.6) * Math.sin(x / 14 + phase * 4);
      x === 194 ? c.moveTo(x, y) : c.lineTo(x, y);
    }
    c.strokeStyle = '#9de4f5'; c.lineWidth = 2; c.stroke();
    // 固定相位序列，暂停时稳定；切换水温、热源后即时响应。
    for (let i = 0; i < (boiling ? 28 : 13); i++) {
      const u = (phase * (boiling ? 0.34 : 0.22) + i * 0.618) % 1;
      const b = Boil.bubble(s, u);
      if (!b.visible) continue;
      const x = 210 + ((i * 53) % 175) + Math.sin(u * 7 + i) * 4;
      const y = 299 - (299 - level) * b.rise;
      const g = c.createRadialGradient(x - b.radius * 0.3, y - b.radius * 0.4, 0, x, y, b.radius);
      g.addColorStop(0, '#d9f7ff55'); g.addColorStop(0.7, '#c0f3ff0a'); g.addColorStop(1, '#bceeff77');
      c.beginPath(); c.arc(x, y, b.radius, 0, Math.PI * 2); c.fillStyle = g; c.fill();
      c.strokeStyle = '#b6e9f7aa'; c.lineWidth = 1.2; c.stroke();
    }
    c.restore();
    // 玻璃轮廓与刻度。
    const glass = c.createLinearGradient(190, 0, 410, 0); glass.addColorStop(0, '#b6e7ff20'); glass.addColorStop(0.18, '#b6e7ff04'); glass.addColorStop(1, '#b6e7ff17');
    c.beginPath(); c.moveTo(182, 104); c.lineTo(194, 113); c.lineTo(194, 294); c.quadraticCurveTo(194, 306, 208, 306); c.lineTo(392, 306); c.quadraticCurveTo(406, 306, 406, 294); c.lineTo(406, 104); c.fillStyle = glass; c.fill(); c.strokeStyle = '#a9d8ec'; c.lineWidth = 2; c.stroke();
    c.beginPath(); c.ellipse(299, 105, 108, 6, 0, 0, Math.PI * 2); c.strokeStyle = '#a9d8ec66'; c.stroke();
    for (let y = 150; y < 290; y += 25) line(c, [[369, y], [391, y]], '#b6d8e388', 1);
    // 温度计玻璃泡完全浸入，不触底壁。
    round(c, 309, 68, 12, 190, 5, '#e1f2edbb', '#deefff');
    round(c, 313, 78, 4, 175, 2, '#eef6fa');
    const top = 251 - (s.temp - 60) / 50 * 168;
    c.fillStyle = '#ff6d6c'; c.fillRect(313, top, 4, 253 - top);
    c.beginPath(); c.arc(315, 260, 8, 0, Math.PI * 2); c.fill();
    for (let t = 70; t <= 110; t += 10) {
      const y = 251 - (t - 60) / 50 * 168;
      line(c, [[321, y], [328, y]], '#c0d4df'); text(c, String(t), 332, y + 4, 10, muted);
    }
    // 热源本体可拖动，水平方向控制功率；大命中范围。
    round(c, 266, 368, 66, 24, 9, '#7f7274', '#bab4ad');
    round(c, 286, 354, 26, 18, 5, '#b9b0a6');
    if (s.heat && s.mass > 0.02) {
      const fh = 25 + (s.power - 200) / 600 * 27;
      c.save(); c.shadowColor = '#ff8c32'; c.shadowBlur = hover === 'flame' ? 25 : 12;
      c.beginPath(); c.moveTo(298, 360); c.bezierCurveTo(263, 350, 298, 335 - fh, 299, 331 - fh);
      c.bezierCurveTo(312, 335 - fh, 338, 350, 298, 360); c.fillStyle = gold; c.fill();
      c.beginPath(); c.moveTo(298, 359); c.quadraticCurveTo(280, 348, 299, 333); c.quadraticCurveTo(315, 350, 298, 359); c.fillStyle = '#74c6ff'; c.fill(); c.restore();
    }
    text(c, s.heat ? `${s.power.toFixed(0)} W · 左右拖动火焰` : '已撤去热源', 299, 411, 13, s.heat ? gold : muted, 'center');
    // 雾团表示液滴，与玻璃、水蒸气泡明确区分。
    if (boiling) {
      for (let i = 0; i < 12; i++) {
        const u = (phase * 0.18 + i / 12) % 1;
        c.beginPath(); c.ellipse(235 + i % 4 * 30 + Math.sin(u * 6 + i) * 9, level - 14 - u * 76, 7 + 16 * u, 4 + 8 * u, -0.3, 0, Math.PI * 2);
        c.fillStyle = `rgba(219,238,245,${0.08 * (1 - u)})`; c.fill();
      }
    }
    c.restore();
    return { x: ox + 200 * scale, y: oy + 282 * scale, w: 100 * scale, h: 120 * scale };
  }
  function chart(c, state, x, y, w, h) {
    const s = state.s, bp = Boil.boilingPoint(s.pressure);
    round(c, x, y, w, h, 14, '#0b111c', '#223044');
    text(c, '温度—时间曲线', x + 18, y + 26, 15);
    text(c, '点选读数', x + w - 18, y + 26, 12, muted, 'right');
    const plot = { x: x + 48, y: y + 50, w: w - 68, h: h - 85 };
    const maxT = Math.max(180, Math.ceil(s.t / 60) * 60), minY = 60, maxY = 110;
    const px = t => plot.x + t / maxT * plot.w;
    const py = t => plot.y + (maxY - t) / (maxY - minY) * plot.h;
    for (let v = 60; v <= 110; v += 10) {
      line(c, [[plot.x, py(v)], [plot.x + plot.w, py(v)]], '#2d3e50');
      text(c, String(v), plot.x - 8, py(v) + 4, 11, muted, 'right');
    }
    for (let v = 0; v <= maxT; v += maxT / 3) text(c, v.toFixed(0), px(v), plot.y + plot.h + 19, 11, muted, 'center');
    text(c, '℃', plot.x - 25, plot.y - 8, 12, muted);
    text(c, '时间 / s', plot.x + plot.w, y + h - 10, 11, muted, 'right');
    c.setLineDash([4, 5]); line(c, [[plot.x, py(bp)], [plot.x + plot.w, py(bp)]], '#6cd8ff88'); c.setLineDash([]);
    text(c, `沸点 ${bp.toFixed(1)}℃`, plot.x + plot.w - 3, py(bp) - 7, 11, blue, 'right');
    c.save(); c.beginPath(); c.rect(plot.x - 2, plot.y - 2, plot.w + 4, plot.h + 4); c.clip();
    line(c, state.history.map(a => [px(a.t), py(a.temp)]), gold, 2.5);
    c.restore();
    const chosen = state.probe === null ? state.history[state.history.length - 1] : state.history.reduce((best, a) => Math.abs(a.t - state.probe) < Math.abs(best.t - state.probe) ? a : best);
    if (chosen) {
      const cx = px(chosen.t), cy = py(chosen.temp);
      c.beginPath(); c.arc(cx, cy, 4, 0, Math.PI * 2); c.fillStyle = gold; c.fill();
      if (state.probe !== null) {
        line(c, [[cx, plot.y], [cx, plot.y + plot.h]], '#ffffff66');
        const lx = Math.max(x + 8, Math.min(cx - 62, x + w - 142));
        round(c, lx, y + h - 57, 134, 24, 6, '#24374b');
        text(c, `${chosen.t.toFixed(0)}s · ${chosen.temp.toFixed(1)}℃`, lx + 67, y + h - 40, 12, '#fff', 'center');
      }
    }
    return { ...plot, maxT };
  }
  function draw(canvas, state) {
    const box = canvas.getBoundingClientRect(), w = box.width, h = box.height, dpr = Math.min(devicePixelRatio || 1, 2);
    if (canvas.width !== Math.round(w * dpr) || canvas.height !== Math.round(h * dpr)) { canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr); }
    const c = canvas.getContext('2d'); c.setTransform(dpr, 0, 0, dpr, 0, 0); c.clearRect(0, 0, w, h);
    c.fillStyle = '#05070d'; c.fillRect(0, 0, w, h);
    const narrow = w < 600, side = w >= 820, top = narrow ? 156 : 150;
    const s = state.s, bp = Boil.boilingPoint(s.pressure), boiling = Boil.isBoiling(s);
    const ch = side ? Math.max(180, Math.min(330, h - top - 190)) : Math.min(215, h * 0.28);
    const aw = side ? w * 0.59 : w;
    const ah = side ? h - top - 100 : h - top - ch - 105;
    const glow = c.createRadialGradient(aw / 2, top + ah * .6, 5, aw / 2, top + ah * .6, aw * .48);
    glow.addColorStop(0, '#142231'); glow.addColorStop(1, '#05070d');
    c.fillStyle = glow; c.fillRect(0, top, aw, Math.max(0, ah));
    text(c, '水温', 22, top + 5, 11, muted);
    text(c, s.temp.toFixed(1) + ' ℃', 22, top + 29, narrow ? 16 : 18, gold);
    text(c, '当前沸点 ' + bp.toFixed(1) + ' ℃', aw - 22, top + 5, 12, blue, 'right');
    text(c, s.pressure.toFixed(1) + ' kPa', aw - 22, top + 27, 11, muted, 'right');
    c.save(); c.translate(0, top + 36);
    const f = apparatus(c, s, state.phase, aw, Math.max(130, ah - 36), state.hover); c.restore();
    const cy = side ? top + 56 : h - ch - 64;
    const cx = side ? aw + 12 : 14;
    const cw = side ? w - aw - 32 : w - 28;
    const plot = chart(c, state, cx, cy, cw, ch);
    if (side) {
      text(c, boiling ? '温度平台 ≠ 停止吸热' : s.heat ? '先升温，再汽化' : '停止加热，温度下降', cx + 16, cy + ch + 36, 15, '#e5eff9');
      text(c, boiling ? '热量用于汽化 · 水量逐渐减少' : '对照气泡变化与曲线的同一时刻', cx + 16, cy + ch + 61, 12, muted);
    }
    layout = { flame: { ...f, y: f.y + top + 36 }, chart: plot };

  }
  function hit(x, y) {
    const f = layout.flame, p = layout.chart;
    if (f && x >= f.x && x <= f.x + f.w && y >= f.y && y <= f.y + f.h) return 'flame';
    if (p && x >= p.x && x <= p.x + p.w && y >= p.y - 15 && y <= p.y + p.h + 25) return 'chart';
    return null;
  }
  window.BoilDraw = { draw, hit, layout: () => layout };
})();
