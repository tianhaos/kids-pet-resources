// 原子结构绘图：电子绕核的分层模型（原子核由质子、中子堆成）、教材式原子结构示意图、离子化合物的形成
(function () {
  var A = window.Atom;
  var PI = Math.PI, TAU = PI * 2;
  var SHELL = ['#4fc3f7', '#7ee081', '#ffc94a', '#ff7a59'];       // 第 1～4 层
  var CATC = { metal: '#ffb36b', nonmetal: '#4fc3f7', noble: '#c9a7ff' };
  var C = { text: '#e6ebf2', muted: '#8d99ab', line: '#2a3446', panel: '#111723', accent: '#ffc94a', gold: '#ff6ec7',
    cation: '#ff8a65', anion: '#64b5f6' };

  function ease(u) { return u < 0.5 ? 2 * u * u : 1 - Math.pow(-2 * u + 2, 2) / 2; }
  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
  function angDist(a, b) { return Math.abs(Math.atan2(Math.sin(a - b), Math.cos(a - b))); }
  function rng(seed) {
    return function () {
      seed |= 0; seed = seed + 0x6D2B79F5 | 0;
      var t = Math.imul(seed ^ seed >>> 15, 1 | seed);
      t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
      return ((t ^ t >>> 14) >>> 0) / 4294967296;
    };
  }
  // 第 k 层电子的公转相位：越外层转得越慢
  function phase(k, clock) { return clock * 0.9 / (k + 1) + k * 0.7; }
  function slotAngle(k, i, c, clock) { return phase(k, clock) + TAU * i / c; }

  // 原子核里质子、中子的排布（向日葵螺旋堆积，固定随机种子），按 z-n 缓存
  var nucCache = {};
  function nucleons(z, n) {
    var key = z + '-' + n;
    if (nucCache[key]) return nucCache[key];
    var a = z + n, r = rng(z * 131 + n * 7 + 1), types = [], pts = [], i;
    for (i = 0; i < a; i++) types.push(i < z);
    for (i = a - 1; i > 0; i--) { var j = Math.floor(r() * (i + 1)), t = types[i]; types[i] = types[j]; types[j] = t; }
    var c = 1 / (Math.sqrt(a) + 0.95);
    for (i = 0; i < a; i++) {
      var rr = a === 1 ? 0 : c * Math.sqrt(i + 0.5), th = i * 2.39996;
      pts.push({ x: rr * Math.cos(th), y: rr * Math.sin(th), p: types[i], r: rr });
    }
    pts.sort(function (p, q) { return q.r - p.r; });     // 外圈先画，中心的球压在上面，有立体感
    return (nucCache[key] = { pts: pts, br: c * 0.98 });
  }

  // 离子化合物形成时各原子最外层的电子位置：金属失去的电子朝向对方，非金属空位朝向对方
  var planCache = {};
  function pairPlan(key) {
    if (planCache[key]) return planCache[key];
    var p = A.PAIRS[key];
    var atoms = p.atoms.map(function (z) { return { z: z, sh: A.shells(z), out: [], inn: [], seats: [] }; });
    p.moves.forEach(function (m, idx) {
      atoms[m[0]].out.push({ m: idx, dir: m[1] > m[0] ? 0 : PI });
      atoms[m[1]].inn.push({ m: idx, dir: m[0] > m[1] ? 0 : PI });
    });
    atoms.forEach(function (a) {
      if (a.out.length) {
        a.out.forEach(function (o) {
          var same = a.out.filter(function (x) { return x.dir === o.dir; }), k = same.indexOf(o);
          a.seats.push({ ang: o.dir + (same.length > 1 ? (k - (same.length - 1) / 2) * 0.6 : 0), m: o.m, kind: 'out' });
        });
      } else {
        var dirs = a.inn.map(function (x) { return x.dir; });
        var base = dirs.length > 1 && dirs.every(function (d) { return d === dirs[0]; }) ? dirs[0] + PI / 8 : dirs[0] || 0;
        for (var i = 0; i < 8; i++) a.seats.push({ ang: base + i * PI / 4, m: -1, kind: 'fill' });
        a.inn.forEach(function (o) {
          var best = null;
          a.seats.forEach(function (s) { if (s.kind === 'fill' && (!best || angDist(s.ang, o.dir) < angDist(best.ang, o.dir))) best = s; });
          best.kind = 'in'; best.m = o.m;
        });
      }
      a.moves = a.out.concat(a.inn).map(function (o) { return o.m; });
    });
    return (planCache[key] = atoms);
  }

  function AtomDraw(canvas) {
    var ctx = canvas.getContext('2d');
    var W = 1, H = 1, dpr = 1, narrow = false;
    var shDisp = null, lastR = [], lastRout = 1;

    function resize(w, h) {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      W = w; H = h;
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
      canvas.style.width = w + 'px'; canvas.style.height = h + 'px';
      narrow = w < 640;
    }
    function area() {
      var top = narrow ? 84 : 44, bot = 48, side = narrow ? 8 : 20;
      return { x: side, y: top, w: W - 2 * side, h: H - top - bot };
    }

    function font(size, weight, mono) {
      ctx.font = (weight || '') + ' ' + size + 'px ' + (mono ? '"SF Mono", Menlo, Consolas, monospace' : '-apple-system, "PingFang SC", "Microsoft YaHei", sans-serif');
    }
    function label(str, x, y, color, align, size, weight, halo, mono) {
      font(size, weight, mono);
      ctx.textAlign = align || 'center'; ctx.textBaseline = 'middle';
      if (halo !== false) { ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(5,7,13,0.85)'; ctx.strokeText(str, x, y); }
      ctx.fillStyle = color; ctx.fillText(str, x, y);
    }
    function circle(x, y, r) { ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); }

    // ---------- 原子核 ----------
    function nucleus(x, y, R, z, n) {
      var nu = nucleons(z, n), br = nu.br * R;
      // 外围淡光
      var g = ctx.createRadialGradient(x, y, R * 0.3, x, y, R * 1.7);
      g.addColorStop(0, 'rgba(255,138,128,0.18)'); g.addColorStop(1, 'rgba(255,138,128,0)');
      ctx.fillStyle = g; circle(x, y, R * 1.7); ctx.fill();
      nu.pts.forEach(function (p) {
        var px = x + p.x * R, py = y + p.y * R;
        var gg = ctx.createRadialGradient(px - br * 0.35, py - br * 0.4, br * 0.1, px, py, br);
        if (p.p) { gg.addColorStop(0, '#ffb3a7'); gg.addColorStop(0.55, '#ef5350'); gg.addColorStop(1, '#8e1f1f'); }
        else { gg.addColorStop(0, '#f1f4f8'); gg.addColorStop(0.55, '#a9b4c2'); gg.addColorStop(1, '#4b5563'); }
        ctx.fillStyle = gg; circle(px, py, br); ctx.fill();
        if (p.p && br >= 5.5) label('+', px, py + 0.5, 'rgba(255,255,255,0.9)', 'center', Math.round(br * 1.25), '600', false);
      });
    }

    function electron(x, y, r, color, alpha) {
      ctx.globalAlpha = alpha == null ? 1 : alpha;
      var g = ctx.createRadialGradient(x, y, 0, x, y, r * 2.6);
      g.addColorStop(0, color); g.addColorStop(0.35, color); g.addColorStop(0.4, 'rgba(255,255,255,0.18)'); g.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.fillStyle = g; circle(x, y, r * 2.6); ctx.fill();
      ctx.fillStyle = '#fff'; circle(x - r * 0.3, y - r * 0.3, r * 0.35); ctx.fill();
      ctx.globalAlpha = 1;
    }

    // 元素周期表样式的小方块：原子序数、符号、名称、相对原子质量
    function tile(x, y, s, p) {
      var el = p.el, col = CATC[el.cat];
      ctx.fillStyle = 'rgba(17,23,35,0.88)'; ctx.strokeStyle = col; ctx.lineWidth = 1.5;
      ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(x, y, s, s * 1.12, 8); else ctx.rect(x, y, s, s * 1.12); ctx.fill(); ctx.stroke();
      label(String(el.z), x + 7, y + s * 0.14, col, 'left', Math.round(s * 0.16), '600', false, true);
      label(el.sym, x + s / 2, y + s * 0.5, C.text, 'center', Math.round(s * 0.4), '700', false);
      label(el.name, x + s / 2, y + s * 0.8, C.text, 'center', Math.round(s * 0.17), '', false);
      label(el.mass, x + s / 2, y + s * 1.0, C.muted, 'center', Math.round(s * 0.14), '', false, true);
    }

    // ---------- 教材式原子结构示意图 ----------
    // cx, cy 为整幅图的中心；u 为尺寸单位（约等于核圆的直径）
    function schematic(cx, cy, u, z, e, opts) {
      opts = opts || {};
      var sh = A.shells(e), R0 = u * 0.5, step = u * 0.62, span = 0.62;
      var right = R0 + step * Math.max(sh.length, 0.4) + u * 0.2;
      var nx = cx - (right - R0) / 2, bottom = cy + (R0 + step * sh.length) * Math.sin(span);                 // 让核与电子层整体居中
      var fsN = Math.round(u * 0.42), fsD = Math.round(u * 0.46);
      ctx.lineWidth = Math.max(1.5, u * 0.045);
      ctx.strokeStyle = C.text; circle(nx, cy, R0); ctx.stroke();
      label('+' + z, nx, cy + 1, C.text, 'center', fsN, '600', false);
      var mono = opts.mono;
      sh.forEach(function (c, k) {
        var r = R0 + step * (k + 1), col = mono ? C.text : SHELL[k];
        var gap = (fsD * 0.62) / r;
        ctx.strokeStyle = col; ctx.lineWidth = Math.max(1.5, u * 0.045);
        ctx.beginPath(); ctx.arc(nx, cy, r, -span, -gap); ctx.stroke();
        ctx.beginPath(); ctx.arc(nx, cy, r, gap, span); ctx.stroke();
        label(String(c), nx + r, cy + 1, col, 'center', fsD, '600', false);
      });
      if (opts.callouts && sh.length) {
        var fs = clamp(Math.round(u * 0.24), 11, 15);
        var rl = R0 + step * sh.length, lead = Math.max(rl * Math.sin(span) + u * 0.35, u * 1.1);
        ctx.strokeStyle = C.muted; ctx.lineWidth = 1;
        // 上方：电子层（指第一层弧线的上端）、该层上的电子数（指最外层的数字）
        var r1 = R0 + step, a1 = -0.5, p1 = [nx + r1 * Math.cos(a1), cy + r1 * Math.sin(a1)];
        line(p1[0], p1[1], p1[0] - u * 0.35, cy - lead);
        label('电子层', p1[0] - u * 0.35, cy - lead - fs * 0.8, C.muted, 'center', fs, '', false);
        var dx = nx + rl, dy = cy - fsD * 0.55;
        line(dx, dy, dx + u * 0.35, cy - lead);
        label('该层上的电子数', dx + u * 0.35, cy - lead - fs * 0.8, C.muted, 'left', fs, '', false);
        // 下方：原子核、质子数
        line(nx - R0 * 0.7, cy + R0 * 0.7, nx - R0 * 1.2, cy + lead);
        label('原子核', nx - R0 * 1.2, cy + lead + fs * 0.8, C.muted, 'right', fs, '', false);
        line(nx + R0 * 0.15, cy + fsN * 0.5, nx + R0 * 0.4, cy + lead);
        label('质子数（核电荷数）', nx + R0 * 0.2, cy + lead + fs * 0.8, C.muted, 'left', fs, '', false);
        bottom = cy + lead + fs * 1.4;
      }
      return { nx: nx, right: nx + right, bottom: bottom };
    }
    function line(x0, y0, x1, y1) { ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke(); }

    // ---------- 场景一：原子结构 ----------
    function drawAtom(st, dt) {
      var p = st.p, a = area();
      var wide = a.w >= a.h * 1.3;
      var bo = wide ? { x: a.x, y: a.y, w: a.w * 0.6, h: a.h } : { x: a.x, y: a.y, w: a.w, h: a.h * 0.64 };
      var sc = wide ? { x: a.x + a.w * 0.6, y: a.y, w: a.w * 0.4, h: a.h } : { x: a.x, y: a.y + a.h * 0.64, w: a.w, h: a.h * 0.36 };

      // 分层模型
      var bx = bo.x + bo.w / 2, by = bo.y + bo.h / 2 - (st.labels ? 22 : 0);
      var Rout = Math.max(40, Math.min(bo.w / 2 - 16, bo.h / 2 - (st.labels ? 46 : 18)));
      lastRout = Rout;
      var nSh = Math.max(1, p.shells.length);
      if (shDisp === null) shDisp = nSh;
      shDisp += (nSh - shDisp) * (1 - Math.exp(-dt / 0.18));
      var rn = Math.max(9, Rout * 0.15 * Math.cbrt(Math.max(p.a, 1) / 40));
      var gap = (Rout - rn) / (shDisp + 0.3);
      var radii = [];
      for (var k = 0; k < 4; k++) radii.push(rn + gap * (k + 1));
      lastR = radii;

      // 轨道
      var shown = Math.ceil(shDisp - 0.02);
      for (k = 0; k < Math.max(shown, p.shells.length); k++) {
        var al = clamp(shDisp - k + (k < p.shells.length ? 1 : 0), 0, 1);
        ctx.globalAlpha = al * 0.55;
        ctx.strokeStyle = SHELL[k]; ctx.lineWidth = 1.2;
        ctx.setLineDash(k === p.shells.length - 1 ? [] : [4, 5]);
        circle(bx, by, radii[k]); ctx.stroke();
        ctx.setLineDash([]);
        ctx.globalAlpha = 1;
      }
      nucleus(bx, by, rn, p.z, p.n);

      // 电子
      var er = clamp(Rout * 0.028, 3.5, 7.5);
      var hidden = {};
      st.fx.forEach(function (f) { if (f.kind === 'in') hidden[f.k + '-' + f.i] = true; });
      p.shells.forEach(function (c, k) {
        for (var i = 0; i < c; i++) {
          if (hidden[k + '-' + i]) continue;
          var ang = slotAngle(k, i, c, st.clock);
          electron(bx + radii[k] * Math.cos(ang), by + radii[k] * Math.sin(ang), er, SHELL[k]);
        }
      });
      // 飞走 / 飞来的电子
      st.fx.forEach(function (f) {
        var u = clamp((st.now - f.t0) / f.dur, 0, 1), e = ease(u), x, y;
        if (f.kind === 'out') {
          var r = f.rf * Rout + (Rout * 1.9 - f.rf * Rout) * e, ang = f.ang + e * 0.6;
          x = bx + r * Math.cos(ang); y = by + r * Math.sin(ang);
          electron(x, y, er, C.gold, 1 - u * u);
          if (u < 0.85) label('e⁻', x + er * 2.2, y - er * 2.2, C.gold, 'left', 12, '600');
        } else {
          var c = p.shells[f.k] || f.i + 1, ta = slotAngle(f.k, f.i, c, st.clock), tr = radii[f.k];
          var sx = bx + Rout * 1.9 * Math.cos(f.ang0), sy = by + Rout * 1.9 * Math.sin(f.ang0);
          x = sx + (bx + tr * Math.cos(ta) - sx) * e; y = sy + (by + tr * Math.sin(ta) - sy) * e;
          electron(x, y, er, u < 1 ? C.gold : SHELL[f.k], Math.min(1, u * 3));
          if (u < 0.85) label('e⁻', x + er * 2.2, y - er * 2.2, C.gold, 'left', 12, '600');
        }
      });

      if (st.labels) {
        // 电子层编号
        p.shells.forEach(function (c, k) {
          var ang = -PI * 0.3, r = radii[k];
          label('第' + (k + 1) + '层', bx + (r + 4) * Math.cos(ang) + 4, by + (r + 4) * Math.sin(ang) - 6, SHELL[k], 'left', 12, '600');
        });
        if (!p.shells.length) label('没有核外电子', bx, by - rn - 18, C.muted, 'center', 12);
        label('原子核', bx, by + rn + 13, C.text, 'center', 12, '600');
        // 图例
        var ly = by + Rout + 26, items = [['质子', '#ef5350', p.z], ['中子', '#a9b4c2', p.n], ['电子', SHELL[0], p.e]];
        font(13); var tw = 0, ws = items.map(function (it) { var w = ctx.measureText(it[0] + ' ' + it[2]).width + 30; tw += w; return w; });
        var lx = bx - tw / 2;
        items.forEach(function (it, i) {
          ctx.fillStyle = it[1]; circle(lx + 7, ly, 5); ctx.fill();
          label(it[0] + ' ' + it[2], lx + 16, ly, C.text, 'left', 13, '', false);
          lx += ws[i];
        });
        label('原子核实际只有原子直径的约十万分之一，图中已大大放大', bx, ly + 20, C.muted, 'center', 11, '', false);
      }

      // 周期表小方块
      tile(bo.x + 4, bo.y + 4, narrow ? 50 : 66, p);

      // 结构示意图（标注展开时要给上下的说明文字和右侧的"该层上的电子数"留出位置）
      var nS = Math.max(p.shells.length, 1), co = st.labels && wide;
      var u = co ? Math.min(sc.w / (1.6 + 0.62 * nS + 2.4), sc.h / 6.4) : Math.min(sc.w / (1.35 + 0.62 * nS + 0.3) * 0.75, sc.h * 0.3);
      u = clamp(u, 20, 72);
      var cx = sc.x + sc.w / 2 - (co ? u * 0.9 : 0), cy = sc.y + sc.h * (co ? 0.44 : 0.4);
      var sm = schematic(cx, cy, u, p.z, p.e, { callouts: co });
      var sy = Math.max(sm.bottom, cy + u * 0.6) + u * 0.62;
      label(p.symbol, sc.x + sc.w / 2, sy, p.kind === 'atom' ? C.text : p.kind === 'cation' ? C.cation : C.anion, 'center', Math.round(clamp(u * 0.5, 16, 30)), '600', false);
      label(p.name + '结构示意图', sc.x + sc.w / 2, sy + clamp(u * 0.5, 16, 30), C.muted, 'center', 12, '', false);
    }

    // ---------- 场景二：离子化合物的形成 ----------
    function drawPair(st) {
      var a = area(), key = st.pair, P = A.PAIRS[key], plan = pairPlan(key), s = A.pairState(P, st.pairT);
      var n = plan.length, maxSh = 0;
      plan.forEach(function (at) { maxSh = Math.max(maxSh, at.sh.length); });
      var Ra = Math.min(a.w / (n * 2.75), a.h * 0.3);
      var rn = Math.max(13, Ra * 0.2), gap = (Ra - rn) / maxSh;
      var spacing = Ra * 2.7;
      var cy = a.y + a.h * 0.44, x0 = a.x + a.w / 2 - spacing * (n - 1) / 2;
      var er = clamp(Ra * 0.06, 3, 6.5);
      var pos = plan.map(function (at, i) { return x0 + spacing * i; });

      function complete(at) { return at.moves.every(function (m) { return m < s.done; }); }

      // 相互作用：阴阳离子之间的静电作用
      if (s.bond > 0) {
        ctx.globalAlpha = s.bond;
        ctx.strokeStyle = C.accent; ctx.setLineDash([5, 5]); ctx.lineWidth = 1.2;
        for (var i = 0; i + 1 < n; i++) {
          var xa = pos[i] + Ra + 6, xb = pos[i + 1] - Ra - 6;
          line(xa, cy, xb, cy); if (!narrow) label('静电作用', (xa + xb) / 2, cy - 12, C.accent, 'center', 12, '', true);
        }
        ctx.setLineDash([]);
        ctx.globalAlpha = 1;
      }

      plan.forEach(function (at, i) {
        var x = pos[i], el = A.EL[at.z], last = at.sh.length - 1, done = complete(at);
        var metal = at.out.length > 0;
        var e = at.z + (metal ? -1 : 1) * at.moves.filter(function (m) { return m < s.done; }).length;
        // 失去全部最外层电子后，最外层轨道淡出
        var outerAlpha = 1;
        if (metal) {
          var gone = at.out.filter(function (o) { return o.m < s.done; }).length + (at.out.some(function (o) { return o.m === s.cur; }) ? s.u : 0);
          outerAlpha = 1 - 0.85 * gone / at.out.length;
        }
        var glow = done && s.done > 0 ? (metal ? C.cation : C.anion) : null;
        if (glow) {
          var g = ctx.createRadialGradient(x, cy, Ra * 0.5, x, cy, Ra * 1.25);
          g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(0.8, glow + '22'); g.addColorStop(1, 'rgba(0,0,0,0)');
          ctx.fillStyle = g; circle(x, cy, Ra * 1.25); ctx.fill();
        }
        at.sh.forEach(function (c, k) {
          var r = rn + gap * (k + 1);
          ctx.globalAlpha = (k === last ? outerAlpha : 1) * 0.55;
          ctx.strokeStyle = SHELL[k]; ctx.lineWidth = 1.2; circle(x, cy, r); ctx.stroke();
          ctx.globalAlpha = 1;
          if (k < last) {
            for (var j = 0; j < c; j++) {
              var an = -PI / 2 + TAU * j / c + (c === 2 ? 0 : PI / c);
              electron(x + r * Math.cos(an), cy + r * Math.sin(an), er, SHELL[k]);
            }
            return;
          }
          at.seats.forEach(function (st2) {
            var sx = x + r * Math.cos(st2.ang), sy = cy + r * Math.sin(st2.ang);
            if (st2.kind === 'fill') electron(sx, sy, er, SHELL[k]);
            else if (st2.kind === 'out') { if (st2.m > s.cur && st2.m >= s.done) electron(sx, sy, er, SHELL[k]); }
            else if (st2.m < s.done) electron(sx, sy, er, C.gold);
            else {   // 空位
              ctx.strokeStyle = 'rgba(255,110,199,0.75)'; ctx.setLineDash([2, 2]); ctx.lineWidth = 1;
              circle(sx, sy, er); ctx.stroke(); ctx.setLineDash([]);
            }
          });
        });
        // 原子核
        var gN = ctx.createRadialGradient(x - rn * 0.3, cy - rn * 0.3, rn * 0.1, x, cy, rn);
        gN.addColorStop(0, '#ff8a80'); gN.addColorStop(1, '#8e1f1f');
        ctx.fillStyle = gN; circle(x, cy, rn); ctx.fill();
        label('+' + at.z, x, cy + 1, '#fff', 'center', Math.round(rn * 0.75), '600', false);
        // 名称与电子排布
        var sym = A.symbol(at.z, e), nm = A.pname(at.z, e);
        var col = done && s.done > 0 ? (metal ? C.cation : C.anion) : C.text;
        label(sym, x, cy + Ra + 22, col, 'center', 20, '700');
        if (narrow) {
          label(nm, x, cy + Ra + 42, C.muted, 'center', 11);
          label(A.shells(e).join(', '), x, cy + Ra + 58, C.muted, 'center', 11, '', true, true);
        } else label(nm + '  ' + A.shells(e).join(', '), x, cy + Ra + 44, C.muted, 'center', 12);
        if (done && s.done > 0 && !narrow) {
          var q = at.z - e;
          label(A.chargeStr(q) ? (q > 0 ? '带 ' + q + ' 个单位正电荷' : '带 ' + (-q) + ' 个单位负电荷') : '', x, cy - Ra - 16, col, 'center', 12);
        }
      });

      // 正在转移的电子
      if (s.cur >= 0) {
        var m = P.moves[s.cur], src = plan[m[0]], dst = plan[m[1]];
        var srcSeat = src.seats.filter(function (q) { return q.m === s.cur && q.kind === 'out'; })[0];
        var dstSeat = dst.seats.filter(function (q) { return q.m === s.cur && q.kind === 'in'; })[0];
        var r1 = rn + gap * src.sh.length, r2 = rn + gap * dst.sh.length;
        var p0 = [pos[m[0]] + r1 * Math.cos(srcSeat.ang), cy + r1 * Math.sin(srcSeat.ang)];
        var p2 = [pos[m[1]] + r2 * Math.cos(dstSeat.ang), cy + r2 * Math.sin(dstSeat.ang)];
        var p1 = [(p0[0] + p2[0]) / 2, cy - Ra * 0.95];
        var bez = function (u) {
          var v = 1 - u;
          return [v * v * p0[0] + 2 * v * u * p1[0] + u * u * p2[0], v * v * p0[1] + 2 * v * u * p1[1] + u * u * p2[1]];
        };
        ctx.strokeStyle = 'rgba(255,110,199,0.35)'; ctx.setLineDash([3, 4]); ctx.lineWidth = 1;
        ctx.beginPath(); ctx.moveTo(p0[0], p0[1]); ctx.quadraticCurveTo(p1[0], p1[1], p2[0], p2[1]); ctx.stroke(); ctx.setLineDash([]);
        var ue = ease(clamp(s.u * 1.15, 0, 1));
        for (var tr = 5; tr >= 1; tr--) {
          var q0 = bez(Math.max(0, ue - tr * 0.025));
          electron(q0[0], q0[1], er * (1 - tr * 0.12), C.gold, 0.12);
        }
        var q = bez(ue);
        electron(q[0], q[1], er, C.gold);
        label('e⁻', q[0] + er * 2.2, q[1] - er * 2.2, C.gold, 'left', 13, '600');
      }

      // 底部：化学式
      var fy = cy + Ra + 84;
      if (s.bond > 0) {
        ctx.globalAlpha = s.bond;
        label(P.formula + '（' + P.name + '）', a.x + a.w / 2, fy, C.accent, 'center', 22, '700');
        ctx.globalAlpha = 1;
      }
      label(A.pairEquation(P), a.x + a.w / 2, fy + 32, C.muted, 'center', 13, '', false);
    }

    // ---------- 场景三：练习 ----------
    function drawQuiz(st) {
      var a = area(), q = st.quiz;
      var u = clamp(Math.min(a.w / (1.35 + 0.62 * Math.max(A.shells(q.e).length, 1) + 0.3) * 0.7, a.h * 0.22), 26, 78);
      var cy = a.y + a.h * 0.42;
      label('这是什么粒子？', a.x + a.w / 2, cy - u * 2.1, C.muted, 'center', 15, '', false);
      schematic(a.x + a.w / 2, cy, u, q.z, q.e, { mono: !q.answered });
      if (q.answered) {
        var k = q.z === q.e ? C.text : q.z > q.e ? C.cation : C.anion;
        label(A.pname(q.z, q.e) + '  ' + A.symbol(q.z, q.e), a.x + a.w / 2, cy + u * 1.7, k, 'center', Math.round(u * 0.5), '700', false);
      }
    }

    function draw(st, dt) {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, W, H);
      if (st.scene === 'atom') drawAtom(st, dt);
      else if (st.scene === 'ion') drawPair(st);
      else drawQuiz(st);
    }

    // 某个电子当前的位置（相对原子中心，用于"失去电子"的飞出动画）
    function slotInfo(k, i, c, clock) {
      return { ang: slotAngle(k, i, c, clock), rf: (lastR[k] || lastRout) / lastRout };
    }

    return { resize: resize, draw: draw, slotInfo: slotInfo };
  }

  window.AtomDraw = AtomDraw;
})();
