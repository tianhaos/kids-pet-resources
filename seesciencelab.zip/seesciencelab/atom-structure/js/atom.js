// 原子结构：1–20 号元素数据、核外电子排布、离子、同位素、离子化合物的形成、练习题
// 只做计算和文案，不碰 DOM。粒子用 { z: 质子数, e: 核外电子数, n: 中子数 } 表示。
(function () {
  // z, 符号, 名称, 相对原子质量（教材取值）, 常见中子数, 类别, 常见离子电荷（null = 不易形成简单离子）, 常见化合价, 同位素质量数, 小知识
  var RAW = [
    [1, 'H', '氢', '1', 0, 'nonmetal', 1, '+1', [1, 2, 3], '宇宙中最多的元素；最轻的气体。'],
    [2, 'He', '氦', '4', 2, 'noble', 0, '0', [3, 4], '密度很小又很稳定，用来充探空气球。'],
    [3, 'Li', '锂', '7', 4, 'metal', 1, '+1', [6, 7], '最轻的金属，用于锂电池。'],
    [4, 'Be', '铍', '9', 5, 'metal', 2, '+2', [9], '轻而坚硬，用于航天材料。'],
    [5, 'B', '硼', '11', 6, 'nonmetal', null, '+3', [10, 11], '碱液沾到皮肤上，要用大量水冲洗，再涂上硼酸溶液。'],
    [6, 'C', '碳', '12', 6, 'nonmetal', null, '+2、+4', [12, 13, 14], '金刚石、石墨都由碳原子构成；碳-14 可用来测定文物年代。'],
    [7, 'N', '氮', '14', 7, 'nonmetal', 3, '−3、+2、+4、+5', [14, 15], '空气中含量最多的气体（体积分数约 78%）。'],
    [8, 'O', '氧', '16', 8, 'nonmetal', 2, '−2', [16, 17, 18], '地壳中含量最多的元素。'],
    [9, 'F', '氟', '19', 10, 'nonmetal', 1, '−1', [19], '含氟牙膏可以预防龋齿。'],
    [10, 'Ne', '氖', '20', 10, 'noble', 0, '0', [20, 21, 22], '通电时发出红光，用于霓虹灯。'],
    [11, 'Na', '钠', '23', 12, 'metal', 1, '+1', [23], '食盐（NaCl）中含有钠离子。'],
    [12, 'Mg', '镁', '24', 12, 'metal', 2, '+2', [24, 25, 26], '燃烧时发出耀眼的白光，可做照明弹。'],
    [13, 'Al', '铝', '27', 14, 'metal', 3, '+3', [27], '地壳中含量最多的金属元素。'],
    [14, 'Si', '硅', '28', 14, 'nonmetal', null, '+4', [28, 29, 30], '地壳中含量第二的元素；芯片的材料。'],
    [15, 'P', '磷', '31', 16, 'nonmetal', 3, '−3、+5', [31], '红磷燃烧产生大量白烟，用于测定空气中氧气的含量。'],
    [16, 'S', '硫', '32', 16, 'nonmetal', 2, '−2、+4、+6', [32, 33, 34, 36], '在氧气中燃烧发出明亮的蓝紫色火焰。'],
    [17, 'Cl', '氯', '35.5', 18, 'nonmetal', 1, '−1、+1、+5、+7', [35, 37], '食盐（NaCl）中含有氯离子；相对原子质量 35.5 是两种同位素的平均值。'],
    [18, 'Ar', '氩', '40', 22, 'noble', 0, '0', [36, 38, 40], '空气中含量最多的稀有气体，用作焊接保护气。'],
    [19, 'K', '钾', '39', 20, 'metal', 1, '+1', [39, 40, 41], '植物生长需要的营养元素之一（钾肥）。'],
    [20, 'Ca', '钙', '40', 20, 'metal', 2, '+2', [40, 42, 43, 44, 46, 48], '人体中含量最多的金属元素，主要在骨骼和牙齿中。']
  ];
  var CAT = { metal: '金属元素', nonmetal: '非金属元素', noble: '稀有气体元素' };
  var GROUP = ['ⅠA', 'ⅡA', 'ⅢA', 'ⅣA', 'ⅤA', 'ⅥA', 'ⅦA', '0'];

  var EL = [null];
  RAW.forEach(function (r) {
    EL.push({ z: r[0], sym: r[1], name: r[2], mass: r[3], n: r[4], cat: r[5], ion: r[6], val: r[7], iso: r[8], fact: r[9] });
  });
  EL.forEach(function (el) {
    if (!el) return;
    var sh = shells(el.z);
    el.period = sh.length;
    // 周期表中的列 0..7（ⅠA…ⅦA、0 族），氦在 0 族
    el.col = el.cat === 'noble' ? 7 : sh[sh.length - 1] - 1;
    el.group = GROUP[el.col];
    // 常见离子：金属失电子成阳离子，非金属得电子成阴离子（氢取 H⁺）
    el.ionE = el.ion === null || el.ion === 0 ? null : el.z + (el.cat === 'metal' || el.z === 1 ? -el.ion : el.ion);
  });

  // 初中排布规律：第 1 层最多 2 个，第 2 层最多 8 个，最外层不超过 8 个（1–20 号元素第 3 层排到 8 个后开始排第 4 层）
  function shells(e) {
    var cap = [2, 8, 8, 8], out = [];
    for (var i = 0; e > 0 && i < cap.length; i++) { var k = Math.min(e, cap[i]); out.push(k); e -= k; }
    return out;
  }

  var SUP = { '0': '⁰', '1': '¹', '2': '²', '3': '³', '4': '⁴', '5': '⁵', '6': '⁶', '7': '⁷', '8': '⁸', '9': '⁹', '+': '⁺', '-': '⁻' };
  function sup(s) { return String(s).split('').map(function (c) { return SUP[c] || c; }).join(''); }
  function chargeStr(q) { return q === 0 ? '' : sup((Math.abs(q) > 1 ? Math.abs(q) : '') + (q > 0 ? '+' : '-')); }

  // 粒子的符号与名称：Na、Na⁺、Cl⁻；钠原子、钠离子
  function symbol(z, e) { return EL[z].sym + chargeStr(z - e); }
  function pname(z, e) { return EL[z].name + (z === e ? '原子' : '离子'); }

  // 粒子的完整描述
  function describe(z, e, n) {
    var el = EL[z], q = z - e, sh = shells(e), outer = sh.length ? sh[sh.length - 1] : 0;
    var stable = e === 0 || (sh.length === 1 ? outer === 2 : outer === 8);
    var kind = q === 0 ? 'atom' : q > 0 ? 'cation' : 'anion';
    var common = q === 0 || e === el.ionE;
    return {
      z: z, e: e, n: n, el: el, q: q, shells: sh, outer: outer, stable: stable, kind: kind, common: common,
      a: z + n, symbol: symbol(z, e), name: pname(z, e)
    };
  }

  // 原子在化学反应中的倾向
  function tendency(el) {
    var o = shells(el.z), out = o[o.length - 1];
    if (el.z === 1) return '最外层 1 个电子。氢是非金属，但在化学反应中容易失去这 1 个电子，常见化合价为 +1。';
    if (el.z === 2) return '只有 1 个电子层，2 个电子就排满了，属于相对稳定结构，化学性质很不活泼。';
    if (el.cat === 'noble') return '最外层 8 个电子，属于相对稳定结构，一般不易得失电子，化学性质很不活泼。';
    if (el.ion === null) return '最外层 ' + out + ' 个电子，既不容易得到也不容易失去电子，常与其他原子共用电子（共价键，高中学习）。';
    if (el.cat === 'metal') return '最外层 ' + out + ' 个电子（少于 4 个），在化学反应中容易失去 ' + out + ' 个电子，形成阳离子 ' + symbol(el.z, el.ionE) + '，达到相对稳定结构。';
    return '最外层 ' + out + ' 个电子（多于 4 个），在化学反应中容易得到 ' + (8 - out) + ' 个电子，形成阴离子 ' + symbol(el.z, el.ionE) + '，达到相对稳定结构。';
  }

  // 同位素名称
  var ISO_NAME = { '1-1': '氕', '1-2': '氘', '1-3': '氚' };
  function isoLabel(z, a) { return sup(a) + EL[z].sym; }
  function isoName(z, a) { return ISO_NAME[z + '-' + a] || EL[z].name + '-' + a; }

  // 电子数可调范围：失去最多 3 个，得到最多 3 个；不超过 max(z, 18) 个
  function eRange(z) { return [Math.max(0, z - 3), Math.min(z + 3, Math.max(z, 18))]; }

  // ---------- 离子化合物的形成 ----------
  // atoms：从左到右排列；moves：电子转移顺序 [从, 到]
  var PAIRS = {
    NaCl: { name: '氯化钠', formula: 'NaCl', atoms: [11, 17], moves: [[0, 1]] },
    MgO:  { name: '氧化镁', formula: 'MgO', atoms: [12, 8], moves: [[0, 1], [0, 1]] },
    MgCl2: { name: '氯化镁', formula: 'MgCl₂', atoms: [17, 12, 17], moves: [[1, 0], [1, 2]] },
    Na2O: { name: '氧化钠', formula: 'Na₂O', atoms: [11, 8, 11], moves: [[0, 1], [2, 1]] },
    CaF2: { name: '氟化钙', formula: 'CaF₂', atoms: [9, 20, 9], moves: [[1, 0], [1, 2]] },
    KCl:  { name: '氯化钾', formula: 'KCl', atoms: [19, 17], moves: [[0, 1]] }
  };
  function pairEquation(p) {
    function side(list) {
      var cnt = {}, order = [];
      list.forEach(function (s) { if (!cnt[s]) { cnt[s] = 0; order.push(s); } cnt[s]++; });
      return order.map(function (s) { return (cnt[s] > 1 ? cnt[s] : '') + s; }).join(' + ');
    }
    var metalFirst = p.atoms.slice().sort(function (a, b) { return (EL[a].cat === 'metal' ? 0 : 1) - (EL[b].cat === 'metal' ? 0 : 1); });
    return side(metalFirst.map(function (z) { return EL[z].sym; })) + ' → ' +
      side(metalFirst.map(function (z) { return symbol(z, EL[z].ionE); })) + ' → ' + p.formula;
  }

  // 动画时间线：开场 → 逐个转移电子 → 阴阳离子相互作用
  var PT = { intro: 0.8, move: 1.6, bond: 1.6 };
  function pairState(p, t) {
    var n = p.moves.length, k = (t - PT.intro) / PT.move;
    var s = { done: 0, cur: -1, u: 0, bond: 0, total: PT.intro + n * PT.move + PT.bond };
    if (k < 0) return s;
    if (k < n) { s.done = s.cur = Math.floor(k); s.u = k - s.cur; return s; }
    s.done = n;
    s.bond = Math.min(1, (t - PT.intro - n * PT.move) / PT.bond);
    return s;
  }
  // 第 i 步开始的时刻（i = moves.length 为相互作用阶段）
  function pairStepTime(p, i) { return PT.intro + i * PT.move; }

  // ---------- 练习：看结构示意图判断粒子 ----------
  var QUIZ_POOL = [];
  for (var z = 1; z <= 20; z++) {
    QUIZ_POOL.push({ z: z, e: z });
    if (EL[z].ionE !== null && [1, 4, 7, 15].indexOf(z) < 0) QUIZ_POOL.push({ z: z, e: EL[z].ionE });
  }
  // 所有可作为选项的粒子：原子 + 各元素常见离子
  var ALL = [];
  for (z = 1; z <= 20; z++) { ALL.push({ z: z, e: z }); if (EL[z].ionE !== null) ALL.push({ z: z, e: EL[z].ionE }); }

  function shuffle(a, rnd) {
    for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(rnd() * (i + 1)), t = a[i]; a[i] = a[j]; a[j] = t; }
    return a;
  }
  function same(p, q) { return p.z === q.z && p.e === q.e; }
  // 干扰项优先选：电子数相同的粒子（如 Ne、Na⁺、Mg²⁺、F⁻、O²⁻），其次是质子数相同的粒子、相邻元素的原子
  function quiz(rnd, prev) {
    rnd = rnd || Math.random;
    var t;
    do { t = QUIZ_POOL[Math.floor(rnd() * QUIZ_POOL.length)]; } while (prev && same(t, prev));
    var iso = shuffle(ALL.filter(function (p) { return p.e === t.e && !same(p, t); }), rnd);
    var near = shuffle(ALL.filter(function (p) {
      return !same(p, t) && p.e !== t.e && (p.z === t.z || (p.z === p.e && Math.abs(p.z - t.z) <= 2));
    }), rnd);
    var opts = [t].concat(iso.slice(0, 2));
    near.forEach(function (p) { if (opts.length < 4) opts.push(p); });
    iso.slice(2).forEach(function (p) { if (opts.length < 4) opts.push(p); });
    return { z: t.z, e: t.e, options: shuffle(opts, rnd) };
  }
  function explain(z, e) {
    var q = z - e;
    var how = q === 0 ? '质子数 = 核外电子数 = ' + z + '，是原子'
      : q > 0 ? '质子数 ' + z + ' > 核外电子数 ' + e + '，是带 ' + q + ' 个单位正电荷的阳离子'
      : '质子数 ' + z + ' < 核外电子数 ' + e + '，是带 ' + (-q) + ' 个单位负电荷的阴离子';
    return '核内有 ' + z + ' 个质子，是' + EL[z].name + '元素；' + how + '：' + pname(z, e) + ' ' + symbol(z, e) + '。';
  }

  window.Atom = {
    EL: EL, CAT: CAT, GROUP: GROUP, PAIRS: PAIRS,
    shells: shells, sup: sup, chargeStr: chargeStr, symbol: symbol, pname: pname,
    describe: describe, tendency: tendency, isoLabel: isoLabel, isoName: isoName, eRange: eRange,
    pairEquation: pairEquation, pairState: pairState, pairStepTime: pairStepTime, quiz: quiz, explain: explain
  };
})();
