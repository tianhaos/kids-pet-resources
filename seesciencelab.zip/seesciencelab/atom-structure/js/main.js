(function () {
  var A = window.Atom, EL = A.EL;
  var $ = function (id) { return document.getElementById(id); };
  var qa = function (sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); };

  var state = {
    scene: 'atom', z: 11, e: 11, n: 12, spin: true, labels: true,
    clock: 0, now: 0, fx: [], queue: [], qNext: 0,
    pair: 'NaCl', pairT: 0, pairPlay: true,
    quiz: null, score: { right: 0, total: 0 }
  };

  var stage = $('stage'), canvas = $('atom'), panel = $('panel');
  var view = window.AtomDraw(canvas);

  function setSeg(attr, val) { qa('[data-' + attr + ']').forEach(function (b) { b.classList.toggle('on', b.dataset[attr] === String(val)); }); }

  // ---------- 场景 ----------
  var HINT = {
    atom: '点选元素，看电子怎样分层排布 · 让原子得失电子变成离子',
    ion: '金属原子把最外层电子交给非金属原子，双方都达到稳定结构',
    quiz: '看结构示意图：质子数定元素，质子数与电子数定原子或离子'
  };
  function setScene(s) {
    state.scene = s;
    setSeg('scene', s);
    qa('[data-for]').forEach(function (el) { el.hidden = el.dataset.for !== s; });
    $('hint').textContent = narrowHint ? '' : HINT[s];
    $('hint').hidden = narrowHint;
    if (s === 'quiz' && !state.quiz) nextQuiz();
    if (s === 'ion') syncPair();
  }
  qa('[data-scene]').forEach(function (b) {
    b.addEventListener('click', function () { setScene(b.dataset.scene); Analytics.track('原子结构', '场景', b.textContent); });
  });

  // ---------- 元素周期表（1–20 号） ----------
  var pt = $('ptable');
  A.GROUP.forEach(function (g, i) {
    var h = document.createElement('span');
    h.className = 'gh'; h.textContent = g; h.style.gridColumn = i + 2; h.style.gridRow = 1;
    pt.appendChild(h);
  });
  for (var r = 1; r <= 4; r++) {
    var ph = document.createElement('span');
    ph.className = 'rh'; ph.textContent = r; ph.title = '第 ' + r + ' 周期'; ph.style.gridColumn = 1; ph.style.gridRow = r + 1;
    pt.appendChild(ph);
  }
  for (var z = 1; z <= 20; z++) {
    var el = EL[z], b = document.createElement('button');
    b.className = 'el ' + el.cat; b.dataset.z = z;
    b.style.gridColumn = el.col + 2; b.style.gridRow = el.period + 1;
    b.title = el.name + '（' + el.sym + '）· ' + A.shells(z).join(', ');
    b.innerHTML = '<i>' + z + '</i><b>' + el.sym + '</b><span>' + el.name + '</span>';
    pt.appendChild(b);
  }
  pt.addEventListener('click', function (e) {
    var b = e.target.closest('button.el');
    if (b) { setZ(+b.dataset.z); Analytics.track('原子结构', '选元素', EL[+b.dataset.z].sym); }
  });
  $('prevEl').addEventListener('click', function () { setZ(state.z > 1 ? state.z - 1 : 20); });
  $('nextEl').addEventListener('click', function () { setZ(state.z < 20 ? state.z + 1 : 1); });
  document.addEventListener('keydown', function (e) {
    if (state.scene !== 'atom' || /INPUT|SELECT|TEXTAREA/.test(e.target.tagName)) return;
    if (e.key === 'ArrowRight') setZ(state.z < 20 ? state.z + 1 : 1);
    else if (e.key === 'ArrowLeft') setZ(state.z > 1 ? state.z - 1 : 20);
  });

  function setZ(z) {
    state.z = z; state.e = z; state.n = EL[z].n;
    state.fx = []; state.queue = [];
    buildIsos();
    syncAtom();
  }

  // ---------- 得失电子 ----------
  function changeE(d) {
    var rg = A.eRange(state.z), e = state.e;
    if (d < 0 && e > rg[0]) {
      var sh = A.shells(e), k = sh.length - 1, inf = view.slotInfo(k, sh[k] - 1, sh[k], state.clock);
      state.fx.push({ kind: 'out', ang: inf.ang, rf: inf.rf, t0: state.now, dur: 1.1 });
      state.e--;
    } else if (d > 0 && e < rg[1]) {
      state.e++;
      var sh2 = A.shells(state.e), k2 = sh2.length - 1;
      state.fx.push({ kind: 'in', k: k2, i: sh2[k2] - 1, ang0: Math.random() * Math.PI * 2, t0: state.now, dur: 0.9 });
    } else return false;
    syncAtom();
    return true;
  }
  // 依次得失多个电子（每隔一小段时间一个，看得清）
  function queueTo(target) {
    state.queue = [];
    for (var e = state.e; e !== target; e += target > e ? 1 : -1) state.queue.push(target > e ? 1 : -1);
    state.qNext = state.now;
  }
  $('eMinus').addEventListener('click', function () { state.queue = []; changeE(-1); Analytics.track('原子结构', '得失电子', '失去'); });
  $('ePlus').addEventListener('click', function () { state.queue = []; changeE(1); Analytics.track('原子结构', '得失电子', '得到'); });
  $('eStable').addEventListener('click', function () {
    var el = EL[state.z];
    if (el.ionE !== null) { queueTo(el.ionE); Analytics.track('原子结构', '得失电子', '稳定离子'); }
  });
  $('eReset').addEventListener('click', function () { queueTo(state.z); });

  // ---------- 同位素 ----------
  function buildIsos() {
    var box = $('isos'), el = EL[state.z];
    box.innerHTML = '';
    el.iso.forEach(function (a) {
      var b = document.createElement('button');
      b.dataset.n = a - el.z;
      b.innerHTML = '<b>' + A.isoLabel(el.z, a) + '</b><small>' + A.isoName(el.z, a) + '</small>';
      b.addEventListener('click', function () { state.n = a - el.z; syncAtom(); Analytics.track('原子结构', '同位素', A.isoName(el.z, a)); });
      box.appendChild(b);
    });
  }

  // ---------- 显示 ----------
  $('spin').addEventListener('change', function () { state.spin = $('spin').checked; });
  $('labels').addEventListener('change', function () { state.labels = $('labels').checked; });

  // ---------- 原子结构面板 ----------
  function syncAtom() {
    var p = A.describe(state.z, state.e, state.n), el = p.el, rg = A.eRange(state.z);
    qa('#ptable .el').forEach(function (b) { b.classList.toggle('on', +b.dataset.z === state.z); });
    $('rName').textContent = p.name;
    $('rSym').textContent = p.symbol;
    $('rSym').className = p.kind;
    var tip;
    if (p.kind === 'atom') tip = A.tendency(el);
    else {
      var lost = state.z - state.e;
      tip = p.name + ' ' + p.symbol + '：' + el.name + '原子' + (lost > 0 ? '失去 ' + lost : '得到 ' + (-lost)) + ' 个电子形成的' +
        (lost > 0 ? '阳离子' : '阴离子') + '。' +
        (p.common ? (p.stable ? (p.e ? '最外层达到 ' + p.outer + ' 个电子的相对稳定结构。' : '氢原子失去唯一的电子后只剩下原子核（1 个质子）。') : '')
          : '这种离子不稳定，在中学化学里不会出现——' + (el.ionE === null ? el.name + '原子一般不得失电子。' : el.name + '的常见离子是 ' + A.symbol(el.z, el.ionE) + '。'));
    }
    $('rTip').textContent = tip;
    $('rP').textContent = p.z + '（= 核电荷数 = 原子序数）';
    $('rE').innerHTML = p.e + (p.kind === 'atom' ? ' <span class="eq">= 质子数</span>' : p.kind === 'cation' ? ' <span class="lt">&lt; 质子数</span>' : ' <span class="gt">&gt; 质子数</span>');
    $('rQ').textContent = p.q === 0 ? '不显电性（正负电荷数相等）' : '带 ' + Math.abs(p.q) + ' 个单位' + (p.q > 0 ? '正' : '负') + '电荷';
    $('rSh').textContent = p.shells.length ? p.shells.join(', ') + '（最外层 ' + p.outer + ' 个' + (p.stable ? '，稳定结构' : '') + '）' : '无';
    $('rN').textContent = p.n;
    $('rA').textContent = p.a + ' = ' + p.z + ' + ' + p.n + '（相对原子质量 ' + el.mass + '）';
    $('rPos').textContent = '第 ' + el.period + ' 周期 · ' + el.group + ' 族';
    $('rCat').textContent = A.CAT[el.cat] + ' · 常见化合价 ' + el.val;
    $('rFact').textContent = '💡 ' + el.fact;

    $('eMinus').disabled = state.e <= rg[0];
    $('ePlus').disabled = state.e >= rg[1];
    $('eStable').disabled = el.ionE === null || state.e === el.ionE;
    $('eStable').textContent = el.ionE === null ? '不易形成离子' : '变成 ' + A.symbol(el.z, el.ionE);
    $('eReset').disabled = state.e === state.z;
    $('eNote').textContent = el.cat === 'noble' ? '稀有气体原子已是稳定结构，一般不得失电子。' :
      el.ionE === null ? el.name + '原子最外层 ' + A.shells(el.z).slice(-1)[0] + ' 个电子，不容易得失电子。' :
      el.cat === 'metal' || el.z === 1 ? '金属原子（和氢原子）容易失去最外层电子，形成阳离子。' : '非金属原子容易得到电子，使最外层达到 8 个。';

    setSeg('n', state.n);
    var iso = A.isoName(el.z, p.a);
    $('isoNote').textContent = el.iso.length > 1
      ? '这几种原子质子数都是 ' + el.z + '，中子数不同，互为同位素，都属于' + el.name + '元素。当前：' + iso + '，' + p.n + ' 个中子。'
      : el.name + '在自然界只有一种稳定的原子：' + p.n + ' 个中子。';
  }

  // ---------- 离子的形成 ----------
  qa('[data-pair]').forEach(function (b) {
    b.addEventListener('click', function () {
      state.pair = b.dataset.pair; state.pairT = 0; state.pairPlay = true; syncPair();
      Analytics.track('原子结构', '离子化合物', b.dataset.pair);
    });
  });
  $('pairPlay').addEventListener('click', function () {
    var P = A.PAIRS[state.pair];
    if (state.pairT >= A.pairState(P, state.pairT).total) state.pairT = 0;
    state.pairPlay = !state.pairPlay; syncPair();
  });
  $('pairReset').addEventListener('click', function () { state.pairT = 0; state.pairPlay = true; syncPair(); });
  $('pairSteps').addEventListener('click', function (e) {
    var li = e.target.closest('li');
    if (!li) return;
    state.pairT = A.pairStepTime(A.PAIRS[state.pair], +li.dataset.i) + 0.001; state.pairPlay = true; syncPair();
  });

  function syncPair() {
    var P = A.PAIRS[state.pair];
    lastStep = -2; lastPlay = null;
    setSeg('pair', state.pair);
    $('pName').textContent = P.name + ' ' + P.formula;
    $('pEq').textContent = A.pairEquation(P);
    var ol = $('pairSteps'), html = '';
    var left = function (i, j) { return P.atoms.length > 2 ? (j < i ? '左边的' : '右边的') : ''; };
    P.moves.forEach(function (m, i) {
      var s = EL[P.atoms[m[0]]], t = EL[P.atoms[m[1]]];
      html += '<li data-i="' + i + '">' + s.name + '原子把最外层的 1 个电子转移给' + left(m[0], m[1]) + t.name + '原子</li>';
    });
    var ions = [], seen = {};
    P.atoms.slice().sort(function (a, b) { return (EL[a].cat === 'metal' ? 0 : 1) - (EL[b].cat === 'metal' ? 0 : 1); }).forEach(function (z) { var sy = A.symbol(z, EL[z].ionE); if (!seen[sy]) { seen[sy] = 1; ions.push(sy); } });
    html += '<li data-i="' + P.moves.length + '">' + ions.join(' 和 ') + ' 都达到最外层 8 个电子的稳定结构，阴、阳离子相互作用，形成' + P.name + '</li>';
    ol.innerHTML = html;
    var counts = {};
    P.atoms.forEach(function (z) { counts[z] = (counts[z] || 0) + 1; });
    var metal = P.atoms.filter(function (z) { return EL[z].cat === 'metal'; })[0], non = P.atoms.filter(function (z) { return EL[z].cat !== 'metal'; })[0];
    $('pNote').textContent = '每个' + EL[metal].name + '原子失去 ' + EL[metal].ion + ' 个电子，每个' + EL[non].name + '原子得到 ' + EL[non].ion +
      ' 个电子，所以 ' + EL[metal].sym + ' 与 ' + EL[non].sym + ' 的个数比是 ' + counts[metal] + ' : ' + counts[non] +
      '，化合物中正负电荷总数相等，整体不显电性。';
  }

  // ---------- 练习 ----------
  function nextQuiz() {
    var q = A.quiz(Math.random, state.quiz);
    state.quiz = { z: q.z, e: q.e, options: q.options, answered: false };
    var box = $('qOpts');
    box.innerHTML = '';
    q.options.forEach(function (o) {
      var b = document.createElement('button');
      b.textContent = A.symbol(o.z, o.e);
      b.dataset.z = o.z; b.dataset.e = o.e;
      b.addEventListener('click', function () { answer(b, o); });
      box.appendChild(b);
    });
    $('qFeedback').textContent = '';
    $('qFeedback').className = 'note';
    $('qNext').hidden = true;
  }
  function answer(btn, o) {
    var q = state.quiz;
    if (q.answered) return;
    q.answered = true;
    var ok = o.z === q.z && o.e === q.e;
    state.score.total++;
    if (ok) state.score.right++;
    qa('#qOpts button').forEach(function (b) {
      var right = +b.dataset.z === q.z && +b.dataset.e === q.e;
      b.classList.toggle('right', right);
      b.classList.toggle('wrong', b === btn && !ok);
      b.disabled = true;
    });
    $('qFeedback').textContent = (ok ? '✓ 答对了。' : '✗ 不对。') + A.explain(q.z, q.e);
    $('qFeedback').className = 'note ' + (ok ? 'ok' : 'bad');
    $('qScore').textContent = '答对 ' + state.score.right + ' / ' + state.score.total;
    $('qNext').hidden = false;
    Analytics.track('原子结构', '练习', ok ? '对' : '错');
  }
  $('qNext').addEventListener('click', nextQuiz);
  $('qToAtom').addEventListener('click', function () {
    var q = state.quiz;
    setZ(q.z); state.e = q.e; state.fx = []; syncAtom(); setScene('atom');
  });

  // ---------- 面板 ----------
  $('panelToggle').addEventListener('click', function () { panel.classList.toggle('collapsed'); });
  if (window.matchMedia('(max-width: 760px)').matches) panel.classList.add('collapsed');
  var narrowHint = window.matchMedia('(max-width: 640px)').matches;

  // ---------- 尺寸与主循环 ----------
  function resize() { view.resize(stage.clientWidth, stage.clientHeight); }
  new ResizeObserver(resize).observe(stage);
  resize();

  // 支持 ?el=Na（或 ?z=11）、?scene=ion&pair=MgCl2、?scene=quiz 直接打开
  var qs = new URLSearchParams(location.search), z0 = 11;
  if (qs.get('z') && +qs.get('z') >= 1 && +qs.get('z') <= 20) z0 = +qs.get('z');
  if (qs.get('el')) for (var i = 1; i <= 20; i++) if (EL[i].sym.toLowerCase() === qs.get('el').toLowerCase()) z0 = i;
  if (A.PAIRS[qs.get('pair')]) state.pair = qs.get('pair');
  setZ(z0);
  syncPair();
  setScene(['atom', 'ion', 'quiz'].indexOf(qs.get('scene')) >= 0 ? qs.get('scene') : 'atom');

  var lastT = performance.now(), lastPlay = null, lastStep = -2;
  function frame(t) {
    var dt = Math.min((t - lastT) / 1000, 0.1);
    lastT = t;
    state.now += dt;
    if (state.spin) state.clock += dt;
    // 排队中的得失电子
    if (state.queue.length && state.now >= state.qNext) {
      changeE(state.queue.shift());
      state.qNext = state.now + 0.4;
    }
    state.fx = state.fx.filter(function (f) { return state.now - f.t0 < f.dur; });

    if (state.scene === 'ion') {
      var P = A.PAIRS[state.pair], ps = A.pairState(P, state.pairT);
      if (state.pairPlay) {
        state.pairT += dt;
        if (state.pairT >= ps.total) { state.pairT = ps.total; state.pairPlay = false; }
      }
      ps = A.pairState(P, state.pairT);
      var step = ps.cur >= 0 ? ps.cur : ps.bond > 0 ? P.moves.length : ps.done ? P.moves.length - 1 : -1;
      if (step !== lastStep) {
        lastStep = step;
        qa('#pairSteps li').forEach(function (li, i) { li.className = i < step || (ps.bond >= 1 && i === step) ? 'done' : i === step ? 'cur' : ''; });
      }
      if (lastPlay !== state.pairPlay) {
        lastPlay = state.pairPlay;
        $('pairPlay').textContent = state.pairPlay ? '❚❚ 暂停' : '▶ 播放';
      }
    }

    view.draw({
      scene: state.scene, p: A.describe(state.z, state.e, state.n), spin: state.spin, labels: state.labels,
      clock: state.clock, now: state.now, fx: state.fx, pair: state.pair, pairT: state.pairT, quiz: state.quiz
    }, dt);
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // 调试用
  window.__model = { state: state, view: view, setZ: setZ, changeE: changeE, setScene: setScene, nextQuiz: nextQuiz };
})();
