// 气温和降水：气候类型、代表城市的逐月气温/降水（多年平均的近似值）、统计与"以温定带、以水定型"的判读
(function () {
  var MON = ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'];
  var NH_SUMMER = [3, 4, 5, 6, 7, 8];        // 北半球夏半年 4–9 月（月份下标）
  var SH_SUMMER = [9, 10, 11, 0, 1, 2];      // 南半球夏半年 10 月—次年 3 月

  // 判读阈值
  var LIM = {
    tropic: 15,      // 最冷月 > 15 °C：热带
    temperate: 0,    // 最冷月 < 0 °C：温带
    cold: 10,        // 最热月 < 10 °C：寒带
    ocean: 22,       // 最热月 < 22 °C 且降水均匀：温带海洋性
    dry: 250,        // 年降水 < 250 mm：干旱（沙漠）
    dryMonth: 50,    // 月降水 < 50 mm 算干季
    monsoonP: 1500,  // 热带：有干季、年降水 ≥ 1500 mm 为热带季风，否则热带草原
    medShare: 0.6,   // 冬半年降水 ≥ 60% 且夏季最干月 < 30 mm：地中海
    medDry: 30,
    tmShare: 0.7,    // 温带：年降水 ≥ 400 mm 且夏半年占 ≥ 70%：温带季风
    tmP: 400,
    highAlt: 2000    // 海拔 ≥ 2000 m 的低纬度地区按高原山地气候
  };

  // 气候类型（顺序即面板上的排列：热带 → 亚热带 → 温带 → 寒带 → 高原）
  var TYPES = {
    rainforest: { name: '热带雨林气候', short: '热带雨林', zone: '热带', color: '#3fbf6f',
      feat: '全年高温多雨', temp: '终年高温，各月均温都在 25 °C 以上，气温年较差很小', rain: '全年多雨，年降水量一般在 2000 mm 以上',
      where: '赤道附近：亚马孙平原、刚果盆地、马来群岛', why: '终年受赤道低气压带控制，盛行上升气流' },
    savanna: { name: '热带草原气候', short: '热带草原', zone: '热带', color: '#c5d94a',
      feat: '全年高温，分明显的干季和湿季', temp: '终年高温，最热月出现在雨季到来之前', rain: '年降水量 750～1000 mm 左右，湿季多雨、干季少雨',
      where: '热带雨林气候的南北两侧：非洲中部、巴西高原、澳大利亚北部', why: '赤道低气压带和信风带交替控制' },
    monsoonT: { name: '热带季风气候', short: '热带季风', zone: '热带', color: '#2fd6b4',
      feat: '全年高温，分旱雨两季', temp: '终年高温，最热月多在 4—5 月（雨季来临之前）', rain: '雨季降水特别集中，年降水量多在 1500 mm 以上',
      where: '亚洲南部和东南部：印度半岛、中南半岛、我国海南岛和台湾南部', why: '海陆热力性质差异和气压带风带季节移动形成季风，夏季西南季风带来大量降水' },
    desertT: { name: '热带沙漠气候', short: '热带沙漠', zone: '热带', color: '#f2b260',
      feat: '全年高温少雨（炎热干燥）', temp: '终年炎热，气温日较差很大', rain: '全年少雨，年降水量多在 250 mm 以下',
      where: '南北回归线附近的大陆内部和西岸：撒哈拉、阿拉伯半岛、澳大利亚中西部、秘鲁沿海', why: '终年受副热带高气压带或干燥的信风控制，盛行下沉气流；西岸还受寒流影响' },
    subtrop: { name: '亚热带季风和季风性湿润气候', short: '亚热带季风', zone: '亚热带', color: '#ff8a80',
      feat: '夏季高温多雨，冬季温和少雨', temp: '最冷月 0～15 °C，夏季炎热', rain: '年降水量 800 mm 以上，夏季多、冬季少，雨热同期',
      where: '南北纬 25°～35° 的大陆东岸：我国秦岭—淮河以南、日本南部、美国东南部、南美东南部、澳大利亚东部', why: '海陆热力性质差异形成季风，夏季风从海洋带来大量水汽' },
    med: { name: '地中海气候', short: '地中海', zone: '亚热带', color: '#c9a7ff',
      feat: '夏季炎热干燥，冬季温和多雨', temp: '最冷月 0～15 °C，夏季炎热', rain: '降水集中在冬季，夏季干燥少雨，雨热不同期',
      where: '南北纬 30°～40° 的大陆西岸：地中海沿岸、美国加利福尼亚、智利中部、南非西南部、澳大利亚西南部', why: '夏季受副热带高气压带控制（干热），冬季受西风带控制（温和多雨）' },
    ocean: { name: '温带海洋性气候', short: '温带海洋性', zone: '温带', color: '#64b5f6',
      feat: '全年温和湿润（冬无严寒，夏无酷暑）', temp: '最冷月在 0 °C 以上，最热月在 22 °C 以下，气温年较差小', rain: '全年都有降水，各月分配比较均匀',
      where: '南北纬 40°～60° 的大陆西岸：西欧、北美西北部、智利南部、新西兰', why: '终年受西风带控制，西风从海洋带来温暖湿润的空气，沿岸还有暖流增温增湿' },
    monsoonW: { name: '温带季风气候', short: '温带季风', zone: '温带', color: '#4dd0e1',
      feat: '夏季高温多雨，冬季寒冷干燥', temp: '最冷月低于 0 °C，夏季较热，气温年较差较大', rain: '降水集中在夏季（7、8 月最多），雨热同期',
      where: '亚洲东部北纬 35°～55°：我国华北、东北，朝鲜半岛，日本北部，俄罗斯远东南部', why: '海陆热力性质差异形成季风：冬季受来自内陆的冬季风影响寒冷干燥，夏季受来自海洋的夏季风影响' },
    cont: { name: '温带大陆性气候', short: '温带大陆性', zone: '温带', color: '#d4a373',
      feat: '冬冷夏热，气温年较差大，降水少', temp: '冬季寒冷漫长，夏季较热，气温年较差大', rain: '降水较少且多在夏季，越往大陆内部越少（可形成温带草原、温带沙漠）',
      where: '亚欧大陆和北美大陆内部：中亚、我国西北、蒙古、俄罗斯大部', why: '深居内陆，距海远，海洋湿润气流难以到达' },
    tundra: { name: '苔原气候', short: '苔原', zone: '寒带', color: '#a7c0cc',
      feat: '全年寒冷，夏季短暂凉爽', temp: '最热月 0～10 °C，冬季漫长严寒', rain: '降水少',
      where: '北冰洋沿岸：亚欧大陆和北美大陆北部、格陵兰沿海', why: '纬度高，获得的太阳辐射少' },
    icecap: { name: '冰原气候', short: '冰原', zone: '寒带', color: '#e8eef2',
      feat: '终年严寒', temp: '各月均温都在 0 °C 以下', rain: '降水极少，以降雪为主',
      where: '南极大陆、格陵兰内部', why: '纬度最高，太阳辐射弱，冰雪反射强，常年受极地高气压带控制' },
    highland: { name: '高原山地气候', short: '高原山地', zone: '高原', color: '#b08d7a',
      feat: '气温随海拔升高而降低，比同纬度平原低得多', temp: '同纬度比平原低得多，"一山有四季"，垂直变化明显', rain: '降水因海拔、坡向不同而差异大',
      where: '青藏高原、安第斯山脉、东非高原、落基山脉等', why: '海拔高，气温随海拔升高而降低（约每升高 1000 m 下降 6 °C）' }
  };
  var TYPE_KEYS = Object.keys(TYPES);

  // 代表城市：t 各月平均气温 °C，p 各月降水量 mm（多年平均的近似值，取整）；lat 北正南负，lon 东正西负，alt 海拔 m
  var CITIES = {
    singapore: { name: '新加坡', type: 'rainforest', lat: 1.4, lon: 103.8, alt: 15, where: '马来半岛南端',
      t: [26.5, 27.1, 27.6, 28.0, 28.4, 28.4, 28.0, 27.9, 27.6, 27.6, 26.9, 26.4], p: [222, 105, 151, 154, 172, 132, 146, 146, 125, 156, 257, 318] },
    manaus: { name: '马瑙斯', type: 'rainforest', lat: -3.1, lon: -60.0, alt: 67, where: '巴西，亚马孙平原',
      t: [26.3, 26.2, 26.3, 26.4, 26.6, 26.6, 26.8, 27.5, 27.9, 27.9, 27.5, 26.9], p: [264, 292, 316, 302, 256, 114, 88, 58, 83, 126, 183, 217] },
    ouaga: { name: '瓦加杜古', type: 'savanna', lat: 12.4, lon: -1.5, alt: 306, where: '布基纳法索，非洲西部',
      t: [24.9, 27.9, 31.2, 32.6, 31.6, 28.9, 27.1, 26.1, 26.9, 28.9, 28.0, 25.4], p: [0, 1, 7, 27, 74, 104, 182, 212, 128, 36, 1, 0] },
    cuiaba: { name: '库亚巴', type: 'savanna', lat: -15.6, lon: -56.1, alt: 165, where: '巴西，巴西高原西部',
      t: [26.8, 26.8, 26.9, 26.4, 24.8, 23.4, 23.4, 25.4, 27.4, 27.6, 27.3, 26.9], p: [211, 209, 207, 104, 49, 15, 10, 15, 52, 117, 163, 201] },
    mumbai: { name: '孟买', type: 'monsoonT', lat: 19.1, lon: 72.9, alt: 14, where: '印度，印度半岛西岸',
      t: [24.3, 25.0, 27.0, 28.8, 30.1, 29.0, 27.7, 27.3, 27.7, 28.7, 27.6, 25.6], p: [1, 0, 0, 1, 11, 537, 828, 512, 312, 72, 14, 1] },
    haikou: { name: '海口', type: 'monsoonT', lat: 20.0, lon: 110.3, alt: 14, where: '中国，海南岛北部',
      t: [17.7, 19.0, 21.9, 25.2, 27.4, 28.4, 28.8, 28.3, 27.3, 25.6, 22.6, 19.2], p: [21, 34, 55, 99, 182, 234, 195, 262, 280, 179, 78, 30] },
    khartoum: { name: '喀土穆', type: 'desertT', lat: 15.6, lon: 32.5, alt: 380, where: '苏丹，撒哈拉沙漠东南缘',
      t: [23.2, 25.0, 28.7, 31.9, 34.5, 34.3, 32.1, 31.5, 32.5, 32.4, 28.1, 24.5], p: [0, 0, 0, 0, 4, 5, 46, 75, 25, 5, 1, 0] },
    lima: { name: '利马', type: 'desertT', lat: -12.0, lon: -77.0, alt: 13, where: '秘鲁，南美洲西岸（秘鲁寒流）',
      t: [22.7, 23.4, 23.0, 21.2, 19.0, 17.2, 16.4, 16.0, 16.3, 17.4, 18.9, 21.0], p: [1, 1, 1, 0, 1, 1, 2, 2, 1, 1, 0, 1] },
    guangzhou: { name: '广州', type: 'subtrop', lat: 23.1, lon: 113.3, alt: 41, where: '中国，珠江三角洲',
      t: [13.9, 15.3, 18.4, 22.4, 25.8, 27.6, 28.7, 28.6, 27.3, 24.6, 20.3, 15.5], p: [47, 64, 92, 190, 286, 318, 234, 252, 172, 58, 40, 34] },
    shanghai: { name: '上海', type: 'subtrop', lat: 31.2, lon: 121.5, alt: 4, where: '中国，长江入海口',
      t: [4.8, 6.6, 10.3, 15.7, 21.0, 24.7, 29.0, 28.7, 24.9, 19.9, 14.0, 7.4], p: [74, 59, 103, 89, 103, 212, 152, 228, 108, 62, 52, 40] },
    buenos: { name: '布宜诺斯艾利斯', type: 'subtrop', lat: -34.6, lon: -58.4, alt: 25, where: '阿根廷，南美洲东南岸',
      t: [24.9, 23.7, 21.7, 17.9, 14.6, 11.7, 11.0, 12.8, 14.6, 17.8, 20.9, 23.6], p: [122, 123, 154, 107, 92, 58, 61, 63, 78, 139, 131, 103] },
    rome: { name: '罗马', type: 'med', lat: 41.9, lon: 12.5, alt: 20, where: '意大利，地中海沿岸',
      t: [8.0, 8.9, 11.2, 13.8, 17.9, 21.8, 24.6, 24.8, 21.2, 17.1, 12.4, 9.0], p: [67, 73, 58, 81, 53, 34, 19, 37, 73, 113, 111, 91] },
    perth: { name: '珀斯', type: 'med', lat: -31.9, lon: 115.9, alt: 15, where: '澳大利亚西南部',
      t: [24.5, 24.9, 23.0, 19.8, 16.4, 14.0, 13.1, 13.5, 14.9, 17.3, 20.3, 22.5], p: [15, 12, 19, 36, 93, 128, 147, 114, 77, 40, 22, 8] },
    london: { name: '伦敦', type: 'ocean', lat: 51.5, lon: -0.1, alt: 25, where: '英国，西欧（北大西洋暖流）',
      t: [5.2, 5.3, 7.6, 9.9, 13.3, 16.5, 18.7, 18.5, 15.7, 12.0, 8.0, 5.5], p: [55, 41, 42, 44, 49, 45, 45, 50, 49, 69, 59, 55] },
    wellington: { name: '惠灵顿', type: 'ocean', lat: -41.3, lon: 174.8, alt: 10, where: '新西兰北岛南端',
      t: [17.8, 18.1, 16.7, 14.6, 12.4, 10.4, 9.6, 10.1, 11.4, 12.6, 14.3, 16.3], p: [87, 74, 90, 99, 124, 140, 140, 120, 104, 104, 88, 84] },
    beijing: { name: '北京', type: 'monsoonW', lat: 39.9, lon: 116.4, alt: 44, where: '中国，华北平原北部',
      t: [-3.1, 0.3, 6.7, 14.8, 20.8, 24.9, 26.7, 25.5, 20.8, 13.7, 5.0, -0.9], p: [3, 5, 9, 26, 35, 78, 185, 160, 46, 22, 10, 3] },
    harbin: { name: '哈尔滨', type: 'monsoonW', lat: 45.8, lon: 126.6, alt: 143, where: '中国，东北平原',
      t: [-17.6, -12.6, -3.6, 7.4, 15.0, 21.0, 23.4, 21.7, 15.6, 6.3, -4.4, -14.2], p: [4, 4, 10, 24, 44, 96, 162, 117, 63, 26, 12, 6] },
    moscow: { name: '莫斯科', type: 'cont', lat: 55.8, lon: 37.6, alt: 156, where: '俄罗斯，东欧平原',
      t: [-6.2, -5.9, -0.7, 6.9, 13.6, 17.4, 19.7, 17.6, 11.9, 5.8, -0.5, -4.4], p: [53, 44, 39, 37, 61, 78, 84, 78, 66, 70, 52, 51] },
    urumqi: { name: '乌鲁木齐', type: 'cont', lat: 43.8, lon: 87.6, alt: 935, where: '中国，新疆（亚欧大陆中心附近）',
      t: [-12.2, -9.4, 0.2, 10.4, 17.3, 22.6, 24.6, 23.1, 17.1, 8.2, -1.7, -9.6], p: [11, 11, 17, 32, 32, 36, 29, 24, 22, 21, 17, 13] },
    yakutsk: { name: '雅库茨克', type: 'cont', lat: 62.0, lon: 129.7, alt: 98, where: '俄罗斯，西伯利亚东部', note: '高中把这类冬季极冷、夏季短暂的气候细分为亚寒带针叶林气候',
      t: [-38.6, -33.8, -20.1, -4.8, 7.5, 16.4, 19.5, 15.2, 6.1, -7.8, -27.0, -37.6], p: [9, 8, 7, 10, 22, 36, 40, 41, 26, 18, 15, 10] },
    barrow: { name: '乌特恰维克（巴罗）', type: 'tundra', lat: 71.3, lon: -156.8, alt: 3, where: '美国阿拉斯加，北冰洋沿岸',
      t: [-25.4, -26.7, -25.5, -17.0, -5.5, 2.0, 5.3, 4.2, -0.3, -9.4, -18.2, -23.4], p: [4, 4, 3, 4, 4, 8, 25, 25, 17, 10, 5, 4] },
    southpole: { name: '南极点', type: 'icecap', lat: -89.9, lon: 0, alt: 2835, where: '南极大陆（阿蒙森—斯科特站）', mapLat: -84,
      t: [-27.0, -39.2, -51.5, -57.2, -57.4, -57.4, -59.3, -59.6, -58.8, -51.2, -38.1, -27.5], p: [1, 1, 1, 0, 1, 1, 0, 1, 0, 1, 0, 1] },
    lhasa: { name: '拉萨', type: 'highland', lat: 29.7, lon: 91.1, alt: 3650, where: '中国，青藏高原',
      t: [-2.2, 1.0, 4.4, 8.3, 12.3, 15.3, 15.1, 14.3, 12.7, 8.3, 2.3, -1.7], p: [1, 1, 2, 5, 27, 72, 119, 123, 58, 10, 2, 1] },
    quito: { name: '基多', type: 'highland', lat: -0.2, lon: -78.5, alt: 2850, where: '厄瓜多尔，安第斯山脉',
      t: [14.1, 14.1, 14.0, 14.1, 14.2, 14.2, 14.0, 14.4, 14.5, 14.3, 14.0, 14.0], p: [99, 112, 141, 175, 98, 39, 19, 25, 77, 109, 98, 91] }
  };
  var CITY_KEYS = Object.keys(CITIES);
  TYPE_KEYS.forEach(function (k) { TYPES[k].cities = CITY_KEYS.filter(function (c) { return CITIES[c].type === k; }); });

  function sum(a) { return a.reduce(function (s, v) { return s + v; }, 0); }
  function r1(v) { return Math.round(v * 10) / 10; }
  function fmtT(v) { return (v < 0 ? '−' : '') + Math.abs(r1(v)).toFixed(1) + ' °C'; }
  function fmtLat(lat) { return Math.abs(lat) < 0.05 ? '0°' : (lat > 0 ? '北纬 ' : '南纬 ') + Math.abs(lat).toFixed(1) + '°'; }
  function fmtLon(lon) { return Math.abs(lon) < 0.05 ? '0°' : (lon > 0 ? '东经 ' : '西经 ') + Math.abs(lon).toFixed(1) + '°'; }

  // ---------- 统计 ----------
  function stats(t, p) {
    var iMax = 0, iMin = 0, pMax = 0;
    for (var i = 1; i < 12; i++) {
      if (t[i] > t[iMax]) iMax = i;
      if (t[i] < t[iMin]) iMin = i;
      if (p[i] > p[pMax]) pMax = i;
    }
    var nh = sum(NH_SUMMER.map(function (i) { return t[i]; })), sh = sum(SH_SUMMER.map(function (i) { return t[i]; }));
    var range = t[iMax] - t[iMin];
    // 半球：哪半年更热；年较差太小则看不出
    var hemi = range < 3 ? 0 : nh >= sh ? 1 : -1;
    var summer = hemi < 0 ? SH_SUMMER : NH_SUMMER;
    var P = sum(p), pS = sum(summer.map(function (i) { return p[i]; }));
    var dryMonths = [], driestSummer = Infinity;
    for (var j = 0; j < 12; j++) if (p[j] < LIM.dryMonth) dryMonths.push(j);
    summer.forEach(function (i) { driestSummer = Math.min(driestSummer, p[i]); });
    return {
      tMax: t[iMax], iMax: iMax, tMin: t[iMin], iMin: iMin, range: range, tAvg: sum(t) / 12,
      P: P, pMax: p[pMax], iPMax: pMax, hemi: hemi, summer: summer, summerLabel: hemi < 0 ? '10 月—次年 3 月' : '4—9 月',
      winterLabel: hemi < 0 ? '4—9 月' : '10 月—次年 3 月',
      sShare: P > 0 ? pS / P : 0.5, wShare: P > 0 ? 1 - pS / P : 0.5,
      dryMonths: dryMonths, driestSummer: driestSummer
    };
  }

  // 多雨期：降水量 ≥ 年均月降水的连续月份（取最长的一段，可跨年）
  function wetSeason(p) {
    var P = sum(p), avg = P / 12, best = null;
    if (P < LIM.dry) return '全年少雨';
    var wet = p.map(function (v) { return v >= avg * 1.15; });
    if (wet.every(Boolean)) return '全年多雨';
    if (p.every(function (v) { return v >= avg * 0.6; }) && Math.max.apply(null, p) < avg * 1.6) return '各月比较均匀';
    for (var s = 0; s < 12; s++) {
      if (!wet[s] || wet[(s + 11) % 12]) continue;
      var n = 0;
      while (n < 12 && wet[(s + n) % 12]) n++;
      if (!best || n > best.n) best = { s: s, n: n };
    }
    if (!best) return '—';
    var e = (best.s + best.n - 1) % 12;
    return best.n === 1 ? (best.s + 1) + ' 月' : (best.s + 1) + '—' + (e < best.s ? '次年 ' : '') + (e + 1) + ' 月';
  }

  // ---------- 以温定带、以水定型 ----------
  // 返回 { type, chartType（只看图的结论）, steps:[{key, title, text, res}] }
  function classify(t, p, alt) {
    var s = stats(t, p), steps = [], type, zone, rain;
    var mx = MON[s.iMax], mn = MON[s.iMin];

    // ① 半球
    if (s.hemi === 0) {
      steps.push({ key: 'hemi', title: '看气温变化，定南北半球',
        text: '各月气温相差很小（年较差 ' + r1(s.range) + ' °C），看不出冬夏，多在赤道附近，不易判断南北半球。', res: '赤道附近' });
    } else {
      var north = s.hemi > 0;
      steps.push({ key: 'hemi', title: '看气温变化，定南北半球',
        text: '气温最高在 ' + mx + '、最低在 ' + mn + '，较热的半年是 ' + s.summerLabel + ' → ' + (north ? '北半球（7 月前后是夏季）' : '南半球（1 月前后是夏季，与北半球相反）') + '。',
        res: north ? '北半球' : '南半球' });
    }

    // ② 以温定带
    if (s.tMax < LIM.cold) {
      zone = '寒带';
      steps.push({ key: 'zone', title: '以温定带：看最热月和最冷月',
        text: '最热月 ' + fmtT(s.tMax) + ' < 10 °C → 寒带' + (s.tMax < 0 ? '（各月都在 0 °C 以下，终年严寒）' : '（最热月 0～10 °C）') + '。', res: '寒带' });
    } else if (s.tMin > LIM.tropic) {
      zone = '热带';
      steps.push({ key: 'zone', title: '以温定带：看最冷月气温',
        text: '最冷月 ' + fmtT(s.tMin) + ' > 15 °C，终年高温 → 热带。', res: '热带' });
    } else if (s.tMin >= LIM.temperate) {
      zone = '亚热带';
      steps.push({ key: 'zone', title: '以温定带：看最冷月气温',
        text: '最冷月 ' + fmtT(s.tMin) + '，在 0～15 °C 之间，冬季温和 → 亚热带（冬季温和的温带海洋性气候也在这个范围）。', res: '亚热带' });
    } else {
      zone = '温带';
      steps.push({ key: 'zone', title: '以温定带：看最冷月气温',
        text: '最冷月 ' + fmtT(s.tMin) + ' < 0 °C，冬季寒冷 → 温带。', res: '温带' });
    }

    // ③ 以水定型
    var P = Math.round(s.P), sh = Math.round(s.sShare * 100), wh = Math.round(s.wShare * 100);
    if (zone === '寒带') {
      type = s.tMax < 0 ? 'icecap' : 'tundra';
      rain = '年降水量 ' + P + ' mm，很少（气温低，蒸发弱，空气中水汽少）。';
      steps.push({ key: 'rain', title: '以水定型：看降水', text: rain, res: '少雨' });
    } else if (s.P < LIM.dry) {
      type = zone === '温带' || s.tMin < 10 ? 'cont' : 'desertT';
      steps.push({ key: 'rain', title: '以水定型：看年降水量',
        text: '年降水量只有 ' + P + ' mm（< 250 mm），全年少雨 → 干旱。', res: '全年少雨' });
    } else if (zone === '热带') {
      var nd = s.dryMonths.length;
      if (nd === 0) {
        type = 'rainforest';
        steps.push({ key: 'rain', title: '以水定型：看各月降水',
          text: '各月降水都在 50 mm 以上，年降水量 ' + P + ' mm → 全年多雨。', res: '全年多雨' });
      } else if (s.P >= LIM.monsoonP) {
        type = 'monsoonT';
        steps.push({ key: 'rain', title: '以水定型：看降水季节和总量',
          text: '有 ' + nd + ' 个月降水不足 50 mm（旱季），雨季降水集中，年降水量 ' + P + ' mm（≥ 1500 mm）→ 旱雨两季，雨季降水特别多。', res: '旱雨两季' });
      } else {
        type = 'savanna';
        steps.push({ key: 'rain', title: '以水定型：看降水季节和总量',
          text: '有 ' + nd + ' 个月降水不足 50 mm（干季），年降水量 ' + P + ' mm（< 1500 mm）→ 干湿两季明显。', res: '干湿两季' });
      }
    } else if (zone === '亚热带') {
      if (s.wShare >= LIM.medShare && s.driestSummer < LIM.medDry) {
        type = 'med';
        steps.push({ key: 'rain', title: '以水定型：看降水集中在哪个季节',
          text: '冬半年（' + s.winterLabel + '）降水占 ' + wh + '%，夏季最少的月份只有 ' + Math.round(s.driestSummer) + ' mm → 冬雨型：夏季干燥，冬季多雨（雨热不同期）。', res: '冬雨型' });
      } else if (s.tMax < LIM.ocean) {
        type = 'ocean';
        steps.push({ key: 'rain', title: '以水定型：看降水和最热月',
          text: '各月都有降水、分配比较均匀（夏半年占 ' + sh + '%），最热月只有 ' + fmtT(s.tMax) + '（< 22 °C）→ 冬无严寒、夏无酷暑、全年湿润。', res: '全年湿润' });
      } else {
        type = 'subtrop';
        steps.push({ key: 'rain', title: '以水定型：看降水集中在哪个季节',
          text: '年降水量 ' + P + ' mm，夏半年（' + s.summerLabel + '）占 ' + sh + '% → 夏雨型：夏季高温多雨，冬季温和少雨（雨热同期）。', res: '夏雨型' });
      }
    } else {
      if (s.P >= LIM.tmP && s.sShare >= LIM.tmShare) {
        type = 'monsoonW';
        steps.push({ key: 'rain', title: '以水定型：看降水集中在哪个季节',
          text: '年降水量 ' + P + ' mm，夏半年（' + s.summerLabel + '）占 ' + sh + '% → 夏季多雨、冬季少雨，降水集中（雨热同期）。', res: '夏雨型' });
      } else {
        type = 'cont';
        steps.push({ key: 'rain', title: '以水定型：看降水总量和季节',
          text: '年降水量 ' + P + ' mm' + (s.P < LIM.tmP ? '，偏少' : '，夏半年只占 ' + sh + '%，不像季风区那样集中') + '；冬冷夏热，年较差 ' + r1(s.range) + ' °C → 深居内陆，降水少。', res: '降水较少' });
      }
    }

    var chartType = type;
    // 高原山地：低纬度却气温很低，要结合位置和海拔
    if (alt >= LIM.highAlt && type !== 'icecap') {
      type = 'highland';
      steps.push({ key: 'alt', title: '结合位置：看海拔',
        text: '只看图会判成"' + TYPES[chartType].name + '"，但这里海拔 ' + alt + ' m，气温比同纬度平原低得多（约每升高 1000 m 下降 6 °C）→ 高原山地气候。', res: '海拔高' });
    }

    var T = TYPES[type];
    steps.push({ key: 'type', title: '得出结论', text: T.name + '：' + T.feat + '。', res: T.short });
    return { type: type, chartType: chartType, zone: zone, steps: steps, stats: s };
  }

  window.Climate = {
    MON: MON, LIM: LIM, TYPES: TYPES, TYPE_KEYS: TYPE_KEYS, CITIES: CITIES, CITY_KEYS: CITY_KEYS,
    stats: stats, wetSeason: wetSeason, classify: classify,
    sum: sum, fmtT: fmtT, fmtLat: fmtLat, fmtLon: fmtLon
  };
})();
