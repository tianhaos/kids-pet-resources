(function () {
  var K = window.Climate, TYPES = K.TYPES, CITIES = K.CITIES;
  var $ = function (id) { return document.getElementById(id); };
  var qa = function (sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); };

  var state = {
    scene: 'read', city: 'beijing', data: null, cls: null, title: '', subtitle: '',
    focus: null, hover: null, mapHover: null, drag: null, lockRange: null, now: 0,
    opts: { marks: true, refs: false, map: true, fixed: false, values: false },
    quiz: { key: null, answered: false, pick: null, hint: 0, total: 0, right: 0, altHint: null },
    demo: null
  };

  var stage = $('stage'), canvas = $('chart'), panel = $('panel');
  var view = window.ClimDraw(canvas);

  function setSeg(attr, val) { qa('[data-' + attr + ']').forEach(function (b) { b.classList.toggle('on', b.dataset[attr] === String(val)); }); }
  function copy(c) { return { t: c.t.slice(), p: c.p.slice() }; }
  function quizHidden() { return state.scene === 'quiz' && !state.quiz.answered; }

  // ---------- 数据变化后重新判读并刷新面板 ----------
  function recompute() {
    var c = CITIES[state.city], alt = state.scene === 'edit' ? 0 : c.alt;
    state.cls = K.classify(state.data.t, state.data.p, alt);
    if (state.scene === 'edit') {
      state.title = '自己调的数据';
      state.subtitle = '从' + c.name + '的数据开始改 · 拖动红点改气温，拖动柱顶改降水';
    } else {
      state.title = c.name;
      state.subtitle = c.where + ' · ' + K.fmtLat(c.lat) + '，' + K.fmtLon(c.lon) + ' · 海拔 ' + c.alt + ' m';
    }
    sync();
  }

  function setCity(key) {
    if (!CITIES[key]) return;
    state.city = key;
    state.data = copy(CITIES[key]);
    state.focus = null; stopDemo();
    recompute();
  }

  function setScene(sc) {
    state.scene = sc;
    state.focus = null; state.drag = null; state.lockRange = null; stopDemo();
    if (sc === 'quiz') newQuiz();
    else { state.data = copy(CITIES[state.city]); recompute(); }
    canvas.classList.toggle('editing', sc === 'edit');
    Analytics.track('气温降水', '场景', { read: '读图', quiz: '练习', edit: '自己调' }[sc]);
  }

  // ---------- 练习 ----------
  function newQuiz() {
    var keys = K.CITY_KEYS.filter(function (k) { return k !== state.quiz.key; });
    var k = keys[Math.floor(Math.random() * keys.length)], c = CITIES[k];
    state.quiz.key = k; state.quiz.answered = false; state.quiz.pick = null; state.quiz.hint = 0;
    state.quiz.altHint = c.alt >= K.LIM.highAlt ? c.alt : null;
    state.city = k; state.data = copy(c); state.focus = null; stopDemo();
    recompute();
  }
  function answer(type) {
    var q = state.quiz;
    if (q.answered) return;
    q.answered = true; q.pick = type; q.total++;
    var ok = type === CITIES[q.key].type;
    if (ok) q.right++;
    Analytics.track('气温降水', '答题', ok ? '对' : '错');
    recompute();
  }

  // ---------- 一步步演示判读 ----------
  function stopDemo() { state.demo = null; $('demoBtn').textContent = '▶ 一步步演示判读'; }
  function startDemo() {
    if (quizHidden()) state.quiz.hint = state.cls.steps.length - 1;
    state.demo = { i: 0, t: 0 };
    state.focus = state.cls.steps[0].key;
    $('demoBtn').textContent = '■ 停止演示';
    sync();
  }
  function tickDemo(dt) {
    var d = state.demo;
    if (!d) return;
    d.t += dt;
    if (d.t < 2.4) return;
    d.t = 0; d.i++;
    var steps = state.cls.steps, max = quizHidden() ? steps.length - 1 : steps.length;
    if (d.i >= max) { stopDemo(); state.focus = null; syncSteps(); return; }
    state.focus = steps[d.i].key;
    syncSteps();
  }
  $('demoBtn').addEventListener('click', function () { if (state.demo) { stopDemo(); state.focus = null; syncSteps(); } else startDemo(); });

  // ---------- 面板 ----------
  // 气候类型按钮：读图时选城市，练习时作答
  var zoneOf = { '热带': 'z1', '亚热带': 'z2', '温带': 'z3', '寒带': 'z4', '高原': 'z5' };
  $('types').innerHTML = K.TYPE_KEYS.map(function (k) {
    var T = TYPES[k];
    return '<button data-type="' + k + '" style="--c:' + T.color + '"><b>' + T.short + '</b><small>' + T.zone + '</small></button>';
  }).join('');
  qa('[data-type]').forEach(function (b) {
    b.addEventListener('click', function () {
      var k = b.dataset.type;
      if (state.scene === 'quiz') { answer(k); return; }
      var list = TYPES[k].cities;
      setCity(list.indexOf(state.city) >= 0 ? state.city : list[0]);
      Analytics.track('气温降水', '气候类型', TYPES[k].name);
    });
  });

  function syncCities() {
    var T = TYPES[CITIES[state.city].type];
    $('cities').innerHTML = T.cities.map(function (k) {
      return '<button data-city="' + k + '" class="' + (k === state.city ? 'on' : '') + '">' + CITIES[k].name + '</button>';
    }).join('');
    qa('#cities [data-city]').forEach(function (b) {
      b.addEventListener('click', function () { setCity(b.dataset.city); Analytics.track('气温降水', '城市', CITIES[b.dataset.city].name); });
    });
  }

  function syncSteps() {
    var steps = state.cls.steps, hide = quizHidden(), n = hide ? state.quiz.hint : steps.length;
    $('steps').innerHTML = steps.slice(0, n).map(function (s, i) {
      var last = s.key === 'type';
      return '<li data-k="' + s.key + '" class="' + (state.focus === s.key ? 'on' : '') + (last ? ' end' : '') + '">' +
        '<div class="st"><b>' + (last ? '结论' : '第 ' + (i + 1) + ' 步') + '</b> ' + s.title + '<em>' + s.res + '</em></div>' +
        '<p>' + s.text + '</p></li>';
    }).join('') + (hide && n < steps.length - 1 ? '<li class="more">还有 ' + (steps.length - 1 - n) + ' 步，点"提示"逐步显示</li>' : '');
    qa('#steps [data-k]').forEach(function (li) {
      li.addEventListener('click', function () {
        stopDemo();
        state.focus = state.focus === li.dataset.k ? null : li.dataset.k;
        syncSteps();
      });
    });
  }

  function syncTable() {
    var d = state.data, s = state.cls.stats;
    var rows = d.t.map(function (v, i) {
      return '<tr class="' + (i === s.iMax ? 'hi' : i === s.iMin ? 'lo' : '') + '"><td>' + (i + 1) + '</td><td>' + K.fmtT(v).replace(' °C', '') + '</td><td>' + Math.round(d.p[i]) + '</td></tr>';
    }).join('');
    $('table').innerHTML = '<thead><tr><th>月份</th><th>气温 / °C</th><th>降水量 / mm</th></tr></thead><tbody>' + rows +
      '<tr class="sum"><td>全年</td><td>平均 ' + K.fmtT(s.tAvg).replace(' °C', '') + '</td><td>合计 ' + Math.round(s.P) + '</td></tr></tbody>';
  }

  function sync() {
    var sc = state.scene, cls = state.cls, s = cls.stats, c = CITIES[state.city], hide = quizHidden();
    var T = TYPES[cls.type], q = state.quiz;
    setSeg('scene', sc);
    $('quizBox').hidden = sc !== 'quiz';
    $('editBox').hidden = sc !== 'edit';
    $('cities').hidden = sc === 'quiz';
    $('typesTitle').textContent = sc === 'quiz' ? '这是哪种气候？点选作答' : '选择气候类型和城市';
    $('typesNote').hidden = sc === 'quiz';
    $('hintBtn').disabled = !hide || q.hint >= cls.steps.length - 1;

    // 读数
    $('rName').textContent = hide ? '某地' : sc === 'edit' ? '自己调的数据' : c.name;
    $('rKind').textContent = hide ? '？' : T.name;
    $('rKind').style.color = hide ? '' : T.color;
    $('rPos').textContent = hide ? (q.altHint ? '海拔 ' + q.altHint + ' m（位置答完后显示）' : '答完后显示') : sc === 'edit' ? '只看图判断，不考虑海拔' : K.fmtLat(c.lat) + '，' + K.fmtLon(c.lon) + '，海拔 ' + c.alt + ' m';
    $('rTmax').textContent = K.fmtT(s.tMax) + '（' + K.MON[s.iMax] + '）';
    $('rTmin').textContent = K.fmtT(s.tMin) + '（' + K.MON[s.iMin] + '）';
    $('rRange').textContent = s.range.toFixed(1) + ' °C';
    $('rAvg').textContent = K.fmtT(s.tAvg);
    $('rP').textContent = Math.round(s.P) + ' mm';
    $('rWet').textContent = K.wetSeason(state.data.p);
    $('rFeat').textContent = hide ? '' : '气候特点：' + T.feat + (c.note && sc === 'read' ? '。' + c.note : '');
    if (sc === 'edit' && cls.chartType !== CITIES[state.city].type && CITIES[state.city].type !== 'highland') $('rFeat').textContent += '（原来是' + TYPES[CITIES[state.city].type].short + '，改动后变了）';

    // 类型说明
    $('typeInfo').hidden = hide;
    $('tiName').textContent = T.name;
    $('tiName').style.color = T.color;
    $('tiTemp').textContent = T.temp;
    $('tiRain').textContent = T.rain;
    $('tiWhere').textContent = T.where;
    $('tiWhy').textContent = T.why;

    // 类型按钮
    qa('[data-type]').forEach(function (b) {
      var k = b.dataset.type;
      b.classList.toggle('on', sc !== 'quiz' && k === cls.type);
      b.classList.toggle('right', sc === 'quiz' && q.answered && k === CITIES[q.key].type);
      b.classList.toggle('wrong', sc === 'quiz' && q.answered && k === q.pick && q.pick !== CITIES[q.key].type);
    });

    // 练习反馈
    if (sc === 'quiz') {
      var ok = q.pick === c.type;
      $('quizMsg').className = 'note ' + (!q.answered ? '' : ok ? 'ok' : 'bad');
      $('quizMsg').textContent = !q.answered ? '先看气温（定温度带），再看降水（定气候类型）。' + (q.altHint ? '注意海拔。' : '')
        : (ok ? '✓ 答对了！' : '✗ 不对，') + '这是' + c.name + '（' + c.where + '）的' + TYPES[c.type].name + '。';
      $('score').textContent = q.total ? '已答 ' + q.total + ' 题，答对 ' + q.right + ' 题' : '';
      $('nextBtn').classList.toggle('hot', q.answered);
    }

    syncSteps();
    syncCities();
    syncTable();
  }

  qa('[data-scene]').forEach(function (b) { b.addEventListener('click', function () { if (state.scene !== b.dataset.scene) setScene(b.dataset.scene); }); });
  $('nextBtn').addEventListener('click', newQuiz);
  $('hintBtn').addEventListener('click', function () {
    var q = state.quiz;
    if (q.hint < state.cls.steps.length - 1) { q.hint++; state.focus = state.cls.steps[q.hint - 1].key; sync(); }
  });

  // ---------- 自己调数据 ----------
  qa('[data-op]').forEach(function (b) {
    b.addEventListener('click', function () {
      var d = state.data, op = b.dataset.op;
      if (op === 'reset') state.data = copy(CITIES[state.city]);
      else if (op === 'shift') { d.t = d.t.slice(6).concat(d.t.slice(0, 6)); d.p = d.p.slice(6).concat(d.p.slice(0, 6)); }
      else if (op === 'tUp' || op === 'tDown') d.t = d.t.map(function (v) { return Math.round((v + (op === 'tUp' ? 5 : -5)) * 10) / 10; });
      else if (op === 'pUp' || op === 'pDown') d.p = d.p.map(function (v) { return Math.round(Math.min(1200, v * (op === 'pUp' ? 2 : 0.5))); });
      recompute();
      Analytics.track('气温降水', '自己调', b.textContent);
    });
  });

  // ---------- 显示 ----------
  ['marks', 'refs', 'map', 'fixed', 'values'].forEach(function (k) {
    $(k).checked = state.opts[k];
    $(k).addEventListener('change', function () { state.opts[k] = $(k).checked; });
  });

  // ---------- 指针：悬停读数、点地图、拖动数据 ----------
  function pos(e) { var r = canvas.getBoundingClientRect(); return { x: e.clientX - r.left, y: e.clientY - r.top }; }
  function applyDrag(y) {
    var d = state.drag, v = view.valueAt(d.what, y);
    if (d.what === 't') state.data.t[d.i] = Math.round(Math.max(-70, Math.min(45, v)) * 2) / 2;
    else state.data.p[d.i] = Math.max(0, Math.round(v / 5) * 5);
    recompute();
  }
  canvas.addEventListener('pointermove', function (e) {
    var p = pos(e);
    if (state.drag) { state.hover = state.drag.i; applyDrag(p.y); return; }
    state.hover = view.monthAt(p.x, p.y);
    state.mapHover = view.cityAt(p.x, p.y);
    canvas.style.cursor = state.mapHover && !quizHidden() ? 'pointer' : state.scene === 'edit' && state.hover != null ? 'ns-resize' : '';
  });
  canvas.addEventListener('pointerdown', function (e) {
    var p = pos(e), city = view.cityAt(p.x, p.y);
    if (city) {
      if (!quizHidden() && state.scene !== 'quiz') { setCity(city); Analytics.track('气温降水', '地图选城市', CITIES[city].name); }
      return;
    }
    if (state.scene === 'edit') {
      var h = view.handleAt(p.x, p.y, state);
      if (h) {
        state.drag = h; state.lockRange = view.range();
        canvas.setPointerCapture(e.pointerId);
        applyDrag(p.y);
        e.preventDefault();
        return;
      }
    }
    state.hover = view.monthAt(p.x, p.y);
  });
  function endDrag() { if (state.drag) { state.drag = null; state.lockRange = null; } }
  canvas.addEventListener('pointerup', endDrag);
  canvas.addEventListener('pointercancel', endDrag);
  canvas.addEventListener('pointerleave', function () { if (!state.drag) { state.hover = null; state.mapHover = null; } });

  // ←/→ 切换城市
  document.addEventListener('keydown', function (e) {
    if (/INPUT|SELECT|TEXTAREA/.test(e.target.tagName) || state.scene === 'quiz') return;
    if (e.key === 'ArrowLeft' || e.key === 'ArrowRight') {
      var ks = K.CITY_KEYS, i = ks.indexOf(state.city) + (e.key === 'ArrowRight' ? 1 : -1);
      setCity(ks[(i + ks.length) % ks.length]);
      e.preventDefault();
    }
  });

  // ---------- 面板开合 ----------
  $('panelToggle').addEventListener('click', function () { panel.classList.toggle('collapsed'); });
  if (window.matchMedia('(max-width: 760px)').matches) panel.classList.add('collapsed');
  if (window.matchMedia('(max-width: 640px)').matches) $('hint').hidden = true;

  // ---------- 尺寸与主循环 ----------
  function resize() { view.resize(stage.clientWidth, stage.clientHeight); }
  new ResizeObserver(resize).observe(stage);
  resize();

  // 支持 ?city=beijing、?scene=quiz|edit
  var qs = new URLSearchParams(location.search);
  if (CITIES[qs.get('city')]) state.city = qs.get('city');
  state.data = copy(CITIES[state.city]);
  var sc0 = qs.get('scene');
  if (sc0 === 'quiz' || sc0 === 'edit') setScene(sc0); else recompute();

  var lastT = performance.now();
  function frame(t) {
    var dt = Math.min((t - lastT) / 1000, 0.1);
    lastT = t;
    state.now += dt;
    tickDemo(dt);
    view.draw(state);
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // 调试用
  window.__model = { state: state, view: view, setCity: setCity, setScene: setScene, K: K };
})();
