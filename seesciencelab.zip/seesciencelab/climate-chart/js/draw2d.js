// 气温和降水绘图：气温曲线和降水量柱状图（双纵轴）、世界地图上的代表城市
(function () {
  var K = window.Climate, TYPES = K.TYPES, CITIES = K.CITIES;
  var C = { text: '#e6ebf2', muted: '#8d99ab', line: '#2a3446', panel: '#111723', panel2: '#1a2231', accent: '#ffc94a',
    temp: '#ff6b57', rain: '#4fc3f7', bar: 'rgba(79,195,247,0.62)', ocean: '#0a1424', land: '#1d2c29', landLine: '#2e4538', ice: '#27313f' };
  var LAT_TOP = 80, LAT_BOT = -90;          // 地图的纬度范围
  var NICE = [5, 10, 20, 25, 50, 100, 150, 200, 250, 300, 400, 500];

  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
  function fmtN(v) { return (v < 0 ? '−' : '') + Math.abs(v); }

  // 坐标范围：气温每格 10 °C，降水的格数与气温相同，网格线对齐
  function axisRange(t, p, fixed) {
    var mn = Math.min.apply(null, t), mx = Math.max.apply(null, t), pm = Math.max.apply(null, p), lo, hi;
    if (fixed) { lo = mn < -40 ? -60 : -40; hi = 40; }
    else {
      lo = Math.min(0, Math.floor((mn - 2) / 10) * 10);
      hi = Math.max(10, Math.ceil((mx + 2) / 10) * 10);
      while (hi - lo < 30) { if (mx > 0 || lo >= 0) hi += 10; else lo -= 10; }
    }
    var n = Math.round((hi - lo) / 10), step;
    if (fixed) step = 100;
    else {
      step = NICE[NICE.length - 1];
      for (var i = 0; i < NICE.length; i++) if (NICE[i] * n >= pm * 1.08) { step = NICE[i]; break; }
    }
    return { tLo: lo, tHi: hi, n: n, pStep: step, pHi: step * n };
  }

  function ClimDraw(canvas) {
    var ctx = canvas.getContext('2d');
    var W = 0, H = 0, dpr = 1, narrow = false;
    var plot = null, map = null, rng = null;   // 本帧的绘图区、地图区、坐标范围（命中测试用）

    function resize(w, h) {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      W = w; H = h;
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
      canvas.style.width = w + 'px'; canvas.style.height = h + 'px';
      narrow = w < 640;
    }

    function font(sz, bold) { ctx.font = (bold ? '600 ' : '') + sz + 'px -apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", sans-serif'; }
    function label(s, x, y, color, align, sz, bold, base) {
      font(sz || 12, bold); ctx.fillStyle = color || C.text; ctx.textAlign = align || 'left'; ctx.textBaseline = base || 'middle';
      ctx.fillText(s, x, y);
    }
    function rrect(x, y, w, h, r) {
      ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r);
      ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
    }
    function pill(s, x, y, color, sz) {
      font(sz, true);
      var w = ctx.measureText(s).width + 10, h = sz + 6;
      ctx.fillStyle = 'rgba(10,14,22,0.88)'; ctx.strokeStyle = color; ctx.lineWidth = 1;
      rrect(x - w / 2, y - h / 2, w, h, h / 2); ctx.fill(); ctx.stroke();
      label(s, x, y + 0.5, color, 'center', sz, true);
    }

    // ---------- 布局：上面是图，下面是世界地图 ----------
    function layout(st) {
      var top = narrow ? 86 : 44, bottom = H - 8, m = null;
      if (st.opts.map) {
        var mh = Math.min(H * (narrow ? 0.3 : 0.34), (W - 32) * (LAT_TOP - LAT_BOT) / 360), mw = mh * 360 / (LAT_TOP - LAT_BOT);
        m = { x: (W - mw) / 2, y: H - 40 - mh, w: mw, h: mh };
        bottom = m.y - 14;
      }
      var padL = narrow ? 44 : 60, padR = narrow ? 48 : 66;
      var cw = Math.min(W - 24, 980), cx = (W - cw) / 2;
      var titleH = narrow ? 40 : 46;
      return {
        plot: { x: cx + padL, y: top + titleH + 18, w: cw - padL - padR, h: Math.max(80, bottom - 34 - (top + titleH + 18)) },
        title: { x: W / 2, y: top + 10 }, map: m
      };
    }

    // ---------- 气温曲线和降水量柱状图 ----------
    function drawChart(L, st) {
      var P = L.plot, t = st.data.t, p = st.data.p, cls = st.cls, s = cls.stats, f = st.focus;
      var hide = st.scene === 'quiz' && !st.quiz.answered;
      rng = st.lockRange || axisRange(t, p, st.opts.fixed);
      var R = rng, cw = P.w / 12, fsz = narrow ? 11 : 12;
      function X(i) { return P.x + cw * (i + 0.5); }
      function YT(v) { return P.y + P.h - (v - R.tLo) / (R.tHi - R.tLo) * P.h; }
      function YP(v) { return P.y + P.h - v / R.pHi * P.h; }
      plot = { x: P.x, y: P.y, w: P.w, h: P.h, cw: cw, X: X, YT: YT, YP: YP };

      // 标题
      var name = hide ? '某地' : st.title;
      label(name + ' 气温曲线和降水量柱状图', L.title.x, L.title.y, C.text, 'center', narrow ? 14 : 16, true);
      var sub = hide ? (st.quiz.altHint ? '提示：该地海拔 ' + st.quiz.altHint + ' m' : '判断它属于哪种气候类型') : st.subtitle;
      if (sub) label(sub, L.title.x, L.title.y + (narrow ? 20 : 22), hide && st.quiz.altHint ? C.accent : C.muted, 'center', fsz);

      // 季节底色：判读半球或降水时标出"夏半年"
      if (f === 'hemi' || f === 'rain') {
        var mark = s.summer, col = 'rgba(255,201,74,0.08)';
        if (f === 'rain' && cls.type === 'med') { mark = s.summer.map(function (i) { return (i + 6) % 12; }); col = 'rgba(201,167,255,0.10)'; }
        if (!(f === 'hemi' && s.hemi === 0)) {
          ctx.fillStyle = col;
          mark.forEach(function (i) { ctx.fillRect(P.x + cw * i, P.y, cw, P.h); });
          var lab = (f === 'rain' && cls.type === 'med') ? '冬半年' : (s.hemi < 0 ? '夏半年（南半球）' : '夏半年');
          // 跨年的半年（10 月—次年 3 月）把文字写在 10—12 月上方
          var wrap = mark.indexOf(0) >= 0 && mark.indexOf(11) >= 0;
          label(lab, wrap ? X(10) : X(mark[0]) + cw * 2.5, P.y + 10, col === 'rgba(201,167,255,0.10)' ? '#c9a7ff' : C.accent, 'center', fsz - 1);
        }
      }

      // 网格与坐标轴
      ctx.lineWidth = 1;
      for (var k = 0; k <= R.n; k++) {
        var y = P.y + P.h - k / R.n * P.h, tv = R.tLo + k * 10, pv = k * R.pStep;
        ctx.strokeStyle = tv === 0 && k > 0 ? 'rgba(141,153,171,0.45)' : C.line;
        ctx.beginPath(); ctx.moveTo(P.x, y); ctx.lineTo(P.x + P.w, y); ctx.stroke();
        label(fmtN(tv), P.x - 7, y, C.temp, 'right', fsz);
        label(String(pv), P.x + P.w + 7, y, C.rain, 'left', fsz);
      }
      ctx.strokeStyle = '#3a4558';
      ctx.beginPath(); ctx.moveTo(P.x, P.y); ctx.lineTo(P.x, P.y + P.h); ctx.lineTo(P.x + P.w, P.y + P.h); ctx.lineTo(P.x + P.w, P.y); ctx.stroke();
      label('气温/°C', P.x - 4, P.y - 14, C.temp, 'center', fsz);
      label('降水量/mm', P.x + P.w + 4, P.y - 14, C.rain, 'center', fsz);
      for (var i = 0; i < 12; i++) label(String(i + 1), X(i), P.y + P.h + 12, C.muted, 'center', fsz);
      label('月', P.x + P.w + 6, P.y + P.h + 12, C.muted, 'left', fsz);

      // 悬停列
      if (st.hover != null) {
        ctx.fillStyle = 'rgba(255,255,255,0.05)';
        ctx.fillRect(P.x + cw * st.hover, P.y, cw, P.h);
      }

      // 降水柱
      var bw = Math.min(cw * 0.62, 34), pulse = 0.5 + 0.5 * Math.sin(st.now * 4);
      for (i = 0; i < 12; i++) {
        var v = p[i], over = v > R.pHi, yb = YP(Math.min(v, R.pHi));
        ctx.fillStyle = C.bar;
        if (f === 'rain' && s.summer.indexOf(i) < 0 && cls.type !== 'med') ctx.fillStyle = 'rgba(79,195,247,0.32)';
        if (f === 'rain' && cls.type === 'med' && s.summer.indexOf(i) >= 0) ctx.fillStyle = 'rgba(79,195,247,0.32)';
        ctx.fillRect(X(i) - bw / 2, yb, bw, P.y + P.h - yb);
        ctx.strokeStyle = 'rgba(79,195,247,0.9)'; ctx.lineWidth = 1;
        ctx.strokeRect(X(i) - bw / 2 + 0.5, yb + 0.5, bw - 1, P.y + P.h - yb - 1);
        if (over) {        // 超出刻度：顶端画折断符号
          ctx.strokeStyle = C.panel; ctx.lineWidth = 3;
          ctx.beginPath(); ctx.moveTo(X(i) - bw / 2, yb + 10); ctx.lineTo(X(i) + bw / 2, yb + 4); ctx.stroke();
          label(String(Math.round(v)), X(i), yb - 8, C.rain, 'center', fsz - 1, true);
        } else if (st.opts.values && cw > 24) label(String(Math.round(v)), X(i), yb - 8, C.rain, 'center', fsz - 2);
        if (st.scene === 'edit') {          // 可拖动的柱顶
          ctx.fillStyle = st.drag && st.drag.what === 'p' && st.drag.i === i ? C.accent : 'rgba(79,195,247,0.95)';
          ctx.fillRect(X(i) - bw / 2, yb - 2, bw, 4);
        }
      }

      // 判读参考线
      var refs = [];
      if (f === 'zone') {
        if (cls.zone === '寒带') refs = [10, 0];
        else refs = [15, 0];
      } else if (f === 'rain' && cls.type === 'ocean') refs = [22];
      else if (st.opts.refs) refs = [15, 0];
      refs.forEach(function (rv) {
        if (rv < R.tLo || rv > R.tHi) return;
        var y = YT(rv);
        ctx.strokeStyle = rv === 0 ? 'rgba(129,212,250,0.85)' : rv === 15 ? 'rgba(255,138,101,0.85)' : 'rgba(255,201,74,0.85)';
        ctx.setLineDash([6, 4]); ctx.lineWidth = 1.3;
        ctx.beginPath(); ctx.moveTo(P.x, y); ctx.lineTo(P.x + P.w, y); ctx.stroke();
        ctx.setLineDash([]);
        label(fmtN(rv) + ' °C', P.x + P.w - 6, y - 9, ctx.strokeStyle, 'right', fsz - 1, true);
      });

      // 气温曲线（平滑）
      var pts = t.map(function (v, j) { return [X(j), YT(v)]; });
      ctx.strokeStyle = C.temp; ctx.lineWidth = 2.4; ctx.lineJoin = 'round';
      ctx.beginPath(); ctx.moveTo(pts[0][0], pts[0][1]);
      for (i = 0; i < 11; i++) {
        var p0 = pts[Math.max(0, i - 1)], p1 = pts[i], p2 = pts[i + 1], p3 = pts[Math.min(11, i + 2)];
        ctx.bezierCurveTo(p1[0] + (p2[0] - p0[0]) / 6, p1[1] + (p2[1] - p0[1]) / 6, p2[0] - (p3[0] - p1[0]) / 6, p2[1] - (p3[1] - p1[1]) / 6, p2[0], p2[1]);
      }
      ctx.stroke();
      var edit = st.scene === 'edit';
      pts.forEach(function (q, j) {
        var hot = edit && st.drag && st.drag.what === 't' && st.drag.i === j;
        ctx.fillStyle = hot ? C.accent : C.temp;
        ctx.beginPath(); ctx.arc(q[0], q[1], edit ? 5.5 : 3.2, 0, Math.PI * 2); ctx.fill();
        if (edit) { ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.2; ctx.stroke(); }
        if (st.opts.values && cw > 30) label(K.fmtT(t[j]).replace(' °C', ''), q[0], q[1] - 11, C.temp, 'center', fsz - 2);
      });

      // 最高、最低月与气温年较差
      var showMarks = st.opts.marks || f === 'hemi' || f === 'zone';
      if (showMarks) {
        var hi = pts[s.iMax], lo = pts[s.iMin];
        var ring = function (q, col, strong) {
          ctx.strokeStyle = col; ctx.lineWidth = 2;
          ctx.beginPath(); ctx.arc(q[0], q[1], 7 + (strong ? pulse * 3 : 0), 0, Math.PI * 2); ctx.stroke();
        };
        ring(hi, C.accent, f === 'hemi');
        ring(lo, '#81d4fa', f === 'hemi' || f === 'zone');
        if (st.opts.marks && s.range >= 1) {
          // 年较差：在图左侧画双向箭头
          var ax = P.x + 14, y1 = hi[1], y2 = lo[1];
          ctx.strokeStyle = 'rgba(255,201,74,0.5)'; ctx.setLineDash([3, 3]); ctx.lineWidth = 1;
          ctx.beginPath(); ctx.moveTo(ax - 6, y1); ctx.lineTo(hi[0] - 8, y1); ctx.moveTo(ax - 6, y2); ctx.lineTo(lo[0] - 8, y2); ctx.stroke();
          ctx.setLineDash([]);
          ctx.strokeStyle = C.accent; ctx.lineWidth = 1.4;
          ctx.beginPath(); ctx.moveTo(ax, y1); ctx.lineTo(ax, y2);
          if (y2 - y1 > 12) { ctx.moveTo(ax - 4, y1 + 6); ctx.lineTo(ax, y1); ctx.lineTo(ax + 4, y1 + 6); ctx.moveTo(ax - 4, y2 - 6); ctx.lineTo(ax, y2); ctx.lineTo(ax + 4, y2 - 6); }
          ctx.stroke();
          ctx.save(); ctx.translate(ax + 10, (y1 + y2) / 2); ctx.rotate(-Math.PI / 2);
          label('年较差 ' + s.range.toFixed(1) + ' °C', 0, 0, C.accent, 'center', fsz - 1, true);
          ctx.restore();
        }
        var hy = hi[1] - 20, ly = lo[1] + 20;
        if (hy < P.y + 8) hy = hi[1] + 20;
        pill('最高 ' + K.fmtT(s.tMax), clamp(hi[0], P.x + 50, P.x + P.w - 50), hy, C.accent, fsz - 1);
        if (Math.abs(ly - hy) > 16 || Math.abs(hi[0] - lo[0]) > 110) pill('最低 ' + K.fmtT(s.tMin), clamp(lo[0], P.x + 50, P.x + P.w - 50), Math.min(ly, P.y + P.h - 8), '#81d4fa', fsz - 1);
      }

      // 悬停读数
      if (st.hover != null && !(st.drag)) {
        var j = st.hover, lines = [K.MON[j], '气温 ' + K.fmtT(t[j]), '降水 ' + Math.round(p[j]) + ' mm'];
        font(fsz);
        var bwid = Math.max.apply(null, lines.map(function (q) { return ctx.measureText(q).width; })) + 18, bh = lines.length * (fsz + 6) + 8;
        var bx = X(j) + cw / 2 + bwid + 8 > P.x + P.w ? X(j) - cw / 2 - bwid - 4 : X(j) + cw / 2 + 4, by = P.y + 22;
        ctx.fillStyle = 'rgba(17,23,35,0.94)'; ctx.strokeStyle = C.line; ctx.lineWidth = 1;
        rrect(bx, by, bwid, bh, 6); ctx.fill(); ctx.stroke();
        lines.forEach(function (q, n) { label(q, bx + 9, by + 4 + (n + 0.5) * (fsz + 6), n === 0 ? C.muted : n === 1 ? C.temp : C.rain, 'left', fsz, n > 0); });
      }

      // 结论徽标
      if (!hide && f === 'type') pill(TYPES[cls.type].name, P.x + P.w / 2, P.y + P.h / 2, TYPES[cls.type].color, narrow ? 13 : 15);
    }

    // ---------- 世界地图 ----------
    function MX(lon) { return map.x + (lon + 180) / 360 * map.w; }
    function MY(lat) { return map.y + (LAT_TOP - lat) / (LAT_TOP - LAT_BOT) * map.h; }
    function polys(list) {
      list.forEach(function (poly) {
        ctx.beginPath();
        poly.forEach(function (q, i) { var x = MX(q[0]), y = MY(Math.min(q[1], LAT_TOP + 2)); if (i) ctx.lineTo(x, y); else ctx.moveTo(x, y); });
        ctx.closePath(); ctx.fill(); ctx.stroke();
      });
    }
    function cityLat(c) { return c.mapLat != null ? c.mapLat : c.lat; }

    function drawMap(m, st) {
      map = m;
      var G = window.Continents, quizHide = st.scene === 'quiz' && !st.quiz.answered, fsz = narrow ? 10 : 11;
      ctx.save();
      rrect(m.x, m.y, m.w, m.h, 6); ctx.clip();
      ctx.fillStyle = C.ocean; ctx.fillRect(m.x, m.y, m.w, m.h);
      ctx.lineJoin = 'round'; ctx.lineWidth = 0.8;
      ctx.fillStyle = C.land; ctx.strokeStyle = C.landLine; polys(G.LAND);
      ctx.fillStyle = C.ice; ctx.strokeStyle = '#34404f'; polys(G.ICE); polys([G.LAND[3]]);
      ctx.fillStyle = C.ocean; ctx.strokeStyle = C.ocean; polys(G.WATER);
      // 赤道、回归线、极圈
      [[0, '赤道', 'rgba(230,235,242,0.35)', []], [23.5, '北回归线', 'rgba(255,201,74,0.35)', [4, 4]], [-23.5, '南回归线', 'rgba(255,201,74,0.35)', [4, 4]],
        [66.5, '北极圈', 'rgba(79,195,247,0.35)', [2, 4]], [-66.5, '南极圈', 'rgba(79,195,247,0.35)', [2, 4]]].forEach(function (g) {
        var y = MY(g[0]);
        ctx.strokeStyle = g[2]; ctx.setLineDash(g[3]); ctx.lineWidth = 1;
        ctx.beginPath(); ctx.moveTo(m.x, y); ctx.lineTo(m.x + m.w, y); ctx.stroke();
        if (m.w > 300) label(g[1], m.x + 4, y - 6, g[2].replace('0.35', '0.8'), 'left', fsz - 1);
      });
      ctx.setLineDash([]);
      ctx.restore();
      ctx.strokeStyle = C.line; ctx.lineWidth = 1; rrect(m.x, m.y, m.w, m.h, 6); ctx.stroke();

      // 城市
      var sel = quizHide ? null : st.city, r = narrow ? 3.2 : 4;
      K.CITY_KEYS.forEach(function (k) {
        var c = CITIES[k], x = MX(c.lon), y = MY(cityLat(c));
        ctx.fillStyle = quizHide ? '#6b7789' : TYPES[c.type].color;
        ctx.strokeStyle = '#05070d'; ctx.lineWidth = 1.2;
        ctx.beginPath(); ctx.arc(x, y, k === sel ? r + 2 : r, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
      });
      if (sel) {
        var c = CITIES[sel], x = MX(c.lon), y = MY(cityLat(c)), pr = 8 + 4 * (0.5 + 0.5 * Math.sin(st.now * 3));
        ctx.strokeStyle = C.accent; ctx.lineWidth = 1.6;
        ctx.beginPath(); ctx.arc(x, y, pr, 0, Math.PI * 2); ctx.stroke();
        mapTag(c.name, x, y, C.accent, fsz);
      }
      if (st.mapHover && st.mapHover !== sel) {
        var h = CITIES[st.mapHover];
        mapTag(quizHide ? '?' : h.name, MX(h.lon), MY(cityLat(h)), C.text, fsz);
      }
      if (!narrow) label(quizHide ? '世界上的代表城市（答完后显示位置）' : '点地图上的城市切换 · 颜色表示气候类型', m.x + m.w - 6, m.y + m.h - 9, C.muted, 'right', fsz);
    }
    function mapTag(s, x, y, color, fsz) {
      font(fsz + 1, true);
      var w = ctx.measureText(s).width + 10, h = fsz + 8, bx = clamp(x - w / 2, map.x + 2, map.x + map.w - w - 2), by = y - 14 - h;
      if (by < map.y + 2) by = y + 12;
      ctx.fillStyle = 'rgba(10,14,22,0.9)'; ctx.strokeStyle = color; ctx.lineWidth = 1;
      rrect(bx, by, w, h, 4); ctx.fill(); ctx.stroke();
      label(s, bx + w / 2, by + h / 2 + 0.5, color, 'center', fsz + 1, true);
    }

    function draw(st) {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, W, H);
      var L = layout(st);
      drawChart(L, st);
      if (L.map) drawMap(L.map, st); else map = null;
    }

    // ---------- 命中测试 ----------
    function monthAt(px, py) {
      if (!plot || px < plot.x || px > plot.x + plot.w || py < plot.y - 10 || py > plot.y + plot.h + 20) return null;
      return clamp(Math.floor((px - plot.x) / plot.cw), 0, 11);
    }
    function cityAt(px, py) {
      if (!map || px < map.x - 8 || px > map.x + map.w + 8 || py < map.y - 8 || py > map.y + map.h + 8) return null;
      var best = null, bd = 14;
      K.CITY_KEYS.forEach(function (k) {
        var c = CITIES[k], d = Math.hypot(MX(c.lon) - px, MY(cityLat(c)) - py);
        if (d < bd) { bd = d; best = k; }
      });
      return best;
    }
    // 编辑：按下的位置离气温点近还是离柱顶近
    function handleAt(px, py, st) {
      var i = monthAt(px, py);
      if (i == null) return null;
      var dt = Math.abs(plot.YT(st.data.t[i]) - py), dp = Math.abs(plot.YP(Math.min(st.data.p[i], rng.pHi)) - py);
      return { what: dt <= dp + 6 ? 't' : 'p', i: i };
    }
    function valueAt(what, py) {
      var f = clamp((plot.y + plot.h - py) / plot.h, what === 'p' ? 0 : -0.05, 1.05);
      return what === 't' ? rng.tLo + f * (rng.tHi - rng.tLo) : f * rng.pHi;
    }

    return { resize: resize, draw: draw, monthAt: monthAt, cityAt: cityAt, handleAt: handleAt, valueAt: valueAt,
      range: function () { return rng; } };
  }

  window.ClimDraw = ClimDraw;
  window.ClimDraw.axisRange = axisRange;
})();
