// 2D 绘制：转盘俯视图、圆锥摆/圆锥筒斜视图与受力小图、拱桥/凹形桥侧视图与 N–x 图、竖直面内的圆周运动
// 世界坐标同 Circ（x 右、y 上，单位 m）；frame(R, box) 把世界范围 box 等比放进屏幕矩形 R
// 力的箭头统一按“mg 对应 FS 像素”的比例画，过长的截断并标注数值
(function () {
  var C = window.Circ, DEG = C.DEG, f = C.f;
  var GOLD = '#ffc94a', PINK = '#f78fb3', G = '#7ee081', CONTACT = '#4fc3f7', FN = '#ff7a59', VEL = '#e6ebf2';
  var MUTED = '#8d99ab', TEXT = '#e6ebf2', GRID = 'rgba(141,153,171,.12)', EDGE = '#4a5670';
  var FONT = '-apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", sans-serif';
  var FS = 50, FMAX = 160;  // mg 对应的像素长度、力箭头的最大长度

  function font(px, w) { return (w ? w + ' ' : '') + px + 'px ' + FONT; }
  function label(ctx, s, x, y, o) {
    o = o || {};
    ctx.font = font(o.size || 12, o.bold ? 600 : null);
    ctx.textAlign = o.align || 'center'; ctx.textBaseline = o.base || 'middle';
    ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(5,7,13,.85)'; ctx.strokeText(s, x, y);
    ctx.fillStyle = o.color || TEXT; ctx.fillText(s, x, y);
  }
  function arrow(ctx, x1, y1, x2, y2, color, o) {
    o = o || {};
    var a = Math.atan2(y2 - y1, x2 - x1), len = Math.hypot(x2 - x1, y2 - y1), size = Math.min(o.size || 10, len * 0.6);
    if (len < 1) return;
    ctx.strokeStyle = ctx.fillStyle = color; ctx.lineWidth = o.width || 2.4; ctx.setLineDash(o.dash || []);
    ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2 - Math.cos(a) * size * 0.6, y2 - Math.sin(a) * size * 0.6); ctx.stroke();
    ctx.setLineDash([]);
    ctx.beginPath();
    ctx.moveTo(x2, y2);
    ctx.lineTo(x2 - size * Math.cos(a - 0.42), y2 - size * Math.sin(a - 0.42));
    ctx.lineTo(x2 - size * Math.cos(a + 0.42), y2 - size * Math.sin(a + 0.42));
    ctx.closePath(); ctx.fill();
  }
  function line(ctx, a, b, color, o) {
    o = o || {};
    ctx.strokeStyle = color; ctx.lineWidth = o.width || 1.2; ctx.setLineDash(o.dash || []);
    ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke(); ctx.setLineDash([]);
  }
  function dot(ctx, p, color, r) { ctx.fillStyle = color; ctx.beginPath(); ctx.arc(p.x, p.y, r || 3.5, 0, 7); ctx.fill(); }
  function shade(c) {
    var n = parseInt(c.slice(1), 16);
    return 'rgb(' + ((n >> 16) * 0.45 | 0) + ',' + ((n >> 8 & 255) * 0.45 | 0) + ',' + ((n & 255) * 0.45 | 0) + ')';
  }
  function ball(ctx, p, color, r, alpha) {
    ctx.globalAlpha = alpha == null ? 1 : alpha;
    var g = ctx.createRadialGradient(p.x - r * 0.35, p.y - r * 0.35, r * 0.1, p.x, p.y, r);
    g.addColorStop(0, '#fff'); g.addColorStop(0.35, color); g.addColorStop(1, shade(color));
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(p.x, p.y, r, 0, 7); ctx.fill();
    ctx.globalAlpha = 1;
  }
  // 力箭头：从 p 沿屏幕方向 (ux, uy) 画 n 倍 mg 的长度；超长截断
  function force(ctx, p, ux, uy, n, color, name, o) {
    o = o || {};
    var l = Math.abs(n) * (o.fs || FS), cut = l > FMAX;
    if (cut) l = FMAX;
    if (l < 2) return;
    var s = n < 0 ? -1 : 1, ex = p.x + ux * l * s, ey = p.y + uy * l * s;
    arrow(ctx, p.x, p.y, ex, ey, color, { width: o.width || 2.4, dash: o.dash, size: 10 });
    if (cut) {  // 截断记号
      var mx = p.x + ux * s * (l - 22), my = p.y + uy * s * (l - 22), nx = -uy * 5, ny = ux * 5;
      line(ctx, { x: mx - nx - ux * s * 2, y: my - ny - uy * s * 2 }, { x: mx + nx - ux * s * 2, y: my + ny - uy * s * 2 }, color, { width: 1.6 });
      line(ctx, { x: mx - nx + ux * s * 2, y: my - ny + uy * s * 2 }, { x: mx + nx + ux * s * 2, y: my + ny + uy * s * 2 }, color, { width: 1.6 });
    }
    if (name) {
      var gap = o.gap || 13;
      label(ctx, name, ex + ux * s * gap + (o.dx || 0), ey + uy * s * gap + (o.dy || 0), { color: color, bold: true, size: 13 });
    }
  }
  // 屏幕坐标下的角弧：从屏幕角 a0 到 a1（弧度，顺时针为正，即 canvas 的约定）
  function arcMark(ctx, c, a0, a1, r, color, text, gap) {
    ctx.strokeStyle = color; ctx.lineWidth = 1.4; ctx.setLineDash([]);
    ctx.beginPath(); ctx.arc(c.x, c.y, r, Math.min(a0, a1), Math.max(a0, a1)); ctx.stroke();
    if (!text) return;
    var am = (a0 + a1) / 2, lr = r + (gap || 11);
    label(ctx, text, c.x + Math.cos(am) * lr, c.y + Math.sin(am) * lr, { color: color, size: 12, bold: true });
  }

  function frame(R, box) {
    var k = Math.min(R.w / (box.x1 - box.x0), R.h / (box.y1 - box.y0));
    var cx = R.x + R.w / 2, cy = R.y + R.h / 2, mx = (box.x0 + box.x1) / 2, my = (box.y0 + box.y1) / 2;
    return {
      k: k, R: R,
      p: function (x, y) { return { x: cx + (x - mx) * k, y: cy - (y - my) * k }; },
      w: function (sx, sy) { return { x: mx + (sx - cx) / k, y: my - (sy - cy) / k }; }
    };
  }

  // ---------- 视图 ----------
  function View(canvas) {
    var ctx = canvas.getContext('2d'), W = 0, H = 0, dpr = 1, narrow = false, geo = null;
    function resize(w, h) {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      W = w; H = h; narrow = w < 640;
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
      canvas.style.width = w + 'px'; canvas.style.height = h + 'px';
    }
    function bg() {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      var g = ctx.createLinearGradient(0, 0, 0, H);
      g.addColorStop(0, '#04060c'); g.addColorStop(1, '#0a1120');
      ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    }
    function area() {
      var t0 = narrow ? 84 : 44, bottom = narrow ? 44 : 50;
      return { x: 12, y: t0, w: W - 24, h: Math.max(160, H - t0 - bottom) };
    }
    function corner(R, lines) {
      lines.forEach(function (s, i) { if (s) label(ctx, s, R.x + R.w - 6, R.y + 10 + i * 17, { align: 'right', size: 12, color: i ? MUTED : TEXT }); });
    }
    function panelBox(x, y, w, h, title) {
      ctx.fillStyle = 'rgba(17,23,35,.82)'; ctx.strokeStyle = '#2a3446'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.roundRect ? ctx.roundRect(x, y, w, h, 8) : ctx.rect(x, y, w, h); ctx.fill(); ctx.stroke();
      if (title) label(ctx, title, x + 8, y + 12, { align: 'left', size: 11, color: MUTED });
    }

    // ================= 场景一：转盘 =================
    // o: { phi, w, mu, g, blocks: [{ b, m, color, name, trail }], showV, showF }
    function drawTurntable(o) {
      bg();
      var R = area(), nb = o.blocks.length, barsH = 30 + nb * 30;
      var DR = C.DISK_R, rad = Math.min(R.w * 0.44, (R.h - barsH - 16) * 0.5);
      var c = { x: R.x + R.w / 2, y: R.y + (R.h - barsH - 8) / 2 }, k = rad / DR;
      function P(x, y) { return { x: c.x + x * k, y: c.y - y * k }; }
      // 转盘
      var g1 = ctx.createRadialGradient(c.x, c.y, rad * 0.1, c.x, c.y, rad);
      g1.addColorStop(0, '#24304a'); g1.addColorStop(1, '#1a2336');
      ctx.fillStyle = g1; ctx.beginPath(); ctx.arc(c.x, c.y, rad, 0, 7); ctx.fill();
      ctx.strokeStyle = '#6f86c9'; ctx.lineWidth = 2; ctx.stroke();
      // 随盘转动的辐条和刻痕，看得出盘在转
      ctx.strokeStyle = 'rgba(111,134,201,.28)'; ctx.lineWidth = 1;
      ctx.beginPath();
      for (var i = 0; i < 12; i++) {
        var a = o.phi + i * Math.PI / 6;
        ctx.moveTo(c.x + Math.cos(a) * rad * 0.12, c.y - Math.sin(a) * rad * 0.12);
        ctx.lineTo(c.x + Math.cos(a) * rad * (i % 3 ? 0.96 : 1), c.y - Math.sin(a) * rad * (i % 3 ? 0.96 : 1));
      }
      ctx.stroke();
      [0.2, 0.4].forEach(function (rr) { ctx.strokeStyle = 'rgba(111,134,201,.16)'; ctx.beginPath(); ctx.arc(c.x, c.y, rr * k, 0, 7); ctx.stroke(); });
      var mk = P(DR * 0.9 * Math.cos(o.phi), DR * 0.9 * Math.sin(o.phi));
      dot(ctx, mk, '#6f86c9', 4);
      dot(ctx, c, TEXT, 3.5);
      // ω 弯箭头
      if (o.w > 0.01) {
        ctx.strokeStyle = MUTED; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.arc(c.x, c.y, 22, -0.3, -Math.PI * 1.5, true); ctx.stroke();
        var ea = -Math.PI * 1.5, ex = c.x + Math.cos(ea) * 22, ey = c.y + Math.sin(ea) * 22;
        arrow(ctx, ex + 6, ey, ex, ey, MUTED, { size: 8, width: 1.6 });
        label(ctx, 'ω', c.x + 30, c.y - 16, { color: MUTED, size: 13, bold: true });
      }
      // 物块
      o.blocks.forEach(function (it) {
        var b = it.b, col = it.color;
        // 圆周轨道
        ctx.strokeStyle = col; ctx.globalAlpha = 0.35; ctx.lineWidth = 1.2; ctx.setLineDash([4, 5]);
        ctx.beginPath(); ctx.arc(c.x, c.y, b.stuck ? Math.hypot(b.p.x, b.p.y) * k : (it.r0 || b.r) * k, 0, 7); ctx.stroke();
        ctx.setLineDash([]); ctx.globalAlpha = 1;
        // 滑动后的轨迹（地面参考系）
        if (it.trail && it.trail.length > 1) {
          ctx.strokeStyle = col; ctx.lineWidth = 2; ctx.beginPath();
          it.trail.forEach(function (q, j) { var s = P(q.x, q.y); if (j) ctx.lineTo(s.x, s.y); else ctx.moveTo(s.x, s.y); });
          ctx.stroke();
          if (b.slipAt) {
            var sa = P(b.slipAt.x, b.slipAt.y);
            dot(ctx, sa, col, 3);
            // 开始滑动处的切线（虚线）：若完全没有摩擦，物块将沿切线飞出
            var t = { x: -b.slipAt.y, y: b.slipAt.x }, tl = Math.hypot(t.x, t.y);
            line(ctx, sa, { x: sa.x + t.x / tl * rad * 0.9, y: sa.y - t.y / tl * rad * 0.9 }, 'rgba(230,235,242,.4)', { dash: [4, 4] });
          }
        }
        var sp = P(b.p.x, b.p.y), ang = b.stuck ? Math.atan2(b.p.y, b.p.x) : (it.fixAng || 0), half = Math.max(8, 0.035 * k);
        ctx.save(); ctx.translate(sp.x, sp.y); ctx.rotate(-ang);
        ctx.fillStyle = col; ctx.strokeStyle = shade(col); ctx.lineWidth = 1.5;
        ctx.fillRect(-half, -half, half * 2, half * 2); ctx.strokeRect(-half, -half, half * 2, half * 2);
        ctx.restore();
        label(ctx, it.name, sp.x, sp.y, { size: 11, bold: true, color: '#1a1300' });
        // 速度（切向）与摩擦力
        var v = Math.hypot(b.v.x, b.v.y);
        if (o.showV && v > 0.01) {
          var kv = Math.min(28 * k / 100 * 4, 60 / Math.max(v, 0.5));
          arrow(ctx, sp.x, sp.y, sp.x + b.v.x * kv * 1.6, sp.y - b.v.y * kv * 1.6, VEL, { width: 2.2, size: 9 });
          label(ctx, 'v', sp.x + b.v.x * kv * 1.6 + b.v.x / v * 12, sp.y - b.v.y * kv * 1.6 - b.v.y / v * 12, { color: VEL, bold: true, size: 13 });
        }
        if (o.showF && !b.off) {
          var rr = Math.hypot(b.p.x, b.p.y), ux, uy, n;
          if (b.stuck) { ux = -b.p.x / rr; uy = b.p.y / rr; n = o.w * o.w * rr / (o.mu * o.g); }
          else {
            var wx = b.v.x + o.w * b.p.y, wy = b.v.y - o.w * b.p.x, wl = Math.hypot(wx, wy);
            if (wl < 1e-6) return;
            ux = -wx / wl; uy = wy / wl; n = 1;
          }
          force(ctx, sp, ux, uy, n, CONTACT, b.stuck ? 'f静' : 'f滑', { gap: 14, fs: 70 });
        }
      });
      // 需要的向心力与最大静摩擦力对比条
      var bx = R.x + 4, by = R.y + R.h - barsH, bw = Math.min(R.w - 8, 520);
      panelBox(bx, by, bw, barsH, '所需向心力 mω²r 与最大静摩擦力 μmg（同一比例）');
      o.blocks.forEach(function (it, j) {
        var y = by + 24 + j * 30, x0 = bx + 34, L = bw - 120, b = it.b;
        var need = it.m * o.w * o.w * (b.stuck ? Math.hypot(b.p.x, b.p.y) : it.r0), fmax = o.mu * it.m * o.g;
        var scale = L / Math.max(fmax * 2, 1e-9), ln = Math.min(L, need * scale), lf = fmax * scale;
        label(ctx, it.name, bx + 16, y + 6, { color: it.color, bold: true, size: 12 });
        ctx.fillStyle = 'rgba(255,255,255,.06)'; ctx.fillRect(x0, y, L, 12);
        ctx.fillStyle = need > fmax * (1 + 1e-9) ? FN : it.color; ctx.globalAlpha = 0.85; ctx.fillRect(x0, y, ln, 12); ctx.globalAlpha = 1;
        line(ctx, { x: x0 + lf, y: y - 4 }, { x: x0 + lf, y: y + 16 }, CONTACT, { width: 2 });
        label(ctx, f(need, 2) + ' N', x0 + L + 8, y + 6, { align: 'left', size: 11, color: need > fmax * (1 + 1e-9) ? FN : TEXT });
        if (j === nb - 1) label(ctx, 'μmg', x0 + lf, y + 22, { size: 10, color: CONTACT });
      });
      corner(R, ['俯视图 · 转盘逆时针转动', o.gName]);
      geo = { scene: 'turntable', c: c, k: k, rad: rad };
      return geo;
    }

    // ================= 场景二：圆锥摆、圆锥筒 =================
    var SQ = 0.3;  // 斜视：水平圆压扁成椭圆的比例
    // o: { mode: 'pendulum'|'funnel', items: [{ q（pendulum/funnel 的结果）, phi, color, name, trail }], g, showF, showV, rim（圆锥筒的高度） }
    function drawConical(o) {
      bg();
      var R = area(), pend = o.mode === 'pendulum', it0 = o.items[0], q0 = it0.q;
      var maxL = 0, maxR = 0;
      o.items.forEach(function (it) { maxL = Math.max(maxL, pend ? it.q.h : o.rim); maxR = Math.max(maxR, pend ? it.q.r : o.rim * Math.tan(q0.al)); });
      // 悬点（圆锥摆）或锥顶（圆锥筒）；左上（左下）留给受力小图
      var axisX = R.x + R.w * (narrow || o.items.length > 1 ? 0.5 : 0.56), half = Math.min(axisX - R.x, R.x + R.w - axisX) - 24;
      var Hv = pend ? Math.max(maxL, 0.25) : o.rim, k = Math.min((R.h - 70) / (Hv * 1.12 + maxR * SQ * 2), half / Math.max(maxR, 0.1));
      var O = pend ? { x: axisX, y: R.y + Math.max(30, (R.h - (Hv * 1.08 + maxR * SQ) * k) / 2) } : { x: axisX, y: R.y + R.h - 26 };
      function P3(x, z, y) { return { x: O.x + x * k, y: O.y - y * k - z * k * SQ }; }  // x 右、z 向纸内、y 上（相对 O）
      function ellipse(cy, r, color, o2) {
        o2 = o2 || {};
        var c = P3(0, 0, cy);
        ctx.strokeStyle = color; ctx.lineWidth = o2.width || 1.2;
        // 后半圈虚、前半圈实
        ctx.setLineDash([4, 5]); ctx.beginPath(); ctx.ellipse(c.x, c.y, r * k, r * k * SQ, 0, Math.PI, Math.PI * 2); ctx.stroke();
        ctx.setLineDash([]); ctx.beginPath(); ctx.ellipse(c.x, c.y, r * k, r * k * SQ, 0, 0, Math.PI); ctx.stroke();
      }
      // 竖直轴
      var axTop = pend ? O : P3(0, 0, o.rim + 0.05), axBot = pend ? P3(0, 0, -Hv * 1.08) : P3(0, 0, -0.02);
      line(ctx, axTop, axBot, 'rgba(141,153,171,.5)', { dash: [6, 5] });
      if (pend) {
        ctx.fillStyle = '#4a5670'; ctx.fillRect(O.x - 40, O.y - 10, 80, 8);
        dot(ctx, O, TEXT, 3);
      } else {
        // 圆锥筒：轮廓与筒口
        var rr = o.rim * Math.tan(q0.al), L1 = P3(-rr, 0, o.rim), R1 = P3(rr, 0, o.rim);
        ctx.fillStyle = 'rgba(111,134,201,.10)';
        ctx.beginPath(); ctx.moveTo(O.x, O.y); ctx.lineTo(L1.x, L1.y); ctx.ellipse(O.x, L1.y, rr * k, rr * k * SQ, 0, Math.PI, 0, true); ctx.lineTo(O.x, O.y); ctx.fill();
        line(ctx, O, L1, '#6f86c9', { width: 2 }); line(ctx, O, R1, '#6f86c9', { width: 2 });
        ellipse(o.rim, rr, '#6f86c9', { width: 2 });
      }
      var draws = [];
      o.items.forEach(function (it) {
        var q = it.q, yy = pend ? -q.h : q.h;
        ellipse(yy, q.r, it.color);
        var c = P3(0, 0, yy);
        dot(ctx, c, it.color, 2.5);
        if (pend) label(ctx, 'h', O.x - 10, (O.y + c.y) / 2, { color: MUTED, size: 12 });
        var x = q.r * Math.cos(it.phi), z = q.r * Math.sin(it.phi), bp = P3(x, z, yy);
        draws.push({ it: it, q: q, x: x, z: z, yy: yy, bp: bp, c: c });
      });
      // 由远到近画，前面的球盖住后面的
      draws.sort(function (a, b) { return b.z - a.z; });
      draws.forEach(function (d) {
        var it = d.it, q = d.q, bp = d.bp, c = d.c;
        // 半径线
        line(ctx, c, bp, 'rgba(230,235,242,.35)', { dash: [3, 4] });
        if (pend) line(ctx, O, bp, '#cfd6e2', { width: 1.6 });
        var r = 9 * (1 - d.z / Math.max(q.r, 1e-6) * 0.12);
        ball(ctx, bp, it.color, r);
        // 受力（投影后的方向）：G 竖直向下，拉力沿线指向悬点 / 支持力垂直筒壁，合力水平指向圆心
        if (o.showF) {
          var inX = -Math.cos(it.phi), inZ = -Math.sin(it.phi);
          var hin = { x: inX * k, y: -inZ * k * SQ }, hl = Math.hypot(hin.x, hin.y) || 1;
          var fnLen = q.fn / o.g;  // 以 mg 为单位
          force(ctx, bp, 0, 1, 1, G, 'G');
          if (pend) {
            // 沿线指向悬点的单位矢量投影到屏幕上（不归一化，长度随透视缩短），使 G + T = F合 在屏幕上也成立
            force(ctx, bp, (O.x - bp.x) / (q.L * k), (O.y - bp.y) / (q.L * k), q.tension / o.g, CONTACT, 'T');
          } else {
            // N = mg/sinα 的方向：水平分量 cosα 指向轴，竖直分量 sinα 向上（投影后水平部分要按透视缩短）
            var nx = hin.x / k * Math.cos(q.al), ny = hin.y / k * Math.cos(q.al) - Math.sin(q.al), nl = Math.hypot(nx, ny);
            force(ctx, bp, nx / nl, ny / nl, q.normal / o.g * nl, CONTACT, 'N');
          }
          force(ctx, bp, hin.x / k, hin.y / k, fnLen, FN, 'F合', { dash: [6, 4] });
        }
        if (o.showV) {
          var tv = { x: -Math.sin(it.phi) * k, y: -Math.cos(it.phi) * k * SQ }, kv = 16;
          arrow(ctx, bp.x, bp.y, bp.x + tv.x / k * q.v * kv, bp.y + tv.y / k * q.v * kv, VEL, { width: 2, size: 9 });
        }
        if (it.name) label(ctx, it.name, bp.x + 14, bp.y - 14, { color: it.color, bold: true, size: 12 });
      });
      // 受力小图：过小球与竖直轴的截面，平面受力分析
      var iw = narrow ? 140 : 200, ih = narrow ? 140 : 190, ix = R.x + 4, iy = pend ? R.y + (narrow ? 4 : 30) : R.y + R.h - ih - 4;
      if (!pend && narrow) iy = R.y + 4;
      panelBox(ix, iy, iw, ih, '受力分析（竖直截面）');
      var s = narrow ? 0.75 : 1;
      if (pend) {
        var th = q0.th, Pv = { x: ix + iw * 0.56, y: iy + 28 }, Ls = 80 * s;
        var Bp = { x: Pv.x - Math.sin(th) * Ls, y: Pv.y + Math.cos(th) * Ls };
        line(ctx, Pv, { x: Pv.x, y: Pv.y + Ls * 1.15 }, 'rgba(141,153,171,.5)', { dash: [4, 4] });
        line(ctx, Pv, Bp, '#cfd6e2', { width: 1.4 });
        arcMark(ctx, Pv, Math.PI / 2, Math.PI / 2 + th, 24 * s, TEXT, 'θ', 9);
        var a = Math.min(46 * s, 90 * s * Math.cos(th));
        miniForces(Bp, a, 1, 1 / Math.cos(th), { x: Math.sin(th), y: -Math.cos(th) }, 'T', Math.tan(th));
      } else {
        var al = q0.al, Ap = { x: ix + iw * 0.66, y: iy + ih - 12 }, Lw = 150 * s;
        var top = { x: Ap.x - Math.sin(al) * Lw, y: Ap.y - Math.cos(al) * Lw };
        line(ctx, Ap, top, '#6f86c9', { width: 2 });
        line(ctx, Ap, { x: Ap.x, y: Ap.y - Lw * 0.95 }, 'rgba(141,153,171,.5)', { dash: [4, 4] });
        arcMark(ctx, Ap, -Math.PI / 2 - al, -Math.PI / 2, 22 * s, TEXT, 'α', 9);
        var Bq = { x: Ap.x - Math.sin(al) * Lw * 0.62, y: Ap.y - Math.cos(al) * Lw * 0.62 };
        var a2 = Math.min(40 * s, 80 * s * Math.sin(al));
        miniForces(Bq, a2, 1, 1 / Math.sin(al), { x: Math.cos(al), y: -Math.sin(al) }, 'N', 1 / Math.tan(al));
      }
      // 平面受力：G 向下，接触力 u 方向，合力水平向右（截面里圆心在小球右侧）
      function miniForces(p, a, gN, cN, u, cName, fN) {
        ball(ctx, p, GOLD, 6 * s);
        arrow(ctx, p.x, p.y, p.x, p.y + a * gN, G, { width: 2, size: 8 });
        label(ctx, 'G', p.x - 10, p.y + a * gN, { color: G, bold: true, size: 12 });
        var cx2 = p.x + u.x * a * cN, cy2 = p.y + u.y * a * cN;
        arrow(ctx, p.x, p.y, cx2, cy2, CONTACT, { width: 2, size: 8 });
        label(ctx, cName, cx2 + 10, cy2 - 2, { color: CONTACT, bold: true, size: 12 });
        line(ctx, { x: cx2, y: cy2 }, { x: p.x + a * fN, y: p.y }, 'rgba(230,235,242,.35)', { dash: [3, 3] });
        line(ctx, { x: p.x, y: p.y + a * gN }, { x: p.x + a * fN, y: p.y }, 'rgba(230,235,242,.35)', { dash: [3, 3] });
        arrow(ctx, p.x, p.y, p.x + a * fN, p.y, FN, { width: 2, size: 8, dash: [5, 3] });
        label(ctx, 'F合', p.x + a * fN + 4, p.y + 11, { color: FN, bold: true, size: 11 });
      }
      corner(R, [pend ? '斜视图 · 圆锥摆' : '斜视图 · 光滑圆锥筒内壁', o.gName]);
      geo = { scene: 'conical' };
      return geo;
    }

    // ================= 场景三：拱桥、凹形桥 =================
    // o: { rd, car, v, g, m, prof（bridgeProfile 结果）, trail, showF, gName }
    function drawBridge(o) {
      bg();
      var R = area(), rd = o.rd, span = rd.x1 - rd.x0, gh = Math.min(170, R.h * 0.34);
      var Rr = { x: R.x, y: R.y, w: R.w, h: R.h - gh - 14 };
      var ys = [0, rd.top], yLo = Math.min.apply(null, ys), yHi = Math.max.apply(null, ys);
      var fr = frame(Rr, { x0: rd.x0 - span * 0.32, x1: rd.x1 + span * 0.32, y0: yLo - span * 0.08, y1: yHi + span * (rd.convex ? 0.2 : 0.1) });
      var Lc = Math.max(4.5, span * 0.09, 46 / fr.k), Hc = Lc * 0.32;  // 车长、车高（世界单位，必要时放大画）
      // 地面与桥体
      var xL = fr.w(0, 0).x, xR = fr.w(W, 0).x, gy = fr.p(0, 0).y;
      ctx.fillStyle = 'rgba(43,51,70,.6)';
      ctx.beginPath(); ctx.moveTo(fr.p(xL, 0).x, gy);
      var n = 160, i;
      for (i = 0; i <= n; i++) { var x = rd.x0 + (rd.x1 - rd.x0) * i / n, pp = fr.p(x, rd.at(x).y); ctx.lineTo(pp.x, pp.y); }
      ctx.lineTo(fr.p(xR, 0).x, gy); ctx.lineTo(W, H); ctx.lineTo(0, H); ctx.closePath(); ctx.fill();
      if (rd.convex) {
        // 拱桥下的河和桥洞
        var a0 = fr.p(rd.x0 + rd.ramp * 0.6, 0), a1 = fr.p(rd.x1 - rd.ramp * 0.6, 0), top = fr.p(0, rd.top * 0.55);
        ctx.fillStyle = '#0b1324';
        ctx.beginPath(); ctx.moveTo(a0.x, gy); ctx.quadraticCurveTo((a0.x + a1.x) / 2, 2 * top.y - gy, a1.x, gy); ctx.closePath(); ctx.fill();
        ctx.fillStyle = 'rgba(79,195,247,.18)'; ctx.fillRect(a0.x - 30, gy, a1.x - a0.x + 60, 10);
      }
      ctx.strokeStyle = '#8a97b3'; ctx.lineWidth = 2.5; ctx.beginPath();
      ctx.moveTo(fr.p(xL, 0).x, gy);
      for (i = 0; i <= n; i++) { var x2 = rd.x0 + (rd.x1 - rd.x0) * i / n, p2 = fr.p(x2, rd.at(x2).y); ctx.lineTo(p2.x, p2.y); }
      ctx.lineTo(fr.p(xR, 0).x, gy); ctx.stroke();
      // 圆弧的圆心和半径
      var cc = fr.p(0, rd.cy), tp = fr.p(0, rd.top);
      if (cc.y > Rr.y - 20 && cc.y < Rr.y + Rr.h + 20) dot(ctx, cc, MUTED, 3);
      line(ctx, tp, { x: tp.x, y: Math.max(Rr.y, Math.min(Rr.y + Rr.h, cc.y)) }, 'rgba(141,153,171,.45)', { dash: [4, 5] });
      label(ctx, 'R = ' + f(rd.R) + ' m', tp.x + 8, (tp.y + Math.max(Rr.y, Math.min(Rr.y + Rr.h, cc.y))) / 2 + (rd.convex ? 0 : -10), { align: 'left', size: 12, color: MUTED });
      // 飞离后的轨迹
      if (o.trail && o.trail.length > 1) {
        ctx.strokeStyle = GOLD; ctx.lineWidth = 1.8; ctx.setLineDash([5, 4]); ctx.beginPath();
        o.trail.forEach(function (q, j) { var s = fr.p(q.x, q.y + Hc * 0.6); if (j) ctx.lineTo(s.x, s.y); else ctx.moveTo(s.x, s.y); });
        ctx.stroke(); ctx.setLineDash([]);
      }
      // 汽车
      var c = o.car, seg = rd.at(c.x), ang = c.air ? Math.atan2(c.vy, c.vx) * 0.5 + seg.th * 0.5 : seg.th;
      var cp = fr.p(c.x, c.y), kk = fr.k;
      ctx.save(); ctx.translate(cp.x, cp.y); ctx.rotate(-ang);
      var L = Lc * kk, Hh = Hc * kk, wr = Math.max(3, Hh * 0.28);
      ctx.fillStyle = GOLD;
      ctx.beginPath();
      ctx.moveTo(-L / 2, -wr); ctx.lineTo(-L / 2, -Hh * 0.62); ctx.lineTo(-L * 0.25, -Hh * 0.68); ctx.lineTo(-L * 0.12, -Hh * 1.12);
      ctx.lineTo(L * 0.22, -Hh * 1.12); ctx.lineTo(L * 0.34, -Hh * 0.66); ctx.lineTo(L / 2, -Hh * 0.56); ctx.lineTo(L / 2, -wr); ctx.closePath(); ctx.fill();
      ctx.fillStyle = 'rgba(11,18,34,.75)'; ctx.fillRect(-L * 0.08, -Hh * 1.02, L * 0.26, Hh * 0.3);
      [-L * 0.3, L * 0.3].forEach(function (wx) { ctx.fillStyle = '#1b2233'; ctx.beginPath(); ctx.arc(wx, -wr, wr, 0, 7); ctx.fill(); ctx.strokeStyle = '#8a97b3'; ctx.lineWidth = 1.2; ctx.stroke(); });
      ctx.restore();
      // 受力：重心画在车身中部
      var up = { x: -Math.sin(ang), y: -Math.cos(ang) }, cg = { x: cp.x + up.x * Hh * 0.55, y: cp.y + up.y * Hh * 0.55 };
      if (o.showF) {
        force(ctx, cg, 0, 1, 1, G, 'G', { dx: 12 });
        var nN = c.air ? 0 : C.roadNormal(seg, o.v, o.g) / o.g;
        if (nN > 0.005) force(ctx, cg, up.x, up.y, nN, CONTACT, 'N', { dx: -12 });
        if (!c.air && seg.part === 'arc') {
          // 合力（向心力）：沿半径指向圆心
          var rx = -Math.sin(seg.th), ry = Math.cos(seg.th), sg = rd.convex ? -1 : 1;
          force(ctx, { x: cg.x + 26, y: cg.y }, rx * sg, -ry * sg, o.v * o.v / rd.R / o.g, FN, 'F合', { dash: [6, 4] });
        }
      }
      if (c.leftAt) { var la = fr.p(c.leftAt.x, c.leftAt.y); dot(ctx, la, FN, 4); label(ctx, '飞离桥面', la.x, la.y - 16, { color: FN, size: 12, bold: true }); }
      // N–x 图（与上面的桥共用横坐标）
      var gy0 = R.y + R.h - gh, gx0 = Math.max(R.x + 34, fr.p(rd.x0 - span * 0.3, 0).x), gx1 = Math.min(R.x + R.w - 8, fr.p(rd.x1 + span * 0.3, 0).x);
      panelBox(R.x + 2, gy0 - 6, R.w - 4, gh + 6, '');
      var maxN = 2.2;
      o.prof.forEach(function (q) { if (q.n > maxN) maxN = Math.ceil(q.n * 2) / 2 + 0.2; });
      var gyP = function (nv) { return gy0 + gh - 18 - nv / maxN * (gh - 34); };
      ctx.save(); ctx.beginPath(); ctx.rect(gx0, gy0, gx1 - gx0, gh); ctx.clip();
      line(ctx, { x: gx0, y: gyP(1) }, { x: gx1, y: gyP(1) }, 'rgba(126,224,129,.6)', { dash: [5, 4] });
      line(ctx, { x: gx0, y: gyP(0) }, { x: gx1, y: gyP(0) }, 'rgba(141,153,171,.6)');
      ctx.strokeStyle = CONTACT; ctx.lineWidth = 2; ctx.beginPath();
      o.prof.forEach(function (q, j) { var sx = fr.p(q.x, 0).x, sy = gyP(q.n); if (j) ctx.lineTo(sx, sy); else ctx.moveTo(sx, sy); });
      ctx.stroke();
      ctx.restore();
      label(ctx, 'mg', gx0 - 4, gyP(1), { align: 'right', size: 11, color: G });
      label(ctx, '0', gx0 - 4, gyP(0), { align: 'right', size: 11, color: MUTED });
      label(ctx, '支持力 N（= 车对桥的压力）随位置变化', gx0 + 6, gy0 + 8, { align: 'left', size: 11, color: MUTED });
      var cnow = c.air ? 0 : C.roadNormal(seg, o.v, o.g) / o.g;
      dot(ctx, { x: cp.x, y: gyP(Math.min(cnow, maxN)) }, GOLD, 4.5);
      line(ctx, { x: cp.x, y: gy0 }, { x: cp.x, y: gy0 + gh - 18 }, 'rgba(255,201,74,.25)');
      corner(R, [rd.convex ? '侧视图 · 拱桥' : '侧视图 · 凹形桥', o.gName, Lc > 4.6 ? '汽车按比例放大画' : '']);
      geo = { scene: 'bridge', fr: fr };
      return geo;
    }

    // ================= 场景四：竖直面内的圆周运动 =================
    // o: { R, rope, b（vball）, trail, g, showF, showV, gName, marks: { slack, top } }
    function drawVertical(o) {
      bg();
      var R = area(), Rm = o.R, rad = Math.min(R.w * 0.36, R.h * 0.4), k = rad / Rm;
      var c = { x: R.x + R.w * (narrow ? 0.5 : 0.5), y: R.y + R.h * 0.5 };
      function P(p) { return { x: c.x + p.x * k, y: c.y - p.y * k }; }
      // 轨道圆
      ctx.strokeStyle = 'rgba(141,153,171,.35)'; ctx.lineWidth = 1.2; ctx.setLineDash([4, 5]);
      ctx.beginPath(); ctx.arc(c.x, c.y, rad, 0, 7); ctx.stroke(); ctx.setLineDash([]);
      line(ctx, { x: c.x - rad - 14, y: c.y }, { x: c.x + rad + 14, y: c.y }, 'rgba(141,153,171,.18)');
      line(ctx, { x: c.x, y: c.y - rad - 14 }, { x: c.x, y: c.y + rad + 14 }, 'rgba(141,153,171,.18)');
      label(ctx, '最高点', c.x, c.y - rad - 24, { size: 11, color: MUTED });
      label(ctx, '最低点', c.x, c.y + rad + 22, { size: 11, color: MUTED });
      // 轨迹
      if (o.trail.length > 1) {
        ctx.strokeStyle = GOLD; ctx.lineWidth = 2; ctx.globalAlpha = 0.6; ctx.beginPath();
        o.trail.forEach(function (q, j) { var s = P(q); if (j) ctx.lineTo(s.x, s.y); else ctx.moveTo(s.x, s.y); });
        ctx.stroke(); ctx.globalAlpha = 1;
      }
      var b = o.b, bp = P(b.p);
      if (b.slackAt) { var sa = P(b.slackAt); dot(ctx, sa, FN, 4); label(ctx, '绳松弛', sa.x + (b.slackAt.x >= 0 ? 34 : -34), sa.y, { color: FN, size: 12, bold: true }); }
      if (b.tautAt) { var ta = P(b.tautAt); dot(ctx, ta, CONTACT, 4); label(ctx, '绳再次绷紧', ta.x + (b.tautAt.x >= 0 ? 44 : -44), ta.y + 4, { color: CONTACT, size: 12, bold: true }); }
      // 绳或杆
      if (o.rope) {
        var d = Math.hypot(b.p.x, b.p.y);
        ctx.strokeStyle = '#cfd6e2'; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.moveTo(c.x, c.y);
        if (b.free && d < Rm * 0.999) {
          var sag = Math.sqrt(Math.max(0, Rm * Rm - d * d)) * k * 0.55, mx = (c.x + bp.x) / 2, my = (c.y + bp.y) / 2;
          ctx.quadraticCurveTo(mx, my + sag, bp.x, bp.y);
        } else ctx.lineTo(bp.x, bp.y);
        ctx.stroke();
      } else {
        ctx.strokeStyle = '#8a97b3'; ctx.lineWidth = 6; ctx.lineCap = 'round';
        ctx.beginPath(); ctx.moveTo(c.x, c.y); ctx.lineTo(bp.x, bp.y); ctx.stroke(); ctx.lineCap = 'butt';
      }
      ctx.fillStyle = '#4a5670'; ctx.beginPath(); ctx.arc(c.x, c.y, 6, 0, 7); ctx.fill();
      dot(ctx, c, TEXT, 2.5);
      // 受力
      var v = Math.hypot(b.v.x, b.v.y);
      if (o.showF) {
        force(ctx, bp, 0, 1, 1, G, 'G', { dx: 10 });
        if (!b.free) {
          var F = C.pull(b.om * Rm, b.th, Rm, o.g) / o.g, ux = (c.x - bp.x) / rad, uy = (c.y - bp.y) / rad;
          var off = { x: bp.x - uy * 9, y: bp.y + ux * 9 };
          if (Math.abs(F) > 0.005) force(ctx, off, ux, uy, F, CONTACT, o.rope ? 'T' : (F > 0 ? 'F拉' : 'F支'), { dx: -uy * 10, dy: ux * 10 });
        }
      }
      if (o.showV && v > 0.01) {
        var kv = Math.min(14, 90 / Math.max(v, 1));
        arrow(ctx, bp.x, bp.y, bp.x + b.v.x * kv, bp.y - b.v.y * kv, VEL, { width: 2.2, size: 9 });
        label(ctx, 'v', bp.x + b.v.x * kv + b.v.x / v * 12, bp.y - b.v.y * kv - b.v.y / v * 12, { color: VEL, bold: true, size: 13 });
      }
      ball(ctx, bp, GOLD, 10);
      corner(R, [o.rope ? '轻绳拴小球（内轨道同理）' : '轻杆连小球（圆管同理）', o.gName, 'R = ' + f(Rm) + ' m']);
      geo = { scene: 'vertical', c: c, k: k };
      return geo;
    }

    return { resize: resize, drawTurntable: drawTurntable, drawConical: drawConical, drawBridge: drawBridge, drawVertical: drawVertical,
      geo: function () { return geo; }, narrow: function () { return narrow; } };
  }

  window.CircDraw = { View: View, COLORS: { GOLD: GOLD, PINK: PINK, G: G, CONTACT: CONTACT, FN: FN, VEL: VEL } };
})();
