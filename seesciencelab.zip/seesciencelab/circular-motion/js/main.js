(function () {
  var C = window.Circ, D = window.CircDraw, DEG = C.DEG, f = C.f, COL = D.COLORS;
  var $ = function (id) { return document.getElementById(id); };
  var qa = function (sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); };
  var NAME = '圆周运动';
  var RIM = 1.2;  // 圆锥筒的高度

  var state = {
    scene: 'turntable', grav: '9.8', slow: 1, paused: false, showF: true, showV: true,
    tt: { w: 3, r: 0.2, mu: 0.4, m: 0.5, two: false, ramp: false, phi: 0, items: [] },
    cp: { mode: 'pendulum', L: 1, th: 40, same: false, al: 30, h: 0.4, two: false, phis: [0, 0] },
    br: { mode: 'convex', v: 15, R: 40, m: 1.2, car: null, rd: null, prof: null, profKey: '', trail: [], wait: 0 },
    vt: { mode: 'rope', v0: 7, R: 0.8, m: 0.5, b: null, trail: [] }
  };

  var HINTS = {
    turntable: '拖动物块改变半径 · 增大 ω 看物块何时滑出',
    conical: '上下拖动画面改变摆角（高度）',
    bridge: '拖动汽车沿桥面移动 · 加大车速看桥顶的压力',
    vertical: '点画面让小球从最低点重新出发'
  };

  var stage = $('stage'), panel = $('panel'), cv = $('view');
  var view = D.View(cv);
  function g() { return C.GRAV[state.grav]; }
  function gName() { return 'g = ' + state.grav + ' m/s²'; }
  function setSeg(attr, val) { qa('[data-' + attr + ']').forEach(function (b) { b.classList.toggle('on', b.dataset[attr] === String(val)); }); }

  // ---------- 各场景的重置 ----------
  function resetTT() {
    var t = state.tt;
    t.items = [{ b: C.block(t.r, 0), r0: t.r, name: 'A', color: COL.GOLD, trail: [], wait: 0 }];
    if (t.two) t.items.push({ b: C.block(Math.min(2 * t.r, 0.48), Math.PI), r0: Math.min(2 * t.r, 0.48), name: 'B', color: COL.PINK, trail: [], wait: 0 });
  }
  function resetBR() {
    var b = state.br;
    b.rd = C.road(b.R, b.mode === 'convex');
    var span = b.rd.x1 - b.rd.x0;
    b.car = C.car(b.rd.x0 - span * 0.28, b.rd);
    b.trail = []; b.wait = 0;
  }
  function resetVT() { var v = state.vt; v.b = C.vball(v.v0, v.R); v.trail = []; }
  function restart() {
    if (state.scene === 'turntable') { state.tt.ramp = false; resetTT(); }
    else if (state.scene === 'conical') state.cp.phis = [0, 0];
    else if (state.scene === 'bridge') resetBR();
    else resetVT();
  }

  // ---------- 场景 ----------
  qa('[data-scene]').forEach(function (b) {
    b.addEventListener('click', function () { setScene(b.dataset.scene); Analytics.track(NAME, '场景', b.textContent); });
  });
  function setScene(sc) {
    state.scene = sc;
    restart();
    syncUI();
  }

  // ---------- 控件 ----------
  qa('[data-grav]').forEach(function (b) {
    b.addEventListener('click', function () { state.grav = b.dataset.grav; restart(); syncUI(); Analytics.track(NAME, '重力加速度', b.textContent); });
  });
  qa('[data-slow]').forEach(function (b) {
    b.addEventListener('click', function () { state.slow = parseFloat(b.dataset.slow); syncUI(); Analytics.track(NAME, '播放速度', b.textContent); });
  });
  qa('[data-cmode]').forEach(function (b) {
    b.addEventListener('click', function () { state.cp.mode = b.dataset.cmode; restart(); syncUI(); Analytics.track(NAME, '圆锥摆', b.textContent); });
  });
  qa('[data-bmode]').forEach(function (b) {
    b.addEventListener('click', function () { state.br.mode = b.dataset.bmode; resetBR(); syncUI(); Analytics.track(NAME, '桥面', b.textContent); });
  });
  qa('[data-vmode]').forEach(function (b) {
    b.addEventListener('click', function () { state.vt.mode = b.dataset.vmode; resetVT(); syncUI(); Analytics.track(NAME, '竖直圆周', b.textContent); });
  });
  function bindSlider(id, get, set, after) {
    var el = $(id);
    el.addEventListener('input', function () { set(parseFloat(el.value)); if (after) after(); });
    el.addEventListener('change', function () { Analytics.track(NAME, '滑块', id); });
    return { el: el, get: get };
  }
  var tt = state.tt, cp = state.cp, br = state.br, vt = state.vt;
  var sliders = [
    bindSlider('ttW', function () { return tt.w; }, function (x) { tt.w = x; tt.ramp = false; }),
    bindSlider('ttR', function () { return tt.r; }, function (x) { tt.r = x; }, resetTT),
    bindSlider('ttMu', function () { return tt.mu; }, function (x) { tt.mu = x; }, resetTT),
    bindSlider('ttM', function () { return tt.m; }, function (x) { tt.m = x; }),
    bindSlider('cpL', function () { return cp.L; }, function (x) { cp.L = x; }),
    bindSlider('cpTh', function () { return cp.th; }, function (x) { cp.th = x; }),
    bindSlider('cpAl', function () { return cp.al; }, function (x) { cp.al = x; }),
    bindSlider('cpH', function () { return cp.h; }, function (x) { cp.h = x; }),
    bindSlider('brV', function () { return br.v; }, function (x) { br.v = x; }),
    bindSlider('brR', function () { return br.R; }, function (x) { br.R = x; }, resetBR),
    bindSlider('brM', function () { return br.m; }, function (x) { br.m = x; }),
    bindSlider('vtV', function () { return vt.v0; }, function (x) { vt.v0 = x; }, resetVT),
    bindSlider('vtR', function () { return vt.R; }, function (x) { vt.R = x; }, function () { resetVT(); buildPresets(); }),
    bindSlider('vtM', function () { return vt.m; }, function (x) { vt.m = x; })
  ];
  $('ttTwo').addEventListener('change', function () { tt.two = $('ttTwo').checked; if (tt.two && tt.r > 0.24) tt.r = 0.2; resetTT(); Analytics.track(NAME, '两个物块', String(tt.two)); });
  $('ttRamp').addEventListener('click', function () { tt.w = 0; tt.ramp = true; resetTT(); state.paused = false; syncUI(); Analytics.track(NAME, '缓慢增大ω', ''); });
  $('ttReset').addEventListener('click', function () { tt.ramp = false; resetTT(); });
  $('cpSame').addEventListener('change', function () { cp.same = $('cpSame').checked; cp.phis = [0, 0]; Analytics.track(NAME, '同高圆锥摆', String(cp.same)); });
  $('cpTwo').addEventListener('change', function () { cp.two = $('cpTwo').checked; cp.phis = [0, 0]; Analytics.track(NAME, '圆锥筒两球', String(cp.two)); });
  $('brCrit').addEventListener('click', function () { br.v = Math.round(C.bridgeCrit(br.R, g()) * 2) / 2; br.mode = 'convex'; resetBR(); syncUI(); Analytics.track(NAME, '临界速度', ''); });
  $('showF').addEventListener('change', function () { state.showF = $('showF').checked; });
  $('showV').addEventListener('change', function () { state.showV = $('showV').checked; });
  function togglePause() { state.paused = !state.paused; syncUI(); }
  qa('.pause').forEach(function (b) { b.addEventListener('click', togglePause); });
  qa('.restart').forEach(function (b) { b.addEventListener('click', function () { restart(); state.paused = false; syncUI(); Analytics.track(NAME, '重新开始', state.scene); }); });

  // 竖直圆周的预设速度按钮（随 R、g 变化）
  function vtPresetList() {
    var gR = g() * vt.R;
    return vt.mode === 'rope'
      ? [['√(2gR) 到水平', Math.sqrt(2 * gR)], ['√(3.5gR) 绳松弛', Math.sqrt(3.5 * gR)], ['√(5gR) 恰过顶', Math.sqrt(5 * gR) * 1.002]]
      : [['√(2gR) 到水平', Math.sqrt(2 * gR)], ['2√(gR) 恰到顶', 2 * Math.sqrt(gR) * 1.003], ['√(5gR) 顶点无力', Math.sqrt(5 * gR)]];
  }
  function buildPresets() {
    var box = $('vtPresets');
    box.innerHTML = '';
    vtPresetList().forEach(function (p) {
      var b = document.createElement('button');
      b.textContent = p[0];
      b.addEventListener('click', function () {
        vt.v0 = C.clamp(p[1], 0.5, 12); resetVT(); state.paused = false; syncUI();
        Analytics.track(NAME, '预设速度', p[0]);
      });
      box.appendChild(b);
    });
  }

  // ---------- 画布交互 ----------
  var drag = null;
  function local(e) { var r = cv.getBoundingClientRect(); return { x: e.clientX - r.left, y: e.clientY - r.top }; }
  cv.addEventListener('pointerdown', function (e) {
    if (e.button !== 0) return;
    var p = local(e), gm = view.geo(), sc = state.scene;
    if (!gm) return;
    if (sc === 'vertical') { resetVT(); state.paused = false; syncUI(); Analytics.track(NAME, '重新出发', vt.mode); return; }
    drag = { sc: sc, y0: p.y, th0: cp.th, h0: cp.h };
    try { cv.setPointerCapture(e.pointerId); } catch (err) { /* 合成事件 */ }
    Analytics.track(NAME, '拖动', sc);
    dragTo(p);
  });
  function dragTo(p) {
    var gm = view.geo();
    if (drag.sc === 'turntable') {
      var r = Math.hypot(p.x - gm.c.x, p.y - gm.c.y) / gm.k;
      tt.r = Math.round(C.clamp(r, 0.05, tt.two ? 0.24 : 0.45) * 100) / 100; tt.ramp = false; resetTT();
    } else if (drag.sc === 'conical') {
      var dy = p.y - drag.y0;
      if (cp.mode === 'pendulum') cp.th = Math.round(C.clamp(drag.th0 - dy * 0.25, 5, 80));
      else cp.h = Math.round(C.clamp(drag.h0 - dy / 300, 0.1, 1) * 50) / 50;
    } else if (drag.sc === 'bridge') {
      var w = gm.fr.w(p.x, p.y), span = br.rd.x1 - br.rd.x0;
      var x = C.clamp(w.x, br.rd.x0 - span * 0.3, br.rd.x1 + span * 0.3);
      br.car = C.car(x, br.rd); br.trail = []; state.paused = true; syncUI();
    }
  }
  cv.addEventListener('pointermove', function (e) {
    if (drag) { dragTo(local(e)); return; }
    cv.style.cursor = state.scene === 'conical' ? 'ns-resize' : 'pointer';
  });
  function endDrag(e) {
    if (!drag) return;
    drag = null;
    if (cv.hasPointerCapture(e.pointerId)) cv.releasePointerCapture(e.pointerId);
  }
  cv.addEventListener('pointerup', endDrag);
  cv.addEventListener('pointercancel', endDrag);

  // ---------- 面板 ----------
  $('panelToggle').addEventListener('click', function () { panel.classList.toggle('collapsed'); });
  if (window.matchMedia('(max-width: 760px)').matches) panel.classList.add('collapsed');
  window.addEventListener('keydown', function (e) {
    var tg = e.target.tagName;
    if (tg === 'INPUT' || tg === 'SELECT' || tg === 'BUTTON' || tg === 'TEXTAREA') return;
    if (e.code === 'Space') { e.preventDefault(); togglePause(); }
  });

  function syncUI() {
    var sc = state.scene;
    setSeg('scene', sc);
    qa('[data-for]').forEach(function (el) { el.hidden = el.dataset.for.split(' ').indexOf(sc) < 0; });
    qa('[data-cmode-for]').forEach(function (el) { el.hidden = el.dataset.cmodeFor !== cp.mode; });
    $('hint').textContent = HINTS[sc];
    setSeg('grav', state.grav); setSeg('slow', state.slow);
    setSeg('cmode', cp.mode); setSeg('bmode', br.mode); setSeg('vmode', vt.mode);
    $('ttTwo').checked = tt.two; $('cpSame').checked = cp.same; $('cpTwo').checked = cp.two;
    $('showF').checked = state.showF; $('showV').checked = state.showV;
    qa('.pause').forEach(function (b) { b.textContent = state.paused ? '▶ 继续' : '❚❚ 暂停'; });
    buildPresets();
  }

  // ---------- 读数 ----------
  var lastText = {};
  function setText(id, s) { if (lastText[id] !== s) { lastText[id] = s; $(id).textContent = s; } }
  function rows(list) {
    for (var k = 1; k <= 5; k++) {
      var r = list[k - 1] || ['', ''];
      setText('d' + k, r[0]); setText('r' + k, r[1]);
      $('d' + k).hidden = $('r' + k).hidden = !r[0];
    }
  }
  function N(x) { return f(x, Math.abs(x) >= 100 ? 0 : Math.abs(x) >= 10 ? 1 : 2) + ' N'; }

  function readTT() {
    var gg = g(), A = tt.items[0], w0 = C.critW(tt.mu, gg, tt.r), b = A.b;
    var any = tt.items.some(function (it) { return !it.b.stuck; });
    setText('rName', 'ω = ' + f(tt.w, 2) + ' rad/s');
    setText('rKind', b.off ? 'A 飞出转盘' : !b.stuck ? 'A 相对盘滑动' : any ? 'B 滑动' : '随盘转动');
    var tip;
    if (tt.two) tip = any && b.stuck ? '半径大的 B 所需向心力 mω²r 更大，先达到最大静摩擦力，先滑动。' : '同轴转动 ω 相同，B 的半径是 A 的 2 倍，所需向心力也是 2 倍。';
    else if (!b.stuck) tip = '静摩擦力不足以提供所需的向心力 mω²r，物块做离心运动；滑动摩擦力仍在，所以轨迹向外弯曲而不是沿切线。';
    else tip = '静摩擦力提供向心力：f = mω²r，方向指向圆心；ω 超过 √(μg/r) 物块就会滑动。';
    setText('rTip', tip);
    var bs = C.basics(tt.w, tt.r);
    var list = [
      ['物块 A', 'r = ' + f(tt.r) + ' m，v = ωr = ' + f(bs.v) + ' m/s，T = ' + (tt.w > 0 ? f(bs.T) + ' s' : '—')],
      ['向心力', 'F = mω²r = ' + N(tt.m * bs.a) + '，a = ω²r = ' + f(bs.a) + ' m/s²'],
      ['最大静摩擦', 'μmg = ' + N(tt.mu * tt.m * gg)],
      ['临界', 'ω0 = √(μg/r) = ' + f(w0) + ' rad/s（与 m 无关）']
    ];
    if (tt.two) {
      var rB = tt.items[1].r0;
      list.push(['物块 B', 'r = ' + f(rB) + ' m，F = ' + N(tt.m * tt.w * tt.w * rB) + '，ω0 = ' + f(C.critW(tt.mu, gg, rB)) + ' rad/s']);
    }
    rows(list);
  }

  function cpItems() {
    var gg = g(), list = [];
    if (cp.mode === 'pendulum') {
      var q = C.pendulum(cp.L, cp.th * DEG, gg);
      list.push({ q: q, color: COL.GOLD, name: cp.same ? 'A' : '' });
      if (cp.same) {
        var th2 = (cp.th <= 55 ? cp.th + 20 : cp.th - 25) * DEG;
        list.push({ q: C.pendulum(C.sameHeightL(q.h, th2), th2, gg), color: COL.PINK, name: 'B' });
      }
    } else {
      list.push({ q: C.funnel(cp.al * DEG, cp.h, gg), color: COL.GOLD, name: cp.two ? 'A' : '' });
      if (cp.two) {
        var h2 = cp.h * 1.8 <= RIM * 0.95 ? cp.h * 1.8 : cp.h * 0.5;
        list.push({ q: C.funnel(cp.al * DEG, h2, gg), color: COL.PINK, name: 'B' });
      }
    }
    return list;
  }
  function readCP(items) {
    var q = items[0].q, gg = g();
    if (cp.mode === 'pendulum') {
      setText('rName', 'T = ' + f(q.T) + ' s');
      setText('rKind', '圆锥摆');
      setText('rTip', cp.same ? '两摆悬点相同、轨道平面高度 h 相同，角速度和周期都相同，始终在同一竖直面内。'
        : '重力与拉力的合力水平指向圆心，提供向心力：mg tanθ = mω²r；θ 越大，拉力越大、周期越短。');
      var list = [
        ['几何', 'h = Lcosθ = ' + f(q.h) + ' m，r = Lsinθ = ' + f(q.r) + ' m'],
        ['周期', 'ω = √(g/h) = ' + f(q.w) + ' rad/s，T = 2π√(h/g) = ' + f(q.T) + ' s'],
        ['受力', '拉力 T = mg/cosθ = ' + f(q.tension / gg) + 'mg，F合 = mg tanθ = ' + f(q.fn / gg) + 'mg'],
        ['线速度', 'v = ωr = ' + f(q.v) + ' m/s，a = g tanθ = ' + f(q.fn) + ' m/s²']
      ];
      if (cp.same) { var q2 = items[1].q; list.push(['摆 B', 'L = ' + f(q2.L) + ' m，θ = ' + C.deg(q2.th) + '，T = ' + f(q2.T) + ' s（相同）']); }
      rows(list);
      return;
    }
    setText('rName', 'v = √(gh) = ' + f(q.v) + ' m/s');
    setText('rKind', '圆锥筒');
    setText('rTip', cp.two ? '两球的支持力 N = mg/sinα、加速度 a = g/tanα 都相同；高处的 B 半径大，v 大、ω 小、T 大。'
      : '重力与筒壁支持力的合力水平指向圆心：mg/tanα = mv²/r，所以 v = √(gh)，a 与高度无关。');
    var l2 = [
      ['位置', 'h = ' + f(q.h) + ' m，r = h·tanα = ' + f(q.r) + ' m'],
      ['受力', '支持力 N = mg/sinα = ' + f(q.normal / gg) + 'mg，F合 = mg/tanα = ' + f(q.fn / gg) + 'mg'],
      ['运动', 'a = g/tanα = ' + f(q.fn) + ' m/s²，ω = ' + f(q.w) + ' rad/s，T = ' + f(q.T) + ' s']
    ];
    if (cp.two) { var b2 = items[1].q; l2.push(['小球 B', 'h = ' + f(b2.h) + ' m，v = ' + f(b2.v) + ' m/s，ω = ' + f(b2.w) + ' rad/s，T = ' + f(b2.T) + ' s']); }
    rows(l2);
  }

  function readBR() {
    var gg = g(), rd = br.rd, c = br.car, seg = rd.at(c.x), m = br.m * 1000, vc = C.bridgeCrit(br.R, gg);
    var n = c.air ? 0 : C.roadNormal(seg, br.v, gg) * m, top = (gg + (br.mode === 'convex' ? -1 : 1) * br.v * br.v / br.R) * m;
    setText('rName', 'v = ' + f(br.v) + ' m/s（' + f(br.v * 3.6, 0) + ' km/h）');
    var where = c.air ? '空中' : seg.part === 'arc' ? (br.mode === 'convex' ? '拱桥上' : '凹形桥上') : seg.part === 'ramp' ? '引桥' : '平路';
    setText('rKind', where);
    var tip;
    if (br.mode === 'convex') tip = c.leftAt ? '车速超过 √(gR) 一带的临界值，支持力减为 0，汽车飞离桥面做抛体运动。'
      : '拱桥顶：mg − N = mv²/R，N < mg，失重；车速越大，压力越小。';
    else tip = '凹形桥底：N − mg = mv²/R，N > mg，超重；车速越大，压力越大，容易爆胎。';
    setText('rTip', tip);
    rows([
      ['此刻', c.air ? '飞离桥面，N = 0' : 'N = ' + f(n / 1000) + ' kN（' + f(n / m / gg) + 'mg），' + (n < m * gg - 1 ? '失重' : n > m * gg + 1 ? '超重' : '等于重力')],
      [br.mode === 'convex' ? '桥顶' : '桥底', 'N = mg ' + (br.mode === 'convex' ? '−' : '+') + ' mv²/R = ' + (top > 0 ? f(top / 1000) + ' kN' : '< 0（到不了桥顶就飞离）')],
      ['重力', 'mg = ' + f(m * gg / 1000) + ' kN（m = ' + f(br.m) + ' t）'],
      ['临界速度', br.mode === 'convex' ? 'v = √(gR) = ' + f(vc) + ' m/s（' + f(vc * 3.6, 0) + ' km/h）' : '凹形桥没有飞离问题'],
      ['向心加速度', 'a = v²/R = ' + f(br.v * br.v / br.R) + ' m/s²']
    ]);
  }

  function readVT() {
    var gg = g(), b = vt.b, R = vt.R, v = Math.hypot(b.v.x, b.v.y), rope = vt.mode === 'rope';
    var gR = gg * R, v0 = vt.v0, sa = C.slackAngle(v0, R, gg);
    setText('rName', 'v0 = ' + f(v0) + ' m/s');
    var fate;
    if (rope) fate = v0 >= Math.sqrt(5 * gR) ? '完整圆周' : v0 <= Math.sqrt(2 * gR) ? '下半圆摆动' : '绳会松弛';
    else fate = v0 > 2 * Math.sqrt(gR) ? '完整圆周' : '来回摆动';
    setText('rKind', fate);
    var vtop = C.speedAt(v0, Math.PI, R, gg), tip;
    if (rope) {
      if (fate === '绳会松弛') tip = '越过水平直径后，重力沿绳方向的分力已足够（甚至超过）提供所需向心力，拉力减为 0，绳松弛，小球做斜抛运动。';
      else if (fate === '完整圆周') tip = '最高点 mg + T = mv²/R，T ≥ 0 要求 v ≥ √(gR)，即最低点 v0 ≥ √(5gR)。';
      else tip = 'v0 ≤ √(2gR)，小球最高只到与圆心等高处，在下半圆来回摆动，绳始终绷紧。';
    } else {
      tip = '杆能拉能推：最高点 v < √(gR) 时杆给支持力，v = √(gR) 时无作用力，v > √(gR) 时给拉力；最低点 v0 > 2√(gR) 就能过顶。';
    }
    setText('rTip', tip);
    var F = b.free ? 0 : C.pull(b.om * R, b.th, R, gg) * vt.m;
    var ang = ((b.th % (2 * Math.PI)) + 2 * Math.PI) % (2 * Math.PI);
    var fName = rope ? '拉力 T' : '杆的作用力';
    var fNow = b.free ? '绳松弛，T = 0（只受重力）' : (rope ? 'T = ' + N(F) : (F >= 0 ? '拉力 ' : '支持力 ') + N(Math.abs(F)));
    rows([
      ['此刻', 'v = ' + f(v) + ' m/s，' + (b.free ? '斜抛中' : '转过 ' + f(ang / DEG, 0) + '°')],
      [fName, fNow],
      ['最低点', (rope ? 'T' : 'F') + ' = mg + mv0²/R = ' + N(vt.m * (gg + v0 * v0 / R))],
      ['最高点', isNaN(vtop) || (rope && sa != null) ? '到不了' : 'v = ' + f(vtop) + ' m/s，' + (rope ? 'T' : 'F') + ' = mv²/R − mg = ' + N(vt.m * (vtop * vtop / R - gg))],
      ['临界', rope ? '最高点 √(gR) = ' + f(Math.sqrt(gR)) + '，最低点 √(5gR) = ' + f(Math.sqrt(5 * gR)) + ' m/s'
        : '最低点 2√(gR) = ' + f(2 * Math.sqrt(gR)) + '，最高点无力时 √(gR) = ' + f(Math.sqrt(gR)) + ' m/s']
    ]);
  }

  // ---------- 尺寸与主循环 ----------
  function resize() { view.resize(stage.clientWidth, stage.clientHeight); }
  new ResizeObserver(resize).observe(stage);

  // 支持 ?scene=turntable|conical|bridge|vertical、&g=9.8|10、&slow=1|0.5|0.25、&show=f,v；
  // 转盘 &w=、&r=、&mu=、&m=（kg）、&two=1、&ramp=1；圆锥摆 &mode=pendulum|funnel、&L=、&th=、&same=1、&alpha=、&h=、&two=1；
  // 过桥 &mode=convex|concave、&v=、&R=、&m=（t）；竖直圆周 &mode=rope|rod、&v0=、&R=、&m=（kg）
  var qs = new URLSearchParams(location.search);
  function num(k, lo, hi) { var x = parseFloat(qs.get(k)); return isFinite(x) && x >= lo && x <= hi ? x : null; }
  var x, sc = qs.get('scene'), mode = qs.get('mode');
  if (HINTS[sc]) state.scene = sc;
  if (C.GRAV[qs.get('g')]) state.grav = qs.get('g');
  if ([1, 0.5, 0.25].indexOf(parseFloat(qs.get('slow'))) >= 0) state.slow = parseFloat(qs.get('slow'));
  if (qs.get('show') != null) { var want = qs.get('show').split(','); state.showF = want.indexOf('f') >= 0; state.showV = want.indexOf('v') >= 0; }
  if (state.scene === 'turntable') {
    if ((x = num('w', 0, 10)) != null) tt.w = x;
    if ((x = num('r', 0.05, 0.45)) != null) tt.r = x;
    if ((x = num('mu', 0.1, 1)) != null) tt.mu = x;
    if ((x = num('m', 0.1, 2)) != null) tt.m = x;
    if (qs.get('two') === '1') { tt.two = true; tt.r = Math.min(tt.r, 0.24); }
  } else if (state.scene === 'conical') {
    if (mode === 'pendulum' || mode === 'funnel') cp.mode = mode;
    if ((x = num('L', 0.3, 2)) != null) cp.L = x;
    if ((x = num('th', 5, 80)) != null) cp.th = x;
    if ((x = num('alpha', 15, 60)) != null) cp.al = x;
    if ((x = num('h', 0.1, 1)) != null) cp.h = x;
    if (qs.get('same') === '1') cp.same = true;
    if (qs.get('two') === '1') cp.two = true;
  } else if (state.scene === 'bridge') {
    if (mode === 'convex' || mode === 'concave') br.mode = mode;
    if ((x = num('v', 1, 40)) != null) br.v = x;
    if ((x = num('R', 10, 100)) != null) br.R = x;
    if ((x = num('m', 0.5, 3)) != null) br.m = x;
  } else if (state.scene === 'vertical') {
    if (mode === 'rope' || mode === 'rod') vt.mode = mode;
    if ((x = num('v0', 0.5, 12)) != null) vt.v0 = x;
    if ((x = num('R', 0.3, 1.5)) != null) vt.R = x;
    if ((x = num('m', 0.1, 2)) != null) vt.m = x;
  }

  resize();
  setScene(state.scene);
  if (state.scene === 'turntable' && qs.get('ramp') === '1') { tt.w = 0; tt.ramp = true; }

  var RAMP = 0.3;  // 缓慢增大 ω 的角加速度（rad/s²）
  function stepTT(dt) {
    var gg = g();
    if (tt.ramp) {
      tt.w = Math.min(10, tt.w + RAMP * dt);
      if (tt.w >= 10 || tt.items.every(function (it) { return it.b.off; })) tt.ramp = false;
    }
    tt.phi = (tt.phi + tt.w * dt) % (Math.PI * 2);
    tt.items.forEach(function (it) {
      var b = it.b;
      if (b.stuck && it.trail.length) it.trail = [];
      C.stepBlock(b, tt.w, tt.phi, tt.mu, gg, dt);
      if (!b.stuck) {
        if (!it.fixAng && it.fixAng !== 0) it.fixAng = Math.atan2(b.p.y, b.p.x);
        it.trail.push({ x: b.p.x, y: b.p.y });
        if (it.trail.length > 600) it.trail.shift();
      } else it.fixAng = null;
      // 飞出转盘、跑出画面后放回原处
      if (b.off) {
        it.wait += dt;
        if (Math.hypot(b.p.x, b.p.y) > C.DISK_R * 1.9 || it.wait > 2.5) {
          it.b = C.block(it.r0, it.name === 'A' ? 0 : Math.PI);
          it.b.ang = Math.atan2(b.slipAt ? b.slipAt.y : 0, b.slipAt ? b.slipAt.x : 1) - tt.phi;
          it.trail = []; it.wait = 0; it.fixAng = null;
          // 匀加速中滑出的物块不再放回，便于比较谁先滑
          if (tt.ramp) { it.b.off = true; it.b.stuck = false; it.b.p = { x: 99, y: 99 }; it.b.v = { x: 0, y: 0 }; }
        }
      }
    });
  }
  function stepBR(dt) {
    var span = br.rd.x1 - br.rd.x0, c = br.car;
    if (c.x > br.rd.x1 + span * 0.32) { br.wait += dt; if (br.wait > 0.8) resetBR(); return; }
    C.stepCar(c, br.rd, br.v, g(), dt);
    if (c.air) br.trail.push({ x: c.x, y: c.y });
  }
  function stepVT(dt) {
    C.stepVball(vt.b, vt.R, g(), vt.mode === 'rope', dt);
    vt.trail.push({ x: vt.b.p.x, y: vt.b.p.y });
    if (vt.trail.length > 900) vt.trail.shift();
  }

  var lastT = performance.now();
  function frame(now) {
    var dt = Math.min((now - lastT) / 1000, 0.05) * state.slow;
    lastT = now;
    var sc = state.scene, items;
    if (sc === 'conical') items = cpItems();
    if (!state.paused) {
      if (sc === 'turntable') stepTT(dt);
      else if (sc === 'conical') items.forEach(function (it, i) { cp.phis[i] = (cp.phis[i] + it.q.w * dt) % (Math.PI * 2); });
      else if (sc === 'bridge') stepBR(dt);
      else stepVT(dt);
    }
    sliders.forEach(function (s) { if (document.activeElement !== s.el) s.el.value = s.get(); });
    setText('ttWOut', f(tt.w, 1) + ' rad/s'); setText('ttROut', f(tt.r) + ' m'); setText('ttMuOut', f(tt.mu)); setText('ttMOut', f(tt.m) + ' kg');
    setText('cpLOut', f(cp.L) + ' m'); setText('cpThOut', cp.th + '°'); setText('cpAlOut', cp.al + '°'); setText('cpHOut', f(cp.h) + ' m');
    setText('brVOut', f(br.v) + ' m/s'); setText('brROut', br.R + ' m'); setText('brMOut', f(br.m) + ' t');
    setText('vtVOut', f(vt.v0) + ' m/s'); setText('vtROut', f(vt.R) + ' m'); setText('vtMOut', f(vt.m) + ' kg');

    if (sc === 'turntable') {
      view.drawTurntable({ phi: tt.phi, w: tt.w, mu: tt.mu, g: g(), gName: gName(), showV: state.showV, showF: state.showF,
        blocks: tt.items.map(function (it) { return { b: it.b, r0: it.r0, m: tt.m, color: it.color, name: it.name, trail: it.trail, fixAng: it.fixAng }; }) });
      readTT();
    } else if (sc === 'conical') {
      items.forEach(function (it, i) { it.phi = cp.phis[i]; });
      view.drawConical({ mode: cp.mode, items: items, g: g(), gName: gName(), rim: RIM, showF: state.showF, showV: state.showV });
      readCP(items);
    } else if (sc === 'bridge') {
      var key = [br.mode, br.R, br.v, state.grav].join();
      if (br.profKey !== key) {
        var span = br.rd.x1 - br.rd.x0;
        br.prof = C.bridgeProfile(br.rd, br.v, g(), br.rd.x0 - span * 0.3, br.rd.x1 + span * 0.3); br.profKey = key;
      }
      view.drawBridge({ rd: br.rd, car: br.car, v: br.v, g: g(), gName: gName(), prof: br.prof, trail: br.trail, showF: state.showF });
      readBR();
    } else {
      view.drawVertical({ R: vt.R, rope: vt.mode === 'rope', b: vt.b, trail: vt.trail, g: g(), gName: gName(), showF: state.showF, showV: state.showV });
      readVT();
    }
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // 调试用
  window.__model = {
    state: state, setScene: setScene, restart: restart, syncUI: syncUI,
    setW: function (w) { tt.w = C.clamp(w, 0, 10); tt.ramp = false; },
    setV: function (v) { br.v = C.clamp(v, 1, 40); },
    setV0: function (v) { vt.v0 = C.clamp(v, 0.5, 12); resetVT(); }
  };
})();
