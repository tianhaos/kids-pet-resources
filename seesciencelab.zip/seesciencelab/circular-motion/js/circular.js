// 圆周运动的计算：转盘上的物块（静摩擦提供向心力、滑动与离心运动）、圆锥摆与圆锥筒内的小球、汽车过拱桥/凹形桥、竖直面内的圆周运动（绳模型、杆模型）
// 单位一律 SI：m、s、kg、N、rad；g 由调用方传入。不碰 DOM
// 转盘：俯视，盘心为原点，x 右 y 上，盘逆时针转（ω > 0）
// 拱桥：侧视，x 右 y 上，桥中点在 x = 0，地面 y = 0；汽车从左向右开
// 竖直圆：圆心为原点，θ 从最低点起逆时针为正，小球位置 (R sinθ, −R cosθ)
(function () {
  var DEG = Math.PI / 180, TAU = Math.PI * 2;
  var GRAV = { '9.8': 9.8, '10': 10 };

  function clamp(x, a, b) { return Math.max(a, Math.min(b, x)); }
  function f(x, d) {
    if (d == null) d = Math.abs(x) >= 100 ? 0 : Math.abs(x) >= 10 ? 1 : 2;
    var s = x.toFixed(d);
    s = s.indexOf('.') >= 0 ? s.replace(/\.?0+$/, '') : s;
    return s === '-0' ? '0' : s;
  }
  function deg(a) { return f(a / DEG, 1) + '°'; }

  // 匀速圆周运动的基本量：已知 ω 和 r
  function basics(w, r) {
    return { w: w, r: r, v: w * r, T: w > 0 ? TAU / w : Infinity, n: w / TAU, a: w * w * r };
  }

  // ---------- 转盘 ----------
  var DISK_R = 0.5;  // 转盘半径
  // 物块恰好不滑动的临界角速度：μmg = mω²r ⇒ ω0 = √(μg/r)，与质量无关
  function critW(mu, g, r) { return Math.sqrt(mu * g / r); }
  // 物块：{ stuck, ang（相对转盘的角位置）, r, p: {x,y}, v: {x,y}, off（已飞出转盘）}
  function block(r, ang) { return { stuck: true, ang: ang, r: r, p: { x: r, y: 0 }, v: { x: 0, y: 0 }, off: false, slipAt: null }; }
  // 推进 dt；phi 为转盘当前转角。滑动时在地面系里积分：盘上受滑动摩擦 μmg，方向与相对转盘的速度相反；飞出盘边后不再受力
  function stepBlock(b, w, phi, mu, g, dt) {
    var need = w * w * b.r, fmax = mu * g;
    if (b.stuck) {
      var a = phi + b.ang;
      b.p = { x: b.r * Math.cos(a), y: b.r * Math.sin(a) };
      b.v = { x: -w * b.p.y, y: w * b.p.x };
      if (need > fmax * (1 + 1e-9)) { b.stuck = false; b.slipAt = { x: b.p.x, y: b.p.y }; }
      return;
    }
    var n = 40, h = dt / n;
    for (var i = 0; i < n; i++) {
      var rr = Math.hypot(b.p.x, b.p.y);
      if (rr < DISK_R && !b.off) {
        var ux = -w * b.p.y, uy = w * b.p.x, wx = b.v.x - ux, wy = b.v.y - uy, wl = Math.hypot(wx, wy);
        if (wl < fmax * h * 1.5) {
          // 相对静止：若静摩擦够用就重新随盘转动
          if (w * w * rr <= fmax) { b.stuck = true; b.r = rr; b.ang = Math.atan2(b.p.y, b.p.x) - phi; return; }
          b.v.x = ux; b.v.y = uy; wl = 0;
        }
        if (wl > 0) { b.v.x -= fmax * wx / wl * h; b.v.y -= fmax * wy / wl * h; }
      } else b.off = true;
      b.p.x += b.v.x * h; b.p.y += b.v.y * h;
    }
  }

  // ---------- 圆锥摆、圆锥筒 ----------
  // 圆锥摆：摆长 L、摆线与竖直方向夹角 θ。mg tanθ = mω²·L sinθ ⇒ ω = √(g/(L cosθ))，周期只由悬点到圆心的高度 h = L cosθ 决定
  function pendulum(L, th, g) {
    var h = L * Math.cos(th), r = L * Math.sin(th), w = Math.sqrt(g / h), b = basics(w, r);
    b.h = h; b.L = L; b.th = th;
    b.tension = g / Math.cos(th);   // 每千克的拉力 F = mg/cosθ
    b.fn = g * Math.tan(th);        // 每千克的向心力 = 加速度 a = g tanθ
    return b;
  }
  // 同高 h、不同夹角的圆锥摆的摆长
  function sameHeightL(h, th) { return h / Math.cos(th); }
  // 光滑圆锥筒内壁：筒壁与竖直轴夹角 α，小球离锥顶高度 h。N sinα = mg、N cosα = mv²/r ⇒ v = √(gh)，a = g/tanα 与高度无关
  function funnel(al, h, g) {
    var r = h * Math.tan(al), v = Math.sqrt(g * h), b = basics(v / r, r);
    b.h = h; b.al = al;
    b.normal = g / Math.sin(al);    // 每千克的支持力
    b.fn = g / Math.tan(al);
    return b;
  }

  // ---------- 拱桥、凹形桥 ----------
  var ARC = 25 * DEG;  // 桥面圆弧两端的切线倾角，引桥按这个坡度与圆弧相切
  // 桥面：引桥（直线坡）+ 圆弧 + 引桥。convex 拱桥向上拱，concave 凹形桥向下凹
  function road(R, convex) {
    var sx = R * Math.sin(ARC), rise = R * (1 - Math.cos(ARC)), e = rise;   // e：圆弧端点离地高度（凹桥为深度）
    var ramp = e / Math.tan(ARC), sgn = convex ? 1 : -1;
    var top = sgn * (e + rise);   // 圆弧顶点（凹桥为最低点）的 y
    var cy = convex ? top - R : top + R;
    return {
      R: R, convex: convex, sx: sx, ramp: ramp, x0: -(sx + ramp), x1: sx + ramp, top: top, cy: cy, end: sgn * e,
      at: function (x) {
        var ax = Math.abs(x), s = x < 0 ? -1 : 1;
        if (ax >= sx + ramp) return { y: 0, th: 0, k: 0, part: 'flat' };
        if (ax >= sx) {
          var y = sgn * (e - (ax - sx) * Math.tan(ARC));
          // 拱桥左侧上坡（th > 0），凹桥左侧下坡
          return { y: y, th: -s * sgn * ARC, k: 0, part: 'ramp' };
        }
        var d = Math.sqrt(R * R - x * x);
        // 圆弧：拱桥 y = cy + √(R² − x²)，曲率 −1/R；凹桥 y = cy − √(R² − x²)，曲率 +1/R
        return { y: convex ? cy + d : cy - d, th: Math.atan(convex ? -x / d : x / d), k: (convex ? -1 : 1) / R, part: 'arc' };
      }
    };
  }
  // 路面对车的支持力（每千克）：N/m = g cosθ + v²·k；拱桥顶 N = m(g − v²/R)，凹桥底 N = m(g + v²/R)
  function roadNormal(seg, v, g) { return g * Math.cos(seg.th) + v * v * seg.k; }
  // 汽车：{ x, y, vx, vy, air }。沿路面以恒定速率 v 行驶（司机控制油门），支持力减为 0 时飞离桥面做抛体运动，落回路面后继续以 v 行驶
  function car(x, rd) { return { x: x, y: rd.at(x).y, vx: 0, vy: 0, air: false, leftAt: null, landAt: null }; }
  function stepCar(c, rd, v, g, dt) {
    var n = 20, h = dt / n;
    for (var i = 0; i < n; i++) {
      if (c.air) {
        c.vy -= g * h; c.x += c.vx * h; c.y += c.vy * h;
        var s = rd.at(c.x);
        if (c.y <= s.y && c.vy < 0) { c.y = s.y; c.air = false; c.landAt = { x: c.x, y: c.y }; }
        continue;
      }
      var seg = rd.at(c.x);
      if (roadNormal(seg, v, g) < 0) {
        c.air = true; c.leftAt = { x: c.x, y: seg.y };
        c.vx = v * Math.cos(seg.th); c.vy = v * Math.sin(seg.th);
        continue;
      }
      c.x += v * Math.cos(seg.th) * h;
      c.y = rd.at(c.x).y;
      c.vx = v * Math.cos(seg.th); c.vy = v * Math.sin(seg.th);
    }
  }
  // 拱桥顶点的临界速度：mg = mv²/R ⇒ v = √(gR)，超过就飞离桥面
  function bridgeCrit(R, g) { return Math.sqrt(g * R); }
  // 以速率 v 从 xa 开到 xb 全程的 N/mg（飞离桥面时为 0），供画 N–x 图
  function bridgeProfile(rd, v, g, xa, xb) {
    var c = car(xa, rd), out = [], guard = 0;
    while (c.x < xb && guard++ < 20000) {
      out.push({ x: c.x, y: c.y, n: c.air ? 0 : roadNormal(rd.at(c.x), v, g) / g, air: c.air });
      stepCar(c, rd, v, g, Math.max(0.002, (xb - xa) / v / 400));
    }
    return out;
  }

  // ---------- 竖直面内的圆周运动 ----------
  // 小球：{ th, om（dθ/dt）, free（绳松弛、做抛体运动）, p, v }
  function vball(v0, R) { return { th: 0, om: v0 / R, free: false, p: { x: 0, y: -R }, v: { x: v0, y: 0 }, slackAt: null, tautAt: null }; }
  function vpos(th, R) { return { x: R * Math.sin(th), y: -R * Math.cos(th) }; }
  // 绳（杆）对小球指向圆心的拉力（每千克）：F/m = v²/R + g cosθ；杆模型可为负（支持力，背离圆心）
  function pull(v, th, R, g) { return v * v / R + g * Math.cos(th); }
  // 绳在 θ 处松弛的条件：v0² − 2gR(1 − cosθ) = −gR cosθ ⇒ cosθ = (2gR − v0²)/(3gR)
  function slackAngle(v0, R, g) {
    var c = (2 * g * R - v0 * v0) / (3 * g * R);
    return c > -1 && c < 0 ? Math.acos(c) : null;
  }
  // 由最低点速度求 θ 处的速率（机械能守恒），到不了时返回 NaN
  function speedAt(v0, th, R, g) {
    var q = v0 * v0 - 2 * g * R * (1 - Math.cos(th));
    return q >= 0 ? Math.sqrt(q) : NaN;
  }
  function stepVball(b, R, g, rope, dt) {
    var n = 60, h = dt / n;
    function acc(th) { return -g / R * Math.sin(th); }
    for (var i = 0; i < n; i++) {
      if (b.free) {
        b.v.y -= g * h; b.p.x += b.v.x * h; b.p.y += b.v.y * h;
        var rr = Math.hypot(b.p.x, b.p.y), vr = (b.p.x * b.v.x + b.p.y * b.v.y) / rr;
        if (rr >= R && vr > 0) {
          // 绳子重新绷紧：沿绳方向的速度瞬间损失（有机械能损失），只保留切向速度
          b.free = false;
          b.th = Math.atan2(b.p.x, -b.p.y);
          b.om = (b.v.x * Math.cos(b.th) + b.v.y * Math.sin(b.th)) / R;
          b.p = vpos(b.th, R); b.tautAt = { x: b.p.x, y: b.p.y };
        }
        continue;
      }
      // RK4 积分 θ'' = −(g/R) sinθ
      var t0 = b.th, w0 = b.om;
      var k1t = w0, k1w = acc(t0);
      var k2t = w0 + k1w * h / 2, k2w = acc(t0 + k1t * h / 2);
      var k3t = w0 + k2w * h / 2, k3w = acc(t0 + k2t * h / 2);
      var k4t = w0 + k3w * h, k4w = acc(t0 + k3t * h);
      b.th = t0 + (k1t + 2 * k2t + 2 * k3t + k4t) * h / 6;
      b.om = w0 + (k1w + 2 * k2w + 2 * k3w + k4w) * h / 6;
      b.p = vpos(b.th, R);
      b.v = { x: b.om * R * Math.cos(b.th), y: b.om * R * Math.sin(b.th) };
      if (rope && pull(b.om * R, b.th, R, g) < 0) { b.free = true; b.slackAt = { x: b.p.x, y: b.p.y }; }
    }
  }

  window.Circ = {
    DEG: DEG, TAU: TAU, GRAV: GRAV, DISK_R: DISK_R, ARC: ARC,
    clamp: clamp, f: f, deg: deg, basics: basics,
    critW: critW, block: block, stepBlock: stepBlock,
    pendulum: pendulum, sameHeightL: sameHeightL, funnel: funnel,
    road: road, roadNormal: roadNormal, car: car, stepCar: stepCar, bridgeCrit: bridgeCrit, bridgeProfile: bridgeProfile,
    vball: vball, vpos: vpos, pull: pull, slackAngle: slackAngle, speedAt: speedAt, stepVball: stepVball
  };
})();
