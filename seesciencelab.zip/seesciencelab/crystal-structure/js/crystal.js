// 晶体结构：晶体数据、晶胞内粒子与均摊、配位数、密度、练习出题（纯计算，不碰 DOM）
// 坐标单位 pm，晶体坐标系 x、y、z（六方晶系 z 为 c 轴）；立方晶胞取 [0, a]³，六方取以原点为中心、外接圆半径 a 的六棱柱
(function () {
  var NA = 6.022e23;
  var S3 = Math.sqrt(3);
  var EPS = 1e-3;              // 判断“在面上”的相对容差（× a）

  // ---------- 粒子种类 ----------
  // r：堆积模型中的半径（pm，离子晶体再按最近距离等比缩放到恰好相切）；col 颜色
  var SP = {
    Na: { f: 'Na⁺', name: '钠离子', col: '#b48cff', r: 102 },
    Cl: { f: 'Cl⁻', name: '氯离子', col: '#7ee081', r: 181 },
    Cs: { f: 'Cs⁺', name: '铯离子', col: '#ff9f6e', r: 174 },
    Ca: { f: 'Ca²⁺', name: '钙离子', col: '#4fc3f7', r: 112 },
    F:  { f: 'F⁻', name: '氟离子', col: '#e6ee9c', r: 131 },
    Zn: { f: 'Zn²⁺', name: '锌离子', col: '#9fb3c8', r: 60 },
    S:  { f: 'S²⁻', name: '硫离子', col: '#ffd54f', r: 184 },
    C:  { f: 'C', name: '碳原子', col: '#a9b4c2', r: 77 },
    Si: { f: 'Si', name: '硅原子', col: '#e0b080', r: 60 },
    O:  { f: 'O', name: '氧原子', col: '#ff6b6b', r: 95 },
    CO2:{ f: 'CO₂', name: '二氧化碳分子', col: '#a9b4c2', r: 0, mol: true },
    Po: { f: 'Po', name: '钋原子', col: '#9ccc65', r: 0 },
    NaM:{ f: 'Na', name: '钠原子', col: '#b48cff', r: 0 },
    Cu: { f: 'Cu', name: '铜原子', col: '#e8915a', r: 0 },
    Mg: { f: 'Mg', name: '镁原子', col: '#b8c7d9', r: 0 },
    A:  { f: 'A', name: 'A 粒子', col: '#ffc94a', r: 120 },
    B:  { f: 'B', name: 'B 粒子', col: '#4fc3f7', r: 120 },
    X:  { f: 'C', name: 'C 粒子', col: '#7ee081', r: 120 }
  };

  var FCC = [[0, 0, 0], [0.5, 0.5, 0], [0.5, 0, 0.5], [0, 0.5, 0.5]];
  var TET = [[0.25, 0.25, 0.25], [0.75, 0.75, 0.25], [0.75, 0.25, 0.75], [0.25, 0.75, 0.75]]; // 交替的 4 个四面体空隙
  var TET8 = [];
  [0.25, 0.75].forEach(function (x) { [0.25, 0.75].forEach(function (y) { [0.25, 0.75].forEach(function (z) { TET8.push([x, y, z]); }); }); });
  function put(list, sp) { return list.map(function (p) { return { sp: sp, p: p }; }); }
  function shift(list, d) { return list.map(function (p) { return [(p[0] + d[0]) % 1, (p[1] + d[1]) % 1, (p[2] + d[2]) % 1]; }); }

  // SiO₂：硅按金刚石排列，每个 Si–Si 键的中点放一个 O（理想化的方石英）
  var SIO2_O = (function () {
    var out = [], seen = {};
    FCC.forEach(function (p) {
      [[1, 1, 1], [1, -1, -1], [-1, 1, -1], [-1, -1, 1]].forEach(function (d) {
        var q = [0, 1, 2].map(function (k) { var v = (p[k] + d[k] / 8 + 1) % 1; return Math.round(v * 8) / 8; });
        var key = q.join();
        if (!seen[key]) { seen[key] = 1; out.push(q); }
      });
    });
    return out;
  })();
  // 干冰：CO₂ 分子中心按面心立方排列，分子轴分别沿四条体对角线
  var CO2_DIR = [[1, 1, 1], [1, -1, -1], [-1, 1, -1], [-1, -1, 1]];

  // kind：ion 离子晶体 / cov 共价晶体 / mol 分子晶体 / metal 金属晶体 / mix 混合型晶体
  // hex：六方晶系（a、c）；bonds：画键的粒子对；cnSp：配位数按“最近的异种粒子”数
  var CRYSTALS = {
    nacl: { name: '氯化钠', formula: 'NaCl', kind: 'ion', a: 564, M: 58.5,
      basis: put(FCC, 'Na').concat(put(shift(FCC, [0.5, 0, 0]), 'Cl')),
      bonds: [['Na', 'Cl']], cnSp: true, unit: 'NaCl',
      dExpr: 'a/2', poly: '正八面体',
      facts: ['每个 Na⁺ 周围有 6 个 Cl⁻，每个 Cl⁻ 周围有 6 个 Na⁺，构成正八面体', '每个 Na⁺ 周围距离最近的 Na⁺ 有 12 个（距离 √2a/2）', '晶胞中 Na⁺：8×1/8 + 6×1/2 = 4，Cl⁻：12×1/4 + 1 = 4，含 4 个“NaCl”', 'NaCl 只表示 Na⁺ 与 Cl⁻ 的个数比为 1∶1，晶体中没有 NaCl 分子'] },
    cscl: { name: '氯化铯', formula: 'CsCl', kind: 'ion', a: 412.3, M: 168.4,
      basis: put([[0, 0, 0]], 'Cl').concat(put([[0.5, 0.5, 0.5]], 'Cs')),
      bonds: [['Cs', 'Cl']], cnSp: true, unit: 'CsCl',
      dExpr: '√3a/2', poly: '立方体',
      facts: ['每个 Cs⁺ 周围有 8 个 Cl⁻，每个 Cl⁻ 周围有 8 个 Cs⁺，构成立方体', '每个 Cs⁺ 周围距离最近的 Cs⁺ 有 6 个（距离 a）', '晶胞中 Cl⁻：8×1/8 = 1，Cs⁺：1，含 1 个“CsCl”', 'Cs⁺ 半径比 Na⁺ 大，周围能容纳更多的阴离子，所以配位数不同'] },
    caf2: { name: '氟化钙（萤石）', formula: 'CaF₂', kind: 'ion', a: 546.3, M: 78.1,
      basis: put(FCC, 'Ca').concat(put(TET8, 'F')),
      bonds: [['Ca', 'F']], cnSp: true, unit: 'CaF₂',
      dExpr: '√3a/4', poly: '',
      facts: ['Ca²⁺ 位于顶点和面心，8 个 F⁻ 位于晶胞内的 8 个四面体空隙中', '每个 Ca²⁺ 周围有 8 个 F⁻（立方体），每个 F⁻ 周围有 4 个 Ca²⁺（正四面体），配位数之比 8∶4 = 2∶1，与化学式中个数比相反', '晶胞中 Ca²⁺：4，F⁻：8，含 4 个“CaF₂”', '每个 F⁻ 周围距离最近的 F⁻ 有 6 个（距离 a/2）'] },
    zns: { name: '硫化锌（闪锌矿）', formula: 'ZnS', kind: 'ion', a: 541, M: 97.4,
      basis: put(FCC, 'S').concat(put(TET, 'Zn')),
      bonds: [['Zn', 'S']], cnSp: true, unit: 'ZnS',
      dExpr: '√3a/4', poly: '正四面体',
      facts: ['S²⁻ 位于顶点和面心，4 个 Zn²⁺ 位于晶胞内，占据一半的四面体空隙', '每个 Zn²⁺ 周围有 4 个 S²⁻，每个 S²⁻ 周围有 4 个 Zn²⁺，构成正四面体', '晶胞中 S²⁻：4，Zn²⁺：4，含 4 个“ZnS”', '把 Zn、S 都换成 C，就是金刚石的晶胞'] },
    diamond: { name: '金刚石', formula: 'C', kind: 'cov', a: 356.7, M: 12,
      basis: put(FCC.concat(TET), 'C'),
      bonds: [['C', 'C']], unit: 'C',
      dExpr: '√3a/4', poly: '正四面体',
      facts: ['每个 C 原子以 sp³ 杂化与 4 个 C 原子形成共价键，构成正四面体，键角 109°28′', '晶胞中 C 原子：8×1/8 + 6×1/2 + 4 = 8', '最小的碳环是六元环（椅式，不在同一平面），每个 C 原子被 12 个六元环共用', '每个 C 原子形成 4 个 C–C 键，每个键被 2 个原子共用：1 mol 金刚石含 2 mol C–C 键'] },
    sio2: { name: '二氧化硅', formula: 'SiO₂', kind: 'cov', a: 716, M: 60.1,
      basis: put(FCC.concat(TET), 'Si').concat(put(SIO2_O, 'O')),
      bonds: [['Si', 'O']], cnSp: true, unit: 'SiO₂',
      dExpr: '√3a/8', poly: '正四面体',
      facts: ['每个 Si 原子与 4 个 O 原子形成 [SiO₄] 四面体，每个 O 原子与 2 个 Si 原子相连', 'Si 与 O 的个数比为 1∶2，“SiO₂”是化学式，晶体中没有 SiO₂ 分子', '最小的环由 6 个 Si 和 6 个 O 构成，是十二元环', '1 mol SiO₂ 中含 4 mol Si–O 键'] },
    graphite: { name: '石墨', formula: 'C', kind: 'mix', hex: true, a: 246.4, c: 670.8, M: 12,
      basis: put([[0, 0, 0], [1 / 3, 2 / 3, 0], [0, 0, 0.5], [2 / 3, 1 / 3, 0.5]], 'C'),
      bonds: [['C', 'C', 142.3]], unit: 'C',
      dExpr: '√3a/3（层内）', poly: '正三角形',
      facts: ['层内每个 C 原子以 sp² 杂化与 3 个 C 原子形成共价键，构成平面六元环，键角 120°', '每个六元环平均含 6×1/3 = 2 个 C 原子、6×1/2 = 3 个 C–C 键；1 mol 石墨含 1.5 mol C–C 键', '层与层之间以范德华力结合（层间距 335 pm，远大于层内键长 142 pm），所以石墨质软、能导电', '既有共价键又有范德华力，还有类似金属键的离域电子，属于混合型晶体'] },
    co2: { name: '干冰', formula: 'CO₂', kind: 'mol', a: 562.4, M: 44,
      basis: FCC.map(function (p, i) { return { sp: 'CO2', p: p, dir: CO2_DIR[i] }; }),
      bonds: [], unit: 'CO₂',
      dExpr: '√2a/2', poly: '',
      facts: ['CO₂ 分子位于顶点和面心，按面心立方排列，晶胞中含 8×1/8 + 6×1/2 = 4 个 CO₂ 分子', '每个 CO₂ 分子周围有 12 个紧邻的 CO₂ 分子，分子之间只有范德华力，属于分子密堆积', '分子间作用力弱，干冰熔点低、易升华；分子内 C=O 是共价键', '冰中水分子之间有氢键，每个水分子周围只有 4 个紧邻分子，不是密堆积'] },
    po: { name: '钋（简单立方）', formula: 'Po', kind: 'metal', a: 335, M: 209,
      basis: put([[0, 0, 0]], 'Po'), bonds: [], unit: 'Po', dExpr: 'a', poly: '正八面体', pack: '简单立方堆积',
      facts: ['原子只位于顶点，晶胞中含 8×1/8 = 1 个原子', '配位数 6，原子半径 r = a/2', '空间利用率 52%，只有少数金属（如 Po）采取这种堆积'] },
    na: { name: '钠（体心立方）', formula: 'Na', kind: 'metal', a: 429.1, M: 23,
      basis: put([[0, 0, 0], [0.5, 0.5, 0.5]], 'NaM'), bonds: [], unit: 'Na', dExpr: '√3a/2', poly: '立方体', pack: '体心立方堆积',
      facts: ['原子位于顶点和体心，晶胞中含 8×1/8 + 1 = 2 个原子', '配位数 8，原子沿体对角线相切：4r = √3a', '空间利用率 68%，Na、K、Fe 等采取这种堆积'] },
    cu: { name: '铜（面心立方）', formula: 'Cu', kind: 'metal', a: 361.5, M: 63.5,
      basis: put(FCC, 'Cu'), bonds: [], unit: 'Cu', dExpr: '√2a/2', poly: '', pack: '面心立方最密堆积',
      facts: ['原子位于顶点和面心，晶胞中含 8×1/8 + 6×1/2 = 4 个原子', '配位数 12，原子沿面对角线相切：4r = √2a', '密置层按 ABCABC… 方式堆积，空间利用率 74%，Cu、Ag、Au、Al 等采取这种堆积'] },
    mg: { name: '镁（六方最密）', formula: 'Mg', kind: 'metal', hex: true, a: 320.9, c: 521, M: 24.3,
      basis: put([[0, 0, 0], [1 / 3, 2 / 3, 0.5]], 'Mg'), bonds: [], unit: 'Mg', dExpr: 'a', poly: '', pack: '六方最密堆积',
      facts: ['密置层按 ABAB… 方式堆积，配位数 12，空间利用率 74%，Mg、Zn、Ti 等采取这种堆积', '六棱柱中：12 个顶点各 1/6，上下底面心各 1/2，中间层 3 个在柱内，共 12×1/6 + 2×1/2 + 3 = 6 个原子', '六方最密堆积与面心立方最密堆积的配位数、空间利用率都相同，只是密置层的堆积顺序不同'] }
  };
  var GROUPS = [
    { id: 'ion', name: '离子晶体', list: ['nacl', 'cscl', 'caf2', 'zns'] },
    { id: 'cov', name: '共价晶体', list: ['diamond', 'sio2'] },
    { id: 'mol', name: '分子晶体 · 混合型', list: ['co2', 'graphite'] },
    { id: 'metal', name: '金属晶体', list: ['po', 'na', 'cu', 'mg'] }
  ];
  var KIND = { ion: '离子晶体', cov: '共价晶体', mol: '分子晶体', metal: '金属晶体', mix: '混合型晶体' };
  var POS = { vtx: '顶点', edge: '棱上', face: '面上', in: '体内' };
  var POS_COL = { vtx: '#ff7a59', edge: '#ffc94a', face: '#4fc3f7', in: '#7ee081' };

  // ---------- 晶格 ----------
  function lattice(cr) {
    if (cr.hex) return [[cr.a, 0, 0], [-cr.a / 2, cr.a * S3 / 2, 0], [0, 0, cr.c]];
    return [[cr.a, 0, 0], [0, cr.a, 0], [0, 0, cr.a]];
  }
  function cart(L, f) {
    return [0, 1, 2].map(function (k) { return f[0] * L[0][k] + f[1] * L[1][k] + f[2] * L[2][k]; });
  }
  function dist(p, q) { var x = p[0] - q[0], y = p[1] - q[1], z = p[2] - q[2]; return Math.sqrt(x * x + y * y + z * z); }

  // 区域：立方 [0, n·a]³；六方为外接圆半径 n·a 的六棱柱（底面在 z = 0），高 c，扩展时 1.5c（四层）
  // 六棱柱侧面的外法线方向角 30° + 60°k，边心距 R·√3/2
  var HEXN = [0, 1, 2, 3, 4, 5].map(function (k) { var t = Math.PI / 6 + k * Math.PI / 3; return [Math.cos(t), Math.sin(t)]; });
  function region(cr, n) {
    if (cr.hex) return { hex: true, R: n * cr.a, H: (n > 1 ? 1.5 : 1) * cr.c, ap: n * cr.a * S3 / 2, tol: EPS * cr.a };
    return { hex: false, L: n * cr.a, tol: EPS * cr.a };
  }
  // 返回 null（在区域外）或 { h: 在几个侧面上, v: 是否在上下底面上 }（立方：k 为落在边界上的坐标个数）
  function where(rg, p) {
    var t = rg.tol;
    if (!rg.hex) {
      var k = 0;
      for (var i = 0; i < 3; i++) {
        if (p[i] < -t || p[i] > rg.L + t) return null;
        if (p[i] < t || p[i] > rg.L - t) k++;
      }
      return { k: k };
    }
    if (p[2] < -t || p[2] > rg.H + t) return null;
    var h = 0;
    for (var j = 0; j < 6; j++) {
      var d = p[0] * HEXN[j][0] + p[1] * HEXN[j][1] - rg.ap;
      if (d > t) return null;
      if (d > -t) h++;
    }
    return { h: h, v: p[2] < t || p[2] > rg.H - t };
  }
  // 均摊：被几个晶胞共用 → 计入的份额与位置类别
  function share(rg, w) {
    if (!rg.hex) {
      var n = [1, 2, 4, 8][w.k];
      return { n: n, w: 1 / n, pos: ['in', 'face', 'edge', 'vtx'][w.k] };
    }
    var nh = [1, 2, 3][w.h], nv = w.v ? 2 : 1, n2 = nh * nv;
    var pos = n2 === 1 ? 'in' : (w.h === 2 && w.v) ? 'vtx' : (w.h === 2 || (w.h === 1 && w.v)) ? 'edge' : 'face';
    return { n: n2, w: 1 / n2, pos: pos };
  }

  // 区域内的全部粒子（含边界上的）
  function atoms(cr, n) {
    n = n || 1;
    var L = lattice(cr), rg = region(cr, n), out = [];
    var m = cr.hex ? 2 * n + 1 : n;
    for (var i = -m; i <= m; i++) for (var j = -m; j <= m; j++) for (var k = -1; k <= n; k++) {
      if (!cr.hex && (i < -1 || j < -1)) continue;
      cr.basis.forEach(function (b) {
        var p = cart(L, [b.p[0] + i, b.p[1] + j, b.p[2] + k]);
        var w = where(rg, p);
        if (!w) return;
        var a = { sp: b.sp, p: p, dir: b.dir || null };
        if (n === 1) { var s = share(rg, w); a.share = s.n; a.w = s.w; a.pos = s.pos; }
        out.push(a);
      });
    }
    return out;
  }
  // 点 c 附近 rmax 以内的粒子（不受区域限制，用于配位与“晶胞外”的邻居）
  function around(cr, c, rmax) {
    var L = lattice(cr), out = [], m = Math.ceil(rmax / Math.min(cr.a, cr.c || cr.a)) + 2;
    var f0 = cr.hex ? [0, 0, 0] : [Math.floor(c[0] / cr.a), Math.floor(c[1] / cr.a), Math.floor(c[2] / cr.a)];
    if (cr.hex) { f0[2] = Math.floor(c[2] / cr.c); var fy = c[1] / (cr.a * S3 / 2); f0[1] = Math.floor(fy); f0[0] = Math.floor(c[0] / cr.a + f0[1] / 2); }
    for (var i = -m; i <= m; i++) for (var j = -m; j <= m; j++) for (var k = -m; k <= m; k++) {
      cr.basis.forEach(function (b) {
        var p = cart(L, [b.p[0] + f0[0] + i, b.p[1] + f0[1] + j, b.p[2] + f0[2] + k]);
        var d = dist(p, c);
        if (d <= rmax) out.push({ sp: b.sp, p: p, dir: b.dir || null, d: d });
      });
    }
    return out;
  }
  // 最近邻：mode 'cn' 配位（离子晶体等取最近的异种粒子）/ 'same' 最近的同种粒子
  function neighbors(cr, atom, mode) {
    var other = mode !== 'same' && cr.cnSp;
    var list = around(cr, atom.p, 1.25 * Math.max(cr.a, cr.c || 0)).filter(function (q) {
      if (q.d < 1) return false;
      return other ? q.sp !== atom.sp : q.sp === atom.sp;
    });
    var d0 = Infinity;
    list.forEach(function (q) { if (q.d < d0) d0 = q.d; });
    return { d: d0, list: list.filter(function (q) { return q.d < d0 * 1.01; }) };
  }

  // ---------- 均摊统计 ----------
  // 返回 { rows: [{sp, items: [{pos, n, w}], total}], z: 每个晶胞含几个“化学式单元”}
  function tally(cr) {
    var by = {};
    atoms(cr, 1).forEach(function (a) {
      var r = by[a.sp] || (by[a.sp] = {});
      var key = a.pos + '|' + a.share;
      r[key] = r[key] || { pos: a.pos, n: 0, w: a.w };
      r[key].n++;
    });
    var order = ['vtx', 'edge', 'face', 'in'];
    var rows = Object.keys(by).map(function (sp) {
      var items = Object.keys(by[sp]).map(function (k) { return by[sp][k]; });
      items.sort(function (x, y) { return order.indexOf(x.pos) - order.indexOf(y.pos) || x.w - y.w; });
      var tot = items.reduce(function (s, it) { return s + it.n * it.w; }, 0);
      return { sp: sp, items: items, total: Math.round(tot * 1000) / 1000 };
    });
    var spOrder = cr.basis.map(function (b) { return b.sp; });
    rows.sort(function (x, y) { return spOrder.indexOf(x.sp) - spOrder.indexOf(y.sp); });
    return rows;
  }
  // 每个晶胞中化学式单元数（取各粒子数的最大公约数）
  function units(cr) {
    var t = tally(cr).map(function (r) { return Math.round(r.total); });
    return t.reduce(gcd);
  }
  function gcd(a, b) { while (b) { var t = a % b; a = b; b = t; } return a; }
  function fracText(w) { return w === 1 ? '1' : '1/' + Math.round(1 / w); }
  function cellVolume(cr) { return cr.hex ? 1.5 * S3 * cr.a * cr.a * cr.c : cr.a * cr.a * cr.a; } // pm³（六棱柱 = 3 个平行六面体）
  function density(cr) { // Z：每个晶胞含几个化学式单元；ρ 单位 g/cm³
    var Z = units(cr);
    return { Z: Z, rho: Z * cr.M / (NA * cellVolume(cr) * 1e-30) };
  }
  // 金属：原子半径与空间利用率
  function packing(cr) {
    var d = neighbors(cr, { sp: cr.basis[0].sp, p: [0, 0, 0] }, 'cn').d, r = d / 2;
    var N = tally(cr)[0].total;
    return { r: r, phi: N * 4 / 3 * Math.PI * r * r * r / cellVolume(cr) };
  }
  // 堆积模型中各粒子半径：单一粒子取最近距离的一半；有多种粒子时按给定半径等比缩放到最近的异种粒子恰好相切
  function radii(cr) {
    var sps = [], out = {};
    cr.basis.forEach(function (b) { if (sps.indexOf(b.sp) < 0) sps.push(b.sp); });
    var a0 = { sp: sps[0], p: cart(lattice(cr), cr.basis[0].p) };
    var nb = neighbors(cr, a0, 'cn');
    if (sps.length === 1) {
      out[sps[0]] = SP[sps[0]].mol ? nb.d * 0.3 : nb.d / 2;
    } else {
      var k = nb.d / (SP[sps[0]].r + SP[nb.list[0].sp].r);
      sps.forEach(function (s) { out[s] = SP[s].r * k; });
    }
    return out;
  }
  // 每种粒子的配位数与最近距离
  function coordination(cr) {
    var L = lattice(cr), seen = {}, out = [];
    cr.basis.forEach(function (b) {
      if (seen[b.sp]) return;
      seen[b.sp] = 1;
      var a = { sp: b.sp, p: cart(L, b.p) };
      var n1 = neighbors(cr, a, 'cn'), n2 = neighbors(cr, a, 'same');
      out.push({ sp: b.sp, cn: n1.list.length, of: n1.list[0].sp, d: n1.d, same: n2.list.length, dSame: n2.d });
    });
    return out;
  }
  // 画键的粒子对
  function bondPairs(cr, list) {
    var out = [];
    cr.bonds.forEach(function (bd) {
      var d0 = bd[2] || neighbors(cr, { sp: bd[0], p: cart(lattice(cr), cr.basis.filter(function (b) { return b.sp === bd[0]; })[0].p) }, 'cn').d;
      for (var i = 0; i < list.length; i++) for (var j = i + 1; j < list.length; j++) {
        var a = list[i], b = list[j];
        if (!((a.sp === bd[0] && b.sp === bd[1]) || (a.sp === bd[1] && b.sp === bd[0]))) continue;
        if (Math.abs(dist(a.p, b.p) - d0) < d0 * 0.02) out.push([i, j]);
      }
    });
    return out;
  }

  // ---------- 自定义晶胞（练习：由位置推化学式） ----------
  var SITES = { vtx: [[0, 0, 0]], edge: [[0.5, 0, 0], [0, 0.5, 0], [0, 0, 0.5]], face: [[0.5, 0.5, 0], [0.5, 0, 0.5], [0, 0.5, 0.5]], in: [[0.5, 0.5, 0.5]] };
  var PER = { vtx: 1, edge: 3, face: 3, in: 1 }, RAW = { vtx: 8, edge: 12, face: 6, in: 1 };
  function custom(assign) { // assign：{ vtx: 'A', face: 'B', … }
    var basis = [];
    Object.keys(assign).forEach(function (pos) { SITES[pos].forEach(function (p) { basis.push({ sp: assign[pos], p: p }); }); });
    return { name: '某晶体', formula: '', kind: 'quiz', a: 500, M: 0, basis: basis, bonds: [], cnSp: true, unit: '' };
  }
  var SUB = '₀₁₂₃₄₅₆₇₈₉';
  function sub(n) { return n === 1 ? '' : String(n).split('').map(function (d) { return SUB[+d]; }).join(''); }
  function formulaOf(counts, names) { // counts 与 names 同序
    var g = counts.reduce(gcd);
    return names.map(function (nm, i) { return nm + sub(counts[i] / g); }).join('');
  }

  // ---------- 练习 ----------
  var TYPES = ['count', 'formula', 'cn', 'fact'];
  function pick(rnd, arr) { return arr[Math.floor(rnd() * arr.length)]; }
  function shuffle(rnd, arr) {
    for (var i = arr.length - 1; i > 0; i--) { var j = Math.floor(rnd() * (i + 1)), t = arr[i]; arr[i] = arr[j]; arr[j] = t; }
    return arr;
  }
  function numOpts(rnd, ans, pool) {
    var o = [ans];
    shuffle(rnd, pool.slice()).forEach(function (v) { if (o.length < 4 && o.indexOf(v) < 0) o.push(v); });
    return shuffle(rnd, o).map(String);
  }
  var FACTS = [
    { x: 'diamond', q: '金刚石晶体中，最小的碳环由几个碳原子构成？', a: '6', o: ['4', '6', '8', '12'], e: '金刚石中最小的碳环是六元环，六个碳原子不在同一平面上（椅式）。每个 C 原子被 12 个六元环共用。', ext: 2 },
    { x: 'diamond', q: '1 mol 金刚石中含有 C–C 键的物质的量是多少？', a: '2 mol', o: ['1 mol', '1.5 mol', '2 mol', '4 mol'], e: '每个 C 原子形成 4 个 C–C 键，每个键被 2 个 C 原子共用，平均每个 C 原子占 4×1/2 = 2 个键。' },
    { x: 'graphite', q: '石墨晶体的层内，每个六元环平均含有几个碳原子？', a: '2', o: ['2', '3', '4', '6'], e: '层内每个 C 原子被 3 个六元环共用，每个六元环平均含 6×1/3 = 2 个 C 原子。', ext: 2 },
    { x: 'graphite', q: '1 mol 石墨中含有 C–C 键的物质的量是多少？', a: '1.5 mol', o: ['1 mol', '1.5 mol', '2 mol', '3 mol'], e: '层内每个 C 原子形成 3 个 C–C 键，每个键被 2 个原子共用，平均每个 C 原子占 3×1/2 = 1.5 个键。' },
    { x: 'sio2', q: 'SiO₂ 晶体中，最小的环由几个原子构成？', a: '12', o: ['6', '8', '10', '12'], e: '把金刚石中的 C 换成 Si，再在每两个 Si 之间插入一个 O：最小环由 6 个 Si 和 6 个 O 构成，是十二元环。', ext: 2 },
    { x: 'sio2', q: '1 mol SiO₂ 晶体中含有 Si–O 键的物质的量是多少？', a: '4 mol', o: ['2 mol', '4 mol', '6 mol', '8 mol'], e: '每个 Si 原子形成 4 个 Si–O 键，O 原子不再另算：1 mol SiO₂ 含 1 mol Si，即 4 mol Si–O 键。' },
    { x: 'cu', q: '面心立方最密堆积的空间利用率约为多少？', a: '74%', o: ['52%', '68%', '74%', '80%'], e: '面心立方晶胞含 4 个原子，4r = √2a，空间利用率 = 4×(4/3)πr³ / a³ = √2π/6 ≈ 74%，与六方最密堆积相同。' },
    { x: 'na', q: '体心立方堆积的空间利用率约为多少？', a: '68%', o: ['52%', '68%', '74%', '80%'], e: '体心立方晶胞含 2 个原子，4r = √3a，空间利用率 = 2×(4/3)πr³ / a³ = √3π/8 ≈ 68%。' },
    { x: 'graphite', q: '石墨层与层之间的作用力是什么？', a: '范德华力', o: ['共价键', '离子键', '金属键', '范德华力'], e: '石墨层内是共价键（还有离域的 π 电子），层与层之间是范德华力，层间距 335 pm 远大于层内 C–C 键长 142 pm。' },
    { x: 'co2', q: '干冰晶体中，每个 CO₂ 分子周围紧邻的 CO₂ 分子有几个？', a: '12', o: ['4', '6', '8', '12'], e: 'CO₂ 分子按面心立方排列：以顶点上的分子为例，与它距离最近的是相邻三个面的面心分子，每个顶点被 8 个晶胞共用，共 3×8/2 = 12 个。', ext: 2 },
    { x: 'mg', q: '镁的六方最密堆积晶胞（六棱柱）中含有几个原子？', a: '6', o: ['2', '4', '6', '17'], e: '12 个顶点各计 1/6，上下底面心各计 1/2，中间层 3 个原子完全在柱内：12×1/6 + 2×1/2 + 3 = 6。' }
  ];
  var KIND_OPTS = ['离子晶体', '共价晶体', '分子晶体', '金属晶体', '混合型晶体'];

  function quiz(rnd, prev, only) {
    rnd = rnd || Math.random;
    var q, tries = 0;
    do {
      var type = only && TYPES.indexOf(only) >= 0 ? only : pick(rnd, TYPES);
      q = make[type](rnd);
      q.type = type;
    } while (prev && q.prompt === prev.prompt && ++tries < 10);
    return q;
  }
  var make = {
    // 晶胞中某种粒子的个数（均摊）
    count: function (rnd) {
      var id = pick(rnd, ['nacl', 'cscl', 'caf2', 'zns', 'diamond', 'co2', 'na', 'cu', 'mg', 'sio2']);
      var cr = CRYSTALS[id], rows = tally(cr), r = pick(rnd, rows);
      var sp = SP[r.sp], ans = r.total;
      var raw = r.items.reduce(function (s, it) { return s + it.n; }, 0);
      return { x: id, cut: false, prompt: '图中是' + cr.name + '的晶胞' + (cr.hex ? '（六棱柱）' : '') + '，平均每个晶胞含有几个 ' + sp.f + '？',
        answer: String(ans), options: numOpts(rnd, ans, [1, 2, 3, 4, 6, 8, 12, 14, raw].filter(function (v) { return v !== ans; })),
        explain: '用均摊法：' + r.items.map(function (it) { return POS[it.pos] + ' ' + it.n + ' 个 × ' + fracText(it.w); }).join(' + ') + ' = ' + ans + '。' };
    },
    // 由位置推化学式
    formula: function (rnd) {
      var nsp = rnd() < 0.5 ? 2 : 3, names = ['A', 'B', 'X'].slice(0, nsp), shown = ['A', 'B', 'C'];
      var pos, assign, counts, f, tries = 0;
      do {
        pos = shuffle(rnd, ['vtx', 'edge', 'face', 'in']).slice(0, nsp);
        assign = {}; pos.forEach(function (p, i) { assign[p] = names[i]; });
        counts = pos.map(function (p) { return PER[p]; });
        f = formulaOf(counts, shown.slice(0, nsp));
      } while (counts.every(function (c) { return c === counts[0]; }) && ++tries < 20);
      var wrong = [
        pos.map(function (p) { return RAW[p]; }),
        pos.map(function (p) { return { vtx: 1, edge: 6, face: 3, in: 1 }[p]; }),
        pos.map(function (p) { return { vtx: 1, edge: 3, face: 6, in: 1 }[p]; }),
        pos.map(function (p) { return { vtx: 2, edge: 3, face: 3, in: 1 }[p]; }),
        counts.slice().reverse()
      ];
      var opts = [f];
      wrong.forEach(function (c) { var g = formulaOf(c, shown.slice(0, nsp)); if (opts.length < 4 && opts.indexOf(g) < 0) opts.push(g); });
      var cr = custom(assign);
      return { x: null, custom: cr, prompt: '某晶体的晶胞如图，' + pos.map(function (p, i) { return shown[i] + ' 位于' + { vtx: '顶点', edge: '棱心', face: '面心', in: '体心' }[p]; }).join('，') + '。它的化学式是？',
        answer: f, options: shuffle(rnd, opts),
        explain: pos.map(function (p, i) { return shown[i] + '：' + RAW[p] + ' × ' + fracText(PER[p] / RAW[p]) + ' = ' + PER[p]; }).join('；') + '，个数比 ' + counts.join('∶') + '，化学式为 ' + f + '。' };
    },
    // 配位数 / 最近的同种粒子
    cn: function (rnd) {
      var id = pick(rnd, ['nacl', 'cscl', 'caf2', 'zns', 'diamond', 'co2', 'po', 'na', 'cu', 'mg', 'sio2']);
      var cr = CRYSTALS[id], co = pick(rnd, coordination(cr));
      var same = cr.cnSp && rnd() < 0.4, n = same ? co.same : co.cn, sp = SP[co.sp], of = SP[same ? co.sp : co.of];
      var prompt = cr.cnSp ? '在' + cr.name + '晶体中，每个 ' + sp.f + ' 周围距离最近且相等的 ' + of.f + ' 有几个？'
        : '在' + cr.name + '晶体中，每个' + (sp.mol ? ' CO₂ 分子周围紧邻的 CO₂ 分子' : '原子周围距离最近的原子') + '有几个？';
      return { x: id, sel: co.sp, mode: same ? 'same' : 'cn', prompt: prompt, answer: String(n),
        options: numOpts(rnd, n, [2, 3, 4, 6, 8, 12].filter(function (v) { return v !== n; })),
        explain: (same ? '最近的同种粒子相距 ' + Math.round(co.dSame) + ' pm，共 ' + n + ' 个。' : '配位数 ' + n + '，相距 ' + Math.round(co.d) + ' pm。')
          + (cr.facts[same || cr.kind === 'metal' || cr.kind === 'mol' ? 1 : 0] || '') + '。点“在模型里看”可以选中一个粒子数一数。' };
    },
    fact: function (rnd) {
      if (rnd() < 0.3) {
        var id = pick(rnd, Object.keys(CRYSTALS)), cr = CRYSTALS[id], k = KIND[cr.kind];
        var o = [k]; shuffle(rnd, KIND_OPTS.slice()).forEach(function (v) { if (o.length < 4 && o.indexOf(v) < 0) o.push(v); });
        var why = { ion: '由阴、阳离子通过离子键结合而成', cov: '原子间以共价键结合成三维骨架结构，没有单个分子', mol: '由分子通过分子间作用力结合而成', metal: '由金属阳离子和自由电子通过金属键结合而成', mix: '层内是共价键，层间是范德华力，还有离域电子' }[cr.kind];
        return { x: id, prompt: cr.name + '（' + cr.formula + '）属于哪一类晶体？', answer: k, options: shuffle(rnd, o), explain: cr.name + why + '，属于' + k + '。' };
      }
      var f = pick(rnd, FACTS);
      return { x: f.x, ext: f.ext || 1, prompt: f.q, answer: f.a, options: f.o.slice(), explain: f.e };
    }
  };

  window.Crystal = {
    NA: NA, SP: SP, CRYSTALS: CRYSTALS, GROUPS: GROUPS, KIND: KIND, POS: POS, POS_COL: POS_COL, TYPES: TYPES,
    lattice: lattice, cart: cart, dist: dist, region: region, atoms: atoms, around: around, neighbors: neighbors,
    tally: tally, units: units, fracText: fracText, cellVolume: cellVolume, density: density, packing: packing,
    radii: radii, coordination: coordination, bondPairs: bondPairs, custom: custom, formulaOf: formulaOf, quiz: quiz
  };
})();
