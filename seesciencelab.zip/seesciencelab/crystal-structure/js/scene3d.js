// 晶体结构：three.js 场景（粒子、化学键、晶胞边框、均摊切割、配位与共用晶胞）
// 晶体坐标 (x, y, z)（pm，六方 z 为 c 轴）→ three 坐标 (x, z, −y)·S，再减去显示区域中心
(function () {
  var C = window.Crystal;
  var V3 = THREE.Vector3;
  var BOND_COL = 0x8d99ab, GOLD = 0xffc94a;
  var CO = 116;                 // C=O 键长 pm
  var MOL_R = { ball: { C: 42, O: 38 }, fill: { C: 105, O: 98 } };

  window.CrystalScene = function (container) {
    var renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.localClippingEnabled = true;
    container.appendChild(renderer.domElement);
    var canvas = renderer.domElement;
    canvas.id = 'view3d';

    var labelRenderer = new THREE.CSS2DRenderer();
    var ls = labelRenderer.domElement.style;
    ls.position = 'absolute'; ls.top = '0'; ls.left = '0'; ls.pointerEvents = 'none'; ls.zIndex = '2';
    container.appendChild(labelRenderer.domElement);

    var scene = new THREE.Scene();
    scene.background = new THREE.Color('#05070d');
    var camera = new THREE.PerspectiveCamera(32, 1, 0.1, 500);
    scene.add(camera);
    scene.add(new THREE.AmbientLight(0xffffff, 0.42));
    var key = new THREE.DirectionalLight(0xffffff, 0.85);
    key.position.set(-4, 6, 8);
    camera.add(key);
    var rim = new THREE.DirectionalLight(0x9fc8ff, 0.25);
    rim.position.set(6, -3, -4);
    camera.add(rim);

    var controls = new THREE.OrbitControls(camera, canvas);
    controls.enableDamping = true;
    controls.dampingFactor = 0.08;
    controls.enablePan = false;
    controls.minDistance = 8;
    controls.maxDistance = 120;
    controls.autoRotateSpeed = 0.7;
    var spinStopped = false;
    controls.addEventListener('start', function () { controls.autoRotate = false; spinStopped = true; });

    var root = new THREE.Group();
    scene.add(root);
    var sphere = new THREE.SphereGeometry(1, 28, 20);
    var cyl = new THREE.CylinderGeometry(1, 1, 1, 12, 1, true);

    // ---------- 材质缓存 ----------
    var mats = {};
    function mat(col, o) {
      o = o || {};
      var k = col + '|' + (o.clip ? 1 : 0) + '|' + (o.back ? 1 : 0) + '|' + (o.op || 1) + '|' + (o.em || 0);
      if (mats[k]) return mats[k];
      var c = new THREE.Color(col), m;
      if (o.back) m = new THREE.MeshBasicMaterial({ color: c.clone().multiplyScalar(0.55), side: THREE.BackSide });
      else m = new THREE.MeshStandardMaterial({ color: c, roughness: 0.55, metalness: 0.05 });
      if (o.em) { m.emissive = new THREE.Color(o.em === 2 ? GOLD : col); m.emissiveIntensity = o.em === 2 ? 0.55 : 0.35; }
      if (o.op && o.op < 1) { m.transparent = true; m.opacity = o.op; m.depthWrite = false; }
      if (o.clip) m.clippingPlanes = clipPlanes;
      return (mats[k] = m);
    }
    var clipPlanes = [];

    // ---------- 坐标 ----------
    var S = 1, ctr = [0, 0, 0];
    function tp(p) { return new V3((p[0] - ctr[0]) * S, (p[2] - ctr[2]) * S, -(p[1] - ctr[1]) * S); }
    function tdir(d) { return new V3(d[0], d[2], -d[1]).normalize(); }

    function clear(g) {
      for (var i = g.children.length - 1; i >= 0; i--) {
        var o = g.children[i];
        if (o.children && o.children.length) clear(o);
        if (o.isCSS2DObject && o.element.parentNode) o.element.parentNode.removeChild(o.element);
        if (o.geometry && o.geometry !== sphere && o.geometry !== cyl) o.geometry.dispose();
        g.remove(o);
      }
    }
    function ball(g, p, r, m) {
      var s = new THREE.Mesh(sphere, m);
      s.position.copy(p); s.scale.setScalar(r);
      g.add(s);
      return s;
    }
    function stick(g, a, b, r, m) {
      var d = b.clone().sub(a), len = d.length();
      var s = new THREE.Mesh(cyl, m);
      s.position.copy(a).addScaledVector(d, 0.5);
      s.scale.set(r, len, r);
      s.quaternion.setFromUnitVectors(new V3(0, 1, 0), d.normalize());
      g.add(s);
      return s;
    }
    function lines(g, segs, col, op, dashed) {
      var pos = [];
      segs.forEach(function (s) { pos.push(s[0].x, s[0].y, s[0].z, s[1].x, s[1].y, s[1].z); });
      var geo = new THREE.BufferGeometry();
      geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
      var m = dashed ? new THREE.LineDashedMaterial({ color: col, dashSize: 0.18, gapSize: 0.12, transparent: true, opacity: op })
        : new THREE.LineBasicMaterial({ color: col, transparent: op < 1, opacity: op });
      var l = new THREE.LineSegments(geo, m);
      if (dashed) l.computeLineDistances();
      g.add(l);
      return l;
    }
    function label(g, html, cls, p) {
      var el = document.createElement('div');
      el.className = 'lab ' + (cls || '');
      el.innerHTML = html;
      var o = new THREE.CSS2DObject(el);
      o.position.copy(p);
      g.add(o);
      return o;
    }

    // ---------- 晶胞边框 ----------
    // 立方：n×n×n 个晶胞的棱（第一个晶胞亮、其余暗）；六方：六棱柱
    function hexPts(R, z) {
      var out = [];
      for (var k = 0; k < 6; k++) out.push([R * Math.cos(k * Math.PI / 3), R * Math.sin(k * Math.PI / 3), z]);
      return out;
    }
    function cubeSegs(o, a) {
      var segs = [], c = [];
      for (var i = 0; i < 8; i++) c.push([o[0] + (i & 1) * a, o[1] + (i >> 1 & 1) * a, o[2] + (i >> 2 & 1) * a]);
      [[0, 1], [2, 3], [4, 5], [6, 7], [0, 2], [1, 3], [4, 6], [5, 7], [0, 4], [1, 5], [2, 6], [3, 7]].forEach(function (e) { segs.push([tp(c[e[0]]), tp(c[e[1]])]); });
      return segs;
    }
    function prismSegs(R, H) {
      var b = hexPts(R, 0), t = hexPts(R, H), segs = [];
      for (var k = 0; k < 6; k++) {
        var k2 = (k + 1) % 6;
        segs.push([tp(b[k]), tp(b[k2])], [tp(t[k]), tp(t[k2])], [tp(b[k]), tp(t[k])]);
      }
      return segs;
    }
    function frame(g, cr, n) {
      if (cr.hex) {
        lines(g, prismSegs(cr.a, cr.c), 0xe6ebf2, 0.85);
        if (n > 1) { var rg = C.region(cr, n); lines(g, prismSegs(rg.R, rg.H), 0x8d99ab, 0.3); }
        return;
      }
      for (var i = 0; i < n; i++) for (var j = 0; j < n; j++) for (var k = 0; k < n; k++) {
        if (i + j + k) lines(g, cubeSegs([i * cr.a, j * cr.a, k * cr.a], cr.a), 0x8d99ab, 0.28);
      }
      lines(g, cubeSegs([0, 0, 0], cr.a), 0xe6ebf2, 0.85);
    }
    // 均摊切割用的裁剪面（法线朝晶胞内）
    function makeClip(cr) {
      var P = THREE.Plane;
      clipPlanes.length = 0;
      if (cr.hex) {
        var ap = cr.a * Math.sqrt(3) / 2 * S;
        for (var k = 0; k < 6; k++) {
          var t = Math.PI / 6 + k * Math.PI / 3;
          clipPlanes.push(new P(new V3(-Math.cos(t), 0, Math.sin(t)), ap));
        }
        var y0 = (0 - ctr[2]) * S, y1 = (cr.c - ctr[2]) * S;
        clipPlanes.push(new P(new V3(0, 1, 0), -y0), new P(new V3(0, -1, 0), y1));
      } else {
        var lo = tp([0, 0, 0]), hi = tp([cr.a, cr.a, cr.a]);
        clipPlanes.push(new P(new V3(1, 0, 0), -lo.x), new P(new V3(-1, 0, 0), hi.x),
          new P(new V3(0, 1, 0), -lo.y), new P(new V3(0, -1, 0), hi.y),
          new P(new V3(0, 0, -1), lo.z), new P(new V3(0, 0, 1), -hi.z));
      }
    }

    // ---------- 粒子 ----------
    function drawAtom(g, a, v, o) {
      var sp = C.SP[a.sp], col = o.col || sp.col, p = tp(a.p);
      var m = mat(col, { clip: o.clip, op: o.op, em: o.em });
      var holder = new THREE.Group();
      holder.position.copy(p);
      g.add(holder);
      if (sp.mol) {
        var R = MOL_R[v.model], d = tdir(a.dir), off = d.clone().multiplyScalar(CO * S);
        var mc = mat(o.col || '#a9b4c2', { clip: o.clip, op: o.op, em: o.em }), mo = mat(o.col || '#ff6b6b', { clip: o.clip, op: o.op, em: o.em });
        ball(holder, new V3(), R.C * S, mc);
        ball(holder, off, R.O * S, mo);
        ball(holder, off.clone().negate(), R.O * S, mo);
        if (v.model === 'ball') stick(holder, off.clone().negate(), off, 14 * S, mat('#cfd6e0', { op: o.op }));
        if (o.clip) {
          ball(holder, new V3(), R.C * S, mat(o.col || '#a9b4c2', { clip: 1, back: 1 }));
          ball(holder, off, R.O * S, mat(o.col || '#ff6b6b', { clip: 1, back: 1 }));
          ball(holder, off.clone().negate(), R.O * S, mat(o.col || '#ff6b6b', { clip: 1, back: 1 }));
        }
      } else {
        var r = v.radii[a.sp] * (v.model === 'ball' ? (v.cut ? 0.45 : 0.3) : 1) * S;
        ball(holder, new V3(), r, m);
        if (o.clip) ball(holder, new V3(), r, mat(col, { clip: 1, back: 1 }));
      }
      return holder;
    }

    // ---------- 构建 ----------
    var sig = '', camSig = '', list = [], view = null, info = null;
    var gAtoms = new THREE.Group(), gBonds = new THREE.Group(), gFrame = new THREE.Group(), gSel = new THREE.Group(), gLab = new THREE.Group();
    [gAtoms, gBonds, gFrame, gSel, gLab].forEach(function (g) { root.add(g); });

    // v：{ cr, ext, model 'ball'|'fill', cut, color 'sp'|'site', hide {sp: 1}, bonds, sel: { i, mode 'cn'|'same'|'info' } | null, labels }
    function update(v) {
      var s = JSON.stringify([v.cr.name, v.cr.basis.length, v.cr.basis[0].sp, v.ext, v.model, v.cut, v.color, v.hide, v.bonds, v.sel, v.labels, v.cr.custom || '']);
      if (s === sig) return info;
      sig = s; view = v;
      var cr = v.cr, n = v.cut ? 1 : v.ext;
      v.radii = C.radii(cr);
      // 比例与中心：以一个晶胞约 10 个单位
      S = 10 / (cr.hex ? Math.max(2 * cr.a, cr.c) : cr.a);
      ctr = cr.hex ? [0, 0, C.region(cr, n).H / 2] : [n * cr.a / 2, n * cr.a / 2, n * cr.a / 2];
      var cs = cr.name + cr.basis.length + cr.basis[0].sp + '|' + n + '|' + v.model;
      if (cs !== camSig) { camSig = cs; homeCamera(cr, n, v); }
      [gAtoms, gBonds, gFrame, gSel, gLab].forEach(clear);
      if (v.cut) makeClip(cr);

      list = C.atoms(cr, n);
      var sel = v.sel && list[v.sel.i] ? v.sel : null, nb = null, hit = {};
      if (sel && sel.mode !== 'info') {
        nb = C.neighbors(cr, list[sel.i], sel.mode);
        nb.list.forEach(function (q) {
          q.k = -1;
          for (var j = 0; j < list.length; j++) if (C.dist(list[j].p, q.p) < 1) { q.k = j; hit[j] = 1; break; }
        });
      }
      // 粒子
      list.forEach(function (a, i) {
        if (v.hide[a.sp]) return;
        var o = { clip: v.cut };
        if (v.color === 'site' && a.pos) o.col = C.POS_COL[a.pos];
        if (sel) {
          if (i === sel.i) o.em = 2;
          else if (hit[i]) o.em = 1;
          else o.op = 0.18;
        }
        var h = drawAtom(gAtoms, a, v, o);
        h.userData.i = i;
      });
      // 化学键
      if (v.bonds && v.model === 'ball' && !v.cut && cr.bonds.length) {
        var pairs = C.bondPairs(cr, list), ion = cr.kind === 'ion';
        var segs = [];
        pairs.forEach(function (pr) {
          var a = list[pr[0]], b = list[pr[1]];
          if (v.hide[a.sp] || v.hide[b.sp]) return;
          var faded = sel && !((pr[0] === sel.i && hit[pr[1]]) || (pr[1] === sel.i && hit[pr[0]]));
          if (ion) segs.push([tp(a.p), tp(b.p)]);
          else stick(gBonds, tp(a.p), tp(b.p), (cr.kind === 'mix' ? 11 : 13) * S * (cr.hex ? 1 : 1), mat('#9aa6b8', { op: faded ? 0.15 : 1 }));
        });
        if (segs.length) lines(gBonds, segs, BOND_COL, sel ? 0.12 : 0.55);
      }
      // 石墨：层间范德华力（虚线）
      if (cr.kind === 'mix' && !v.cut && v.model === 'ball') {
        var vdw = [];
        list.forEach(function (a) {
          list.forEach(function (b) {
            if (b.p[2] - a.p[2] > cr.c / 2 - 1 && b.p[2] - a.p[2] < cr.c / 2 + 1 && Math.abs(a.p[0] - b.p[0]) < 1 && Math.abs(a.p[1] - b.p[1]) < 1) vdw.push([tp(a.p), tp(b.p)]);
          });
        });
        if (vdw.length) lines(gBonds, vdw, 0x4fc3f7, sel ? 0.1 : 0.45, true);
      }
      frame(gFrame, cr, n);
      if (v.cut) addFaces(cr);

      info = { list: list, nb: nb };
      if (sel) drawSel(cr, list[sel.i], sel, nb, v);
      else if (v.cut && v.labels) shareLabels(cr);
      return info;
    }
    // 均摊模式下晶胞的半透明面
    function addFaces(cr) {
      var geo;
      if (cr.hex) geo = new THREE.CylinderGeometry(cr.a * S, cr.a * S, cr.c * S, 6, 1);
      else geo = new THREE.BoxGeometry(cr.a * S, cr.a * S, cr.a * S);
      var m = new THREE.Mesh(geo, new THREE.MeshBasicMaterial({ color: 0x4fc3f7, transparent: true, opacity: 0.05, depthWrite: false, side: THREE.DoubleSide }));
      if (cr.hex) m.rotation.y = Math.PI / 2;   // 圆柱的第一个顶点在 +z，转到 +x 与六棱柱对齐
      gFrame.add(m);
    }
    // 每类位置挑一个最靠近观察者的粒子标注份额
    function shareLabels(cr) {
      var best = {}, eye = camera.position.clone().normalize();
      list.forEach(function (a) {
        if (view.hide[a.sp]) return;
        var k = a.pos + a.share, sc = tp(a.p).dot(eye);
        if (!best[k] || sc > best[k].sc) best[k] = { a: a, sc: sc };
      });
      Object.keys(best).forEach(function (k) {
        var a = best[k].a;
        label(gLab, C.POS[a.pos] + ' <b>×' + C.fracText(a.w) + '</b>', 'share', tp(a.p).add(new V3(0, 0.55, 0)));
      });
    }
    // 选中的粒子：配位多面体 / 共用它的晶胞
    function drawSel(cr, a, sel, nb, v) {
      var c = tp(a.p);
      if (nb) {
        var segs = [], poly = [], pts = nb.list.map(function (q) { return q; });
        pts.forEach(function (q) {
          segs.push([c, tp(q.p)]);
          if (q.k < 0) drawAtom(gSel, q, v, { op: 0.42, em: 1 });
        });
        lines(gSel, segs, GOLD, 0.9, true);
        // 多面体的棱：邻居之间距离最短的一对对
        var dmin = Infinity;
        for (var i = 0; i < pts.length; i++) for (var j = i + 1; j < pts.length; j++) dmin = Math.min(dmin, C.dist(pts[i].p, pts[j].p));
        if (pts.length >= 3) {
          for (i = 0; i < pts.length; i++) for (j = i + 1; j < pts.length; j++) {
            if (C.dist(pts[i].p, pts[j].p) < dmin * 1.01) poly.push([tp(pts[i].p), tp(pts[j].p)]);
          }
          lines(gSel, poly, GOLD, 0.5);
        }
        label(gLab, '<b>' + nb.list.length + '</b> 个', 'sel', c.clone().add(new V3(0, 1.1, 0)));
      } else if (a.share) {
        // 共用这个粒子的晶胞（立方：在边界上的坐标各取两侧）
        if (!cr.hex && a.share > 1) {
          var opts = a.p.map(function (x) { var r = Math.round(x / cr.a); return Math.abs(x - r * cr.a) < 1 ? [(r - 1) * cr.a, r * cr.a] : [0]; });
          var segs2 = [];
          opts[0].forEach(function (x) { opts[1].forEach(function (y) { opts[2].forEach(function (z) {
            if (x || y || z) segs2 = segs2.concat(cubeSegs([x, y, z], cr.a));
          }); }); });
          lines(gSel, segs2, GOLD, 0.45, true);
        }
        label(gLab, a.share === 1 ? '体内：计 <b>1</b>' : C.POS[a.pos] + '：' + a.share + ' 个晶胞共用，计 <b>' + C.fracText(a.w) + '</b>', 'sel', c.clone().add(new V3(0, 1.1, 0)));
      }
    }

    // ---------- 相机 ----------
    var anim = null;
    function homeCamera(cr, n, v) {
      var rg = C.region(cr, n), rmax = 0;
      Object.keys(v.radii).forEach(function (k) { rmax = Math.max(rmax, v.radii[k] * (v.model === 'ball' ? 0.3 : 1)); });
      var size = ((cr.hex ? Math.max(2 * rg.R * 0.9, rg.H * 1.25) : n * cr.a * 1.55) + 2 * rmax) * S;
      var aspect = Math.max(0.45, Math.min(1, camera.aspect || 1));
      var dist = size / (2 * Math.tan(camera.fov * Math.PI / 360)) * 1.35 / aspect;
      var dir = cr.hex ? new V3(0.9, 0.85, 1.5) : new V3(1.05, 0.72, 1.45);
      controls.target.set(0, 0, 0);
      camera.position.copy(dir.normalize().multiplyScalar(dist));
      controls.update();
    }
    function home() { if (view) homeCamera(view.cr, view.cut ? 1 : view.ext, view); }

    var raycaster = new THREE.Raycaster(), ndc = new THREE.Vector2();
    function pick(clientX, clientY) {
      var r = canvas.getBoundingClientRect();
      ndc.set((clientX - r.left) / r.width * 2 - 1, -(clientY - r.top) / r.height * 2 + 1);
      raycaster.setFromCamera(ndc, camera);
      var hits = raycaster.intersectObjects(gAtoms.children, true);
      for (var h = 0; h < hits.length; h++) {
        var o = hits[h].object;
        if (o.material && o.material.opacity < 0.3) continue;   // 被淡化的粒子不参与点选
        if (view.cut && clipPlanes.some(function (pl) { return pl.distanceToPoint(hits[h].point) < -1e-3; })) continue;
        while (o && o.userData.i == null) o = o.parent;
        if (o) return o.userData.i;
      }
      return -1;
    }

    function resize(w, h) {
      camera.aspect = w / Math.max(1, h);
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
      labelRenderer.setSize(w, h);
    }
    function render() {
      controls.update();
      renderer.render(scene, camera);
      labelRenderer.render(scene, camera);
    }
    function spin(on) { controls.autoRotate = !!on && !spinStopped; }

    return { update: update, render: render, resize: resize, pick: pick, home: home, spin: spin, canvas: canvas,
      getList: function () { return list; }, camera: camera, controls: controls };
  };
})();
