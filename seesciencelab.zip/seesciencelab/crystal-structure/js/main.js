(function () {
  var C = window.Crystal;
  var $ = function (id) { return document.getElementById(id); };
  var qa = function (sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); };
  var NAME = '晶体结构';

  var state = {
    scene: 'cell', x: 'nacl', model: 'ball', ext: 1, cut: false, color: 'sp', bonds: true, labels: true, spin: true,
    hide: {}, nn: 'cn', sel: null,
    quiz: null, quizOnly: null, answered: false, correct: false, choice: null, score: { n: 0, ok: 0 }
  };
  var HINTS = {
    cell: '拖动旋转、滚轮缩放；点一个粒子看它的配位或被几个晶胞共用',
    quiz: '晶体结构 · 判断练习（可拖动旋转晶胞）'
  };

  var stage = $('stage'), panel = $('panel');
  var sc3 = null;
  try { sc3 = window.CrystalScene(stage); } catch (e) { sc3 = null; }
  if (!sc3) {
    $('hint').textContent = '此浏览器不支持 WebGL，无法显示 3D 晶胞；面板中的均摊计算和练习仍可使用';
  }
  function setSeg(attr, val) { qa('[data-' + attr + ']').forEach(function (b) { b.classList.toggle('on', b.dataset[attr] === String(val)); }); }
  function cr() { return C.CRYSTALS[state.x]; }

  // ---------- 晶体选择 ----------
  (function buildPicker() {
    var html = '';
    C.GROUPS.forEach(function (g) {
      html += '<h3>' + g.name + '</h3><div class="presets xs">';
      g.list.forEach(function (id) {
        var c = C.CRYSTALS[id];
        html += '<button data-x="' + id + '"><b>' + c.name.replace(/（.*）/, '') + '</b><small>' + (c.pack ? c.pack.replace('堆积', '') : c.formula) + '</small></button>';
      });
      html += '</div>';
    });
    $('picker').innerHTML = html;
  })();
  qa('[data-x]').forEach(function (b) {
    b.addEventListener('click', function () { setCrystal(b.dataset.x); Analytics.track(NAME, '晶体', cr().name); });
  });
  function setCrystal(id) {
    state.x = id; state.sel = null; state.hide = {};
    buildSpecies();
    syncUI();
  }
  function speciesOf(c) {
    var out = [];
    c.basis.forEach(function (b) { if (out.indexOf(b.sp) < 0) out.push(b.sp); });
    return out;
  }
  // 各粒子的显示开关与“选中一个”按钮
  function buildSpecies() {
    var sps = speciesOf(cr());
    $('spBox').innerHTML = sps.length < 2 ? '' : sps.map(function (s) {
      return '<label><input type="checkbox" data-sp="' + s + '"' + (state.hide[s] ? '' : ' checked') + '> 显示 ' + C.SP[s].f + '</label>';
    }).join('');
    qa('[data-sp]').forEach(function (inp) {
      inp.addEventListener('change', function () {
        if (inp.checked) delete state.hide[inp.dataset.sp]; else state.hide[inp.dataset.sp] = 1;
        if (state.sel && state.hide[curList()[state.sel.i].sp]) state.sel = null;
        syncUI();
      });
    });
    $('selBtns').innerHTML = sps.map(function (s) { return '<button class="small" data-pick="' + s + '">选中一个 ' + C.SP[s].f + '</button>'; }).join('')
      + '<button class="small" id="clearSel">取消选择</button>';
    qa('[data-pick]').forEach(function (b) {
      b.addEventListener('click', function () { pickCentral(b.dataset.pick); Analytics.track(NAME, '选中粒子', cr().name + ' ' + C.SP[b.dataset.pick].f); });
    });
    $('clearSel').addEventListener('click', function () { state.sel = null; syncUI(); });
  }
  function curList() { return C.atoms(cr(), state.cut ? 1 : state.ext); }
  // 选中离显示区域中心最近的某种粒子
  function pickCentral(sp) {
    var c = cr(), n = state.cut ? 1 : state.ext, L = curList();
    var ctr = c.hex ? [0, 0, C.region(c, n).H / 2] : [n * c.a / 2, n * c.a / 2, n * c.a / 2];
    var best = -1, bd = Infinity;
    L.forEach(function (a, i) {
      if (a.sp !== sp) return;
      var d = C.dist(a.p, ctr) + (a.p[0] + a.p[1] * 0.01 + a.p[2] * 1e-4) * 1e-6;
      if (d < bd - 1e-6) { bd = d; best = i; }
    });
    delete state.hide[sp];
    state.sel = best < 0 ? null : { i: best, mode: state.cut ? 'info' : state.nn };
    buildSpecies();
    syncUI();
  }

  // ---------- 显示控件 ----------
  qa('[data-scene]').forEach(function (b) {
    b.addEventListener('click', function () { setScene(b.dataset.scene); Analytics.track(NAME, '场景', b.textContent); });
  });
  function setScene(s) {
    state.scene = s;
    if (s === 'quiz' && !state.quiz) newQuiz();
    syncUI();
  }
  qa('[data-model]').forEach(function (b) { b.addEventListener('click', function () { state.model = b.dataset.model; syncUI(); Analytics.track(NAME, '模型', b.textContent); }); });
  qa('[data-ext]').forEach(function (b) {
    b.addEventListener('click', function () {
      state.ext = +b.dataset.ext; state.sel = null;
      if (state.ext > 1) state.cut = false;
      syncUI(); Analytics.track(NAME, '范围', b.textContent);
    });
  });
  qa('[data-nn]').forEach(function (b) {
    b.addEventListener('click', function () {
      state.nn = b.dataset.nn;
      if (state.sel && state.sel.mode !== 'info') state.sel.mode = state.nn;
      syncUI(); Analytics.track(NAME, '配位', b.textContent);
    });
  });
  $('cut').addEventListener('change', function () {
    state.cut = $('cut').checked; state.sel = null;
    if (state.cut) state.ext = 1;
    syncUI(); Analytics.track(NAME, '均摊切割', state.cut ? '开' : '关');
  });
  $('site').addEventListener('change', function () { state.color = $('site').checked ? 'site' : 'sp'; syncUI(); Analytics.track(NAME, '按位置着色', state.color); });
  $('bonds').addEventListener('change', function () { state.bonds = $('bonds').checked; syncUI(); });
  $('spin').addEventListener('change', function () { state.spin = $('spin').checked; if (sc3) { sc3.controls.autoRotate = state.spin; } });
  $('homeBtn').addEventListener('click', function () { if (sc3) sc3.home(); });

  // 点选粒子（按下与抬起位置接近才算点击，拖动是旋转）
  var down = null;
  if (sc3) {
    sc3.canvas.addEventListener('pointerdown', function (e) { down = { x: e.clientX, y: e.clientY }; });
    sc3.canvas.addEventListener('pointerup', function (e) {
      if (!down || Math.hypot(e.clientX - down.x, e.clientY - down.y) > 6) { down = null; return; }
      down = null;
      if (state.scene !== 'cell') return;
      var i = sc3.pick(e.clientX, e.clientY);
      if (i < 0) { if (state.sel) { state.sel = null; syncUI(); } return; }
      state.sel = state.sel && state.sel.i === i ? null : { i: i, mode: state.cut ? 'info' : state.nn };
      syncUI();
      if (state.sel) Analytics.track(NAME, '点选粒子', cr().name);
    });
  }

  // ---------- 练习 ----------
  function newQuiz() {
    state.quiz = C.quiz(Math.random, state.quiz, state.quizOnly);
    state.answered = false; state.choice = null;
    var box = $('quizOpts');
    box.innerHTML = '';
    state.quiz.options.forEach(function (o) {
      var b = document.createElement('button');
      b.className = 'small';
      b.textContent = o;
      b.addEventListener('click', function () { answer(o); });
      box.appendChild(b);
    });
    box.classList.toggle('four', state.quiz.options.every(function (o) { return o.length <= 6; }));
    syncUI();
  }
  function answer(o) {
    if (state.answered) return;
    state.answered = true; state.choice = o;
    state.correct = o === state.quiz.answer;
    state.score.n++; if (state.correct) state.score.ok++;
    Analytics.track(NAME, '练习', state.quiz.type + (state.correct ? ' 对' : ' 错'));
    syncUI();
  }
  $('nextQ').addEventListener('click', newQuiz);
  // 把题目里的晶体搬到模型里：数个数 → 切开晶胞；配位 → 扩展并选中一个粒子
  $('showQ').addEventListener('click', function () {
    var q = state.quiz;
    setCrystal(q.x);
    state.model = 'ball';
    if (q.type === 'count') { state.cut = true; state.ext = 1; state.color = 'site'; }
    else { state.cut = false; state.ext = q.type === 'cn' ? 2 : q.ext || 1; state.color = 'sp'; }
    if (q.type === 'cn') { state.nn = q.mode; pickCentral(q.sel); }
    setScene('cell');
    Analytics.track(NAME, '练习 → 模型', q.type);
  });

  // ---------- 面板 ----------
  $('panelToggle').addEventListener('click', function () { panel.classList.toggle('collapsed'); });
  if (window.matchMedia('(max-width: 760px)').matches) panel.classList.add('collapsed');

  function viewOf() {
    if (state.scene === 'quiz' && state.quiz) {
      var q = state.quiz;
      return { cr: q.custom || C.CRYSTALS[q.x], ext: q.ext || 1, model: 'ball', cut: false, color: 'sp', hide: {}, bonds: true, sel: null, labels: false };
    }
    return { cr: cr(), ext: state.ext, model: state.model, cut: state.cut, color: state.color, hide: state.hide, bonds: state.bonds, sel: state.sel, labels: state.labels };
  }
  var info = null;
  function syncUI() {
    var s = state.scene, c = cr();
    setSeg('scene', s);
    qa('[data-for]').forEach(function (el) { el.hidden = el.dataset.for.split(' ').indexOf(s) < 0; });
    $('hint').textContent = sc3 ? HINTS[s] : $('hint').textContent;
    setSeg('x', state.x); setSeg('model', state.model); setSeg('ext', state.cut ? 1 : state.ext); setSeg('nn', state.nn);
    $('cut').checked = state.cut; $('site').checked = state.color === 'site'; $('bonds').checked = state.bonds; $('spin').checked = state.spin;
    $('bonds').disabled = !c.bonds.length || state.model !== 'ball' || state.cut;
    qa('[data-nn="same"]').forEach(function (b) { b.disabled = !c.cnSp; });
    if (!c.cnSp && state.nn === 'same') { state.nn = 'cn'; setSeg('nn', 'cn'); }
    $('extLabel').textContent = c.hex ? '扩大到周围' : '2×2×2';
    if (sc3) {
      sc3.spin(state.spin);
      info = sc3.update(viewOf());
    }
    legend();
    tallyTable();
    $('facts').innerHTML = (c.facts || []).map(function (f) { return '<li>' + f + '</li>'; }).join('');
    var q = state.quiz;
    if (q) {
      $('quizQ').textContent = q.prompt;
      qa('#quizOpts button').forEach(function (b) {
        b.disabled = state.answered;
        b.classList.toggle('on', state.answered && b.textContent === q.answer);
        b.classList.toggle('no', state.answered && b.textContent === state.choice && !state.correct);
      });
      $('quizMsg').innerHTML = !state.answered ? ''
        : '<b class="' + (state.correct ? 'ok">✓ 答对了' : 'bad">✗ 应选「' + q.answer + '」') + '</b>' + q.explain;
      $('nextQ').textContent = state.answered ? '下一题 →' : '换一题';
      $('showQ').hidden = !state.answered || !q.x;
    }
    if (s === 'cell') readCell(); else if (q) readQuiz();
  }
  // 画面左上角的图例
  function legend() {
    var v = viewOf(), sps = speciesOf(v.cr), html;
    if (v.color === 'site') {
      html = ['vtx', 'edge', 'face', 'in'].map(function (p) { return '<span><i style="background:' + C.POS_COL[p] + '"></i>' + C.POS[p] + '</span>'; }).join('');
    } else {
      html = sps.map(function (s) {
        var sp = C.SP[s];
        if (sp.mol) return '<span><i style="background:#a9b4c2"></i>C</span><span><i style="background:#ff6b6b"></i>O</span>';
        return '<span><i style="background:' + sp.col + '"></i>' + sp.f + '</span>';
      }).join('');
    }
    if (v.cr.kind === 'mix' && !v.cut && v.model === 'ball') html += '<span><i class="dash"></i>层间范德华力</span>';
    $('legend').innerHTML = html;
  }
  // 均摊计算表
  function tallyTable() {
    var v = viewOf(), rows = C.tally(v.cr);
    var html = '<table class="cmp"><thead><tr><th>粒子</th><th>位置 × 份额</th><th>合计</th></tr></thead><tbody>';
    rows.forEach(function (r) {
      html += '<tr><td>' + C.SP[r.sp].f + '</td><td>' + r.items.map(function (it) {
        return '<span class="pos" style="border-color:' + C.POS_COL[it.pos] + '">' + C.POS[it.pos] + ' ' + it.n + '×' + C.fracText(it.w) + '</span>';
      }).join(' + ') + '</td><td><b>' + r.total + '</b></td></tr>';
    });
    $('tallyTbl').innerHTML = html + '</tbody></table>';
    $('tallyNote').textContent = v.cr.hex
      ? '六棱柱：顶点被 6 个晶胞共用（1/6），上下底面上被 2 个共用（1/2），侧棱上被 3 个共用（1/3），柱内 1。'
      : '平行六面体（立方）晶胞：顶点被 8 个晶胞共用（1/8），棱上被 4 个共用（1/4），面上被 2 个共用（1/2），体内 1。';
  }

  // ---------- 读数 ----------
  var lastText = {};
  function setText(id, t) { if (lastText[id] !== t) { lastText[id] = t; $(id).textContent = t; } }
  function rows(list) {
    for (var k = 1; k <= 6; k++) {
      var r = list[k - 1] || ['', ''];
      setText('d' + k, r[0]); setText('r' + k, r[1]);
      $('d' + k).hidden = $('r' + k).hidden = !r[0];
    }
  }
  function f(x, n) { return x.toFixed(n); }
  function readCell() {
    var c = cr(), t = C.tally(c), d = C.density(c), co = C.coordination(c);
    setText('rName', c.name + (c.formula && c.name.indexOf(c.formula) < 0 ? ' ' + c.formula : ''));
    $('rName').className = '';
    setText('rKind', C.KIND[c.kind]);
    var single = t.length === 1;
    var list = [
      ['晶胞中', single ? t[0].total + ' 个' + (C.SP[t[0].sp].mol ? ' CO₂ 分子' : '原子')
        : t.map(function (r) { return C.SP[r.sp].f + ' ' + r.total; }).join('，') + '，即 ' + d.Z + ' 个“' + c.unit + '”'],
      ['配位数', co.map(function (x) {
        return single ? String(x.cn) : C.SP[x.sp].f + ' ' + x.cn + '（周围 ' + C.SP[x.of].f + '）';
      }).join('，')],
      ['晶胞参数', c.hex ? 'a = ' + c.a + ' pm，c = ' + c.c + ' pm（六棱柱）' : 'a = ' + c.a + ' pm'],
      ['最近距离', 'd = ' + c.dExpr + ' = ' + Math.round(co[0].d) + ' pm'],
      ['密度', 'ρ = ' + (c.hex ? 'Z·M / (N_A·V)' : 'Z·M / (N_A·a³)') + ' = ' + f(d.rho, 2) + ' g/cm³（Z = ' + d.Z + '）']
    ];
    if (c.kind === 'metal') {
      var pk = C.packing(c);
      list.push(['空间利用率', c.pack + '，' + Math.round(pk.phi * 100) + '%（r = ' + Math.round(pk.r) + ' pm）']);
    }
    rows(list);
    var tip;
    var L = info && info.list, sel = state.sel;
    if (sel && L && L[sel.i]) {
      var a = L[sel.i], sp = C.SP[a.sp], where = a.pos ? { vtx: '顶点上的 ', edge: '棱上的 ', face: '面上的 ', in: '晶胞内的 ' }[a.pos] : '';
      if (sel.mode === 'info') {
        tip = '选中' + where + sp.f + '：' + (a.share === 1 ? '完全属于这个晶胞，计 1。'
          : '被 ' + a.share + ' 个晶胞共用，每个晶胞只占 ' + C.fracText(a.w) + (c.hex ? '。' : '（虚线框为共用它的其他晶胞）。'));
      } else {
        var nb = info.nb, of = C.SP[nb.list[0].sp];
        var poly = nb.list.length === 6 ? '正八面体' : nb.list.length === 8 ? '立方体' : nb.list.length === 4 ? '正四面体' : nb.list.length === 3 ? '正三角形' : '';
        var out = nb.list.filter(function (q) { return q.k < 0; }).length;
        tip = '选中' + where + sp.f + '：距离最近的' + (sel.mode === 'same' ? '同种粒子 ' : ' ') + of.f + ' 有 ' + nb.list.length + ' 个，相距 ' + Math.round(nb.d) + ' pm'
          + (poly ? '，围成' + poly : '') + '。' + (out ? '其中 ' + out + ' 个在当前显示范围之外（半透明）。' : '');
      }
    } else if (state.cut) {
      tip = '均摊法：只保留每个粒子在这个晶胞里的那一部分。' + (c.hex ? '六棱柱的顶点、侧棱上、面上的粒子被相邻晶胞共用，切开后分别只剩 1/6、1/3、1/2。'
        : '顶点、棱上、面上的粒子被相邻晶胞共用，切开后分别只剩 1/8、1/4、1/2。') + '点一个粒子看它被几个晶胞共用。';
    } else {
      tip = c.facts[0] + '。点一个粒子查看它的配位情况，或勾选“均摊”切开晶胞。';
    }
    setText('rTip', tip);
  }
  function readQuiz() {
    var q = state.quiz, s = state.score;
    setText('rName', !state.answered ? '判断练习' : state.correct ? '✓ 答对了' : '✗ 答错了');
    $('rName').className = !state.answered ? '' : state.correct ? 'ok' : 'bad';
    setText('rKind', '得分 ' + s.ok + ' / ' + s.n);
    setText('rTip', state.answered ? q.explain : q.prompt);
    rows([]);
  }

  // ---------- 尺寸与主循环 ----------
  function resize() { if (sc3) sc3.resize(stage.clientWidth, stage.clientHeight); }
  new ResizeObserver(resize).observe(stage);

  // 支持 ?scene=cell|quiz、&x=nacl|cscl|caf2|zns|diamond|sio2|graphite|co2|po|na|cu|mg、&model=ball|fill、&ext=1|2、&cut=1、
  // &color=site、&bonds=0、&hide=Cl（逗号分隔，粒子代号）、&sel=Na（选中显示区域中心附近的该种粒子）、&nn=cn|same、&spin=0、练习 &q=count|formula|cn|fact
  var qs = new URLSearchParams(location.search);
  if (HINTS[qs.get('scene')]) state.scene = qs.get('scene');
  if (C.CRYSTALS[qs.get('x')]) state.x = qs.get('x');
  if (qs.get('model') === 'fill') state.model = 'fill';
  if (qs.get('ext') === '2') state.ext = 2;
  if (qs.get('cut') === '1') { state.cut = true; state.ext = 1; }
  if (qs.get('color') === 'site') state.color = 'site';
  if (qs.get('bonds') === '0') state.bonds = false;
  if (qs.get('spin') === '0') state.spin = false;
  if (qs.get('nn') === 'same') state.nn = 'same';
  if (C.TYPES.indexOf(qs.get('q')) >= 0) state.quizOnly = qs.get('q');
  resize();
  setCrystal(state.x);
  (qs.get('hide') || '').split(',').forEach(function (s) { if (s && speciesOf(cr()).indexOf(s) >= 0) state.hide[s] = 1; });
  buildSpecies();
  if (qs.get('sel') && speciesOf(cr()).indexOf(qs.get('sel')) >= 0) pickCentral(qs.get('sel'));
  setScene(state.scene);
  if (sc3) sc3.home();

  function frame() {
    if (sc3) sc3.render();
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // 调试用
  window.__model = {
    state: state, C: C, scene: sc3, setCrystal: setCrystal, setScene: setScene, pickCentral: pickCentral, newQuiz: newQuiz, sync: syncUI,
    answer: function (o) { answer(o == null ? state.quiz.answer : o); }
  };
})();
