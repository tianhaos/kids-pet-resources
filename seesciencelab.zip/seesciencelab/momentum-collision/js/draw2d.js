// 2D 绘制：气垫导轨上的一维碰撞（滑块、动量条、动能条、v-t 图像）、动碰静的速度—质量比图像、斜槽验证动量守恒（侧视 + 记录纸）
// 世界坐标同 Mom：x 右、y 上，单位 m；frame(R, box) 把世界范围 box 等比放进屏幕矩形 R
(function () {
  var M = window.Mom, f = M.f, clamp = M.clamp, CH = M.CH;
  var MUTED = '#8d99ab', TEXT = '#e6ebf2', GRID = 'rgba(141,153,171,.14)', LINE = '#4a5670', PANEL = 'rgba(17,23,35,.6)';
  var CA = '#ffc94a', CB = '#4fc3f7', SUM = '#7ee081', LOSS = '#ff7a59', VC = '#cfd6e2';
  var FONT = '-apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", sans-serif';
  var KIND = { elastic: '弹簧圈', inelastic: '橡皮垫', perfect: '橡皮泥' };

  function font(px, w) { return (w ? w + ' ' : '') + px + 'px ' + FONT; }
  function label(ctx, s, x, y, o) {
    o = o || {};
    ctx.font = font(o.size || 12, o.bold ? 600 : null);
    ctx.textAlign = o.align || 'center'; ctx.textBaseline = o.base || 'middle';
    ctx.lineWidth = 3; ctx.lineJoin = 'round'; ctx.strokeStyle = 'rgba(5,7,13,.85)'; ctx.strokeText(s, x, y);
    ctx.fillStyle = o.color || TEXT; ctx.fillText(s, x, y);
  }
  function arrow(ctx, x1, y1, x2, y2, color, o) {
    o = o || {};
    var a = Math.atan2(y2 - y1, x2 - x1), len = Math.hypot(x2 - x1, y2 - y1), size = Math.min(o.size || 9, len * 0.6);
    if (len < 2) return;
    ctx.strokeStyle = ctx.fillStyle = color; ctx.lineWidth = o.width || 2.2; ctx.setLineDash(o.dash || []);
    ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2 - Math.cos(a) * size * 0.6, y2 - Math.sin(a) * size * 0.6); ctx.stroke();
    ctx.setLineDash([]);
    ctx.beginPath();
    ctx.moveTo(x2, y2);
    ctx.lineTo(x2 - size * Math.cos(a - 0.42), y2 - size * Math.sin(a - 0.42));
    ctx.lineTo(x2 - size * Math.cos(a + 0.42), y2 - size * Math.sin(a + 0.42));
    ctx.closePath(); ctx.fill();
  }
  function line(ctx, x1, y1, x2, y2, color, o) {
    o = o || {};
    ctx.strokeStyle = color; ctx.lineWidth = o.width || 1.2; ctx.setLineDash(o.dash || []);
    ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke(); ctx.setLineDash([]);
  }
  function box(ctx, R) {
    ctx.fillStyle = PANEL; ctx.fillRect(R.x, R.y, R.w, R.h);
    ctx.strokeStyle = 'rgba(42,52,70,.9)'; ctx.lineWidth = 1; ctx.strokeRect(R.x + 0.5, R.y + 0.5, R.w - 1, R.h - 1);
  }
  function frame(R, b) {
    var k = Math.min(R.w / (b.x1 - b.x0), R.h / (b.y1 - b.y0));
    var cx = R.x + R.w / 2, cy = R.y + R.h / 2, mx = (b.x0 + b.x1) / 2, my = (b.y0 + b.y1) / 2;
    return { k: k, p: function (x, y) { return { x: cx + (x - mx) * k, y: cy - (y - my) * k }; } };
  }
  // 速度、动量的显示：正为向右
  function sv(v, unit) { return (v > 0.005 ? '+' : '') + f(v) + ' ' + unit; }

  function View(canvas) {
    var ctx = canvas.getContext('2d'), W = 0, H = 0, dpr = 1, narrow = false, hits = {};
    function resize(w, h) {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      W = w; H = h; narrow = w < 640;
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
      canvas.style.width = w + 'px'; canvas.style.height = h + 'px';
    }
    function bg() {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      var g = ctx.createLinearGradient(0, 0, 0, H);
      g.addColorStop(0, '#04060c'); g.addColorStop(1, '#0a1120');
      ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
      hits = {};
    }
    function area() {
      var t0 = narrow ? 84 : 46, bottom = narrow ? 46 : 48;
      return { x: 14, y: t0, w: W - 28, h: Math.max(200, H - t0 - bottom) };
    }

    // ---------- 气垫导轨与滑块 ----------
    // 滑块：中心 x（屏幕）、导轨面 y；高度随质量变化（看得出谁重）；side 为碰撞面（+1 右、−1 左）
    function cart(cx, y, w, m, color, name, side, kind) {
      var h = clamp(16 + 13 * Math.cbrt(m), 18, 42);
      ctx.fillStyle = color; ctx.strokeStyle = 'rgba(5,7,13,.6)'; ctx.lineWidth = 1.2;
      ctx.beginPath(); ctx.roundRect(cx - w / 2, y - h - 3, w, h, 4); ctx.fill(); ctx.stroke();
      ctx.fillStyle = 'rgba(0,0,0,.22)'; ctx.fillRect(cx - w / 2 + 3, y - h, w - 6, h * 0.25);
      // 挡光片
      ctx.fillStyle = 'rgba(230,235,242,.75)'; ctx.fillRect(cx - 2, y - h - 13, 4, 10);
      label(ctx, name, cx, y - h / 2 - 3, { size: Math.min(13, h * 0.55), bold: true, color: '#111' });
      // 碰撞面上的装置
      var ex = cx + side * w / 2, ym = y - h / 2 - 3;
      if (kind === 'elastic') {
        ctx.strokeStyle = '#cfd6e2'; ctx.lineWidth = 1.6; ctx.beginPath();
        ctx.ellipse(ex + side * 7, ym, 7, h * 0.36, 0, 0, 7); ctx.stroke();
      } else if (kind === 'perfect') {
        ctx.fillStyle = '#b07ad9'; ctx.beginPath(); ctx.ellipse(ex + side * 2, ym, 4, h * 0.3, 0, 0, 7); ctx.fill();
      } else {
        ctx.fillStyle = '#6b7385'; ctx.fillRect(side > 0 ? ex : ex - 5, ym - h * 0.3, 5, h * 0.6);
      }
      return h;
    }
    // 导轨：返回 { p(x) 屏幕 x, y 导轨面, k }
    function track(R, o) {
      var pad = 10, k = (R.w - 2 * pad) / M.TRACK, x0 = R.x + pad, y = R.y + R.h - (o.compact ? 26 : 40);
      var X = function (x) { return x0 + x * k; };
      ctx.fillStyle = '#2b3346'; ctx.fillRect(x0, y, M.TRACK * k, 9);
      ctx.strokeStyle = '#6f86c9'; ctx.lineWidth = 1.5; ctx.strokeRect(x0, y, M.TRACK * k, 9);
      ctx.fillStyle = 'rgba(141,153,171,.5)';
      for (var i = 0.05; i < M.TRACK; i += 0.1) { ctx.beginPath(); ctx.arc(X(i), y + 4.5, 1.2, 0, 7); ctx.fill(); }
      // 两端缓冲器、支脚
      ctx.fillStyle = '#4a5670'; ctx.fillRect(x0 - 6, y - 14, 6, 23); ctx.fillRect(X(M.TRACK), y - 14, 6, 23);
      line(ctx, X(0.25), y + 9, X(0.25), y + 20, LINE, { width: 3 }); line(ctx, X(M.TRACK - 0.25), y + 9, X(M.TRACK - 0.25), y + 20, LINE, { width: 3 });
      if (!o.compact && !narrow) label(ctx, '气垫导轨（不计摩擦）', X(M.TRACK) - 4, y + 24, { size: 11, color: MUTED, align: 'right' });
      return { X: X, y: y, k: k };
    }
    function carts(R, o) {
      var r = o.run, s = r.at(o.t), tr = track(R, o), w = M.CART * tr.k;
      var yA = tr.y, ax = tr.X(s.x1), bx = tr.X(s.x2);
      var hA = cart(ax, yA, w, r.m1, CA, 'A', 1, o.kind), hB = cart(bx, yA, w, r.m2, CB, 'B', -1, o.kind);
      // 碰撞瞬间的闪光
      if (r.hit && Math.abs(o.t - r.tc) < 0.12) {
        var cxp = (ax + bx) / 2, a = 1 - Math.abs(o.t - r.tc) / 0.12;
        ctx.strokeStyle = 'rgba(255,255,255,' + (0.8 * a) + ')'; ctx.lineWidth = 2;
        for (var i = 0; i < 8; i++) { var an = i * Math.PI / 4; ctx.beginPath(); ctx.moveTo(cxp + Math.cos(an) * 8, yA - 22 + Math.sin(an) * 8); ctx.lineTo(cxp + Math.cos(an) * 20, yA - 22 + Math.sin(an) * 20); ctx.stroke(); }
      }
      // 速度箭头（长度 = 0.3 s 内走过的距离）
      var sc = tr.k * 0.3, top = yA - Math.max(hA, hB) - 26;
      var joint = s.after && Math.abs(s.v1 - s.v2) < 1e-9;
      if (joint) {
        var mid = (ax + bx) / 2, jl = clamp(s.v1 * sc, -R.w * 0.3, R.w * 0.3);
        if (Math.abs(s.v1) > 0.005) arrow(ctx, mid, top, mid + jl, top, SUM, { width: 2.4 });
        label(ctx, '粘在一起，共同速度 v = ' + sv(s.v1, 'm/s'), mid, top - 14, { size: 11, color: SUM, bold: true });
      } else [[ax, s.v1, CA, 'v₁'], [bx, s.v2, CB, 'v₂']].forEach(function (c) {
        var len = clamp(c[1] * sc, -R.w * 0.3, R.w * 0.3);
        if (Math.abs(c[1]) > 0.005) arrow(ctx, c[0], top, c[0] + len, top, c[2], { width: 2.4 });
        else label(ctx, '静止', c[0], top, { size: 11, color: c[2] });
        if (!o.compact || Math.abs(c[1]) > 0.005) label(ctx, c[3] + (s.after ? '′' : '') + ' = ' + sv(c[1], 'm/s'), c[0], top - 14, { size: 11, color: c[2], bold: true });
      });
      if (!o.compact) {
        var near = bx - ax < 110;   // 两车挨在一起时标签分到两侧
        label(ctx, 'm₁ = ' + f(r.m1) + ' kg', near ? ax - w / 2 : ax, yA + 24, { size: 11, color: CA, align: near ? 'right' : 'center' });
        label(ctx, 'm₂ = ' + f(r.m2) + ' kg', near ? bx + w / 2 : bx, yA + 24, { size: 11, color: CB, align: near ? 'left' : 'center' });
      }
      if (!r.hit) label(ctx, 'A 追不上 B，两车不会相碰', R.x + R.w / 2, R.y + 12, { size: 12, color: LOSS, bold: true });
      return tr;
    }

    // ---------- 动量条、动能条 ----------
    function rowsPanel(R, title, unit, rows, maxV, signed, extra) {
      box(ctx, R);
      label(ctx, title, R.x + 10, R.y + 13, { size: 12, color: MUTED, align: 'left', bold: true });
      var lw = 46, vw = narrow ? 92 : 104, bx0 = R.x + lw, bw = R.w - lw - vw - 10, rh = Math.min(26, (R.h - 30) / rows.length);
      var zero = signed ? bx0 + bw / 2 : bx0, half = signed ? bw / 2 : bw, sc = half / (maxV || 1);
      line(ctx, zero, R.y + 24, zero, R.y + 28 + rows.length * rh, MUTED, { width: 1 });
      rows.forEach(function (r, i) {
        var y = R.y + 28 + i * rh, bh = rh * 0.62;
        label(ctx, r.name, R.x + lw - 6, y + rh / 2, { size: 11, color: r.color, align: 'right', bold: true });
        if (r.ghost != null) { ctx.strokeStyle = r.color; ctx.globalAlpha = 0.55; ctx.lineWidth = 1; ctx.setLineDash([3, 3]); ctx.strokeRect(Math.min(zero, zero + r.ghost * sc), y + (rh - bh) / 2, Math.abs(r.ghost * sc), bh); ctx.setLineDash([]); ctx.globalAlpha = 1; }
        var w = r.v * sc;
        ctx.fillStyle = r.color; ctx.globalAlpha = 0.85; ctx.fillRect(Math.min(zero, zero + w), y + (rh - bh) / 2, Math.abs(w), bh); ctx.globalAlpha = 1;
        if (r.loss) {
          var x1 = zero + w, wl = r.loss * sc;
          ctx.save(); ctx.beginPath(); ctx.rect(x1, y + (rh - bh) / 2, wl, bh); ctx.clip();
          ctx.strokeStyle = LOSS; ctx.lineWidth = 1.4;
          for (var j = -bh; j < wl; j += 5) { ctx.beginPath(); ctx.moveTo(x1 + j, y + (rh + bh) / 2); ctx.lineTo(x1 + j + bh, y + (rh - bh) / 2); ctx.stroke(); }
          ctx.restore();
          ctx.strokeStyle = LOSS; ctx.lineWidth = 1; ctx.strokeRect(x1, y + (rh - bh) / 2, wl, bh);
        }
        label(ctx, r.text, R.x + R.w - 8, y + rh / 2, { size: 11, color: r.color, align: 'right' });
      });
      if (extra) label(ctx, extra.text, R.x + R.w - 8, R.y + 13, { size: 11, color: extra.color, align: 'right', bold: true });
    }
    function bars(R, o) {
      var r = o.run, s = r.at(o.t), p1 = r.m1 * s.v1, p2 = r.m2 * s.v2, after = s.after;
      var pMax = Math.max(Math.abs(r.m1 * r.v1), Math.abs(r.m2 * r.v2), Math.abs(r.m1 * r.u1), Math.abs(r.m2 * r.u2), Math.abs(r.p0), 0.5) * 1.05;
      var E1 = M.ek(r.m1, s.v1), E2 = M.ek(r.m2, s.v2), eMax = Math.max(r.E0, 0.5);
      var side = !narrow && R.w > 620, gap = 10, w = side ? (R.w - gap) / 2 : R.w, h = side ? R.h : (R.h - gap) / 2;
      var RP = { x: R.x, y: R.y, w: w, h: h }, RE = side ? { x: R.x + w + gap, y: R.y, w: w, h: h } : { x: R.x, y: R.y + h + gap, w: w, h: h };
      rowsPanel(RP, after ? '动量 p = mv（向右为正，虚框为碰前）' : '动量 p = mv（向右为正，碰前）', 'kg·m/s', [
        { name: 'A', color: CA, v: p1, ghost: after ? r.m1 * r.v1 : null, text: sv(p1, 'kg·m/s') },
        { name: 'B', color: CB, v: p2, ghost: after ? r.m2 * r.v2 : null, text: sv(p2, 'kg·m/s') },
        { name: '总', color: SUM, v: p1 + p2, ghost: after ? r.p0 : null, text: sv(p1 + p2, 'kg·m/s') }
      ], pMax, true, after ? { text: '总动量不变', color: SUM } : null);
      var loss = after ? r.E0 - E1 - E2 : 0;
      rowsPanel(RE, after ? '动能 Ek = ½mv²（碰后）' : '动能 Ek = ½mv²（碰前）', 'J', [
        { name: 'A', color: CA, v: E1, ghost: after ? M.ek(r.m1, r.v1) : null, text: f(E1) + ' J' },
        { name: 'B', color: CB, v: E2, ghost: after ? M.ek(r.m2, r.v2) : null, text: f(E2) + ' J' },
        { name: '总', color: SUM, v: E1 + E2, loss: loss > 1e-6 ? loss : 0, text: f(E1 + E2) + ' J' }
      ], eMax, false, after ? (loss > 1e-6 ? { text: '损失 ' + f(loss) + ' J（' + f(loss / r.E0 * 100, 0) + '%）', color: LOSS } : { text: '总动能不变', color: SUM }) : null);
    }

    // ---------- v-t 图像 ----------
    function vt(R, o) {
      box(ctx, R);
      var r = o.run, P = { x: R.x + 44, y: R.y + 24, w: R.w - 64, h: R.h - 48 };
      var vs = [r.v1, r.v2, r.u1, r.u2, 0], vMax = Math.max.apply(null, vs), vMin = Math.min.apply(null, vs);
      var span = Math.max(vMax - vMin, 1), step = span > 5 ? 2 : span > 2.4 ? 1 : 0.5;
      vMax = Math.ceil((vMax + span * 0.08) / step) * step; vMin = Math.floor((vMin - span * 0.08) / step) * step;
      if (vMax - vMin < step * 2) vMax += step;
      var tMax = r.tEnd, X = function (t) { return P.x + t / tMax * P.w; }, Y = function (v) { return P.y + (vMax - v) / (vMax - vMin) * P.h; };
      ctx.strokeStyle = GRID; ctx.lineWidth = 1; ctx.beginPath();
      var ts = tMax > 3 ? 0.5 : tMax > 1.2 ? 0.25 : 0.1, i;
      for (i = 0; i * ts <= tMax + 1e-9; i++) { ctx.moveTo(X(i * ts), P.y); ctx.lineTo(X(i * ts), P.y + P.h); }
      for (var v = vMin; v <= vMax + 1e-9; v += step) { ctx.moveTo(P.x, Y(v)); ctx.lineTo(P.x + P.w, Y(v)); }
      ctx.stroke();
      var lab = Math.max(1, Math.ceil(28 / (ts / tMax * P.w)));
      for (i = 0; i * ts <= tMax + 1e-9; i += lab) label(ctx, f(i * ts), X(i * ts), P.y + P.h + 11, { size: 10, color: MUTED });
      for (v = vMin; v <= vMax + 1e-9; v += step) label(ctx, f(v, 1), P.x - 6, Y(v), { size: 10, color: MUTED, align: 'right' });
      line(ctx, P.x, Y(0), P.x + P.w, Y(0), MUTED, { width: 1.2 });
      label(ctx, 't / s', P.x + P.w + 6, Y(0) - 10, { size: 11, color: MUTED, align: 'right' });
      label(ctx, 'v / (m·s⁻¹)', P.x - 30, R.y + 11, { size: 11, color: MUTED, align: 'left' });
      label(ctx, '速度—时间图像（拖动图像可改时刻）', P.x + P.w, R.y + 11, { size: 11, color: MUTED, align: 'right' });
      // 质心速度：整个过程不变
      line(ctx, P.x, Y(r.vc), P.x + P.w, Y(r.vc), VC, { dash: [6, 5], width: 1.2 });
      label(ctx, 'v质心 = ' + f(r.vc) + ' m/s', P.x + 6, Y(r.vc) + (r.vc >= (vMax + vMin) / 2 ? 11 : -11), { size: 10, color: VC, align: 'left' });
      if (r.hit) line(ctx, X(r.tc), P.y, X(r.tc), P.y + P.h, 'rgba(255,255,255,.25)', { dash: [3, 4] });
      var t = Math.min(o.t, tMax);
      [[r.v1, r.u1, CA, 'x1'], [r.v2, r.u2, CB, 'x2']].forEach(function (c) {
        var post = r.hit && t > r.tc, t1 = post ? r.tc : t;
        line(ctx, X(0), Y(c[0]), X(t1), Y(c[0]), c[2], { width: 2.4 });
        if (post) {
          line(ctx, X(r.tc), Y(c[0]), X(r.tc), Y(c[1]), c[2], { width: 1.2, dash: [3, 3] });
          line(ctx, X(r.tc), Y(c[1]), X(t), Y(c[1]), c[2], { width: 2.4 });
        }
        ctx.fillStyle = c[2]; ctx.beginPath(); ctx.arc(X(t), Y(post ? c[1] : c[0]), 4, 0, 7); ctx.fill();
      });
      line(ctx, X(t), P.y, X(t), P.y + P.h, 'rgba(230,235,242,.35)', { width: 1 });
      hits.vt = { x: P.x, y: R.y, w: P.w, h: R.h, t: function (px) { return clamp((px - P.x) / P.w, 0, 1) * tMax; } };
    }

    // o: { run, t, kind, bars, graph }
    function drawCollide(o) {
      bg();
      var R = area(), th = clamp(R.h * 0.3, 128, 180), gap = 12;
      var bh = o.bars ? (narrow || R.w <= 620 ? 196 : 112) : 0, gh = o.graph ? Math.max(140, R.h - th - bh - gap * 2) : 0;
      var tot = th + (bh ? bh + gap : 0) + (gh ? gh + gap : 0), y = R.y + Math.max(0, (R.h - tot) / 2);
      if (o.graph && tot > R.h) gh = Math.max(110, gh - (tot - R.h));
      carts({ x: R.x, y: y, w: R.w, h: th }, o);
      y += th + gap;
      if (bh) { bars({ x: R.x, y: y, w: R.w, h: bh }, o); y += bh + gap; }
      if (gh) vt({ x: R.x, y: y, w: R.w, h: gh }, o);
    }

    // ---------- ② 动碰静：v′/v0 与 m1/m2 ----------
    var K_MIN = 0.1, K_MAX = 10;
    function ratioGraph(R, o) {
      box(ctx, R);
      var P = { x: R.x + 46, y: R.y + 28, w: R.w - 66, h: R.h - 56 }, y0 = -1.1, y1 = 2.1;
      var lk0 = Math.log10(K_MIN), lk1 = Math.log10(K_MAX);
      var X = function (k) { return P.x + (Math.log10(k) - lk0) / (lk1 - lk0) * P.w; }, Y = function (v) { return P.y + (y1 - v) / (y1 - y0) * P.h; };
      ctx.strokeStyle = GRID; ctx.lineWidth = 1; ctx.beginPath();
      [0.1, 0.2, 0.5, 1, 2, 5, 10].forEach(function (k) { ctx.moveTo(X(k), P.y); ctx.lineTo(X(k), P.y + P.h); });
      for (var v = -1; v <= 2; v += 0.5) { ctx.moveTo(P.x, Y(v)); ctx.lineTo(P.x + P.w, Y(v)); }
      ctx.stroke();
      [0.1, 0.2, 0.5, 1, 2, 5, 10].forEach(function (k) { label(ctx, f(k), X(k), P.y + P.h + 11, { size: 10, color: MUTED }); });
      for (v = -1; v <= 2; v += 0.5) label(ctx, f(v, 1), P.x - 6, Y(v), { size: 10, color: MUTED, align: 'right' });
      line(ctx, P.x, Y(0), P.x + P.w, Y(0), MUTED, { width: 1.2 });
      label(ctx, 'm₁ / m₂（对数刻度）', P.x + P.w, P.y + P.h + 24, { size: 11, color: MUTED, align: 'right' });
      label(ctx, '碰后速度 ÷ v₀', P.x - 36, R.y + 12, { size: 11, color: MUTED, align: 'left' });
      label(ctx, narrow ? '拖动图像改质量比' : 'A 撞静止的 B：碰后速度与质量比的关系（拖动图像改质量比）', P.x + P.w, R.y + 12, { size: 11, color: MUTED, align: 'right' });
      function curve(fn, color, dash, width) {
        ctx.strokeStyle = color; ctx.lineWidth = width || 2.2; ctx.setLineDash(dash || []); ctx.beginPath();
        for (var i = 0; i <= 200; i++) { var k = Math.pow(10, lk0 + (lk1 - lk0) * i / 200), yy = fn(k); if (i) ctx.lineTo(X(k), Y(yy)); else ctx.moveTo(X(k), Y(yy)); }
        ctx.stroke(); ctx.setLineDash([]);
      }
      if (o.e < 1) {
        curve(function (k) { return M.ratio(k, 1).a; }, 'rgba(255,201,74,.35)', [4, 4], 1.4);
        curve(function (k) { return M.ratio(k, 1).b; }, 'rgba(79,195,247,.35)', [4, 4], 1.4);
      }
      curve(function (k) { return M.ratio(k, o.e).share; }, SUM, [6, 4], 1.8);
      curve(function (k) { return M.ratio(k, o.e).a; }, CA);
      curve(function (k) { return M.ratio(k, o.e).b; }, CB);
      // 渐近线说明
      label(ctx, (o.e > 0 ? 'v₂′ → ' + f(1 + o.e) : 'v₁′ = v₂′ → ') + 'v₀', X(K_MAX) - 4, Y(1 + o.e) - 12, { size: 10, color: CB, align: 'right' });
      if (o.e > 0) label(ctx, o.e === 1 ? 'v₁′ → −v₀（被弹回）' : 'v₁′ → −' + f(o.e) + 'v₀', X(K_MIN) + 4, Y(-o.e) + 12, { size: 10, color: CA, align: 'left' });
      // 当前质量比
      var q = M.ratio(o.k, o.e), xk = X(o.k);
      line(ctx, xk, P.y, xk, P.y + P.h, 'rgba(230,235,242,.4)', { width: 1 });
      var tags = o.e > 0 ? [[q.a, CA, 'v₁′ = ' + f(q.a) + 'v₀'], [q.b, CB, 'v₂′ = ' + f(q.b) + 'v₀']] : [[q.b, CB, '共同速度 v = ' + f(q.b) + 'v₀']];
      tags.push([q.share, SUM, 'B 得到 ' + f(q.share * 100, 0) + '% 动能']);
      tags.forEach(function (c) { ctx.fillStyle = c[1]; ctx.beginPath(); ctx.arc(xk, Y(c[0]), 5, 0, 7); ctx.fill(); c.y = Y(c[0]) - 11; });
      // 标签按高度排开，避免重叠
      tags.sort(function (a, b) { return a.y - b.y; });
      for (var i = 1; i < tags.length; i++) if (tags[i].y - tags[i - 1].y < 15) tags[i].y = tags[i - 1].y + 15;
      var right = xk < P.x + P.w * 0.62;
      tags.forEach(function (c) { label(ctx, c[2], xk + (right ? 9 : -9), c.y, { size: 11, color: c[1], bold: true, align: right ? 'left' : 'right' }); });
      // 图例
      var lx = P.x + 8, ly = P.y + 8;
      [[CA, 'A 碰后 v₁′', []], [CB, 'B 碰后 v₂′', []], [SUM, 'B 获得动能占比', [6, 4]]].forEach(function (c, i) {
        var x = lx + i * (narrow ? 86 : 110);
        line(ctx, x, ly, x + 16, ly, c[0], { width: 2.2, dash: c[2] });
        label(ctx, c[1], x + 20, ly, { size: 10, color: c[0], align: 'left' });
      });
      hits.ratio = { x: P.x, y: R.y, w: P.w, h: R.h, k: function (px) { return Math.pow(10, lk0 + clamp((px - P.x) / P.w, 0, 1) * (lk1 - lk0)); } };
    }
    // o: { run, t, kind, k, e }
    function drawRatio(o) {
      bg();
      var R = area(), th = clamp(R.h * 0.3, 128, 170), gap = 14;
      carts({ x: R.x, y: R.y, w: R.w, h: th }, { run: o.run, t: o.t, kind: o.kind, compact: narrow });
      ratioGraph({ x: R.x, y: R.y + th + gap, w: R.w, h: R.h - th - gap }, o);
    }

    // ---------- ③ 斜槽验证动量守恒 ----------
    var RR = CH.R, X0 = -0.5, X1 = 0.86;
    // 入射球球心沿斜槽的路径（二次贝塞尔，槽口处水平），u ∈ [0, 1]，终点在被碰球左侧 2R 处
    var C0 = { x: -0.46, y: CH.H + 0.27 }, C1 = { x: -0.2, y: CH.H }, C2 = { x: -2 * RR, y: CH.H };
    function bez(u) { var a = (1 - u) * (1 - u), b = 2 * u * (1 - u), c = u * u; return { x: a * C0.x + b * C1.x + c * C2.x, y: a * C0.y + b * C1.y + c * C2.y }; }
    // 一个球在动画时刻 τ 的位置（世界）：v 为离开槽口（或碰后）的水平速度，tc 为到达碰撞点的时刻
    function ballPos(v, tau, start) {
      var tc = CH.ROLL;
      if (tau < tc && start === 'roll') return bez(Math.pow(tau / tc, 1.6));
      var x = start === 'roll' ? -2 * RR : 0, u = tau - tc;
      if (start === 'roll') {
        if (v <= 0.05 * CH.V0) return { x: Math.max(-0.06, x + v * u), y: CH.H, onChute: true };
        var tEdge = 2 * RR / v;
        if (u < tEdge) return { x: x + v * u, y: CH.H };
        u -= tEdge; x = 0;
      }
      var tt = Math.min(u, CH.TF);
      return { x: x + v * tt, y: CH.H - M.G * tt * tt / 2, landed: u >= CH.TF };
    }
    function ball(p, color, fr) {
      var c = fr.p(p.x, p.y), r = Math.max(6, RR * fr.k);
      var g = ctx.createRadialGradient(c.x - r * 0.35, c.y - r * 0.35, 1, c.x, c.y, r);
      g.addColorStop(0, '#fff'); g.addColorStop(0.35, color); g.addColorStop(1, 'rgba(0,0,0,.6)');
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(c.x, c.y, r, 0, 7); ctx.fill();
    }
    var PCOL = { P: CA, M: LOSS, N: CB };
    // o: { anim: { d, tau } | null, pts: { P, M, N }, means: { P, M, N }, m1, m2 }
    function drawChute(o) {
      bg();
      var R = area(), gap = 12, need = R.w / (X1 - X0) * (CH.H + 0.34);
      var sideH = Math.min(R.h * 0.62, need), paperH = Math.min(R.h - sideH - gap, Math.max(150, sideH * 0.5));
      R = { x: R.x, y: R.y + (R.h - sideH - gap - paperH) / 2, w: R.w, h: sideH + gap + paperH };
      var fr = frame({ x: R.x, y: R.y, w: R.w, h: sideH }, { x0: X0, x1: X1, y0: -0.04, y1: CH.H + 0.3 }), k = fr.k;
      var floor = fr.p(0, -RR).y, O = fr.p(0, 0);
      ctx.fillStyle = 'rgba(43,51,70,.55)'; ctx.fillRect(R.x, floor, R.w, 6);
      line(ctx, R.x, floor, R.x + R.w, floor, LINE, { width: 2 });
      // 记录纸（侧视）
      var pa = fr.p(0.05, 0), pb = fr.p(X1 - 0.02, 0);
      ctx.fillStyle = '#d9dee6'; ctx.fillRect(pa.x, floor - 2, pb.x - pa.x, 2);
      // 斜槽与支架
      var lip = fr.p(RR * 0.6, CH.H - RR);
      ctx.strokeStyle = '#6f86c9'; ctx.lineWidth = 3; ctx.beginPath();
      for (var i = 0; i <= 40; i++) { var q = bez(i / 40), s = fr.p(q.x, q.y - RR); if (i) ctx.lineTo(s.x, s.y); else ctx.moveTo(s.x, s.y); }
      ctx.lineTo(lip.x, lip.y); ctx.stroke();
      var st0 = fr.p(-0.44, CH.H + 0.24), stb = fr.p(-0.44, -RR), st1 = fr.p(-0.06, CH.H - RR - 0.01);
      ctx.fillStyle = 'rgba(111,134,201,.18)'; ctx.beginPath(); ctx.moveTo(st0.x, st0.y);
      for (i = 0; i <= 40; i++) { var q2 = bez(i / 40), s2 = fr.p(q2.x, q2.y - RR - 0.004); ctx.lineTo(s2.x, s2.y); }
      ctx.lineTo(st1.x, st1.y + 6); ctx.lineTo(fr.p(-0.06, 0).x, st1.y + 6); ctx.lineTo(fr.p(-0.06, 0).x, stb.y); ctx.lineTo(stb.x, stb.y); ctx.closePath(); ctx.fill();
      // 释放位置挡板
      var rel = fr.p(C0.x - 0.02, C0.y);
      line(ctx, rel.x, rel.y - 10, rel.x, rel.y + 6, '#cfd6e2', { width: 3 });
      label(ctx, '每次从同一位置由静止释放', rel.x - 4, rel.y - 20, { size: 11, color: MUTED, align: 'left' });
      // 铅垂线
      line(ctx, lip.x - (RR * 0.6) * k, lip.y, O.x, floor, 'rgba(230,235,242,.6)', { dash: [2, 3] });
      label(ctx, '重垂线', O.x - 6, (lip.y + floor) / 2, { size: 10, color: MUTED, align: 'right' });
      label(ctx, 'O', O.x, floor + 14, { size: 12, bold: true });
      label(ctx, '槽口离地 ' + f(CH.H * 100, 0) + ' cm', fr.p(-0.06, 0).x - 6, fr.p(0, CH.H * 0.4).y, { size: 10, color: MUTED, align: 'right' });
      // 落点（侧视的小痕迹）与平均落点字母
      ['P', 'M', 'N'].forEach(function (g) {
        o.pts[g].forEach(function (p) { var s = fr.p(p.x, 0); line(ctx, s.x, floor - 3, s.x, floor + 1, PCOL[g], { width: 1.4 }); });
        var m = o.means[g];
        if (m) { var s3 = fr.p(m.x, 0); label(ctx, g, s3.x, floor + 14, { size: 12, bold: true, color: PCOL[g] }); }
      });
      // 球：动画中或静止在起点
      var a = o.anim, hitMode = a ? a.d.mode === 'hit' : o.mode === 'hit';
      if (a) {
        var tau = a.tau, d = a.d, p1 = ballPos(d.mode === 'hit' && tau >= CH.ROLL ? d.v1 : d.v0, tau, 'roll');
        if (d.mode === 'hit') {
          var p2 = tau < CH.ROLL ? { x: 0, y: CH.H } : ballPos(d.v2, tau, 'edge');
          ball(p2, CB, fr);
          if (Math.abs(tau - CH.ROLL) < 0.06) { var cc = fr.p(-RR, CH.H); ctx.strokeStyle = 'rgba(255,255,255,.7)'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(cc.x, cc.y, 14, 0, 7); ctx.stroke(); }
        }
        ball(p1, CA, fr);
        // 轨迹
        [[d.mode === 'hit' ? d.v1 : d.v0, CA, 'roll'], [d.mode === 'hit' ? d.v2 : 0, CB, 'edge']].forEach(function (c) {
          if (!(c[0] > 0.05 * CH.V0) || tau < CH.ROLL) return;
          ctx.strokeStyle = c[1]; ctx.globalAlpha = 0.45; ctx.lineWidth = 1.2; ctx.setLineDash([3, 4]); ctx.beginPath();
          for (var j = 0; j <= 30; j++) { var tt = CH.ROLL + (tau - CH.ROLL) * j / 30, pp = ballPos(c[0], tt, c[2]), sp = fr.p(pp.x, pp.y); if (j) ctx.lineTo(sp.x, sp.y); else ctx.moveTo(sp.x, sp.y); }
          ctx.stroke(); ctx.setLineDash([]); ctx.globalAlpha = 1;
        });
        if (d.back && tau > CH.ROLL + 0.05) label(ctx, d.v1 < -0.01 ? 'm₁ < m₂：入射球被弹回！' : 'm₁ = m₂：入射球停在槽口', fr.p(-0.12, CH.H).x, fr.p(0, CH.H + 0.07).y, { size: 12, color: LOSS, bold: true });
      } else {
        ball(C0, CA, fr);
        if (hitMode) ball({ x: 0, y: CH.H }, CB, fr);
      }
      label(ctx, '入射球 m₁ = ' + o.m1 + ' g', R.x + R.w - 4, R.y + 10, { size: 12, color: CA, align: 'right', bold: true });
      label(ctx, '被碰球 m₂ = ' + o.m2 + ' g' + (hitMode ? '（放在槽口）' : '（未放）'), R.x + R.w - 4, R.y + 28, { size: 12, color: hitMode ? CB : MUTED, align: 'right' });
      paper({ x: R.x, y: R.y + sideH + gap, w: R.w, h: paperH }, fr, o);
    }
    // 记录纸俯视：横向位置与侧视一致，前后方向放大 3 倍
    function paper(R, fr, o) {
      box(ctx, R);
      var mag = 3, hh = Math.min((R.h - 24 - 34) / 2, 0.06 * fr.k * mag), cy = R.y + 24 + hh, xa = fr.p(-0.03, 0).x, xb = fr.p(X1 - 0.02, 0).x;
      ctx.fillStyle = '#d9dee6'; ctx.fillRect(xa, cy - hh, xb - xa, hh * 2);
      label(ctx, '记录纸（俯视，前后方向放大 ' + mag + ' 倍）', R.x + 8, R.y + 11, { size: 11, color: MUTED, align: 'left' });
      var Y = function (y) { return cy - y * fr.k * mag; };
      var ox = fr.p(0, 0).x;
      ctx.fillStyle = '#111'; ctx.beginPath(); ctx.arc(ox, cy, 2.5, 0, 7); ctx.fill();
      label(ctx, 'O', ox - 9, cy - 9, { size: 11, color: '#111', bold: true });
      line(ctx, ox, cy, xb, cy, 'rgba(17,17,17,.25)', { width: 1, dash: [3, 3] });
      ['P', 'M', 'N'].forEach(function (g) {
        o.pts[g].forEach(function (p) { var x = fr.p(p.x, 0).x; ctx.fillStyle = 'rgba(20,24,34,.85)'; ctx.beginPath(); ctx.arc(x, Y(p.y), 2.2, 0, 7); ctx.fill(); });
        var m = o.means[g];
        if (m) {
          var mx = fr.p(m.x, 0).x, r = Math.max(6, m.r * fr.k * mag + 3);
          ctx.strokeStyle = PCOL[g]; ctx.lineWidth = 1.6; ctx.setLineDash([4, 3]); ctx.beginPath(); ctx.arc(mx, Y(m.y), r, 0, 7); ctx.stroke(); ctx.setLineDash([]);
          line(ctx, mx - 4, Y(m.y), mx + 4, Y(m.y), PCOL[g], { width: 1.6 }); line(ctx, mx, Y(m.y) - 4, mx, Y(m.y) + 4, PCOL[g], { width: 1.6 });
          label(ctx, g, mx + r + 8, Y(m.y) - r * 0.6, { size: 12, color: PCOL[g], bold: true });
        }
      });
      // 刻度尺（cm）
      var ry = cy + hh + 4;
      ctx.fillStyle = 'rgba(201,163,107,.35)'; ctx.fillRect(ox, ry, xb - ox, 16);
      var every = 0.01 * fr.k < 5 ? 10 : 5;
      for (var c = 0; c * 0.01 <= X1 - 0.02 + 1e-9; c++) {
        var x = fr.p(c * 0.01, 0).x, big = c % every === 0;
        line(ctx, x, ry, x, ry + (big ? 7 : c % 5 === 0 ? 5 : 3), 'rgba(230,235,242,.6)', { width: 1 });
        if (big) label(ctx, String(c), x, ry + 12, { size: 9, color: TEXT });
      }
      label(ctx, 'cm', xb + 2, ry + 8, { size: 10, color: MUTED, align: 'left' });
      // 平均落点距离
      var txt = [];
      ['M', 'P', 'N'].forEach(function (g) { var m = o.means[g]; if (m) txt.push('O' + g + ' = ' + f(m.x * 100, 1) + ' cm'); });
      if (txt.length) label(ctx, txt.join('　'), R.x + R.w - 8, R.y + 11, { size: 11, color: TEXT, align: 'right', bold: true });
    }

    return {
      resize: resize, drawCollide: drawCollide, drawRatio: drawRatio, drawChute: drawChute, ballPos: ballPos,
      hit: function (name, x, y) { var h = hits[name]; return h && x >= h.x - 6 && x <= h.x + h.w + 6 && y >= h.y && y <= h.y + h.h ? h : null; },
      size: function () { return { w: W, h: H, narrow: narrow }; }, K_MIN: K_MIN, K_MAX: K_MAX, KIND: KIND
    };
  }

  window.MomDraw = { View: View };
})();
