// 动量守恒（碰撞）：计算模块（不碰 DOM）
// 单位：kg、m、s、m/s、J（斜槽实验里质量用 g、距离用 cm 读数）；一维运动向右为正
// ① 一维碰撞：气垫导轨上两辆滑块（不计摩擦）正碰，恢复系数 e = 分离速度 / 接近速度（1 弹性、0 完全非弹性）
// ② 动碰静：B 静止，A 以 v0 撞 B，速度之比只与质量比 k = m1/m2 和 e 有关
// ③ 验证动量守恒（斜槽）：入射球从同一位置滚下、在槽口撞被碰球，两球做平抛，落地时间相同 → 水平位移代替速度
(function () {
  var G = 9.8;

  function clamp(x, a, b) { return Math.max(a, Math.min(b, x)); }
  function f(x, n) { n = n == null ? 2 : n; var s = (+x).toFixed(n); s = s.indexOf('.') >= 0 ? s.replace(/0+$/, '').replace(/\.$/, '') : s; return s === '-0' ? '0' : s; }

  // 碰撞后的速度：动量守恒 m1v1 + m2v2 = m1u1 + m2u2，且 u2 − u1 = e(v1 − v2)
  function collide(m1, m2, v1, v2, e) {
    var M = m1 + m2, p = m1 * v1 + m2 * v2, dv = v1 - v2;
    return { u1: (p - m2 * e * dv) / M, u2: (p + m1 * e * dv) / M, vc: p / M };
  }
  // 碰撞损失的动能 ΔE = m1m2(1 − e²)(v1 − v2)² / [2(m1 + m2)]
  function lossE(m1, m2, v1, v2, e) { var d = v1 - v2; return m1 * m2 * (1 - e * e) * d * d / (2 * (m1 + m2)); }
  function ek(m, v) { return m * v * v / 2; }

  // ---------- ① 气垫导轨上的一维碰撞 ----------
  // 导轨长 TRACK，滑块长 CART，x 为滑块中心；两车接触时 x2 − x1 = CART
  var TRACK = 4, CART = 0.3, EDGE = CART / 2 + 0.05, T_PRE = 1.4, T_POST = 2.5;

  // o = { m1, m2, v1, v2, e }：自动摆放起点，使两车在导轨中点相碰（若追不上则不碰）
  function run(o) {
    var m1 = o.m1, m2 = o.m2, v1 = o.v1, v2 = o.v2, e = o.e;
    var lo = EDGE, hi = TRACK - EDGE, hit = v1 - v2 > 1e-9, tc = Infinity, x10, x20, c = null;
    if (hit) {
      var xc = TRACK / 2, a = xc - CART / 2, b = xc + CART / 2;
      tc = T_PRE;
      if (v1 > 0) tc = Math.min(tc, (a - lo) / v1);
      if (v2 < 0) tc = Math.min(tc, (hi - b) / -v2);
      x10 = a - v1 * tc; x20 = b - v2 * tc;
      c = collide(m1, m2, v1, v2, e);
    } else { x10 = TRACK * 0.3; x20 = TRACK * 0.7; }
    var xa = hit ? x10 + v1 * tc : 0, xb = hit ? x20 + v2 * tc : 0;
    var u1 = hit ? c.u1 : v1, u2 = hit ? c.u2 : v2;
    // 碰后（或不碰时从一开始）到某辆车碰到导轨末端为止
    function edgeT(x, v) { return v > 1e-9 ? (hi - x) / v : v < -1e-9 ? (lo - x) / v : Infinity; }
    var t0 = hit ? tc : 0, s1 = hit ? xa : x10, s2 = hit ? xb : x20;
    var tEnd = t0 + Math.min(T_POST, edgeT(s1, u1), edgeT(s2, u2));
    function at(t) {
      t = clamp(t, 0, tEnd);
      if (t < tc) return { x1: x10 + v1 * t, x2: x20 + v2 * t, v1: v1, v2: v2, after: false };
      var u = t - t0;
      return { x1: s1 + u1 * u, x2: s2 + u2 * u, v1: u1, v2: u2, after: hit };
    }
    var p0 = m1 * v1 + m2 * v2, E0 = ek(m1, v1) + ek(m2, v2);
    return {
      m1: m1, m2: m2, v1: v1, v2: v2, e: e, hit: hit, tc: tc, tEnd: tEnd, u1: u1, u2: u2,
      vc: p0 / (m1 + m2), p0: p0, E0: E0, E1: ek(m1, u1) + ek(m2, u2), dE: hit ? lossE(m1, m2, v1, v2, e) : 0, at: at
    };
  }

  // ---------- ② 动碰静：k = m1/m2，返回以 v0 为单位的碰后速度与 B 获得的动能占比 ----------
  function ratio(k, e) {
    return { a: (k - e) / (k + 1), b: (1 + e) * k / (k + 1), share: (1 + e) * (1 + e) * k / ((k + 1) * (k + 1)) };
  }

  // ---------- ③ 斜槽实验 ----------
  // 槽口离地 H（球心下落高度），入射球每次从同一位置由静止滚下，到槽口速度 V0；两球半径 R 相同
  var CH = { H: 0.45, V0: 1.3, R: 0.011, ROLL: 0.55, SIG: 0.005, SIG_Y: 0.004 };
  CH.TF = Math.sqrt(2 * CH.H / G);

  // 可复现的伪随机（mulberry32）+ 正态分布
  function rng(seed) {
    var a = seed >>> 0;
    function u() { a = (a + 0x6D2B79F5) >>> 0; var t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }
    return { u: u, n: function () { var x = u() || 1e-9, y = u(); return Math.sqrt(-2 * Math.log(x)) * Math.cos(2 * Math.PI * y); } };
  }

  // 一次释放：mode 'alone' 只放入射球，'hit' 槽口放被碰球；r 为 rng。落点含小的随机散布（每次滚下的速度、方向略有差别）
  // 返回 { v1, v2（碰后，alone 时 v2 为 null）, land: [{ ball: 1|2, x, y }]（落点，m）, back: 入射球是否被弹回或停在槽口 }
  function drop(mode, m1, m2, e, r) {
    var k = 1 + r.n() * 0.006, v0 = CH.V0 * k, out = { mode: mode, v0: v0, land: [], back: false };
    function land(ball, v) { out.land.push({ ball: ball, x: v * CH.TF + r.n() * CH.SIG, y: r.n() * CH.SIG_Y }); }
    if (mode === 'alone') { out.v1 = v0; out.v2 = null; land(1, v0); return out; }
    var c = collide(m1, m2, v0, 0, e);
    out.v1 = c.u1; out.v2 = c.u2;
    if (c.u1 > 0.05 * CH.V0) land(1, c.u1); else out.back = true;
    land(2, c.u2);
    return out;
  }

  // 落点统计：平均落点（用最小的圆把落点圈起来，圆心视为平均落点）及半径
  function mean(pts) {
    if (!pts.length) return null;
    var x = 0, y = 0;
    pts.forEach(function (p) { x += p.x; y += p.y; });
    x /= pts.length; y /= pts.length;
    var r = 0;
    pts.forEach(function (p) { r = Math.max(r, Math.hypot(p.x - x, p.y - y)); });
    return { x: x, y: y, r: r, n: pts.length };
  }
  // 由 OP、OM、ON（m）验证：m1·OP 与 m1·OM + m2·ON（g·cm）；弹性时还有 OP + OM = ON
  function verify(m1, m2, OP, OM, ON) {
    var L = m1 * OP * 100, R = m1 * OM * 100 + m2 * ON * 100;
    return { L: L, R: R, err: Math.abs(R - L) / L, E0: m1 * OP * OP * 1e4, E1: m1 * OM * OM * 1e4 + m2 * ON * ON * 1e4, sum: (OP + OM) * 100, on: ON * 100 };
  }

  window.Mom = {
    G: G, f: f, clamp: clamp, collide: collide, lossE: lossE, ek: ek,
    TRACK: TRACK, CART: CART, run: run, ratio: ratio,
    CH: CH, rng: rng, drop: drop, mean: mean, verify: verify
  };
})();
