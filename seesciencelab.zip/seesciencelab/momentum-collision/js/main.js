(function () {
  var M = window.Mom, D = window.MomDraw, f = M.f, clamp = M.clamp, CH = M.CH;
  var $ = function (id) { return document.getElementById(id); };
  var qa = function (sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); };
  var NAME = '动量守恒';

  var state = {
    scene: 'collide',
    slows: { collide: 0.5, ratio: 0.5, chute: 0.25 },
    type: 'elastic', eIn: 0.5,
    // ① 一维碰撞
    m1: 1, m2: 1, v1: 2, v2: 0, preset: 'equal', run: null, t: 0, playing: false, paused: false, bars: true, graph: true,
    // ② 动碰静
    k: 1, rrun: null, rt: 0, rPlaying: false,
    // ③ 斜槽
    cm1: 30, cm2: 10, mode: 'alone', pts: { P: [], M: [], N: [] }, anim: null, seed: 1
  };
  var PRESETS = {
    equal: { m1: 1, m2: 1, v1: 2, v2: 0, type: 'elastic' },
    big:   { m1: 3, m2: 1, v1: 2, v2: 0, type: 'elastic' },
    small: { m1: 1, m2: 3, v1: 2, v2: 0, type: 'elastic' },
    head:  { m1: 1, m2: 2, v1: 3, v2: -1.5, type: 'elastic' },
    chase: { m1: 2, m2: 1, v1: 3, v2: 1, type: 'elastic' },
    stick: { m1: 1, m2: 1, v1: 2, v2: 0, type: 'perfect' }
  };
  var TYPES = { elastic: '弹性碰撞', inelastic: '非弹性碰撞', perfect: '完全非弹性碰撞' };
  var HINTS = {
    collide: '两辆滑块在气垫导轨上正碰：看碰撞前后的总动量和总动能',
    ratio: 'A 撞静止的 B：质量比决定碰后谁快谁慢、A 是否被弹回',
    chute: '斜槽实验：用平抛的水平位移代替速度，验证 m₁·OP = m₁·OM + m₂·ON'
  };
  var V0 = 2;   // 动碰静场景 A 的初速度

  var stage = $('stage'), panel = $('panel'), cv = $('view');
  var view = D.View(cv);
  function setSeg(attr, val) { qa('[data-' + attr + ']').forEach(function (b) { b.classList.toggle('on', b.dataset[attr] === String(val)); }); }
  function e() { return state.type === 'elastic' ? 1 : state.type === 'perfect' ? 0 : state.eIn; }

  // ---------- ① 一维碰撞 ----------
  function resetCollide() { state.run = M.run({ m1: state.m1, m2: state.m2, v1: state.v1, v2: state.v2, e: e() }); state.t = 0; state.playing = false; state.paused = false; }
  function playCollide() {
    if (state.t >= state.run.tEnd - 1e-6) state.t = 0;
    state.playing = true; state.paused = false; syncUI();
    Analytics.track(NAME, '开始碰撞', TYPES[state.type]);
  }
  function applyPreset(k) {
    var p = PRESETS[k]; if (!p) return;
    state.preset = k; state.m1 = p.m1; state.m2 = p.m2; state.v1 = p.v1; state.v2 = p.v2; state.type = p.type;
    resetAll(); syncUI();
  }

  // ---------- ② 动碰静 ----------
  function resetRatio() { state.rrun = M.run({ m1: state.k, m2: 1, v1: V0, v2: 0, e: e() }); state.rt = 0; state.rPlaying = false; state.paused = false; }
  function playRatio() {
    if (state.rt >= state.rrun.tEnd - 1e-6) state.rt = 0;
    state.rPlaying = true; state.paused = false; syncUI();
  }
  function setK(k) { state.k = Math.round(clamp(k, view.K_MIN, view.K_MAX) * 100) / 100; resetRatio(); syncUI(); }

  // ---------- ③ 斜槽 ----------
  function rnd() { return M.rng(state.seed++ * 7919); }
  function commit(d) {
    d.land.forEach(function (p) { (d.mode === 'alone' ? state.pts.P : p.ball === 1 ? state.pts.M : state.pts.N).push(p); });
  }
  function animEnd(d) {
    var t = CH.ROLL;
    [d.mode === 'hit' ? d.v1 : d.v0].forEach(function (v) { if (v > 0.05 * CH.V0) t = Math.max(t, CH.ROLL + 2 * CH.R / v + CH.TF); });
    if (d.mode === 'hit') t = Math.max(t, CH.ROLL + CH.TF);
    return t + 0.3;
  }
  function finishAnim() { if (state.anim) { commit(state.anim.d); state.anim = null; } }
  function dropBalls(mode, n) {
    finishAnim();
    state.mode = mode;
    for (var i = 0; i < n - 1; i++) commit(M.drop(mode, state.cm1, state.cm2, e(), rnd()));
    var d = M.drop(mode, state.cm1, state.cm2, e(), rnd());
    state.anim = { d: d, tau: 0, end: animEnd(d) }; state.paused = false;
    syncUI();
    Analytics.track(NAME, mode === 'alone' ? '只放入射球' : '两球相碰', n + ' 次');
  }
  function clearHit() { finishAnim(); state.pts.M = []; state.pts.N = []; }
  function means() { return { P: M.mean(state.pts.P), M: M.mean(state.pts.M), N: M.mean(state.pts.N) }; }

  function resetAll() { resetCollide(); resetRatio(); clearHit(); }

  // ---------- 控件 ----------
  qa('[data-scene]').forEach(function (b) {
    b.addEventListener('click', function () { setScene(b.dataset.scene); Analytics.track(NAME, '场景', b.textContent); });
  });
  function setScene(sc) { state.scene = sc; state.paused = false; syncUI(); }
  qa('[data-type]').forEach(function (b) {
    b.addEventListener('click', function () { state.type = b.dataset.type; state.preset = ''; resetAll(); syncUI(); Analytics.track(NAME, '碰撞类型', TYPES[state.type]); });
  });
  qa('[data-preset]').forEach(function (b) {
    b.addEventListener('click', function () { applyPreset(b.dataset.preset); playCollide(); Analytics.track(NAME, '预设', b.textContent); });
  });
  qa('[data-k]').forEach(function (b) {
    b.addEventListener('click', function () { setK(parseFloat(b.dataset.k)); playRatio(); Analytics.track(NAME, '质量比', b.textContent); });
  });
  qa('[data-slow]').forEach(function (b) {
    b.addEventListener('click', function () { state.slows[state.scene] = parseFloat(b.dataset.slow); syncUI(); Analytics.track(NAME, '播放速度', b.textContent); });
  });

  // 滑块：[id, state 键, 换算]
  [['m1', 'm1'], ['m2', 'm2'], ['v1', 'v1'], ['v2', 'v2']].forEach(function (c) {
    var el = $(c[0]);
    el.addEventListener('input', function () { state[c[1]] = parseFloat(el.value); state.preset = ''; resetCollide(); syncUI(); });
    el.addEventListener('change', function () { Analytics.track(NAME, '滑块', c[0]); });
  });
  $('eIn').addEventListener('input', function () { state.eIn = parseFloat($('eIn').value); resetAll(); syncUI(); });
  $('eIn').addEventListener('change', function () { Analytics.track(NAME, '滑块', '恢复系数'); });
  $('kr').addEventListener('input', function () { setK(Math.pow(10, parseFloat($('kr').value))); });
  $('kr').addEventListener('change', function () { Analytics.track(NAME, '滑块', '质量比'); });
  [['cm1', 'cm1'], ['cm2', 'cm2']].forEach(function (c) {
    var el = $(c[0]);
    el.addEventListener('input', function () { state[c[1]] = parseInt(el.value, 10); clearHit(); syncUI(); });
    el.addEventListener('change', function () { Analytics.track(NAME, '滑块', c[0]); });
  });
  $('bars').addEventListener('change', function () { state.bars = $('bars').checked; });
  $('graph').addEventListener('change', function () { state.graph = $('graph').checked; });

  $('playBtn').addEventListener('click', playCollide);
  $('resetBtn').addEventListener('click', function () { resetCollide(); syncUI(); });
  $('rPlayBtn').addEventListener('click', playRatio);
  $('aloneBtn').addEventListener('click', function () { dropBalls('alone', 1); });
  $('hitBtn').addEventListener('click', function () { dropBalls('hit', 1); });
  $('tenBtn').addEventListener('click', function () { dropBalls('alone', 10); finishAnim(); dropBalls('hit', 10); });
  $('clearBtn').addEventListener('click', function () { finishAnim(); state.pts = { P: [], M: [], N: [] }; syncUI(); });

  function running() {
    var sc = state.scene;
    return sc === 'collide' ? state.playing : sc === 'ratio' ? state.rPlaying : !!state.anim;
  }
  function startScene() {
    if (state.scene === 'collide') playCollide();
    else if (state.scene === 'ratio') playRatio();
    else dropBalls(state.pts.P.length ? 'hit' : 'alone', 1);
  }
  function togglePause() { if (!running()) { startScene(); return; } state.paused = !state.paused; syncUI(); }
  qa('.pause').forEach(function (b) { b.addEventListener('click', togglePause); });

  // 画布：拖动 v-t 图像改时刻、拖动比值图像改质量比；点其他地方开始 / 暂停
  var drag = null;
  function local(ev) { var r = cv.getBoundingClientRect(); return { x: ev.clientX - r.left, y: ev.clientY - r.top }; }
  cv.addEventListener('pointerdown', function (ev) {
    if (ev.button) return;
    var p = local(ev), h;
    if (state.scene === 'collide' && (h = view.hit('vt', p.x, p.y))) {
      drag = { kind: 'vt', h: h }; state.playing = false; state.t = h.t(p.x);
    } else if (state.scene === 'ratio' && (h = view.hit('ratio', p.x, p.y))) {
      drag = { kind: 'ratio', h: h }; setK(h.k(p.x));
    } else { togglePause(); return; }
    cv.setPointerCapture(ev.pointerId); ev.preventDefault(); syncUI();
  });
  cv.addEventListener('pointermove', function (ev) {
    if (!drag) return;
    var p = local(ev);
    if (drag.kind === 'vt') state.t = drag.h.t(p.x);
    else { var k = drag.h.k(p.x); if (Math.abs(k - state.k) > 0.005) setK(k); }
  });
  function endDrag() {
    if (!drag) return;
    if (drag.kind === 'ratio') { playRatio(); Analytics.track(NAME, '拖动', '质量比'); } else Analytics.track(NAME, '拖动', 'v-t 图像');
    drag = null;
  }
  cv.addEventListener('pointerup', endDrag);
  cv.addEventListener('pointercancel', endDrag);

  // ---------- 面板 ----------
  $('panelToggle').addEventListener('click', function () { panel.classList.toggle('collapsed'); });
  if (window.matchMedia('(max-width: 760px)').matches) panel.classList.add('collapsed');
  window.addEventListener('keydown', function (ev) {
    var tg = ev.target.tagName;
    if (tg === 'INPUT' || tg === 'SELECT' || tg === 'BUTTON' || tg === 'TEXTAREA') return;
    if (ev.code === 'Space') { ev.preventDefault(); togglePause(); }
  });

  function syncUI() {
    var sc = state.scene;
    setSeg('scene', sc);
    qa('[data-for]').forEach(function (el) { el.hidden = el.dataset.for.split(' ').indexOf(sc) < 0; });
    $('hint').textContent = HINTS[sc];
    setSeg('type', state.type); setSeg('preset', state.preset); setSeg('slow', state.slows[sc]); setSeg('k', state.k);
    $('eRow').hidden = state.type !== 'inelastic';
    $('eIn').value = state.eIn; $('eOut').textContent = 'e = ' + f(state.eIn);
    ['m1', 'm2', 'v1', 'v2'].forEach(function (k) { $(k).value = state[k]; });
    $('m1Out').textContent = f(state.m1, 1) + ' kg'; $('m2Out').textContent = f(state.m2, 1) + ' kg';
    $('v1Out').textContent = f(state.v1, 1) + ' m/s'; $('v2Out').textContent = f(state.v2, 1) + ' m/s';
    $('kr').value = Math.log10(state.k); $('kOut').textContent = f(state.k, state.k < 1 ? 2 : 1);
    $('cm1').value = state.cm1; $('cm2').value = state.cm2;
    $('cm1Out').textContent = state.cm1 + ' g'; $('cm2Out').textContent = state.cm2 + ' g';
    $('bars').checked = state.bars; $('graph').checked = state.graph;
    qa('.pause').forEach(function (b) { b.textContent = running() && state.paused ? '▶ 继续' : '❚❚ 暂停'; b.disabled = !running(); });
    $('massWarn').hidden = state.cm1 > state.cm2;
    renderTable();
  }

  // 斜槽实验记录与验证
  function renderTable() {
    var m = means(), html = '<thead><tr><th>落点</th><th>次数</th><th>平均距离</th></tr></thead><tbody>';
    [['P', '入射球单独落下'], ['M', '碰后入射球'], ['N', '碰后被碰球']].forEach(function (c) {
      var q = m[c[0]];
      html += '<tr><td>' + c[0] + '　' + c[1] + '</td><td>' + (q ? q.n : 0) + '</td><td>' + (q ? 'O' + c[0] + ' = ' + f(q.x * 100, 1) + ' cm' : '—') + '</td></tr>';
    });
    $('table').innerHTML = html + '</tbody>';
    var out = '';
    if (m.P && m.M && m.N) {
      var v = M.verify(state.cm1, state.cm2, m.P.x, m.M.x, m.N.x);
      out = '<tr><td>m₁·OP</td><td>' + f(v.L, 0) + ' g·cm</td></tr>'
        + '<tr><td>m₁·OM + m₂·ON</td><td>' + f(v.R, 0) + ' g·cm</td></tr>'
        + '<tr><td>相对误差</td><td>' + f(v.err * 100, 1) + '%' + (v.err < 0.05 ? '　✓ 动量守恒' : '') + '</td></tr>'
        + '<tr><td>OP + OM</td><td>' + f(v.sum, 1) + ' cm（ON = ' + f(v.on, 1) + ' cm）</td></tr>';
    } else if (m.P && m.N && !m.M) {
      out = '<tr><td colspan="2">入射球没有落点 M，无法验证——要求 m₁ &gt; m₂</td></tr>';
    } else out = '<tr><td colspan="2">先“只放入射球”找 P，再“放上被碰球”找 M、N</td></tr>';
    $('verify').innerHTML = '<tbody>' + out + '</tbody>';
  }

  // ---------- 读数 ----------
  var lastText = {};
  function setText(id, s) { if (lastText[id] !== s) { lastText[id] = s; $(id).textContent = s; } }
  function rows(list) {
    for (var k = 1; k <= 5; k++) {
      var r = list[k - 1] || ['', ''];
      setText('d' + k, r[0]); setText('r' + k, r[1]);
      $('d' + k).hidden = $('r' + k).hidden = !r[0];
    }
  }
  function sv(v) { return (v > 0.005 ? '+' : '') + f(v); }

  function readCollide() {
    var r = state.run, s = r.at(state.t);
    setText('rName', TYPES[state.type]);
    setText('rKind', !r.hit ? '不相碰' : s.after ? '碰后' : '碰前');
    var tip;
    if (!r.hit) tip = 'A 的速度不大于 B，追不上 B。把 v₁ 调大，或让 B 向左运动。';
    else if (!s.after) tip = '碰撞前：总动量 p = m₁v₁ + m₂v₂ = ' + f(r.p0) + ' kg·m/s。系统在水平方向不受外力，碰撞后总动量不变。';
    else if (state.type === 'elastic') tip = Math.abs(r.m1 - r.m2) < 1e-9 && Math.abs(r.v2) < 1e-9 ? '质量相等的弹性碰撞：两车交换速度，A 停下、B 以 A 原来的速度运动。' : '弹性碰撞：总动量和总动能都不变。';
    else if (state.type === 'perfect') tip = '完全非弹性碰撞：碰后两车粘在一起，以共同速度 v = ' + f(r.u1) + ' m/s 运动，动能损失最多。';
    else tip = '非弹性碰撞：总动量不变，但有 ' + f(r.dE) + ' J 动能转化为内能等其他形式的能。';
    setText('rTip', tip);
    rows([
      ['A 速度', r.hit ? sv(r.v1) + ' → ' + sv(r.u1) + ' m/s' : sv(r.v1) + ' m/s'],
      ['B 速度', r.hit ? sv(r.v2) + ' → ' + sv(r.u2) + ' m/s' : sv(r.v2) + ' m/s'],
      ['总动量', f(r.p0) + ' kg·m/s' + (r.hit ? '（碰前 = 碰后）' : '')],
      ['总动能', r.hit ? f(r.E0) + ' → ' + f(r.E1) + ' J' : f(r.E0) + ' J'],
      ['时间', 't = ' + f(state.t) + ' s']
    ]);
  }
  function readRatio() {
    var q = M.ratio(state.k, e()), k = state.k;
    setText('rName', 'm₁ : m₂ = ' + f(k, k < 1 ? 2 : 1) + ' : 1');
    setText('rKind', TYPES[state.type]);
    var tip;
    if (state.type === 'perfect') tip = '完全非弹性：碰后共同速度 v = m₁v₀/(m₁ + m₂)，质量比越大越接近 v₀。';
    else if (Math.abs(k - 1) < 0.005 && state.type === 'elastic') tip = '质量相等：交换速度，A 停下，B 以 v₀ 运动，B 得到全部动能。';
    else if (q.a < -1e-6) tip = 'm₁ < ' + (state.type === 'elastic' ? 'm₂' : 'e·m₂') + '：A 被弹回。B 很重时 A 几乎以原速率弹回，B 几乎不动。';
    else if (k > 1) tip = 'm₁ > m₂：两球都向前运动，B 比 A 快。A 很重时 A 速度几乎不变，B 以接近 ' + f(1 + e()) + 'v₀ 的速度飞出。';
    else tip = 'A 碰后停下或继续向前，B 向前运动。';
    setText('rTip', tip);
    rows([
      ['A 碰后', 'v₁′ = ' + f(q.a) + 'v₀ = ' + sv(q.a * V0) + ' m/s'],
      ['B 碰后', 'v₂′ = ' + f(q.b) + 'v₀ = ' + sv(q.b * V0) + ' m/s'],
      ['B 得动能', f(q.share * 100, 1) + '%'],
      state.type === 'elastic' ? ['弹性公式', 'v₁′ = (m₁−m₂)v₀/(m₁+m₂)，v₂′ = 2m₁v₀/(m₁+m₂)'] : state.type === 'perfect' ? ['共速', 'v = m₁v₀/(m₁+m₂)'] : ['公式', 'v₁′ = (m₁−em₂)v₀/(m₁+m₂)，v₂′ = (1+e)m₁v₀/(m₁+m₂)']
    ]);
  }
  function readChute() {
    var m = means(), a = state.anim;
    setText('rName', '验证动量守恒定律');
    setText('rKind', a ? (a.d.mode === 'alone' ? '入射球单独滚下' : '两球相碰') : '等待释放');
    var tip;
    if (state.cm1 <= state.cm2) tip = 'm₁ ≤ m₂ 时入射球会被弹回（或停在槽口），没有落点 M。应选质量较大的球作入射球。';
    else if (!m.P) tip = '先不放被碰球，让入射球从斜槽上同一位置滚下多次，找出它的平均落点 P。';
    else if (!m.M || !m.N) tip = '再把被碰球放在槽口，入射球仍从同一位置滚下，找出碰后两球的平均落点 M、N。';
    else tip = '两球从同一高度平抛、落地时间相同，水平位移与速度成正比：m₁v₀ = m₁v₁ + m₂v₂ ⇔ m₁·OP = m₁·OM + m₂·ON。';
    setText('rTip', tip);
    var d = a ? a.d : null;
    rows([
      ['入射球 v₀', d ? f(d.v0) + ' m/s' : '≈ ' + f(CH.V0) + ' m/s'],
      ['碰后', d && d.mode === 'hit' ? 'v₁ = ' + f(d.v1) + '，v₂ = ' + f(d.v2) + ' m/s' : '—'],
      ['下落时间', 't = √(2H/g) = ' + f(CH.TF, 3) + ' s'],
      ['落点次数', 'P ' + state.pts.P.length + '　M ' + state.pts.M.length + '　N ' + state.pts.N.length]
    ]);
  }

  // ---------- 尺寸与主循环 ----------
  function resize() { view.resize(stage.clientWidth, stage.clientHeight); }
  new ResizeObserver(resize).observe(stage);

  // 支持 ?scene=collide|ratio|chute；通用 &type=elastic|inelastic|perfect、&e=0.1~0.9（非弹性的恢复系数）、&slow=1|0.5|0.25、&t=（秒，停在该时刻）；
  // 碰撞 &preset=equal|big|small|head|chase|stick、&m1=0.5~4、&m2=、&v1=-4~4、&v2=、&bars=0、&graph=0；动碰静 &k=0.1~10；
  // 斜槽 &m1=10~50、&m2=（g）、&runs=1~20（预填 P、M、N 各 n 次）
  var qs = new URLSearchParams(location.search);
  if (HINTS[qs.get('scene')]) state.scene = qs.get('scene');
  if (PRESETS[qs.get('preset')]) applyPreset(qs.get('preset'));
  if (TYPES[qs.get('type')]) state.type = qs.get('type');
  var x = parseFloat(qs.get('e'));
  if (x >= 0.1 && x <= 0.9) { state.eIn = Math.round(x * 20) / 20; state.type = 'inelastic'; }
  function num(name, lo, hi, step) { var v = parseFloat(qs.get(name)); return v >= lo && v <= hi ? Math.round(v / step) * step : null; }
  if (state.scene === 'chute') {
    if ((x = num('m1', 10, 50, 1)) != null) state.cm1 = x;
    if ((x = num('m2', 10, 50, 1)) != null) state.cm2 = x;
  } else {
    ['m1', 'm2'].forEach(function (k) { var v = num(k, 0.5, 4, 0.1); if (v != null) { state[k] = +v.toFixed(1); state.preset = ''; } });
    ['v1', 'v2'].forEach(function (k) { var v = num(k, -4, 4, 0.1); if (v != null) { state[k] = +v.toFixed(1); state.preset = ''; } });
  }
  if ((x = num('k', 0.1, 10, 0.01)) != null) state.k = +x.toFixed(2);
  if (qs.get('bars') === '0') state.bars = false;
  if (qs.get('graph') === '0') state.graph = false;
  x = parseFloat(qs.get('slow'));
  if ([1, 0.5, 0.25].indexOf(x) >= 0) state.slows[state.scene] = x;

  resetAll();
  x = parseInt(qs.get('runs'), 10);
  if (x >= 1 && x <= 20) { for (var i = 0; i < x; i++) { commit(M.drop('alone', state.cm1, state.cm2, e(), rnd())); commit(M.drop('hit', state.cm1, state.cm2, e(), rnd())); } }
  resize();
  setScene(state.scene);
  x = parseFloat(qs.get('t'));
  if (x > 0 && x < 30) {
    if (state.scene === 'collide') { state.playing = true; state.t = Math.min(x, state.run.tEnd); }
    else if (state.scene === 'ratio') { state.rPlaying = true; state.rt = Math.min(x, state.rrun.tEnd); }
    else { dropBalls('hit', 1); state.anim.tau = Math.min(x, state.anim.end - 0.31); }
    state.paused = true; syncUI();
  }

  var lastT = performance.now(), wasRunning = null;
  function frame(now) {
    var dt = Math.min((now - lastT) / 1000, 0.1) * state.slows[state.scene];
    lastT = now;
    var sc = state.scene;
    if (!state.paused) {
      if (sc === 'collide' && state.playing) { state.t += dt; if (state.t >= state.run.tEnd) { state.t = state.run.tEnd; state.playing = false; } }
      if (sc === 'ratio' && state.rPlaying) { state.rt += dt; if (state.rt >= state.rrun.tEnd) { state.rt = state.rrun.tEnd; state.rPlaying = false; } }
      if (sc === 'chute' && state.anim) { state.anim.tau += dt; if (state.anim.tau >= state.anim.end) { finishAnim(); syncUI(); } }
    }
    if (running() !== wasRunning) { wasRunning = running(); syncUI(); }

    var kind = state.type;
    if (sc === 'collide') { view.drawCollide({ run: state.run, t: state.t, kind: kind, bars: state.bars, graph: state.graph }); readCollide(); }
    else if (sc === 'ratio') { view.drawRatio({ run: state.rrun, t: state.rt, kind: kind, k: state.k, e: e() }); readRatio(); }
    else { view.drawChute({ anim: state.anim, pts: state.pts, means: means(), m1: state.cm1, m2: state.cm2, mode: state.mode }); readChute(); }
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // 调试用
  window.__model = {
    state: state, setScene: setScene, syncUI: syncUI, applyPreset: applyPreset, play: startScene, setK: setK, drop: dropBalls,
    set: function (o) { Object.keys(o).forEach(function (k) { state[k] = o[k]; }); state.preset = ''; resetAll(); syncUI(); }
  };
})();
