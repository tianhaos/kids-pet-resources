(function () {
  'use strict';
  const $=id=>document.getElementById(id),p=new URLSearchParams(location.search);
  const state={...Oersted.clean({scene:p.get('scene'),current:p.get('current'),turns:p.get('turns'),x:p.get('x'),z:p.get('z'),on:p.get('on')!=='0',reverse:p.get('reverse')==='1',earth:p.get('earth')!=='0',lines:p.get('lines')!=='0'}),mode:'auto',records:[],drag:false};
  const track=(action,value)=>window.Analytics?.track('奥斯特实验与通电螺线管',action,String(value??state.scene));
  function solve(){return Oersted.solve(state);}
  function update() {
    Object.assign(state,Oersted.clean(state));Oersted.relocate(state);const q=solve();
    for(const k of ['current','turns','x','z']){$(k).value=state[k];$(k+'Out').textContent=k==='turns'?state[k]+'匝':state[k].toFixed(k==='current'?1:2)+(k==='current'?'A':'');}
    for(const k of ['earth','lines'])$(k).checked=state[k];
    $('turnsRow').hidden=state.scene!=='solenoid';
    $('reading').textContent=q.angle===null?'水平场为零':q.angle.toFixed(1)+'°';
    $('fieldValue').textContent=q.sourceStrength.toFixed(1)+' μT';
    $('north').textContent=state.scene==='solenoid'?q.pole:(state.on&&state.current>0?(state.reverse?'电流向南':'电流向北'):'导线无电流');
    $('status').textContent=state.on&&state.current>0?'通电':'断电 / 零电流';
    $('power').textContent=state.on?'断开开关':'闭合开关';$('reverse').textContent=state.reverse?'恢复电流方向':'反接电源';
    $('mode').textContent=state.mode==='probe'?'全画面探测：已开启':'全画面探测';$('mode').classList.toggle('on',state.mode==='probe');
    $('hint').textContent=state.mode==='probe'?'拖动画面移动探针 · 再点「全画面探测」退出':'拖动空白处旋转 · 拖住磁针移动 · 滚轮 / 双指缩放';
    $('sceneNote').textContent=state.scene==='wire'?'磁针始终在南北导线下方的水平面，只按水平合场定向。探测平面上方才是导线，3D透视不代表二者相接。':'磁针在通过线圈轴线的水平面内转动；可拖到线圈内部。每匝圆电流同向，细桥线仅示串联，引线场未计。';
    $('stageAngle').textContent=q.angle===null?'—':q.angle.toFixed(1)+'°';$('stageField').textContent=q.sourceStrength.toFixed(1)+' μT';$('stageStatus').textContent=state.on?(state.current>0?'通电':'零电流'):'断电';$('stageTitle').textContent=Oersted.names[state.scene];
    const active=state.on&&state.current>0;
    $('stagePower').textContent=state.on?'⏻ 断开开关':'⏻ 闭合开关';
    $('stagePower').classList.toggle('off',!active);
    $('stagePower').setAttribute('aria-pressed',String(state.on));
    $('power').setAttribute('aria-pressed',String(state.on));
    $('reverse').setAttribute('aria-pressed',String(state.reverse));
    $('stageReverse').setAttribute('aria-pressed',String(state.reverse));
    $('stageStatus').classList.toggle('off',!active);
    $('stageSubtitle').textContent=state.scene==='wire'?'反接电源，观察磁针 N 端的变化':'从管内到管外，探索磁场的方向';
    $('observation').textContent=q.angle===null?'水平合场为零 · 磁针方向未定':!active?(state.earth?'装置场消失，地磁使 N 端指北':'装置场为零'):state.scene==='wire'?(state.earth?'装置场与地磁叠加，N 端沿水平合场定向':'已关闭地磁，N 端沿装置场的水平投影定向'):'反接电源，两端磁极与装置场方向一起反转';
    document.querySelectorAll('[data-scene]').forEach(b=>{b.classList.toggle('on',b.dataset.scene===state.scene);b.setAttribute('aria-pressed',b.dataset.scene===state.scene);});
    OerstedScene.render(state,q);
  }
  function setScene(scene) {
    if(!Object.hasOwn(Oersted.names,scene))return;
    Object.assign(state,{scene,x:scene==='wire'?0:2.35,z:0,reverse:false,on:true});OerstedScene.resetView();update();track('场景');
  }
  function setProbe(x,z){state.x=x;state.z=z;update();}
  function link(){const u=new URL(location.href);u.search='';u.hash='';for(const k of ['scene','current','turns','x','z','on','reverse','earth','lines'])u.searchParams.set(k,typeof state[k]==='boolean'?(state[k]?'1':'0'):state[k]);return u.href;}
  const api={state,solve,update,setScene,setProbe,link,viewState:()=>OerstedScene.viewState()};window.__model=api;
  const canvas=OerstedScene.init($('stage'),api);
  api.screenPoint=(x,z)=>{const r=canvas.getBoundingClientRect(),s=OerstedScene.screenPoint(x,state.scene==='wire'?0:.85,z);return {x:s.x+r.x,y:s.y+r.y};};
  document.querySelectorAll('[data-scene]').forEach(b=>b.onclick=()=>setScene(b.dataset.scene));
  for(const k of ['current','turns','x','z']){$(k).oninput=()=>{state[k]=Number($(k).value);update();};$(k).onchange=()=>track('参数',k+':'+state[k]);}
  for(const k of ['earth','lines'])$(k).onchange=()=>{state[k]=$(k).checked;update();track('显示',k+':'+state[k]);};
  function power(){state.on=!state.on;update();track('开关',state.on);}
  function reverse(){state.reverse=!state.reverse;update();track('反接');}
  $('power').onclick=power;$('reverse').onclick=reverse;$('stagePower').onclick=power;$('stageReverse').onclick=reverse;
  $('mode').onclick=()=>{state.mode=state.mode==='probe'?'auto':'probe';OerstedScene.enableOrbit(state.mode==='auto');update();track('交互模式',state.mode);};
  $('view').onclick=()=>{OerstedScene.resetView();update();};$('stageReset').onclick=$('view').onclick;
  $('top').onclick=()=>{OerstedScene.resetView(true);update();track('俯视');};
  $('record').onclick=()=>{const q=solve(),text=`${Oersted.names[state.scene]} · ${state.on?state.current:0}A${state.reverse?'反向':''} · ${state.turns}匝 · (${state.x.toFixed(2)},${state.z.toFixed(2)}) · ${q.angle===null?'方向未定':q.angle.toFixed(1)+'°'} · 装置场${q.sourceStrength.toFixed(1)}μT · 地磁${state.earth?'开':'关'}`;state.records.push(text);if(state.records.length>6)state.records.shift();$('records').replaceChildren(...state.records.map(t=>{const p=document.createElement('p');p.textContent=t;return p;}));track('记录');};
  $('clear').onclick=()=>{state.records=[];$('records').replaceChildren();};
  $('share').onclick=async()=>{const u=link();try{await navigator.clipboard.writeText(u);$('shareNote').textContent='已复制当前实验条件，打开后保持此位置。';}catch{$('shareNote').textContent=u;}track('分享');};
  if(matchMedia('(max-width:760px)').matches)$('panel').classList.add('collapsed');
  $('panelToggle').onclick=()=>{$('panelToggle').setAttribute('aria-expanded',String(!$('panel').classList.toggle('collapsed')));};
  let press=null;
  // 捕获阶段决定手势归属：磁针优先拖动，其余区域交给OrbitControls。
  canvas.addEventListener('pointerdown',e=>{
    const a=OerstedScene.action(e);
    if(a){press={x:e.clientX,y:e.clientY,action:a};canvas.setPointerCapture(e.pointerId);OerstedScene.enableOrbit(false);return;}
    if(state.mode!=='probe'&&!OerstedScene.hitProbe(e)){OerstedScene.enableOrbit(true);return;}
    const pt=OerstedScene.point(e,state);if(!pt)return;
    OerstedScene.enableOrbit(false);e.preventDefault();state.drag=true;
    canvas.setPointerCapture(e.pointerId);setProbe(pt.x,pt.z);
  },true);
  canvas.addEventListener('pointermove',e=>{
    canvas.style.cursor=state.drag?'grabbing':OerstedScene.action(e)?'pointer':OerstedScene.hitProbe(e)?'move':'grab';
    if(!state.drag)return;const pt=OerstedScene.point(e,state);if(pt)setProbe(pt.x,pt.z);
  });
  function release(e){
    if(press&&e&&Math.hypot(e.clientX-press.x,e.clientY-press.y)<8){press.action==='switch'?power():reverse();}
    press=null;if(state.drag)track('拖动磁针');state.drag=false;
    OerstedScene.enableOrbit(state.mode==='auto');
  }
  canvas.addEventListener('pointerup',release);canvas.addEventListener('pointercancel',()=>{press=null;release();});
  canvas.addEventListener('keydown',e=>{const d={ArrowLeft:[-.1,0],ArrowRight:[.1,0],ArrowUp:[0,-.1],ArrowDown:[0,.1]}[e.key];if(d){e.preventDefault();setProbe(state.x+d[0],state.z+d[1]);}});
  window.addEventListener('resize',update);
  update();function frame(){OerstedScene.render(state,solve());requestAnimationFrame(frame);}requestAnimationFrame(frame);
}());
