(function () {
  'use strict';
  // 三维右手坐标：x向右，y向上，z向南；1绘图单位=0.05m。
  const names = {wire:'奥斯特实验',solenoid:'通电螺线管'};
  const finite=(v,d,a,b)=>v===null||v===''||!Number.isFinite(Number(v))?d:Math.max(a,Math.min(b,Number(v)));
  function clean(s) {
    const scene=s.scene==='solenoid'?'solenoid':'wire';
    return {scene,current:finite(s.current,3,0,4),turns:Math.round(finite(s.turns,8,4,16)),
      reverse:!!s.reverse,on:s.on!==false,earth:s.earth!==false,lines:s.lines!==false,
      x:finite(s.x,scene==='wire'?0:2.35,-3,3),z:finite(s.z,0,-2,2)};
  }
  const cache=new Map();
  // 忽略螺距和引线：与可见线圈对应的N个同向圆电流，各64段中点积分。
  function loops(n) {
    if(cache.has(n))return cache.get(n);
    const out=[],da=2*Math.PI/64;
    for(let j=0;j<n;j++)for(let k=0;k<64;k++) {
      const a=(k+.5)*da;
      out.push({x:-1.6+3.2*(j+.5)/n,y:.65*Math.cos(a),z:.65*Math.sin(a),dy:-.65*Math.sin(a)*da,dz:.65*Math.cos(a)*da});
    }
    cache.set(n,out);return out;
  }
  function coil(n,x,y,z) {
    let bx=0,by=0,bz=0;
    for(const p of loops(n)) {
      const rx=x-p.x,ry=y-p.y,rz=z-p.z,r=Math.hypot(rx,ry,rz);
      // 实体邻域不探测；这个保护仅防止场线积分遇到奇点。
      const f=2/Math.pow(Math.max(r,.06),3);
      bx+=(p.dy*rz-p.dz*ry)*f;by+=p.dz*rx*f;bz-=p.dy*rx*f;
    }
    return {x:bx,y:by,z:bz};
  }
  function source(s,x=s.x,z=s.z) {
    const i=s.on?s.current*(s.reverse?-1:1):0;
    if(s.scene==='solenoid') {const b=coil(s.turns,x,0,z);return {x:b.x*i,y:b.y*i,z:b.z*i};}
    const r2=x*x+.65*.65;
    // 直导线电流朝北(-z)，B=μ0 I/(2πr)，结果单位μT。
    return {x:-4*i*.65/r2,y:-4*i*x/r2,z:0};
  }
  function solve(s) {
    const b=source(s),total={x:b.x,y:b.y,z:b.z-(s.earth?20:0)},horizontal=Math.hypot(total.x,total.z);
    return {b,total,horizontal,sourceStrength:Math.hypot(b.x,b.y,b.z),
      angle:horizontal<1e-7?null:Math.atan2(total.x,-total.z)*180/Math.PI,
      pole:!s.on||s.current===0?'无通电磁极':s.reverse?'左N · 右S':'左S · 右N'};
  }
  function relocate(s) {
    // 探针中心与每匝穿过水平探测平面的导线保持距离。
    if(s.scene==='solenoid'&&Math.abs(s.x)<1.8&&Math.abs(Math.abs(s.z)-.65)<.2)s.z=s.z<0?-.9:.9;
    return s;
  }
  function trace(n,z0) {
    function half(sign) {
      let x=0,z=z0;const p=[];
      for(let k=0;k<350;k++) {
        p.push([x,.85,z]);const b=coil(n,x,0,z),r=Math.hypot(b.x,b.z);if(r<1e-7)break;
        const h=.045*sign,m=coil(n,x+h*b.x/r/2,0,z+h*b.z/r/2),mr=Math.hypot(m.x,m.z);
        if(mr<1e-7)break;x+=h*m.x/mr;z+=h*m.z/mr;
        if(Math.abs(x)>4||Math.abs(z)>2.8)break;
        if(k>30&&Math.hypot(x,z-z0)<.04)break;
      }return p;
    }
    return half(-1).reverse().concat(half(1).slice(1));
  }
  window.Oersted={names,clean,loops,coil,source,solve,relocate,trace};
}());
