(function () {
  'use strict';
  const T=THREE,V=(x,y,z)=>new T.Vector3(x,y,z);
  let renderer,scene,camera,controls,rig,field,probe,needle,labels,stage,canvas,model,probePlane;
  let key='',fieldKey='',width=0,height=0;
  const ray=new T.Raycaster(),pointer=new T.Vector2();
  const tagObjects=[];
  function mat(color,extra={}) {return new T.MeshStandardMaterial({color,roughness:.38,metalness:.35,...extra});}
  function tube(points,color,r=.025,parent=rig) {
    const curve=new T.CatmullRomCurve3(points.map(p=>Array.isArray(p)?V(...p):p));
    const m=new T.Mesh(new T.TubeGeometry(curve,Math.min(480,points.length*3),r,8,false),mat(color));parent.add(m);return m;
  }
  function box(x,y,z,w,h,d,color,parent=rig) {
    const m=new T.Mesh(new T.BoxGeometry(w,h,d),mat(color));m.position.set(x,y,z);parent.add(m);return m;
  }
  function arrow(p,d,color,len=.35,parent=rig) {
    const dir=V(...d).normalize(),a=new T.ArrowHelper(dir,V(...p),len,color,.12,.09);parent.add(a);return a;
  }
  const annotations=[];
  let overlay;
  // 标注是浏览器原生文字，仅投影锚点；文字本身永不缩放或透视变形。
  function label(text,p,color='#dbe8f3',parent=rig) {
    const anchor=new T.Object3D();anchor.position.set(...p);parent.add(anchor);
    const el=document.createElement('span');el.className='scene-label';el.textContent=text;el.style.color=color;
    overlay.append(el);annotations.push({anchor,el});return anchor;
  }
  function placeLabels() {
    scene.updateMatrixWorld(true);
    for(let i=annotations.length-1;i>=0;i--) {
      const {anchor,el}=annotations[i];
      if(!anchor.parent){el.remove();annotations.splice(i,1);continue;}
      let root=anchor,visible=anchor.visible;while(root.parent){root=root.parent;visible=visible&&root.visible;}
      if(root!==scene){el.remove();annotations.splice(i,1);continue;}
      const v=anchor.getWorldPosition(new T.Vector3()).project(camera);
      const x=(v.x+1)*width/2,y=(1-v.y)*height/2;
      el.hidden=!visible||v.z>1||v.z< -1||x<8||x>width-8||y<90||y>height-130;
      el.style.left=x+'px';el.style.top=y+'px';
    }
  }
  function cylinder(x,y,z,r,h,color,parent=rig) {
    const m=new T.Mesh(new T.CylinderGeometry(r,r,h,64),mat(color));m.position.set(x,y,z);parent.add(m);return m;
  }
  function clear(group) {
    while(group.children.length) {
      const child=group.children[0];child.traverse(o=>{o.geometry?.dispose();if(o.material)for(const m of [].concat(o.material)){m.map?.dispose();m.dispose();}});group.remove(child);
    }
  }
  function makeProbe() {
    probe=new T.Group();probe.scale.setScalar(1.12);scene.add(probe);
    const disk=cylinder(0,0,0,.43,.09,'#142735',probe);
    cylinder(0,.06,0,.37,.018,'#253a4c',probe);
    for(let j=0;j<32;j++){const a=j*Math.PI/16;const tick=box(Math.sin(a)*.33,.077,Math.cos(a)*.33,.012,.008,j%8===0?.08:.035,'#a2b7c8',probe);tick.rotation.y=a;}
    cylinder(0,.145,0,.036,.04,'#e6bd65',probe);
    const rim=new T.Mesh(new T.TorusGeometry(.42,.025,8,64),mat('#d6b56b'));rim.rotation.x=Math.PI/2;rim.position.y=.06;probe.add(rim);
    needle=new T.Group();needle.position.y=.13;probe.add(needle);
    // 红尖端指向本地-z；整个磁针旋转后N端沿合水平场。
    function tip(front,color) {
      const shape=new T.Shape();shape.moveTo(0,front?-.36:.36);shape.lineTo(-.11,0);shape.lineTo(.11,0);shape.closePath();
      const m=new T.Mesh(new T.ShapeGeometry(shape),new T.MeshBasicMaterial({color,side:T.DoubleSide}));
      m.rotation.x=Math.PI/2;needle.add(m);
    }
    tip(true,'#ff6b70');tip(false,'#72baff');
    label('N', [0,.24,-.54],'#ff8790',needle).scale.set(.4,.28,1);
    label('S', [0,.24,.54],'#72baff',needle).scale.set(.4,.28,1);

  }
  function makeRig(s) {
    clear(rig);tagObjects.length=0;
    cylinder(0,-.38,0,3.55,.18,'#0b111b');
    const edge=new T.Mesh(new T.TorusGeometry(3.48,.012,8,160),mat('#25354a'));edge.rotation.x=Math.PI/2;edge.position.y=-.28;rig.add(edge);
    for(const r of [1.3,2.3]){const ring=new T.Mesh(new T.TorusGeometry(r,.003,4,96),mat('#233446'));ring.rotation.x=Math.PI/2;ring.position.y=-.28;rig.add(ring);}

    const y=s.scene==='wire'?0:.85;
    arrow([2.6,y+.05,-1.15],[0,0,-1],'#88cda8',.65);
    label('北',[2.6,y+.3,-2.15],'#a0d7b9').scale.set(.95,.25,1);
    const plane=new T.Mesh(new T.PlaneGeometry(6.2,4.2),new T.MeshBasicMaterial({color:'#3f8aa4',transparent:true,opacity:.025,side:T.DoubleSide,depthWrite:false}));
    plane.rotation.x=-Math.PI/2;plane.position.y=y;rig.add(plane);probePlane=plane;
    if(s.scene==='wire') {
      tube([[0,.65,2],[0,.65,-2]],'#e8a35a',.045);
      for(const z of [-1.65,1.65]){cylinder(0,.12,z,.04,1.1,'#768b9c');cylinder(0,-.2,z,.24,.11,'#243b4e');cylinder(0,.67,z,.09,.08,'#ddae63');}
      label('长直导线',[0,1.15,-1.9]);
      if(s.on&&s.current>0)for(const z of [-1,1])arrow([0,.65,z],[0,0,s.reverse?1:-1],'#ffc94a',.55);
      label(s.on&&s.current>0?(s.reverse?'I · 向南':'I · 向北'):'I = 0',[.8,1.1,-.7],'#f2c66f');

    } else {
      // 每圈是独立圆电流近似；端点桥线仅说明串联，不参与求场。
      for(let j=0;j<s.turns;j++) {
        const x=-1.6+3.2*(j+.5)/s.turns,points=[];
        for(let k=0;k<=64;k++){const a=k*2*Math.PI/64;points.push([x,.85+.65*Math.cos(a),.65*Math.sin(a)]);}
        tube(points,'#dc9a58',.025);
        if(j<s.turns-1)tube([[x,1.5,0],[x+3.2/s.turns,1.5,0]],'#8c663f',.015);
        if(s.on&&s.current>0&&(j%3===0))arrow([x,1.49,0],[0,0,s.reverse?-1:1],'#ffc94a',.32);
      }
      for(const x of [-1.35,1.35]){cylinder(x,.17,0,.045,.9,'#718494');cylinder(x,-.2,0,.25,.1,'#243b4e');}
      label(s.on&&s.current>0?(s.reverse?'N 极':'S 极'):'断电',[-2,1.65,0],s.reverse?'#ff8790':'#72baff');
      label(s.on&&s.current>0?(s.reverse?'S 极':'N 极'):'断电',[2,1.65,0],s.reverse?'#72baff':'#ff8790');
      label(s.turns+' 匝空心线圈',[0,1.95,0],'#edc99d');
    }
    // 独立电源与开关，画面点选与面板等效。
    const supply=box(-2.45,.03,1.65,.85,.5,.65,'#1e3448');
    cylinder(-2.65,.31,1.65,.055,.08,'#e17673');cylinder(-2.25,.31,1.65,.055,.08,'#a4b6ca');
    const sw=box(-1.5,-.02,1.7,.48,.18,.4,s.on?'#5ab89b':'#425265');sw.userData.action='switch';supply.userData.action='reverse';
    tagObjects.push(sw,supply);
    label('点按反接',[-2.5,.65,1.65],'#a9bbc9');


    // 引线为装置连接示意，磁场只求长直导线/圆电流部分。
    const a=s.scene==='wire'?[0,.65,2]:[-1.6,1.5,0],b=s.scene==='wire'?[0,.65,-2]:[1.6,1.5,0];
    tube([[-2.1,.03,1.65],[-1.5,.03,1.7],[-.7,-.12,2.15],a],'#bb6363',.018);
    tube([[-2.8,.03,1.65],[-3.25,-.12,1],[-3.25,-.12,-2],b],'#718ba4',.018);
  }
  function makeFields(s) {
    clear(field);if(!s.lines||!s.on||s.current===0)return;
    const rev=s.reverse?-1:1;
    if(s.scene==='wire') {
      for(const radius of [.5,.9,1.3]) {
        const pts=[];for(let k=0;k<=96;k++){const a=2*Math.PI*k/96;pts.push([radius*Math.cos(a),.65+radius*Math.sin(a),0]);}
        tube(pts,'#3988a4',.006,field);
        for(const a of [0,Math.PI])arrow([radius*Math.cos(a),.65+radius*Math.sin(a),0],[rev*Math.sin(a),-rev*Math.cos(a),0],'#69d9f1',.26,field);
      }
    } else {
      for(const z of [-.3,.3,1.1,-1.1]) {
        const pts=Oersted.trace(s.turns,z);if(pts.length<4)continue;
        tube(pts,'#3988a4',.005,field);
        for(const fraction of [.22,.5,.78]) {
          const i=Math.min(pts.length-2,Math.floor(fraction*pts.length)),p=pts[i],b=Oersted.coil(s.turns,p[0],0,p[2]);
          arrow(p,[b.x*rev,0,b.z*rev],'#6bd6ed',.24,field);
        }
      }
    }
  }
  function fit() {
    const w=stage.clientWidth,h=stage.clientHeight;if(w===width&&h===height)return;
    width=w;height=h;renderer.setSize(w,h);const aspect=w/h;
    const view=aspect<.8?6.9/aspect:7.7;
    camera.left=-view*aspect/2;camera.right=view*aspect/2;camera.top=view/2;camera.bottom=-view/2;
    camera.updateProjectionMatrix();
  }
  function render(s,q) {
    fit();const next=[s.scene,s.turns,s.on,s.reverse,s.current>0].join(':');
    if(key!==next){makeRig(s);key=next;}
    const fk=[s.scene,s.turns,s.on,s.reverse,s.lines,s.current>0].join(':');
    if(fieldKey!==fk){makeFields(s);fieldKey=fk;}
    probe.position.set(s.x,s.scene==='wire'?.08:.93,s.z);
    needle.visible=q.angle!==null;needle.rotation.y=q.angle===null?0:-q.angle*Math.PI/180;
    if(probePlane)probePlane.visible=s.drag||s.mode==='probe';controls.update();renderer.render(scene,camera);placeLabels();
  }
  function screenPoint(x,y,z) {
    const v=V(x,y,z).project(camera);return {x:(v.x+1)*width/2,y:(1-v.y)*height/2};
  }
  function cast(e) {
    const r=canvas.getBoundingClientRect();pointer.set((e.clientX-r.left)/r.width*2-1,-(e.clientY-r.top)/r.height*2+1);ray.setFromCamera(pointer,camera);
  }
  function point(e,s) {
    cast(e);const p=new T.Vector3();const plane=new T.Plane(V(0,1,0),s.scene==='wire'?0:-.85);
    return ray.ray.intersectPlane(plane,p)?{x:p.x,z:p.z}:null;
  }
  function action(e) {
    cast(e);const h=ray.intersectObjects(tagObjects);if(h.length)return h[0].object.userData.action;
    const r=canvas.getBoundingClientRect();let best=null,distance=23;
    for(const o of tagObjects){const p=screenPoint(o.position.x,o.position.y,o.position.z),d=Math.hypot(e.clientX-r.left-p.x,e.clientY-r.top-p.y);if(d<distance){best=o.userData.action;distance=d;}}
    return best;
  }
  function init(el,api) {
    T.ColorManagement.legacyMode=false;stage=el;model=api;overlay=document.createElement('div');overlay.className='scene-labels';stage.append(overlay);renderer=new T.WebGLRenderer({antialias:true,alpha:false});renderer.setPixelRatio(Math.min(devicePixelRatio,2));
    renderer.setClearColor('#05070d');renderer.outputEncoding=T.sRGBEncoding;renderer.toneMapping=T.ACESFilmicToneMapping;renderer.toneMappingExposure=1.05;
    canvas=renderer.domElement;canvas.tabIndex=0;canvas.setAttribute('aria-label','三维电流磁场实验：拖动空白处旋转，拖动磁针移动探针');stage.prepend(canvas);
    scene=new T.Scene();scene.add(new T.HemisphereLight('#c4dcff','#121722',.8));const light=new T.DirectionalLight('#fff2dc',1.7);light.position.set(1,7,4);scene.add(light);
    camera=new T.OrthographicCamera(-5,5,4,-4,.1,80);camera.position.set(3.6,6,8);camera.lookAt(0,.5,0);
    controls=new T.OrbitControls(camera,canvas);controls.target.set(0,.5,0);controls.enablePan=false;controls.enableDamping=true;controls.minPolarAngle=.18;controls.maxPolarAngle=1.52;controls.minZoom=.65;controls.maxZoom=2;
    rig=new T.Group();field=new T.Group();scene.add(rig,field);makeProbe();fit();return canvas;
  }
  function resetView(top=false) {camera.position.set(...(top?[0,12,.001]:[3.6,6,8]));controls.target.set(0,.5,0);camera.zoom=1;camera.lookAt(controls.target);camera.updateProjectionMatrix();controls.update();}
  function hitProbe(e) {
    const r=canvas.getBoundingClientRect(),p=screenPoint(probe.position.x,probe.position.y,probe.position.z);
    return Math.hypot(e.clientX-r.left-p.x,e.clientY-r.top-p.y)<Math.max(28,width/(camera.right-camera.left)*camera.zoom*.48);
  }
  function enableOrbit(enabled){controls.enabled=enabled;}
  function viewState(){return {position:camera.position.toArray(),zoom:camera.zoom};}
  window.OerstedScene={init,render,point,action,screenPoint,resetView,hitProbe,enableOrbit,viewState};
}());
