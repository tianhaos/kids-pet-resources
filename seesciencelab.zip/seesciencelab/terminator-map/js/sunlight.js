// 纯计算：某日某时全球的光照（直射点、晨昏线、各地地方时与昼夜、日期范围）与光照图判读练习（不碰 DOM）
// 依赖 shared/astro.js（直射点纬度 declination、昼长 dayLength、正午太阳高度 noonAltitude）
// 纬度北正、经度东正（−180, 180]；时刻用“北京时间”= 120°E 的地方时，不考虑均时差和大气折射（与教材一致）
// 时角 h = 当地经度 − 直射点经度（度，归到 (−180, 180]）：h = 0 为正午，h < 0 为上午；晨线在直射点以西（h < 0），昏线在以东
(function () {
  var A = window.Astro, DEG = Math.PI / 180;

  var PLACES = [
    { key: 'beijing', name: '北京', lat: 39.9, lon: 116.4 },
    { key: 'london', name: '伦敦', lat: 51.5, lon: 0 },
    { key: 'newyork', name: '纽约', lat: 40.7, lon: -74.0 },
    { key: 'sydney', name: '悉尼', lat: -33.9, lon: 151.2 },
    { key: 'singapore', name: '新加坡', lat: 1.3, lon: 103.8 },
    { key: 'reykjavik', name: '雷克雅未克', lat: 64.1, lon: -21.9 }
  ];

  function clamp(v, lo, hi) { return v < lo ? lo : v > hi ? hi : v; }
  function normLon(lon) {
    var x = ((lon + 180) % 360 + 360) % 360 - 180;
    return x === -180 ? 180 : x;
  }
  function mod24(t) { return ((t % 24) + 24) % 24; }

  // 直射点经度：北京时间 bj 时，正午（地方时 12 时）所在的经线
  function subLon(bj) { return normLon(120 + (12 - bj) * 15); }
  // 某经线的地方时
  function localTime(lon, bj) { return mod24(bj + (lon - 120) / 15); }
  // 相对北京的日期偏移（−1 昨天、0 同一天、+1 明天）：以 180° 经线为日界线
  function dateOffset(lon, bj) {
    var L = normLon(lon);
    return Math.floor((bj + (L - 120) / 15) / 24);
  }
  function hourAngle(lon, sLon) { return normLon(lon - sLon); }

  // 太阳高度（度）
  function altitude(lat, lon, decl, sLon) {
    var p = lat * DEG, d = decl * DEG, h = (lon - sLon) * DEG;
    return Math.asin(clamp(Math.sin(p) * Math.sin(d) + Math.cos(p) * Math.cos(d) * Math.cos(h), -1, 1)) / DEG;
  }

  // 晨昏线在某时角上的纬度：tan φ = −cos h / tan δ；二分日 δ = 0 时晨昏线与经线重合，取一个很小的 δ 近似
  function termLat(h, decl) {
    var d = Math.abs(decl) < 0.02 ? (decl < 0 ? -0.02 : 0.02) : decl;
    return Math.atan(-Math.cos(h * DEG) / Math.tan(d * DEG)) / DEG;
  }
  function isDawn(h) { return normLon(h) < 0; }

  // 某地此刻的光照情况
  function pointInfo(lat, lon, decl, bj) {
    var sLon = subLon(bj), h = hourAngle(lon, sLon), alt = altitude(lat, lon, decl, sLon);
    var L = A.dayLength(lat, decl);
    var r = { lat: lat, lon: lon, t: localTime(lon, bj), h: h, alt: alt, len: L, noonAlt: A.noonAltitude(lat, decl) };
    r.kind = L >= 24 - 1e-6 ? 'polarDay' : L <= 1e-6 ? 'polarNight' : 'normal';
    if (r.kind === 'normal') { r.rise = 12 - L / 2; r.set = 12 + L / 2; }
    r.day = alt > 0;
    // 离晨昏线 0.6° 以内算“在晨线/昏线上”
    r.line = Math.abs(alt) < 0.6 && r.kind === 'normal' ? (isDawn(h) ? 'dawn' : 'dusk') : '';
    r.state = dayState(L);
    return r;
  }
  function dayState(L) {
    if (L >= 24 - 1e-6) return '极昼';
    if (L <= 1e-6) return '极夜';
    if (L > 12.05) return '昼长夜短';
    if (L < 11.95) return '昼短夜长';
    return '昼夜等长';
  }

  // 日期范围：0 时（子夜）所在经线向东到 180° 是新的一天
  function dateSplit(bj) {
    var mid = normLon(subLon(bj) + 180);
    var newFrac = mid >= 180 - 1e-9 ? 0 : (180 - mid) / 360;
    var east = dateOffset(179.999, bj); // 新的一天（日界线西侧）相对北京的日期偏移
    return { mid: mid, newFrac: newFrac, newOff: east, oldOff: east - 1, whole: newFrac < 1e-9 || newFrac > 1 - 1e-9 };
  }

  function fmtLat(v) {
    var a = Math.abs(v);
    if (a < 0.05) return '0°';
    return (Math.abs(a - Math.round(a)) < 0.05 ? Math.round(a) : a.toFixed(1)) + '°' + (v > 0 ? 'N' : 'S');
  }
  function fmtLon(v) {
    var x = normLon(v), a = Math.abs(x);
    if (a < 0.05) return '0°';
    if (a > 179.95) return '180°';
    return (Math.abs(a - Math.round(a)) < 0.05 ? Math.round(a) : a.toFixed(1)) + '°' + (x > 0 ? 'E' : 'W');
  }
  function fmtDate(day) { var d = A.dayToDate(day); return d.month + '月' + d.date + '日'; }
  function termOf(day) {
    var d = A.wrapDay(Math.round(day));
    return A.TERMS.filter(function (T) { return T.day === d; })[0] || null;
  }
  function fmtHour(t) { var h = Math.round(mod24(t)); return (h === 24 ? 0 : h) + ' 时'; }
  function frac(f) {
    var list = [[1 / 4, '1/4'], [1 / 3, '1/3'], [1 / 2, '1/2'], [2 / 3, '2/3'], [3 / 4, '3/4']];
    for (var i = 0; i < list.length; i++) if (Math.abs(f - list[i][0]) < 0.004) return list[i][1];
    return Math.round(f * 100) + '%';
  }

  // ---------- 判读练习 ----------
  // 每题带一个 view：在哪种光照图上画（side/polar/flat）、日期、北京时间、A 点、要隐藏的信息
  var TYPES = ['date', 'time', 'line', 'state', 'range'];
  var TERM_DAYS = [80, 173, 266, 356];
  function pick(rng, arr) { return arr[Math.floor(rng() * arr.length)]; }
  function shuffle(rng, arr) {
    for (var i = arr.length - 1; i > 0; i--) { var j = Math.floor(rng() * (i + 1)), t = arr[i]; arr[i] = arr[j]; arr[j] = t; }
    return arr;
  }
  function termName(day) { var T = termOf(day); return T ? T.name : fmtDate(day); }

  function quizDate(rng) {
    var day = pick(rng, [173, 356, pick(rng, [80, 266])]);
    var view = pick(rng, ['side', 'polar', 'polar']), pole = pick(rng, ['n', 's']);
    var bj = 2 * Math.floor(rng() * 12);
    var ans = day === 173 ? '夏至日（6月22日前后）' : day === 356 ? '冬至日（12月22日前后）' : '春分日或秋分日';
    var ex;
    if (day === 80 || day === 266) ex = '晨昏线通过两极，与经线重合，全球昼夜等长，太阳直射赤道。';
    else {
      var northDay = day === 173;
      if (view === 'polar') {
        var poleDay = (pole === 'n') === northDay;
        ex = (pole === 'n' ? '北' : '南') + '极圈以内' + (poleDay ? '全是白昼（极昼）' : '全是黑夜（极夜）') + '，晨昏线与' + (pole === 'n' ? '北' : '南') + '极圈相切，' +
          '说明太阳直射' + (northDay ? '北' : '南') + '回归线。';
      } else ex = '北极圈以内' + (northDay ? '极昼、南极圈以内极夜' : '极夜、南极圈以内极昼') + '，晨昏线与极圈相切，太阳直射' + (northDay ? '北' : '南') + '回归线。';
    }
    return { type: 'date', prompt: '图示这一天最可能是：', options: ['夏至日（6月22日前后）', '冬至日（12月22日前后）', '春分日或秋分日'], answer: ans,
      explain: ex, view: { scene: view, pole: pole, day: day, bj: bj, A: null, hide: { date: true, ring: true, lon: view === 'polar' } } };
  }

  function quizTime(rng) {
    var day = pick(rng, TERM_DAYS);
    var scene = pick(rng, ['polar', 'flat']), pole = pick(rng, ['n', 's']);
    var bj = 2 * Math.floor(rng() * 12), sLon = subLon(bj);
    var lon = normLon(sLon + 30 * (1 + Math.floor(rng() * 11)));
    var lat = pole === 's' && scene === 'polar' ? -pick(rng, [20, 40, 50]) : pick(rng, [20, 40, 50]);
    var askBj = rng() < 0.4, t = askBj ? bj : localTime(lon, bj);
    var right = fmtHour(t), opts = [right];
    [6, -6, 12, 3, -3].forEach(function (d) { var o = fmtHour(t + d); if (opts.indexOf(o) < 0 && opts.length < 4) opts.push(o); });
    var dh = hourAngle(lon, sLon), noon = '昼半球正中的经线是正午 12 时，图中为 ' + fmtLon(sLon) + '。';
    var ex = askBj
      ? noon + '北京时间是 120°E 的地方时，120°E 在它' + (normLon(120 - sLon) >= 0 ? '以东 ' : '以西 ') + Math.abs(normLon(120 - sLon)) + '°，相差 ' + Math.abs(normLon(120 - sLon)) / 15 + ' 小时，所以是 ' + right + '。'
      : noon + 'A 在 ' + fmtLon(lon) + '，' + (dh >= 0 ? '以东 ' : '以西 ') + Math.abs(dh) + '°，经度每差 15° 地方时差 1 小时，东早西晚，所以是 ' + right + '。';
    return { type: 'time', prompt: askBj ? '图示时刻，北京时间是：' : '图示时刻，A 地的地方时是：', options: shuffle(rng, opts), answer: right, explain: ex,
      view: { scene: scene, pole: pole, day: day, bj: bj, A: { lat: lat, lon: lon }, hide: { date: true, ring: true } } };
  }

  function quizLine(rng) {
    var day = pick(rng, [173, 356, 120, 300]);
    var scene = pick(rng, ['polar', 'polar', 'flat']), pole = pick(rng, ['n', 's']);
    var bj = 2 * Math.floor(rng() * 12), mark = pick(rng, ['dawn', 'dusk']);
    var ans = mark === 'dawn' ? '晨线' : '昏线';
    var ex = scene === 'flat'
      ? '地球自西向东自转，地图上东在右。弧线 MN 的' + (mark === 'dawn' ? '西侧是夜、东侧是昼' : '西侧是昼、东侧是夜') + '，顺着自转方向' + (mark === 'dawn' ? '由夜进入昼，是晨线' : '由昼进入夜，是昏线') + '。'
      : '从' + (pole === 'n' ? '北极上空看地球逆时针' : '南极上空看地球顺时针') + '自转（北逆南顺）。顺着自转方向，经过 MN ' + (mark === 'dawn' ? '由夜进入昼，是晨线' : '由昼进入夜，是昏线') + '。';
    return { type: 'line', prompt: '图中加粗的弧线 MN 是：', options: ['晨线', '昏线'], answer: ans, explain: ex,
      view: { scene: scene, pole: pole, day: day, bj: bj, A: null, mark: mark, hide: { date: true, ring: true, lon: true, color: true } } };
  }

  function quizState(rng) {
    var day = pick(rng, [173, 356, 80, 120, 300]);
    var lat = pick(rng, [75, 50, 23.4, 0, -23.4, -50, -75]);
    var decl = A.declination(day), ans = dayState(A.dayLength(lat, decl));
    var pool = ['极昼', '极夜', '昼长夜短', '昼短夜长', '昼夜等长'].filter(function (s) { return s !== ans; });
    var opts = shuffle(rng, [ans].concat(shuffle(rng, pool).slice(0, 3)));
    var L = A.dayLength(lat, decl), ex;
    if (ans === '极昼' || ans === '极夜') ex = 'A 所在的纬线全部位于' + (ans === '极昼' ? '昼' : '夜') + '半球，一整天都是' + (ans === '极昼' ? '白天' : '黑夜') + '。';
    else if (ans === '昼夜等长') ex = (Math.abs(lat) < 0.1 ? '赤道被晨昏线平分，全年昼夜等长。' : '晨昏线通过两极，平分每一条纬线，全球昼夜等长。');
    else ex = 'A 所在纬线的昼弧' + (ans === '昼长夜短' ? '长于' : '短于') + '夜弧（约 ' + A.formatHours(L) + '）。直射点在哪个半球，哪个半球就昼长夜短。';
    return { type: 'state', prompt: '图示这一天，A 地的昼夜状况是：', options: opts, answer: ans, explain: ex,
      view: { scene: 'side', day: day, bj: 12, A: { lat: lat, lon: 0 }, hide: { date: true } } };
  }

  function quizRange(rng) {
    var c = pick(rng, [[2, '1/4'], [8, '1/2'], [14, '3/4'], [20, '全球同一日期']]);
    var bj = c[0], sp = dateSplit(bj), day = pick(rng, [173, 356, 80, 266]);
    var ans = c[1];
    var ex = '昼半球正中是 12 时（' + fmtLon(subLon(bj)) + '），与它相对的 ' + fmtLon(sp.mid) + ' 是 0 时。' +
      (sp.whole ? '0 时经线正好与 180° 经线重合，全球是同一个日期。' : '从 0 时经线向东到 180° 是新的一天，跨 ' + Math.round(sp.newFrac * 360) + '°，占全球的 ' + ans + '；北京（120°E）在这个范围里。');
    return { type: 'range', prompt: '图示时刻，与北京处于同一日期的范围约占全球的：', options: ['1/4', '1/2', '3/4', '全球同一日期'], answer: ans, explain: ex,
      view: { scene: 'polar', pole: 'n', day: day, bj: bj, A: null, hide: { date: true, ring: true } } };
  }

  var MAKERS = { date: quizDate, time: quizTime, line: quizLine, state: quizState, range: quizRange };
  var seq = 0;
  function quiz(rng, prevType, only) {
    rng = rng || Math.random;
    var type = only && MAKERS[only] ? only : pick(rng, TYPES.filter(function (t) { return t !== prevType; }));
    var q = MAKERS[type](rng);
    q.id = ++seq;
    return q;
  }

  window.Sunlight = {
    DEG: DEG, PLACES: PLACES, TYPES: TYPES,
    clamp: clamp, normLon: normLon, mod24: mod24,
    subLon: subLon, localTime: localTime, dateOffset: dateOffset, hourAngle: hourAngle,
    altitude: altitude, termLat: termLat, isDawn: isDawn, pointInfo: pointInfo, dayState: dayState, dateSplit: dateSplit,
    fmtLat: fmtLat, fmtLon: fmtLon, fmtDate: fmtDate, termOf: termOf, termName: termName, fmtHour: fmtHour, frac: frac,
    quiz: quiz
  };
})();
