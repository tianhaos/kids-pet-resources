(function () {
  var S = window.Sunlight, A = window.Astro, D = window.TermDraw;
  var $ = function (id) { return document.getElementById(id); };
  var qa = function (sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); };
  var NAME = '晨昏线与光照图';

  var state = {
    scene: 'polar',
    day: 173, bj: 10,
    A: { lat: 39.9, lon: 116.4 },
    pole: 'n', axisUp: false,
    play: false,
    show: { chord: true, special: true, ring: true, labels: true },
    quiz: null, quizOnly: null, answered: false, correct: false, choice: null, score: { n: 0, ok: 0 }
  };

  var HINTS = {
    side: '在图上拖动改变 A 的纬度 · 侧视图里经度看不出来，A 只画在正午一侧',
    polar: '点击或拖动地球放置 A · 拖动外圈转动地球（改变时刻）',
    flat: '点击或拖动地图放置 A · 拖动太阳或上方时间条改变时刻',
    quiz: '光照图判读练习'
  };
  var TERM_KEYS = { spring: 0, summer: 1, autumn: 2, winter: 3 };
  var SHOW_IDS = [['showChord', 'chord'], ['showSpecial', 'special'], ['showRing', 'ring'], ['showLabels', 'labels']];

  var stage = $('stage'), panel = $('panel'), cv = $('view');
  var view = D.View(cv);
  function decl() { return A.declination(state.day); }
  function setSeg(attr, val) { qa('[data-' + attr + ']').forEach(function (b) { b.classList.toggle('on', b.dataset[attr] === String(val)); }); }

  // ---------- 场景与选项 ----------
  qa('[data-scene]').forEach(function (b) {
    b.addEventListener('click', function () { setScene(b.dataset.scene); Analytics.track(NAME, '场景', b.textContent); });
  });
  function setScene(sc) {
    state.scene = sc;
    if (sc === 'quiz') { setPlay(false); if (!state.quiz) newQuiz(); }
    $('rName').className = '';
    syncUI();
  }
  qa('[data-pole]').forEach(function (b) {
    b.addEventListener('click', function () { state.pole = b.dataset.pole; syncUI(); Analytics.track(NAME, '俯视', b.textContent); });
  });
  qa('[data-axis]').forEach(function (b) {
    b.addEventListener('click', function () { state.axisUp = b.dataset.axis === 'up'; syncUI(); Analytics.track(NAME, '侧视摆放', b.textContent); });
  });
  function setPlay(on) {
    state.play = on;
    $('play').textContent = on ? '❚❚ 暂停' : '▶ 播放';
    $('play').classList.toggle('on', on);
  }
  $('play').addEventListener('click', function () { setPlay(!state.play); if (state.play) Analytics.track(NAME, '播放', state.scene); });

  // ---------- 日期、时刻、地点 ----------
  function bindSlider(id, get, set) {
    var el = $(id);
    el.addEventListener('input', function () { set(parseFloat(el.value)); });
    return { el: el, get: get };
  }
  var sliders = [
    bindSlider('day', function () { return state.day; }, function (v) { state.day = v; }),
    bindSlider('bj', function () { return state.bj; }, function (v) { setPlay(false); state.bj = v >= 24 ? 23.99 : v; }),
    bindSlider('lat', function () { return state.A.lat; }, function (v) { state.A.lat = v; }),
    bindSlider('lon', function () { return state.A.lon; }, function (v) { state.A.lon = v; })
  ];
  qa('[data-term]').forEach(function (b) {
    b.addEventListener('click', function () {
      state.day = A.TERMS[TERM_KEYS[b.dataset.term]].day;
      Analytics.track(NAME, '节气', b.textContent);
    });
  });
  var placeBox = $('placeBtns');
  S.PLACES.forEach(function (p) {
    var b = document.createElement('button');
    b.dataset.place = p.key;
    b.textContent = p.name;
    b.addEventListener('click', function () {
      state.A = { lat: p.lat, lon: p.lon };
      // 俯视图只画一个半球：选了另一半球的地点就换个极
      if (state.scene === 'polar' && (p.lat < 0) !== (state.pole === 's')) state.pole = p.lat < 0 ? 's' : 'n';
      syncUI();
      Analytics.track(NAME, '地点', p.name);
    });
    placeBox.appendChild(b);
  });
  SHOW_IDS.forEach(function (p) {
    $(p[0]).addEventListener('change', function () { state.show[p[1]] = $(p[0]).checked; });
  });

  // ---------- 画布拖动 ----------
  var drag = null, lastAng = 0;
  function local(e) { var r = cv.getBoundingClientRect(); return { x: e.clientX - r.left, y: e.clientY - r.top }; }
  function hit(p) {
    var g = view.geo(); if (!g || state.scene === 'quiz') return null;
    if (g.kind === 'side') return Math.hypot(p.x - g.cx, p.y - g.cy) < g.R * 1.08 ? 'lat' : null;
    if (g.kind === 'polar') {
      var r = Math.hypot(p.x - g.cx, p.y - g.cy);
      if (r <= g.R + 4) return 'A';
      if (r < g.R + 70) return 'ring';
      return null;
    }
    if (g.kind === 'flat') {
      if (Math.hypot(p.x - g.sun.x, p.y - g.sun.y) < 16) return 'sun';
      if (p.y < g.y0 && p.y > g.stripY && p.x >= g.x0 - 4 && p.x <= g.x0 + g.w + 4) return 'sun';
      if (g.latLon(p.x, p.y).inside) return 'A';
    }
    return null;
  }
  function dragTo(p) {
    var g = view.geo();
    if (drag === 'lat') state.A.lat = Math.round(g.latAt(p.x, p.y) * 2) / 2;
    else if (drag === 'A') {
      var ll = g.latLon(p.x, p.y);
      state.A = { lat: Math.round(ll.lat * 2) / 2, lon: Math.round(ll.lon * 2) / 2 };
    } else if (drag === 'ring') {
      var a = g.angle(p.x, p.y), da = a - lastAng;
      if (da > 180) da -= 360; if (da < -180) da += 360;
      state.bj = S.mod24(state.bj + da / (15 * g.dir));
      lastAng = a;
    } else if (drag === 'sun') {
      // 让正午经线跟着指针：bj = 12 − (λ − 120°)/15
      state.bj = S.mod24(Math.round((12 - (g.lonAt(p.x) - 120) / 15) * 12) / 12);
    }
  }
  cv.addEventListener('pointerdown', function (e) {
    if (e.button !== 0) return;
    var p = local(e);
    drag = hit(p);
    if (!drag) return;
    if (drag === 'ring' || drag === 'sun') setPlay(false);
    if (drag === 'ring') lastAng = view.geo().angle(p.x, p.y);
    try { cv.setPointerCapture(e.pointerId); } catch (err) { /* 合成事件 */ }
    cv.style.cursor = 'grabbing';
    Analytics.track(NAME, '拖动', drag);
    if (drag !== 'ring') dragTo(p);
  });
  cv.addEventListener('pointermove', function (e) {
    var p = local(e);
    if (drag) { dragTo(p); return; }
    if (e.buttons === 0) { var h = hit(p); cv.style.cursor = h === 'ring' || h === 'sun' ? 'grab' : h ? 'pointer' : ''; }
  });
  function endDrag(e) {
    if (!drag) return;
    drag = null;
    if (cv.hasPointerCapture(e.pointerId)) cv.releasePointerCapture(e.pointerId);
    cv.style.cursor = '';
  }
  cv.addEventListener('pointerup', endDrag);
  cv.addEventListener('pointercancel', endDrag);

  // ---------- 练习 ----------
  function newQuiz() {
    state.quiz = S.quiz(Math.random, state.quiz && state.quiz.type, state.quizOnly);
    state.answered = false; state.choice = null;
    var box = $('quizOpts');
    box.innerHTML = '';
    state.quiz.options.forEach(function (o) {
      var b = document.createElement('button');
      b.className = 'small';
      b.textContent = o;
      b.addEventListener('click', function () { answer(o); });
      box.appendChild(b);
    });
    syncUI();
  }
  function answer(o) {
    if (state.answered) return;
    state.answered = true;
    state.choice = o;
    state.correct = o === state.quiz.answer;
    state.score.n++; if (state.correct) state.score.ok++;
    Analytics.track(NAME, '练习', state.quiz.type + (state.correct ? ' 对' : ' 错'));
    syncUI();
  }
  qa('[data-q]').forEach(function (b) {
    b.addEventListener('click', function () { state.quizOnly = b.dataset.q || null; newQuiz(); Analytics.track(NAME, '题型', b.textContent); });
  });
  $('nextQ').addEventListener('click', newQuiz);
  $('showQ').addEventListener('click', function () {
    var v = state.quiz.view;
    state.day = v.day; state.bj = v.bj;
    if (v.pole) state.pole = v.pole;
    if (v.A) state.A = { lat: v.A.lat, lon: v.A.lon };
    setScene(v.scene);
  });

  // ---------- 面板 ----------
  $('panelToggle').addEventListener('click', function () { panel.classList.toggle('collapsed'); });
  if (window.matchMedia('(max-width: 760px)').matches) panel.classList.add('collapsed');
  window.addEventListener('keydown', function (e) {
    var tg = e.target.tagName;
    if (tg === 'INPUT' || tg === 'SELECT' || tg === 'BUTTON' || tg === 'TEXTAREA') return;
    if (e.code === 'Space' && state.scene !== 'quiz') { e.preventDefault(); setPlay(!state.play); }
  });

  function syncUI() {
    var sc = state.scene;
    setSeg('scene', sc);
    qa('[data-for]').forEach(function (el) { el.hidden = el.dataset.for.split(' ').indexOf(sc) < 0; });
    $('hint').textContent = HINTS[sc];
    setSeg('pole', state.pole);
    setSeg('axis', state.axisUp ? 'up' : 'tilt');
    setSeg('q', state.quizOnly || '');
    SHOW_IDS.forEach(function (p) { $(p[0]).checked = state.show[p[1]]; });
    var q = state.quiz;
    if (q) {
      $('quizQ').textContent = q.prompt;
      qa('#quizOpts button').forEach(function (b) {
        b.disabled = state.answered;
        b.classList.toggle('on', state.answered && b.textContent === q.answer);
        b.classList.toggle('no', state.answered && b.textContent === state.choice && !state.correct);
      });
      $('quizMsg').innerHTML = !state.answered ? ''
        : '<b class="' + (state.correct ? 'ok">✓ 答对了' : 'bad">✗ 应选「' + q.answer + '」') + '</b>' + q.explain;
      $('nextQ').textContent = state.answered ? '下一题 →' : '换一题';
      $('showQ').hidden = !state.answered;
    }
  }

  // ---------- 读数 ----------
  var lastText = {};
  function setText(id, s) { if (lastText[id] !== s) { lastText[id] = s; $(id).textContent = s; } }
  function rows(list) {
    for (var k = 1; k <= 5; k++) {
      var r = list[k - 1] || ['', ''];
      setText('d' + k, r[0]); setText('r' + k, r[1]);
      $('d' + k).hidden = $('r' + k).hidden = !r[0];
    }
  }
  function placeName() {
    var p = S.PLACES.filter(function (x) { return Math.abs(x.lat - state.A.lat) < 0.01 && Math.abs(x.lon - state.A.lon) < 0.01; })[0];
    return p ? p.name + ' ' : '';
  }
  function dateText() { var T = S.termOf(state.day); return S.fmtDate(state.day) + (T ? '（' + T.name + '）' : ''); }

  function readModel() {
    var dc = decl(), sLon = S.subLon(state.bj), a = state.A, info = S.pointInfo(a.lat, a.lon, dc, state.bj);
    setText('rName', 'A 地 ' + A.formatClock(info.t) + '（地方时）');
    $('rName').className = '';
    setText('rKind', info.line === 'dawn' ? '在晨线上' : info.line === 'dusk' ? '在昏线上' : info.day ? '白昼' : '黑夜');
    var tip;
    if (info.line === 'dawn') tip = 'A 正在日出：顺着自转方向，A 正由夜半球进入昼半球。';
    else if (info.line === 'dusk') tip = 'A 正在日落：顺着自转方向，A 正由昼半球进入夜半球。';
    else if (state.scene === 'side') tip = '晨昏线与地轴的夹角 = 直射点纬度（' + Math.abs(dc).toFixed(1) + '°）；A 所在纬线' + info.state + '。';
    else if (state.scene === 'polar') tip = (state.pole === 'n' ? '北极上空看逆时针' : '南极上空看顺时针') + '自转；昼半球正中的经线是 12 时，晨线与赤道交点是 6 时。';
    else tip = '地图上东在右：昼区西侧的边界是晨线，东侧是昏线；夜区随时间自东向西移动。';
    setText('rTip', tip);
    var lenText = info.kind === 'polarDay' ? '24 小时（极昼）' : info.kind === 'polarNight' ? '0（极夜）'
      : A.formatHours(info.len) + '（日出 ' + A.formatClock(info.rise) + '，日落 ' + A.formatClock(info.set) + '）';
    var sp = S.dateSplit(state.bj);
    var dateRow = sp.whole ? '全球都是 ' + S.fmtDate(state.day + S.dateOffset(0, state.bj)) + '（0 时经线与 180° 重合）'
      : S.fmtDate(state.day + sp.newOff) + ' 占 ' + S.frac(sp.newFrac) + '：0 时经线 ' + S.fmtLon(sp.mid) + ' 向东到 180°';
    rows([
      ['直射点', S.fmtLat(dc) + '，' + S.fmtLon(sLon) + ' · 北京 ' + dateText()],
      ['A 位置', placeName() + S.fmtLat(a.lat) + '，' + S.fmtLon(a.lon)],
      ['A 昼长', lenText],
      ['太阳高度', '此刻 ' + (info.alt > 0 ? info.alt.toFixed(1) + '°' : '地平线下') + ' · 正午 ' + (info.noonAlt > 0 ? info.noonAlt.toFixed(1) + '°' : '不升起')],
      ['新的一天', dateRow]
    ]);
  }

  function readQuiz() {
    var q = state.quiz, sc = state.score;
    setText('rName', !state.answered ? '判读练习' : state.correct ? '✓ 答对了' : '✗ 答错了');
    $('rName').className = !state.answered ? '' : state.correct ? 'ok' : 'bad';
    setText('rKind', '得分 ' + sc.ok + ' / ' + sc.n);
    setText('rTip', state.answered ? q.explain : q.prompt);
    var v = q.view;
    rows(state.answered ? [
      ['日期', S.fmtDate(v.day) + (S.termOf(v.day) ? '（' + S.termOf(v.day).name + '）' : '')],
      ['北京时间', A.formatClock(v.bj)],
      ['直射点', S.fmtLat(A.declination(v.day)) + '，' + S.fmtLon(S.subLon(v.bj))]
    ] : []);
  }

  // ---------- 尺寸与主循环 ----------
  function resize() { view.resize(stage.clientWidth, stage.clientHeight); }
  new ResizeObserver(resize).observe(stage);

  // 支持 ?scene=side|polar|flat|quiz；&date=MM-DD 或 &term=spring|summer|autumn|winter；&bj=0~24（北京时间）；
  // &lat=&lon= 或 &place=beijing|london|newyork|sydney|singapore|reykjavik；&pole=n|s；&axis=up|tilt；&q=date|time|line|state|range；
  // 显示开关 &chord=0 &special=0 &ring=0 &labels=0；&play=1 自动播放
  var qs = new URLSearchParams(location.search);
  if (HINTS[qs.get('scene')]) state.scene = qs.get('scene');
  function num(k, lo, hi) { var v = parseFloat(qs.get(k)); return isFinite(v) && v >= lo && v <= hi ? v : null; }
  var v;
  if (TERM_KEYS[qs.get('term')] != null) state.day = A.TERMS[TERM_KEYS[qs.get('term')]].day;
  var dm = /^(\d{1,2})-(\d{1,2})$/.exec(qs.get('date') || '');
  if (dm && +dm[1] >= 1 && +dm[1] <= 12 && +dm[2] >= 1 && +dm[2] <= 31) state.day = A.wrapDay(A.dateToDay(+dm[1], +dm[2]));
  if ((v = num('bj', 0, 24)) != null) state.bj = S.mod24(v);
  var place = S.PLACES.filter(function (p) { return p.key === qs.get('place'); })[0];
  if (place) state.A = { lat: place.lat, lon: place.lon };
  if ((v = num('lat', -90, 90)) != null) state.A.lat = v;
  if ((v = num('lon', -180, 180)) != null) state.A.lon = v;
  if (qs.get('pole') === 's' || qs.get('pole') === 'n') state.pole = qs.get('pole');
  else if (state.A.lat < 0) state.pole = 's';
  if (qs.get('axis') === 'up') state.axisUp = true;
  if (S.TYPES.indexOf(qs.get('q')) >= 0) { state.quizOnly = qs.get('q'); if (!qs.get('scene')) state.scene = 'quiz'; }
  SHOW_IDS.forEach(function (p) { if (qs.get(p[1]) === '0') state.show[p[1]] = false; });

  resize();
  setScene(state.scene);
  if (qs.get('play') === '1' && state.scene !== 'quiz') setPlay(true);

  var lastT = performance.now();
  function frame(now) {
    var dt = Math.min((now - lastT) / 1000, 0.1);
    lastT = now;
    var sc = state.scene;
    if (state.play && sc !== 'quiz') {
      state.bj += 2 * dt;
      if (state.bj >= 24) { state.bj -= 24; state.day = A.wrapDay(state.day + 1); }
    }
    sliders.forEach(function (s) { if (document.activeElement !== s.el) s.el.value = s.get(); });
    setText('dayOut', S.fmtDate(state.day));
    setText('bjOut', A.formatClock(state.bj));
    setText('latOut', S.fmtLat(state.A.lat));
    setText('lonOut', S.fmtLon(state.A.lon));
    qa('[data-place]').forEach(function (b) {
      var p = S.PLACES.filter(function (x) { return x.key === b.dataset.place; })[0];
      b.classList.toggle('on', Math.abs(p.lat - state.A.lat) < 0.01 && Math.abs(p.lon - state.A.lon) < 0.01);
    });
    var T = S.termOf(state.day);
    setSeg('term', T ? T.key : '');

    if (sc === 'quiz') {
      var q = state.quiz, qv = q.view, rev = state.answered;
      view.draw({
        scene: qv.scene, decl: A.declination(qv.day), sLon: S.subLon(qv.bj), bj: qv.bj, day: qv.day, A: qv.A, pole: qv.pole, axisUp: false,
        show: { chord: rev, special: true, ring: rev, labels: false },
        hide: rev ? {} : qv.hide, mark: qv.mark, reserve: $('quizBar').offsetHeight + 8
      });
      readQuiz();
    } else {
      view.draw({
        scene: sc, decl: decl(), sLon: S.subLon(state.bj), bj: state.bj, day: state.day, A: state.A,
        pole: state.pole, axisUp: state.axisUp, show: state.show, hide: {}
      });
      readModel();
    }
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // 调试用
  window.__model = {
    state: state, setScene: setScene, newQuiz: newQuiz, syncUI: syncUI,
    setDay: function (d) { state.day = A.wrapDay(d); },
    setBj: function (t) { state.bj = S.mod24(t); },
    setA: function (lat, lon) { state.A = { lat: S.clamp(lat, -90, 90), lon: S.normLon(lon) }; }
  };
})();
