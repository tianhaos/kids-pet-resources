// 2D 绘制：三种光照图——侧视图（正午经线所在平面）、极地俯视图（北极/南极为中心）、矩形光照图（等距圆柱投影的世界地图）
// 三种图里太阳都在右边；俯视图太阳固定、地球转动（经线标注跟着转），地方时刻度环固定（12 时朝向太阳）
// 俯视图用等距方位投影：r = R·(90° − |φ|)/90°，只画所看的半球，外圈是赤道
(function () {
  var S = window.Sunlight, A = window.Astro, DEG = S.DEG;
  var GOLD = '#ffc94a', MUTED = '#8d99ab', TEXT = '#e6ebf2', LINE = '#2a3446';
  var DAWN = '#ff9f5a', DUSK = '#7fb2ff', NIGHT_ARC = '#6f86c9', GREEN = '#7ee081';
  var OCEAN = '#245a94', LAND = '#5f8f4a', ICE_C = '#c9d6dd', NIGHT_FILL = 'rgba(4,8,22,.62)';
  var FONT = '-apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", sans-serif';
  var SPECIAL = [{ lat: 66.56, name: '北极圈' }, { lat: 23.44, name: '北回归线' }, { lat: 0, name: '赤道' }, { lat: -23.44, name: '南回归线' }, { lat: -66.56, name: '南极圈' }];
  var STARS = [];
  for (var i = 0; i < 140; i++) STARS.push([Math.random(), Math.random(), 0.4 + Math.random() * 1.1]);

  function font(px, w) { return (w ? w + ' ' : '') + px + 'px ' + FONT; }
  function label(ctx, s, x, y, o) {
    o = o || {};
    ctx.font = font(o.size || 12, o.bold ? 600 : null);
    ctx.textAlign = o.align || 'center'; ctx.textBaseline = o.base || 'middle';
    ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(5,7,13,.85)'; ctx.strokeText(s, x, y);
    ctx.fillStyle = o.color || TEXT; ctx.fillText(s, x, y);
  }
  function arrow(ctx, x1, y1, x2, y2, size) {
    var a = Math.atan2(y2 - y1, x2 - x1);
    ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(x2, y2);
    ctx.lineTo(x2 - size * Math.cos(a - 0.4), y2 - size * Math.sin(a - 0.4));
    ctx.lineTo(x2 - size * Math.cos(a + 0.4), y2 - size * Math.sin(a + 0.4));
    ctx.closePath(); ctx.fill();
  }
  function sunDisc(ctx, x, y, r) {
    var g = ctx.createRadialGradient(x, y, 0, x, y, r * 3);
    g.addColorStop(0, 'rgba(255,220,120,.9)'); g.addColorStop(0.35, 'rgba(255,190,60,.35)'); g.addColorStop(1, 'rgba(255,160,0,0)');
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r * 3, 0, 7); ctx.fill();
    ctx.fillStyle = '#ffd54f'; ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.fill();
  }
  function marker(ctx, x, y, name) {
    ctx.fillStyle = GREEN; ctx.strokeStyle = '#05070d'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.arc(x, y, 6, 0, 7); ctx.fill(); ctx.stroke();
    if (name) label(ctx, name, x + 10, y - 10, { size: 13, bold: true, color: GREEN, align: 'left' });
  }
  function dashed(ctx, on) { ctx.setLineDash(on ? [6, 5] : []); }
  // 把点列按 key 分段（key 变化或跨越 jump 时断开）
  function segments(pts, keyFn, jump) {
    var out = [], cur = null;
    pts.forEach(function (p, i) {
      var k = keyFn(p), prev = pts[i - 1];
      if (!cur || k !== cur.key || (jump && prev && jump(prev, p))) {
        cur = { key: k, pts: cur && k !== cur.key && !(jump && jump(prev, p)) ? [prev] : [] };
        out.push(cur);
      }
      cur.pts.push(p);
    });
    return out;
  }
  function stroke(ctx, pts) {
    ctx.beginPath();
    pts.forEach(function (p, i) { if (i) ctx.lineTo(p.x, p.y); else ctx.moveTo(p.x, p.y); });
    ctx.stroke();
  }
  function lineColor(dawn, o) { return o.hide && o.hide.color ? TEXT : dawn ? DAWN : DUSK; }

  // ================= 侧视图 =================
  // 基准坐标：地轴竖直（北极 (0, 1)），太阳方向 s = (cos δ, sin δ)；axisUp = false 时整体转 −δ 让光线水平
  function side(ctx, rect, o) {
    var d = o.decl, rot = o.axisUp ? 0 : -d * DEG, hide = o.hide || {};
    var cx = rect.x + rect.w * 0.46, cy = rect.y + rect.h * 0.5;
    var R = Math.max(60, Math.min(rect.w * 0.33, rect.h * 0.36, cx - rect.x - 96));
    var cr = Math.cos(rot), sr = Math.sin(rot);
    function P(x, y, k) { k = k || 1; return { x: cx + R * k * (x * cr - y * sr), y: cy - R * k * (x * sr + y * cr) }; }
    var sd = { x: Math.cos(d * DEG), y: Math.sin(d * DEG) };

    // 光线
    var sp = P(sd.x * 2.2, sd.y * 2.2);
    var sunX = Math.min(rect.x + rect.w - 30, sp.x), sunY = sp.y + (sunX - sp.x) * (sp.y - cy) / (sp.x - cx || 1);
    sunDisc(ctx, sunX, sunY, 16);
    ctx.strokeStyle = 'rgba(255,201,74,.55)'; ctx.fillStyle = 'rgba(255,201,74,.75)'; ctx.lineWidth = 1.4;
    [-0.8, -0.4, 0, 0.4, 0.8].forEach(function (k) {
      // 沿垂直于光线方向平移 k，从 x = 1.9 射到圆面
      var nx = -sd.y * k, ny = sd.x * k, hit = Math.sqrt(1 - k * k);
      var a = P(nx + sd.x * 1.9, ny + sd.y * 1.9), b = P(nx + sd.x * (hit + 0.04), ny + sd.y * (hit + 0.04));
      arrow(ctx, a.x, a.y, b.x, b.y, 7);
    });

    // 地球、夜半球
    ctx.fillStyle = OCEAN; ctx.beginPath(); ctx.arc(cx, cy, R, 0, 7); ctx.fill();
    ctx.fillStyle = NIGHT_FILL; ctx.beginPath();
    for (var i = 0; i <= 90; i++) { var a = (d + 90 + 180 * i / 90) * DEG, q = P(Math.cos(a), Math.sin(a)); if (i) ctx.lineTo(q.x, q.y); else ctx.moveTo(q.x, q.y); }
    ctx.closePath(); ctx.fill();

    // 纬线（侧视为水平弦）
    ctx.lineWidth = 1;
    [-60, -30, 30, 60].forEach(function (L) {
      var y = Math.sin(L * DEG), x = Math.cos(L * DEG);
      ctx.strokeStyle = 'rgba(255,255,255,.14)'; stroke(ctx, [P(-x, y), P(x, y)]);
    });
    if (o.show.special) SPECIAL.forEach(function (T) {
      var y = Math.sin(T.lat * DEG), x = Math.cos(T.lat * DEG);
      ctx.strokeStyle = T.lat === 0 ? 'rgba(255,255,255,.55)' : 'rgba(255,255,255,.35)';
      dashed(ctx, T.lat !== 0); stroke(ctx, [P(-x, y), P(x, y)]); dashed(ctx, false);
      var e = P(-x, y);
      label(ctx, T.name + (T.lat ? ' ' + S.fmtLat(T.lat) : ''), e.x - 8, e.y, { size: 11, color: MUTED, align: 'right' });
    });

    // A 所在纬线：昼弧金、夜弧蓝
    if (o.A && o.show.chord) {
      var ay = Math.sin(o.A.lat * DEG), ax = Math.cos(o.A.lat * DEG), xs = -ay * Math.tan(d * DEG);
      var cut = Math.max(-ax, Math.min(ax, xs));
      ctx.lineWidth = 4; ctx.lineCap = 'round';
      if (cut < ax) { ctx.strokeStyle = GOLD; stroke(ctx, [P(cut, ay), P(ax, ay)]); }
      if (cut > -ax) { ctx.strokeStyle = NIGHT_ARC; stroke(ctx, [P(-ax, ay), P(cut, ay)]); }
      ctx.lineCap = 'butt';
    } else if (o.A) {
      var by = Math.sin(o.A.lat * DEG), bx = Math.cos(o.A.lat * DEG);
      ctx.strokeStyle = 'rgba(255,255,255,.8)'; ctx.lineWidth = 1.6; stroke(ctx, [P(-bx, by), P(bx, by)]);
    }

    // 地轴
    ctx.strokeStyle = 'rgba(230,235,242,.8)'; ctx.lineWidth = 1.6;
    dashed(ctx, true); stroke(ctx, [P(0, -1.22), P(0, 1.22)]); dashed(ctx, false);
    var np = P(0, 1.3), spp = P(0, -1.3);
    label(ctx, 'N', np.x, np.y, { size: 13, bold: true }); label(ctx, 'S', spp.x, spp.y, { size: 13, bold: true });

    // 晨昏线
    var t1 = P(-sd.y, sd.x), t2 = P(sd.y, -sd.x);
    ctx.strokeStyle = hide.color ? TEXT : DAWN; ctx.lineWidth = 2.6; stroke(ctx, [t1, t2]);
    var tl = P(-sd.y * 1.12, sd.x * 1.12);
    if (o.show.labels) label(ctx, '晨昏线（朝向你的一面是晨线）', tl.x, tl.y - 10, { size: 12, color: hide.color ? TEXT : DAWN });

    // 直射点
    var dp = P(sd.x, sd.y);
    ctx.fillStyle = GOLD; ctx.beginPath(); ctx.arc(dp.x, dp.y, 4.5, 0, 7); ctx.fill();
    if (!hide.date) label(ctx, '直射点 ' + S.fmtLat(d), dp.x + 10, dp.y - 14, { size: 12, color: GOLD, align: 'left' });

    if (o.show.labels) {
      var dl = P(sd.x * 0.5, sd.y * 0.5 - 0.12), nl = P(-sd.x * 0.5, -sd.y * 0.5 - 0.12);
      label(ctx, '昼半球', dl.x, dl.y, { size: 13, color: 'rgba(255,255,255,.75)' });
      label(ctx, '夜半球', nl.x, nl.y, { size: 13, color: 'rgba(255,255,255,.6)' });
      if (Math.abs(d) > 1) {
        var ang = Math.round(Math.abs(d) * 10) / 10;
        label(ctx, '晨昏线与地轴夹角 ' + ang + '° = 直射点纬度', cx, rect.y + rect.h - 14, { size: 12, color: MUTED });
      }
    }
    if (o.A) {
      var ap = P(Math.cos(o.A.lat * DEG), Math.sin(o.A.lat * DEG));
      marker(ctx, ap.x, ap.y, 'A');
    }
    return {
      kind: 'side', cx: cx, cy: cy, R: R,
      latAt: function (x, y) {
        var u = (x - cx) / R, v = (cy - y) / R, by = -u * sr + v * cr;
        return Math.asin(S.clamp(by, -1, 1)) / DEG;
      }
    };
  }

  // ================= 极地俯视图 =================
  function polar(ctx, rect, o) {
    var f = o.pole === 's' ? -1 : 1, dir = f, d = o.decl, df = f * d, sLon = o.sLon, hide = o.hide || {};
    var ring = o.show.ring && !hide.ring;
    var pad = ring ? 66 : 34;
    var R = Math.max(60, Math.min(rect.w * 0.5 - pad - 40, rect.h * 0.5 - pad));
    var cx = rect.x + rect.w * 0.5 - Math.min(30, rect.w * 0.04), cy = rect.y + rect.h * 0.5;
    function th(lon) { return S.normLon(lon - sLon) * dir * DEG; }
    function P(lat, lon) { var r = R * (90 - f * lat) / 90, a = th(lon); return { x: cx + r * Math.cos(a), y: cy - r * Math.sin(a) }; }
    function PH(latf, h) { var r = R * (90 - latf) / 90, a = h * dir * DEG; return { x: cx + r * Math.cos(a), y: cy - r * Math.sin(a) }; }

    // 太阳与光线（右侧）
    var sx = Math.min(rect.x + rect.w - 24, cx + R + pad + 34);
    sunDisc(ctx, sx, cy, 14);
    ctx.strokeStyle = 'rgba(255,201,74,.45)'; ctx.fillStyle = 'rgba(255,201,74,.7)'; ctx.lineWidth = 1.3;
    [-0.32, 0.32].forEach(function (k) { arrow(ctx, sx - 8, cy + k * R, Math.max(cx + R + 20, sx - 70), cy + k * R, 7); });

    // 地球
    ctx.save();
    ctx.beginPath(); ctx.arc(cx, cy, R, 0, 7); ctx.clip();
    ctx.fillStyle = OCEAN; ctx.fillRect(cx - R, cy - R, 2 * R, 2 * R);
    var C = window.Continents;
    function polys(list, fill) {
      ctx.fillStyle = fill;
      list.forEach(function (poly) {
        var vis = poly.some(function (p) { return f * p[1] > -15; });
        if (!vis) return;
        ctx.beginPath();
        poly.forEach(function (p, k) { var q = P(Math.max(-40, Math.min(90, p[1] * f)) * f, p[0]); if (k) ctx.lineTo(q.x, q.y); else ctx.moveTo(q.x, q.y); });
        ctx.closePath(); ctx.fill();
      });
    }
    if (C) { polys(C.LAND, LAND); polys(C.ICE, ICE_C); polys([C.LAND[3]], ICE_C); polys(C.WATER, OCEAN); }

    // 夜半球：赤道上的夜半弧（h 90°→270°）+ 晨昏线（h 270°→90°）
    var term = [];
    for (var i = 0; i <= 180; i++) {
      var h = 270 + (df > 0 ? -1 : 1) * 180 * i / 180;
      term.push({ h: h, lf: Math.max(0, S.termLat(h, df)) });
    }
    ctx.fillStyle = NIGHT_FILL; ctx.beginPath();
    for (var k = 0; k <= 60; k++) { var q = PH(0, 90 + 180 * k / 60); if (k) ctx.lineTo(q.x, q.y); else ctx.moveTo(q.x, q.y); }
    term.forEach(function (t) { var q = PH(t.lf, t.h); ctx.lineTo(q.x, q.y); });
    ctx.closePath(); ctx.fill();

    // 经纬网
    ctx.lineWidth = 1;
    for (var lon = -180; lon < 180; lon += 30) {
      var e = P(0, lon);
      ctx.strokeStyle = lon === 0 ? 'rgba(255,255,255,.4)' : 'rgba(255,255,255,.16)';
      stroke(ctx, [{ x: cx, y: cy }, e]);
    }
    [30, 60].forEach(function (L) { ctx.strokeStyle = 'rgba(255,255,255,.14)'; ctx.beginPath(); ctx.arc(cx, cy, R * (90 - L) / 90, 0, 7); ctx.stroke(); });
    if (o.show.special) [66.56, 23.44].forEach(function (L) {
      ctx.strokeStyle = 'rgba(255,255,255,.4)'; dashed(ctx, true);
      ctx.beginPath(); ctx.arc(cx, cy, R * (90 - L) / 90, 0, 7); ctx.stroke(); dashed(ctx, false);
    });

    // A 所在纬线：昼弧金、夜弧蓝
    var Avis = o.A && f * o.A.lat > 0.01;
    if (Avis && o.show.chord && f * o.A.lat < 89.9) {
      var pts = [];
      for (var j = 0; j <= 240; j++) {
        var hh = -180 + 360 * j / 240, la = o.A.lat;
        pts.push({ day: S.altitude(la, sLon + hh, d, sLon) > 0, p: PH(f * la, hh) });
      }
      ctx.lineWidth = 3.5;
      segments(pts, function (p) { return p.day; }).forEach(function (sg) {
        ctx.strokeStyle = sg.key ? GOLD : NIGHT_ARC; stroke(ctx, sg.pts.map(function (p) { return p.p; }));
      });
    }

    // 晨昏线：晨线、昏线分色（h < 0 为晨线）
    var tp = term.map(function (t) { return { dawn: S.isDawn(t.h), p: PH(t.lf, t.h), h: t.h }; });
    var segs = segments(tp, function (p) { return p.dawn; });
    segs.forEach(function (sg) {
      var bold = o.mark && (o.mark === 'dawn') === sg.key;
      ctx.strokeStyle = bold && hide.color ? GOLD : lineColor(sg.key, o);
      ctx.lineWidth = bold ? 5 : 2.6;
      stroke(ctx, sg.pts.map(function (p) { return p.p; }));
      if (bold) {
        var a = sg.pts[0].p, b = sg.pts[sg.pts.length - 1].p;
        label(ctx, 'M', a.x + (a.x - cx) * 0.06, a.y + (a.y - cy) * 0.06 - 8, { size: 14, bold: true, color: GOLD });
        label(ctx, 'N', b.x + (b.x - cx) * 0.06 + 10, b.y + (b.y - cy) * 0.06, { size: 14, bold: true, color: GOLD });
      }
    });
    ctx.restore();

    // 赤道外圈
    ctx.strokeStyle = 'rgba(255,255,255,.6)'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(cx, cy, R, 0, 7); ctx.stroke();

    // 直射点、正午与子夜经线
    if (!hide.ring) {
      ctx.strokeStyle = 'rgba(255,201,74,.7)'; ctx.lineWidth = 1.4; dashed(ctx, true);
      stroke(ctx, [{ x: cx, y: cy }, { x: cx + R, y: cy }]); dashed(ctx, false);
    }
    if (df > 0.3) {
      var dp = P(d, sLon);
      ctx.fillStyle = GOLD; ctx.beginPath(); ctx.arc(dp.x, dp.y, 4.5, 0, 7); ctx.fill();
      if (!hide.date) label(ctx, '直射点', dp.x, dp.y - 12, { size: 11, color: GOLD });
    }

    // 特殊纬线标注（沿左上方的一条半径）
    if (o.show.special && o.show.labels) {
      var la0 = 112 * DEG;
      [[66.56, f > 0 ? '北极圈' : '南极圈'], [23.44, f > 0 ? '北回归线' : '南回归线']].forEach(function (s) {
        var r = R * (90 - s[0]) / 90;
        label(ctx, s[1], cx + r * Math.cos(la0), cy - r * Math.sin(la0), { size: 10, color: MUTED });
      });
    }

    // 经度标注
    if (!hide.lon) for (var lo = -180; lo < 180; lo += 30) {
      var a = th(lo), rr = R + 15;
      label(ctx, S.fmtLon(lo), cx + rr * Math.cos(a), cy - rr * Math.sin(a), { size: 10, color: lo === 0 || lo === -180 ? TEXT : MUTED });
    }

    // 地方时刻度环（固定，12 时朝向太阳）
    var r0 = R + 34, r1 = R + 54;
    if (ring) {
      ctx.strokeStyle = LINE; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.arc(cx, cy, r0, 0, 7); ctx.stroke();
      for (var hr = 0; hr < 24; hr++) {
        var aa = (hr - 12) * 15 * dir * DEG, big = hr % 3 === 0;
        var c = Math.cos(aa), s = Math.sin(aa);
        ctx.strokeStyle = big ? MUTED : LINE;
        stroke(ctx, [{ x: cx + r0 * c, y: cy - r0 * s }, { x: cx + (r0 + (big ? 7 : 4)) * c, y: cy - (r0 + (big ? 7 : 4)) * s }]);
        if (big) label(ctx, hr + '时', cx + (r1 + 2) * c, cy - (r1 + 2) * s, { size: 11, color: hr === 12 ? GOLD : hr === 0 ? DUSK : TEXT });
      }
    }

    // 极点与自转方向
    label(ctx, f > 0 ? 'N' : 'S', cx, cy, { size: 13, bold: true });
    if (!hide.color) {
      var ra = R * 0.13, a0 = 200 * DEG, a1 = 330 * DEG;
      ctx.strokeStyle = 'rgba(230,235,242,.85)'; ctx.fillStyle = 'rgba(230,235,242,.85)'; ctx.lineWidth = 1.5;
      ctx.beginPath();
      for (var m = 0; m <= 20; m++) {
        var am = a0 + (a1 - a0) * m / 20; am = dir > 0 ? am : -am;
        var x = cx + ra * Math.cos(am), y = cy - ra * Math.sin(am);
        if (m) ctx.lineTo(x, y); else ctx.moveTo(x, y);
      }
      ctx.stroke();
      var aE = dir > 0 ? a1 : -a1, aE0 = dir > 0 ? a1 - 0.25 : -(a1 - 0.25);
      arrow(ctx, cx + ra * Math.cos(aE0), cy - ra * Math.sin(aE0), cx + ra * Math.cos(aE), cy - ra * Math.sin(aE), 6);
    }

    if (Avis) { var ap = P(o.A.lat, o.A.lon); marker(ctx, ap.x, ap.y, 'A'); }
    label(ctx, (f > 0 ? '北极' : '南极') + '上空俯视' + (hide.color ? '' : '：' + (f > 0 ? '逆' : '顺') + '时针自转'), rect.x + 6, rect.y + 10, { size: 11, color: MUTED, align: 'left' });

    return {
      kind: 'polar', cx: cx, cy: cy, R: R, r0: r0, r1: r1 + 14, ring: ring, dir: dir,
      latLon: function (x, y) {
        var dx = x - cx, dy = cy - y, r = Math.hypot(dx, dy);
        var lf = S.clamp(90 - 90 * r / R, 0, 90), a = Math.atan2(dy, dx) / DEG;
        return { lat: f * lf, lon: S.normLon(sLon + a * dir), inside: r <= R + 4 };
      },
      angle: function (x, y) { return Math.atan2(cy - y, x - cx) / DEG; }
    };
  }

  // ================= 矩形光照图 =================
  function flat(ctx, rect, o) {
    var d = o.decl, sLon = o.sLon, hide = o.hide || {};
    var top = 40, left = 40, bottom = 22;
    var w = Math.min(rect.w - left - 12, (rect.h - top - bottom) * 2), h = w / 2;
    var x0 = rect.x + left + (rect.w - left - 12 - w) / 2, y0 = rect.y + top + Math.max(0, (rect.h - top - bottom - h) / 2);
    function X(lon) { return x0 + (lon + 180) / 360 * w; }
    function Y(lat) { return y0 + (90 - lat) / 180 * h; }

    ctx.save();
    ctx.beginPath(); ctx.rect(x0, y0, w, h); ctx.clip();
    ctx.fillStyle = OCEAN; ctx.fillRect(x0, y0, w, h);
    var C = window.Continents;
    function polys(list, fill) {
      ctx.fillStyle = fill;
      list.forEach(function (poly) {
        ctx.beginPath(); poly.forEach(function (p, k) { if (k) ctx.lineTo(X(p[0]), Y(p[1])); else ctx.moveTo(X(p[0]), Y(p[1])); });
        ctx.closePath(); ctx.fill();
      });
    }
    if (C) { polys(C.LAND, LAND); polys(C.ICE, ICE_C); polys([C.LAND[3]], ICE_C); polys(C.WATER, OCEAN); }

    // 夜半球
    var term = [];
    for (var i = 0; i <= 360; i++) {
      var lon = -180 + i;
      term.push({ lon: lon, lat: S.termLat(lon - sLon, d), h: S.normLon(lon - sLon) });
    }
    // 二分日（|δ| < 0.05°）晨昏线就是两条经线，单独画成竖直线，避免曲线沿两极边缘绕行
    var eq = Math.abs(d) < 0.05, north = d < 0; // 直射点在南半球时，夜在北侧
    ctx.fillStyle = NIGHT_FILL; ctx.beginPath();
    if (eq) {
      var run = null;
      for (var c = -180; c <= 180; c += 0.5) {
        var nt = Math.abs(S.normLon(c - sLon)) > 90;
        if (nt && run == null) run = c;
        if ((!nt || c === 180) && run != null) { ctx.rect(X(run), y0, X(c) - X(run), h); run = null; }
      }
    } else {
      term.forEach(function (t, k) { if (k) ctx.lineTo(X(t.lon), Y(t.lat)); else ctx.moveTo(X(t.lon), Y(t.lat)); });
      ctx.lineTo(X(180), Y(north ? 90 : -90)); ctx.lineTo(X(-180), Y(north ? 90 : -90)); ctx.closePath();
    }
    ctx.fill();

    // 经纬网
    ctx.lineWidth = 1;
    for (var lo = -150; lo < 180; lo += 30) { ctx.strokeStyle = lo === 0 ? 'rgba(255,255,255,.35)' : 'rgba(255,255,255,.14)'; stroke(ctx, [{ x: X(lo), y: y0 }, { x: X(lo), y: y0 + h }]); }
    [-60, -30, 30, 60].forEach(function (L) { ctx.strokeStyle = 'rgba(255,255,255,.14)'; stroke(ctx, [{ x: x0, y: Y(L) }, { x: x0 + w, y: Y(L) }]); });
    if (o.show.special) SPECIAL.forEach(function (T) {
      ctx.strokeStyle = T.lat === 0 ? 'rgba(255,255,255,.5)' : 'rgba(255,255,255,.35)';
      dashed(ctx, T.lat !== 0); stroke(ctx, [{ x: x0, y: Y(T.lat) }, { x: x0 + w, y: Y(T.lat) }]); dashed(ctx, false);
    });

    // A 所在纬线
    if (o.A && o.show.chord && Math.abs(o.A.lat) < 89.9) {
      var pts = [];
      for (var j = 0; j <= 360; j++) { var ll = -180 + j; pts.push({ day: S.altitude(o.A.lat, ll, d, sLon) > 0, p: { x: X(ll), y: Y(o.A.lat) } }); }
      ctx.lineWidth = 3.5;
      segments(pts, function (p) { return p.day; }).forEach(function (sg) { ctx.strokeStyle = sg.key ? GOLD : NIGHT_ARC; stroke(ctx, sg.pts.map(function (p) { return p.p; })); });
    }

    // 正午、子夜经线
    var mid = S.normLon(sLon + 180);
    if (!hide.ring) {
      ctx.lineWidth = 1.4; dashed(ctx, true);
      ctx.strokeStyle = 'rgba(255,201,74,.7)'; stroke(ctx, [{ x: X(sLon), y: y0 }, { x: X(sLon), y: y0 + h }]);
      ctx.strokeStyle = 'rgba(127,178,255,.7)'; stroke(ctx, [{ x: X(mid), y: y0 }, { x: X(mid), y: y0 + h }]);
      dashed(ctx, false);
    }

    // 晨昏线
    var tp = eq ? [] : term.map(function (t) { return { dawn: S.isDawn(t.h), p: { x: X(t.lon), y: Y(t.lat) } }; });
    if (eq) [true, false].forEach(function (dawn) {
      var xl = X(S.normLon(sLon + (dawn ? -90 : 90))), bold = o.mark && (o.mark === 'dawn') === dawn;
      ctx.strokeStyle = bold && hide.color ? GOLD : lineColor(dawn, o); ctx.lineWidth = bold ? 5 : 2.6;
      stroke(ctx, [{ x: xl, y: y0 }, { x: xl, y: y0 + h }]);
    });
    segments(tp, function (p) { return p.dawn; }, function (a, b) { return Math.abs(a.p.y - b.p.y) > h * 0.6; }).forEach(function (sg) {
      var bold = o.mark && (o.mark === 'dawn') === sg.key;
      ctx.strokeStyle = bold && hide.color ? GOLD : lineColor(sg.key, o);
      ctx.lineWidth = bold ? 5 : 2.6;
      stroke(ctx, sg.pts.map(function (p) { return p.p; }));
    });
    if (o.mark) {
      // M、N 标在所标弧线（h 从 −180° 到 0° 或 0° 到 180°）的两端附近
      var hs = o.mark === 'dawn' ? [-150, -30] : [30, 150];
      ['M', 'N'].forEach(function (nm, k) {
        var ll = S.normLon(sLon + hs[k]), la = S.termLat(hs[k], d);
        label(ctx, nm, X(ll) + 12, Y(la) - 10, { size: 14, bold: true, color: GOLD });
      });
    }
    ctx.restore();
    ctx.strokeStyle = 'rgba(255,255,255,.45)'; ctx.lineWidth = 1; ctx.strokeRect(x0, y0, w, h);

    // 直射点
    var sx = X(sLon), sy = Y(d);
    sunDisc(ctx, sx, sy, 7);
    if (!hide.date) label(ctx, '直射点', sx, sy - 16, { size: 11, color: GOLD });

    // 左侧纬度、下方经度
    [60, 30, 0, -30, -60].forEach(function (L) { label(ctx, S.fmtLat(L), x0 - 6, Y(L), { size: 10, color: MUTED, align: 'right' }); });
    if (!hide.lon) for (var lb = -180; lb <= 180; lb += 30) {
      if (w < 520 && lb % 60) continue;
      label(ctx, S.fmtLon(lb), X(lb), y0 + h + 11, { size: 10, color: lb === 0 ? TEXT : MUTED });
    }

    // 上方：地方时与日期
    if (!hide.ring) {
      for (var lt = -150; lt <= 180; lt += 30) {
        if (w < 520 && lt % 60) continue;
        var t = S.localTime(lt, o.bj), tt = Math.round(t * 60);
        var s = (Math.floor(tt / 60) % 24) + ':' + ('0' + tt % 60).slice(-2);
        label(ctx, s, X(lt), y0 - 9, { size: 10, color: Math.abs(S.normLon(lt - sLon)) < 1 ? GOLD : TEXT });
      }
      label(ctx, '地方时', x0 - 6, y0 - 9, { size: 10, color: MUTED, align: 'right' });
    }
    if (!hide.date && o.day != null) {
      var sp = S.dateSplit(o.bj), yb = y0 - 30, hb = 14;
      function band(a, b, off) {
        if (b - a < 0.5) return;
        ctx.fillStyle = off === sp.newOff ? 'rgba(255,201,74,.22)' : 'rgba(127,178,255,.18)';
        ctx.fillRect(X(a) + 1, yb, X(b) - X(a) - 2, hb);
        if (X(b) - X(a) > 56) label(ctx, S.fmtDate(o.day + off), (X(a) + X(b)) / 2, yb + hb / 2, { size: 11, color: off === sp.newOff ? GOLD : DUSK });
      }
      if (sp.whole) band(-180, 180, S.dateOffset(0, o.bj));
      else { band(-180, sp.mid, sp.oldOff); band(sp.mid, 180, sp.newOff); }
    }

    if (o.A) marker(ctx, X(o.A.lon), Y(o.A.lat), 'A');
    return {
      kind: 'flat', x0: x0, y0: y0, w: w, h: h, stripY: y0 - top,
      latLon: function (x, y) { return { lat: S.clamp(90 - (y - y0) / h * 180, -90, 90), lon: S.normLon(S.clamp((x - x0) / w * 360 - 180, -180, 180)), inside: x >= x0 && x <= x0 + w && y >= y0 && y <= y0 + h }; },
      lonAt: function (x) { return S.clamp((x - x0) / w * 360 - 180, -180, 180); },
      sun: { x: sx, y: sy }
    };
  }

  function View(canvas) {
    var ctx = canvas.getContext('2d'), W = 0, H = 0, dpr = 1, narrow = false, geo = null;
    function resize(w, h) {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      W = w; H = h; narrow = w < 640;
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
      canvas.style.width = w + 'px'; canvas.style.height = h + 'px';
    }
    function bg() {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      var g = ctx.createLinearGradient(0, 0, 0, H);
      g.addColorStop(0, '#04060c'); g.addColorStop(1, '#0a1120');
      ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
      ctx.fillStyle = 'rgba(255,255,255,.35)';
      STARS.forEach(function (s) { ctx.fillRect(s[0] * W, s[1] * H, s[2], s[2]); });
    }
    // o: { scene, decl, sLon, bj, day, A, pole, axisUp, show, hide, mark, reserve（底部留给练习卡片的高度） }
    function draw(o) {
      bg();
      var t0 = narrow ? 84 : 44, bottom = (narrow ? 44 : 50) + (o.reserve || 0);
      var R = { x: 12, y: t0, w: W - 24, h: Math.max(140, H - t0 - bottom) };
      if (o.scene === 'side') geo = side(ctx, R, o);
      else if (o.scene === 'polar') geo = polar(ctx, R, o);
      else geo = flat(ctx, R, o);
      return geo;
    }
    return { resize: resize, draw: draw, geo: function () { return geo; }, narrow: function () { return narrow; } };
  }

  window.TermDraw = { View: View, side: side, polar: polar, flat: flat };
})();
