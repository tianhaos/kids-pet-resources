/* 整株与叶片下表皮分别取景。标签与手柄使用 CSS 像素。 */
(function () {
  'use strict';

  const ink = '#deebeb', muted = '#a2b9bf', water = '#83d9f7', gold = '#edc171';
  const leafShape = new Path2D('M0 0C.19 -.36 .6 -.31 1 0C.66 .06 .38 .37 0 0Z');
  const stem = new Path2D('M173 251Q181 202 176 162Q182 123 169 65M177 195Q146 191 112 164M176 163Q205 144 220 139M173 99Q147 97 125 74M170 74Q176 55 192 47');
  const waterPath = [[39, 350], [83, 337], [121, 318], [157, 282], [173, 246], [177, 204],
    [177, 166], [187, 150], [218, 140], [250, 128], [291, 108], [312, 96]];
  const roots = [
    ['M173 230Q176 259 157 282Q128 325 80 339Q53 347 33 353', 5],
    ['M170 261Q171 299 182 323Q192 350 187 378', 4],
    ['M159 280Q183 282 212 310Q243 342 296 355', 4],
    ['M132 309Q107 300 88 311L61 320M103 328Q105 350 83 369M77 339Q58 329 46 335', 2],
    ['M180 316Q156 337 151 362L146 375M185 333Q210 346 221 369', 2],
    ['M216 313Q245 302 274 319M249 337Q254 354 273 371M290 353L318 348', 2]
  ];
  const rootPaths = roots.map(([path, width]) => [new Path2D(path), width]);
  const route = waterPath.slice(1).map(([x, y], i) => ({
    x, y, dx: x - waterPath[i][0], dy: y - waterPath[i][1],
    length: Math.hypot(x - waterPath[i][0], y - waterPath[i][1])
  }));
  const routeLength = route.reduce((sum, segment) => sum + segment.length, 0);
  let handle = { x: 0, y: 0, start: 0, end: 1 }, hover = false;

  function text(c, label, x, y, color = ink, size = 12, align = 'left') {
    c.fillStyle = color;
    c.font = `${size}px -apple-system,BlinkMacSystemFont,"PingFang SC","Microsoft YaHei",sans-serif`;
    c.textAlign = align;
    c.fillText(label, x, y);
  }

  function line(c, points, color, width = 1) {
    c.beginPath();
    points.forEach(([x, y], i) => i ? c.lineTo(x, y) : c.moveTo(x, y));
    c.strokeStyle = color;
    c.lineWidth = width;
    c.stroke();
  }

  function dot(c, x, y, r, color) {
    c.fillStyle = color;
    c.beginPath();
    c.arc(x, y, r, 0, 2 * Math.PI);
    c.fill();
  }

  function panel(c, box, edge, center) {
    c.save();
    c.beginPath();
    c.roundRect(box.x, box.y, box.w, box.h, 12);
    c.clip();
    const bg = c.createRadialGradient(box.x + box.w * .56, box.y + box.h * .45, 0,
      box.x + box.w * .56, box.y + box.h * .45, Math.max(box.w, box.h) * .7);
    bg.addColorStop(0, center);
    bg.addColorStop(1, edge);
    c.fillStyle = bg;
    c.fillRect(box.x, box.y, box.w, box.h);
  }

  function outline(c, box) {
    c.restore();
    c.beginPath();
    c.roundRect(box.x + .5, box.y + .5, box.w - 1, box.h - 1, 12);
    c.lineWidth = 1;
    c.strokeStyle = '#293d43';
    c.stroke();
  }

  function leaf(c, x, y, angle, length, lit) {
    c.save();
    c.translate(x, y);
    c.rotate(angle);
    c.scale(length, length);
    const fill = c.createLinearGradient(.3, -.31, .44, .26);
    fill.addColorStop(0, lit ? '#b4ca72' : '#72a053');
    fill.addColorStop(.45, lit ? '#60944d' : '#427d4b');
    fill.addColorStop(1, '#1b4934');
    c.fillStyle = fill;
    c.fill(leafShape);
    c.strokeStyle = lit ? '#b5ce85' : '#659166';
    c.lineWidth = .008;
    c.stroke(leafShape);
    c.clip(leafShape);
    line(c, [[0, 0], [.43, .018], [.95, 0]], lit ? '#bcd285' : '#8bb26e', .014);
    for (let i = 1; i <= 6; i++) {
      const t = .115 * i;
      const reach = Math.sin(t * Math.PI) * .24;
      c.beginPath();
      c.moveTo(t, .015);
      c.quadraticCurveTo(t + .1, -reach * .3, t + .19, -reach);
      c.moveTo(t, .016);
      c.quadraticCurveTo(t + .1, reach * .25, t + .19, reach * .77);
      c.lineWidth = .005;
      c.strokeStyle = '#a1be79';
      c.stroke();
    }
    c.restore();
  }

  function particles(c, offset, rate) {
    if (rate <= 0) return;
    const intensity = Math.min(1, Math.sqrt(rate / 1.3));
    for (let i = 0; i < 18; i++) {
      const fraction = (i / 18 + offset) % 1;
      let distance = fraction * routeLength;
      for (const segment of route) {
        if (distance <= segment.length) {
          const left = 1 - distance / segment.length;
          c.globalAlpha = Math.min(1, fraction * 16, (1 - fraction) * 28) * (.25 + .75 * intensity);
          const x = segment.x - segment.dx * left, y = segment.y - segment.dy * left;
          dot(c, x, y, 5, '#286380');
          dot(c, x, y, 2.7, water);
          break;
        }
        distance -= segment.length;
      }
    }
    c.globalAlpha = 1;
  }

  function plant(c, box, state, rate, compact) {
    panel(c, box, '#080e14', '#142b29');
    const k = Math.min((box.w - (compact ? 98 : 18)) / 360, (box.h - 42) / 390, 1.48);
    const x = compact ? box.x + 7 + (box.w - 98 - 360 * k) * .34 : box.x + (box.w - 360 * k) / 2;
    const y = box.y + 31 + (box.h - 37 - 390 * k) * .48;
    const soilTop = y + 247 * k;
    const soil = c.createLinearGradient(0, soilTop, 0, box.y + box.h);
    soil.addColorStop(0, '#3b3026');
    soil.addColorStop(.24, '#28221e');
    soil.addColorStop(1, '#15171a');
    c.fillStyle = soil;
    c.fillRect(box.x, soilTop, box.w, box.y + box.h - soilTop);
    line(c, [[box.x, soilTop], [box.x + box.w, soilTop]], '#685342');
    for (let i = 0; i < 175; i++) {
      const px = box.x + (i * .61803399 % 1) * box.w;
      const py = soilTop + (i * .41421356 % 1) * (box.y + box.h - soilTop);
      dot(c, px, py, i % 5 === 0 ? 1.5 : .7, i % 4 ? '#47382c' : '#70604a');
    }

    c.save();
    c.translate(x, y);
    c.scale(k, k);
    c.lineCap = 'round';
    for (const [path, width] of rootPaths) {
      c.lineWidth = width + 3;
      c.strokeStyle = '#4e4032';
      c.stroke(path);
      c.lineWidth = width;
      c.strokeStyle = width > 2 ? '#c9ad80' : '#927e61';
      c.stroke(path);
    }
    c.strokeStyle = '#477448';
    c.lineWidth = 11;
    c.stroke(stem);
    c.strokeStyle = '#94ad66';
    c.lineWidth = 3;
    c.stroke(stem);
    leaf(c, 112, 164, -2.79, 96, false);
    leaf(c, 125, 74, -2.59, 86, false);
    leaf(c, 192, 47, -.71, 72, false);
    leaf(c, 220, 139, -.44, 114, true);

    // 导管和叶脉连续连到选中的叶片。亮点沿路线单向推进。
    line(c, waterPath, '#77b4c4', 1.8);
    particles(c, state.phase, rate);
    c.restore();

    const markX = x + 293 * k, markY = y + 108 * k;
    const markRadius = Math.max(9, 14 * k);
    c.beginPath();
    c.arc(markX, markY, markRadius, 0, Math.PI * 2);
    c.strokeStyle = gold;
    c.lineWidth = 1.4;
    c.stroke();
    const labelX = box.x + box.w - 12;
    line(c, [[markX + markRadius, markY], [labelX - 5, markY], [labelX - 5, markY + 8]], '#ab9762');
    text(c, '放大位置', labelX, markY + 23, gold, 11, 'right');
    const stemY = y + 214 * k, rootY = y + 325 * k;
    line(c, [[x + 178 * k, stemY], [labelX - 38, stemY]], '#668990');
    text(c, '导管', labelX, stemY + 4, muted, 11, 'right');
    line(c, [[x + 187 * k, rootY], [labelX - 38, rootY]], '#88775f');
    text(c, '根系', labelX, rootY + 4, '#d0b99a', 11, 'right');
    text(c, '整株水路', box.x + 12, box.y + 20, ink, 13);
    text(c, '土壤', box.x + 12, soilTop + 17, '#c4ac8d', 11);
    outline(c, box);
  }

  function epidermis(c, box, cx, cy) {
    // 相邻表皮细胞共用波状细胞壁。
    const grid = Array.from({ length: Math.ceil(box.h / 65) + 2 }, (_, row) =>
      Array.from({ length: Math.ceil(box.w / 80) + 2 }, (_, col) => [
        box.x - 30 + col * 80 + Math.sin(col * 2.9 + row * 6.7) * 23,
        box.y - 20 + row * 65 + Math.cos(row * 2.1 + col * 3.7) * 18
      ]));
    function wall([x, y], [tx, ty], bend) {
      const dx = tx - x, dy = ty - y;
      c.bezierCurveTo(x + dx * .31 - dy * bend, y + dy * .31 + dx * bend,
        x + dx * .71 + dy * bend, y + dy * .71 - dx * bend, tx, ty);
    }
    for (let row = 0; row < grid.length - 1; row++) {
      for (let col = 0; col < grid[row].length - 1; col++) {
        const a = grid[row][col], b = grid[row][col + 1], d = grid[row + 1][col], e = grid[row + 1][col + 1];
        c.beginPath();
        c.moveTo(...a);
        wall(a, b, .34); wall(b, e, -.31); wall(e, d, .34); wall(d, a, -.31);
        c.fillStyle = (row + col * 2) % 3 === 0 ? '#234c3e' : '#183b33';
        c.fill();
        c.strokeStyle = '#396052';
        c.lineWidth = 1.1;
        c.stroke();
      }
    }
    const shade = c.createRadialGradient(cx, cy, 8, cx, cy, Math.max(box.w, box.h) * .59);
    shade.addColorStop(0, '#06151300');
    shade.addColorStop(.55, '#07161153');
    shade.addColorStop(1, '#081318ed');
    c.fillStyle = shade;
    c.fillRect(box.x, box.y, box.w, box.h);
  }

  function guard(c, g, side) {
    const { height: h, gap, bulge } = g;
    c.save();
    c.scale(side, 1);
    const cell = new Path2D();
    cell.moveTo(0, -h);
    cell.bezierCurveTo(bulge + 45, -h - 5, bulge + 54, h + 5, 0, h);
    cell.bezierCurveTo(gap, h * .55, gap, -h * .55, 0, -h);
    const color = c.createLinearGradient(0, -h * .65, 96, h * .65);
    color.addColorStop(0, '#d4e997');
    color.addColorStop(.34, '#8fb968');
    color.addColorStop(.72, '#487e4f');
    color.addColorStop(1, '#264a37');
    c.fillStyle = color;
    c.fill(cell);
    c.lineWidth = 2.3;
    c.strokeStyle = '#91ba79';
    c.stroke(cell);
    c.clip(cell);
    for (let i = 0; i < 12; i++) {
      const t = (i + 1.4) / 14;
      const x = 21 + Math.sin(t * Math.PI) * (25 + gap * .32) + Math.sin(i * 8) * 8;
      const y = -h + t * h * 2;
      c.beginPath();
      c.ellipse(x, y, 6.9, 3.7, .7 - t * 1.4, 0, Math.PI * 2);
      c.fillStyle = i % 3 ? '#608b3d' : '#c1d779';
      c.fill();
    }
    c.beginPath();
    c.moveTo(0, -h);
    c.bezierCurveTo(gap, -h * .55, gap, h * .55, 0, h);
    c.strokeStyle = '#d4e8a4';
    c.lineWidth = 6;
    c.stroke();
    c.restore();
  }

  function cone(c, x, y, k, phase, rate, aperture) {
    // 投影的水汽从孔口离开叶面。零通量时无水汽粒子。
    if (rate <= 0 || aperture <= 0) return;
    const intensity = Math.min(1, Math.sqrt(rate / 1.3)) * Math.min(1, aperture * 7);
    for (let i = 0; i < 17; i++) {
      const p = (i / 17 + phase * 1.7) % 1;
      const px = x + Math.sin(i * 7.13) * p * p * 61 * k;
      const py = y - p * 108 * k;
      c.globalAlpha = Math.min(p * 13, 1 - p) * intensity;
      dot(c, px, py, (3.2 - p) * Math.max(.7, k), water);
    }
    c.globalAlpha = 1;
  }

  function stoma(c, box, state, rate) {
    const k = Math.min((box.w - 32) / 230, (box.h - 92) / 212, 1.85);
    const cx = box.x + box.w / 2, cy = box.y + 28 + (box.h - 86) * .51;
    const g = Transpiration.guardGeometry(state.aperture);
    panel(c, box, '#091518', '#244738');
    epidermis(c, box, cx, cy);
    c.save();
    c.translate(cx, cy);
    c.scale(k, k);
    c.beginPath();
    c.moveTo(0, -g.height);
    c.bezierCurveTo(g.gap, -g.height * .55, g.gap, g.height * .55, 0, g.height);
    c.bezierCurveTo(-g.gap, g.height * .55, -g.gap, -g.height * .55, 0, -g.height);
    c.fillStyle = '#041313';
    c.fill();
    guard(c, g, -1);
    guard(c, g, 1);
    c.restore();
    cone(c, cx, cy + 7 * k, k, state.phase, rate, state.aperture);

    const labelY = cy + 44 * k;
    const left = box.x + 12, right = box.x + box.w - 12;
    const stemLabelX = cx - 45 * k;
    line(c, [[left + 2, labelY + 8], [stemLabelX - 11, labelY + 8], [stemLabelX, labelY - 7]], '#a0bd88');
    text(c, '保卫细胞', left, labelY + 3, '#d0e2bd', 11);
    const gapEdge = Math.max(2, .75 * g.gap * k);
    line(c, [[cx + gapEdge, cy], [cx + gapEdge + 12, cy - 10], [right - 4, cy - 10]], '#94ada8');
    text(c, '气孔', right, cy - 15, ink, 11, 'right');
    text(c, '叶片下表皮 · 放大', left, box.y + 20, ink, 13);
    text(c, '水汽扩散示意', right, box.y + 20, water, 11, 'right');

    const hy = box.y + box.h - 26, end = right - 12;
    const start = end - Math.min(170, box.w * .48);
    const hx = start + state.aperture * (end - start);
    c.fillStyle = '#0c191df2';
    c.fillRect(box.x, hy - 23, box.w, 49);
    line(c, [[box.x, hy - 23], [box.x + box.w, hy - 23]], '#334744');
    text(c, '拖动调开度', left, hy + 4, gold, 12);
    c.lineCap = 'round';
    line(c, [[start, hy], [end, hy]], '#3f5655', 3);
    line(c, [[start, hy], [hx, hy]], '#ad8b53', 3);
    if (hover) dot(c, hx, hy, 18, '#675738');
    dot(c, hx, hy, 11, gold);
    text(c, '↔', hx, hy + 4, '#211d16', 13, 'center');
    outline(c, box);
    handle = { x: hx, y: hy, start, end };
  }

  function render(canvas, state, rate) {
    const { width: w, height: h } = canvas.getBoundingClientRect();
    if (w < 20 || h < 20) return;
    const ratio = Math.min(devicePixelRatio || 1, 2);
    const pw = Math.round(w * ratio), ph = Math.round(h * ratio);
    if (canvas.width !== pw || canvas.height !== ph) {
      canvas.width = pw;
      canvas.height = ph;
    }
    const c = canvas.getContext('2d');
    c.setTransform(ratio, 0, 0, ratio, 0, 0);
    c.clearRect(0, 0, w, h);
    const gap = 8, stacked = w < 570;
    if (stacked) {
      const split = Math.round(h * .42);
      plant(c, { x: 0, y: 0, w, h: split }, state, rate, true);
      stoma(c, { x: 0, y: split + gap, w, h: h - split - gap }, state, rate);
    } else {
      const split = Math.round(w * .46);
      plant(c, { x: 0, y: 0, w: split, h }, state, rate, false);
      stoma(c, { x: split + gap, y: 0, w: w - split - gap, h }, state, rate);
    }
  }

  function hit(x, y) {
    return x >= handle.start - 22 && x <= handle.end + 22 && Math.abs(y - handle.y) <= 22;
  }
  function apertureAt(x) {
    return Transpiration.clamp((x - handle.start) / (handle.end - handle.start), 0, 1);
  }
  window.PlantDraw = { render, hit, apertureAt, setHover(value) { hover = value; }, getHandle: () => handle };
})();
