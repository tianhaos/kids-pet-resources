/* 纯计算：水汽压差与两段串联扩散阻力；导度为教学相对量。 */
(function () {
  'use strict';
  const clamp = (x, lo, hi) => Math.max(lo, Math.min(hi, x));
  const presets = {
    humid: { humidity: 80, temperature: 25, wind: 1, aperture: .85, title: '湿润白天', note: '气孔张开，湿空气使水汽散失较慢。' },
    dry: { humidity: 30, temperature: 25, wind: 1, aperture: .85, title: '干燥白天', note: '与湿润场景只差湿度：相同开度，散失更快。' },
    drought: { humidity: 30, temperature: 25, wind: 1, aperture: .08, title: '缺水关孔', note: '与干燥场景只差开度：关小气孔，减少失水。' },
    night: { humidity: 80, temperature: 25, wind: 1, aperture: .03, title: '夜间示意', note: '许多植物夜间气孔关小；本场景只设定开度。' }
  };
  function saturation(t) { return .6108 * Math.exp(17.27 * t / (t + 237.3)); }
  function flux(a, h, t, w) {
    const gs = .02 + .98 * a, gb = .3 + .7 * Math.sqrt(w);
    const vpd = saturation(t) * (1 - h / 100);
    return { gs, gb, vpd, flux: vpd / (1 / gs + 1 / gb) };
  }
  const reference = flux(1, 50, 25, 1).flux;
  function sample(s) {
    const a = clamp(s.aperture, 0, 1), h = clamp(s.humidity, 10, 100);
    const t = clamp(s.temperature, 10, 40), w = clamp(s.wind, 0, 4);
    const r = flux(a, h, t, w);
    return Object.assign(r, { rate: r.flux / reference });
  }
  // 开度从0到1：孔隙渐宽；两侧肾形细胞的内壁曲率同步增大。
  function guardGeometry(a) {
    a = clamp(a, 0, 1);
    return { gap: 1 + 44 * a, bulge: 41 + 12 * a, height: 82 };
  }
  window.Transpiration = { presets, sample, saturation, guardGeometry, clamp };
})();
