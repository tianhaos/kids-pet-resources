(function(){
  'use strict';
  const $=id=>document.getElementById(id),qs=new URLSearchParams(location.search);
  const presets=Transpiration.presets,keys=['aperture','humidity','temperature','wind'];
  const bounds={aperture:[0,1],humidity:[10,100],temperature:[10,40],wind:[0,4]};
  const initial=Object.hasOwn(presets,qs.get('scene'))?qs.get('scene'):'dry';
  const state=Object.assign({scene:initial,phase:0,play:!matchMedia('(prefers-reduced-motion: reduce)').matches,custom:false},presets[initial]);
  for(const key of keys){
    if(qs.has(key)&&Number.isFinite(Number(qs.get(key)))){
      state[key]=Transpiration.clamp(Number(qs.get(key)),...bounds[key]);state.custom=true;
    }
  }
  if(qs.get('play')==='0')state.play=false;
  const records=[];
  let rate=0;
  let needsDraw=true;
  function track(action,label=''){if(window.Analytics)Analytics.track('蒸腾作用与气孔开闭',action,label);}
  function update(){
    const r=Transpiration.sample(state);
    rate=r.rate;
    needsDraw=true;
    $('sceneNote').textContent=state.custom?'自定义条件 · 保持其余变量不变，观察速率怎样变化。':presets[state.scene].note;
    $('rate').textContent=$('panelRate').textContent=r.rate.toFixed(2);
    $('vpd').textContent=r.vpd.toFixed(2)+' kPa';$('opening').textContent=Math.round(state.aperture*100)+'%';
    for(const key of keys)$(key).value=state[key];
    $('apertureText').textContent=Math.round(state.aperture*100)+'%';
    $('humidityText').textContent=state.humidity.toFixed(0)+'%';
    $('temperatureText').textContent=state.temperature.toFixed(0)+' °C';
    $('windText').textContent=state.wind.toFixed(1)+' m/s';
    $('play').textContent=state.play?'暂停粒子':'播放粒子';
    document.querySelectorAll('[data-scene]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.scene===state.scene&&!state.custom)));
  }
  function setScene(scene){
    if(!Object.hasOwn(presets,scene))return;
    Object.assign(state,presets[scene],{scene,custom:false,phase:0});
    $('feedback').textContent='';update();track('场景',scene);
  }
  function setValue(key,value){
    if(!bounds[key]||!Number.isFinite(Number(value)))return;
    state[key]=Transpiration.clamp(Number(value),...bounds[key]);state.custom=true;update();
  }
  for(const key of keys){$(key).oninput=e=>setValue(key,e.target.value);$(key).onchange=()=>track('调节',key+':'+state[key]);}
  document.querySelectorAll('[data-scene]').forEach(b=>b.onclick=()=>setScene(b.dataset.scene));
  $('reset').onclick=()=>setScene(state.scene);
  $('play').onclick=()=>{state.play=!state.play;update();track('粒子动画',String(state.play));};
  $('record').onclick=()=>{
    records.push({...state,rate:Transpiration.sample(state).rate});if(records.length>5)records.shift();
    $('records').innerHTML='<table><thead><tr><th>开度</th><th>湿度</th><th>°C</th><th>m/s</th><th>速率</th></tr></thead><tbody>'+records.map(r=>`<tr><td>${Math.round(r.aperture*100)}%</td><td>${r.humidity.toFixed(0)}%</td><td>${r.temperature.toFixed(0)}</td><td>${r.wind.toFixed(1)}</td><td>${r.rate.toFixed(2)}</td></tr>`).join('')+'</tbody></table>';
    track('记录对照',String(records.length));
  };
  document.querySelectorAll('[data-answer]').forEach(b=>b.onclick=()=>{
    $('feedback').textContent=b.dataset.answer==='down'?'正确。其他条件相同，湿度越高，水汽压差越小，散失越慢。':'再看湿度的作用：湿度升高使叶内外水汽压差减小。';track('判断',b.dataset.answer);
  });
  $('share').onclick=async()=>{
    const u=new URL(location.href),p=new URLSearchParams({scene:state.scene,play:'0'});
    keys.forEach(k=>p.set(k,String(state[k])));u.search=p;
    try{await navigator.clipboard.writeText(u.href);$('shareStatus').textContent='已复制当前条件链接';}
    catch{$('shareStatus').textContent=u.href;}track('分享实验');
  };
  const narrow=matchMedia('(max-width:760px)'), panel=$('panel'), toggle=$('panelToggle');
  function setPanel(open, moveFocus=false){
    panel.classList.toggle('collapsed',!open);
    toggle.setAttribute('aria-expanded',String(open));
    if(moveFocus)(open?$('closePanel'):toggle).focus();
  }
  toggle.onclick=()=>setPanel(panel.classList.contains('collapsed'),true);
  $('closePanel').onclick=()=>setPanel(false,true);
  panel.addEventListener('keydown',e=>{if(e.key==='Escape'&&narrow.matches)setPanel(false,true);});
  narrow.addEventListener('change',e=>setPanel(!e.matches));
  setPanel(!narrow.matches);

  const canvas=$('plant');
  let drag=null, grabOffset=0;
  function point(e){const r=canvas.getBoundingClientRect();return{x:e.clientX-r.x,y:e.clientY-r.y};}
  function hover(over){
    PlantDraw.setHover(over);
    canvas.style.cursor=over?'ew-resize':'';
    needsDraw=true;
  }
  canvas.addEventListener('pointerdown',e=>{
    const p=point(e);
    if(drag!==null||e.button!==0||!PlantDraw.hit(p.x,p.y))return;
    drag=e.pointerId;
    canvas.setPointerCapture(drag);
    canvas.classList.add('dragging');
    hover(true);
    const dx=p.x-PlantDraw.getHandle().x;
    grabOffset=Math.abs(dx)<=11?dx:0;
    if(Math.abs(dx)>11)setValue('aperture',PlantDraw.apertureAt(p.x));
  });
  canvas.addEventListener('pointermove',e=>{
    const p=point(e);
    if(drag===e.pointerId)setValue('aperture',PlantDraw.apertureAt(p.x-grabOffset));
    else if(drag===null)hover(PlantDraw.hit(p.x,p.y));
  });
  canvas.addEventListener('pointerleave',()=>{if(drag===null)hover(false);});
  function finish(e){
    if(drag!==e.pointerId)return;
    drag=null;
    canvas.classList.remove('dragging');
    const p=point(e);
    hover(e.pointerType==='mouse'&&PlantDraw.hit(p.x,p.y));
    track('拖动气孔',state.aperture.toFixed(2));
  }
  canvas.addEventListener('lostpointercapture',finish);
  canvas.addEventListener('pointerup',finish);
  canvas.addEventListener('pointercancel',finish);
  new ResizeObserver(()=>{needsDraw=true;}).observe(canvas);
  let previous=performance.now();
  function frame(now){
    const dt=Math.min(.1,(now-previous)/1000);
    previous=now;
    if(state.play&&rate>0){
      state.phase+=dt*Math.min(.56,.25*Math.sqrt(rate));
      needsDraw=true;
    }
    if(needsDraw){
      PlantDraw.render(canvas,state,rate);
      needsDraw=false;
    }
    requestAnimationFrame(frame);
  }
  update();requestAnimationFrame(frame);
  window.__model={state,setScene,setValue,update,records,sample:()=>Transpiration.sample(state),getHandle:PlantDraw.getHandle};
})();
