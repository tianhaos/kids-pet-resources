/* 自适应实验画布；计算仍由 FloatPhysics 独立完成。 */
(function(){
'use strict';
const C={gold:'#ffc94a',blue:'#7cdef0',text:'#e3edf5',muted:'#8da5bb'};
let ctx,scale=1,ox=0,oy=0,geometry={};
function text(t,x,y,size=13,color=C.text,align='left'){ctx.fillStyle=color;ctx.font=`${size}px -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif`;ctx.textAlign=align;ctx.fillText(t,x,y);}
function line(x,y,a,b,color,width=1,dash=[]){ctx.beginPath();ctx.setLineDash(dash);ctx.moveTo(x,y);ctx.lineTo(a,b);ctx.strokeStyle=color;ctx.lineWidth=width;ctx.stroke();ctx.setLineDash([]);}
function box(x,y,w,h,color,r=0){ctx.fillStyle=color;ctx.beginPath();ctx.roundRect(x,y,w,h,r);ctx.fill();}
function arrow(x,y,dy,color,label){line(x,y,x,y+dy,color,2);line(x,y+dy,x-5,y+dy-Math.sign(dy)*8,color,2);line(x,y+dy,x+5,y+dy-Math.sign(dy)*8,color,2);text(label,x+10,y+dy/2+4,12,color);}
function water(top,bottom,left,right,time){
 const g=ctx.createLinearGradient(0,top,0,bottom);g.addColorStop(0,'#15577799');g.addColorStop(1,'#0c283c55');box(left,top,right-left,bottom-top,g);
 line(left,top,right,top,C.blue,1.5);
 for(let i=0;i<3;i++){const y=top+45+i*75;line(left+15,y,right-15,y,'#4c8bad18');}
}
function draw(canvas,s,time){
 const rect=canvas.getBoundingClientRect(),dpr=Math.min(devicePixelRatio||1,2);
 if(canvas.width!==Math.round(rect.width*dpr)||canvas.height!==Math.round(rect.height*dpr)){canvas.width=Math.round(rect.width*dpr);canvas.height=Math.round(rect.height*dpr);}
 ctx=canvas.getContext('2d');ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,rect.width,rect.height);
 const W=rect.width<600?390:660,H=550;scale=Math.min(rect.width/W,rect.height/H);ox=(rect.width-W*scale)/2;oy=(rect.height-H*scale)/2;
 ctx.translate(ox,oy);ctx.scale(scale,scale);
 const r=FloatPhysics.solve(s);if(s.scene==='meter')meter(s,r,W,time);else ship(s,r,W,time);
}
function meter(s,r,W,time){
 const top=225,bottom=520,x=W===390?143:260,k=520,base=top+s.h*k,left=x-76,right=x+76;
 // 量筒玻璃边缘与真实比例的杆、球部（0.50 m 与 0.10 m）。
 box(left,20,152,502,'#5589a90c',14);water(top,bottom,left+2,right-2,time);
 const stemTop=base-312,bulbTop=base-52;
 const glass=ctx.createLinearGradient(x-24,0,x+24,0);glass.addColorStop(0,'#649dba');glass.addColorStop(.4,'#e1f0e7');glass.addColorStop(.65,'#b7cfd1');glass.addColorStop(1,'#5e899d');
 ctx.save();ctx.shadowBlur=s.held?18:0;ctx.shadowColor=C.gold;box(x-7,stemTop,14,270,glass,6);box(x-24,bulbTop,48,52,glass,21);ctx.restore();
 for(let i=0;i<18;i++){const a=i*2.399;ctx.beginPath();ctx.arc(x+Math.cos(a)*15,base-10-Math.abs(Math.sin(a))*14,2.8,0,7);ctx.fillStyle='#354659';ctx.fill();}
 for(let d=800;d<=1200;d+=20){const yy=base-FloatPhysics.meterDepth(d)*k;line(x-6,yy,x+(d%100===0?6:1),yy,'#253a4d');if(d%100===0)text((d/1000).toFixed(2),x+14,yy+4,11,C.text);}
 ctx.save();ctx.beginPath();ctx.rect(left,top,right-left,bottom-top);ctx.clip();box(x-24,bulbTop,48,52,'#1977a033',21);ctx.restore();
 line(left,top,right,top,C.blue,1.5);line(left,20,left,512,'#7bafc270',2);line(right,20,right,512,'#7bafc270',2);line(left,512,right,512,'#8cbacc',2);line(left-5,20,left+5,20,'#aec5d6',2);line(right-5,20,right+5,20,'#aec5d6',2);box(left-16,522,184,7,'#344858',3);
 line(left+8,32,left+8,209,'#e5f5ff22',3);text('80 g',x,base+20,11,C.muted,'center');
 // 放大刻度按同一反比例公式绘制，水线指向当前浸入位置；手持时不伪装成密度读数。
 const zx=W===390?286:468,zy=92,zscale=630;
 box(zx-16,44,105,280,'#0e1824',10);text('刻度放大',zx+35,26,12,C.muted,'center');text('g/cm³',zx+35,65,11,C.muted,'center');
 const yFor=d=>zy+(FloatPhysics.meterDepth(800)-FloatPhysics.meterDepth(d))*zscale;
 line(zx,zy,zx,yFor(1200),'#adc9d7',2);
 for(let d=800;d<=1200;d+=20){const yy=yFor(d);line(zx,yy,zx+(d%100===0?18:9),yy,d%100===0?'#d4e2ec':'#58758a');if(d%100===0)text((d/1000).toFixed(2),zx+25,yy+4,12,C.text);}
 const readY=zy+(FloatPhysics.meterDepth(800)-s.h)*zscale;
 if(readY>=zy-10&&readY<=yFor(1200)+10){line(right+3,top,zx-21,readY,'#6dd5e455',1,[3,4]);line(zx-10,readY,zx+76,readY,C.blue,1.5);}
 text(s.held?'手持中':Math.abs(s.h-r.target)<.001?`读数 ${(s.rho/1000).toFixed(3)}`:'等待平衡',zx+35,346,14,C.blue,'center');
 const fx=zx+8;arrow(fx,424,-Math.min(72,r.buoy/.8*60),C.blue,'F浮');arrow(fx,424,60,C.gold,'G');text(s.held?'还有手的作用力':'浮力与重力',zx+30,514,11,C.muted,'center');
 text('水线',left-8,top+4,11,C.blue,'right');geometry={type:'meter',x:x-30,y:stemTop,w:70,h:base-stemTop+10,k};
}
function ship(s,r,W,time){
 const top=285,k=25,beam=W===390?270:440,x=(W-beam)/2-12,deck=top-(6-s.shipH)*k,bottom=deck+162;
 // 剖视箱形船，水面固定；装货后船身相对水线下移。
 ctx.beginPath();ctx.moveTo(0,278);ctx.lineTo(W*.15,242);ctx.lineTo(W*.22,259);ctx.lineTo(W*.39,222);ctx.lineTo(W*.53,275);ctx.lineTo(W,247);ctx.lineTo(W,300);ctx.lineTo(0,300);ctx.fillStyle='#192c35';ctx.fill();
 water(top,503,0,W,time);
 const hull=ctx.createLinearGradient(0,deck,0,bottom);hull.addColorStop(0,'#d9b46c');hull.addColorStop(1,'#816036');box(x,deck,beam,162,hull,5);box(x+7,deck,beam-14,153,'#111e2b',2);box(x+7,bottom-9,beam-14,6,C.gold,1);
 box(x+10,deck-69,57,69,'#b6c9ce',4);box(x+20,deck-54,15,18,'#31556a',2);box(x+42,deck-54,15,18,'#31556a',2);box(x+5,deck-75,66,7,'#718d9e',2);line(x+35,deck-75,x+35,deck-107,'#adc4d3',2);
 ctx.beginPath();ctx.moveTo(x+36,deck-107);ctx.lineTo(x+62,deck-99);ctx.lineTo(x+36,deck-92);ctx.fillStyle=C.gold;ctx.fill();
 const cw=(beam-110)/4;for(let i=0;i<Math.ceil(s.cargo/100);i++){const xx=x+80+(i%4)*cw,yy=deck-35-Math.floor(i/4)*36;box(xx,yy,cw-3,32,i%2?'#bd803e':'#e7b95b',2);for(let j=1;j<4;j++)line(xx+j*(cw-3)/4,yy+4,xx+j*(cw-3)/4,yy+28,'#765427',1);}
 for(let d=0;d<=6;d++){const y=bottom-d*k;line(x+beam-20,y,x+beam-6,y,'#ffe5a0');text(String(d),x+beam-26,y+4,10,'#ffe5a0','right');}
 line(0,top,W,top,C.blue,1.5);text('水线',12,top-10,12,C.blue);
 const dx=x+beam+20;line(dx,top,dx,bottom,C.gold,1.5);line(dx-5,top,dx+5,top,C.gold);line(dx-5,bottom,dx+5,bottom,C.gold);
 text(`${r.depth.toFixed(2)} m`,W/2,470,18,C.gold,'center');text(r.over?'已达型深上限':'吃水深度',W/2,492,11,C.muted,'center');
 text(`货物 ${s.cargo.toFixed(0)} t`,W/2,38,16,C.gold,'center');text('上下拖动货箱，观察船身与水线',W/2,62,12,C.muted,'center');
 if(r.over){box(20,92,W-40,34,'#542c27',6);text('船舷触水 · 存在进水风险',W/2,114,13,'#ffbea0','center');}
 text(`排水量 ${(r.vol*s.rho/1000).toFixed(0)} t`,W/2-75,535,12,C.blue,'center');text(`排水体积 ${r.vol.toFixed(1)} m³`,W/2+75,535,12,C.blue,'center');
 geometry={type:'ship',x:x+72,y:deck-95,w:beam-78,h:125,k};
}
function point(e,canvas){const r=canvas.getBoundingClientRect();return {x:(e.clientX-r.left-ox)/scale,y:(e.clientY-r.top-oy)/scale};}
function hit(p){const g=geometry;return p.x>=g.x&&p.x<=g.x+g.w&&p.y>=g.y-12&&p.y<=g.y+g.h;}
window.FloatDraw={draw,point,hit,get geometry(){return {...geometry,scale,ox,oy};}};
})();
