/* 纯计算：SI 单位。密度计竖直坐标 h 为底端至水面的距离。 */
(function(){
'use strict';
const M=.08, AREA=.0001, BULB=.00006, BH=.10, STEM=.50;
const clamp=(v,a,b)=>Math.min(b,Math.max(a,v));
function volume(h){return BULB*clamp(h/BH,0,1)+AREA*clamp(h-BH,0,STEM);}
function meterDepth(rho){return BH+(M/rho-BULB)/AREA;}
function solve(s){
 if(s.scene==='meter'){
  const v=volume(s.h);return {mass:M,vol:v,weight:M*10,buoy:rhoSafe(s.rho)*v*10,depth:s.h,target:meterDepth(s.rho),over:false};
 }
 const mass=(400+s.cargo)*1000, maxVol=200*6, need=mass/s.rho;
 return {mass,vol:Math.min(need,maxVol),weight:mass*10,buoy:Math.min(need,maxVol)*s.rho*10,depth:Math.min(need/200,6),target:Math.min(need/200,6),over:need>=maxVol};
}
function rhoSafe(r){return clamp(r,800,1200);}
window.FloatPhysics={M,AREA,BULB,BH,STEM,clamp,volume,meterDepth,solve};
})();
