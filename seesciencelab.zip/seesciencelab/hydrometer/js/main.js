(function(){
'use strict';
const $=id=>document.getElementById(id),P=FloatPhysics,q=new URLSearchParams(location.search);
function num(key,def,a,b){const raw=q.get(key),v=raw===null?def:Number(raw);return P.clamp(Number.isFinite(v)?v:def,a,b);}
const state={scene:q.get('scene')==='ship'?'ship':'meter',rho:num('rho',1000,800,1200),cargo:num('cargo',400,0,800),h:0,shipH:0,held:false};
state.h=P.meterDepth(state.rho);state.shipH=P.solve({...state,scene:'ship'}).depth;
const canvas=$('view');let last=0,drag=null,records=[];
const reduceMotion=matchMedia('(prefers-reduced-motion: reduce)');
function track(action,label){if(window.Analytics)Analytics.track('密度计与轮船',action,String(label));}
function controls(){ $('rho').value=state.rho;$('cargo').value=state.cargo;$('rhoOut').textContent=state.rho+' kg/m³';$('cargoOut').textContent=state.cargo+' t';$('cargoPanel').hidden=state.scene!=='ship';document.querySelectorAll('[data-scene]').forEach(b=>{const on=b.dataset.scene===state.scene;b.classList.toggle('on',on);b.setAttribute('aria-pressed',String(on));});document.querySelectorAll('[data-rho]').forEach(b=>{const on=Number(b.dataset.rho)===state.rho;b.classList.toggle('on',on);b.setAttribute('aria-pressed',String(on));});$('stageTitle').textContent=state.scene==='meter'?'液体越密，密度计浸得越浅':'装上货物，船会浸得更深';$('hint').textContent=state.scene==='meter'?'拖动密度计再松手，观察它回到平衡':'上下拖动货箱装卸，比较水线与吃水';}
function update(){controls();const r=P.solve(state),ship=state.scene==='ship',at=Math.abs(state.h-r.target)<.0001;
 $('stageConclusion').textContent=ship?(r.over?'已达排水上限，不能继续套用漂浮条件':`总质量 ${(r.mass/1000).toFixed(0)} t · 漂浮时 F浮 = G`):'同一支密度计 · 平衡时 F浮 = G = 0.80 N';
 $('status').textContent=r.over?'到达 / 超过最大排水能力':state.held?'手持中：还有手的作用力':ship?'轮船漂浮平衡':at?'密度计漂浮平衡':'正在回到漂浮位置';
 $('rRho').textContent=state.rho.toFixed(0)+' kg/m³';$('rMass').textContent=ship?(r.mass/1000).toFixed(0)+' t':'80.0 g';$('rVol').textContent=ship?r.vol.toFixed(2)+' m³':(r.vol*1e6).toFixed(2)+' cm³';$('rForce').textContent=ship?(r.buoy/1e6).toFixed(3)+' / '+(r.weight/1e6).toFixed(3)+' MN':r.buoy.toFixed(2)+' / 0.80 N';$('depthLabel').textContent=ship?'平衡吃水 / 极限':'底端浸入深度';$('rDepth').textContent=ship?r.depth.toFixed(2)+' m':(state.h*100).toFixed(2)+' cm';$('explain').textContent=ship?(r.over?'船舷达到水面后可能进水；本模型只提示风险，不计算沉船。':`排水量 ${(r.mass/1000).toFixed(0)} t = 空船 400 t + 货物 ${state.cargo.toFixed(0)} t。`):'平衡时浮力恒定；液体密度越小，密度计需要浸得越深。';
}
function setScene(scene){state.scene=scene;state.held=false;state.h=P.meterDepth(state.rho);state.shipH=P.solve({...state,scene:'ship'}).depth;records=[];$('records').textContent='';update();track('切换场景',scene);}
document.querySelectorAll('[data-scene]').forEach(b=>b.onclick=()=>setScene(b.dataset.scene));
function setRho(v){state.rho=P.clamp(Number(v),800,1200);state.shipH=P.solve({...state,scene:'ship'}).depth;update();}
$('rho').oninput=e=>setRho(e.target.value);$('rho').onchange=()=>track('改变密度',state.rho);
document.querySelectorAll('[data-rho]').forEach(b=>b.onclick=()=>{setRho(b.dataset.rho);track('液体预设',state.rho);});
function setCargo(v){state.cargo=P.clamp(Number(v),0,800);state.shipH=P.solve({...state,scene:'ship'}).depth;update();}
$('cargo').oninput=e=>setCargo(e.target.value);$('cargo').onchange=()=>track('改变载重',state.cargo);$('load').onclick=()=>{setCargo(state.cargo+100);track('装货',state.cargo);};$('unload').onclick=()=>{setCargo(state.cargo-100);track('卸货',state.cargo);};
$('reset').onclick=()=>{state.rho=1000;state.cargo=400;setScene(state.scene);track('重置',state.scene);};
$('record').onclick=()=>{const r=P.solve(state);if(state.held||Math.abs(state.h-r.target)>.001&&state.scene==='meter'||r.over){$('message').textContent='请等待漂浮平衡后记录。';return;}records.push(state.scene==='meter'?`ρ=${state.rho}，V排=${(r.vol*1e6).toFixed(2)} cm³，F浮=${r.buoy.toFixed(2)} N`:`ρ=${state.rho}，货物${state.cargo} t，吃水${r.depth.toFixed(2)} m`);records=records.slice(-6);$('records').replaceChildren(...records.map(t=>{const d=document.createElement('div');d.textContent=t;return d;}));$('message').textContent='已记录平衡状态';track('记录',state.scene);};
$('share').onclick=async()=>{const u=new URL(location.href);u.search=new URLSearchParams({scene:state.scene,rho:state.rho,cargo:state.cargo}).toString();try{await navigator.clipboard.writeText(u.href);$('message').textContent='已复制条件链接';}catch{$('message').textContent=u.href;}track('分享',state.scene);};
function togglePanel(){const closed=$('panel').classList.toggle('collapsed');$('panelToggle').setAttribute('aria-expanded',String(!closed));$('panelToggle').setAttribute('aria-label',closed?'显示控制面板':'隐藏控制面板');} $('panelToggle').onclick=togglePanel;if(matchMedia('(max-width:760px)').matches)$('panel').classList.add('collapsed');
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!$('panel').classList.contains('collapsed')&&matchMedia('(max-width:760px)').matches)togglePanel();});
canvas.onpointerdown=e=>{const pos=FloatDraw.point(e,canvas);if(!FloatDraw.hit(pos))return;e.preventDefault();drag={y:pos.y,h:state.h,cargo:state.cargo,k:FloatDraw.geometry.k};state.held=state.scene==='meter';canvas.setPointerCapture(e.pointerId);update();};
canvas.onpointermove=e=>{const pos=FloatDraw.point(e,canvas);canvas.style.cursor=drag?'grabbing':FloatDraw.hit(pos)?'grab':'default';if(!drag)return;if(state.scene==='meter')state.h=P.clamp(drag.h+(pos.y-drag.y)/drag.k,.12,.53);else setCargo(Math.round(P.clamp(drag.cargo+(drag.y-pos.y)*4,0,800)/10)*10);update();};
function release(){if(!drag)return;drag=null;state.held=false;track('画面拖动',state.scene);update();}canvas.onpointerup=release;canvas.onpointercancel=release;canvas.onlostpointercapture=release;
function frame(t){const dt=Math.min((t-last)/1000,.05);last=t;if(!state.held){const target=P.meterDepth(state.rho);state.h=reduceMotion.matches?target:state.h+(target-state.h)*(1-Math.exp(-dt*4));if(Math.abs(state.h-target)<.00001)state.h=target;}FloatDraw.draw(canvas,state,t/1800);update();requestAnimationFrame(frame);}
window.__model={state,update,setScene,setRho,setCargo,settle(){state.h=P.meterDepth(state.rho);update();},solve:()=>P.solve(state)};controls();requestAnimationFrame(frame);
})();
