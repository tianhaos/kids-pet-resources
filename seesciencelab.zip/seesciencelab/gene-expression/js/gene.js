// 人工短编码区；序列统一按编码链 5′→3′ 保存，位置配对不反转。
(function () {
  'use strict';
  const sequences = { normal: 'ATGGCTTTTGGACAATAA', missense: 'ATGGCTTATGGACAATAA', stop: 'ATGGCTTAAGGACAATAA' };
  const pairs = { A: 'T', T: 'A', G: 'C', C: 'G' };
  // 本教学短序列涉及的标准遗传密码；不接收任意外来序列。
  const code = { AUG: '甲硫氨酸', GCU: '丙氨酸', UUU: '苯丙氨酸', UAU: '酪氨酸', GGA: '甘氨酸', CAA: '谷氨酰胺', UAA: '终止', UAG: '终止', UGA: '终止' };
  function complement(s) { return [...s].map(b => pairs[b]).join(''); }
  function rna(s) { return s.replace(/T/g, 'U'); }
  function anticodon(s) { return [...s].map(b => ({ A: 'U', U: 'A', G: 'C', C: 'G' })[b]).join(''); }
  function codons(s) { return rna(s).match(/.{3}/g) || []; }
  function translate(s) {
    const peptide = [];
    for (const c of codons(s)) { if (code[c] === '终止') break; peptide.push(code[c]); }
    return peptide;
  }
  function limit(scene) { return scene === 'translation' ? 6 : 18; }
  function sample(state) {
    const dna = sequences[state.variant] || sequences.normal;
    const n = Math.max(0, Math.min(limit(state.scene), Math.floor(state.t)));
    const cs = codons(dna);
    const stop = cs.findIndex(c => code[c] === '终止');
    return { dna, template: complement(dna), rna: rna(dna), n, codons: cs, stop,
      peptide: translate(dna).slice(0, n), terminated: state.scene === 'translation' && n > stop };
  }
  window.Gene = { sequences, code, complement, rna, anticodon, codons, translate, limit, sample };
})();
