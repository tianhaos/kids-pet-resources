(function () {
  'use strict';
  const $ = id => document.getElementById(id);
  const params = new URLSearchParams(location.search);
  const canvas = $('gene');
  const sceneButtons = [...document.querySelectorAll('[data-scene]')];
  const colors = GeneDraw.colors;
  const scenes = {
    replication: {
      title: '半保留复制',
      explain: '两条亲代链各自作模板。蓝色新链沿各自的 5′→3′ 方向延伸，完成时每份子代 DNA 各有一条旧链和一条新链。',
      legend: [[colors.dna, '亲代 DNA'], [colors.copy, '新 DNA']],
      hint: '点选任一列碱基，查看两份 DNA 的配对状态。'
    },
    transcription: {
      title: '从模板链合成 RNA',
      explain: '沿虚线比较同一位点：mRNA 与下方模板链互补。对照上方编码链，mRNA 用 U 代替 T。',
      legend: [[colors.dna, 'DNA'], [colors.rna, 'mRNA'], ['#809dca', 'RNA 聚合酶']],
      hint: '点选任一列碱基，对照编码链、模板链和 mRNA。'
    },
    translation: {
      title: '核糖体逐个读取密码子',
      explain: '对照当前密码子与 tRNA 反密码子的方向。试试错义和无义预设，观察第三个密码子怎样改变肽链。',
      legend: [[colors.rna, 'mRNA'], [colors.copy, 'tRNA'], [colors.ribosome, '核糖体'], [colors.stop, '释放因子'], [colors.dna, '氨基酸']],
      hint: '点选任一密码子，查看它对应的氨基酸或终止信号。'
    }
  };
  const variants = {
    normal: '对照基准，第三个密码子 UUU 编码苯丙氨酸。',
    missense: '第 8 位改变，第三个密码子 UUU → UAU，苯丙氨酸换成酪氨酸。',
    stop: '第 8、9 位改变，第三个密码子 UUU → UAA，肽链提前终止。'
  };
  const state = {
    scene: Object.hasOwn(scenes, params.get('scene')) ? params.get('scene') : 'replication',
    variant: Object.hasOwn(Gene.sequences, params.get('variant')) ? params.get('variant') : 'normal',
    t: 0,
    play: params.get('play') === '1'
  };
  const mobile = matchMedia('(max-width: 760px)');
  let selected = null, hovered = null, geometry = null;
  let dirty = true;

  function limit(s = Gene.sample(state)) {
    return state.scene === 'translation' ? s.stop + 1 : Gene.limit(state.scene);
  }

  // 无定位参数的入口停在半保留复制的中段，显式的零进度链接仍从第一步开始。
  const entryProgress = !['scene', 'variant', 't', 'play'].some(key => params.has(key)) ? 9 : 0;
  state.t = Math.max(0, Math.min(limit(), params.has('t') ? Number(params.get('t')) || 0 : entryProgress));

  function track(action, label = state.scene) {
    if (window.Analytics) Analytics.track('DNA 复制、转录与翻译', action, label);
  }
  function probeText(index, s) {
    const number = index + 1;
    if (state.scene === 'replication') {
      const first = index >= 18 - s.n ? `${s.dna[index]}–${s.template[index]}` : `${s.dna[index]} 等待配对`;
      const second = index < s.n ? `${s.template[index]}–${s.dna[index]}` : `${s.template[index]} 等待配对`;
      return `第 ${number} 位 · 子代① ${first} · 子代② ${second}（亲代在前）`;
    }
    if (state.scene === 'transcription') {
      const rna = index < s.n ? s.rna[index] : '待合成';
      return `第 ${number} 位 · 编码链 ${s.dna[index]} · 模板链 ${s.template[index]} · mRNA ${rna}`;
    }
    const detail = index === s.stop ? '终止 · 由释放因子识别' : `${Gene.code[s.codons[index]]} · 反密码子 3′-${Gene.anticodon(s.codons[index])}-5′`;
    return `第 ${number} 个 ${s.codons[index]} · ${index > s.stop ? '终止后不会读取' : detail}`;
  }

  function updateProbe(s) {
    const index = hovered ?? selected;
    const message = index === null ? scenes[state.scene].hint : probeText(index, s);
    if ($('probe').textContent !== message) $('probe').textContent = message;
    dirty = true;
  }
  function update() {
    const s = Gene.sample(state), end = limit(s);
    const unit = state.scene === 'translation' ? '密码子' : '碱基';
    $('progress').max = end;
    $('progress').value = s.n;
    $('progress').setAttribute('aria-valuetext', `已处理 ${s.n} / ${end} 个${unit}`);
    $('count').textContent = `${s.n} / ${end} ${unit}`;
    $('play').textContent = state.play ? 'Ⅱ 暂停' : (s.n === end ? '↻ 重播' : '▶ 播放');
    $('step').disabled = s.n === end;
    $('reset').disabled = state.t === 0;
    updateProbe(s);
  }
  function updateScene() {
    const scene = scenes[state.scene];
    $('sceneTitle').textContent = scene.title;
    $('explain').textContent = scene.explain;
    $('legend').replaceChildren(...scene.legend.map(([color, name]) => {
      const item = document.createElement('span');
      const swatch = document.createElement('i');
      swatch.style.backgroundColor = color;
      item.append(swatch, name);
      return item;
    }));
    sceneButtons.forEach(button => {
      const active = button.dataset.scene === state.scene;
      button.classList.toggle('on', active);
      button.setAttribute('aria-pressed', active);
    });
    $('variant').value = state.variant;
    const s = Gene.sample(state), peptide = Gene.translate(s.dna);
    $('result').textContent = `第 ${s.stop + 1} 个密码子终止 · ${peptide.length} 个氨基酸`;
    $('peptideResult').textContent = peptide.join(' → ');
    $('mutationNote').textContent = variants[state.variant];
    update();
  }

  function setScene(scene) {
    if (!Object.hasOwn(scenes, scene)) return;
    state.scene = scene;
    state.t = 0;
    state.play = false;
    selected = hovered = null;
    updateScene();
  }
  function setVariant(variant) {
    if (!Object.hasOwn(Gene.sequences, variant)) return;
    state.variant = variant;
    state.t = 0;
    state.play = false;
    selected = hovered = null;
    updateScene();
  }
  function setT(t) {
    state.t = Math.max(0, Math.min(limit(), Number(t) || 0));
    update();
  }
  function advance(dt) {
    const end = limit(), previous = Math.floor(state.t), wasPlaying = state.play;
    state.t = Math.min(end, state.t + dt);
    if (state.t >= end) state.play = false;
    if (previous !== Math.floor(state.t) || wasPlaying !== state.play) update();
  }
  function setPanel(open) {
    $('panel').classList.toggle('open', open);
    $('panelToggle').setAttribute('aria-expanded', open);
    if (open) $('panelClose').focus();
    else if (mobile.matches) $('panelToggle').focus();
  }

  sceneButtons.forEach(button => button.onclick = () => {
    if (state.scene === button.dataset.scene) return;
    setScene(button.dataset.scene);
    track('切换');
  });
  $('variant').onchange = e => { setVariant(e.target.value); track('序列对照', state.variant); };
  $('progress').oninput = e => { state.play = false; setT(e.target.value); };
  $('progress').onchange = () => track('进度');
  $('play').onclick = () => {
    if (state.t >= limit()) state.t = 0;
    state.play = !state.play;
    update();
    track('播放暂停');
  };
  $('step').onclick = () => {
    state.play = false;
    advance(1 - state.t % 1);
    track('下一步');
  };
  $('reset').onclick = () => { state.play = false; setT(0); track('重来'); };
  $('panelToggle').onclick = () => setPanel(true);
  $('panelClose').onclick = () => setPanel(false);
  $('panel').onkeydown = e => { if (e.key === 'Escape' && mobile.matches) setPanel(false); };
  mobile.addEventListener('change', () => {
    $('panel').classList.remove('open');
    $('panelToggle').setAttribute('aria-expanded', 'false');
  });
  $('share').onclick = async () => {
    const url = new URL(location.href);
    url.search = new URLSearchParams({ scene: state.scene, variant: state.variant, t: Math.floor(state.t), play: '0' });
    try {
      await navigator.clipboard.writeText(url.href);
      $('shareStatus').textContent = '已复制当前步骤链接';
    } catch {
      $('shareStatus').textContent = url.href;
    }
    track('分享');
  };

  function hit(e) {
    if (!geometry) return null;
    const box = canvas.getBoundingClientRect();
    const x = e.clientX - box.left, y = e.clientY - box.top;
    if (x < geometry.left || x >= geometry.right || !geometry.bands.some(([top, bottom]) => y >= top && y <= bottom)) return null;
    const group = state.scene === 'translation' ? 3 : 1;
    return Math.floor((x - geometry.left) / (geometry.cell * group));
  }
  canvas.onpointermove = e => {
    if (e.pointerType === 'touch') return;
    const index = hit(e);
    canvas.style.cursor = index === null ? '' : 'crosshair';
    if (index !== hovered) {
      hovered = index;
      updateProbe(Gene.sample(state));
    }
  };
  canvas.onpointerleave = () => { hovered = null; updateProbe(Gene.sample(state)); };
  canvas.onclick = e => {
    const index = hit(e);
    hovered = null;
    selected = index === selected ? null : index;
    updateProbe(Gene.sample(state));
  };
  canvas.onkeydown = e => {
    if (!['ArrowLeft', 'ArrowRight', 'Escape'].includes(e.key)) return;
    e.preventDefault();
    hovered = null;
    const max = state.scene === 'translation' ? 5 : 17;
    const delta = e.key === 'ArrowLeft' ? -1 : 1;
    selected = e.key === 'Escape' ? null : (selected === null ? (delta < 0 ? max : 0) : Math.max(0, Math.min(max, selected + delta)));
    updateProbe(Gene.sample(state));
  };
  new ResizeObserver(() => { dirty = true; }).observe(canvas);

  let last = performance.now();
  function frame(now) {
    const dt = Math.min(.1, (now - last) / 1000);
    last = now;
    if (state.play) advance(dt * (state.scene === 'translation' ? .65 : 2));
    if (dirty) {
      geometry = GeneDraw.render(canvas, state, Gene.sample(state), hovered ?? selected);
      dirty = false;
    }
    requestAnimationFrame(frame);
  }
  window.__model = { state, setScene, setT, setVariant, advance, update, sample: () => Gene.sample(state) };
  updateScene();
  requestAnimationFrame(frame);
})();
