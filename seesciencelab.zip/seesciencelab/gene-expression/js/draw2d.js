// 碱基与方向按科学计算的结果绘制。轮廓和间距为示意。
(function () {
  'use strict';
  const colors = { dna: '#ffc94a', copy: '#6dccff', rna: '#7ee0a0', ribosome: '#abafff', stop: '#ff9d87' };
  const ink = '#e6eef8', muted = '#a4b2c7';

  function render(canvas, state, s, selected = null, preview = false) {
    const { width: w, height: h } = canvas.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    if (canvas.width !== Math.round(w * dpr) || canvas.height !== Math.round(h * dpr)) {
      canvas.width = Math.round(w * dpr);
      canvas.height = Math.round(h * dpr);
    }
    const c = canvas.getContext('2d');
    c.setTransform(dpr, 0, 0, dpr, 0, 0);
    if (w < 80 || h < 80) return null;

    const compact = w < 540;
    const cell = Math.min(44, (w - (compact ? 62 : 116)) / 18);
    const x0 = (w - cell * 18) / 2, right = w - x0;
    const x = i => x0 + (i + .5) * cell;
    const baseHeight = Math.min(25, cell * .8 + 4);
    const backbone = baseHeight / 2 + 7;
    const bands = [];
    const gradient = c.createRadialGradient(w / 2, h * .44, 1, w / 2, h * .45, Math.max(w, h) * .62);
    gradient.addColorStop(0, '#131f30');
    gradient.addColorStop(1, '#0a0f19');
    c.fillStyle = gradient;
    c.fillRect(0, 0, w, h);
    c.fillStyle = '#91abd020';
    for (let yy = 14; yy < h; yy += 22) {
      for (let xx = 14; xx < w; xx += 22) c.fillRect(xx, yy, 1, 1);
    }

    function text(label, xx, yy, color = ink, size = 13, align = 'left', bold = false, mono = false) {
      c.font = `${bold ? 650 : 450} ${size}px ${mono ? 'Menlo, Consolas, monospace' : '-apple-system, "PingFang SC", "Microsoft YaHei", sans-serif'}`;
      c.fillStyle = color;
      c.textAlign = align;
      c.textBaseline = 'middle';
      c.fillText(label, xx, yy);
    }
    function line(x1, y1, x2, y2, color, width = 1) {
      c.strokeStyle = color;
      c.lineWidth = width;
      c.beginPath();
      c.moveTo(x1, y1);
      c.lineTo(x2, y2);
      c.stroke();
    }
    function box(xx, yy, width, height, radius, fill, edge) {
      c.beginPath();
      c.roundRect(xx, yy, width, height, radius);
      c.fillStyle = fill;
      c.fill();
      if (edge) {
        c.strokeStyle = edge;
        c.lineWidth = 1;
        c.stroke();
      }
    }
    function base(xx, yy, width, height, letter, color, direction, active = true) {
      const a = width / 2, b = height / 2;
      c.beginPath();
      c.moveTo(xx - a, yy - b * direction);
      c.lineTo(xx + a, yy - b * direction);
      c.lineTo(xx + a, yy + b * .38 * direction);
      c.lineTo(xx, yy + b * direction);
      c.lineTo(xx - a, yy + b * .38 * direction);
      c.closePath();
      c.fillStyle = active ? color + '31' : '#111a28';
      c.fill();
      c.strokeStyle = active ? color + 'b0' : '#36425a';
      c.lineWidth = 1;
      c.stroke();
      if (active) text(letter, xx, yy - direction, color, Math.min(16, width * .85 + 2), 'center', true, true);
    }
    function strand(seq, yy, color, direction, left, start = 0, end = 18) {
      const rail = yy - direction * backbone;
      if (start < end) line(x(start), rail, x(end - 1), rail, color, 2);
      for (let i = 0; i < 18; i++) {
        const active = i >= start && i < end;
        base(x(i), yy, cell - 3, baseHeight, seq[i], color, direction, active);
        if (active) {
          line(x(i), rail, x(i), yy - direction * baseHeight / 2, color + 'b0');
          c.beginPath();
          c.arc(x(i), rail, compact ? 1.7 : 2.4, 0, Math.PI * 2);
          c.fillStyle = color;
          c.fill();
        }
      }
      text(left, x0 - 7, yy, color, 12, 'right', true);
      text(left === '5′' ? '3′' : '5′', right + 7, yy, color, 12, 'left', true);
    }
    function bonds(start, end, y1, y2) {
      for (let i = start; i < end; i++) {
        const mid = (y1 + y2) / 2;
        line(x(i), y1 + baseHeight / 2 + 2, x(i), mid - 1, '#8398b5a0');
        line(x(i), mid + 1, x(i), y2 - baseHeight / 2 - 2, '#8398b5a0');
      }
    }
    function highlight(index, y1, y2, group = 1) {
      if (index === null) return;
      box(x0 + index * cell * group, y1, cell * group, y2 - y1, 5, '#e2eaff15', '#d9e6fa');
    }
    function label(labelText, yy, color = muted) {
      text(labelText, x0, yy, color, compact ? 11 : 13);
    }
    function footer(labelText, yy, color, align = 'center') {
      text(labelText, align === 'center' ? w / 2 : (align === 'right' ? right : x0), yy, color, compact ? 11 : 13, align);
    }

    if (state.scene === 'replication') {
      const gap = Math.min(compact ? 45 : 58, h * .153);
      for (let copy = 0; copy < 2; copy++) {
        const mid = h * (copy ? .74 : .25), y1 = mid - gap / 2, y2 = mid + gap / 2;
        const start = copy ? 0 : 18 - s.n, end = copy ? s.n : 18;
        const titleY = y1 - backbone - 16;
        const noteY = y2 + backbone + 17;
        box(x0 - (compact ? 24 : 36), titleY - 12, (right - x0) + (compact ? 48 : 72), noteY - titleY + 30, 10, '#0b1321c0', '#2a394f');
        label(copy ? '子代 DNA ② · 上新下旧' : '子代 DNA ① · 上旧下新', titleY);
        highlight(selected, y1 - backbone - 5, y2 + backbone + 5);
        bonds(start, end, y1, y2);
        strand(s.dna, y1, copy ? colors.copy : colors.dna, 1, '5′', 0, copy ? s.n : 18);
        strand(s.template, y2, copy ? colors.dna : colors.copy, -1, '3′', copy ? 0 : start);
        const done = s.n === 18;
        footer(done ? '新链合成完成' : (copy ? '新链 5′ → 3′ 延伸 →' : '← 新链 5′ → 3′ 延伸'), noteY, colors.copy, copy ? 'left' : 'right');
        bands.push([y1 - backbone - 11, y2 + backbone + 12]);
      }
      if (preview) return null;
    } else if (state.scene === 'transcription') {
      const y1 = h * .20, y2 = h * .42, y3 = h * .65;
      label('编码链 · 5′ → 3′', y1 - backbone - 16, colors.dna);
      label('模板链 · 3′ → 5′ 读取', y2 - backbone - 15, colors.dna);
      const machineX = x(Math.min(s.n, 17));
      if (s.n < 18) {
        c.save();
        c.translate(machineX, (y2 + y3) / 2);
        const radius = Math.min(32, cell * 1.3 + 7);
        c.scale(radius / 30, Math.min(1, (y3 - y2) / 84));
        c.beginPath();
        c.moveTo(-29, -14);
        c.bezierCurveTo(-32, -38, -9, -46, 13, -37);
        c.bezierCurveTo(34, -32, 39, -7, 24, 7);
        c.bezierCurveTo(39, 23, 15, 46, -12, 36);
        c.bezierCurveTo(-34, 32, -40, 8, -22, -3);
        c.closePath();
        c.fillStyle = '#263951';
        c.fill();
        c.strokeStyle = '#809dca';
        c.lineWidth = 1.6;
        c.stroke();
        c.restore();
      }
      highlight(selected, y1 - backbone - 5, y3 + backbone + 5);
      strand(s.dna, y1, colors.dna, 1, '5′');
      c.setLineDash([3, 5]);
      for (let i = 0; i < s.n; i++) {
        line(x(i), y2 + baseHeight / 2 + 4, x(i), y3 - baseHeight / 2 - 3, '#829cba75');
      }
      c.setLineDash([]);
      strand(s.template, y2, colors.dna, 1, '3′');
      strand(s.rna, y3, colors.rna, -1, '5′', 0, s.n);
      label(s.n === 18 ? 'mRNA · 编码区已转录' : 'mRNA · 从 5′ 向 3′ 延伸 →', y3 + backbone + 20, colors.rna);
      footer(s.n === 18 ? '比较编码链与 mRNA：T 对应 U' : '蓝灰轮廓为 RNA 聚合酶', h * .91, muted);
      bands.push([y1 - backbone - 11, y3 + backbone + 12]);
    } else {
      const idx = Math.min(s.n, s.stop), codon = s.codons[idx];
      const overview = h * .16, cx = x(idx * 3 + 1), yPair = h * .58;
      const detailWidth = Math.min(right - x0 + 22, 430);
      const stop = idx === s.stop;
      label('mRNA · 核糖体按 5′ → 3′ 读取', overview - backbone - 19, colors.rna);
      for (let i = 0; i < 6; i++) {
        const start = x0 + i * 3 * cell;
        const edge = i === idx ? (stop ? colors.stop : colors.ribosome) : '#334159';
        box(start + 1, overview - 16, cell * 3 - 2, 34, 5, i === idx ? edge + '34' : '#142133', edge);
        text(s.codons[i], x(i * 3 + 1), overview, i > s.stop ? '#8594a9' : colors.rna, compact ? 12 : 16, 'center', true, true);
        text(String(i + 1), x(i * 3 + 1), overview + 29, muted, 11, 'center');
      }
      text('5′', x0 - 7, overview, colors.rna, 12, 'right', true);
      text('3′', right + 7, overview, colors.rna, 12, 'left', true);
      highlight(selected, overview - 19, overview + 20, 3);
      bands.push([overview - 24, overview + 38]);

      const top = h * .32, bottom = h * .70;
      const detailX = Math.max(w / 2 - detailWidth / 2 + 14, Math.min(w / 2 + detailWidth / 2 - 14, cx));
      const connector = stop ? colors.stop : colors.ribosome;
      line(cx, overview + 37, cx, (overview + 37 + top) / 2, connector);
      line(cx, (overview + 37 + top) / 2, detailX, (overview + 37 + top) / 2, connector);
      line(detailX, (overview + 37 + top) / 2, detailX, top, connector);
      box(w / 2 - detailWidth / 2, top, detailWidth, bottom - top, 13, '#1a203a', '#515984');
      text(s.terminated ? '核糖体 · 终止位点' : '核糖体 · 当前位点', w / 2 - detailWidth / 2 + 10, top + 15, colors.ribosome, 11);
      const symbolY = Math.min(top + (yPair - top) * .51, yPair - 40);
      const sx = w / 2;
      if (stop) {
        c.save();
        c.translate(sx, symbolY);
        c.beginPath();
        c.moveTo(-18, -12);
        c.bezierCurveTo(-4, -26, 19, -14, 13, -3);
        c.bezierCurveTo(28, 10, 9, 17, 3, 12);
        c.bezierCurveTo(-19, 19, -24, -1, -18, -12);
        c.fillStyle = '#633c44';
        c.fill();
        c.strokeStyle = colors.stop;
        c.lineWidth = 1.5;
        c.stroke();
        c.restore();
        text('释放因子', sx + 28, symbolY, colors.stop, 12);
      } else {
        c.save();
        c.translate(sx, symbolY);
        c.beginPath();
        c.moveTo(0, 14);
        c.bezierCurveTo(-24, 13, -26, -1, -13, -4);
        c.bezierCurveTo(-6, -5, -3, 0, 0, 3);
        c.bezierCurveTo(14, -18, 30, 5, 5, 9);
        c.strokeStyle = colors.copy;
        c.lineWidth = 2;
        c.stroke();
        line(0, -11, 0, 5, colors.copy, 2);
        c.beginPath();
        c.arc(0, -13, 5, 0, Math.PI * 2);
        c.fillStyle = colors.dna;
        c.fill();
        c.restore();
        text(`tRNA · ${Gene.code[codon]}`, sx + 26, symbolY, colors.copy, 11);
      }

      const anti = Gene.anticodon(codon), spacing = 22;
      for (let i = 0; i < 3; i++) {
        const xx = sx + (i - 1) * spacing;
        if (!stop) {
          base(xx, yPair - 18, 18, 15, anti[i], colors.copy, 1);
          line(xx, yPair - 8, xx, yPair - 1, '#8da7bc');
        }
        base(xx, yPair + 8, 18, 15, codon[i], colors.rna, -1);
      }
      text('5′', sx - 40, yPair + 8, colors.rna, 11, 'right');
      text('3′', sx + 40, yPair + 8, colors.rna, 11);
      if (!stop) {
        text('3′', sx - 40, yPair - 18, colors.copy, 11, 'right');
        text('5′', sx + 40, yPair - 18, colors.copy, 11);
      }
      const title = s.terminated ? '肽链已释放' : (stop ? '下一步：终止，不再添加氨基酸' : '已连接的肽链');
      footer(title, h * .75, s.terminated ? colors.dna : muted);
      const space = Math.min(104, (w - 58) / 5), peptideY = h * .86;
      const first = sx - (s.peptide.length - 1) * space / 2;
      if (!s.peptide.length) footer('等待第一个氨基酸连接', peptideY + 5, colors.dna);
      else {
        const last = first + (s.peptide.length - 1) * space;
        line(first, peptideY, last, peptideY, colors.dna + 'b0', 2);
        text('N', first - 17, peptideY, colors.dna, 11, 'right', true);
        text('C', last + 17, peptideY, colors.dna, 11, 'left', true);
        s.peptide.forEach((aa, i) => {
          const xx = first + i * space;
          box(xx - 11, peptideY - 9, 22, 18, 6, '#604820', colors.dna);
          text(aa, xx, peptideY + 22, colors.dna, compact ? 10 : 12, 'center');
        });
      }
    }
    return { left: x0, right, cell, bands };
  }

  window.GeneDraw = { render, colors };
})();
