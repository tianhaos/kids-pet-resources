// 2D 绘图：折射规律（以入射点为圆心的量角盘）+ 三个"隔着水面看"的生活场景（世界坐标 y 向上，水面 y = 0 或水位）
// 视觉约定与凸透镜、眼睛模型一致：光线 #ffd166，反向延长线虚线，虚像 = 半透明 + 紫色 #c9a7ff 虚线描边。
(function () {
  var Rf = window.Refract, G = Rf.GEO, RAD = Math.PI / 180;

  var C = {
    grid: 'rgba(255,255,255,0.035)', axis: '#3c475a', text: '#c9d2df', muted: '#8d99ab', normal: 'rgba(230,235,242,0.55)',
    ray: '#ffd166', rayBack: 'rgba(255,209,102,0.6)', pulse: '#fff3c4', bad: '#ff7a59',
    image: '#c9a7ff', imageFill: 'rgba(201,167,255,0.32)',
    water: 'rgba(79,160,255,0.17)', waterEdge: '#6fb6ff',
    wood: '#d9a066', woodDark: '#9c6a3a', earth: '#2a2620', earthEdge: '#4a4236',
    cup: 'rgba(214,222,234,0.55)', bowl: '#aab3c2', bowlEdge: '#d6deea', coin: '#e0a83a', fish: '#ff9f43'
  };
  var MEDIA_FILL = {
    air: null,
    water: { fill: 'rgba(79,160,255,0.17)', edge: '#6fb6ff' },
    glass: { fill: 'rgba(150,220,210,0.16)', edge: '#a8e0d8' },
    diamond: { fill: 'rgba(205,195,255,0.2)', edge: '#d6ccff' }
  };

  // 各场景的世界范围（筷子、硬币 cm，池底 m）
  var BOUNDS = {
    chop: { x0: -30, x1: 16, y0: -14, y1: 24 },
    pool: { x0: -4.4, x1: 10.4, y0: -3.3, y1: 4.2 },
    coin: { x0: -26, x1: 10, y0: -1.5, y1: 18 }
  };
  // 窄屏（竖屏手机）：裁掉左侧空白，让主体大一些
  var BOUNDS_NARROW = {
    chop: { x0: -21, x1: 16, y0: -14, y1: 24 },
    pool: { x0: -2.4, x1: 10.4, y0: -3.3, y1: 3.4 },
    coin: { x0: -19, x1: 9.5, y0: -1.5, y1: 18 }
  };

  function RefDraw(canvas) {
    var ctx = canvas.getContext('2d');
    var W = 1, H = 1, dpr = 1, narrow = false, padT = 44, padB = 44;
    var s = 1, ox = 0, oy = 0;                 // 世界坐标 → 像素：px = ox + x·s，py = oy − y·s
    var LO = { x: 0, y: 0, R: 100 };           // 折射规律场景：入射点与量角盘半径

    function resize(w, h) {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      W = w; H = h;
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
      canvas.style.width = w + 'px'; canvas.style.height = h + 'px';
      narrow = w < 640;
      padT = narrow ? 88 : 44; padB = 44;
    }

    function layout(scene) {
      if (scene === 'law') {
        var avail = H - padT - padB;
        LO.R = Math.max(60, Math.min(W * (narrow ? 0.4 : 0.32), avail * 0.42, 300));
        LO.x = W / 2; LO.y = padT + avail / 2;
        return;
      }
      var b = bounds(scene), aw = W - 32, ah = H - padT - padB;
      s = Math.min(aw / (b.x1 - b.x0), ah / (b.y1 - b.y0));
      ox = 16 + (aw - (b.x1 - b.x0) * s) / 2 - b.x0 * s;
      oy = padT + (ah - (b.y1 - b.y0) * s) / 2 + b.y1 * s;
    }
    function bounds(scene) { return (narrow ? BOUNDS_NARROW : BOUNDS)[scene]; }
    function X(x) { return ox + x * s; }
    function Y(y) { return oy - y * s; }
    function toWorld(px, py) { return { x: (px - ox) / s, y: (oy - py) / s }; }

    // ---------- 基本绘图 ----------
    function seg(x1, y1, x2, y2, color, width, dash) {
      ctx.beginPath();
      ctx.setLineDash(dash || []);
      ctx.strokeStyle = color; ctx.lineWidth = width || 1.5;
      ctx.moveTo(x1, y1); ctx.lineTo(x2, y2);
      ctx.stroke();
      ctx.setLineDash([]);
    }
    function wseg(a, b, color, width, dash) { seg(X(a.x), Y(a.y), X(b.x), Y(b.y), color, width, dash); }
    function arrowMid(x1, y1, x2, y2, color, alpha) {
      var len = Math.hypot(x2 - x1, y2 - y1);
      if (len < 40) return;
      ctx.save();
      ctx.globalAlpha = alpha === undefined ? 1 : alpha;
      ctx.translate((x1 + x2) / 2, (y1 + y2) / 2); ctx.rotate(Math.atan2(y2 - y1, x2 - x1));
      ctx.beginPath(); ctx.moveTo(6, 0); ctx.lineTo(-5, -4.5); ctx.lineTo(-5, 4.5); ctx.closePath();
      ctx.fillStyle = color; ctx.fill();
      ctx.restore();
    }
    function font(size, weight) {
      ctx.font = (weight || '') + ' ' + (size || 12) + 'px -apple-system, "PingFang SC", "Microsoft YaHei", sans-serif';
    }
    function text(str, x, y, color, align, size, weight) {
      font(size, weight);
      ctx.fillStyle = color || C.text;
      ctx.textAlign = align || 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(str, x, y);
    }
    // 带深色描边的文字：压在光线上也看得清
    function htext(str, x, y, color, align, size) {
      font(size);
      ctx.textAlign = align || 'center'; ctx.textBaseline = 'middle';
      ctx.lineWidth = 4; ctx.lineJoin = 'round'; ctx.strokeStyle = 'rgba(5,7,13,0.85)';
      ctx.strokeText(str, x, y);
      ctx.fillStyle = color; ctx.fillText(str, x, y);
    }
    function roundRect(x, y, w, h, r) {
      ctx.beginPath();
      ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r);
      ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
    }
    function tag(str, x, y, color) {
      font(12);
      var w = ctx.measureText(str).width + 14;
      x = Math.max(w / 2 + 4, Math.min(W - w / 2 - 4, x));
      ctx.fillStyle = 'rgba(11,15,23,0.88)';
      ctx.strokeStyle = color; ctx.lineWidth = 1;
      roundRect(x - w / 2, y - 10, w, 20, 10);
      ctx.fill(); ctx.stroke();
      text(str, x, y, color);
    }
    function dot(x, y, r, color) { ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fillStyle = color; ctx.fill(); }

    function drawGrid(x0, y0) {
      ctx.strokeStyle = C.grid; ctx.lineWidth = 1;
      ctx.beginPath();
      var step = 32;
      for (var x = x0 % step; x < W; x += step) { ctx.moveTo(x, 0); ctx.lineTo(x, H); }
      for (var y = y0 % step; y < H; y += step) { ctx.moveTo(0, y); ctx.lineTo(W, y); }
      ctx.stroke();
    }

    // 眼睛图标：朝向 (tx, ty)
    function eyeLabel(x, y) {
      font(12);
      var w = ctx.measureText('眼睛（可拖动）').width / 2 + 4;
      text('眼睛（可拖动）', Math.max(w, Math.min(W - w, x)), y - 20, C.muted, 'center', 12);
    }
    function drawEye(x, y, tx, ty) {
      var a = Math.atan2(ty - y, tx - x);
      ctx.save();
      ctx.translate(x, y); ctx.rotate(a);
      ctx.beginPath();
      ctx.moveTo(-13, 0); ctx.quadraticCurveTo(0, -11, 13, 0); ctx.quadraticCurveTo(0, 11, -13, 0); ctx.closePath();
      ctx.fillStyle = '#eef2f7'; ctx.fill();
      ctx.strokeStyle = '#8d99ab'; ctx.lineWidth = 1.2; ctx.stroke();
      dot(4, 0, 5, '#4f86c6'); dot(5, 0, 2.4, '#0b0f17');
      ctx.restore();
    }

    // ================= 折射规律 =================
    function mediaFill(key, y0, y1) {
      var m = MEDIA_FILL[key];
      if (!m) return;
      ctx.fillStyle = m.fill;
      ctx.fillRect(0, y0, W, y1 - y0);
    }

    function angleArc(r, aFrom, aTo, color) {
      var d = aTo - aFrom;
      while (d > Math.PI) d -= 2 * Math.PI;
      while (d <= -Math.PI) d += 2 * Math.PI;
      ctx.beginPath();
      ctx.arc(LO.x, LO.y, r, aFrom, aFrom + d, d < 0);
      ctx.strokeStyle = color; ctx.lineWidth = 1.4; ctx.stroke();
      return aFrom + d / 2;
    }

    function drawLaw(st, sol) {
      var O = LO, R = LO.R;
      var sy = st.side === 'top' ? -1 : 1, lr = st.lr;
      var si = Math.sin(sol.i * RAD), ci = Math.cos(sol.i * RAD);
      var src = { x: O.x + R * lr * si, y: O.y + R * sy * ci };
      var refl = { x: O.x - R * lr * si, y: O.y + R * sy * ci };
      var tra = sol.tir ? null : { x: O.x - R * lr * Math.sin(sol.r * RAD), y: O.y - R * sy * Math.cos(sol.r * RAD) };

      mediaFill(st.top, 0, O.y);
      mediaFill(st.bot, O.y, H);
      drawGrid(O.x, O.y);
      var eT = MEDIA_FILL[st.top], eB = MEDIA_FILL[st.bot];
      seg(0, O.y, W, O.y, (eB || eT || { edge: C.axis }).edge, 1.5);

      // 介质名称
      var mT = Rf.MEDIA[st.top], mB = Rf.MEDIA[st.bot];
      text(mT.name + '  n = ' + mT.n.toFixed(2), 16, padT + 10, C.text, 'left', 13, '600');
      text('光速 ≈ ' + Rf.speed(mT.n).toFixed(2) + '×10⁸ m/s', 16, padT + 30, C.muted, 'left', 12);
      text(mB.name + '  n = ' + mB.n.toFixed(2), 16, H - padB - 26, C.text, 'left', 13, '600');
      text('光速 ≈ ' + Rf.speed(mB.n).toFixed(2) + '×10⁸ m/s', 16, H - padB - 6, C.muted, 'left', 12);

      // 量角盘
      if (st.show.ring) {
        ctx.beginPath(); ctx.arc(O.x, O.y, R, 0, Math.PI * 2);
        ctx.strokeStyle = 'rgba(230,235,242,0.22)'; ctx.lineWidth = 1; ctx.stroke();
        for (var d = 0; d < 360; d += 5) {
          var a = d * RAD, long = d % 30 === 0 ? 12 : d % 10 === 0 ? 7 : 4;
          var c = Math.cos(a), sn = Math.sin(a);
          seg(O.x + sn * R, O.y - c * R, O.x + sn * (R - long), O.y - c * (R - long), 'rgba(230,235,242,0.35)', 1);
          if (d % 30 === 0) {
            var lab = d <= 90 ? d : d <= 270 ? Math.abs(180 - d) : 360 - d;
            text(lab + '°', O.x + sn * (R - 24), O.y - c * (R - 24), 'rgba(141,153,171,0.8)', 'center', 10);
          }
        }
      }
      // 法线
      seg(O.x, O.y - R * 1.12, O.x, O.y + R * 1.12, C.normal, 1.2, [6, 5]);
      text('法线', O.x + 6, O.y - R * 1.12 + 2, C.muted, 'left', 12);

      // 临界角标记
      if (!isNaN(sol.C)) {
        var cC = Math.cos(sol.C * RAD), sC = Math.sin(sol.C * RAD);
        seg(O.x + lr * sC * (R - 16), O.y + sy * cC * (R - 16), O.x + lr * sC * (R + 6), O.y + sy * cC * (R + 6), C.bad, 2);
        if (st.show.angles) htext('临界角 ' + sol.C.toFixed(1) + '°', O.x + lr * sC * (R - 52), O.y + sy * cC * (R - 52), C.bad, 'center', 12);
      }

      // 光线：亮度按能量分配（菲涅耳公式）
      var aRefl = sol.tir ? 1 : 0.18 + 0.82 * Math.sqrt(sol.R), aTra = 0.25 + 0.75 * Math.sqrt(1 - sol.R);
      seg(src.x, src.y, O.x, O.y, C.ray, 2.5);
      arrowMid(src.x, src.y, O.x, O.y, C.ray);
      if (st.show.reflect || sol.tir) {
        ctx.globalAlpha = aRefl;
        seg(O.x, O.y, refl.x, refl.y, C.ray, sol.tir ? 2.5 : 1.8);
        ctx.globalAlpha = 1;
        arrowMid(O.x, O.y, refl.x, refl.y, C.ray, aRefl);
      }
      if (tra) {
        ctx.globalAlpha = aTra;
        seg(O.x, O.y, tra.x, tra.y, C.ray, 2.5);
        ctx.globalAlpha = 1;
        arrowMid(O.x, O.y, tra.x, tra.y, C.ray, aTra);
      }

      // 光的传播：光点等时间间隔发出，速度 ∝ 1/n，进入光密介质后间距变小
      if (st.show.pulse) {
        var T = 0.32, v1 = R * 0.5 / sol.n1, v2 = R * 0.5 / sol.n2, t = st.t;
        var k0 = Math.floor(t / T);
        for (var j = 0; j < 40; j++) {
          var tau = t - (k0 - j) * T, d1 = tau * v1;
          if (d1 < R) { dot(src.x + (O.x - src.x) * d1 / R, src.y + (O.y - src.y) * d1 / R, 2.6, C.pulse); continue; }
          var t2 = tau - R / v1, dt = t2 * v2, dr = t2 * v1;
          if (tra && dt < R) { ctx.globalAlpha = aTra; dot(O.x + (tra.x - O.x) * dt / R, O.y + (tra.y - O.y) * dt / R, 2.6, C.pulse); }
          if ((st.show.reflect || sol.tir) && dr < R) { ctx.globalAlpha = aRefl; dot(O.x + (refl.x - O.x) * dr / R, O.y + (refl.y - O.y) * dr / R, 2.6, C.pulse); }
          ctx.globalAlpha = 1;
          if ((!tra || dt >= R) && dr >= R) break;
        }
      }

      // 角度
      if (st.show.angles) {
        var aN1 = Math.atan2(sy, 0), aN2 = Math.atan2(-sy, 0);
        var mid = angleArc(R * 0.26, aN1, Math.atan2(src.y - O.y, src.x - O.x), C.ray);
        // 文字靠法线外侧对齐，避免两侧的角度标注互相重叠
        var al1 = lr < 0 ? 'right' : 'left', al2 = lr < 0 ? 'left' : 'right';
        var lr1 = R * 0.26 + 10;
        htext('入射角 ' + sol.i.toFixed(1) + '°', O.x + Math.cos(mid) * lr1, O.y + Math.sin(mid) * lr1, C.ray, al1, 12);
        if (tra) {
          var mid2 = angleArc(R * 0.3, aN2, Math.atan2(tra.y - O.y, tra.x - O.x), '#7ee081');
          var lr2 = R * 0.3 + 10;
          htext('折射角 ' + sol.r.toFixed(1) + '°', O.x + Math.cos(mid2) * lr2, O.y + Math.sin(mid2) * lr2, '#7ee081', al2, 12);
        }
        if (st.show.reflect || sol.tir) {
          var mid3 = angleArc(R * 0.2, aN1, Math.atan2(refl.y - O.y, refl.x - O.x), 'rgba(255,209,102,0.6)');
          var lr3 = R * 0.2 + 10;
          htext('反射角 ' + sol.i.toFixed(1) + '°', O.x + Math.cos(mid3) * lr3, O.y + Math.sin(mid3) * lr3, C.muted, al2, 11);
        }
      }
      if (sol.tir) tag('全反射：没有折射光', O.x, O.y - sy * R * 0.55, C.bad);

      // 激光笔
      ctx.save();
      ctx.translate(src.x, src.y);
      ctx.rotate(Math.atan2(src.y - O.y, src.x - O.x));
      roundRect(6, -7, 46, 14, 4);
      ctx.fillStyle = '#2b3446'; ctx.fill();
      ctx.strokeStyle = '#8d99ab'; ctx.lineWidth = 1; ctx.stroke();
      ctx.fillStyle = '#ff5d5d'; ctx.fillRect(30, -3, 6, 6);
      ctx.restore();
      dot(src.x, src.y, 3, C.ray);
      dot(O.x, O.y, 3, '#e6ebf2');
    }

    // ================= 筷子弯折 =================
    function drawChop(st, sol) {
      var g = G.chop, E = st.eye.chop;
      drawGrid(X(0), Y(0));
      // 桌面
      seg(X(bounds('chop').x0), Y(g.bottom - 0.6), X(16), Y(g.bottom - 0.6), C.axis, 1.5);
      // 筷子：先画水下真实部分，再盖上半透明的水，看起来像被水"染色"
      var wpx = Math.max(4, 0.7 * s);
      ctx.lineCap = 'round';
      if (st.show.real) wseg(sol.Q, sol.tip, C.wood, wpx);
      // 水与杯
      ctx.fillStyle = C.water;
      ctx.fillRect(X(g.x0), Y(0), (g.x1 - g.x0) * s, -g.bottom * s);
      seg(X(g.x0), Y(0), X(g.x1), Y(0), C.waterEdge, 1.5);
      ctx.beginPath();
      ctx.moveTo(X(g.x0 - 0.3), Y(g.rim)); ctx.lineTo(X(g.x0 - 0.3), Y(g.bottom - 0.3));
      ctx.lineTo(X(g.x1 + 0.3), Y(g.bottom - 0.3)); ctx.lineTo(X(g.x1 + 0.3), Y(g.rim));
      ctx.strokeStyle = C.cup; ctx.lineWidth = Math.max(2, 0.45 * s); ctx.stroke();
      // 虚像：水下部分看起来的位置
      var img = [sol.Q];
      sol.pts.forEach(function (v) { if (v.ok) img.push(v.I); });
      if (img.length > 1) {
        ctx.beginPath();
        img.forEach(function (p, k) { if (k) ctx.lineTo(X(p.x), Y(p.y)); else ctx.moveTo(X(p.x), Y(p.y)); });
        ctx.strokeStyle = C.imageFill; ctx.lineWidth = wpx; ctx.stroke();
        ctx.setLineDash([5, 4]); ctx.strokeStyle = C.image; ctx.lineWidth = 1.5; ctx.stroke(); ctx.setLineDash([]);
      }
      // 水上部分
      wseg(sol.top, sol.Q, C.wood, wpx);
      wseg(sol.top, { x: sol.top.x + (sol.Q.x - sol.top.x) * 0.06, y: sol.top.y + (sol.Q.y - sol.top.y) * 0.06 }, C.woodDark, wpx);
      ctx.lineCap = 'butt';

      var vt = sol.vt;
      if (st.show.rays && vt.ok) {
        var S = vt.S;
        wseg({ x: S.x, y: 3.2 }, { x: S.x, y: -3.2 }, C.normal, 1, [4, 4]);
        wseg(sol.tip, S, C.ray, 1.8);
        arrowMid(X(sol.tip.x), Y(sol.tip.y), X(S.x), Y(S.y), C.ray);
        wseg(S, E, C.ray, 1.8);
        arrowMid(X(S.x), Y(S.y), X(E.x), Y(E.y), C.ray);
        wseg(S, vt.I, C.rayBack, 1.2, [4, 4]);
        dot(X(vt.I.x), Y(vt.I.y), 3.5, C.image);
        dot(X(sol.tip.x), Y(sol.tip.y), 3, C.ray);
      }
      // 文字
      text('空气', X(bounds('chop').x0 + 1), Y(1.6), C.muted, 'left', 12);
      text('水  n = ' + st.nLiq.toFixed(2), X(g.x1 - 0.6), Y(g.bottom + 1.2), C.waterEdge, 'right', 12);
      if (st.show.real) htext('筷子的实际位置', X(sol.tip.x), Y(g.bottom - 0.6) + 14, C.wood, 'center', 12);
      if (img.length > 1) {
        var last = img[img.length - 1];
        htext('看到的筷子（虚像）', X(last.x) - 8, Y(last.y) - (Math.abs(last.y - sol.tip.y) * s > 24 ? 0 : 18), C.image, 'right', 12);
      }
      drawEye(X(E.x), Y(E.y), vt.ok ? X(vt.S.x) : X(0), vt.ok ? Y(vt.S.y) : Y(0));
      eyeLabel(X(E.x), Y(E.y));
      if (!vt.ok) tag('从这里透过水面看不到筷子下端', X(E.x), Y(E.y) + 26, C.bad);
    }

    // ================= 池底变浅 =================
    var PEBBLES = [];
    for (var k = 0; k < 26; k++) PEBBLES.push([0.3 + 9.4 * ((k * 0.618) % 1), 0.06 + 0.08 * ((k * 0.37) % 1), 0.12 + 0.1 * ((k * 0.71) % 1)]);

    function fishPath(x, y, sc, flip) {
      // 鱼身朝右，(x, y) 为鱼身中心（像素）
      ctx.beginPath();
      var f = flip ? -1 : 1;
      ctx.moveTo(x + f * 1.0 * sc, y);
      ctx.quadraticCurveTo(x + f * 0.2 * sc, y - 0.55 * sc, x - f * 0.6 * sc, y);
      ctx.lineTo(x - f * 1.05 * sc, y - 0.35 * sc);
      ctx.lineTo(x - f * 1.0 * sc, y + 0.35 * sc);
      ctx.lineTo(x - f * 0.6 * sc, y);
      ctx.quadraticCurveTo(x + f * 0.2 * sc, y + 0.55 * sc, x + f * 1.0 * sc, y);
      ctx.closePath();
    }

    function drawPool(st, sol) {
      var g = G.pool, E = st.eye.pool, d = st.depth, b = bounds('pool');
      drawGrid(X(0), Y(0));
      // 岸与池壁
      ctx.fillStyle = C.earth; ctx.strokeStyle = C.earthEdge; ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(X(b.x0), Y(g.ground)); ctx.lineTo(X(0), Y(g.ground)); ctx.lineTo(X(0), Y(-d));
      ctx.lineTo(X(g.x1), Y(-d)); ctx.lineTo(X(g.x1), Y(g.ground)); ctx.lineTo(X(b.x1), Y(g.ground));
      ctx.lineTo(X(b.x1), Y(b.y0)); ctx.lineTo(X(b.x0), Y(b.y0)); ctx.closePath();
      ctx.fill(); ctx.stroke();
      // 池底石子
      PEBBLES.forEach(function (p) {
        ctx.beginPath();
        ctx.ellipse(X(p[0]), Y(-d + p[1] * 0.6), p[2] * s, p[2] * s * 0.55, 0, 0, Math.PI * 2);
        ctx.fillStyle = '#6d6a5e'; ctx.fill();
      });
      // 鱼（实际）
      var fs = Math.max(10, 0.32 * s), flip = E.x > st.fish.x;
      fishPath(X(st.fish.x), Y(st.fish.y), fs, flip);
      ctx.fillStyle = C.fish; ctx.fill();
      // 水
      ctx.fillStyle = C.water; ctx.fillRect(X(0), Y(0), g.x1 * s, d * s);
      seg(X(0), Y(0), X(g.x1), Y(0), C.waterEdge, 1.5);

      // 看到的池底
      if (st.show.bottom) {
        ctx.beginPath();
        sol.bottom.forEach(function (v, k) { if (k) ctx.lineTo(X(v.I.x), Y(v.I.y)); else ctx.moveTo(X(v.I.x), Y(v.I.y)); });
        ctx.setLineDash([6, 4]); ctx.strokeStyle = C.image; ctx.lineWidth = 1.8; ctx.stroke(); ctx.setLineDash([]);
        var far = Math.abs(sol.bottom[0].I.x - E.x) > Math.abs(sol.bottom[100].I.x - E.x) ? sol.bottom[0] : sol.bottom[100];
        var lx = far === sol.bottom[0] ? X(0.15) : X(g.x1 - 0.15);
        text('看到的池底（虚像）', lx, Y(far.I.y) - 12, C.image, far === sol.bottom[0] ? 'left' : 'right', 12);
      }
      // 鱼的像
      var vf = sol.vf;
      fishPath(X(vf.I.x), Y(vf.I.y), fs, flip);
      ctx.fillStyle = C.imageFill; ctx.fill();
      ctx.setLineDash([4, 3]); ctx.strokeStyle = C.image; ctx.lineWidth = 1.3; ctx.stroke(); ctx.setLineDash([]);

      if (st.show.rays) {
        var S = vf.S;
        wseg({ x: S.x, y: 0.7 }, { x: S.x, y: -0.7 }, C.normal, 1, [4, 4]);
        wseg(st.fish, S, C.ray, 1.8);
        arrowMid(X(st.fish.x), Y(st.fish.y), X(S.x), Y(S.y), C.ray);
        wseg(S, E, C.ray, 1.8);
        arrowMid(X(S.x), Y(S.y), X(E.x), Y(E.y), C.ray);
        wseg(S, vf.I, C.rayBack, 1.2, [4, 4]);
      }
      // 深度标尺：鱼的实际深度与看起来的深度
      var mx = X(st.fish.x) + (flip ? 1 : -1) * (fs * 1.6 + 8), al = flip ? 'left' : 'right', off = flip ? 6 : -6;
      seg(mx, Y(0), mx, Y(st.fish.y), C.fish, 1.5);
      seg(mx - 4, Y(st.fish.y), mx + 4, Y(st.fish.y), C.fish, 1.5);
      text('实际 ' + sol.depth.toFixed(2) + ' m', mx + off, Y(st.fish.y) + 2, C.fish, al, 12);
      seg(mx - 4, Y(vf.I.y), mx + 4, Y(vf.I.y), C.image, 1.5);
      if (Math.abs(Y(vf.I.y) - Y(st.fish.y)) > 16) text('看起来 ' + sol.depthI.toFixed(2) + ' m', mx + off, Y(vf.I.y), C.image, al, 12);

      if (!narrow) {
        text('空气', X(b.x0 + 0.2), Y(g.ground + 0.35), C.muted, 'left', 12);
        text('水  n = ' + st.nLiq.toFixed(2), X(0.2), Y(-0.25), C.waterEdge, 'left', 12);
      }
      drawEye(X(E.x), Y(E.y), X(vf.S.x), Y(vf.S.y));
      eyeLabel(X(E.x), Y(E.y));
      text('鱼（可拖动）', X(st.fish.x), Y(st.fish.y) + fs * 0.9 + 10, C.fish, 'center', 11);
    }

    // ================= 碗中硬币 =================
    // 从 A 射向 E 的线段被杯壁挡住的位置（找不到时返回 null）
    function blockPoint(A, E) {
      var g = G.coin, walls = [g.x0, g.x1];
      for (var k = 0; k < 2; k++) {
        var xw = walls[k];
        if ((A.x - xw) * (E.x - xw) < 0) {
          var y = A.y + (E.y - A.y) * (xw - A.x) / (E.x - A.x);
          if (y < g.rim) return { x: xw, y: y };
        }
      }
      return null;
    }

    function drawCoin(st, sol) {
      var g = G.coin, E = st.eye.coin, h = st.level;
      drawGrid(X(0), Y(0));
      seg(X(bounds('coin').x0), Y(-0.6), X(bounds('coin').x1), Y(-0.6), C.axis, 1.5);
      // 水
      if (sol.wet) {
        ctx.fillStyle = C.water; ctx.fillRect(X(g.x0), Y(h), (g.x1 - g.x0) * s, h * s);
        seg(X(g.x0), Y(h), X(g.x1), Y(h), C.waterEdge, 1.5);
      }
      // 硬币
      var cw = g.w * s, ch = Math.max(4, 0.35 * s);
      roundRect(X(g.cx - g.w / 2), Y(0) - ch, cw, ch, 2);
      ctx.fillStyle = C.coin; ctx.fill();
      // 硬币的像（只画看得见的部分）
      if (sol.wet) {
        var vis = sol.pts.filter(function (v) { return v.ok; });
        if (vis.length > 1) {
          var a = vis[0].I, b2 = vis[vis.length - 1].I;
          ctx.beginPath();
          ctx.moveTo(X(a.x), Y(a.y)); ctx.lineTo(X(b2.x), Y(b2.y));
          ctx.strokeStyle = C.imageFill; ctx.lineWidth = ch; ctx.stroke();
          ctx.setLineDash([4, 3]); ctx.strokeStyle = C.image; ctx.lineWidth = 1.3;
          ctx.strokeRect(X(a.x), Y((a.y + b2.y) / 2) - ch / 2, X(b2.x) - X(a.x), ch);
          ctx.setLineDash([]);
          htext('看到的硬币（虚像）', X((a.x + b2.x) / 2), Y(Math.max(a.y, b2.y)) - ch - 10, C.image, 'center', 12);
        }
      }
      // 碗（不透明）
      ctx.fillStyle = C.bowl; ctx.strokeStyle = C.bowlEdge; ctx.lineWidth = 1;
      [[g.x0 - g.wall, -0.6, g.wall, g.rim + 0.6], [g.x1, -0.6, g.wall, g.rim + 0.6], [g.x0, -0.6, g.x1 - g.x0, 0.6]].forEach(function (r) {
        ctx.fillRect(X(r[0]), Y(r[1] + r[3]), r[2] * s, r[3] * s);
        ctx.strokeRect(X(r[0]), Y(r[1] + r[3]), r[2] * s, r[3] * s);
      });

      // 擦着碗边的视线
      if (sol.sight) {
        ctx.beginPath();
        sol.sight.forEach(function (p, k) { if (k) ctx.lineTo(X(p.x), Y(p.y)); else ctx.moveTo(X(p.x), Y(p.y)); });
        ctx.setLineDash([3, 5]); ctx.strokeStyle = 'rgba(230,235,242,0.55)'; ctx.lineWidth = 1.2; ctx.stroke(); ctx.setLineDash([]);
        var e0 = sol.sight[0], e1 = sol.sight[1];
        ctx.save();
        ctx.translate(X((e0.x + e1.x) / 2), Y((e0.y + e1.y) / 2));
        ctx.rotate(Math.atan2(Y(e1.y) - Y(e0.y), X(e1.x) - X(e0.x)));
        htext('擦着碗边的视线', 0, -10, C.muted, 'center', 11);
        ctx.restore();
      }

      // 来自硬币的光：优先画中心那条，看不见时画被挡住的那条
      var pick = sol.pts[4].ok ? sol.pts[4] : sol.pts.filter(function (v) { return v.ok; })[0];
      if (st.show.rays) {
        if (pick) {
          if (sol.wet) {
            wseg(pick.P, pick.S, C.ray, 1.8);
            wseg(pick.S, E, C.ray, 1.8);
            arrowMid(X(pick.S.x), Y(pick.S.y), X(E.x), Y(E.y), C.ray);
            wseg(pick.S, pick.I, C.rayBack, 1.2, [4, 4]);
          } else {
            wseg(pick.P, E, C.ray, 1.8);
            arrowMid(X(pick.P.x), Y(pick.P.y), X(E.x), Y(E.y), C.ray);
          }
        } else {
          var v = sol.pts[4], A = sol.wet ? v.S : v.P;
          if (sol.wet) wseg(v.P, v.S, C.bad, 1.5);
          var bp = blockPoint(A, E) || A;
          wseg(A, bp, C.bad, 1.5);
          wseg(bp, E, 'rgba(255,122,89,0.35)', 1, [3, 4]);
          text('✕', X(bp.x) - 10, Y(bp.y), C.bad, 'center', 14, '700');
        }
      }
      text('碗（不透明）', X(g.x0 - g.wall) - 6, Y(g.rim - 1), C.muted, 'right', 12);
      if (sol.wet && !narrow) text('水  n = ' + st.nLiq.toFixed(2), X(g.x0 + 0.5), Y(h) + 12, C.waterEdge, 'left', 12);
      drawEye(X(E.x), Y(E.y), X(g.cx), Y(0));
      eyeLabel(X(E.x), Y(E.y));
    }

    function draw(st, sol) {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, W, H);
      layout(st.scene);
      if (st.scene === 'law') drawLaw(st, sol);
      else if (st.scene === 'chop') drawChop(st, sol);
      else if (st.scene === 'pool') drawPool(st, sol);
      else drawCoin(st, sol);
    }

    // ---------- 交互：命中测试与坐标换算 ----------
    function distSeg(px, py, ax, ay, bx, by) {
      var dx = bx - ax, dy = by - ay, t = ((px - ax) * dx + (py - ay) * dy) / (dx * dx + dy * dy);
      t = Math.max(0, Math.min(1, t));
      return Math.hypot(px - ax - dx * t, py - ay - dy * t);
    }
    // 返回可拖动的对象：'laser' | 'eye' | 'fish' | 'chop' | null；strict = 只认图标本身（用于鼠标指针样式）
    function hit(px, py, st, sol, strict) {
      layout(st.scene);
      if (st.scene === 'law') {
        if (!strict) return 'laser';
        var sy = st.side === 'top' ? -1 : 1, R = LO.R + 28;
        var lx = LO.x + R * st.lr * Math.sin(st.i * RAD), ly = LO.y + R * sy * Math.cos(st.i * RAD);
        return Math.hypot(px - lx, py - ly) < 30 ? 'laser' : null;
      }
      var E = st.eye[st.scene];
      if (Math.hypot(px - X(E.x), py - Y(E.y)) < 24) return 'eye';
      if (st.scene === 'pool' && Math.abs(px - X(st.fish.x)) < Math.max(18, 0.45 * s) && Math.abs(py - Y(st.fish.y)) < Math.max(14, 0.3 * s)) return 'fish';
      if (st.scene === 'chop' && sol && distSeg(px, py, X(sol.top.x), Y(sol.top.y), X(G.chop.rest.x), Y(G.chop.rest.y)) < 14) return 'chop';
      return null;
    }
    // 折射规律场景：指针位置 → { side, lr, i }
    function lawAngle(px, py) {
      var dx = px - LO.x, dy = py - LO.y;
      return {
        side: dy <= 0 ? 'top' : 'bottom', lr: dx < 0 ? -1 : 1,
        i: Math.min(89.5, Math.atan2(Math.abs(dx), Math.abs(dy)) / RAD)
      };
    }

    return { resize: resize, draw: draw, hit: hit, toWorld: toWorld, lawAngle: lawAngle, bounds: bounds };
  }

  window.RefDraw = RefDraw;
})();
