(function () {
  var Rf = window.Refract, G = Rf.GEO;
  var $ = function (id) { return document.getElementById(id); };
  var qa = function (sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); };

  var state = {
    scene: 'law',
    // 折射规律
    top: 'air', bot: 'water', side: 'top', lr: -1, i: 40,   // lr：激光笔在法线左侧（−1）或右侧（1）
    // 生活场景
    nLiq: 1.33, chopA: 35, depth: 2, level: 0, pouring: false,
    eye: { chop: { x: -12, y: 21.5 }, pool: { x: -1.5, y: 1.6 }, coin: { x: -20, y: 14 } },
    fish: { x: 4, y: -1.4 },
    show: { reflect: true, angles: true, ring: true, pulse: true, rays: true, real: true, bottom: true },
    t: 0
  };

  var HINTS = {
    law: '拖动激光笔（或在画面任意处拖动）改变入射角',
    chop: '拖动眼睛换个角度看 · 拖筷子上端改变倾角',
    pool: '拖动眼睛或小鱼 · 看池底怎样"变浅"',
    coin: '碗边刚好挡住硬币时，往碗里倒水试试'
  };

  var stage = $('stage'), canvas = $('ray'), panel = $('panel');
  var view = window.RefDraw(canvas);

  function solve() {
    if (state.scene === 'law') return Rf.solveLaw(state);
    if (state.scene === 'chop') return Rf.solveChop(state);
    if (state.scene === 'pool') return Rf.solvePool(state);
    return Rf.solveCoin(state);
  }
  var sol = null;

  function setSeg(attr, val) { qa('[data-' + attr + ']').forEach(function (b) { b.classList.toggle('on', b.dataset[attr] === val); }); }
  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }

  // ---------- 场景 ----------
  qa('[data-scene]').forEach(function (b) {
    b.addEventListener('click', function () { setScene(b.dataset.scene); Analytics.track('折射', '场景', b.textContent); });
  });
  function setScene(sc) {
    state.scene = sc;
    state.pouring = false;
    syncUI();
  }

  // ---------- 折射规律 ----------
  qa('[data-top]').forEach(function (b) { b.addEventListener('click', function () { state.top = b.dataset.top; syncUI(); }); });
  qa('[data-bot]').forEach(function (b) { b.addEventListener('click', function () { state.bot = b.dataset.bot; syncUI(); }); });
  qa('[data-side]').forEach(function (b) { b.addEventListener('click', function () { state.side = b.dataset.side; syncUI(); }); });
  qa('[data-law]').forEach(function (b) {
    b.addEventListener('click', function () {
      var p = b.dataset.law.split(',');
      state.top = p[0]; state.bot = p[1]; state.side = p[2];
      syncUI();
    });
  });
  var incEl = $('inc');
  incEl.addEventListener('input', function () { state.i = parseFloat(incEl.value); syncUI(); });
  $('reverse').addEventListener('click', function () {
    var s = Rf.solveLaw(state);
    if (s.tir) { $('lawNote').textContent = '全反射时没有折射光，先减小入射角。'; return; }
    // 让光逆着原来的折射光线射回去
    state.side = state.side === 'top' ? 'bottom' : 'top';
    state.lr = -state.lr;
    state.i = Math.round(s.r * 10) / 10;
    syncUI();
    $('lawNote').textContent = '光逆着原来的折射光线射入，折射后沿原来入射光线的反方向射出：光路可逆。';
  });
  $('toNormal').addEventListener('click', function () { state.i = 0; syncUI(); });
  $('toC').addEventListener('click', function () {
    var s = Rf.solveLaw(state);
    if (isNaN(s.C)) { $('lawNote').textContent = '光从' + s.m1.name + '射入' + s.m2.name + '（光疏 → 光密）没有临界角，不会发生全反射。试试「玻璃 → 空气」。'; return; }
    state.i = Math.floor(s.C * 10) / 10;
    syncUI();
  });

  // ---------- 生活场景 ----------
  var nEl = $('nLiq');
  nEl.addEventListener('input', function () { state.nLiq = parseFloat(nEl.value); syncUI(); });
  qa('[data-n]').forEach(function (b) { b.addEventListener('click', function () { state.nLiq = parseFloat(b.dataset.n); syncUI(); }); });
  $('chopA').addEventListener('input', function () { state.chopA = parseFloat($('chopA').value); syncUI(); });
  $('depth').addEventListener('input', function () { state.depth = parseFloat($('depth').value); clampFish(); syncUI(); });
  $('eyeTop').addEventListener('click', function () { state.eye.pool = { x: state.fish.x, y: 2.6 }; });
  $('eyeBank').addEventListener('click', function () { state.eye.pool = { x: -1.5, y: 1.6 }; });
  $('level').addEventListener('input', function () { state.pouring = false; state.level = parseFloat($('level').value); syncUI(); });
  $('pour').addEventListener('click', function () {
    if (state.level >= 7) state.level = 0;
    state.pouring = true;
    Analytics.track('折射', '倒水');
  });
  $('empty').addEventListener('click', function () { state.pouring = false; state.level = 0; syncUI(); });
  $('eyeHide').addEventListener('click', function () { state.pouring = false; state.level = 0; hideCoin(); syncUI(); });

  // 碗中没水时，把眼睛放到碗边刚好挡住整枚硬币的高度（保持水平位置）
  function hideCoin() {
    var E = state.eye.coin, g = G.coin;
    if (E.x > g.x0 - g.wall - 2 || E.x < view.bounds('coin').x0 + 2) E.x = Math.max(-20, view.bounds('coin').x0 + 3);
    var P = { x: g.cx + g.w / 2, y: g.h };
    E.y = g.rim + (g.rim - P.y) * (g.x0 - E.x) / (P.x - g.x0) - 0.3;
    clampEye('coin', E);
  }

  function clampFish() {
    state.fish.x = clamp(state.fish.x, 0.6, G.pool.x1 - 0.6);
    state.fish.y = clamp(state.fish.y, -state.depth + 0.25, -0.25);
  }
  function clampEye(sc, E) {
    var b = view.bounds(sc), m = (b.x1 - b.x0) * 0.03;
    E.x = clamp(E.x, b.x0 + m, b.x1 - m); E.y = Math.min(E.y, b.y1 - m);
    if (sc === 'chop') {
      E.x = clamp(E.x, -29, 15); E.y = clamp(E.y, 2, 23);
      if (E.x > G.chop.x0 - 0.8 && E.x < G.chop.x1 + 0.8) E.y = Math.max(E.y, G.chop.rim + 1);
    } else if (sc === 'pool') {
      E.x = clamp(E.x, -4.2, 10.2); E.y = clamp(E.y, 0.5, 4);
    } else {
      E.x = clamp(E.x, -25, 9); E.y = clamp(E.y, 0.6, 17.5);
      if (E.x > G.coin.x0 - G.coin.wall - 0.4 && E.x < G.coin.x1 + G.coin.wall + 0.4) E.y = Math.max(E.y, G.coin.rim + 1);
    }
  }

  // ---------- 显示 ----------
  [['showReflect', 'reflect'], ['showAngles', 'angles'], ['showRing', 'ring'], ['showPulse', 'pulse'],
   ['showRays', 'rays'], ['showReal', 'real'], ['showBottom', 'bottom']].forEach(function (p) {
    $(p[0]).addEventListener('change', function () { state.show[p[1]] = $(p[0]).checked; });
  });

  // ---------- 拖动 ----------
  var drag = null;
  function localXY(e) { var r = canvas.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; }
  function dragTo(px, py) {
    if (drag === 'laser') {
      var a = view.lawAngle(px, py);
      state.side = a.side; state.lr = a.lr; state.i = Math.round(a.i * 2) / 2;
      syncUI();
      return;
    }
    var w = view.toWorld(px, py);
    if (drag === 'eye') {
      var E = state.eye[state.scene];
      E.x = w.x; E.y = w.y;
      clampEye(state.scene, E);
    } else if (drag === 'fish') {
      state.fish.x = w.x; state.fish.y = w.y;
      clampFish();
    } else if (drag === 'chop') {
      var r = G.chop.rest;
      state.chopA = Math.round(clamp(Math.atan2(w.x - r.x, w.y - r.y) * 180 / Math.PI, 0, G.chop.aMax));
      syncUI();
    }
  }
  canvas.addEventListener('pointerdown', function (e) {
    var p = localXY(e);
    drag = view.hit(p[0], p[1], state, sol, false);
    if (!drag) return;
    try { canvas.setPointerCapture(e.pointerId); } catch (err) { /* 合成事件无法捕获指针 */ }
    canvas.classList.add('grabbing');
    if (drag === 'laser') dragTo(p[0], p[1]);
  });
  canvas.addEventListener('pointermove', function (e) {
    var p = localXY(e);
    if (!drag) { canvas.classList.toggle('grab', !!view.hit(p[0], p[1], state, sol, true)); return; }
    dragTo(p[0], p[1]);
  });
  function endDrag(e) {
    if (!drag) return;
    drag = null;
    canvas.classList.remove('grabbing');
    if (canvas.hasPointerCapture(e.pointerId)) canvas.releasePointerCapture(e.pointerId);
  }
  canvas.addEventListener('pointerup', endDrag);
  canvas.addEventListener('pointercancel', endDrag);

  // ---------- 面板同步 ----------
  function syncUI() {
    var sc = state.scene;
    setSeg('scene', sc);
    qa('[data-for]').forEach(function (el) { el.hidden = el.dataset.for.split(' ').indexOf(sc) < 0; });
    $('hint').textContent = HINTS[sc];
    setSeg('top', state.top); setSeg('bot', state.bot); setSeg('side', state.side);
    incEl.value = state.i; $('incOut').textContent = state.i.toFixed(1) + '°';
    nEl.value = state.nLiq; $('nLiqOut').textContent = state.nLiq.toFixed(2);
    $('chopA').value = state.chopA; $('chopAOut').textContent = state.chopA + '°';
    $('depth').value = state.depth; $('depthOut').textContent = state.depth.toFixed(2) + ' m';
    $('level').value = state.level; $('levelOut').textContent = state.level.toFixed(1) + ' cm';
    var s = Rf.solveLaw(state);
    $('lawNote').textContent = isNaN(s.C) ? '' : '光从' + s.m1.name + '射向' + s.m2.name + '：入射角 ≥ ' + s.C.toFixed(1) + '° 时发生全反射。';
  }

  $('panelToggle').addEventListener('click', function () { panel.classList.toggle('collapsed'); });
  if (window.matchMedia('(max-width: 760px)').matches) panel.classList.add('collapsed');

  // ---------- 读数 ----------
  var last = {};
  function setText(id, s) { if (last[id] !== s) { last[id] = s; $(id).textContent = s; } }
  function rows(list) {
    for (var k = 1; k <= 5; k++) {
      var r = list[k - 1] || ['', ''];
      setText('d' + k, r[0]); setText('r' + k, r[1]);
      $('d' + k).hidden = $('r' + k).hidden = !r[0];
    }
  }
  function setBig(str, cls) { setText('rState', str); $('rState').className = cls || ''; }
  function deg(a) { return a.toFixed(1) + '°'; }

  function readLaw(s) {
    var same = Math.abs(s.n1 - s.n2) < 1e-9;
    if (s.tir) setBig('全反射', 'bad');
    else if (s.i < 0.25) setBig('垂直入射：方向不变');
    else if (same) setBig('折射率相同：不偏折');
    else setBig(s.r < s.i ? '折射角 < 入射角' : '折射角 > 入射角', 'ok');
    setText('rTip', s.tir ? '入射角 ≥ 临界角，光全部被反射回' + s.m1.name + '中——这就是全反射（光导纤维的原理）。'
      : s.i < 0.25 ? '光垂直射到界面上时，传播方向不改变，但光速变了。'
      : same ? '两种介质的折射率相同，光沿直线传播。'
      : s.n1 < s.n2 ? '光从' + s.m1.name + '斜射入' + s.m2.name + '：进入光速更小的介质，折射光线偏向法线。'
      : '光从' + s.m1.name + '斜射入' + s.m2.name + '：进入光速更大的介质，折射光线偏离法线。');
    rows([
      ['光路', s.m1.name + ' → ' + s.m2.name + '（n ' + s.n1.toFixed(2) + ' → ' + s.n2.toFixed(2) + '）'],
      ['角度', '入射角 ' + deg(s.i) + ' · 折射角 ' + (s.tir ? '—' : deg(s.r)) + ' · 反射角 ' + deg(s.i)],
      ['能量', s.tir ? '反射 100% · 折射 0%' : '反射 ' + (s.R * 100).toFixed(1) + '% · 折射 ' + ((1 - s.R) * 100).toFixed(1) + '%'],
      ['光速', s.v1.toFixed(2) + ' → ' + s.v2.toFixed(2) + ' ×10⁸ m/s'],
      ['临界角', isNaN(s.C) ? '无（光疏 → 光密，不会全反射）' : deg(s.C) + '（sin C = ' + s.n2.toFixed(2) + '/' + s.n1.toFixed(2) + '）']
    ]);
  }

  function readChop(s) {
    var straight = s.n < 1.005;
    var vt = s.vt;
    if (!vt.ok) setBig('看不到水中的筷尖', 'bad');
    else setBig(straight ? '筷子是直的' : state.chopA < 0.5 ? '水中部分看起来变短了' : '水中部分看起来向上"折"了', straight ? '' : 'ok');
    setText('rTip', straight ? '折射率为 1 时光不偏折，看到的就是筷子的真实位置。'
      : '筷尖反射的光从水中斜射入空气时偏离法线，眼睛逆着折射光线看去，看到的是比实际位置高的虚像。');
    rows([
      ['筷尖实际', '水下 ' + s.depth.toFixed(1) + ' cm'],
      ['看起来', vt.ok ? '水下 ' + s.depthI.toFixed(1) + ' cm（升高 ' + (s.depth - s.depthI).toFixed(1) + ' cm）' : '—'],
      ['水中', vt.ok ? '入射角 ' + deg(vt.iP) : '—'],
      ['空气中', vt.ok ? '折射角 ' + deg(vt.iE) : '—'],
      ['倾角', state.chopA + '°（与竖直方向）']
    ]);
  }

  function readPool(s) {
    var straight = s.n < 1.005;
    setBig(straight ? '看到的就是实际深度' : '池底看起来变浅了', straight ? '' : 'ok');
    setText('rTip', straight ? '折射率为 1 时光不偏折，没有"变浅"。'
      : '看到的鱼比实际位置高：叉鱼要对准看到的鱼的下方。斜着看时，越远处显得越浅。');
    rows([
      ['水深', state.depth.toFixed(2) + ' m'],
      ['鱼实际', '水下 ' + s.depth.toFixed(2) + ' m'],
      ['看起来', '水下 ' + s.depthI.toFixed(2) + ' m（约为实际的 ' + Math.round(s.depthI / s.depth * 100) + '%）'],
      ['正上方看', '约 ' + s.nadir.toFixed(2) + ' m（h / n）'],
      ['角度', '水中 ' + deg(s.vf.iP) + ' → 空气中 ' + deg(s.vf.iE)]
    ]);
  }

  function readCoin(s) {
    var all = s.pts.length;
    if (s.seen === 0) setBig('✗ 看不见硬币', 'bad');
    else if (s.seen === all) setBig('✓ 看见整枚硬币', 'ok');
    else setBig('看见一部分硬币', 'ok');
    setText('rTip', !s.wet && s.seen === 0 ? '光沿直线传播，硬币射来的光被碗壁挡住了。往碗里倒水试试。'
      : !s.wet ? '从这里能直接看见硬币。点「眼睛放到刚好看不见」，或把眼睛放低一些。'
      : s.seen === 0 ? (s.n < 1.005 ? '折射率为 1，光不偏折，倒再多水也看不见。' : '水还不够多，继续倒水（或把眼睛稍微抬高一点）。')
      : '光从水中斜射入空气时偏离法线，越过碗边进入眼睛——看到的是升高了的硬币虚像。');
    var c = s.pts[4];
    rows([
      ['水位', state.level.toFixed(1) + ' cm'],
      ['看得见', Math.round(s.seen / all * 100) + '% 的硬币'],
      ['硬币的像', s.wet && c.ok ? '比实际高 ' + (c.I.y - c.P.y).toFixed(1) + ' cm' : '—']
    ]);
  }

  // ---------- 尺寸与主循环 ----------
  function resize() {
    view.resize(stage.clientWidth, stage.clientHeight);
    ['chop', 'pool', 'coin'].forEach(function (sc) { clampEye(sc, state.eye[sc]); });
  }
  new ResizeObserver(resize).observe(stage);

  // 支持 ?scene=chop 这样的链接直接打开某个场景
  var q = /[?&]scene=(\w+)/.exec(location.search);
  if (q && HINTS[q[1]]) state.scene = q[1];

  resize();
  hideCoin();
  syncUI();

  var lastT = performance.now();
  function frame(t) {
    var dt = Math.min((t - lastT) / 1000, 0.1);
    lastT = t;
    state.t += dt;
    if (state.pouring) {
      state.level = Math.min(7, state.level + dt * 1.5);
      if (state.level >= 7) state.pouring = false;
      $('level').value = state.level; $('levelOut').textContent = state.level.toFixed(1) + ' cm';
    }
    sol = solve();
    view.draw(state, sol);
    if (state.scene === 'law') readLaw(sol);
    else if (state.scene === 'chop') readChop(sol);
    else if (state.scene === 'pool') readPool(sol);
    else readCoin(sol);
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // 调试用
  window.__model = { state: state, setScene: setScene, solve: solve, syncUI: syncUI };
})();
