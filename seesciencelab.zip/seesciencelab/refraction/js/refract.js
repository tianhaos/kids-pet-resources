// 光的折射计算（纯函数）：斯涅尔定律、全反射、菲涅耳反射率，以及"隔着水面看物体"的光路与虚像。
// 约定：角度一律从法线量起，单位度；平面坐标 y 向上，界面是水平线 y = ySurf。
(function () {
  var C_LIGHT = 3.0;   // 真空中光速（×10⁸ m/s）

  var MEDIA = {
    air:     { key: 'air',     name: '空气', n: 1.00 },
    water:   { key: 'water',   name: '水',   n: 1.33 },
    glass:   { key: 'glass',   name: '玻璃', n: 1.50 },
    diamond: { key: 'diamond', name: '钻石', n: 2.42 }
  };

  var RAD = Math.PI / 180;

  // 折射角（度）；发生全反射时返回 NaN
  function snell(n1, n2, i) {
    var s = n1 * Math.sin(i * RAD) / n2;
    return s > 1 ? NaN : Math.asin(s) / RAD;
  }

  // 临界角（度）；光从光疏射向光密时没有临界角，返回 NaN
  function critical(n1, n2) { return n1 > n2 ? Math.asin(n2 / n1) / RAD : NaN; }

  // 反射光占入射光的比例（自然光，s、p 偏振取平均）
  function fresnel(n1, n2, i) {
    var r = snell(n1, n2, i);
    if (isNaN(r)) return 1;
    var ci = Math.cos(i * RAD), cr = Math.cos(r * RAD);
    var rs = (n1 * ci - n2 * cr) / (n1 * ci + n2 * cr);
    var rp = (n1 * cr - n2 * ci) / (n1 * cr + n2 * ci);
    return (rs * rs + rp * rp) / 2;
  }

  function speed(n) { return C_LIGHT / n; }

  // 从 P（折射率 nP）经界面 y = ySurf 到 E（折射率 nE）的实际光路与界面的交点 x。
  // 费马原理：光程 nP·|PS| + nE·|SE| 最短；它是 x 的凸函数，在 P、E 之间用黄金分割搜索。
  function surfacePoint(P, nP, E, nE, ySurf) {
    var a = Math.min(P.x, E.x), b = Math.max(P.x, E.x);
    var hP = P.y - ySurf, hE = E.y - ySurf;
    function L(x) { return nP * Math.hypot(x - P.x, hP) + nE * Math.hypot(E.x - x, hE); }
    var g = 0.6180339887, x1 = b - g * (b - a), x2 = a + g * (b - a), f1 = L(x1), f2 = L(x2);
    for (var k = 0; k < 60 && b - a > 1e-9; k++) {
      if (f1 < f2) { b = x2; x2 = x1; f2 = f1; x1 = b - g * (b - a); f1 = L(x1); }
      else { a = x1; x1 = x2; f1 = f2; x2 = a + g * (b - a); f2 = L(x2); }
    }
    return (a + b) / 2;
  }

  // 眼睛 E 隔着界面看 P 时看到的像（虚像）。
  // 平面界面关于法线轴对称，像在过 P 的法线（竖直线）上：把进入眼睛的光线反向延长，与这条竖直线的交点即像点。
  // 正对着看时退化为 h' = h·nE/nP。返回 { S 入射点, I 像点, iP 物侧角, iE 眼侧角 }。
  function view(P, nP, E, nE, ySurf) {
    var sx = surfacePoint(P, nP, E, nE, ySurf), S = { x: sx, y: ySurf };
    var I;
    if (Math.abs(sx - P.x) < 1e-6 || Math.abs(E.x - sx) < 1e-6) {
      I = { x: P.x, y: ySurf + (P.y - ySurf) * nE / nP };
    } else {
      var t = (P.x - sx) / (sx - E.x);
      I = { x: P.x, y: ySurf + (ySurf - E.y) * t };
    }
    var iP = Math.atan2(Math.abs(sx - P.x), Math.abs(P.y - ySurf)) / RAD;
    var iE = Math.atan2(Math.abs(E.x - sx), Math.abs(E.y - ySurf)) / RAD;
    return { S: S, I: I, iP: iP, iE: iE };
  }

  // ================= 各场景的几何与求解 =================
  // 场景尺寸：筷子、碗中硬币单位 cm，池底单位 m。
  var GEO = {
    chop: { x0: -8, x1: 8, bottom: -12, rim: 5, rest: { x: 7.6, y: 5 }, above: 9, aMax: 60 },
    pool: { x0: 0, x1: 10, bank: -4, ground: 0.3, depthMin: 0.5, depthMax: 3 },
    coin: { x0: -7, x1: 7, wall: 0.6, rim: 8, levelMax: 7.5, cx: 2.5, w: 3, h: 0.12 }
  };

  // 折射规律：side = 'top' 光从上方介质射入；i 入射角
  function solveLaw(st) {
    var mT = MEDIA[st.top], mB = MEDIA[st.bot];
    var m1 = st.side === 'top' ? mT : mB, m2 = st.side === 'top' ? mB : mT;
    var r = snell(m1.n, m2.n, st.i);
    return {
      m1: m1, m2: m2, n1: m1.n, n2: m2.n, i: st.i, r: r, tir: isNaN(r),
      R: fresnel(m1.n, m2.n, st.i), C: critical(m1.n, m2.n),
      v1: speed(m1.n), v2: speed(m2.n)
    };
  }

  // 筷子：斜靠在杯口右沿 rest 上，倾角 a（与竖直方向的夹角），下端碰到杯底或杯壁为止
  function solveChop(st) {
    var g = GEO.chop, a = st.chopA * RAD, E = st.eye.chop, n = st.nLiq;
    var dx = -Math.sin(a), dy = -Math.cos(a);
    var tB = (g.rest.y - g.bottom) / -dy, tW = dx < 0 ? (g.rest.x - g.x0 - 0.4) / -dx : Infinity;
    var t = Math.min(tB, tW);
    var tip = { x: g.rest.x + dx * t, y: g.rest.y + dy * t };
    var t0 = g.rest.y / -dy, Q = { x: g.rest.x + dx * t0, y: 0 };
    var top = { x: g.rest.x - dx * g.above, y: g.rest.y - dy * g.above };
    var pts = [], N = 30;
    for (var k = 1; k <= N; k++) {
      var P = { x: Q.x + (tip.x - Q.x) * k / N, y: Q.y + (tip.y - Q.y) * k / N };
      var v = view(P, n, E, 1, 0);
      v.P = P; v.ok = v.S.x > g.x0 && v.S.x < g.x1;
      pts.push(v);
    }
    var vt = pts[N - 1];
    return { tip: tip, Q: Q, top: top, pts: pts, vt: vt, depth: -tip.y, depthI: -vt.I.y, n: n };
  }

  // 池底：水面 y = 0，池底 y = −depth；鱼 st.fish
  function solvePool(st) {
    var g = GEO.pool, E = st.eye.pool, n = st.nLiq, bottom = [];
    for (var k = 0; k <= 100; k++) {
      var x = g.x0 + 0.05 + (g.x1 - g.x0 - 0.1) * k / 100;
      bottom.push(view({ x: x, y: -st.depth }, n, E, 1, 0));
    }
    var vf = view(st.fish, n, E, 1, 0);
    return { bottom: bottom, vf: vf, depth: -st.fish.y, depthI: -vf.I.y, nadir: -st.fish.y / n, n: n };
  }

  // 线段 A→E 能否越过两侧杯沿（杯沿内角 (x0, rim)、(x1, rim)）
  function clearsRim(A, E) {
    var g = GEO.coin, walls = [g.x0, g.x1];
    for (var k = 0; k < 2; k++) {
      var xw = walls[k];
      if ((A.x - xw) * (E.x - xw) < 0) {
        var y = A.y + (E.y - A.y) * (xw - A.x) / (E.x - A.x);
        if (y < g.rim) return false;
      }
    }
    return true;
  }

  // 碗中硬币：不透明的碗，水位 st.level；硬币上取 9 个点判断能否被看见
  function solveCoin(st) {
    var g = GEO.coin, E = st.eye.coin, n = st.nLiq, h = st.level, wet = h > 0.02, pts = [], seen = 0;
    for (var k = 0; k < 9; k++) {
      var P = { x: g.cx - g.w / 2 + g.w * k / 8, y: g.h }, v;
      if (wet) {
        v = view(P, n, E, 1, h);
        v.ok = v.S.x > g.x0 && v.S.x < g.x1 && clearsRim(v.S, E);
      } else {
        v = { S: null, I: P, ok: clearsRim(P, E) };
      }
      v.P = P;
      if (v.ok) seen++;
      pts.push(v);
    }
    return { pts: pts, seen: seen, wet: wet, sight: sightLine(E, h, n), n: n };
  }

  // 从眼睛擦着杯沿看进碗里的视线（入水后按折射偏折），返回折线点；眼睛在碗口正上方时返回 null
  function sightLine(E, h, n) {
    var g = GEO.coin;
    if (E.x > g.x0 && E.x < g.x1) return null;
    var Cn = { x: E.x < g.x0 ? g.x0 : g.x1, y: g.rim };
    var dx = Cn.x - E.x, dy = Cn.y - E.y, L = Math.hypot(dx, dy);
    dx /= L; dy /= L;
    if (dy >= -1e-6) return null;
    var pts = [E, Cn], P = Cn, inWater = false;
    for (var step = 0; step < 3; step++) {
      // 下一个交点：水面（还没入水时）、对面杯壁、杯底
      var tS = !inWater && h > 0.02 && P.y > h ? (h - P.y) / dy : Infinity;
      var xw = dx > 0 ? g.x1 : g.x0, tW = Math.abs(dx) > 1e-9 ? (xw - P.x) / dx : Infinity;
      var tB = (0 - P.y) / dy;
      var t = Math.min(tS, tW, tB);
      P = { x: P.x + dx * t, y: P.y + dy * t };
      pts.push(P);
      if (t !== tS) break;
      inWater = true;
      var sw = Math.abs(dx) / n, cw = Math.sqrt(1 - sw * sw);
      dx = (dx > 0 ? 1 : -1) * sw; dy = -cw;
    }
    return pts;
  }

  window.Refract = {
    MEDIA: MEDIA, C_LIGHT: C_LIGHT, GEO: GEO,
    snell: snell, critical: critical, fresnel: fresnel, speed: speed,
    surfacePoint: surfacePoint, view: view,
    solveLaw: solveLaw, solveChop: solveChop, solvePool: solvePool, solveCoin: solveCoin
  };
})();
