(function () {
  'use strict';
  const C = { gold: '#ffc94a', blue: '#66cded', purple: '#bca1fa', orange: '#ef9474', muted: '#94afbe', text: '#e4edf2' };
  function draw(canvas, s, ui) {
    const box = canvas.getBoundingClientRect(), w = box.width, h = box.height;
    const dpr = Math.min(devicePixelRatio || 1, 2);
    if (canvas.width !== Math.round(w * dpr) || canvas.height !== Math.round(h * dpr)) {
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
    }
    const c = canvas.getContext('2d'); c.setTransform(dpr, 0, 0, dpr, 0, 0);
    const e = Wheel.values(s), mobile = w < 600;
    const bg = c.createLinearGradient(0, 0, w, h); bg.addColorStop(0, '#0c1420'); bg.addColorStop(.55, '#070b13'); bg.addColorStop(1, '#05070d');
    c.fillStyle = bg; c.fillRect(0, 0, w, h);
    const compact = h < 620, top = compact ? 130 : mobile ? 190 : 177;
    const radius = Math.min(mobile ? 45 : 64, Math.max(22, (h-top-310)*.23));
    const bottom = Math.max(top + 65, h - 310 - radius);
    const scale = (bottom - top) / .8, cx = w * (mobile ? .46 : .48);
    const shaft = radius * 1.42, cy = bottom - e.h * scale;
    const beam = top - radius - 24, standX = cx - shaft - 38, standR = cx + shaft + 38;
    function line(x1,y1,x2,y2,color,width=1,dash=[]) { c.beginPath(); c.setLineDash(dash); c.strokeStyle=color;c.lineWidth=width;c.moveTo(x1,y1);c.lineTo(x2,y2);c.stroke();c.setLineDash([]); }
    function text(str,x,y,size=12,color=C.muted,align='left') {c.font=`${size}px -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif`;c.fillStyle=color;c.textAlign=align;c.fillText(str,x,y);}
    function rect(x,y,rw,rh,color,r=4){c.fillStyle=color;c.beginPath();c.roundRect(x,y,rw,rh,r);c.fill();}
    function circle(x,y,r,color,stroke){c.beginPath();c.arc(x,y,r,0,Math.PI*2);c.fillStyle=color;c.fill();if(stroke){c.strokeStyle=stroke;c.lineWidth=1;c.stroke();}}
    // 地面与坚固的双立柱框架，绳的两个固定点始终可见。
    const floor = bottom + radius + 20;
    // 低对比台面与投影承托装置，不干扰绳线和刻度。
    line(20,floor+23,w-20,floor+23,'#1b293b');
    c.fillStyle='#101a28';c.beginPath();c.ellipse(cx,floor+8,shaft+82,17,0,0,Math.PI*2);c.fill();
    const steel=c.createLinearGradient(standX,0,standX+12,0);steel.addColorStop(0,'#263546');steel.addColorStop(.5,'#66788c');steel.addColorStop(1,'#293747');
    for(const x of [standX,standR]) {rect(x-5,beam,10,floor-beam,steel,3);rect(x-21,floor-3,42,9,'#52657a',3);}
    rect(standX-8,beam-8,standR-standX+16,13,'#708399',3);
    for(const x of [cx-shaft,cx+shaft]){circle(x,beam,4,C.gold);line(x,beam+5,x,cy,C.gold,2);}
    // 每侧绕线的示意：圈数随放出的绳长减少，不把线圈宽度当比例测量。
    const wraps=Math.max(0,Math.min(12,Math.round(e.h/Wheel.AXLE/(2*Math.PI))));
    line(cx-shaft-7,cy,cx+shaft+7,cy,'#9cabb0',11);
    line(cx-shaft-7,cy-3,cx+shaft+7,cy-3,'#d1d7d3',2);
    for(const side of [-1,1])for(let i=0;i<wraps;i++){
      const x=cx+side*(radius+6+i*2.6);line(x,cy-6,x+1,cy+6,C.gold,1.5);
    }
    // 圆盘保持正圆；金属边缘、轮毂与偏心标记让旋转可直接辨认。
    circle(cx+4,cy+4,radius,'#0a121b','#5a6871');
    const metal=c.createRadialGradient(cx-radius*.35,cy-radius*.4,2,cx,cy,radius);
    metal.addColorStop(0,'#879cac');metal.addColorStop(.35,'#405b72');metal.addColorStop(.83,'#182d43');metal.addColorStop(.9,'#8a9eae');metal.addColorStop(1,'#cfdae1');
    circle(cx,cy,radius,metal);
    c.save();c.translate(cx,cy);c.rotate(s.theta);
    for(let i=0;i<6;i++){const a=i*Math.PI/3;line(Math.cos(a)*14,Math.sin(a)*14,Math.cos(a)*(radius-13),Math.sin(a)*(radius-13),'#9baeb44d',5);}
    circle(0,-radius*.72,5,C.gold);c.restore();
    c.beginPath();c.arc(cx,cy,radius*.84,0,Math.PI*2);c.strokeStyle='#c8e5ff22';c.lineWidth=1;c.stroke();
    circle(cx,cy,13,'#b49a6b','#f3d59c');circle(cx,cy,5,'#354652');
    if(ui.hover||ui.dragging){c.beginPath();c.arc(cx,cy,radius+7,0,Math.PI*2);c.strokeStyle=C.gold;c.lineWidth=2;c.stroke();}
    // 固定的最低轴心为势能零点，释放高度虚线与实物轴心使用同一映射。
    const rulerX = Math.min(w-25,standR+31);
    line(rulerX,bottom-.8*scale,rulerX,bottom,C.muted);
    for(let i=0;i<=8;i++){const y=bottom-i*.1*scale;line(rulerX-5,y,rulerX+(i%2?3:7),y,C.muted);if(i%2===0)text((i/10).toFixed(1),rulerX+10,y+4,10);}
    text('m',rulerX+5,top-10,11);
    line(standX+12,bottom,standR-12,bottom,'#8ba9b66b',1,[4,4]);
    if(ui.height){
      const releaseY=bottom-s.release*scale;
      line(standX+12,releaseY,standR-12,releaseY,C.gold,1,[4,5]);
      text('释放位置',standX+12,releaseY-9,11,C.gold);
    }
    const arrowX = cx-radius-20;
    if(ui.velocity&&e.speed>.002){const sign=s.v>0?-1:1,len=Math.min(52,e.speed*90)+12;
      line(arrowX,cy,arrowX,cy+sign*len,C.blue,2.5);
      line(arrowX,cy+sign*len,arrowX-5,cy+sign*(len-8),C.blue,2.5);
      line(arrowX,cy+sign*len,arrowX+5,cy+sign*(len-8),C.blue,2.5);
    }
    const phase=e.speed<.002?(s.rest?'接近静止':s.t === 0 ? '等待释放' : '上方转折'):(s.v<0?'放线 · 下降加速':'绕线 · 上升减速');
    const captionY=floor+43;
    text(phase,cx,captionY, mobile?14:16,C.text,'center');
    text(`高度 ${e.h.toFixed(2)} m  ·  速率 ${e.speed.toFixed(2)} m/s`,cx,captionY+22,11,C.muted,'center');
    text(ui.dragging?'松开后点击释放':ui.hover?'拖动以设置释放高度':'拖动圆盘，改变释放高度',cx,beam-19,10,ui.hover?C.gold:'#71869e','center');
    // 共用初始能量刻度：势能、两种动能及耗散之和始终为一整条。
    const ex=mobile?24:Math.max(40,w*.17), ew=w-ex*2, ey=h-177;
    rect(ex-14,ey-35,ew+28,112,'#101925',10);
    text('能量去向',ex,ey-13,12,C.text);
    text(`合计 ${e.e0.toFixed(2)} J`,ex+ew,ey-13,11,C.muted,'right');
    const energies=[['重力势能',e.ep,C.gold],['转动动能',e.er,C.purple],['平动动能',e.et,C.blue],['耗散',e.q,C.orange]];
    rect(ex,ey,ew,13,'#243448',5);let offset=0;
    for(const [,val,col]of energies){const width=ew*Math.max(0,val/e.e0);if(width>.05)rect(ex+offset,ey,width,13,col,0);offset+=width;}
    energies.forEach(([label,val,col],i)=>{const x=ex+(i%2)*ew*.52,y=ey+36+Math.floor(i/2)*24;circle(x+3,y-4,3,col);text(`${label} ${val.toFixed(2)} J`,x+13,y,11,C.text);});

    return {wheel:{x:cx,y:cy,r:radius},layout:{bottom,scale},energies:e};
  }
  window.WheelDraw={draw};
})();
