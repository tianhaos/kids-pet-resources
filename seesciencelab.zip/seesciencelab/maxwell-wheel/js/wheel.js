(function () {
  'use strict';
  // SI单位；h向上，v向上。圆盘、轻轴；换向事件不求短时绳弹性。
  const G = 10, R = .11, AXLE = .016, K = .5 * R * R / (AXLE * AXLE);
  const A = G / (1 + K);
  function create(scene = 'ideal', mass = 1, release = .7) {
    return { scene, mass, release, h: release, v: 0, theta: 0, branch: -1, t: 0, q: 0, turns: 0, rest: false, lastTurn: -10 };
  }
  function values(s) {
    const omega = s.branch * s.v / AXLE;
    const ep = s.mass * G * s.h, et = .5 * s.mass * s.v * s.v;
    const er = .5 * s.mass * K * s.v * s.v;
    return { h: s.h, v: s.v, speed: Math.abs(s.v), omega, ep, et, er, ek: et + er,
      em: ep + et + er, q: s.q, e0: s.mass * G * s.release, a: s.rest ? 0 : A,
      apex: s.rest ? 0 : s.h + s.v * s.v / (2 * A), turns: s.turns };
  }
  function step(s, seconds) {
    let remain = Math.max(0, Math.min(120 - s.t, seconds));
    // 每段为精确匀加速解，分段定位底部事件，避免时间步长改变能量。
    while (remain > 1e-10) {
      if (s.rest) { s.t += remain; break; }
      const impact = (s.v + Math.sqrt(Math.max(0, s.v * s.v + 2 * A * s.h))) / A;
      const dt = Math.min(remain, impact);
      const dh = s.v * dt - .5 * A * dt * dt;
      s.theta += s.branch * dh / AXLE;
      s.h = Math.max(0, s.h + dh); s.v -= A * dt; s.t += dt; remain -= dt;
      if (impact <= dt + 1e-10) {
        const before = .5 * s.mass * (1 + K) * s.v * s.v;
        const keep = s.scene === 'damped' ? .85 : 1;
        s.q += before * (1 - keep);
        s.h = 0; s.v = -s.v * Math.sqrt(keep); s.branch *= -1;
        s.turns++; s.lastTurn = s.t;
        // 极小振幅最终停下，残余机械能一并转入耗散，避免无限事件。
        if (s.v * s.v / (2 * A) < .0001) {
          s.q += before * keep; s.v = 0; s.rest = true;
        }
      }
    }
    return values(s);
  }
  function at(scene, mass, release, time) { const s = create(scene, mass, release); step(s, time); return s; }
  window.Wheel = { G, R, AXLE, K, A, create, values, step, at };
})();
