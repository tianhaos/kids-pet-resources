(function () {
  'use strict';
  const $ = id => document.getElementById(id), query = new URLSearchParams(location.search);
  function num(key, fallback, min, max) { const raw = query.get(key); const v = raw === null || raw.trim() === '' ? fallback : Number(raw); return Number.isFinite(v) ? Math.max(min, Math.min(max, v)) : fallback; }
  const scene = query.get('scene') === 'damped' ? 'damped' : 'ideal';
  const state = Wheel.create(scene, num('m', 1, .5, 2), num('h', .7, .2, .8));
  const ui = { velocity: true, height: true, dragging: false, hover: false, speed: num('rate', .6, .2, 1) };
  let play = false, last = 0, drawing, records = [], pointer = null;
  const initialTime = num('t', 1, 0, 20);
  for (let t = 0; t < initialTime; t += .02) Wheel.step(state, Math.min(.02, initialTime - t));
  play = query.get('play') === '1';
  function track(action, label) { if (window.Analytics) Analytics.track('滚摆与能量转化', action, String(label)); }
  function reset(x = state.release) {
    Object.assign(state, Wheel.create(state.scene, state.mass, x)); play = false; update();
  }
  function setScene(value) { state.scene = value === 'damped' ? 'damped' : 'ideal'; reset(); track('场景', state.scene); }
  function update() {
    const e = Wheel.values(state);
    $('mass').value = state.mass; $('massOut').textContent = `${state.mass.toFixed(1)} kg`;
    $('release').value = state.release; $('releaseOut').textContent = `${state.release.toFixed(2)} m`;
    $('speed').value = ui.speed; $('speedOut').textContent = `${ui.speed.toFixed(1)}×`;
    $('play').textContent = play ? '暂停' : state.t > 0 ? '继续运动' : '释放滚摆';
    $('rHeight').textContent = `${e.h.toFixed(3)} m`; $('rSpeed').textContent = `${e.speed.toFixed(3)} m/s`;
    $('rOmega').textContent = `${Math.abs(e.omega).toFixed(2)} rad/s`; $('rApex').textContent = `${e.apex.toFixed(3)} m`; $('rTurns').textContent = e.turns;
    $('rM').textContent = `${e.em.toFixed(3)} J`; $('rQ').textContent = `${e.q.toFixed(3)} J`;
    $('time').value = state.t; $('timeOut').textContent = `${state.t.toFixed(2)} s`;
    $('status').textContent = state.rest ? '接近静止' : e.speed < .002 ? state.t === 0 ? '等待释放' : '上方转折' : state.v < 0 ? '放线 · 下降加速' : '绕线 · 上升减速';
    $('stageMode').textContent = state.scene === 'ideal' ? '理想 · 无损耗' : '对照 · 换向耗散';
    $('sceneNote').textContent = state.scene === 'ideal' ? '理想换向无损耗，每次回到同一高度。' : '每次底部换向损失15%机械能；教学设定。';
    document.querySelectorAll('[data-scene]').forEach(b => { b.classList.toggle('on', b.dataset.scene === state.scene); b.setAttribute('aria-pressed', b.dataset.scene === state.scene); });
    drawing = WheelDraw.draw($('wheel'), state, ui);
  }
  document.querySelectorAll('[data-scene]').forEach(b => b.addEventListener('click', () => setScene(b.dataset.scene)));
  $('play').onclick = () => { if (state.t >= 20 || state.rest) reset(); play = !play; track('播放', play); update(); };
  $('reset').onclick = () => { reset(); track('重置', state.scene); };
  $('mass').oninput = () => { state.mass = Number($('mass').value); reset(); };
  $('mass').onchange = () => track('质量', state.mass);
  $('release').oninput = () => reset(Number($('release').value));
  $('release').onchange = () => track('释放点', state.release);
  $('time').oninput = () => { play = false; Object.assign(state, Wheel.at(state.scene, state.mass, state.release, Number($('time').value))); update(); };
  $('time').onchange = () => track('时间探测', state.t.toFixed(2));
  $('speed').oninput = () => { ui.speed = Number($('speed').value); update(); };
  $('speed').onchange = () => track('慢放', ui.speed);
  for (const key of ['velocity', 'height']) $(key).onchange = () => { ui[key] = $(key).checked; track('显示', key + ':' + ui[key]); update(); };
  if (matchMedia('(max-width:760px)').matches) $('panel').classList.add('collapsed');
  $('panelToggle').setAttribute('aria-expanded', String(!$('panel').classList.contains('collapsed')));
  $('panelToggle').onclick = () => $('panelToggle').setAttribute('aria-expanded', String(!$('panel').classList.toggle('collapsed')));
  $('record').onclick = () => {
    const e = Wheel.values(state);
    records.unshift({ scene: state.scene, t: state.t, mass: state.mass, ...e }); records = records.slice(0, 6);
    $('records').replaceChildren(...records.map(r => {
      const p = document.createElement('p'); p.textContent = `${r.scene === 'ideal' ? '理想' : '耗散'} · ${r.mass.toFixed(1)} kg · ${r.t.toFixed(1)} s｜h ${r.h.toFixed(2)} m，v ${r.speed.toFixed(2)} m/s｜平 ${r.et.toFixed(2)} / 转 ${r.er.toFixed(2)} / 势 ${r.ep.toFixed(2)} / 耗散 ${r.q.toFixed(2)} J`; return p;
    })); track('记录', records.length);
  };
  $('clear').onclick = () => { records = []; $('records').replaceChildren(); track('清空记录', ''); };
  function shareURL() {
    const url = new URL(location.href); url.search = '';
    // 从相同释放点积分到相同时间，恢复全部运动与耗散状态。
    const params = { scene: state.scene, m: state.mass, h: state.release, t: state.t.toFixed(6), play: 0, rate: ui.speed };
    Object.entries(params).forEach(([k, v]) => url.searchParams.set(k, v)); return url.href;
  }
  $('share').onclick = async () => {
    play = false; update(); const url = shareURL();
    try { await navigator.clipboard.writeText(url); $('shareNote').textContent = '已复制当前条件与暂停时刻链接。'; }
    catch { $('shareNote').textContent = url; }
    track('分享', state.scene);
  };
  const canvas = $('wheel');
  function point(ev) { const r = canvas.getBoundingClientRect(); return { x: ev.clientX - r.left, y: ev.clientY - r.top }; }
  function hit(p) { return drawing && Math.hypot(p.x - drawing.wheel.x, p.y - drawing.wheel.y) <= drawing.wheel.r + 12; }
  canvas.onpointerdown = ev => {
    if (!hit(point(ev))) return;
    pointer = ev.pointerId; canvas.setPointerCapture(pointer); ui.dragging = true; canvas.style.cursor = 'grabbing'; play = false; ev.preventDefault(); update();
  };
  canvas.onpointermove = ev => {
    const p = point(ev);
    if (ui.dragging && pointer === ev.pointerId) {
      const l = drawing.layout, x = Math.max(.2, Math.min(.8, (l.bottom - p.y) / l.scale));
      reset(x);
    } else { ui.hover = hit(p); canvas.style.cursor = ui.hover ? 'grab' : 'default'; }
  };
  function end(ev) {
    if (pointer !== ev.pointerId) return;
    ui.dragging = false; pointer = null; canvas.style.cursor = 'grab'; track('拖动滚摆', state.release.toFixed(2)); update();
  }
  canvas.onpointerup = end; canvas.onpointercancel = end;
  canvas.onpointerleave = () => { ui.hover = false; };
  window.addEventListener('keydown', ev => {
    if (ev.code !== 'Space' || /INPUT|BUTTON|TEXTAREA|SELECT/.test(ev.target.tagName) || ev.target.isContentEditable) return;
    ev.preventDefault(); $('play').click();
  });
  function frame(now) {
    if (play && !ui.dragging) {
      Wheel.step(state, Math.min(20 - state.t, Math.min((now - (last || now)) / 1000, .05) * ui.speed));
      if (state.t >= 20 - 1e-8) { state.t = 20; play = false; }
    }
    last = now; update(); requestAnimationFrame(frame);
  }
  window.__model = { state, ui, update, reset, setScene, values: () => Wheel.values(state), advance: seconds => { play = false; Wheel.step(state, Math.max(0, Math.min(20-state.t, seconds))); update(); }, setPlay: value => { play = !!value; }, shareURL, getDrawing: () => drawing, getRecords: () => records.slice() };
  update(); requestAnimationFrame(frame);
})();
