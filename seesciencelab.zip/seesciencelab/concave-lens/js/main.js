(function () {
  var K = window.Concave;
  var $ = function (id) { return document.getElementById(id); };
  var qa = function (sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); };

  var state = {
    scene: 'image',
    f: 10,
    // 对光的作用
    lens: 'concave', beam: { kind: 'parallel', d: 10, ang: 0 },
    // 成像
    u: 20, h: 6, cmp: false, eye: { x: 22, y: 1 },
    auto: false, autoDir: -1, autoMult: 1, autoPause: 0,
    // 判断透镜
    quiz: null, answered: false, correct: false, score: { n: 0, ok: 0 },
    show: { orig: true, ext: true, pulse: true, rays: true, fan: false, eye: false, labels: true },
    t: 0
  };

  var HINTS = {
    light: '看光经过透镜后是会聚还是发散',
    image: '拖动蜡烛改变物距 · 像总是正立、缩小的虚像',
    quiz: '方框里是凸透镜还是凹透镜？'
  };
  var SNAP_PX = 8;

  var stage = $('stage'), canvas = $('ray'), panel = $('panel');
  var view = window.LensDraw(canvas);
  var sol = null;

  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
  function setSeg(attr, val) { qa('[data-' + attr + ']').forEach(function (b) { b.classList.toggle('on', b.dataset[attr] === val); }); }
  function near(a, b) { return Math.abs(a - b) < 1e-6; }

  function solve() {
    if (state.scene === 'light') return K.traceBeam(state.lens, state.f, state.beam, 7, 9);
    if (state.scene === 'image') {
      var r = { ccv: K.solveImage(state.u, state.h, -state.f) };
      if (state.cmp) r.cvx = K.solveImage(state.u, state.h, state.f);
      return r;
    }
    return null;
  }

  // ---------- 场景 ----------
  qa('[data-scene]').forEach(function (b) {
    b.addEventListener('click', function () { setScene(b.dataset.scene); Analytics.track('凹透镜', '场景', b.textContent); });
  });
  function setScene(sc) {
    state.scene = sc;
    if (sc !== 'image') setAuto(false);
    if (sc === 'quiz' && !state.quiz) newQuiz();
    syncUI();
  }

  // ---------- 对光的作用 ----------
  qa('[data-lens]').forEach(function (b) {
    b.addEventListener('click', function () { state.lens = b.dataset.lens; syncUI(); Analytics.track('凹透镜', '透镜', b.textContent); });
  });
  qa('[data-beam]').forEach(function (b) {
    b.addEventListener('click', function () { setBeam(b.dataset.beam); Analytics.track('凹透镜', '入射光', b.textContent); });
  });
  function setBeam(kind) {
    state.beam.kind = kind;
    if (kind !== 'parallel' && state.beam.d < 2) state.beam.d = state.f;
    syncUI();
  }
  var angEl = $('ang'), posEl = $('pos');
  angEl.addEventListener('input', function () { state.beam.ang = parseFloat(angEl.value); syncUI(); });
  posEl.addEventListener('input', function () { state.beam.d = parseFloat(posEl.value); syncUI(); });
  $('toFocus').addEventListener('click', function () {
    // 凸透镜：点光源放在焦点 F；凹透镜：入射光射向异侧虚焦点 F′。两种情况出射光都平行于主光轴
    if (state.lens === 'convex') state.beam.kind = 'point'; else state.beam.kind = 'converge';
    state.beam.d = state.f;
    syncUI();
    Analytics.track('凹透镜', '特殊光线', state.lens);
  });

  // ---------- 成像 ----------
  var autoOn = $('autoOn');
  function setAuto(on) {
    state.auto = on;
    autoOn.checked = on;
    state.autoPause = 0;
  }
  autoOn.addEventListener('change', function () { setAuto(autoOn.checked); if (autoOn.checked) Analytics.track('凹透镜', '自动移动'); });
  $('autoSpeed').addEventListener('input', function () { state.autoMult = parseFloat($('autoSpeed').value); syncUI(); });
  $('height').addEventListener('input', function () { state.h = parseFloat($('height').value); syncUI(); });
  qa('[data-k]').forEach(function (b) {
    b.addEventListener('click', function () { setAuto(false); state.u = Math.min(uMax(), parseFloat(b.dataset.k) * state.f); });
  });
  $('cmp').addEventListener('change', function () { state.cmp = $('cmp').checked; if (state.cmp) Analytics.track('凹透镜', '对比凸透镜'); });

  function uMax() { return Math.max(state.f * 0.5, -view.xRange('main')[0] - 2); }
  function uMin() { return Math.max(0.6, state.f * 0.15); }

  // 自动移动：在 uMax 与 0.2f 之间往返，远处快、近处慢，两端停顿
  function autoStep(dt) {
    if (state.autoPause > 0) { state.autoPause -= dt; return; }
    var lo = Math.max(uMin(), state.f * 0.2), hi = uMax();
    var speed = state.f * 0.35 * (0.35 + state.u / (2 * state.f)) * state.autoMult;
    state.u += state.autoDir * speed * dt;
    if (state.u <= lo) { state.u = lo; state.autoDir = 1; state.autoPause = 0.8; }
    if (state.u >= hi) { state.u = hi; state.autoDir = -1; state.autoPause = 0.8; }
  }

  // ---------- 判断透镜 ----------
  function newQuiz() {
    state.quiz = K.quiz(Math.random, state.quiz && state.quiz.id);
    state.answered = false;
    syncUI();
  }
  qa('[data-answer]').forEach(function (b) {
    b.addEventListener('click', function () {
      if (state.answered) return;
      state.answered = true;
      state.correct = b.dataset.answer === state.quiz.type;
      state.score.n++; if (state.correct) state.score.ok++;
      Analytics.track('凹透镜', '判断透镜', state.correct ? '对' : '错');
      syncUI();
    });
  });
  $('nextQ').addEventListener('click', newQuiz);

  // ---------- 公共 ----------
  var focalEl = $('focal');
  focalEl.addEventListener('input', function () {
    var v = parseFloat(focalEl.value), k = state.u / state.f;
    if (state.beam.kind !== 'parallel' && near(state.beam.d, state.f)) state.beam.d = v;   // 保持"在焦点上"
    state.u = Math.min(k * v, uMax());                                                    // 保持 u/f，不跳区间
    state.f = v;
    syncUI();
  });
  [['showOrig', 'orig'], ['showExt', 'ext'], ['showPulse', 'pulse'], ['showRays', 'rays'], ['showFan', 'fan'],
   ['showEye', 'eye'], ['showLabels', 'labels'], ['showOrigQ', 'orig']].forEach(function (p) {
    $(p[0]).addEventListener('change', function () {
      state.show[p[1]] = $(p[0]).checked;
      if (p[1] === 'eye' && state.show.eye) Analytics.track('凹透镜', '人眼观察');
      syncUI();
    });
  });

  // ---------- 拖动 ----------
  var drag = null;
  function localXY(e) { var r = canvas.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; }
  function snapF(x, target) {
    var w = view.toWorld(0, 0, drag.pane), p0 = view.toWorld(SNAP_PX, 0, drag.pane);
    return Math.abs(x - target) < (p0.x - w.x) ? target : x;
  }
  function dragTo(px, py) {
    var w = view.toWorld(px, py, drag.pane), rg = view.xRange(drag.pane);
    if (drag.what === 'obj') {
      var u = clamp(-w.x - drag.off, uMin(), -rg[0] - 2);
      [state.f, 2 * state.f].forEach(function (t) { u = snapF(u, t); });
      state.u = u;
    } else if (drag.what === 'eye') {
      state.eye.x = clamp(w.x - 0.8, 4, rg[1] - 4); state.eye.y = clamp(w.y, -9, 9);
    } else if (drag.what === 'src') {
      var d = state.beam.kind === 'point' ? -w.x : w.x;
      state.beam.d = snapF(clamp(d, 2, (state.beam.kind === 'point' ? -rg[0] : rg[1]) - 2), state.f);
      syncUI();
    }
  }
  canvas.addEventListener('pointerdown', function (e) {
    var p = localXY(e);
    drag = view.hit(p[0], p[1], state);
    if (!drag) return;
    if (drag.what === 'obj') { drag.off = -view.toWorld(p[0], p[1], drag.pane).x - state.u; setAuto(false); }
    try { canvas.setPointerCapture(e.pointerId); } catch (err) { /* 合成事件无法捕获指针 */ }
    canvas.classList.add('grabbing');
  });
  canvas.addEventListener('pointermove', function (e) {
    var p = localXY(e);
    if (!drag) { canvas.classList.toggle('grab', !!view.hit(p[0], p[1], state)); return; }
    dragTo(p[0], p[1]);
  });
  function endDrag(e) {
    if (!drag) return;
    drag = null;
    canvas.classList.remove('grabbing');
    if (canvas.hasPointerCapture(e.pointerId)) canvas.releasePointerCapture(e.pointerId);
  }
  canvas.addEventListener('pointerup', endDrag);
  canvas.addEventListener('pointercancel', endDrag);

  $('panelToggle').addEventListener('click', function () { panel.classList.toggle('collapsed'); });
  if (window.matchMedia('(max-width: 760px)').matches) panel.classList.add('collapsed');
  window.addEventListener('keydown', function (e) {
    var t = e.target.tagName;
    if (t === 'INPUT' || t === 'SELECT' || t === 'BUTTON' || t === 'TEXTAREA') return;
    if (e.code === 'Space' && state.scene === 'image') { e.preventDefault(); setAuto(!state.auto); }
  });

  // ---------- 面板同步 ----------
  function syncUI() {
    var sc = state.scene, b = state.beam;
    setSeg('scene', sc);
    qa('[data-for]').forEach(function (el) {
      var f = el.dataset.for.split(' ');
      el.hidden = f.indexOf(sc) < 0 || (f.indexOf('parallel') >= 0 && b.kind !== 'parallel') || (f.indexOf('nonpar') >= 0 && b.kind === 'parallel');
    });
    $('hint').textContent = sc === 'light' && b.kind !== 'parallel' ? '拖动' + (b.kind === 'point' ? '点光源' : '会聚点') + '改变位置 · 靠近焦点时会吸附' : HINTS[sc];
    setSeg('lens', state.lens); setSeg('beam', b.kind);
    angEl.value = b.ang; $('angOut').textContent = b.ang.toFixed(0) + '°';
    posEl.max = 40; posEl.value = b.d; $('posOut').textContent = b.d.toFixed(1) + ' cm';
    $('posLabel').textContent = b.kind === 'point' ? '光源距离' : '会聚点';
    $('toFocus').textContent = state.lens === 'convex' ? '点光源放在焦点 F' : '光射向异侧焦点 F′';
    focalEl.value = state.f; $('focalOut').textContent = state.f.toFixed(1) + ' cm';
    $('height').value = state.h; $('heightOut').textContent = state.h.toFixed(1) + ' cm';
    $('autoOut').textContent = state.autoMult + '×';
    $('cmp').checked = state.cmp;
    $('showOrigQ').checked = $('showOrig').checked = state.show.orig;
    $('showEye').checked = state.show.eye;
    qa('[data-answer]').forEach(function (x) {
      x.disabled = state.answered;
      x.classList.toggle('on', state.answered && x.dataset.answer === (state.quiz && state.quiz.type));
    });
    $('nextQ').textContent = state.answered ? '下一题 →' : '换一题';
    $('quizMsg').innerHTML = !state.answered || !state.quiz ? ''
      : '<b class="' + (state.correct ? 'ok">✓ 答对了' : 'bad">✗ 是' + (state.quiz.type === 'concave' ? '凹透镜' : '凸透镜')) + '</b>' + K.explain(state.quiz);
  }

  // ---------- 读数 ----------
  var last = {};
  function setText(id, s) { if (last[id] !== s) { last[id] = s; $(id).textContent = s; } }
  function rows(list) {
    for (var k = 1; k <= 5; k++) {
      var r = list[k - 1] || ['', ''];
      setText('d' + k, r[0]); setText('r' + k, r[1]);
      $('d' + k).hidden = $('r' + k).hidden = !r[0];
    }
  }
  function setBig(str, cls) { setText('rState', str); $('rState').className = cls || ''; }
  function cm(a) { return a.toFixed(1) + ' cm'; }

  function readLight(s) {
    var ccv = state.lens === 'concave', b = state.beam, atF = b.kind !== 'parallel' && Math.abs(b.d - state.f) < 0.05;
    setBig(ccv ? '凹透镜：发散作用' : '凸透镜：会聚作用', ccv ? 'virt' : 'ok');
    var tip;
    if (b.kind === 'parallel') {
      tip = ccv ? (b.ang ? '斜射的平行光经凹透镜后发散，反向延长线交于焦平面上同一点。'
        : '平行于主光轴的光经凹透镜折射后发散，反向延长线交于主光轴上一点——凹透镜的虚焦点 F。凹透镜两侧各有一个虚焦点。')
        : (b.ang ? '斜射的平行光经凸透镜后会聚于焦平面上的一点。' : '平行于主光轴的光经凸透镜折射后会聚于焦点 F′，这是实际光线的交点（实焦点）。');
    } else if (b.kind === 'point') {
      tip = ccv ? '点光源发出的发散光，经凹透镜后更加发散。'
        : atF ? '从焦点发出的光，经凸透镜折射后平行于主光轴（光路可逆）。'
        : b.d < state.f ? '光源在焦点以内：出射光仍然发散，但比原来的方向更靠拢主光轴——凸透镜仍起会聚作用。'
        : '发散光经凸透镜后会聚于一点。';
    } else {
      tip = !ccv ? '会聚光经凸透镜后会聚得更快，会聚点提前了。'
        : atF ? '射向异侧虚焦点 F′ 的光，经凹透镜折射后平行于主光轴。这是凹透镜的第三条特殊光线。'
        : b.d < state.f ? '会聚光经凹透镜后仍然会聚，但比原来的方向偏离主光轴，会聚点变远了——凹透镜仍起发散作用。'
        : '原本会聚的光，经凹透镜后变成了发散光。';
    }
    setText('rTip', tip);
    rows([
      ['透镜', (ccv ? '凹透镜（中间薄、边缘厚）' : '凸透镜（中间厚、边缘薄）') + '，f = ' + cm(state.f)],
      ['入射光', s.inn.text],
      ['出射光', s.out.text],
      ['与原方向比', ccv ? '偏离主光轴（更发散）' : '靠拢主光轴（更会聚）'],
      ['焦点', ccv ? 'F、F′ 都是虚焦点（反向延长线的交点）' : 'F、F′ 是实焦点（实际光线的交点）']
    ]);
  }

  function readImage(s) {
    var c = s.ccv, am = c.m;
    setBig(c.nature.text, 'virt');
    var tip = state.cmp && s.cvx
      ? '同一物距，凸透镜' + (s.cvx.none ? '不成像' : '成' + s.cvx.nature.text.replace(/ · /g, '、')) + '；凹透镜不管物体在哪里，都成正立、缩小的虚像。'
      : '不论物体放在哪里，凹透镜都成正立、缩小的虚像，像与物在透镜同侧，位于虚焦点 F 与光心 O 之间。';
    if (state.show.eye && !state.cmp) tip = '眼睛逆着折射光线看去，光好像是从像点发出的：透过凹透镜看到的是缩小的虚像，光屏接不到。';
    setText('rTip', tip);
    rows([
      ['物距 u', cm(c.u) + '（= ' + (c.u / state.f).toFixed(2) + ' f）'],
      ['像距 |v|', cm(-c.v) + '（与物同侧，小于 f）'],
      ['放大率', am.toFixed(2) + ' 倍（缩小）'],
      ['变化', '物体越近，像越大、越靠近透镜，但总小于物体'],
      state.cmp && s.cvx ? ['凸透镜', s.cvx.none ? '不成像（u = f）' : s.cvx.nature.text + (s.cvx.real ? '，v = ' + cm(s.cvx.v) : '')]
        : ['应用', '近视眼镜、门镜（猫眼）的物镜']
    ]);
  }

  function readQuiz() {
    var q = state.quiz, sc = state.score;
    if (!state.answered) {
      setBig('方框里是什么透镜？', '');
      setText('rTip', '红、蓝两条光线从左边射入方框，从右边射出。比较出射光和"原来的传播方向"。');
    } else {
      setBig(state.correct ? '✓ 答对了' : '✗ 是' + (q.type === 'concave' ? '凹透镜' : '凸透镜'), state.correct ? 'ok' : 'bad');
      setText('rTip', K.explain(q));
    }
    var inn = isFinite(q.u) ? (q.u > 0 ? '发散光' : '会聚光') : '平行光';
    var out = !isFinite(q.v) ? '平行光' : q.v > 0 ? '会聚光' : '发散光';
    rows([
      ['入射光', inn],
      ['出射光', out + (q.cross ? '（两条光线在框内相交）' : '')],
      ['得分', sc.ok + ' / ' + sc.n],
      state.answered ? ['透镜', (q.type === 'concave' ? '凹透镜' : '凸透镜') + '，f = ' + cm(q.f)] : ['', ''],
      ['', '']
    ]);
  }

  // ---------- 尺寸与主循环 ----------
  function resize() { view.resize(stage.clientWidth, stage.clientHeight); }
  new ResizeObserver(resize).observe(stage);

  // 支持 ?scene=light&lens=convex&beam=point、?scene=image&cmp=1&eye=1、?scene=quiz
  var qs = new URLSearchParams(location.search);
  if (HINTS[qs.get('scene')]) state.scene = qs.get('scene');
  if (qs.get('lens') === 'convex') state.lens = 'convex';
  if (['parallel', 'point', 'converge'].indexOf(qs.get('beam')) >= 0) state.beam.kind = qs.get('beam');
  if (qs.get('cmp') === '1') state.cmp = true;
  if (qs.get('eye') === '1') state.show.eye = true;
  var fq = parseFloat(qs.get('f'));
  if (fq >= 6 && fq <= 15) { state.f = fq; state.beam.d = fq; }

  resize();
  setScene(state.scene);

  var lastT = performance.now();
  function frame(t) {
    var dt = Math.min((t - lastT) / 1000, 0.1);
    lastT = t;
    state.t += dt;
    if (state.scene === 'image') {
      if (state.auto && !drag) autoStep(dt);
      state.u = Math.min(state.u, uMax());
      state.eye.x = Math.min(state.eye.x, view.xRange('main')[1] - 4);   // 窄屏时眼睛别跑出画面
    }
    sol = solve();
    view.draw(state, sol);
    if (state.scene === 'light') readLight(sol);
    else if (state.scene === 'image') readImage(sol);
    else readQuiz();
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // 调试用
  window.__model = { state: state, setScene: setScene, setBeam: setBeam, newQuiz: newQuiz, solve: solve, syncUI: syncUI };
})();
