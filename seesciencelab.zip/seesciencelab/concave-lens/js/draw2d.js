// 2D 光路图：对光的作用（光束）、凹透镜成像（可叠加凸透镜对比）、判断方框里的透镜
// 世界坐标单位 cm，透镜光心在原点，x 向右、y 向上。
// 视觉约定与凸透镜模型一致：三条特殊光线 平行 #ff7a59、过光心 #4fc3f7、过（射向）焦点 #7ee081；
// 实物金色 #ffc94a，虚像 = 半透明 + 紫色 #c9a7ff 虚线描边，反向延长线一律虚线。
(function () {
  var K = window.Concave;

  var C = {
    axis: '#5b677b', text: '#c9d2df', muted: '#8d99ab', grid: 'rgba(255,255,255,0.035)',
    lens: 'rgba(120,190,255,0.20)', lensEdge: '#8fd0ff',
    r1: '#ff7a59', r2: '#4fc3f7', r3: '#7ee081', fan: 'rgba(255,201,74,0.22)',
    beam: '#ffd166', orig: 'rgba(230,235,242,0.42)', real: '#ffc94a', virt: '#c9a7ff', focus: '#ffc94a',
    box: '#1a2232', boxEdge: '#8d99ab', cone: 'rgba(255,209,102,0.16)'
  };
  var APERTURE = { light: 11, image: 12, quiz: 11 };

  function LensDraw(canvas) {
    var ctx = canvas.getContext('2d');
    var W = 1, H = 1, dpr = 1, narrow = false;
    var P = null;                       // 当前绘图窗格：{ x, y, w, h, s, cx, cy }
    var panes = {};                     // 记录各窗格，供拖动命中与坐标换算

    function X(x) { return P.cx + x * P.s; }
    function Y(y) { return P.cy - y * P.s; }
    function xl() { return (P.x - P.cx) / P.s; }
    function xr() { return (P.x + P.w - P.cx) / P.s; }

    function resize(w, h) {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      W = w; H = h;
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
      canvas.style.width = w + 'px'; canvas.style.height = h + 'px';
      narrow = w < 640;
    }

    // 在像素矩形里放一个窗格：水平至少显示 ±hw、竖直至少 ±hv（cm），光心横向位于 fx 处
    function pane(name, x, y, w, h, hw, hv, fx) {
      var s = Math.min(w / (2 * hw), h / (2 * hv));
      P = { x: x, y: y, w: w, h: h, s: s, cx: x + w * fx, cy: y + h / 2 };
      panes[name] = P;
      ctx.save();
      ctx.beginPath(); ctx.rect(x, y, w, h); ctx.clip();
      return P;
    }
    function endPane() { ctx.restore(); }

    // ---------- 基本绘图 ----------
    function line(x1, y1, x2, y2, color, width, dash) {
      ctx.beginPath();
      ctx.setLineDash(dash || []);
      ctx.strokeStyle = color; ctx.lineWidth = width || 1.5;
      ctx.moveTo(X(x1), Y(y1)); ctx.lineTo(X(x2), Y(y2));
      ctx.stroke();
      ctx.setLineDash([]);
    }
    function arrowHead(x1, y1, x2, y2, color) {
      var ax = X(x1), ay = Y(y1), bx = X(x2), by = Y(y2);
      if (Math.hypot(bx - ax, by - ay) < 40) return;
      ctx.save();
      ctx.translate((ax + bx) / 2, (ay + by) / 2); ctx.rotate(Math.atan2(by - ay, bx - ax));
      ctx.beginPath(); ctx.moveTo(6, 0); ctx.lineTo(-4, -4); ctx.lineTo(-4, 4); ctx.closePath();
      ctx.fillStyle = color; ctx.fill();
      ctx.restore();
    }
    function font(size, weight) {
      ctx.font = (weight || '') + ' ' + (size || 12) + 'px -apple-system, "PingFang SC", "Microsoft YaHei", sans-serif';
    }
    function text(str, px, py, color, align, size, weight) {
      font(size, weight);
      ctx.fillStyle = color || C.text;
      ctx.textAlign = align || 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(str, px, py);
    }
    function roundRect(x, y, w, h, r) {
      ctx.beginPath();
      ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r);
      ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
    }
    function tag(str, px, py, color) {
      font(12);
      var w = ctx.measureText(str).width + 12;
      px = Math.max(P.x + w / 2 + 4, Math.min(P.x + P.w - w / 2 - 4, px));
      ctx.fillStyle = 'rgba(11,15,23,0.85)';
      ctx.strokeStyle = color; ctx.lineWidth = 1;
      roundRect(px - w / 2, py - 10, w, 20, 10);
      ctx.fill(); ctx.stroke();
      text(str, px, py, color);
    }
    // 从 (x, y) 沿斜率 k 向右延伸到窗格边缘之外
    function rightEnd(x, y, k) { var e = xr() + 5; return [e, y + k * (e - x)]; }
    function leftEnd(x, y, k) { var e = xl() - 5; return [e, y + k * (e - x)]; }

    function background() {
      ctx.strokeStyle = C.grid; ctx.lineWidth = 1;
      ctx.beginPath();
      for (var gx = Math.ceil(xl() / 5) * 5; gx <= xr(); gx += 5) { ctx.moveTo(X(gx), P.y); ctx.lineTo(X(gx), P.y + P.h); }
      for (var gy = -60; gy <= 60; gy += 5) { ctx.moveTo(P.x, Y(gy)); ctx.lineTo(P.x + P.w, Y(gy)); }
      ctx.stroke();
      line(xl(), 0, xr(), 0, C.axis, 1);
    }

    // ---------- 透镜 ----------
    // 凸透镜中间厚边缘薄，凹透镜中间薄边缘厚；焦距越短越"鼓"或越"凹"
    function lens(type, f, A, extendTo, label) {
      var top = Y(A), bot = Y(-A), x0 = X(0), cy = P.cy;
      ctx.beginPath();
      if (type === 'convex') {
        var half = Math.min(Math.max(20 / f, 0.6), 3) * P.s;
        ctx.moveTo(x0, top);
        ctx.quadraticCurveTo(x0 + half * 2, cy, x0, bot);
        ctx.quadraticCurveTo(x0 - half * 2, cy, x0, top);
      } else {
        var ew = Math.max(Math.min(Math.max(16 / f, 0.7), 2.4) * P.s, 7), cw = Math.max(0.12 * P.s, 1.5);
        ctx.moveTo(x0 - ew, top); ctx.lineTo(x0 + ew, top);
        ctx.quadraticCurveTo(x0 + 2 * cw - ew, cy, x0 + ew, bot);
        ctx.lineTo(x0 - ew, bot);
        ctx.quadraticCurveTo(x0 - 2 * cw + ew, cy, x0 - ew, top);
      }
      ctx.closePath();
      ctx.fillStyle = C.lens; ctx.fill();
      ctx.strokeStyle = C.lensEdge; ctx.lineWidth = 1.5; ctx.stroke();
      line(0, A, 0, -A, 'rgba(143,208,255,0.35)', 1);
      if (extendTo > A) {
        line(0, A, 0, extendTo + 1, 'rgba(143,208,255,0.6)', 1.2, [4, 4]);
        line(0, -A, 0, -extendTo - 1, 'rgba(143,208,255,0.6)', 1.2, [4, 4]);
      }
      if (label) text(label, x0, top - 12, C.lensEdge, 'center', 12, '600');
    }

    function foci(f, type, labels, twoF) {
      var list = [[-f, 'F'], [f, 'F′']];
      if (twoF) list.push([-2 * f, '2F'], [2 * f, '2F′']);
      list.forEach(function (p) {
        if (p[0] < xl() || p[0] > xr()) return;
        var minor = p[1].indexOf('2') === 0;
        ctx.beginPath(); ctx.arc(X(p[0]), P.cy, minor ? 3.2 : 4, 0, Math.PI * 2);
        if (type === 'concave' && !minor) {            // 虚焦点：空心
          ctx.fillStyle = '#05070d'; ctx.fill();
          ctx.strokeStyle = C.focus; ctx.lineWidth = 1.6; ctx.stroke();
        } else { ctx.fillStyle = minor ? '#9aa6b8' : C.focus; ctx.fill(); }
        if (labels) text(p[1], X(p[0]), P.cy - 13, minor ? '#9aa6b8' : C.focus, 'center', 13, '600');
      });
      if (labels) text('O', X(0) + 10, P.cy + 12, C.muted, 'left', 12);
    }

    // ---------- 蜡烛（与凸透镜模型同一画法） ----------
    function candle(px, py, hp, style) {
      if (Math.abs(hp) < 0.5) return;
      var k = Math.abs(hp);
      var m = new DOMMatrix().translate(px, py).scale(k, -hp);
      var body = new Path2D(); body.rect(-0.08, 0, 0.16, 0.68);
      var flame = new Path2D();
      flame.moveTo(0, 1);
      flame.bezierCurveTo(0.03, 0.93, 0.085, 0.86, 0.075, 0.8);
      flame.bezierCurveTo(0.068, 0.74, 0.03, 0.72, 0, 0.72);
      flame.bezierCurveTo(-0.03, 0.72, -0.068, 0.74, -0.075, 0.8);
      flame.bezierCurveTo(-0.085, 0.86, -0.03, 0.93, 0, 1);
      var inner = new Path2D(); inner.ellipse(0, 0.79, 0.03, 0.055, 0, 0, Math.PI * 2);
      function T(p) { var q = new Path2D(); q.addPath(p, m); return q; }
      var b = T(body), fl = T(flame), inn = T(inner);
      ctx.save();
      if (style === 'virtual') {
        ctx.globalAlpha = 0.22;
        ctx.fillStyle = '#efe6d2'; ctx.fill(b);
        ctx.fillStyle = '#ffb347'; ctx.fill(fl);
        ctx.globalAlpha = 1;
        ctx.setLineDash([5, 4]);
        ctx.strokeStyle = C.virt; ctx.lineWidth = 1.5;
        ctx.stroke(b); ctx.stroke(fl);
        ctx.setLineDash([]);
      } else {
        ctx.fillStyle = style === 'real' ? '#f6e7c1' : '#efe6d2';
        ctx.fill(b);
        ctx.shadowColor = 'rgba(255,170,60,0.9)'; ctx.shadowBlur = Math.min(24, k * 0.4);
        ctx.fillStyle = '#ff9a3c'; ctx.fill(fl);
        ctx.shadowBlur = 0;
        ctx.fillStyle = '#fff3b0'; ctx.fill(inn);
        if (style === 'real') { ctx.strokeStyle = C.real; ctx.lineWidth = 1.5; ctx.stroke(b); ctx.stroke(fl); }
      }
      ctx.restore();
    }

    // 朝左看的眼睛，(px, py) 为瞳孔中心
    function eye(px, py, sc) {
      ctx.save();
      ctx.translate(px, py); ctx.scale(sc, sc);
      ctx.beginPath();
      ctx.moveTo(-2, 0); ctx.quadraticCurveTo(14, -16, 30, -2); ctx.quadraticCurveTo(14, 14, -2, 0);
      ctx.fillStyle = '#e9eef5'; ctx.fill();
      ctx.strokeStyle = '#9aa6b8'; ctx.lineWidth = 1.5 / sc; ctx.stroke();
      ctx.beginPath(); ctx.arc(6, -1, 6, 0, Math.PI * 2); ctx.fillStyle = '#4b6a8a'; ctx.fill();
      ctx.beginPath(); ctx.arc(4, -1, 2.6, 0, Math.PI * 2); ctx.fillStyle = '#0b0f17'; ctx.fill();
      ctx.restore();
    }

    // 一束光的流动效果：沿折线画间断的亮点
    function pulse(pts, color, t) {
      ctx.save();
      ctx.beginPath();
      ctx.moveTo(X(pts[0][0]), Y(pts[0][1]));
      for (var i = 1; i < pts.length; i++) ctx.lineTo(X(pts[i][0]), Y(pts[i][1]));
      ctx.setLineDash([3, 25]); ctx.lineDashOffset = -t * 70;
      ctx.strokeStyle = color; ctx.lineWidth = 3.2; ctx.lineCap = 'round';
      ctx.shadowColor = color; ctx.shadowBlur = 6;
      ctx.stroke();
      ctx.restore();
    }

    // ---------- 场景一：对光的作用 ----------
    function drawLight(st, sol) {
      var A = APERTURE.light;
      pane('main', 0, 0, W, H, narrow ? 30 : 46, 17, narrow ? 0.55 : 0.5);
      background();
      var F = sol.F, kind = st.beam.kind;
      lens(st.lens, st.f, A, 0, st.lens === 'concave' ? '凹透镜' : '凸透镜');
      foci(st.f, st.lens, st.show.labels, false);

      // 起点：点光源从光源出发，其余从左边缘射来
      var src = kind === 'point' ? [-st.beam.d, 0] : null;
      sol.rays.forEach(function (r) {
        var s0 = src || leftEnd(0, r.y, r.k);
        var e = rightEnd(0, r.y, r.ko);
        if (st.show.orig) {                                      // 不放透镜时光的传播方向
          var o = rightEnd(0, r.y, r.k);
          line(0, r.y, o[0], o[1], C.orig, 1.2, [3, 5]);
        }
        line(s0[0], s0[1], 0, r.y, C.beam, 1.8);
        arrowHead(s0[0], s0[1], 0, r.y, C.beam);
        line(0, r.y, e[0], e[1], C.beam, 1.8);
        var ax = Math.min(e[0], 28);
        arrowHead(0, r.y, ax, r.y + r.ko * ax, C.beam);
        if (st.show.ext && sol.P && sol.P.x < 0) line(0, r.y, sol.P.x, sol.P.y, C.virt, 1.1, [5, 5]);
        if (st.show.pulse) pulse([s0, [0, r.y], e], '#fff4c8', st.t);
      });

      // 光源 / 会聚点标记
      if (src) {
        ctx.beginPath(); ctx.arc(X(src[0]), Y(0), 7, 0, Math.PI * 2);
        ctx.fillStyle = '#fff3b0'; ctx.shadowColor = '#ffb347'; ctx.shadowBlur = 16; ctx.fill(); ctx.shadowBlur = 0;
        if (st.show.labels) text('点光源', X(src[0]), Y(0) + 20, C.text, 'center', 12);
      }
      if (kind === 'converge' && st.show.labels) {
        ctx.beginPath(); ctx.arc(X(st.beam.d), Y(0), 5, 0, Math.PI * 2);
        ctx.strokeStyle = C.orig; ctx.lineWidth = 1.5; ctx.setLineDash([2, 2]); ctx.stroke(); ctx.setLineDash([]);
        if (st.show.orig) text('原会聚点', X(st.beam.d), Y(0) + 20, C.muted, 'center', 12);
      }
      // 出射光（或其反向延长线）的交点
      if (sol.P && st.show.labels && sol.P.x > xl() && sol.P.x < xr()) {
        var virt = sol.P.x < 0;
        if (!virt || st.show.ext) {
          ctx.beginPath(); ctx.arc(X(sol.P.x), Y(sol.P.y), 4.5, 0, Math.PI * 2);
          ctx.fillStyle = virt ? C.virt : C.real; ctx.fill();
          var focal = kind === 'parallel', axial = focal && st.beam.ang === 0;
          // 标签放在光束下方，避免压住光线
          tag(axial ? (virt ? '反向延长线交于虚焦点 F' : '会聚于焦点 F′')
            : virt ? (focal ? '反向延长线交于焦平面上一点' : '反向延长线的交点') : (focal ? '会聚于焦平面上一点' : '实际光线的会聚点'),
            X(sol.P.x), Y(-A - 2), virt ? C.virt : C.real);
        }
      }
      endPane();
    }

    // ---------- 场景二：成像 ----------
    function drawImage(st, sols) {
      var cmp = !!sols.cvx;
      var hw = narrow ? 22 : 34, fx = narrow ? 0.62 : 0.56;   // 凹透镜的像都在 F 与 O 之间，画面比凸透镜放大一些
      if (!cmp) {
        imagePane('main', st, sols.ccv, 0, 0, W, H, hw, 15, fx, true);
      } else {
        var gap = 2, hh = (H - gap) / 2;
        imagePane('main', st, sols.ccv, 0, 0, W, hh, hw, 12, fx, true);
        imagePane('cvx', st, sols.cvx, 0, hh + gap, W, hh, hw, 12, fx, false);
        ctx.fillStyle = '#1b2333'; ctx.fillRect(0, hh, W, gap);
      }
    }

    function imagePane(name, st, s, x, y, w, h, hw, hv, fx, main) {
      var A = APERTURE.image, type = s.F < 0 ? 'concave' : 'convex', f = Math.abs(s.F);
      var u = s.u, hO = s.h, show = st.show, T = [-u, hO];
      pane(name, x, y, w, h, hw, hv, fx);
      background();
      if (st.cmp) text(type === 'concave' ? '凹透镜' : '凸透镜（焦距相同，作对比）', P.x + 14, P.y + P.h - (main ? 16 : 52), type === 'concave' ? C.lensEdge : C.muted, 'left', 13, '600');

      var hits = [Math.abs(hO)];
      if (show.rays) s.rays.forEach(function (r) { if (isFinite(r.y)) hits.push(Math.abs(r.y)); });
      lens(type, f, Math.min(A, hv - 2), Math.min(Math.max.apply(null, hits), 200), st.cmp ? '' : '凹透镜');
      foci(f, type, show.labels, type === 'convex');

      var I = s.none ? null : [s.v, s.hi];
      var imgOn = I && I[0] > xl() && I[0] < xr();

      // 人眼观察（仅凹透镜窗格）：进入瞳孔的光束
      if (main && show.eye && I) {
        var E = { x: st.eye.x, y: st.eye.y }, pr = 0.9;
        var ys = K.eyeCone({ x: I[0], y: I[1] }, E, pr);
        ctx.beginPath();
        ctx.moveTo(X(T[0]), Y(T[1])); ctx.lineTo(X(0), Y(ys[0])); ctx.lineTo(X(E.x), Y(E.y + pr));
        ctx.lineTo(X(E.x), Y(E.y - pr)); ctx.lineTo(X(0), Y(ys[1])); ctx.closePath();
        ctx.fillStyle = C.cone; ctx.fill();
        ys.forEach(function (yy, i) {
          line(T[0], T[1], 0, yy, 'rgba(255,209,102,0.75)', 1.2);
          line(0, yy, E.x, E.y + (i ? -pr : pr), 'rgba(255,209,102,0.75)', 1.2);
          line(0, yy, I[0], I[1], 'rgba(201,167,255,0.7)', 1, [4, 4]);
        });
      }

      if (show.fan && I) {
        for (var i = -5; i <= 5; i++) {
          var ly = i / 5 * A * 0.95, k = (ly - hO) / u, ko = K.refract(ly, k, s.F);
          var e = rightEnd(0, ly, ko);
          line(T[0], T[1], 0, ly, C.fan, 1);
          line(0, ly, e[0], e[1], C.fan, 1);
          if (!s.real) line(0, ly, I[0], I[1], 'rgba(201,167,255,0.18)', 1, [3, 4]);
        }
      }

      if (show.rays) {
        var cols = [C.r1, C.r2, C.r3];
        ctx.save();
        if (main && show.eye) ctx.globalAlpha = 0.35;              // 人眼观察时淡化特殊光线，突出进入眼睛的光束
        s.rays.forEach(function (r, j) {
          if (!isFinite(r.y)) return;
          var c = cols[j];
          // 凸透镜 u < f 时第三条光线"好像从 F 发出"：从 F 画虚线到物体顶端
          if (j === 2 && type === 'convex' && u < f) line(-f, 0, T[0], T[1], c, 1.2, [5, 5]);
          line(T[0], T[1], 0, r.y, c, 2);
          arrowHead(T[0], T[1], 0, r.y, c);
          var e = rightEnd(0, r.y, r.ko);
          line(0, r.y, e[0], e[1], c, 2);
          arrowHead(0, r.y, s.real ? I[0] : e[0], s.real ? I[1] : e[1], c);
          if (type === 'concave') {
            if (j === 0) line(0, r.y, -f, 0, c, 1.2, [5, 5]);       // 反向延长线过同侧虚焦点 F
            if (j === 2) line(0, r.y, f, 0, c, 1.2, [5, 5]);        // 原本射向异侧虚焦点 F′
          }
          if (I && !s.real) line(0, r.y, I[0], I[1], c, 1.2, [5, 5]);
        });
        ctx.restore();
      }

      // 物
      if (-u > xl() + 1) candle(X(-u), P.cy, hO * P.s, 'object');
      else tag('← 蜡烛在 u = ' + u.toFixed(0) + ' cm 处', P.x + 150, P.cy - 40, C.text);

      // 像
      if (s.none) {
        if (show.labels) tag('u = f：折射光平行，不成像', X(f * 2), Y(hO) - 24, C.muted);
      } else if (!imgOn) {
        tag((s.real ? '实像在右侧 ' : '虚像在左侧 ') + Math.abs(s.v).toFixed(0) + ' cm 处（画面外）' + (s.real ? ' →' : ''),
          s.real ? P.x + P.w - 150 : P.x + 150, P.cy + (s.real ? 46 : -54), s.real ? C.real : C.virt);
      } else {
        candle(X(I[0]), P.cy, I[1] * P.s, s.real ? 'real' : 'virtual');
        if (show.labels) {
          var ty = Y(I[1]) + (I[1] > 0 ? -18 : 20);
          tag(s.real ? '实像' : '虚像', X(I[0]), Math.max(P.y + 14, Math.min(P.y + P.h - 14, ty)), s.real ? C.real : C.virt);
        }
      }

      if (main && show.eye && I) {
        eye(X(st.eye.x), Y(st.eye.y), Math.max(1, Math.min(1.8, P.s / 10)));
        if (show.labels) text('眼睛看到缩小的像', X(st.eye.x) + 4, Y(st.eye.y) + 26, C.muted, 'center', 12);
      }

      // 物距、像距标注
      if (show.labels) {
        var base = Math.min(P.y + P.h - 22, P.cy + (s.real && imgOn ? Math.max(40, -I[1] * P.s + 30) : 40));
        dim(Math.max(-u, xl()), 0, base, 'u = ' + u.toFixed(1) + ' cm', C.text);
        if (imgOn) dim(Math.min(0, I[0]), Math.max(0, I[0]), base + 22 > P.y + P.h - 8 ? base : base + 22,
          (s.real ? 'v = ' : '|v| = ') + Math.abs(s.v).toFixed(1) + ' cm', s.real ? C.real : C.virt);
      }
      endPane();
    }

    function dim(x1, x2, py, label, color) {
      var a = X(x1), b = X(x2);
      if (b - a < 24) return;
      ctx.strokeStyle = color; ctx.globalAlpha = 0.6; ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(a, py); ctx.lineTo(b, py);
      ctx.moveTo(a, py - 4); ctx.lineTo(a, py + 4);
      ctx.moveTo(b, py - 4); ctx.lineTo(b, py + 4);
      ctx.stroke(); ctx.globalAlpha = 1;
      font(12);
      var w = ctx.measureText(label).width + 8;
      ctx.fillStyle = '#05070d'; ctx.fillRect((a + b) / 2 - w / 2, py - 8, w, 16);
      text(label, (a + b) / 2, py, color, 'center', 12);
    }

    // ---------- 场景三：判断方框里的透镜 ----------
    function drawQuiz(st) {
      var q = st.quiz, B = K.BOX, open = st.answered;
      pane('main', 0, 0, W, H - 110, narrow ? 24 : 40, 15, 0.5);     // 下方留给答题条
      background();
      var cols = [C.r1, C.r2];
      var src = isFinite(q.u) && q.u > 0 ? [-q.u, 0] : null;

      if (open) lens(q.type, q.f, B.h - 1, 0, '');
      q.rays.forEach(function (r, i) {
        var s0 = src || leftEnd(0, r.y, r.k), e = rightEnd(0, r.y, r.ko);
        if (open || st.show.orig) {
          var o = rightEnd(0, r.y, r.k);
          line(0, r.y, o[0], o[1], C.orig, 1.2, [3, 5]);
        }
        line(s0[0], s0[1], 0, r.y, cols[i], 2.2);
        arrowHead(s0[0], s0[1], -B.w, r.y - r.k * B.w, cols[i]);
        line(0, r.y, e[0], e[1], cols[i], 2.2);
        arrowHead(B.w, r.y + r.ko * B.w, e[0], e[1], cols[i]);
        if (open && q.v < 0 && isFinite(q.v)) line(0, r.y, q.v, 0, C.virt, 1.1, [5, 5]);
      });
      if (src) {
        ctx.beginPath(); ctx.arc(X(src[0]), Y(0), 6, 0, Math.PI * 2);
        ctx.fillStyle = '#fff3b0'; ctx.shadowColor = '#ffb347'; ctx.shadowBlur = 14; ctx.fill(); ctx.shadowBlur = 0;
      }

      // 方框：答题前不透明，答题后半透明露出透镜
      var bx = X(-B.w), by = Y(B.h), bw = 2 * B.w * P.s, bh = 2 * B.h * P.s;
      ctx.save();
      ctx.globalAlpha = open ? 0.22 : 1;
      ctx.fillStyle = C.box; ctx.fillRect(bx, by, bw, bh);
      ctx.restore();
      ctx.strokeStyle = C.boxEdge; ctx.lineWidth = 1.5; ctx.setLineDash(open ? [5, 4] : []);
      ctx.strokeRect(bx, by, bw, bh); ctx.setLineDash([]);
      if (!open) text('?', X(0), Y(0), C.muted, 'center', Math.max(28, bw * 0.35), '600');
      else text(q.type === 'concave' ? '凹透镜' : '凸透镜', X(0), by - 14, st.correct ? '#7ee081' : '#ff7a59', 'center', 14, '600');
      endPane();
    }

    // ---------- 主绘制 ----------
    function draw(st, sol) {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, W, H);
      panes = {};
      if (st.scene === 'light') drawLight(st, sol);
      else if (st.scene === 'image') drawImage(st, sol);
      else drawQuiz(st);
    }

    // ---------- 命中与坐标 ----------
    function use(name) { P = panes[name] || P; return P; }
    function toWorld(px, py, name) { use(name || 'main'); return { x: (px - P.cx) / P.s, y: (P.cy - py) / P.s }; }
    function inPane(name, py) { var p = panes[name]; return p && py >= p.y && py <= p.y + p.h; }

    function hit(px, py, st) {
      if (st.scene === 'image') {
        var names = ['main', 'cvx'];
        for (var i = 0; i < names.length; i++) {
          if (!inPane(names[i], py)) continue;
          use(names[i]);
          if (names[i] === 'main' && st.show.eye) {
            if (Math.hypot(px - X(st.eye.x) - 12, py - Y(st.eye.y)) < 26) return { what: 'eye', pane: 'main' };
          }
          var cx = X(-st.u), top = Y(st.h), half = Math.max(16, st.h * P.s * 0.18);
          if (Math.abs(px - cx) < half && py > top - 12 && py < P.cy + 10) return { what: 'obj', pane: names[i] };
        }
        return null;
      }
      if (st.scene === 'light' && st.beam.kind !== 'parallel') {
        use('main');
        var bx = st.beam.kind === 'point' ? -st.beam.d : st.beam.d;
        if (Math.abs(px - X(bx)) < 18 && Math.abs(py - P.cy) < 22) return { what: 'src', pane: 'main' };
      }
      return null;
    }

    return {
      resize: resize, draw: draw, hit: hit, toWorld: toWorld,
      xRange: function (name) {
        if (!panes[name || 'main']) return [-28, 28];        // 尚未绘制时给个保守范围
        use(name || 'main'); return [xl(), xr()];
      }
    };
  }

  window.LensDraw = LensDraw;
})();
