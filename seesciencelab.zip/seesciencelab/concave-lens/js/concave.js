// 凹透镜计算（纯函数，不碰 DOM）
// 约定与凸透镜模型一致：世界单位 cm，光心在原点，x 向右、y 向上，光从左向右传播。
// 带符号焦距 F：凸透镜 F = +f，凹透镜 F = −f（f 为焦距大小）。
// 物距 u > 0 为左侧实物（点光源）；u < 0 表示入射光会聚向右侧 |u| 处（虚物）；u = Infinity 为平行光。
// 像距 v > 0 实像（右侧，实际光线相交），v < 0 虚像（左侧，反向延长线相交）。
(function () {
  var O = window.Optics;

  function signedF(type, f) { return type === 'concave' ? -f : f; }

  // 1/u + 1/v = 1/F；复用 shared/optics.js，额外处理平行光和虚物
  function image(u, F) {
    if (!isFinite(u)) return { v: F, m: 0 };
    if (Math.abs(u - F) < 1e-9) return { v: Infinity, m: Infinity };
    return O.image(u, F);
  }

  // 薄透镜（近轴）折射：在高度 y 处入射、斜率 k = dy/dx 的光线，折射后斜率 k − y/F
  function refract(y, k, F) { return k - y / F; }

  // ---------- 场景一：对光的作用 ----------
  // beam：{ kind: 'parallel' | 'point' | 'converge', d: 点光源到光心 / 会聚点到光心的距离, ang: 平行光倾角（度，向下为正） }
  // 返回打在透镜上的若干条光线 { y, k, ko } 和"出射光的像点"
  function beamU(beam) {
    return beam.kind === 'parallel' ? Infinity : beam.kind === 'point' ? beam.d : -beam.d;
  }

  function traceBeam(type, f, beam, n, A) {
    var F = signedF(type, f), u = beamU(beam), rays = [];
    var kPar = -Math.tan(beam.ang * Math.PI / 180);
    for (var i = 0; i < n; i++) {
      var y = A * (2 * i / (n - 1) - 1);
      var k = beam.kind === 'parallel' ? kPar : y / u;    // 点光源 (−u,0) → (0,y)；会聚光指向 (|u|,0)
      rays.push({ y: y, k: k, ko: refract(y, k, F) });
    }
    var im = image(u, F);
    // 平行光斜射时，出射光（或反向延长线）交于焦平面 x = F 上的一点
    var P = beam.kind === 'parallel' ? { x: F, y: kPar * F } : isFinite(im.v) ? { x: im.v, y: 0 } : null;
    return { F: F, u: u, v: im.v, rays: rays, P: P, out: describe(im.v), inn: describeIn(beam) };
  }

  // 一束光的"形态"：会聚到右侧某点 / 平行 / 从左侧某点发散
  function describe(v) {
    if (!isFinite(v)) return { key: 'parallel', text: '平行光' };
    if (v > 0) return { key: 'converge', text: '会聚光（实际光线交于右侧 ' + v.toFixed(1) + ' cm 处）' };
    return { key: 'diverge', text: '发散光（反向延长线交于左侧 ' + (-v).toFixed(1) + ' cm 处）' };
  }
  function describeIn(beam) {
    if (beam.kind === 'parallel') return { key: 'parallel', text: beam.ang ? '平行光（斜射 ' + beam.ang.toFixed(0) + '°）' : '平行于主光轴的平行光' };
    if (beam.kind === 'point') return { key: 'diverge', text: '发散光（点光源在左侧 ' + beam.d.toFixed(1) + ' cm）' };
    return { key: 'converge', text: '会聚光（射向右侧 ' + beam.d.toFixed(1) + ' cm 处）' };
  }

  // ---------- 场景二：成像 ----------
  // 物体高 h、物距 u，透镜带符号焦距 F
  function solveImage(u, h, F) {
    var im = image(u, F), v = im.v, none = !isFinite(v);
    var hi = none ? Infinity : im.m * h;
    // 三条特殊光线：①平行于主光轴 ②过光心 ③入射线过 (−F, 0)（凸透镜：过物方焦点；凹透镜：射向异侧虚焦点 F′）
    var y3 = Math.abs(u - F) < 1e-9 ? NaN : -h * F / (u - F);
    var rays = [
      { y: h, k: 0 },
      { y: 0, k: -h / u },
      { y: y3, k: -h / (u - F) }
    ].map(function (r) { r.ko = refract(r.y, r.k, F); return r; });
    return { u: u, h: h, F: F, v: v, m: im.m, hi: hi, real: !none && v > 0, none: none, rays: rays, nature: nature(F, u, im) };
  }

  function nature(F, u, im) {
    if (!isFinite(im.v)) return { text: '不成像', size: '', up: '', real: '' };
    var am = Math.abs(im.m);
    var size = am > 1.005 ? '放大' : am < 0.995 ? '缩小' : '等大';
    var up = im.m > 0 ? '正立' : '倒立', real = im.v > 0 ? '实像' : '虚像';
    return { text: up + ' · ' + size + ' · ' + real, size: size, up: up, real: real };
  }

  // 人眼在 E 处透过透镜看物体顶端 T：进入瞳孔（半径 r）的两条边缘光线在透镜上的高度
  // 薄透镜下，折射光（或其反向延长线）都过像点 I，所以透镜上的点就是"像点—瞳孔边缘"连线与 x = 0 的交点
  function eyeCone(I, E, r) {
    function at0(P, Q) { return P.y + (Q.y - P.y) * (0 - P.x) / (Q.x - P.x); }
    return [at0(I, { x: E.x, y: E.y + r }), at0(I, { x: E.x, y: E.y - r })];
  }

  // ---------- 场景三：判断方框里的透镜 ----------
  // 每道题两条光线（红、蓝）从左边射入方框、从右边射出；方框半宽 BOX.w、半高 BOX.h。
  // u 同 beamU 的含义，a 为光线打在透镜上的高度。
  var BOX = { w: 6, h: 12 };
  var TEMPLATES = [
    { id: 'par-cvx', type: 'convex', u: function () { return Infinity; }, f: [14, 26], tip: '平行光经过后变成会聚光。' },
    { id: 'par-ccv', type: 'concave', u: function () { return Infinity; }, f: [10, 22], tip: '平行光经过后变得发散。' },
    { id: 'pt-F-cvx', type: 'convex', u: function (f) { return f; }, f: [12, 20], tip: '发散光经过后变成平行光：光源在凸透镜的焦点上。' },
    { id: 'cv-F-ccv', type: 'concave', u: function (f) { return -f; }, f: [12, 20], tip: '会聚光经过后变成平行光：入射光射向凹透镜另一侧的虚焦点。' },
    { id: 'pt-in-cvx', type: 'convex', u: function (f) { return f * 0.55; }, f: [18, 26], tip: '出射光虽然仍是发散的，但比原来的传播方向更靠拢主光轴——发散程度变小了，这是会聚作用。' },
    { id: 'cv-far-ccv', type: 'concave', u: function (f) { return -f * 0.55; }, f: [18, 26], tip: '出射光虽然仍会聚，但比原来的传播方向更偏离主光轴，会聚点变远了——这是发散作用。' },
    { id: 'cv-near-cvx', type: 'convex', u: function (f) { return -f * 1.3; }, f: [12, 18], tip: '会聚光经过后会聚得更厉害，交点提前了。' },
    { id: 'cross-cvx', type: 'convex', u: function () { return Infinity; }, f: [3.2, 4.4], tip: '注意颜色：上面射入的光从下面射出，说明两条光线在方框里已经相交——是会聚光。' },
    { id: 'pt-ccv', type: 'concave', u: function (f) { return f * 0.9; }, f: [10, 16], tip: '发散光经过后发散得更厉害。' },
    { id: 'cv-ccv', type: 'concave', u: function (f) { return -f * 1.6; }, f: [8, 12], tip: '原来的会聚光经过后变成了发散光。' }
  ];

  function quiz(rand, lastId) {
    rand = rand || Math.random;
    var t;
    do { t = TEMPLATES[Math.floor(rand() * TEMPLATES.length)]; } while (t.id === lastId && TEMPLATES.length > 1);
    var f = t.f[0] + rand() * (t.f[1] - t.f[0]);
    f = Math.round(f * 2) / 2;
    var q = { id: t.id, type: t.type, f: f, u: t.u(f), tip: t.tip };
    q.F = signedF(t.type, f);
    // 光线打在透镜上的高度 ±a：4–8 cm，并保证光线从方框左右两边进出（不从上下边穿出）
    var k1 = isFinite(q.u) ? 1 / q.u : 0, grow = Math.max(Math.abs(1 - k1 * BOX.w), Math.abs(1 + refract(1, k1, q.F) * BOX.w));
    var a = Math.min(4 + Math.round(rand() * 4), Math.floor((BOX.h - 1.5) / grow * 2) / 2);
    q.a = a;
    q.rays = [a, -a].map(function (y) {
      var k = isFinite(q.u) ? y / q.u : 0;
      return { y: y, k: k, ko: refract(y, k, q.F) };
    });
    q.v = image(q.u, q.F).v;
    q.cross = q.v > 0 && q.v < BOX.w;                          // 两条光线在方框内相交，出射时上下对调
    return q;
  }

  // 解释：比较出射光与"原来的传播方向"
  function explain(q) {
    var dk = q.rays[0].ko - q.rays[0].k;                      // 上面那条光线（y > 0）的偏折
    var toward = dk < 0;                                      // 斜率变小 = 向主光轴偏折
    return (toward ? '和原来的传播方向（虚线）相比，出射光向主光轴偏折，透镜对光起会聚作用，是凸透镜。'
      : '和原来的传播方向（虚线）相比，出射光偏离主光轴，透镜对光起发散作用，是凹透镜。') + q.tip;
  }

  window.Concave = {
    signedF: signedF, image: image, refract: refract,
    beamU: beamU, traceBeam: traceBeam, describe: describe,
    solveImage: solveImage, nature: nature, eyeCone: eyeCone,
    BOX: BOX, TEMPLATES: TEMPLATES, quiz: quiz, explain: explain
  };
})();
