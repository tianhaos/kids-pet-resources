(function () {
  var M = window.Moon, D = window.MoonDraw;
  var $ = function (id) { return document.getElementById(id); };
  var qa = function (sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); };

  var SPEEDS = {
    orbit: [{ v: 0.5, t: '0.5 天/秒' }, { v: 2, t: '2 天/秒' }, { v: 5, t: '5 天/秒' }],
    sky: [{ v: 0.5, t: '0.5 小时/秒' }, { v: 2, t: '2 小时/秒' }, { v: 6, t: '6 小时/秒' }]
  };

  var state = {
    scene: 'orbit',
    age: M.ageOf(90),      // 月龄（天）
    t: 18,                 // 地方时（小时）
    play: false, speed: 1,
    south: false,
    spin: 0,
    show: { rays: true, minis: true, halves: true, sight: true, labels: true, path: true, widgets: true },
    quiz: null, answered: false, correct: false, choice: null, score: { n: 0, ok: 0 }
  };

  var HINTS = {
    orbit: '拖动月球绕地球公转 · 拖动空白处旋转视角',
    sky: '面向南方的天空 · 拖动时刻滑块看月亮东升西落',
    quiz: '北半球观察，面向南方'
  };

  // 各月相的成因说明（{R}{L}：北半球的右 / 左，南半球互换）
  var TIPS = [
    '月球在日、地之间，被照亮的半球背对地球，看不见月亮（新月，也叫“朔”）。',
    '朝向地球的半个月球只有一小部分被照亮，看到弯弯的一道亮边，亮面朝西（{R}）。',
    '日、地、月成直角，朝向地球的半个月球正好一半被照亮：西（{R}）半边亮的上弦月。',
    '朝向地球的部分大半被照亮，亮面朝西（{R}），一天天变圆。',
    '地球在日、月之间，被照亮的半球整个朝向地球：满月（望）。',
    '过了满月，西侧开始变暗，亮面在东侧（{L}），一天天变瘦。',
    '日、地、月再次成直角，看到东（{L}）半边亮的下弦月。',
    '只剩东侧（{L}）一道弯弯的亮边，月球快要回到日、地之间了。'
  ];

  var stage = $('stage'), panel = $('panel'), skyCanvas = $('sky');
  var view = D.View(skyCanvas);
  var S3, has3d = true;
  try {
    S3 = window.MoonScene(stage, {
      onDrag: function (l) { setPlay(false); state.age = M.ageOf(l); },
      onDragStart: function () { Analytics.track('月相', '拖动月球'); },
      onPick: function (i) { jumpPhase(i); }
    });
  } catch (err) {
    // 不支持 WebGL：3D 场景不可用，另两个 2D 场景照常
    has3d = false;
    var nop = function () {};
    S3 = { update: nop, resize: nop, setView: nop, render: nop, setVisible: nop, view: function () { return 'tilt'; } };
    var ob = document.querySelector('[data-scene="orbit"]');
    ob.disabled = true;
    ob.title = '此浏览器不支持 WebGL，3D 场景无法显示';
  }

  function lambda() { return M.lambdaOf(state.age); }
  function setSeg(attr, val) { qa('[data-' + attr + ']').forEach(function (b) { b.classList.toggle('on', b.dataset[attr] === String(val)); }); }

  // ---------- 场景 ----------
  qa('[data-scene]').forEach(function (b) {
    b.addEventListener('click', function () { setScene(b.dataset.scene); Analytics.track('月相', '场景', b.textContent); });
  });
  function setScene(sc) {
    state.scene = sc;
    setPlay(false);
    if (sc === 'quiz' && !state.quiz) newQuiz();
    $('rName').className = '';
    S3.setVisible(sc === 'orbit');
    skyCanvas.style.display = sc === 'orbit' ? 'none' : '';
    syncUI();
  }

  // ---------- 农历日期 ----------
  var ageEl = $('age');
  ageEl.addEventListener('input', function () { setPlay(false); state.age = parseFloat(ageEl.value); });
  var phaseBox = $('phaseBtns');
  M.PHASES.forEach(function (p, i) {
    var b = document.createElement('button');
    b.dataset.ph = i;
    b.innerHTML = '<b>' + p.name + '</b><small>' + p.day + '</small>';
    b.addEventListener('click', function () { jumpPhase(i); });
    phaseBox.appendChild(b);
  });
  function jumpPhase(i) {
    setPlay(false);
    state.age = M.ageOf(M.PHASES[i].lambda);
    Analytics.track('月相', '选月相', M.PHASES[i].name);
  }

  function setPlay(on) {
    state.play = on;
    $('playBtn').textContent = on ? '❚❚ 暂停' : '▶ 播放';
    $('playBtn').classList.toggle('on', on);
  }
  $('playBtn').addEventListener('click', function () { setPlay(!state.play); if (state.play) Analytics.track('月相', '播放', state.scene); });
  qa('[data-speed]').forEach(function (b) {
    b.addEventListener('click', function () { state.speed = +b.dataset.speed; syncUI(); });
  });

  // ---------- 观察时刻 ----------
  var clockEl = $('clock');
  clockEl.addEventListener('input', function () { setPlay(false); state.t = parseFloat(clockEl.value) % 24; });
  qa('[data-t]').forEach(function (b) {
    b.addEventListener('click', function () { setPlay(false); state.t = +b.dataset.t; Analytics.track('月相', '时刻', b.textContent); });
  });

  // ---------- 显示 ----------
  [['showRays', 'rays'], ['showMinis', 'minis'], ['showHalves', 'halves'], ['showSight', 'sight'], ['showLabels', 'labels'],
   ['showPath', 'path'], ['showWidgets', 'widgets']].forEach(function (p) {
    $(p[0]).addEventListener('change', function () { state.show[p[1]] = $(p[0]).checked; });
  });
  qa('[data-hemi]').forEach(function (b) {
    b.addEventListener('click', function () {
      state.south = b.dataset.hemi === 's';
      syncUI();
      Analytics.track('月相', '观察者', state.south ? '南半球' : '北半球');
    });
  });
  qa('[data-view]').forEach(function (b) {
    b.addEventListener('click', function () { S3.setView(b.dataset.view); syncUI(); Analytics.track('月相', '视角', b.textContent); });
  });
  $('resetView').addEventListener('click', function () { S3.setView(S3.view()); });

  // ---------- 练习 ----------
  function newQuiz() {
    state.quiz = M.quiz(Math.random, state.quiz && state.quiz.id);
    state.answered = false; state.choice = null;
    var box = $('quizOpts');
    box.innerHTML = '';
    state.quiz.options.forEach(function (o) {
      var b = document.createElement('button');
      b.className = 'small';
      b.textContent = o;
      b.addEventListener('click', function () { answer(o); });
      box.appendChild(b);
    });
    syncUI();
  }
  function answer(o) {
    if (state.answered) return;
    state.answered = true;
    state.choice = o;
    state.correct = o === state.quiz.answer;
    state.score.n++; if (state.correct) state.score.ok++;
    Analytics.track('月相', '练习', state.quiz.type + (state.correct ? ' 对' : ' 错'));
    syncUI();
  }
  $('nextQ').addEventListener('click', newQuiz);
  $('showQ').addEventListener('click', function () {
    var q = state.quiz;
    state.age = M.ageOf(q.lambda);
    if (q.t != null) { state.t = q.t; setScene('sky'); } else setScene('orbit');
  });

  // ---------- 面板 ----------
  $('panelToggle').addEventListener('click', function () { panel.classList.toggle('collapsed'); });
  if (window.matchMedia('(max-width: 760px)').matches) panel.classList.add('collapsed');
  window.addEventListener('keydown', function (e) {
    var tg = e.target.tagName;
    if (tg === 'INPUT' || tg === 'SELECT' || tg === 'BUTTON' || tg === 'TEXTAREA') return;
    if (e.code === 'Space' && state.scene !== 'quiz') { e.preventDefault(); setPlay(!state.play); }
  });

  function syncUI() {
    var sc = state.scene;
    setSeg('scene', sc);
    qa('[data-for]').forEach(function (el) { el.hidden = el.dataset.for.split(' ').indexOf(sc) < 0; });
    $('hint').textContent = HINTS[sc];
    setSeg('speed', state.speed);
    if (SPEEDS[sc]) $('speedNote').textContent = SPEEDS[sc][state.speed].t;
    setSeg('hemi', state.south ? 's' : 'n');
    setSeg('view', S3.view());
    [['showRays', 'rays'], ['showMinis', 'minis'], ['showHalves', 'halves'], ['showSight', 'sight'], ['showLabels', 'labels'],
     ['showPath', 'path'], ['showWidgets', 'widgets']].forEach(function (p) { $(p[0]).checked = state.show[p[1]]; });
    var q = state.quiz;
    if (q) {
      $('quizQ').textContent = q.prompt;
      qa('#quizOpts button').forEach(function (b) {
        b.disabled = state.answered;
        b.classList.toggle('on', state.answered && b.textContent === q.answer);
        b.classList.toggle('no', state.answered && b.textContent === state.choice && !state.correct);
      });
      $('quizMsg').innerHTML = !state.answered ? ''
        : '<b class="' + (state.correct ? 'ok">✓ 答对了' : 'bad">✗ 应选「' + q.answer + '」') + '</b>' + q.explain;
      $('nextQ').textContent = state.answered ? '下一题 →' : '换一题';
      $('showQ').hidden = !state.answered;
    }
  }

  // ---------- 读数 ----------
  var last = {};
  function setText(id, s) { if (last[id] !== s) { last[id] = s; $(id).textContent = s; } }
  function rows(list) {
    for (var k = 1; k <= 5; k++) {
      var r = list[k - 1] || ['', ''];
      setText('d' + k, r[0]); setText('r' + k, r[1]);
      $('d' + k).hidden = $('r' + k).hidden = !r[0];
    }
  }
  function dayText() { return '农历' + M.lunarName(M.lunarDay(state.age)); }
  function riseText(l) {
    var r = M.riseSet(l);
    return '月出 ' + M.fmtClock(r.rise) + ' · 中天 ' + M.fmtClock(r.transit) + ' · 月落 ' + M.fmtClock(r.set);
  }

  function readOrbit() {
    var l = lambda(), i = M.phaseIndex(state.age), p = M.PHASES[i];
    setText('rName', M.phaseLabel(p));
    setText('rKind', dayText());
    var tip = TIPS[i].replace(/\{R\}/g, state.south ? '左' : '右').replace(/\{L\}/g, state.south ? '右' : '左');
    setText('rTip', tip);
    var elong = l <= 180 ? '月球在太阳以东 ' + l.toFixed(0) + '°' : '月球在太阳以西 ' + (360 - l).toFixed(0) + '°';
    rows([
      ['月龄', state.age.toFixed(1) + ' 天（周期 29.53 天）'],
      ['日月位置', elong],
      ['亮面比例', (M.illum(l) * 100).toFixed(0) + '%'],
      ['亮面朝向', M.brightSide(l, state.south)],
      ['出没时刻', riseText(l)]
    ]);
    setText('insetDay', dayText());
    setText('insetFoot', (state.south ? '南半球 · 面向北方' : '北半球 · 面向南方') + ' · ' + p.name);
  }

  function readSky() {
    var l = lambda(), s = M.sky(state.t, l), p = M.phaseOf(state.age), m = s.moon;
    var up = m.alt > 0;
    setText('rName', up ? '月亮在' + M.dirName(m.az) + '天空' : '月亮在地平线以下');
    setText('rKind', dayText());
    setText('rTip', M.phaseLabel(p) + '：' + p.see + '。');
    rows([
      ['时刻', M.fmtClock(state.t) + '（' + M.timeWord(state.t) + '）'],
      ['太阳', s.sun.alt > 0 ? M.dirName(s.sun.az) + '，高度 ' + s.sun.alt.toFixed(0) + '°' : '在地平线以下'],
      ['月亮', up ? M.dirName(m.az) + '，高度 ' + m.alt.toFixed(0) + '°' : '在地平线以下，看不见'],
      ['亮面朝向', M.brightSide(l)],
      ['出没时刻', riseText(l)]
    ]);
  }

  function readQuiz() {
    var q = state.quiz, sc = state.score;
    setText('rName', !state.answered ? '判断月相' : state.correct ? '✓ 答对了' : '✗ 答错了');
    $('rName').className = !state.answered ? '' : state.correct ? 'ok' : 'bad';
    setText('rKind', '得分 ' + sc.ok + ' / ' + sc.n);
    setText('rTip', state.answered ? q.explain : q.prompt);
    rows(state.answered ? [
      ['月相', M.phaseLabel(q.phase) + '（农历' + q.phase.day + '）'],
      ['亮面', M.brightSide(q.lambda)],
      ['出没时刻', riseText(q.lambda)]
    ] : []);
  }

  // ---------- 尺寸与主循环 ----------
  function resize() {
    var w = stage.clientWidth, h = stage.clientHeight;
    view.resize(w, h);
    S3.resize(w, h);
  }
  new ResizeObserver(resize).observe(stage);

  // 支持 ?scene=orbit|sky|quiz、&day=1~30（农历）或 &age=0~29.5、&t=0~24、&view=top、&south=1
  var qs = new URLSearchParams(location.search);
  if (HINTS[qs.get('scene')]) state.scene = qs.get('scene');
  if (!has3d && state.scene === 'orbit') state.scene = 'sky';
  var dq = parseInt(qs.get('day'), 10), aq = parseFloat(qs.get('age')), tq = parseFloat(qs.get('t'));
  if (dq >= 1 && dq <= 30) state.age = dq - 0.5;
  if (aq >= 0 && aq < M.SYNODIC) state.age = aq;
  if (tq >= 0 && tq <= 24) state.t = tq % 24;
  if (qs.get('south') === '1') state.south = true;

  resize();
  S3.setView(qs.get('view') === 'top' ? 'top' : 'tilt');
  setScene(state.scene);

  var insetCanvas = $('insetCanvas');
  var lastT = performance.now();
  function frame(now) {
    var dt = Math.min((now - lastT) / 1000, 0.1);
    lastT = now;
    var sc = state.scene;
    if (state.play && SPEEDS[sc]) {
      var v = SPEEDS[sc][state.speed].v * dt;
      if (sc === 'orbit') state.age = M.wrapAge(state.age + v);
      else {
        state.t += v;
        state.age = M.wrapAge(state.age + v / 24);
        if (state.t >= 24) state.t -= 24;
      }
    }
    state.spin += dt * 0.25;
    if (document.activeElement !== ageEl) ageEl.value = state.age;
    if (document.activeElement !== clockEl) clockEl.value = state.t;
    setText('ageOut', M.lunarName(M.lunarDay(state.age)) + ' · ' + state.age.toFixed(1) + ' 天');
    setText('clockOut', M.fmtClock(state.t));
    var pi = M.phaseIndex(state.age);
    qa('[data-ph]').forEach(function (b) { b.classList.toggle('on', +b.dataset.ph === pi); });

    var l = lambda();
    if (sc === 'orbit') {
      S3.update({ lambda: l, spin: state.spin, show: state.show });
      S3.render();
      D.inset(insetCanvas, l, state.south);
      readOrbit();
    } else if (sc === 'sky') {
      view.drawSky({ t: state.t, lambda: l, path: state.show.path, widgets: state.show.widgets, labels: true, clock: true });
      readSky();
    } else {
      view.drawQuiz(state.quiz, state.answered);
      readQuiz();
    }
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // 调试用
  window.__model = {
    state: state, setScene: setScene, newQuiz: newQuiz, jumpPhase: jumpPhase, syncUI: syncUI,
    setAge: function (a) { state.age = M.wrapAge(a); }, setTime: function (t) { state.t = ((t % 24) + 24) % 24; }
  };
})();
