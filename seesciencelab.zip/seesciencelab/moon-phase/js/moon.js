// 纯计算：月龄 ⇄ 日月夹角、月相名称、农历日期、月出月落、地面上看到的日月位置、练习题（不碰 DOM）
// 约定：λ 为“日月角距”（从地球看，月球在太阳以东的角度，0° 朔 → 180° 望 → 360°），月龄 age 单位天
// 地面观察按春分/秋分前后、北纬 35° 简化：太阳 6 时升 18 时落，月球与太阳走同一条路径（不计月球赤纬变化）
(function () {
  var DEG = Math.PI / 180;
  var SYNODIC = 29.53;   // 朔望月（天）
  var SIDEREAL = 27.32;  // 恒星月（天）
  var LAT = 35;          // 地面观察的纬度（°N）

  var CN_NUM = ['', '一', '二', '三', '四', '五', '六', '七', '八', '九', '十'];

  // 八个典型月相：λ 为该月相的中心角，day 为教材常写的农历日期
  var PHASES = [
    { key: 'new', name: '新月', alias: '朔', lambda: 0, day: '初一', see: '与太阳同升同落，亮面背对地球，看不见' },
    { key: 'crescent', name: '娥眉月', lambda: 40, day: '初三、初四', see: '黄昏时在西方低空，日落后不久也落下' },
    { key: 'first', name: '上弦月', lambda: 90, day: '初七、初八', see: '上半夜可见，黄昏时在南方天空' },
    { key: 'waxgib', name: '凸月', lambda: 135, day: '初十至十三', see: '下午升起，前半夜到后半夜可见，逐渐变圆', waxing: true },
    { key: 'full', name: '满月', alias: '望', lambda: 180, day: '十五、十六', see: '日落时从东方升起，通宵可见，午夜在正南' },
    { key: 'wangib', name: '凸月', lambda: 225, day: '十七至二十', see: '天黑后升起，后半夜到上午可见，逐渐变瘦', waxing: false },
    { key: 'last', name: '下弦月', lambda: 270, day: '廿二、廿三', see: '下半夜可见，清晨时在南方天空' },
    { key: 'waning', name: '残月', lambda: 320, day: '廿六、廿七', see: '黎明前在东方低空，日出后看不清' }
  ];

  function wrap360(a) { return ((a % 360) + 360) % 360; }
  function wrapAge(a) { return ((a % SYNODIC) + SYNODIC) % SYNODIC; }
  function lambdaOf(age) { return wrap360(age / SYNODIC * 360); }
  function ageOf(lambda) { return wrap360(lambda) / 360 * SYNODIC; }

  // 农历第几天（1–30）：朔所在的那天为初一
  function lunarDay(age) { return Math.min(30, Math.floor(wrapAge(age)) + 1); }
  function lunarName(d) {
    if (d <= 10) return '初' + CN_NUM[d];
    if (d < 20) return '十' + CN_NUM[d - 10];
    if (d === 20) return '二十';
    if (d < 30) return '廿' + CN_NUM[d - 20];
    return '三十';
  }

  // 按农历日期归类（与教材一致）：初一新月、初二至初六娥眉月、初七八上弦、初九至十四凸月、
  // 十五十六满月、十七至廿一凸月、廿二三下弦、廿四至廿九残月、三十（月末）又接近新月
  function phaseIndex(age) {
    var d = lunarDay(age);
    if (d === 1 || d === 30) return 0;
    if (d <= 6) return 1;
    if (d <= 8) return 2;
    if (d <= 14) return 3;
    if (d <= 16) return 4;
    if (d <= 21) return 5;
    if (d <= 23) return 6;
    return 7;
  }
  function phaseOf(age) { return PHASES[phaseIndex(age)]; }
  function phaseLabel(p) {
    return p.name + (p.waxing === true ? '（渐盈）' : p.waxing === false ? '（渐亏）' : '');
  }

  // 被照亮部分占月面（圆面）的比例
  function illum(lambda) { return (1 - Math.cos(lambda * DEG)) / 2; }
  function waxing(lambda) { var l = wrap360(lambda); return l > 0 && l < 180; }

  // 北半球面向南方看：上半月（渐盈）右侧 = 西侧亮，下半月（渐亏）左侧 = 东侧亮；南半球左右相反
  function brightSide(lambda, south) {
    var l = wrap360(lambda), k = illum(l);
    if (k < 0.015) return '看不见亮面';          // 与按农历归类一致：初一、三十为新月，十五、十六为满月
    if (k > 0.985) return '整个圆面都亮';
    var west = l < 180;
    var how = k < 0.42 ? '侧一弯亮' : k > 0.58 ? '侧大半亮' : '半边亮';
    return (west ? '西' : '东') + how + '（' + ((west !== !!south) ? '右' : '左') + '侧）';
  }

  // 月出、上中天、月落的地方时（小时）：太阳 6 时升 12 时中天 18 时落，月球每天晚约 50 分钟
  function riseSet(lambda) {
    var d = wrap360(lambda) / 15;
    return { rise: (6 + d) % 24, transit: (12 + d) % 24, set: (18 + d) % 24 };
  }

  // 时角 H（°，西为正）→ 高度角 alt 与方位角 az（°，正南为 0，西为正），赤纬取 0
  function horiz(H, lat) {
    lat = lat == null ? LAT : lat;
    var h = H * DEG, p = lat * DEG;
    var up = Math.cos(p) * Math.cos(h), south = Math.sin(p) * Math.cos(h), west = Math.sin(h);
    return { alt: Math.asin(up) / DEG, az: Math.atan2(west, south) / DEG, H: wrap360(H + 180) - 180 };
  }

  // t 时（地方时，小时）的太阳和月亮
  function sky(t, lambda, lat) {
    var Hs = (t - 12) * 15;
    return { sun: horiz(Hs, lat), moon: horiz(Hs - lambda, lat) };
  }

  function dirName(az) {
    if (az < -67.5) return '东方';
    if (az < -22.5) return '东南方';
    if (az <= 22.5) return '南方';
    if (az <= 67.5) return '西南方';
    return '西方';
  }

  // 月亮在天空中的时段（月出到月落）里，有多少是夜晚（18 时—次日 6 时）
  function nightHours(lambda) {
    var r = riseSet(lambda), n = 0;
    for (var i = 0; i < 240; i++) {
      var t = (r.rise + i * 0.05) % 24;
      if (t >= 18 || t < 6) n += 0.05;
    }
    return n;
  }

  function fmtClock(h) {
    h = ((h % 24) + 24) % 24;
    var m = Math.round(h * 60) % 1440;
    var hh = Math.floor(m / 60), mm = m % 60;
    return (hh < 10 ? '0' : '') + hh + ':' + (mm < 10 ? '0' : '') + mm;
  }
  function timeWord(t) {
    t = ((t % 24) + 24) % 24;
    if (t < 1 || t >= 23) return '午夜';
    if (t < 5) return '后半夜';
    if (t < 7) return '清晨';
    if (t < 11) return '上午';
    if (t < 13) return '正午';
    if (t < 17) return '下午';
    if (t < 19) return '傍晚';
    return '前半夜';
  }

  // ---------- 练习题 ----------
  // type: name 看图说月相、date 看图说农历、sky 看天空判断农历、where 已知农历和时刻判断方位
  var DATE_OPTS = PHASES.map(function (p) { return p.day; });
  var WHEN = [{ t: 18, w: '傍晚（18 时前后）' }, { t: 0, w: '午夜（0 时前后）' }, { t: 6, w: '清晨（6 时前后）' }];

  function pick(rng, arr) { return arr[Math.floor(rng() * arr.length)]; }
  function shuffle(rng, arr) {
    for (var i = arr.length - 1; i > 0; i--) { var j = Math.floor(rng() * (i + 1)), t = arr[i]; arr[i] = arr[j]; arr[j] = t; }
    return arr;
  }
  // 正确答案 + 从候选里挑 3 个不同的干扰项，打乱顺序
  function options(rng, answer, pool) {
    var others = shuffle(rng, pool.filter(function (x) { return x !== answer; })).slice(0, 3);
    return shuffle(rng, others.concat([answer]));
  }

  function whereAnswer(lambda, t) {
    var m = sky(t, lambda).moon;
    if (m.alt < 0) return '看不到（在地平线以下）';
    return m.az < -22.5 ? '东方天空' : m.az > 22.5 ? '西方天空' : '南方天空';
  }

  function quiz(rng, prevId) {
    rng = rng || Math.random;
    var q, tries = 0;
    do {
      var type = pick(rng, ['name', 'date', 'sky', 'sky', 'where', 'where']);
      var idx = 1 + Math.floor(rng() * 7);            // 不出新月（看不见）
      var p = PHASES[idx], lambda = p.lambda + (idx === 4 ? 0 : (rng() - 0.5) * 10);
      q = { type: type, phase: p, lambda: lambda, id: type + idx };
      if (type === 'name') {
        q.prompt = '这是北半球看到的月亮，它是什么月相？';
        q.answer = phaseLabel(p);
        q.options = options(rng, q.answer, PHASES.slice(1).map(phaseLabel));
      } else if (type === 'date') {
        q.prompt = '北半球看到这样的月亮，大约是农历哪几天？';
        q.answer = p.day;
        q.options = options(rng, q.answer, DATE_OPTS.slice(1));
      } else if (type === 'sky') {
        // 选一个月亮在地平线以上、且天色较暗的时刻
        var cands = [18, 20, 22, 0, 2, 4, 6].filter(function (t) {
          var s = sky(t, lambda); return s.moon.alt > 12;
        });
        if (!cands.length) { q = null; continue; }
        q.t = pick(rng, cands);
        q.id += '@' + q.t;
        q.prompt = timeWord(q.t) + ' ' + fmtClock(q.t) + '，面向南方看到这样的月亮，大约是农历哪几天？';
        q.answer = p.day;
        q.options = options(rng, q.answer, DATE_OPTS.slice(1));
      } else {
        q.lambda = p.lambda;
        var w = pick(rng, WHEN);
        if (Math.abs(sky(w.t, q.lambda).moon.alt) < 8) { q = null; continue; }   // 正在升起或落下，方位有歧义
        q.t = w.t;
        q.id += '@' + q.t;
        q.prompt = '农历' + p.day + '的' + w.w + '，在北半球能在哪里看到月亮？';
        q.answer = whereAnswer(q.lambda, q.t);
        q.options = ['东方天空', '南方天空', '西方天空', '看不到（在地平线以下）'];
      }
    } while ((!q || q.id === prevId) && ++tries < 20);
    if (!q) return quiz(rng, null);
    q.explain = explain(q);
    return q;
  }

  function explain(q) {
    var p = q.phase, r = riseSet(q.lambda);
    var base = p.name + '（农历' + p.day + '）：' + brightSide(q.lambda) + '，' + p.see + '。';
    if (q.type === 'where') {
      return base + '它大约 ' + fmtClock(r.rise) + ' 从东方升起、' + fmtClock(r.transit) + ' 到正南、' + fmtClock(r.set) + ' 在西方落下。';
    }
    if (q.type === 'sky') return base + '记口诀：上上上西西（上弦月、上半月、上半夜、西边天空、西半边亮），下下下东东。';
    return base;
  }

  window.Moon = {
    DEG: DEG, SYNODIC: SYNODIC, SIDEREAL: SIDEREAL, LAT: LAT,
    PHASES: PHASES,
    wrap360: wrap360, wrapAge: wrapAge,
    lambdaOf: lambdaOf, ageOf: ageOf,
    lunarDay: lunarDay, lunarName: lunarName,
    phaseIndex: phaseIndex, phaseOf: phaseOf, phaseLabel: phaseLabel,
    illum: illum, waxing: waxing, brightSide: brightSide,
    riseSet: riseSet, horiz: horiz, sky: sky, dirName: dirName, nightHours: nightHours,
    fmtClock: fmtClock, timeWord: timeWord,
    quiz: quiz, whereAnswer: whereAnswer
  };
})();
