// 3D 场景：太阳光（+x 方向射来的平行光）、地球、月球轨道与八个典型位置；月球被照亮的半球与朝向地球的半球
// 坐标：y 轴指向北极，从北极上空看月球逆时针公转；月球位置 = R·(cosλ, 0, −sinλ)，λ = 0 为新月（月球在日地之间）
// 尺寸不按比例：地月距离约为地球半径的 60 倍，太阳更远得多
(function () {
  var M = window.Moon, DEG = M.DEG, V3 = THREE.Vector3, Y = new V3(0, 1, 0);
  var ORBIT_R = 9, EARTH_R = 1.6, MOON_R = 0.62, MINI_R = 0.34;
  var MAIN_ONLY = 1;

  function orbitPos(lambda, r) {
    var l = lambda * DEG;
    return new V3((r || ORBIT_R) * Math.cos(l), 0, -(r || ORBIT_R) * Math.sin(l));
  }

  // 月面贴图：等距圆柱投影，u = 0.5 的经线（局部 +x）是朝向地球的一面
  function moonCanvas() {
    var W = 512, H = 256, c = document.createElement('canvas');
    c.width = W; c.height = H;
    var x = c.getContext('2d');
    x.fillStyle = '#b9b5ab'; x.fillRect(0, 0, W, H);
    var seed = 7;
    function rnd() { seed = (seed * 16807) % 2147483647; return seed / 2147483647; }
    for (var i = 0; i < 260; i++) {
      var r = 1 + rnd() * 5;
      x.fillStyle = 'rgba(' + (rnd() < 0.5 ? '90,88,82' : '230,228,220') + ',' + (0.12 + rnd() * 0.2) + ')';
      x.beginPath(); x.arc(rnd() * W, rnd() * H, r, 0, Math.PI * 2); x.fill();
    }
    // 近侧月海：与 2D 圆面上的位置对应（屏幕右 = u 增大，屏幕下 = v 增大）
    x.fillStyle = 'rgba(96,92,84,.55)';
    [[-0.38, -0.36, 0.30], [-0.08, -0.42, 0.20], [0.20, -0.30, 0.20], [0.36, -0.05, 0.22],
     [0.66, -0.18, 0.13], [-0.52, 0.06, 0.30], [-0.25, 0.42, 0.20], [0.10, 0.25, 0.14], [0.40, 0.32, 0.12]].forEach(function (m) {
      var u = 0.5 + Math.asin(Math.max(-1, Math.min(1, m[0]))) / (2 * Math.PI);
      var v = 0.5 + Math.asin(Math.max(-1, Math.min(1, m[1]))) / Math.PI;
      x.beginPath(); x.ellipse(u * W, v * H, m[2] * W / (2 * Math.PI) * 1.3, m[2] * H / Math.PI * 1.1, 0, 0, Math.PI * 2); x.fill();
    });
    return c;
  }

  function circlePts(r, n) {
    var pts = [];
    for (var i = 0; i <= n; i++) { var a = i / n * Math.PI * 2; pts.push(new V3(0, r * Math.cos(a), r * Math.sin(a))); }
    return pts;
  }

  window.MoonScene = function (stage, opts) {
    opts = opts || {};
    var renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    var canvas = renderer.domElement;
    canvas.id = 'gl';
    stage.insertBefore(canvas, stage.firstChild);

    var labelRenderer = new THREE.CSS2DRenderer();
    var lEl = labelRenderer.domElement, ls = lEl.style;
    ls.position = 'absolute'; ls.top = '0'; ls.left = '0'; ls.pointerEvents = 'none'; ls.zIndex = '2';
    stage.appendChild(lEl);

    var scene = new THREE.Scene();
    scene.background = new THREE.Color('#05070d');
    var camera = new THREE.PerspectiveCamera(42, 1, 0.1, 2000);
    camera.layers.enable(MAIN_ONLY);
    var VIEWS = { tilt: new V3(-1.7, 17, 21.5), top: new V3(0, 30, 0.001) };
    var view = 'tilt';
    camera.position.copy(VIEWS.tilt);

    // ---------- 拖动月球（先于 OrbitControls 注册） ----------
    var raycaster = new THREE.Raycaster(), ndc = new THREE.Vector2(), plane = new THREE.Plane(Y, 0);
    var dragging = false, moon;
    function setNdc(e) {
      var r = canvas.getBoundingClientRect();
      ndc.set((e.clientX - r.left) / r.width * 2 - 1, -(e.clientY - r.top) / r.height * 2 + 1);
      raycaster.setFromCamera(ndc, camera);
    }
    function hitMoon() {
      // 月球较小，放宽命中范围：射线到月心的距离小于 2.2 倍半径即可
      return raycaster.ray.distanceToPoint(moon.position) < MOON_R * 2.2;
    }
    canvas.addEventListener('pointerdown', function (e) {
      if (e.button !== 0) return;
      setNdc(e);
      if (!hitMoon()) return;
      dragging = true;
      e.stopImmediatePropagation();
      try { canvas.setPointerCapture(e.pointerId); } catch (err) { /* 合成事件 */ }
      canvas.style.cursor = 'grabbing';
      if (opts.onDragStart) opts.onDragStart();
    });
    canvas.addEventListener('pointermove', function (e) {
      setNdc(e);
      if (dragging) {
        var p = raycaster.ray.intersectPlane(plane, new V3());
        if (p && opts.onDrag) opts.onDrag(M.wrap360(Math.atan2(-p.z, p.x) / DEG));
      } else if (e.buttons === 0) {
        canvas.style.cursor = hitMoon() ? 'grab' : '';
      }
    });
    function endDrag(e) {
      if (!dragging) return;
      dragging = false;
      if (canvas.hasPointerCapture(e.pointerId)) canvas.releasePointerCapture(e.pointerId);
      canvas.style.cursor = 'grab';
    }
    canvas.addEventListener('pointerup', endDrag);
    canvas.addEventListener('pointercancel', endDrag);

    var controls = new THREE.OrbitControls(camera, canvas);
    controls.enableDamping = true;
    controls.dampingFactor = 0.08;
    controls.minDistance = 6;
    controls.maxDistance = 80;
    controls.enablePan = false;

    // ---------- 标签 ----------
    function label(html, cls, parent, onClick) {
      var el = document.createElement('div');
      el.className = 'lbl ' + (cls || '');
      el.innerHTML = html;
      if (onClick) el.addEventListener('click', onClick);
      var o = new THREE.CSS2DObject(el);
      parent.add(o);
      return o;
    }

    // ---------- 星空、光照 ----------
    (function () {
      var n = 1600, pos = new Float32Array(n * 3);
      for (var i = 0; i < n; i++) {
        var v = new V3().randomDirection().multiplyScalar(500 + Math.random() * 300);
        pos[i * 3] = v.x; pos[i * 3 + 1] = v.y; pos[i * 3 + 2] = v.z;
      }
      var g = new THREE.BufferGeometry();
      g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
      scene.add(new THREE.Points(g, new THREE.PointsMaterial({ color: 0xffffff, size: 1.3, sizeAttenuation: false, transparent: true, opacity: 0.7 })));
    })();
    var sunLight = new THREE.DirectionalLight(0xffffff, 1.35);
    sunLight.position.set(100, 0, 0);
    scene.add(sunLight);
    scene.add(new THREE.AmbientLight(0x8090b0, 0.13));

    // ---------- 太阳与平行光 ----------
    var sunGroup = new THREE.Group();
    scene.add(sunGroup);
    var sun = new THREE.Mesh(new THREE.SphereGeometry(2.6, 40, 24), new THREE.MeshBasicMaterial({ color: 0xffd54f }));
    sun.position.set(30, 0, 0);
    sunGroup.add(sun);
    var glow = new THREE.Sprite(new THREE.SpriteMaterial({
      map: (function () {
        var c = document.createElement('canvas'); c.width = c.height = 128;
        var x = c.getContext('2d'), g = x.createRadialGradient(64, 64, 0, 64, 64, 64);
        g.addColorStop(0, 'rgba(255,220,120,1)'); g.addColorStop(0.3, 'rgba(255,190,60,.5)'); g.addColorStop(1, 'rgba(255,140,0,0)');
        x.fillStyle = g; x.fillRect(0, 0, 128, 128);
        return new THREE.CanvasTexture(c);
      })(),
      blending: THREE.AdditiveBlending, depthWrite: false, transparent: true
    }));
    glow.scale.set(14, 14, 1);
    glow.position.copy(sun.position);
    sunGroup.add(glow);
    label('太阳<small>（实际远得多）</small>', 'lbl-sun', sun).position.set(0, -3.6, 0);

    var rays = new THREE.Group();
    scene.add(rays);
    var rayMat = new THREE.LineBasicMaterial({ color: 0xffc94a, transparent: true, opacity: 0.38 });
    var coneMat = new THREE.MeshBasicMaterial({ color: 0xffc94a, transparent: true, opacity: 0.6 });
    [-11, -5.5, 0, 5.5, 11].forEach(function (z) {
      var y = 0;
      rays.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints([new V3(24, y, z), new V3(z === 0 ? 3 : -14, y, z)]), rayMat));
      [12, -8].forEach(function (x) {
        if (z === 0 && x < 0) return;
        var c = new THREE.Mesh(new THREE.ConeGeometry(0.22, 0.8, 10), coneMat);
        c.position.set(x, y, z);
        c.quaternion.setFromUnitVectors(Y, new V3(-1, 0, 0));
        rays.add(c);
      });
    });
    label('太阳光（平行光）', 'lbl-ray', rays).position.set(11.5, 0.6, -11);
    rays.traverse(function (o) { o.layers.set(MAIN_ONLY); });

    // ---------- 地球 ----------
    var earth = new THREE.Mesh(new THREE.SphereGeometry(EARTH_R, 64, 40), new THREE.MeshPhongMaterial({
      map: new THREE.CanvasTexture(window.makeEarthCanvas()), shininess: 6
    }));
    scene.add(earth);
    var axis = new THREE.Line(new THREE.BufferGeometry().setFromPoints([new V3(0, -EARTH_R * 1.35, 0), new V3(0, EARTH_R * 1.35, 0)]),
      new THREE.LineBasicMaterial({ color: 0x9fb3c8 }));
    scene.add(axis);
    label('地球', 'lbl-body', earth).position.set(0, -EARTH_R - 0.55, 0);
    label('北', 'lbl-pole', axis).position.set(0, EARTH_R * 1.35 + 0.3, 0);

    // ---------- 月球轨道、方向箭头、八个典型位置 ----------
    (function () {
      var pts = [];
      for (var i = 0; i <= 200; i++) pts.push(orbitPos(i / 200 * 360));
      var ring = new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts), new THREE.LineBasicMaterial({ color: 0x5b6b85 }));
      ring.layers.set(MAIN_ONLY);
      scene.add(ring);
      [22, 157, 202, 337].forEach(function (l) {
        var c = new THREE.Mesh(new THREE.ConeGeometry(0.2, 0.7, 10), new THREE.MeshBasicMaterial({ color: 0x7d8da8 }));
        c.position.copy(orbitPos(l));
        c.quaternion.setFromUnitVectors(Y, new V3(-Math.sin(l * DEG), 0, -Math.cos(l * DEG)));
        c.layers.set(MAIN_ONLY);
        scene.add(c);
      });
    })();

    var moonTex = new THREE.CanvasTexture(moonCanvas());
    var minis = new THREE.Group();
    scene.add(minis);
    var miniLabels = [];
    M.PHASES.forEach(function (p, i) {
      var m = new THREE.Mesh(new THREE.SphereGeometry(MINI_R, 28, 18), new THREE.MeshLambertMaterial({ map: moonTex }));
      m.position.copy(orbitPos(p.lambda));
      m.rotation.y = p.lambda * DEG + Math.PI;
      m.layers.set(MAIN_ONLY);
      minis.add(m);
      var lb = label('<b>' + p.name + '</b><small>' + p.day + '</small>', 'lbl-phase', m, function () { if (opts.onPick) opts.onPick(i); });
      var out = orbitPos(p.lambda, 1).multiplyScalar(1.5);
      lb.position.set(out.x, -0.2, out.z);
      miniLabels.push(lb);
    });

    // ---------- 当前月球 + 辅助：两个半球的分界圈、朝向地球的半球、视线 ----------
    moon = new THREE.Mesh(new THREE.SphereGeometry(MOON_R, 48, 32), new THREE.MeshLambertMaterial({ map: moonTex }));
    scene.add(moon);
    var moonLabel = label('月球', 'lbl-body', moon);
    moonLabel.position.set(0, MOON_R + 0.45, 0);

    var aids = new THREE.Group();   // 跟随月球平移，不随月球转
    scene.add(aids);
    var litRing = new THREE.Line(new THREE.BufferGeometry().setFromPoints(circlePts(MOON_R * 1.12, 64)),
      new THREE.LineBasicMaterial({ color: 0xffc94a }));
    aids.add(litRing);
    var viewGroup = new THREE.Group();   // 局部 +x 指向地球
    aids.add(viewGroup);
    var viewRing = new THREE.Line(new THREE.BufferGeometry().setFromPoints(circlePts(MOON_R * 1.18, 64)),
      new THREE.LineBasicMaterial({ color: 0x4fc3f7 }));
    viewGroup.add(viewRing);
    var shell = new THREE.Mesh(new THREE.SphereGeometry(MOON_R * 1.16, 40, 20, 0, Math.PI * 2, 0, Math.PI / 2),
      new THREE.MeshBasicMaterial({ color: 0x4fc3f7, transparent: true, opacity: 0.16, depthWrite: false, side: THREE.DoubleSide }));
    shell.quaternion.setFromUnitVectors(Y, new V3(1, 0, 0));
    viewGroup.add(shell);
    aids.traverse(function (o) { o.layers.set(MAIN_ONLY); });

    var sight = new THREE.Line(new THREE.BufferGeometry().setFromPoints([new V3(), new V3(1, 0, 0)]),
      new THREE.LineDashedMaterial({ color: 0x4fc3f7, dashSize: 0.35, gapSize: 0.25, transparent: true, opacity: 0.8 }));
    sight.layers.set(MAIN_ONLY);
    scene.add(sight);

    // ---------- 更新 ----------
    var allLabels = [];
    scene.traverse(function (o) { if (o.isCSS2DObject) allLabels.push(o); });

    function update(st) {
      var p = orbitPos(st.lambda);
      moon.position.copy(p);
      moon.rotation.y = st.lambda * DEG + Math.PI;        // 同步自转：同一面朝向地球
      aids.position.copy(p);
      viewGroup.rotation.y = st.lambda * DEG + Math.PI;
      aids.visible = st.show.halves;
      var toEarth = p.clone().setLength(p.length() - MOON_R * 1.25);
      var a = new V3().copy(p).setLength(EARTH_R * 1.05);
      sight.geometry.setFromPoints([a, toEarth]);
      sight.computeLineDistances();
      sight.visible = st.show.sight;
      earth.rotation.y = st.spin;
      rays.visible = st.show.rays;
      minis.visible = st.show.minis;
      var on = st.show.labels;
      allLabels.forEach(function (o) {
        var want = on;
        if (miniLabels.indexOf(o) >= 0) want = on && st.show.minis;
        if (o.parent === rays) want = on && st.show.rays;
        o.visible = want;
        o.element.style.display = want ? '' : 'none';
      });
    }

    function resize(w, h) {
      renderer.setSize(w, h);
      labelRenderer.setSize(w, h);
      camera.aspect = w / h;
      // 竖屏时拉远，保证整条轨道在画面内
      camera.userData.fit = Math.max(1, 1.25 / camera.aspect);
      camera.updateProjectionMatrix();
    }
    function setView(v) {
      view = v;
      camera.position.copy(VIEWS[v]).multiplyScalar(camera.userData.fit || 1);
      controls.target.set(0, 0, 0);
      controls.update();
    }
    function render() {
      controls.update();
      renderer.render(scene, camera);
      labelRenderer.render(scene, camera);
    }
    function setVisible(on) {
      canvas.style.display = on ? '' : 'none';
      lEl.style.display = on ? '' : 'none';
    }

    return {
      update: update, resize: resize, setView: setView, render: render, setVisible: setVisible,
      view: function () { return view; }
    };
  };
})();
