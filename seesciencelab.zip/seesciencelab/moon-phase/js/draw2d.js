// 2D 绘制：月相圆面、地面上看到的天空（面向南方的全景）、北极上空俯视示意图、24 小时日月出没时间轴、练习题画面
// 全景：横轴为方位角（左东、中南、右西），纵轴为高度角；俯视图与 3D 一致：太阳光从右边射来，月球逆时针公转
(function () {
  var M = window.Moon, DEG = Math.PI / 180;
  var GOLD = '#ffc94a', CYAN = '#4fc3f7', MUTED = '#8d99ab', LINE = '#2a3446';
  var FONT = '-apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", sans-serif';

  // 月海（以月面半径为单位，北半球正立看到的位置），让月亮有“脸”，也能看出月球总是同一面朝向地球
  var MARIA = [
    [-0.38, -0.36, 0.30], [-0.08, -0.42, 0.20], [0.20, -0.30, 0.20], [0.36, -0.05, 0.22],
    [0.66, -0.18, 0.13], [-0.52, 0.06, 0.30], [-0.25, 0.42, 0.20], [0.10, 0.25, 0.14], [0.40, 0.32, 0.12]
  ];

  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
  function mix(a, b, t) { return a + (b - a) * t; }
  function mixColor(c1, c2, t) {
    var a = parseInt(c1.slice(1), 16), b = parseInt(c2.slice(1), 16);
    var r = Math.round(mix(a >> 16, b >> 16, t)), g = Math.round(mix((a >> 8) & 255, (b >> 8) & 255, t)), bl = Math.round(mix(a & 255, b & 255, t));
    return 'rgb(' + r + ',' + g + ',' + bl + ')';
  }

  // 月相圆面：lambda 为日月角距，sunAng 为“指向太阳”的屏幕方向（弧度，canvas 坐标），
  // o.dark 暗面颜色（null 不画）、o.flip 月面上下左右颠倒（南半球）、o.alpha 亮面透明度、o.outline 轮廓
  function disc(ctx, x, y, r, lambda, sunAng, o) {
    o = o || {};
    var k = Math.cos(lambda * DEG), N = 48, i, a;
    ctx.save();
    ctx.translate(x, y);
    if (o.dark) {
      ctx.fillStyle = o.dark;
      ctx.beginPath(); ctx.arc(0, 0, r, 0, Math.PI * 2); ctx.fill();
    }
    if (o.outline) {
      ctx.strokeStyle = o.outline; ctx.lineWidth = 1; ctx.setLineDash([3, 3]);
      ctx.beginPath(); ctx.arc(0, 0, r, 0, Math.PI * 2); ctx.stroke();
      ctx.setLineDash([]);
    }
    if (k < 0.9995) {
      // 亮区：亮面一侧的半圆边缘 + 晨昏线（投影成半个椭圆，横半轴 r·cosλ）
      ctx.save();
      ctx.rotate(sunAng);
      ctx.beginPath();
      for (i = 0; i <= N; i++) { a = -Math.PI / 2 + Math.PI * i / N; ctx.lineTo(r * Math.cos(a), r * Math.sin(a)); }
      for (i = N; i >= 0; i--) { a = -Math.PI / 2 + Math.PI * i / N; ctx.lineTo(r * k * Math.cos(a), r * Math.sin(a)); }
      ctx.closePath();
      ctx.restore();
      ctx.clip();
      ctx.globalAlpha = o.alpha == null ? 1 : o.alpha;
      var g = ctx.createRadialGradient(-r * 0.3, -r * 0.3, r * 0.1, 0, 0, r);
      g.addColorStop(0, '#fbf6e6'); g.addColorStop(1, '#d8d0bb');
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.arc(0, 0, r, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = 'rgba(128,122,108,.45)';
      if (o.flip) ctx.rotate(Math.PI);
      MARIA.forEach(function (m) { ctx.beginPath(); ctx.arc(m[0] * r, m[1] * r, m[2] * r, 0, Math.PI * 2); ctx.fill(); });
    }
    ctx.restore();
  }

  function View(canvas) {
    var ctx = canvas.getContext('2d');
    var W = 0, H = 0, dpr = 1, L = null;
    var STARS = [];
    for (var i = 0; i < 160; i++) STARS.push([Math.random(), Math.random() * 0.95, 0.4 + Math.random() * 1.1]);

    function resize(w, h) {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      W = w; H = h;
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
      canvas.style.width = w + 'px'; canvas.style.height = h + 'px';
      L = layout(w, h);
    }

    function layout(w, h) {
      var narrow = w < 640;
      var top = narrow ? 92 : 56;
      var hor = Math.round(h * (narrow ? 0.48 : 0.6));
      var pad = narrow ? 20 : 56;
      var l = { narrow: narrow, top: top, hor: hor, x0: pad, x1: w - pad, mr: clamp(w * 0.022, 15, 28) };
      // 地面上的两个小部件：俯视示意图 + 时间轴
      var gy = hor + 34, gh = h - gy - 48;
      if (narrow) {
        var s = clamp(Math.min(gh * 0.55, w * 0.5), 120, 220);
        l.topv = { x: 12, y: gy, w: s, h: s };
        l.tl = { x: s + 24, y: gy + 6, w: w - s - 36, h: Math.min(110, s) };
      } else {
        var s2 = clamp(gh, 120, 250);
        l.topv = { x: pad, y: gy, w: s2, h: s2 };
        l.tl = { x: pad + s2 + 32, y: gy + 10, w: Math.min(w - pad * 2 - s2 - 32, 620), h: 116 };
      }
      return l;
    }

    // 方位角 / 高度角 → 屏幕
    function px(az) { return mix(L.x0, L.x1, (az + 90) / 180); }
    function py(alt) { return L.hor - alt / 60 * (L.hor - L.top - 20); }
    function pos(H) { var p = M.horiz(H); return { x: px(p.az), y: py(p.alt), alt: p.alt, az: p.az }; }

    function skyBg(sunAlt, sunPos) {
      var day = clamp((sunAlt + 10) / 18, 0, 1);
      var g = ctx.createLinearGradient(0, 0, 0, L.hor);
      g.addColorStop(0, mixColor('#04060c', '#2c66ad', day));
      g.addColorStop(1, mixColor('#111b31', '#93c4ec', day));
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, W, L.hor);
      // 晨昏时太阳附近的地平线泛红
      var tw = clamp(1 - Math.abs(sunAlt) / 10, 0, 1);
      if (tw > 0) {
        var gx = clamp(sunPos.x, -W * 0.2, W * 1.2);
        var rg = ctx.createRadialGradient(gx, L.hor, 0, gx, L.hor, W * 0.45);
        rg.addColorStop(0, 'rgba(255,150,70,' + (0.55 * tw) + ')');
        rg.addColorStop(1, 'rgba(255,150,70,0)');
        ctx.fillStyle = rg;
        ctx.fillRect(0, 0, W, L.hor);
      }
      var night = clamp((-sunAlt - 4) / 10, 0, 1);
      if (night > 0) {
        ctx.fillStyle = 'rgba(255,255,255,' + (0.8 * night) + ')';
        STARS.forEach(function (s) { ctx.fillRect(s[0] * W, s[1] * L.hor, s[2], s[2]); });
      }
      return night;
    }

    function ground() {
      var g = ctx.createLinearGradient(0, L.hor, 0, H);
      g.addColorStop(0, '#16212e'); g.addColorStop(0.08, '#0d141e'); g.addColorStop(1, '#070a10');
      ctx.fillStyle = g;
      ctx.fillRect(0, L.hor, W, H - L.hor);
      // 远山剪影
      ctx.fillStyle = '#121b27';
      ctx.beginPath(); ctx.moveTo(0, L.hor);
      for (var x = 0; x <= W; x += 24) ctx.lineTo(x, L.hor - 6 - 6 * Math.abs(Math.sin(x * 0.013) + Math.sin(x * 0.031)));
      ctx.lineTo(W, L.hor); ctx.closePath(); ctx.fill();
      ctx.strokeStyle = '#3a4a60'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(0, L.hor + 0.5); ctx.lineTo(W, L.hor + 0.5); ctx.stroke();
      ctx.font = '600 14px ' + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'top';
      [[-90, '东'], [-45, '东南'], [0, '南'], [45, '西南'], [90, '西']].forEach(function (d) {
        var x = px(d[0]);
        ctx.fillStyle = d[0] === 0 ? GOLD : '#c7d0dc';
        ctx.fillText(d[1], x, L.hor + 8);
        ctx.fillRect(x - 0.5, L.hor - 4, 1, 8);
      });
    }

    function dailyPath() {
      ctx.save();
      ctx.strokeStyle = 'rgba(255,255,255,.22)'; ctx.lineWidth = 1.2; ctx.setLineDash([5, 6]);
      ctx.beginPath();
      for (var h = -90; h <= 90; h += 3) { var p = pos(h); if (h === -90) ctx.moveTo(p.x, p.y); else ctx.lineTo(p.x, p.y); }
      ctx.stroke();
      ctx.restore();
    }

    function drawSun(p) {
      var r = L.mr * 0.9;
      var g = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, r * 3.2);
      g.addColorStop(0, 'rgba(255,230,140,.95)'); g.addColorStop(0.3, 'rgba(255,200,80,.35)'); g.addColorStop(1, 'rgba(255,180,60,0)');
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.arc(p.x, p.y, r * 3.2, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#ffe28a';
      ctx.beginPath(); ctx.arc(p.x, p.y, r, 0, Math.PI * 2); ctx.fill();
    }

    // 月亮在全景中的亮面方向：沿日月共同的路径指向太阳（较近的一侧）
    function sunAngleAt(Hm, lambda) {
      var dir = M.wrap360(lambda) < 180 ? 1 : -1;
      var a = pos(Hm), b = pos(Hm + dir * 2);
      return Math.atan2(b.y - a.y, b.x - a.x);
    }

    function drawMoonInSky(Hm, lambda, night, labels) {
      var p = pos(Hm);
      if (p.alt < -8) return p;
      var dayA = 1 - night;
      disc(ctx, p.x, p.y, L.mr, lambda, sunAngleAt(Hm, lambda), {
        dark: 'rgba(52,60,76,' + (0.85 * night) + ')', alpha: 1 - 0.3 * dayA,
        outline: M.illum(lambda) < 0.03 ? 'rgba(200,210,225,.35)' : null
      });
      if (labels && p.alt > 0) {
        var ph = M.phaseOf(M.ageOf(lambda));
        ctx.font = '13px ' + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'bottom';
        ctx.fillStyle = 'rgba(230,235,242,.9)';
        ctx.fillText(ph.name, p.x, p.y - L.mr - 6);
      }
      return p;
    }

    // 北极上空俯视：太阳光自右向左，地球逆时针自转，观察者处画地平线（切线）
    function topView(b, t, lambda) {
      var cx = b.x + b.w / 2, cy = b.y + b.h / 2, ro = b.w * 0.36, re = b.w * 0.12;
      ctx.save();
      ctx.fillStyle = 'rgba(10,15,24,.82)'; ctx.strokeStyle = LINE;
      roundRect(b.x, b.y, b.w, b.h, 10); ctx.fill(); ctx.stroke();
      ctx.font = '11px ' + FONT; ctx.fillStyle = MUTED; ctx.textAlign = 'left'; ctx.textBaseline = 'top';
      ctx.fillText('从北极上空看', b.x + 8, b.y + 6);
      ctx.textAlign = 'right'; ctx.fillStyle = GOLD;
      ctx.fillText('太阳光 ←', b.x + b.w - 8, b.y + 6);
      // 太阳光
      ctx.strokeStyle = ctx.fillStyle = 'rgba(255,201,74,.45)'; ctx.lineWidth = 1;
      for (var k = -2; k <= 2; k++) {
        var yy = cy + k * b.h * 0.18, xa = b.x + b.w - 8, xb = b.x + b.w - 30;
        ctx.beginPath(); ctx.moveTo(xa, yy); ctx.lineTo(xb, yy); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(xb - 5, yy); ctx.lineTo(xb + 1, yy - 3); ctx.lineTo(xb + 1, yy + 3); ctx.closePath(); ctx.fill();
      }
      // 月球轨道
      ctx.strokeStyle = 'rgba(141,153,171,.5)'; ctx.setLineDash([3, 4]);
      ctx.beginPath(); ctx.arc(cx, cy, ro, 0, Math.PI * 2); ctx.stroke(); ctx.setLineDash([]);
      // 地球：右半边是白天
      ctx.fillStyle = '#1b3a63'; ctx.beginPath(); ctx.arc(cx, cy, re, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#3f8fd6'; ctx.beginPath(); ctx.arc(cx, cy, re, -Math.PI / 2, Math.PI / 2); ctx.fill();
      // 自转方向
      ctx.strokeStyle = 'rgba(230,235,242,.55)'; ctx.lineWidth = 1.2;
      ctx.beginPath(); ctx.arc(cx, cy, re * 0.55, 0.3, 1.7 * Math.PI, true); ctx.stroke();
      // 观察者与地平线
      var th = (t - 12) * 15 * DEG, ox = cx + re * Math.cos(th), oy = cy - re * Math.sin(th);
      var tx = -Math.sin(th), ty = -Math.cos(th);
      ctx.strokeStyle = 'rgba(255,138,128,.8)'; ctx.setLineDash([4, 3]);
      ctx.beginPath(); ctx.moveTo(ox - tx * re * 2.2, oy - ty * re * 2.2); ctx.lineTo(ox + tx * re * 2.2, oy + ty * re * 2.2); ctx.stroke();
      ctx.setLineDash([]);
      ctx.fillStyle = '#ff8a80'; ctx.beginPath(); ctx.arc(ox, oy, 3.5, 0, Math.PI * 2); ctx.fill();
      // 月球：被照亮的一半朝右
      var l = lambda * DEG, mx = cx + ro * Math.cos(l), my = cy - ro * Math.sin(l), mr = Math.max(6, b.w * 0.045);
      ctx.strokeStyle = 'rgba(79,195,247,.45)'; ctx.beginPath(); ctx.moveTo(ox, oy); ctx.lineTo(mx, my); ctx.stroke();
      ctx.fillStyle = '#3a3f4a'; ctx.beginPath(); ctx.arc(mx, my, mr, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#f3ecd6'; ctx.beginPath(); ctx.arc(mx, my, mr, -Math.PI / 2, Math.PI / 2); ctx.fill();
      ctx.fillStyle = MUTED; ctx.textAlign = 'center'; ctx.textBaseline = 'bottom';
      ctx.fillText('观察者', ox + Math.cos(th) * 22, oy - Math.sin(th) * 22 + 5);
      ctx.restore();
    }

    // 24 小时时间轴（12 时 → 次日 12 时，夜晚在中间）
    function timeline(b, t, lambda) {
      var x0 = b.x + 40, x1 = b.x + b.w - 8;
      function tx(h) { return mix(x0, x1, (h - 12) / 24); }
      ctx.save();
      ctx.fillStyle = 'rgba(10,15,24,.82)'; ctx.strokeStyle = LINE;
      roundRect(b.x, b.y, b.w, b.h, 10); ctx.fill(); ctx.stroke();
      var r1 = b.y + 30, r2 = b.y + 62, bh = 16;
      ctx.fillStyle = 'rgba(40,52,80,.6)';
      ctx.fillRect(tx(18), b.y + 22, tx(30) - tx(18), 64);
      ctx.font = '12px ' + FONT; ctx.textBaseline = 'middle'; ctx.textAlign = 'left';
      ctx.fillStyle = GOLD; ctx.fillText('太阳', b.x + 8, r1 + bh / 2);
      ctx.fillStyle = '#e8e2cf'; ctx.fillText('月亮', b.x + 8, r2 + bh / 2);
      // 逐段取样，把“在地平线以上”的连续时段画成一整条（月亮：夜里亮、白天淡）
      function runs(test, y, color) {
        var start = null, cur = null, N = 480;
        for (var i = 0; i <= N; i++) {
          var h = 12 + 24 * i / N, v = i < N ? test(h) : null;
          if (v !== cur) {
            if (cur) { ctx.fillStyle = color(cur); ctx.fillRect(tx(start), y, tx(h) - tx(start), bh); }
            start = h; cur = v;
          }
        }
      }
      runs(function (h) { return M.sky(h % 24, lambda).sun.alt > 0 ? 'up' : null; }, r1, function () { return 'rgba(255,201,74,.85)'; });
      runs(function (h) {
        return M.sky(h % 24, lambda).moon.alt > 0 ? (h >= 18 && h < 30 ? 'night' : 'day') : null;
      }, r2, function (v) { return v === 'night' ? 'rgba(240,234,214,.95)' : 'rgba(240,234,214,.3)'; });
      ctx.fillStyle = MUTED; ctx.textAlign = 'center'; ctx.textBaseline = 'top'; ctx.font = '11px ' + FONT;
      [12, 18, 24, 30, 36].forEach(function (h) {
        ctx.fillText((h % 24) + ' 时', tx(h), r2 + bh + 6);
        ctx.fillRect(tx(h) - 0.5, r2 + bh + 1, 1, 4);
      });
      ctx.fillText('夜晚', (tx(18) + tx(30)) / 2, b.y + 6);
      var tt = t < 12 ? t + 24 : t;
      ctx.strokeStyle = '#ff8a80'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(tx(tt), b.y + 20); ctx.lineTo(tx(tt), r2 + bh + 2); ctx.stroke();
      ctx.restore();
    }

    function roundRect(x, y, w, h, r) {
      ctx.beginPath();
      ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r);
      ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
    }

    // 场景二：地面上看到的天空
    function drawSky(o) {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      var Hs = (o.t - 12) * 15, Hm = Hs - o.lambda, sp = pos(Hs);
      var night = skyBg(sp.alt, sp);
      if (o.path) dailyPath();
      if (sp.alt > -8) drawSun(sp);
      if (o.moon !== false) drawMoonInSky(Hm, o.lambda, night, o.labels);
      ground();
      if (o.clock) {
        ctx.font = '600 22px ' + FONT; ctx.textAlign = 'left'; ctx.textBaseline = 'top'; ctx.fillStyle = '#e6ebf2';
        ctx.fillText(M.fmtClock(o.t), L.narrow ? 16 : L.x0, L.top - (L.narrow ? 8 : 24));
        ctx.font = '12px ' + FONT; ctx.fillStyle = MUTED;
        ctx.fillText(M.timeWord(o.t) + ' · 面向南方', (L.narrow ? 16 : L.x0) + 74, L.top - (L.narrow ? 2 : 18));
      }
      if (o.widgets) { topView(L.topv, o.t, o.lambda); timeline(L.tl, o.t, o.lambda); }
    }

    // 场景三：练习题画面
    function drawQuiz(q, answered) {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      if (q.type === 'sky' || q.type === 'where') {
        drawSky({ t: q.t, lambda: q.lambda, path: true, moon: q.type === 'sky' || answered, labels: answered, clock: true });
        if (q.type === 'where' && !answered) {
          ctx.font = '600 44px ' + FONT; ctx.fillStyle = 'rgba(230,235,242,.5)'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
          ctx.fillText('?', W / 2, (L.top + L.hor) / 2);
        }
        return;
      }
      var g = ctx.createLinearGradient(0, 0, 0, H);
      g.addColorStop(0, '#04060c'); g.addColorStop(1, '#0e1729');
      ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
      ctx.fillStyle = 'rgba(255,255,255,.6)';
      STARS.forEach(function (s) { ctx.fillRect(s[0] * W, s[1] * H, s[2], s[2]); });
      var r = clamp(Math.min(W, H) * 0.17, 60, 150), cy = H * 0.4;
      disc(ctx, W / 2, cy, r, q.lambda, M.waxing(q.lambda) ? 0 : Math.PI, { dark: 'rgba(52,60,76,.55)' });
      ctx.font = '600 15px ' + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#c7d0dc';
      ctx.fillText('东', W / 2 - r - 34, cy); ctx.fillText('西', W / 2 + r + 34, cy);
      ctx.font = '12px ' + FONT; ctx.fillStyle = MUTED;
      ctx.fillText('北半球 · 面向南方观察', W / 2, cy + r + 24);
    }

    return {
      resize: resize, drawSky: drawSky, drawQuiz: drawQuiz,
      layout: function () { return L; }
    };
  }

  // 面板外的小窗：从地球上看到的月相（北半球正立，南半球颠倒）
  function inset(canvas, lambda, south) {
    var ctx = canvas.getContext('2d'), dpr = Math.min(window.devicePixelRatio || 1, 2);
    var w = canvas.clientWidth, h = canvas.clientHeight;
    if (canvas.width !== Math.round(w * dpr)) { canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr); }
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, w, h);
    var r = Math.min(w, h) * 0.34, cx = w / 2, cy = h / 2 + 4;
    var west = M.waxing(lambda) ? 0 : Math.PI;   // 北半球：渐盈时亮面在右（西）
    disc(ctx, cx, cy, r, lambda, south ? west + Math.PI : west, {
      dark: 'rgba(52,60,76,.6)', flip: south, outline: M.illum(lambda) < 0.03 ? 'rgba(200,210,225,.4)' : null
    });
    ctx.font = '12px ' + FONT; ctx.fillStyle = MUTED; ctx.textBaseline = 'middle';
    ctx.textAlign = 'left'; ctx.fillText(south ? '西' : '东', 6, cy);
    ctx.textAlign = 'right'; ctx.fillText(south ? '东' : '西', w - 6, cy);
  }

  window.MoonDraw = { disc: disc, View: View, inset: inset };
})();
