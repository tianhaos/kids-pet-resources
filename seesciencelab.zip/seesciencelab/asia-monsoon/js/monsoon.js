// 亚洲季风的两种典型季节配置。经纬度按东经、北纬为正。
(function () {
  const COLD = '#8bd0ff', WET = '#76f7c6';
  const CENTERS = {
    siberian: { pos: [99, 50], type: '高', name: '亚洲高压', short: '亚洲高压',
      radius: [24, 13], label: [0, -1], detail: '亚洲内陆冬季降温快。低层冷空气积聚，形成蒙古—西伯利亚高压。' },
    aleutian: { pos: [177, 52], type: '低', name: '阿留申低压', short: '阿留申低压',
      radius: [22, 12], label: [0, -1], detail: '北太平洋冬季低压活动强，形成明显的阿留申低压。和亚洲高压并列比较，可看出低压带在海陆上的差异。' },
    asian: { pos: [71, 29], type: '低', name: '亚洲低压', short: '亚洲低压',
      radius: [25, 13], label: [0, -1], detail: '夏季亚洲大陆升温快，南亚和西亚一带形成热低压。图上标示的是近地面气压。' },
    pacific: { pos: [187, 34], type: '高', name: '北太平洋副热带高压', short: '太平洋副高',
      radius: [27, 12], label: [0, -1], detail: '夏季北太平洋副热带高压发达。它的西侧可向东亚输送来自低纬海洋的暖湿气流。' },
    indian: { pos: [63, -24], type: '高', name: '南印度洋副热带高压', short: '南印度洋副高',
      radius: [20, 10], label: [1, 0], detail: '南印度洋副热带高压北侧的东南信风向赤道流动，是南亚夏季西南季风的重要气流来源。' }
  };
  const ROUTES = {
    winter: [
      { region: 'east', name: '东亚西北季风', compact: '西北风', color: COLD,
        source: '亚洲大陆 → 东亚沿海', label: [144, 39],
        detail: '从亚洲内陆向东亚沿海流动。典型风向为西北风，越往南局地也常吹东北风。',
        curves: [[[110, 46], [117, 43], [123, 39], [131, 35]], [[131, 35], [139, 31], [145, 26], [150, 21]]],
        branches: [[[[107, 40], [112, 33], [117, 25], [120, 17]]]] },
      { region: 'south', name: '南亚东北季风', compact: '东北风', color: COLD,
        source: '南亚大陆 → 印度洋', label: [57, 10],
        detail: '南亚低层气流多从东北吹向印度洋，陆源气流一般较干。经过孟加拉湾后，也可为印度东南部带来降水。',
        curves: [[[88, 25], [85, 20], [82, 16], [77, 11]], [[77, 11], [73, 7], [70, 4], [67, 0]]],
        branches: [[[[97, 23], [95, 16], [91, 10], [85, 5]]]] }
    ],
    summer: [
      { region: 'east', name: '东亚东南季风', compact: '东南风', color: WET,
        source: '西太平洋 → 东亚沿海', label: [156, 24],
        detail: '西太平洋的暖湿气流沿副高西侧到达东亚沿海。典型风向为东南风，也可因地区和副高位置不同而偏南。',
        curves: [[[159, 15], [150, 17], [141, 19], [133, 24]], [[133, 24], [124, 30], [117, 37], [114, 44]]],
        branches: [[[[167, 26], [155, 28], [143, 33], [137, 41]]]] },
      { region: 'south', name: '南亚西南季风', compact: '西南风', color: WET,
        source: '南印度洋 → 越赤道 → 南亚', label: [66, 9],
        detail: '东南信风先向西北走，越过赤道后在北半球逐步右偏，成为从西南吹来的暖湿气流。',
        curves: [[[75, -22], [65, -17], [55, -11], [53, -4]], [[53, -4], [50, 7], [57, 14], [68, 18]], [[68, 18], [73, 20], [77, 22], [82, 25]]],
        branches: [[[[73, 5], [84, 9], [90, 16], [93, 24]]]] }
    ]
  };
  const SEASONS = {
    winter: {
      name: '1 月 · 北半球冬季', land: '大陆较冷', water: '海洋相对较暖',
      band: '副极地低气压带', bandLat: 57, bandType: '低',
      centers: ['siberian', 'aleutian'], routes: ROUTES.winter,
      cause: '冬季亚洲内陆降温较快，形成亚洲冷高压。同纬度附近的北太平洋上，阿留申低压较显著。',
      compare: '对照约 60°N 的理想低压带。冬季亚洲大陆上出现冷高压，原本连续的低压带在大陆处被打断。'
    },
    summer: {
      name: '7 月 · 北半球夏季', land: '大陆较暖', water: '海洋相对较凉',
      band: '副热带高气压带', bandLat: 32, bandType: '高',
      centers: ['asian', 'pacific', 'indian'], routes: ROUTES.summer,
      cause: '夏季亚洲内陆升温较快，形成亚洲热低压。北太平洋副热带高压在海上发达。',
      compare: '对照约 30°N 的理想高压带。夏季亚洲大陆上出现热低压，原本连续的高压带在大陆处被打断。'
    }
  };

  // 将分段贝塞尔采样为等比例地图距离，粒子沿同一路径匀速示意。
  function sample(curves) {
    const points = [];
    let total = 0;
    for (const [a, b, c, d] of curves) {
      for (let i = points.length ? 1 : 0; i <= 24; i++) {
        const t = i / 24, u = 1 - t;
        const p = a.map((value, axis) =>
          u ** 3 * value + 3 * u * u * t * b[axis] + 3 * u * t * t * c[axis] + t ** 3 * d[axis]);
        if (points.length) {
          const prev = points[points.length - 1];
          total += Math.hypot((p[0] - prev.lon) * 0.84, p[1] - prev.lat);
        }
        points.push({ lon: p[0], lat: p[1], distance: total });
      }
    }
    return { points, total };
  }

  function pointAt(path, fraction) {
    const at = Math.max(0, Math.min(1, fraction)) * path.total;
    let lo = 0, hi = path.points.length - 1;
    while (hi - lo > 1) {
      const mid = (lo + hi) >> 1;
      if (path.points[mid].distance < at) lo = mid;
      else hi = mid;
    }
    const a = path.points[lo], b = path.points[hi];
    const mix = (at - a.distance) / (b.distance - a.distance);
    return [a.lon + (b.lon - a.lon) * mix, a.lat + (b.lat - a.lat) * mix];
  }

  function distanceToPath(path, point) {
    let closest = Infinity;
    const [lon, lat] = point;
    for (let i = 1; i < path.points.length; i++) {
      const a = path.points[i - 1], b = path.points[i];
      const dx = (b.lon - a.lon) * 0.84, dy = b.lat - a.lat;
      const x = (lon - a.lon) * 0.84, y = lat - a.lat;
      const f = Math.max(0, Math.min(1, (x * dx + y * dy) / (dx * dx + dy * dy)));
      closest = Math.min(closest, Math.hypot(x - f * dx, y - f * dy));
    }
    return closest;
  }

  for (const routes of Object.values(ROUTES)) {
    for (const route of routes) route.paths = [route.curves, ...route.branches].map(sample);
  }
  const southerly = ROUTES.summer[1].paths[0].points;
  const nextNorth = southerly.findIndex(p => p.lat >= 0);
  const [before, after] = southerly.slice(nextNorth - 1, nextNorth + 1);
  const equatorLon = before.lon + (after.lon - before.lon) * (-before.lat / (after.lat - before.lat));

  window.Monsoon = { SEASONS, CENTERS, pointAt, distanceToPath, equatorLon };
})();
