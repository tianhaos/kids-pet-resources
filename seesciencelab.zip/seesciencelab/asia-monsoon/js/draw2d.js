// 区域地图采用等距圆柱投影，标准纬线约 33°。各层共用投影。
(function () {
  const { SEASONS, CENTERS, pointAt, distanceToPath, equatorLon } = window.Monsoon;
  const { LAND, WATER, ICE } = window.Continents;
  const HIGH = '#9acaff', LOW = '#ffb092', DARK = '#06101a';
  const GEO = { west: 42, east: 211, north: 75, south: -31 };
  const RELIEF = [
    { color: '#b8a172', width: 5, points: [[52, 36], [58, 37], [68, 37], [73, 37]] },
    { color: '#b39e76', width: 7, points: [[71, 35], [77, 34], [82, 32], [92, 30], [97, 30], [102, 29]] },
    { color: '#a99874', width: 6, points: [[72, 42], [78, 43], [85, 43], [94, 43]] },
    { color: '#889a87', width: 5, points: [[80, 49], [88, 48], [100, 48], [106, 52]] },
    { color: '#859d8c', width: 5, points: [[125, 53], [127, 47], [130, 44], [132, 43]] },
    { color: '#9a9576', width: 3, points: [[74, 18], [74, 15], [76, 11], [77, 9]] },
    { color: '#929f77', width: 3, points: [[98, 24], [98, 19], [100, 14], [99, 10]] }
  ];

  function create(canvas) {
    const ctx = canvas.getContext('2d');
    const base = document.createElement('canvas');
    const map = base.getContext('2d');
    let width, height, dpr, key, scale, origin, compact, hits = [];

    function project(lon, lat) {
      return [origin[0] + (lon - GEO.west) * scale * 0.84, origin[1] + (GEO.north - lat) * scale];
    }

    function unproject(x, y) {
      return [GEO.west + (x - origin[0]) / (scale * 0.84), GEO.north - (y - origin[1]) / scale];
    }

    function pathLine(c, points) {
      c.beginPath();
      points.forEach(([x, y], index) => index ? c.lineTo(x, y) : c.moveTo(x, y));
    }

    function geography(polygons) {
      const shape = new Path2D();
      for (const polygon of polygons) {
        // 阿拉斯加与俄罗斯海岸分跨 180° 经线。
        for (const shift of [0, 360]) {
          const points = polygon.map(([x, y]) => project(x + shift, y));
          shape.moveTo(...points[0]);
          for (const p of points.slice(1)) shape.lineTo(...p);
          shape.closePath();
        }
      }
      return shape;
    }

    function resize() {
      const rect = canvas.getBoundingClientRect();
      width = rect.width;
      height = rect.height;
      dpr = Math.min(2, window.devicePixelRatio || 1);
      canvas.width = base.width = Math.round(width * dpr);
      canvas.height = base.height = Math.round(height * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      map.setTransform(dpr, 0, 0, dpr, 0, 0);
      compact = width < 560;
      const spanX = (GEO.east - GEO.west) * 0.84, spanY = GEO.north - GEO.south;
      const pad = compact ? 12 : 26;
      scale = Math.min(Math.max(width - 2 * pad, 1) / spanX, Math.max(height - 2 * pad, 1) / spanY);
      origin = [(width - spanX * scale) / 2, (height - spanY * scale) / 2];
      key = '';
    }

    function text(c, value, x, y, options = {}) {
      const { size = 13, color = '#d8e5ee', align = 'center', weight = 550, halo = 3 } = options;
      c.font = weight + ' ' + size + 'px -apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", sans-serif';
      c.textAlign = align;
      c.textBaseline = 'middle';
      if (halo) {
        c.lineJoin = 'round';
        c.lineWidth = halo;
        c.strokeStyle = '#071320';
        c.strokeText(value, x, y);
      }
      c.fillStyle = color;
      c.fillText(value, x, y);
    }

    function gradient(c, x, y, rx, ry, inner) {
      c.save();
      c.translate(x, y);
      c.scale(rx, ry);
      const shade = c.createRadialGradient(0, 0, 0, 0, 0, 1);
      shade.addColorStop(0, inner);
      shade.addColorStop(1, inner.slice(0, 7) + '00');
      c.fillStyle = shade;
      c.fillRect(-1, -1, 2, 2);
      c.restore();
    }

    function terrain(c, land, summer, ideal) {
      const rock = c.createLinearGradient(0, 0, 0, height);
      rock.addColorStop(0, '#364951');
      rock.addColorStop(0.44, '#3c544a');
      rock.addColorStop(0.76, '#3d554a');
      rock.addColorStop(1, '#4c5145');
      c.fillStyle = rock;
      c.fill(land);
      c.save();
      c.clip(land);
      const [x, y] = project(summer ? 77 : 102, summer ? 34 : 52);
      if (!ideal) gradient(c, x, y, scale * 55, scale * 37, summer ? '#d77f467d' : '#629bdd87');
      const [tx, ty] = project(86, 32);
      gradient(c, tx, ty, scale * 20, scale * 8, '#b9a17385');
      // 纹理沿主要山系布置。线条表现地貌，未标示高程读数。
      for (const ridge of RELIEF) {
        c.strokeStyle = ridge.color;
        for (let j = -3; j <= 3; j++) {
          const points = ridge.points.flatMap(([lon, lat], i) => {
            const p = [[lon, lat + j * ridge.width * 0.27]];
            if (i < ridge.points.length - 1) {
              const next = ridge.points[i + 1];
              p.push([(lon + next[0]) / 2, (lat + next[1]) / 2 + j * ridge.width * 0.27 + (i % 2 ? 0.8 : -0.9)]);
            }
            return p.map(pair => project(...pair));
          });
          pathLine(c, points);
          c.globalAlpha = j === 0 ? 0.62 : 0.33 - Math.abs(j) * 0.056;
          c.lineWidth = j === 0 ? 1.25 : 0.75;
          c.stroke();
        }
      }
      c.restore();
      c.strokeStyle = '#80a7a2a0';
      c.lineWidth = compact ? 0.65 : 1;
      c.stroke(land);
      c.fillStyle = '#11293a';
      c.fill(geography(WATER));
      c.fillStyle = '#8aa0a36e';
      c.fill(geography(ICE));
    }

    function grid(c) {
      for (let lon = 60; lon <= 210; lon += 30) {
        c.strokeStyle = '#88b0c82b';
        c.lineWidth = 0.75;
        const [x] = project(lon, 0);
        pathLine(c, [[x, 0], [x, height]]);
        c.stroke();
        if (!compact || lon <= 180) text(c, lon <= 180 ? lon + '°E' : (360 - lon) + '°W',
          x, height - 10, { size: 10, color: '#a0b7c9' });
      }
      for (const lat of [-20, 0, 20, 40, 60]) {
        const [, y] = project(0, lat);
        pathLine(c, [[0, y], [width, y]]);
        c.strokeStyle = lat === 0 ? '#b0d0e17a' : '#88b0c82b';
        c.lineWidth = lat === 0 ? 1.15 : 0.75;
        c.setLineDash(lat === 0 ? [5, 4] : []);
        c.stroke();
        c.setLineDash([]);
        if (lat === 0) text(c, '赤道', width - (compact ? 9 : 14), y - 10,
          { size: compact ? 10 : 12, color: '#b6cfdf', align: 'right' });
      }
    }

    function drawBand(c, season) {
      const [, y] = project(0, season.bandLat);
      c.fillStyle = season.bandType === '低' ? '#ff9c8052' : '#84bfff52';
      c.fillRect(0, y - scale * 5, width, scale * 10);
      c.strokeStyle = season.bandType === '低' ? LOW : HIGH;
      c.setLineDash([5, 5]);
      c.lineWidth = 1.5;
      for (const edge of [-5, 5]) {
        const [, line] = project(0, season.bandLat + edge);
        pathLine(c, [[0, line], [width, line]]);
        c.stroke();
      }
      c.setLineDash([]);
      text(c, season.band + '（理想）', width / 2, y, { size: compact ? 13 : 17, weight: 680 });
    }

    function pressureShape(c, center) {
      const [x, y] = project(...center.pos);
      const [rx, ry] = [center.radius[0] * scale * 0.84, center.radius[1] * scale];
      const hue = center.type === '高' ? HIGH : LOW;
      gradient(c, x, y, rx * 1.38, ry * 1.5, hue + '68');
      c.strokeStyle = hue;
      c.lineWidth = 1;
      for (const size of [0.55, 0.81, 1.08]) {
        c.globalAlpha = 0.6 - size * 0.33;
        c.beginPath();
        c.ellipse(x, y, rx * size, ry * size, -0.08, 0, 2 * Math.PI);
        c.stroke();
      }
      c.globalAlpha = 1;
    }

    function compass(c) {
      const x = width - 24, y = 23;
      text(c, '北', x, y - 9, { size: 11, color: '#bfd1dc' });
      pathLine(c, [[x - 4, y + 10], [x, y + 1], [x + 4, y + 10], [x, y + 7]]);
      c.closePath();
      c.fillStyle = '#bfd1dc';
      c.fill();
    }

    function renderBase(state) {
      const season = SEASONS[state.scene], ideal = state.layer === 'ideal';
      const sea = map.createLinearGradient(0, 0, width * 0.65, height);
      sea.addColorStop(0, '#122533');
      sea.addColorStop(0.53, '#0c2030');
      sea.addColorStop(1, '#081423');
      map.fillStyle = sea;
      map.fillRect(0, 0, width, height);
      const oceanGlow = project(166, 17);
      gradient(map, ...oceanGlow, scale * 61, scale * 49, '#2e667c42');
      terrain(map, geography(LAND), state.scene === 'summer', ideal);
      grid(map);

      if (ideal) drawBand(map, season);
      else for (const id of season.centers) pressureShape(map, CENTERS[id]);

      text(map, '亚 欧 大 陆', ...project(75, 65), { size: compact ? 11 : 14, color: '#c3d3ce' });
      text(map, '北 太 平 洋', ...project(174, 5), { size: compact ? 11 : 15, color: '#8fb2c9' });
      text(map, '印 度 洋', ...project(108, -15), { size: compact ? 11 : 15, color: '#8fb2c9' });
      if (!compact) {
        text(map, '青藏高原', ...project(93, 33), { size: 11, color: '#dacaac' });
        text(map, '印度半岛', ...project(72, 12), { size: 11, color: '#b6cabd', align: 'right' });
        text(map, '澳大利亚', ...project(129, -21), { size: 12, color: '#b6cabd' });
      }
      compass(map);
    }

    function arrow(x, y, dx, dy, size, color) {
      const length = Math.hypot(dx, dy);
      if (!length) return;
      const ux = dx / length, uy = dy / length;
      pathLine(ctx, [[x, y], [x - size * ux - size * 0.56 * uy, y - size * uy + size * 0.56 * ux],
        [x - size * 0.73 * ux, y - size * 0.73 * uy],
        [x - size * ux + size * 0.56 * uy, y - size * uy - size * 0.56 * ux]]);
      ctx.closePath();
      ctx.fillStyle = color;
      ctx.fill();
    }

    function drawFlow(path, route, time, main, active) {
      const color = route.color;
      const coords = path.points.map(p => project(p.lon, p.lat));
      pathLine(ctx, coords);
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.globalAlpha = main ? 0.85 : 0.56;
      ctx.strokeStyle = DARK;
      ctx.lineWidth = main ? 7 : 4.5;
      ctx.stroke();
      ctx.strokeStyle = color;
      ctx.lineWidth = main ? (active ? 3.1 : 2.2) : 1.15;
      ctx.globalAlpha = main ? 0.74 : 0.53;
      ctx.stroke();
      ctx.globalAlpha = 1;
      // 在暂停时保留箭头，运动速度只服务于风向阅读。
      for (const f of main ? [0.56, 1] : [1]) {
        const p = project(...pointAt(path, f)), prev = project(...pointAt(path, f - 0.045));
        arrow(...p, p[0] - prev[0], p[1] - prev[1], main ? (compact ? 8 : 13) : 6, color);
      }
      const count = Math.max(2, Math.round(path.total / 15));
      for (let k = 0; k < count; k++) {
        const f = (time * 13 / path.total + k / count) % 1;
        const p = project(...pointAt(path, f)), prev = project(...pointAt(path, Math.max(0, f - 0.05)));
        ctx.globalAlpha = Math.min(1, f * 14, (1 - f) * 14) * (main ? 0.96 : 0.67);
        pathLine(ctx, [prev, p]);
        ctx.lineWidth = main ? 3.1 : 1.65;
        ctx.strokeStyle = '#ecfff9';
        ctx.stroke();
      }
      ctx.globalAlpha = 1;
    }

    function drawCrossing() {
      const [x, y] = project(equatorLon, 0);
      ctx.beginPath();
      ctx.arc(x, y, compact ? 3.5 : 5, 0, Math.PI * 2);
      ctx.strokeStyle = '#c8ffe9';
      ctx.lineWidth = 1.4;
      ctx.stroke();
      text(ctx, '越赤道', x + 9, y + 8, { align: 'left', size: compact ? 10 : 12, color: '#c8ffe9' });
      text(ctx, '东南信风', ...project(80, -15), { size: compact ? 10 : 12, color: '#c8ffe9' });
    }

    function drawCenter(id, state) {
      const center = CENTERS[id], [x, y] = project(...center.pos);
      const color = center.type === '高' ? HIGH : LOW;
      const active = state.selected === id, hover = state.hover === id;
      const r = compact ? 11 : 15;
      if (active || hover) {
        ctx.beginPath();
        ctx.arc(x, y, r + 4, 0, 2 * Math.PI);
        ctx.strokeStyle = active ? '#ffc94a' : '#e0edf5';
        ctx.lineWidth = 1.5;
        ctx.stroke();
      }
      ctx.beginPath();
      ctx.arc(x, y, r, 0, 2 * Math.PI);
      ctx.fillStyle = '#0b1a29';
      ctx.fill();
      ctx.strokeStyle = color;
      ctx.lineWidth = 1.3;
      ctx.stroke();
      text(ctx, center.type, x, y, { color, size: compact ? 12 : 15, halo: 0, weight: 700 });
      const [side, up] = center.label;
      const label = side === 1 ? 'left' : 'center';
      const dx = side === 1 ? r + 5 : 0;
      text(ctx, center.short, x + dx, y + up * (r + 10),
        { color, align: label, size: compact ? 11 : 13, weight: 650 });
      hits.push({ id, x, y, radius: compact ? 23 : 25 });
    }

    function draw(state) {
      if (!width || !height) return;
      const next = state.scene + '/' + state.layer;
      if (key !== next) {
        renderBase(state);
        key = next;
      }
      ctx.drawImage(base, 0, 0, width, height);
      hits = [];
      if (state.layer === 'ideal') return;
      const season = SEASONS[state.scene];
      const routes = season.routes.filter(route => state.region === 'all' || route.region === state.region);
      for (const route of routes) {
        const active = state.selected === route.region || state.hover === route.region;
        route.paths.slice().reverse().forEach((p, i) => drawFlow(p, route, state.time, i === route.paths.length - 1, active));
        text(ctx, compact ? route.compact : route.name, ...project(...route.label),
          { color: route.color, size: compact ? 11 : 15, weight: active ? 750 : 620, halo: 4 });
      }
      if (state.scene === 'summer' && (state.region === 'south' || state.selected === 'south')) drawCrossing();
      for (const id of season.centers) drawCenter(id, state);
    }

    function hit(x, y, state) {
      if (state.layer === 'ideal') return null;
      let chosen = null, closest = 25;
      for (const item of hits) {
        const distance = Math.hypot(item.x - x, item.y - y);
        if (distance > item.radius || distance > closest) continue;
        chosen = item.id;
        closest = distance;
      }
      if (chosen) return chosen;
      for (const route of SEASONS[state.scene].routes) {
        if (state.region !== 'all' && route.region !== state.region) continue;
        for (const path of route.paths) {
          const distance = distanceToPath(path, unproject(x, y)) * scale;
          if (distance < closest) {
            closest = distance;
            chosen = route.region;
          }
        }
      }
      return chosen;
    }

    return { draw, resize, hit, project };
  }

  window.MonsoonDraw = { create };
})();
