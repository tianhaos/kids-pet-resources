(function () {
  const { SEASONS, CENTERS } = window.Monsoon;
  const $ = id => document.getElementById(id);
  const all = selector => [...document.querySelectorAll(selector)];
  const motion = matchMedia('(prefers-reduced-motion: reduce)');
  const mobile = matchMedia('(max-width: 760px)');
  const params = new URLSearchParams(location.search);
  const scenes = ['winter', 'summer'];
  const regions = ['all', 'east', 'south'];
  const scene = scenes.includes(params.get('scene')) ? params.get('scene') : 'winter';
  const region = regions.includes(params.get('region')) ? params.get('region') : 'all';
  const requested = params.get('focus');
  const validFocus = SEASONS[scene].centers.includes(requested) ||
    (requested === 'east' || requested === 'south') && (region === 'all' || region === requested);
  const state = {
    scene, region,
    selected: validFocus ? requested : region === 'all' ? null : region,
    layer: params.get('layer') === 'ideal' ? 'ideal' : 'season',
    playing: params.get('play') === '1' || (params.get('play') !== '0' && !motion.matches),
    hover: null, time: 0.66
  };
  const canvas = $('map');
  const draw = window.MonsoonDraw.create(canvas);
  let dirty = true, previousTime = 0, renderedScene;

  function track(action, item) {
    window.Analytics?.track('亚洲季风成因', action, item);
  }

  function pressed(button, on) {
    button.classList.toggle('on', on);
    button.setAttribute('aria-pressed', on);
  }

  function centerButtons(season) {
    const buttons = season.centers.map(id => {
      const center = CENTERS[id];
      const button = document.createElement('button');
      button.type = 'button';
      button.dataset.center = id;
      const symbol = document.createElement('span');
      symbol.className = center.type === '高' ? 'pressure' : 'pressure low';
      symbol.textContent = center.type;
      symbol.setAttribute('aria-hidden', 'true');
      button.append(symbol, center.name);
      button.addEventListener('click', () => select(id));
      return button;
    });
    $('centerButtons').replaceChildren(...buttons);
  }

  function update() {
    const season = SEASONS[state.scene], ideal = state.layer === 'ideal';
    const route = season.routes.find(item => item.region === state.selected);
    const center = season.centers.includes(state.selected) ? CENTERS[state.selected] : null;
    all('[data-scene]').forEach(el => pressed(el, el.dataset.scene === state.scene));
    all('[data-region]').forEach(el => pressed(el, el.dataset.region === state.region));
    all('[data-trace]').forEach(el => pressed(el,
      !ideal && el.dataset.month === state.scene && el.dataset.trace === state.selected));
    if (state.scene !== renderedScene) {
      centerButtons(season);
      renderedScene = state.scene;
    }
    all('[data-center]').forEach(el => pressed(el, !ideal && el.dataset.center === state.selected));
    pressed($('layer'), ideal);
    $('layer').textContent = ideal ? '返回海陆分布' : '对照理想气压带';
    pressed($('play'), state.playing);
    $('play').textContent = state.playing ? '暂停风迹' : '播放风迹';
    $('play').disabled = ideal;
    $('mapNote').textContent = ideal ? '地表均匀 · 理想示意' : '近地面示意 · 点高低压或风线';
    $('thermal').className = 'thermal ' + state.scene;
    $('landTemp').textContent = season.land;
    $('seaTemp').textContent = season.water;
    $('obsTitle').textContent = ideal ? season.band : center?.name || route?.name || season.name;
    $('obsLead').textContent = ideal ? '假设地表均匀，气压大致沿纬线连续分布' :
      center ? '近地面气压中心' : route?.source || season.land + ' · ' + season.water;
    $('obsDetail').textContent = ideal ? season.compare : center?.detail || route?.detail || season.cause;
    canvas.setAttribute('aria-label', ideal ? season.name + '，' + season.band + '示意图' :
      season.name + '，亚洲近地面气压中心和' + season.routes.filter(item =>
        state.region === 'all' || item.region === state.region).map(item => item.name).join('、') + '示意地图');
    dirty = true;
  }

  function setScene(next) {
    if (next === state.scene || !scenes.includes(next)) return;
    state.scene = next;
    state.hover = null;
    if (state.selected !== 'east' && state.selected !== 'south') {
      state.selected = state.region === 'all' ? null : state.region;
    }
    track('切换季节', next);
    update();
  }

  function setRegion(next) {
    state.region = next;
    state.selected = next === 'all' ? null : next;
    state.layer = 'season';
    state.hover = null;
    track('查看季风区域', next);
    update();
  }

  function select(id) {
    if (mobile.matches && !$('panel').classList.contains('collapsed')) setPanel(false);
    state.layer = 'season';
    state.selected = id;
    track('地图探测', id);
    update();
  }

  function setPanel(open) {
    const panel = $('panel');
    if (!open && panel.contains(document.activeElement) && mobile.matches) $('panelToggle').focus();
    panel.classList.toggle('collapsed', !open);
    $('panelToggle').setAttribute('aria-expanded', open);
    $('panelToggle').textContent = open ? '收起面板' : '☰ 实验面板';
  }

  function stateURL() {
    const url = new URL(location.pathname, location.origin);
    url.searchParams.set('scene', state.scene);
    if (state.region !== 'all') url.searchParams.set('region', state.region);
    if (state.layer === 'ideal') url.searchParams.set('layer', 'ideal');
    if (state.selected && state.selected !== state.region) url.searchParams.set('focus', state.selected);
    url.searchParams.set('play', state.playing ? '1' : '0');
    return url.href;
  }

  function getHit(event) {
    const rect = canvas.getBoundingClientRect();
    return draw.hit(event.clientX - rect.left, event.clientY - rect.top, state);
  }

  all('[data-scene]').forEach(el => el.addEventListener('click', () => setScene(el.dataset.scene)));
  all('[data-region]').forEach(el => el.addEventListener('click', () => setRegion(el.dataset.region)));
  all('[data-trace]').forEach(el => el.addEventListener('click', () => {
    setScene(el.dataset.month);
    setRegion(el.dataset.trace);
    if (mobile.matches) setPanel(false);
  }));
  $('layer').addEventListener('click', () => {
    state.layer = state.layer === 'season' ? 'ideal' : 'season';
    state.hover = null;
    track('对照气压带', state.layer);
    update();
  });
  $('play').addEventListener('click', () => {
    state.playing = !state.playing;
    update();
  });
  $('panelToggle').addEventListener('click', () => setPanel($('panel').classList.contains('collapsed')));
  $('share').addEventListener('click', async () => {
    const url = stateURL(), status = $('shareStatus');
    try {
      await navigator.clipboard.writeText(url);
      status.textContent = '已复制';
    } catch {
      const input = document.createElement('input');
      input.value = url;
      input.readOnly = true;
      input.setAttribute('aria-label', '当前场景链接');
      status.replaceChildren(input);
      input.select();
    }
    track('分享场景', state.scene);
  });
  canvas.addEventListener('pointermove', event => {
    const id = getHit(event);
    if (state.hover === id) return;
    state.hover = id;
    canvas.classList.toggle('interactive', Boolean(id));
    dirty = true;
  });
  canvas.addEventListener('pointerleave', () => {
    state.hover = null;
    canvas.classList.remove('interactive');
    dirty = true;
  });
  canvas.addEventListener('click', event => {
    const id = getHit(event);
    if (id) select(id);
  });
  motion.addEventListener('change', event => {
    state.playing = !event.matches;
    update();
  });
  mobile.addEventListener('change', () => setPanel(false));

  function resize() {
    draw.resize();
    dirty = true;
  }

  new ResizeObserver(resize).observe(canvas);
  resize();
  update();

  function frame(time) {
    const animating = state.playing && state.layer === 'season';
    if (animating && previousTime) state.time += Math.min(0.05, (time - previousTime) / 1000);
    if (dirty || animating) {
      draw.draw(state);
      dirty = false;
    }
    previousTime = time;
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
  window.__model = { state, setScene, setRegion, update, stateURL, project: draw.project };
})();
