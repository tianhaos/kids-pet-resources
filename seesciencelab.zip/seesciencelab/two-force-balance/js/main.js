(function () {
  'use strict';
  const B = window.Balance, D = window.BalanceDraw, $ = id => document.getElementById(id), q = new URLSearchParams(location.search);
  const scene = B.scenes[q.get('scene')] ? q.get('scene') : 'balance';
  const state = Object.assign({ scene: scene, t: 0, v0: 0, play: false, lines: true, ghost: true, chart: false }, B.scenes[scene]);
  function num(key, fallback, lo, hi) { const v = Number(q.get(key)); return q.has(key) && Number.isFinite(v) ? B.clamp(v, lo, hi) : fallback; }
  for (const key of ['fL', 'fR']) state[key] = num(key, state[key], 1, 4);
  for (const key of ['yL', 'yR']) state[key] = num(key, state[key] * 100, -18, 18) / 100;
  state.t = num('t', 0, 0, B.duration); state.v0 = num('v0', 0, 0, 0.5);
  if (q.has('same')) state.same = q.get('same') === '1';
  state.play = q.get('play') === '1'; state.lines = q.get('lines') !== '0'; state.ghost = q.get('ghost') !== '0';
  const canvas = $('balance'); D.init(canvas);
  function track(action, label) { if (window.Analytics) window.Analytics.track('二力平衡', action, String(label)); }
  function sync() {
    const p = B.at(state, state.t), c = B.conditions(state), ok = B.balanced(state);
    $('status').textContent = ok ? '满足二力平衡条件' : '不满足二力平衡条件';
    $('netRead').textContent = p.net.toFixed(2) + ' N（向右为正）';
    $('speedRead').textContent = p.vx.toFixed(2) + ' m/s';
    $('angleRead').textContent = (p.angle * 180 / Math.PI).toFixed(1) + '°';
    $('torqueRead').textContent = p.torque.toFixed(3) + ' N·m';
    $('stageTime').value = state.t; $('stageTimeOut').textContent = state.t.toFixed(2) + ' s';
    $('stageResult').textContent = state.t >= B.duration ? (Math.abs(p.vx) + Math.abs(p.omega) < 1e-8 ? '观察结束 · 卡片保持静止；重做可回到初态' : '观察结束 · 卡片仍将继续运动；重做可回到初态') : '0.25 倍慢放 · 拖动时间条，逐帧观察';
    const matches = preset => ['fL', 'fR', 'yL', 'yR', 'same'].every(k => preset[k] === state[k]);
    $('sceneNote').textContent = matches(B.scenes[state.scene]) ? B.scenes[state.scene].note : '已自定义条件。观察作用线，再播放检验。';
    $('explain').textContent = ok ? '初始角速度为零：平衡时保持静止或匀速直线运动。' : (Math.abs(p.net) < 1e-7 ? '两力合力为零，但作用线错开会改变转动状态。' : '合力不为零，质心速度发生变化；偏心施力还可能转动。');
    $('conditions').innerHTML = [['同一物体', true], ['大小相等', c.equal], ['方向相反', c.opposite], ['初始共线', c.collinear]].map(v => '<span class="' + (v[1] ? 'yes' : 'no') + '">' + (v[1] ? '✓ ' : '× ') + v[0] + '</span>').join('');
    for (const key of ['fL', 'fR', 'yL', 'yR', 'v0', 'time']) {
      const v = key === 'time' ? state.t : key[0] === 'y' ? state[key] * 100 : state[key];
      $(key).value = v; $(key + 'Out').textContent = v.toFixed(key[0] === 'y' ? 0 : 2);
    }
    for (const key of ['same', 'lines', 'ghost']) $(key).checked = state[key];
    $('play').textContent = $('stagePlay').textContent = state.play ? '❚❚ 暂停' : '▶ 播放';
    document.querySelectorAll('[data-scene]').forEach(el => { el.classList.toggle('on', matches(B.scenes[el.dataset.scene])); el.setAttribute('aria-pressed', matches(B.scenes[el.dataset.scene])); });
  }
  function update() { sync(); D.draw(state); }
  function reset() { state.t = 0; state.play = false; update(); }
  function setScene(key) { if (!B.scenes[key]) return; Object.assign(state, B.scenes[key], { scene: key, t: 0, play: false }); update(); track('切换实验', key); }
  function setTime(t) { state.t = B.clamp(t, 0, B.duration); state.play = false; update(); }
  function play() { if (state.t >= B.duration) state.t = 0; state.play = !state.play; update(); track('播放暂停', state.play); }
  document.querySelectorAll('[data-scene]').forEach(el => el.onclick = () => setScene(el.dataset.scene));
  for (const key of ['fL', 'fR', 'yL', 'yR', 'v0']) {
    $(key).oninput = () => { state[key] = Number($(key).value) / (key[0] === 'y' ? 100 : 1); reset(); };
    $(key).onchange = () => track('改变条件', key);
  }
  $('chartToggle').onclick = () => { state.chart = !state.chart; $('chartToggle').setAttribute('aria-pressed', state.chart); update(); };
  $('stageTime').oninput = () => setTime(Number($('stageTime').value));
  $('stageTime').onchange = () => track('时间探测', state.t.toFixed(2));
  $('time').oninput = () => setTime(Number($('time').value)); $('time').onchange = () => track('时间探测', state.t.toFixed(2));
  $('same').onchange = () => { state.same = $('same').checked; reset(); track('方向', state.same ? '同向' : '反向'); };
  for (const key of ['lines', 'ghost']) $(key).onchange = () => { state[key] = $(key).checked; update(); track('显示', key); };
  $('play').onclick = $('stagePlay').onclick = play;
  $('reset').onclick = $('stageReset').onclick = () => { reset(); track('重做实验', state.scene); };
  $('align').onclick = () => { state.yL = state.yR = 0; reset(); track('施力点归中', '共线'); };
  $('share').onclick = async () => {
    const params = new URLSearchParams({ scene: state.scene, fL: state.fL, fR: state.fR, yL: (state.yL * 100).toFixed(2), yR: (state.yR * 100).toFixed(2), same: +state.same, v0: state.v0, t: state.t.toFixed(3), play: 0, lines: +state.lines, ghost: +state.ghost });
    const url = new URL(location.href); url.search = params.toString(); url.hash = '';
    try { await navigator.clipboard.writeText(url.href); $('shareNote').textContent = '已复制当前条件与时刻'; } catch { $('shareNote').textContent = url.href; }
    track('复制链接', state.scene);
  };
  if (innerWidth <= 760) $('panel').classList.add('collapsed');
  $('panelToggle').onclick = () => { const hidden = $('panel').classList.toggle('collapsed'); $('panelToggle').setAttribute('aria-expanded', !hidden); };
  let drag = null;
  function pos(e) { const r = canvas.getBoundingClientRect(); return { x: e.clientX - r.left, y: e.clientY - r.top }; }
  function move(e) {
    const z = pos(e);
    if (drag) {
      if (drag.type === 'point') { state[drag.index ? 'yR' : 'yL'] = Math.round(D.localY(z.y) * 100) / 100; reset(); }
      else setTime(D.timeFromX(z.x));
    } else { const v = D.hit(z.x, z.y); D.setHover(v && v.type === 'point' ? v.index : null); canvas.style.cursor = v ? 'grab' : 'default'; }
  }
  canvas.onpointerdown = e => {
    const z = pos(e); drag = D.hit(z.x, z.y); if (!drag) return;
    e.preventDefault();
    // 编辑施力点总在初态进行，避免把旋转后的世界y误当成卡片局部y。
    if (drag.type === 'point') reset();
    canvas.setPointerCapture(e.pointerId); canvas.style.cursor = 'grabbing';
    if (drag.type === 'time') move(e);
  };
  canvas.onpointermove = move;
  function end(e) { if (!drag) return; track('画面拖动', drag.type); drag = null; D.setHover(null); if (canvas.hasPointerCapture(e.pointerId)) canvas.releasePointerCapture(e.pointerId); canvas.style.cursor = 'grab'; }
  canvas.onpointerup = end; canvas.onpointercancel = end; canvas.onpointerleave = () => { if (!drag) D.setHover(null); };
  document.addEventListener('keydown', e => { if (e.code === 'Space' && !/INPUT|BUTTON|SELECT|TEXTAREA/.test(document.activeElement.tagName)) { e.preventDefault(); play(); } });
  let last;
  function frame(now) { if (last !== undefined && state.play) { state.t = Math.min(B.duration, state.t + Math.min(0.05, (now - last) / 1000) * 0.25); if (state.t >= B.duration) state.play = false; } last = now; update(); requestAnimationFrame(frame); }
  window.__model = { state: state, setScene: setScene, setTime: setTime, update: update, play: play };
  update(); requestAnimationFrame(frame);
}());
