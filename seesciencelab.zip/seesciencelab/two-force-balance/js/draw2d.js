/* 俯视实验台。舞台按屏宽缩放；卡片、施力点、作用线来自同一世界坐标。 */
(function () {
  'use strict';
  const B = window.Balance, gold = '#ffc94a', blue = '#6bd8ff';
  let canvas, ctx, w, h, scale, ox, oy, hitPoints = [], chart;
  let hover = null;
  function init(el) { canvas = el; ctx = canvas.getContext('2d'); }
  function resize(s) {
    const r = canvas.getBoundingClientRect(), d = Math.min(devicePixelRatio || 1, 2);
    w = r.width; h = r.height;
    if (canvas.width !== Math.round(w * d) || canvas.height !== Math.round(h * d)) { canvas.width = Math.round(w * d); canvas.height = Math.round(h * d); }
    ctx.setTransform(d, 0, 0, d, 0, 0);
    const top = w < 600 ? 171 : 194, bottom = h - (s.chart ? (w < 600 ? 375 : 345) : (w < 600 ? 205 : 175));
    scale = Math.max(35, Math.min((w - 42) / (w < 600 ? 2.15 : 3.8), (bottom - top - 50) / 1.15));
    ox = w / 2; oy = (top + bottom) / 2 + 8;
  }
  function xy(x, y) { return { x: ox + x * scale, y: oy - y * scale }; }
  function line(x1, y1, x2, y2, color, width, dash) {
    ctx.strokeStyle = color; ctx.lineWidth = width || 1; ctx.setLineDash(dash || []);
    ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke(); ctx.setLineDash([]);
  }
  function text(str, x, y, size, color, align) { ctx.font = (size || 13) + 'px -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif'; ctx.fillStyle = color || '#e4edf0'; ctx.textAlign = align || 'left'; ctx.fillText(str, x, y); }
  function round(x, y, ww, hh, r, fill, stroke) { ctx.beginPath(); ctx.roundRect(x, y, ww, hh, r); if (fill) { ctx.fillStyle = fill; ctx.fill(); } if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = 1; ctx.stroke(); } }
  function arrow(x, y, dx, color) {
    line(x, y, x + dx, y, color, 3);
    ctx.fillStyle = color; ctx.beginPath(); ctx.moveTo(x + dx, y); ctx.lineTo(x + dx - Math.sign(dx) * 9, y - 5); ctx.lineTo(x + dx - Math.sign(dx) * 9, y + 5); ctx.closePath(); ctx.fill();
  }
  function card(x, angle, ghost) {
    const p = xy(x, 0); ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(-angle);
    const ww = B.width * scale, hh = B.height * scale;
    if (ghost) { ctx.globalAlpha = 0.35; ctx.setLineDash([5, 5]); round(-ww / 2, -hh / 2, ww, hh, 5, null, '#e6dfb7'); }
    else {
      ctx.shadowColor = '#0008'; ctx.shadowBlur = 13; ctx.shadowOffsetY = 7;
      const gr = ctx.createLinearGradient(0, -hh / 2, 0, hh / 2); gr.addColorStop(0, '#f6d58b'); gr.addColorStop(1, '#bc8c3e');
      round(-ww / 2, -hh / 2, ww, hh, 5, gr, '#fff0c4'); ctx.shadowBlur = 0; ctx.shadowOffsetY = 0;
      for (let i = -2; i <= 2; i++) line(-ww * 0.37, i * hh / 7, ww * 0.37, i * hh / 7, '#8c703c30');
      ctx.fillStyle = '#574f35'; ctx.beginPath(); ctx.arc(0, 0, 3, 0, Math.PI * 2); ctx.fill();
      if (ww > 90) text('同一物体', 0, hh * 0.33, 11, '#594626', 'center');
    }
    ctx.restore();
  }
  function gauge(p, dir, f, color, side) {
    const length = f * (w < 600 ? 12 : 27);
    const end = p.x + dir * (length + (w < 600 ? 18 : 24)), gaugeW = w < 600 ? 28 : 48;
    const showGauge = !(side === 'F₂' && dir < 0);
    if (showGauge) {
      line(p.x, p.y, end + dir * gaugeW, p.y, '#ddd5b2', 2);
      const gx = dir > 0 ? end : end - gaugeW;
      round(gx, p.y - 12, gaugeW, 24, 6, '#273748', '#6b7d8e');
      for (let i = 1; i < 8; i++) line(gx + gaugeW * i / 8, p.y - 8, gx + gaugeW * i / 8, p.y + (i % 2 ? -2 : 3), '#a7b6c4');
      line(gx + gaugeW * (0.15 + f / 5 * 0.7), p.y - 8, gx + gaugeW * (0.15 + f / 5 * 0.7), p.y + 8, '#bc473d', 2);
    }
    arrow(p.x, p.y, dir * length, color);
    const tx = B.clamp(p.x + dir * (length / 2 + 14), 45, w - 45);
    text(side + ' ' + f.toFixed(1) + ' N', tx, p.y + (side === 'F₁' ? -27 : (dir < 0 ? B.height * scale / 2 + 22 : 35)), 14, color, 'center');
  }
  function chartDraw(s) {
    const top = h - (w < 600 ? 325 : 295), left = 44, right = w - 28, bottom = top + 85;
    if (bottom - top < 48) { chart = null; return; }
    round(16, top - 37, w - 32, bottom - top + 76, 12, '#102332e6', '#416072');
    text('运动记录', 30, top - 18, 12, '#cfdfdf');
    text('实线：位置x / m    虚线：转角θ / rad', 30, bottom + 27, w < 600 ? 11 : 12, '#a5bcc8');
    const mid = (top + bottom) / 2, amp = (bottom - top) / 6;
    line(left, mid, right, mid, '#617c86', 1); line(left, top, left, bottom, '#617c86');
    for (const v of [-3, 0, 3]) text(String(v), left - 8, mid - v * amp + 4, 10, '#97b3c0', 'right');
    for (const tick of [0, 0.4, 0.8, 1.2]) { const x = left + tick / B.duration * (right - left); line(x, top, x, bottom, '#45616e45'); text(tick.toFixed(1), x, bottom + 10, 10, '#97b3c0', 'center'); }
    text('t / s', right, top - 8, 11, '#a5bcc8', 'right');
    for (const key of ['x', 'angle']) {
      ctx.beginPath(); ctx.strokeStyle = key === 'x' ? blue : gold; ctx.lineWidth = 2; ctx.setLineDash(key === 'x' ? [] : [5, 4]);
      for (let i = 0; i <= 60; i++) { const t = s.t * i / 60, p = B.at(s, t), x = left + t / B.duration * (right - left), y = mid - B.clamp(p[key], -3, 3) * amp; if (i) ctx.lineTo(x, y); else ctx.moveTo(x, y); }
      ctx.stroke(); ctx.setLineDash([]);
    }
    const probe = left + s.t / B.duration * (right - left); line(probe, top, probe, bottom, '#fff9', 1);
    chart = { left: left, right: right, top: top - 15, bottom: bottom + 15 };
  }
  function draw(s) {
    resize(s); const p = B.at(s, s.t);
    // 超出中心视野时相机跟随，保持最大拉力下卡片与测力计可见。
    const follow = Math.abs(p.x) > 0.15 ? p.x - Math.sign(p.x) * 0.15 : 0;
    ox -= follow * scale;
    ctx.fillStyle = '#05070d'; ctx.fillRect(0, 0, w, h);
    const tableTop = w < 600 ? 161 : 177, tableBottom = h - (s.chart ? (w < 600 ? 370 : 335) : (w < 600 ? 200 : 165));
    const wood = ctx.createLinearGradient(0, tableTop, 0, tableBottom); wood.addColorStop(0, '#101a27'); wood.addColorStop(1, '#0a111d');
    round(12, tableTop, w - 24, tableBottom - tableTop, 17, wood, '#28394d');
    ctx.save(); ctx.beginPath(); ctx.roundRect(13, tableTop, w - 26, tableBottom - tableTop, 17); ctx.clip();
    for (let x = -3; x <= 3; x += 0.2) { const a = xy(x, 0); line(a.x, tableTop, a.x, tableBottom, '#8da8cd12'); }
    for (let y = -1.5; y < 1.5; y += 0.2) { const a = xy(0, y); line(13, a.y, w - 13, a.y, '#8da8cd12'); }
    for (let i = 0; i < 18; i++) { const yy = tableTop + i * 17; line(13, yy, w - 13, yy + 5 * Math.sin(i), '#8da8cd04'); }
    if (s.ghost) card(0, 0, true);
    if (s.lines) for (let i = 0; i < 2; i++) { const z = xy(p.x + p.points[i].x, p.points[i].y); line(16, z.y, w - 16, z.y, i ? '#6bd8ff88' : '#ffc94a88', 1, [6, 5]); }
    card(p.x, p.angle, false);
    hitPoints = p.points.map(z => xy(p.x + z.x, z.y));
    gauge(hitPoints[0], -1, s.fL, gold, 'F₁'); gauge(hitPoints[1], s.same ? -1 : 1, s.fR, blue, 'F₂');
    hitPoints.forEach((z, i) => {
      ctx.fillStyle = i ? blue : gold; ctx.strokeStyle = '#f7fbff'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(z.x, z.y, hover === i ? 11 : 8, 0, 2 * Math.PI); ctx.fill(); ctx.stroke();
      if (s.t === 0) { ctx.beginPath(); ctx.arc(z.x, z.y, 20, 0, Math.PI * 2); ctx.strokeStyle = (i ? '#6bd8ff' : '#ffc94a') + '66'; ctx.stroke(); }
    });
    const center = xy(p.x, 0); text('●', center.x, center.y + 5, 10, '#504d36', 'center');
    ctx.restore();
    if (!s.chart) {
      const rulerY = tableBottom + 19;
      line(27, rulerY, w - 27, rulerY, '#63858a');
      for (let xx = -2; xx <= 2; xx += 0.5) { const z = xy(xx, 0); if (z.x < 25 || z.x > w - 25) continue; line(z.x, rulerY - 4, z.x, rulerY + 4, '#8eacaf'); text(xx.toFixed(1), z.x, rulerY + 16, 10, '#9bb9bf', 'center'); }
      text('x / m', w - 23, rulerY - 9, 11, '#9bb9bf', 'right');
    }
    const balanced = B.balanced(s);
    text(balanced ? (s.v0 ? '平衡：仍在匀速运动' : '平衡：保持静止') : (Math.abs(p.net) < 1e-7 ? '合力为零，仍会转动' : '不平衡：运动状态改变'), w / 2, tableTop + 26, 14, balanced ? '#b5e9c9' : '#ffe0aa', 'center');
    chart = null;
    if (s.chart) chartDraw(s);
    const metricsY = tableBottom - 19;
    text('x  ' + p.x.toFixed(2) + ' m', w / 2 - 64, metricsY, 12, blue, 'center');
    text('θ  ' + (p.angle * 180 / Math.PI).toFixed(1) + '°', w / 2 + 64, metricsY, 12, gold, 'center');
  }
  function hit(x, y) {
    for (let i = 0; i < hitPoints.length; i++) if (Math.hypot(x - hitPoints[i].x, y - hitPoints[i].y) < 25) return { type: 'point', index: i };
    if (chart && x >= chart.left - 15 && x <= chart.right + 15 && y >= chart.top && y <= chart.bottom) return { type: 'time' };
    return null;
  }
  function localY(y) { return B.clamp((oy - y) / scale, -0.18, 0.18); }
  function timeFromX(x) { return chart ? B.clamp((x - chart.left) / (chart.right - chart.left) * B.duration, 0, B.duration) : 0; }
  window.BalanceDraw = { init: init, draw: draw, hit: hit, localY: localY, timeFromX: timeFromX, setHover(i) { hover = i; }, geometry() { return { points: hitPoints, ox: ox, oy: oy, scale: scale, chart: chart }; } };
}());
