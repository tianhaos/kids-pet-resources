/* 水平面刚体：米、秒、牛顿；x右、y上，逆时针为正。 */
(function () {
  'use strict';
  const width = 0.72, height = 0.40, mass = 2;
  const inertia = mass * (width * width + height * height) / 12;
  const duration = 1.2;
  const scenes = {
    balance: { title: '等大 · 反向 · 共线', note: '两力作用在同一卡片上。先预测，再播放。', fL: 2, fR: 2, yL: 0, yR: 0, same: false },
    unequal: { title: '只改变右侧大小', note: '保持反向、共线，只把右侧拉力改成3 N。', fL: 2, fR: 3, yL: 0, yR: 0, same: false },
    offset: { title: '等大反向 · 不共线', note: '合力为零，卡片会保持原来的朝向吗？', fL: 2, fR: 2, yL: 0.12, yR: -0.12, same: false },
    same: { title: '等大 · 同向', note: '两个拉力都向左，大小相等就能平衡吗？', fL: 2, fR: 2, yL: 0, yR: 0, same: true }
  };
  const clamp = (x, a, b) => Math.max(a, Math.min(b, x));
  function rotate(x, y, angle) { return { x: x * Math.cos(angle) - y * Math.sin(angle), y: x * Math.sin(angle) + y * Math.cos(angle) }; }
  function points(s, angle) { return [rotate(-width / 2, s.yL, angle), rotate(width / 2, s.yR, angle)]; }
  function forces(s, angle) {
    const p = points(s, angle), right = s.same ? -s.fR : s.fR;
    return { net: right - s.fL, torque: s.fL * p[0].y - right * p[1].y, gap: Math.abs(p[0].y - p[1].y) };
  }
  // 四阶Runge–Kutta积分角运动；每次从相同初态重算，拖动时间不积累误差。
  function at(s, time, maxStep) {
    const t = clamp(time, 0, duration), n = Math.max(1, Math.ceil(t / (maxStep || 0.004))), h = t / n;
    let angle = 0, omega = 0;
    const accel = a => forces(s, a).torque / inertia;
    for (let i = 0; i < n; i++) {
      const a1 = omega, w1 = accel(angle);
      const a2 = omega + w1 * h / 2, w2 = accel(angle + a1 * h / 2);
      const a3 = omega + w2 * h / 2, w3 = accel(angle + a2 * h / 2);
      const a4 = omega + w3 * h, w4 = accel(angle + a3 * h);
      angle += h * (a1 + 2 * a2 + 2 * a3 + a4) / 6;
      omega += h * (w1 + 2 * w2 + 2 * w3 + w4) / 6;
    }
    const f = forces(s, angle), ax = f.net / mass;
    return { t: t, x: s.v0 * t + ax * t * t / 2, vx: s.v0 + ax * t, angle: angle, omega: omega, ax: ax, net: f.net, torque: f.torque, gap: f.gap, points: points(s, angle) };
  }
  function conditions(s) {
    return { equal: Math.abs(s.fL - s.fR) < 1e-8, opposite: !s.same, collinear: Math.abs(s.yL - s.yR) < 1e-8, centered: Math.abs(s.yL) < 1e-8 && Math.abs(s.yR) < 1e-8 };
  }
  function balanced(s) { const c = conditions(s); return c.equal && c.opposite && c.collinear; }
  window.Balance = { width: width, height: height, mass: mass, inertia: inertia, duration: duration, scenes: scenes, clamp: clamp, rotate: rotate, forces: forces, at: at, conditions: conditions, balanced: balanced };
}());
