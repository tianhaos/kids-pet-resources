// 浮力计算：液面高度、排开液体体积、浮力与重力、溢水杯溢出、弹簧测力计示数、浮沉动力学
// 单位：长度 cm、体积 cm³、密度 g/cm³、力 N，取 g = 10 N/kg，所以 G = ρV/100、F浮 = ρ液V排/100
(function () {
  var GK = 10;

  var LIQUIDS = {
    alcohol: { name: '酒精', rho: 0.8, color: '#9fd8ff' },
    water: { name: '水', rho: 1.0, color: '#4fa8e8' },
    salt: { name: '盐水', rho: 1.2, color: '#5fc4c0' },
    mercury: { name: '水银', rho: 13.6, color: '#c7ccd6' }
  };
  // 称重法用的金属块（底面积 S = 10 cm² 的长方体，体积 50 或 100 cm³）
  var METALS = {
    al: { name: '铝块', rho: 2.7, color: '#c9d1dc' },
    fe: { name: '铁块', rho: 7.9, color: '#7f8896' },
    cu: { name: '铜块', rho: 8.9, color: '#d08a4f' }
  };
  // 浮沉条件用的物体（棱长 6 cm 的正方体，鸡蛋为椭球）
  var OBJECTS = {
    wood: { name: '木块', rho: 0.6, color: '#c8975a', shape: 'cube' },
    ice: { name: '冰块', rho: 0.9, color: '#d8f0ff', shape: 'cube' },
    egg: { name: '鸡蛋', rho: 1.1, color: '#f1dfc4', shape: 'egg' },
    al: { name: '铝块', rho: 2.7, color: '#c9d1dc', shape: 'cube' },
    fe: { name: '铁块', rho: 7.9, color: '#7f8896', shape: 'cube' },
    custom: { name: '自定义', rho: 1.0, color: '#ffc94a', shape: 'cube' }
  };

  // 溢水杯：杯内底面积 120 cm²（画面宽 12 cm），杯深 16 cm，溢水口高 13 cm；小桶底面积 30 cm²，重 0.4 N
  var CUP = { A: 120, w: 12, h: 16, spout: 13 };
  var BUCKET = { A: 30, w: 5, h: 7, G: 0.4 };
  var PRISM_S = 10, PRISM_W = Math.sqrt(10);
  var TOP0 = 18;          // 称重法：物体抬起时下表面离杯底的高度
  var DMAX = TOP0 + 2;    // 下降距离上限；超过 TOP0 后物体压在杯底
  // 大烧杯：底面积 288 cm²（画面宽 24 cm），深 26 cm，原有液体 16 cm 深
  var BEAKER = { A: 288, w: 24, h: 26, level0: 16 };
  var CUBE = 6, EGG_R = 3.2, EGG_B = 4.2;

  // 形状：V 体积，sub(d) 下表面浸入深度为 d 时浸在液体里的体积，h 高度，w 画面宽度
  function prism(S, H) { return { kind: 'prism', S: S, h: H, w: Math.sqrt(S), V: S * H, sub: function (d) { return S * clamp(d, 0, H); } }; }
  function cube(a) { return { kind: 'cube', S: a * a, h: a, w: a, V: a * a * a, sub: function (d) { return a * a * clamp(d, 0, a); } }; }
  function egg(r, b) {   // 竖直半轴 b、水平半轴 r 的椭球：浸入深度 z 的“冠”体积 π r² z²(3b − z) / (3b²)
    return { kind: 'egg', S: Math.PI * r * r, h: 2 * b, w: 2 * r, r: r, b: b, V: 4 / 3 * Math.PI * r * r * b,
      sub: function (d) { var z = clamp(d, 0, 2 * b); return Math.PI * r * r * z * z * (3 * b - z) / (3 * b * b); } };
  }
  function shapeOf(id) { return OBJECTS[id] && OBJECTS[id].shape === 'egg' ? egg(EGG_R, EGG_B) : cube(CUBE); }

  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
  function weight(rho, V) { return rho * V * GK / 1000; }
  function buoyant(rhoL, Vsub) { return rhoL * Vsub * GK / 1000; }

  // 容器底面积 A、液体体积 Vw、物体下表面高度 yb：A·L = Vw + sub(L − yb)，二分求液面 L
  function level(A, Vw, shape, yb) {
    var lo = 0, hi = (Vw + shape.V) / A + 1e-9;
    for (var i = 0; i < 60; i++) {
      var m = (lo + hi) / 2;
      if (A * m - shape.sub(m - yb) < Vw) lo = m; else hi = m;
    }
    var L = (lo + hi) / 2;
    return { L: L, Vsub: shape.sub(L - yb) };
  }

  // 溢水杯：液面超过溢水口的部分流进小桶。返回新的杯内液体体积、液面、V排、本次溢出体积
  function overflow(Vw, shape, yb) {
    var r = level(CUP.A, Vw, shape, yb), out = 0;
    if (r.L > CUP.spout) {
      var Vsub = shape.sub(CUP.spout - yb), Vin = CUP.A * CUP.spout - Vsub;
      out = Vw - Vin; Vw = Vin; r = { L: CUP.spout, Vsub: Vsub };
    }
    return { Vw: Vw, L: r.L, Vsub: r.Vsub, out: Math.max(0, out) };
  }

  // 称重法：下降距离 d → 物体下表面高度与压在杯底的“多下降量”
  function hang(d) { var yb = TOP0 - d; return { yb: Math.max(0, yb), press: Math.max(0, -yb) }; }
  // 测力计示数：F示 = G − F浮；物体压在杯底后细线变松，示数继续减小（杯底给物体支持力）
  function scaleRead(G, Fb, press) {
    var F = G - Fb, N = 0;
    if (press > 0) { N = Math.min(F, F * press / (DMAX - TOP0)); F -= N; }
    return { F: Math.max(0, F), N: N };
  }
  // 理论 F-h 图像（溢水杯装满、液面不变）：h 为下表面浸入液面以下的深度
  function curve(G, rhoL, shape, h) { var Fb = buoyant(rhoL, shape.sub(h)); return { F: G - Fb, Fb: Fb }; }

  // 浮沉判断（物体浸没时）：ρ物 < ρ液 上浮，最终漂浮；= 悬浮；> 下沉，最终沉底
  function fate(rhoO, rhoL) {
    var e = 1e-9;
    if (rhoO < rhoL - e) return 'float';
    if (rhoO > rhoL + e) return 'sink';
    return 'suspend';
  }
  // 漂浮时 V排 / V物 = ρ物 / ρ液（正方体即浸入深度之比）
  function floatRatio(rhoO, rhoL) { return Math.min(1, rhoO / rhoL); }

  // 浮沉动力学：obj = { y 下表面高度, v 速度 cm/s }，液体体积 Vw 一定。为了看得清，
  // 加速度按真实值的 SLOW 倍计算，并加上较大的黏滞阻尼。返回各力，供画箭头。
  var SLOW = 0.12, DAMP = 3.2;
  function forces(rhoO, rhoL, shape, Vw, y) {
    var r = level(BEAKER.A, Vw, shape, y), G = weight(rhoO, shape.V), Fb = buoyant(rhoL, r.Vsub);
    return { L: r.L, Vsub: r.Vsub, G: G, Fb: Fb, N: y <= 1e-6 ? Math.max(0, G - Fb) : 0 };
  }
  function step(obj, rhoO, rhoL, shape, Vw, dt) {
    var n = Math.max(1, Math.ceil(dt / 0.004)), h = dt / n;
    for (var i = 0; i < n; i++) {
      var f = forces(rhoO, rhoL, shape, Vw, obj.y), m = rhoO * shape.V / 1000;   // kg
      var a = (f.Fb - f.G) / m * 100 * SLOW - DAMP * obj.v;                        // cm/s²
      obj.v += a * h; obj.y += obj.v * h;
      if (obj.y <= 0) { obj.y = 0; if (obj.v < 0) obj.v = 0; }
      var top = BEAKER.h + 6 - shape.h;
      if (obj.y > top) { obj.y = top; if (obj.v > 0) obj.v = 0; }
    }
    return forces(rhoO, rhoL, shape, Vw, obj.y);
  }
  // 运动状态的文字：上浮 / 下沉 / 漂浮 / 悬浮 / 沉底
  function phase(f, v, shape, y) {
    if (y <= 1e-6 && f.G > f.Fb + 1e-6) return 'bottom';
    if (Math.abs(v) < 0.2 && Math.abs(f.Fb - f.G) < 0.01 * f.G + 1e-3) return f.Vsub >= shape.V - 1e-3 ? 'suspend' : 'floating';
    if (v) return v > 0 ? 'rise' : 'fall';
    return f.Fb > f.G ? 'rise' : 'fall';
  }
  var PHASE = { rise: '上浮', fall: '下沉', floating: '漂浮', suspend: '悬浮', bottom: '沉底' };

  window.Buoy = {
    GK: GK, LIQUIDS: LIQUIDS, METALS: METALS, OBJECTS: OBJECTS, CUP: CUP, BUCKET: BUCKET, BEAKER: BEAKER,
    PRISM_S: PRISM_S, PRISM_W: PRISM_W, TOP0: TOP0, DMAX: DMAX, CUBE: CUBE, PHASE: PHASE,
    prism: prism, cube: cube, egg: egg, shapeOf: shapeOf, clamp: clamp, weight: weight, buoyant: buoyant,
    level: level, overflow: overflow, hang: hang, scaleRead: scaleRead, curve: curve,
    fate: fate, floatRatio: floatRatio, forces: forces, step: step, phase: phase
  };
})();
