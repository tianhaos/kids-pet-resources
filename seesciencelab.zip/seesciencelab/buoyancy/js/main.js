(function () {
  var B = window.Buoy;
  var $ = function (id) { return document.getElementById(id); };
  var qa = function (sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); };
  var NAME = '浮力';
  var MAXROWS = 10, VW0 = B.BEAKER.A * B.BEAKER.level0;

  var SCENES = {
    weigh: { name: '阿基米德原理', hint: '上下拖动弹簧测力计，让物体慢慢浸入溢水杯 · 看示数、F-h 图像和小桶里的水',
      note: '用称重法测浮力：F浮 = G − F示；溢出的液体流进小桶，G排 = G总 − G桶。比较 F浮 和 G排，并改变液体、物体、浸入深度，探究浮力的大小与哪些因素有关。' },
    sink: { name: '物体的浮沉条件', hint: '拖动物体放到液体中任意位置再松手 · 改变物体或液体的密度',
      note: '把物体浸没在液体中再松手：比较浮力和重力（或物体和液体的密度），看物体上浮、下沉还是悬浮，最后停在什么状态。' }
  };

  var state = {
    scene: 'weigh', showForces: true, hover: null, dragging: false,
    metal: 'al', vol: 100, liquid: 'water', notFull: false, d: 0, Vw: 0, Vout: 0, pour: 0, trace: [],
    obj: 'wood', rhoO: 0.6, rhoL: 1.0, liqS: 'water', sim: { y: 4, v: 0 }, held: false,
    dataBy: { weigh: [] }
  };
  var info = {};

  var stage = $('stage'), canvas = $('buoy'), panel = $('panel');
  var view = window.BuoyDraw(canvas);

  function setSeg(attr, val) { qa('[data-' + attr + ']').forEach(function (b) { b.classList.toggle('on', b.dataset[attr] === String(val)); }); }
  function fmt(v, d) { return (+v.toFixed(d == null ? 2 : d)).toString(); }
  function esc(s) { return String(s).replace(/[&<>]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]; }); }
  function sinkLiqName() {
    var hit = Object.keys(B.LIQUIDS).filter(function (k) { return Math.abs(B.LIQUIDS[k].rho - state.rhoL) < 1e-9; })[0];
    return hit ? B.LIQUIDS[hit].name : '液体';
  }

  // ---------- 称重法 ----------
  function prismShape() { return B.prism(B.PRISM_S, state.vol / B.PRISM_S); }
  function fullVw() { return B.CUP.A * B.CUP.spout - (state.notFull ? B.CUP.A * 1.2 : 0); }
  function refill() { state.Vw = fullVw(); state.Vout = 0; state.trace = []; state.pour = 0; }
  function setD(d) {
    state.d = B.clamp(d, 0, B.DMAX);
    var h = B.hang(state.d), r = B.overflow(state.Vw, prismShape(), h.yb);
    state.Vw = r.Vw; state.Vout += r.out;
    if (r.out > 1e-6) state.pour = 0.5;
    update();
    var t = state.trace, last = t[t.length - 1];
    if (!last || Math.abs(last.h - info.h) > 0.04 || Math.abs(last.F - info.F) > 0.01) { t.push({ h: info.h, F: info.F, Fb: info.Fb }); if (t.length > 800) t.shift(); }
  }

  function compute() {
    var st = state;
    if (st.scene === 'weigh') {
      var sh = prismShape(), metal = B.METALS[st.metal], liq = B.LIQUIDS[st.liquid], hg = B.hang(st.d);
      var lv = B.level(B.CUP.A, st.Vw, sh, hg.yb), G = B.weight(metal.rho, sh.V), Fb = B.buoyant(liq.rho, lv.Vsub);
      var sr = B.scaleRead(G, Fb, hg.press);
      info = { shape: sh, metal: metal, liq: liq, yb: hg.yb, press: hg.press, L: lv.L, Vsub: lv.Vsub, G: G, Fb: Fb, F: sr.F, N: sr.N,
        h: Math.max(0, lv.L - hg.yb), Vout: st.Vout, Gp: B.buoyant(liq.rho, st.Vout), Fcalc: G - sr.F };
    } else {
      var ob = B.OBJECTS[st.obj], s2 = B.shapeOf(st.obj), f = B.forces(st.rhoO, st.rhoL, s2, VW0, st.sim.y);
      info = { shape: s2, obj: ob, f: f, phase: B.phase(f, st.sim.v, s2, st.sim.y), fate: B.fate(st.rhoO, st.rhoL), liqName: sinkLiqName() };
    }
  }
  function update() { compute(); syncPanel(); }

  // ---------- 记录数据（称重法） ----------
  function canRecord() {
    if (state.dataBy.weigh.length >= MAXROWS) return '最多记录 ' + MAXROWS + ' 组，先清除数据';
    if (info.Vsub < 0.01) return '物体还没有浸入液体';
    if (info.press > 0) return '物体碰到杯底了，示数不准，稍微往上提一点';
    return '';
  }
  function record() {
    var why = canRecord();
    if (why) { flash(why); return; }
    var d = { liq: info.liq.name, obj: info.metal.name, V: state.vol, h: +info.h.toFixed(1), full: info.Vsub >= info.shape.V - 1e-6, Vsub: +info.Vsub.toFixed(1),
      G: info.G, F: info.F, Fb: info.Fcalc, Gp: info.Gp, rho: info.liq.rho, mrho: info.metal.rho };
    var rows = state.dataBy.weigh, last = rows[rows.length - 1];
    if (last && JSON.stringify(last) === JSON.stringify(d)) { flash('和上一组一样，改变深度、液体或物体再记录'); return; }
    rows.push(d);
    Analytics.track(NAME, '记录数据', d.liq + d.obj);
    syncPanel();
  }
  var flashT = 0;
  function flash(msg) { $('recMsg').textContent = msg; clearTimeout(flashT); flashT = setTimeout(function () { $('recMsg').textContent = ''; }, 2600); }

  function summary(d) {
    var s = [], eq = function (a, b) { return Math.abs(a - b) < 0.005; };
    if (!d.length) return '';
    if (d.length >= 2 && d.every(function (r) { return eq(r.Fb, r.Gp); })) s.push('<p>每一组都有 F浮 = G排：<b>浸在液体中的物体受到向上的浮力，浮力的大小等于它排开的液体所受的重力</b>（阿基米德原理）。</p>');
    if (d.some(function (r) { return r.Gp < r.Fb - 0.005; })) s.push('<p class="bad">有的组 G排 &lt; F浮：溢水杯没有装满，或者物体提起过、溢水杯里的液体不满了。</p>');
    function pair(test) { for (var i = 0; i < d.length; i++) for (var j = i + 1; j < d.length; j++) if (test(d[i], d[j])) return [d[i], d[j]]; return null; }
    var p;
    if ((p = pair(function (a, b) { return a.liq === b.liq && a.obj === b.obj && a.V === b.V && a.full && b.full && Math.abs(a.h - b.h) > 0.5; })))
      s.push('<p>浸没后改变深度（' + p[0].h + ' cm、' + p[1].h + ' cm），浮力都是 ' + fmt(p[0].Fb) + ' N：<b>浮力与物体浸没的深度无关</b>。</p>');
    if ((p = pair(function (a, b) { return a.liq === b.liq && a.obj === b.obj && a.V === b.V && Math.abs(a.Vsub - b.Vsub) > 1; })))
      s.push('<p>同种液体中，V排 越大浮力越大（' + fmt(p[0].Vsub, 0) + ' cm³ → ' + fmt(p[0].Fb) + ' N，' + fmt(p[1].Vsub, 0) + ' cm³ → ' + fmt(p[1].Fb) + ' N）：<b>浮力与物体排开液体的体积有关</b>。</p>');
    if ((p = pair(function (a, b) { return a.liq !== b.liq && Math.abs(a.Vsub - b.Vsub) < 0.5; })))
      s.push('<p>V排 相同时，' + p[0].liq + '中 ' + fmt(p[0].Fb) + ' N、' + p[1].liq + '中 ' + fmt(p[1].Fb) + ' N：<b>液体的密度越大，浮力越大</b>。</p>');
    if ((p = pair(function (a, b) { return a.liq === b.liq && a.obj !== b.obj && Math.abs(a.Vsub - b.Vsub) < 0.5; })))
      s.push('<p>' + p[0].obj + '和' + p[1].obj + '重力不同，V排 相同时浮力都是 ' + fmt(p[0].Fb) + ' N：<b>浮力与物体的密度、重力无关</b>。</p>');
    if (d.length < 3 && !s.length) s.push('<p class="muted">改变浸入深度、液体或物体，多记录几组再比较。</p>');
    return s.join('');
  }

  // ---------- 读数、提示 ----------
  function notes() {
    var n = [], st = state, warn = false;
    if (st.scene === 'weigh') {
      var full = info.Vsub >= info.shape.V - 1e-6;
      if (info.Vsub < 0.01) n.push('物体在液面上方：测力计示数等于物重，G = ' + fmt(info.G) + ' N。向下拖动测力计，让物体慢慢浸入液体。');
      else if (!full) n.push('物体部分浸入：浸入越深，排开液体的体积越大，浮力越大，示数越小。F浮 = G − F示 = ' + fmt(info.Fcalc) + ' N。');
      else if (!info.press) n.push('物体已浸没：V排 = V物 = ' + st.vol + ' cm³ 不再变化，继续下降示数也不变——浮力与浸没的深度无关。');
      if (info.press > 0) { warn = true; n.push('物体碰到了杯底：杯底对物体有支持力 N，测力计示数偏小，用 G − F示 算出的“浮力”' + fmt(info.Fcalc) + ' N 比真实浮力 ' + fmt(info.Fb) + ' N 偏大。'); }
      if (info.Vsub > 0.01) n.push('F浮 = ρ液 g V排 = ' + fmt(info.liq.rho * 1000, 0) + ' kg/m³ × 10 N/kg × ' + fmt(info.Vsub, 1) + '×10⁻⁶ m³ = ' + fmt(info.Fb) + ' N。');
      if (st.notFull && info.Vsub > 0.01 && info.Gp < info.Fb - 0.005) { warn = true; n.push('溢水杯没有装满：排开的液体先要把液面抬到溢水口，这部分没有流进小桶，所以测得的 G排 = ' + fmt(info.Gp) + ' N 偏小。'); }
      else if (!st.notFull && st.Vw < fullVw() - 0.5 && info.Gp > info.Fb + 0.005) { warn = true; n.push('物体被提起过：小桶里的液体比现在排开的多，溢水杯也不满了。点“重新装满”再做。'); }
    } else {
      var f = info.f, ro = st.rhoO, rl = st.rhoL, fa = info.fate, ph = info.phase;
      var cmp = fa === 'float' ? '<' : fa === 'sink' ? '>' : '=';
      var FbFull = B.buoyant(rl, info.shape.V);
      n.push('浸没时：F浮 = ρ液 g V物 = ' + fmt(FbFull) + ' N，G = ρ物 g V物 = ' + fmt(f.G) + ' N。ρ物 ' + cmp + ' ρ液，F浮 ' + (fa === 'float' ? '>' : fa === 'sink' ? '<' : '=') + ' G，物体' +
        (fa === 'float' ? '上浮，最终漂浮在液面上。' : fa === 'sink' ? '下沉，最终沉到底部。' : '悬浮，可以停留在液体中任何深度。'));
      if (st.held) n.push('手' + (f.G > f.Fb ? '托着物体：F手 = G − F浮' : '把物体按住：F手 = F浮 − G') + ' = ' + fmt(Math.abs(f.G - f.Fb - (st.sim.y <= 1e-6 ? f.N : 0))) + ' N。松手后看它怎样运动。');
      else if (ph === 'floating') n.push('漂浮：F浮 = G = ' + fmt(f.G) + ' N，V排 / V物 = ρ物 / ρ液 = ' + fmt(ro / rl) + '，有 ' + Math.round((1 - ro / rl) * 100) + '% 露出液面。');
      else if (ph === 'suspend') n.push('悬浮：F浮 = G，V排 = V物，物体完全浸没，可以停在任意深度。悬浮和漂浮都是 F浮 = G，但漂浮时 V排 < V物。');
      else if (ph === 'bottom') n.push('沉底：F浮 + N = G，支持力 N = ' + fmt(f.N) + ' N。浸没后浮力 F浮 = ' + fmt(f.Fb) + ' N 不随深度变化。');
      else if (ph === 'rise' && f.Vsub >= info.shape.V - 1e-3) n.push('上浮过程中，露出液面之前 V排 不变，浮力不变；开始露出液面后 V排 减小，浮力减小，直到 F浮 = G。');
      if (st.obj === 'fe' && rl > 7.9) n.push('铁块在水银里也能漂浮：浮沉取决于物体与液体密度的大小关系，不是“重的物体就下沉”。');
      if (st.obj === 'egg' && fa === 'sink') n.push('试试“加一勺盐”：盐水的密度变大，鸡蛋受到的浮力变大，会慢慢浮起来。');
    }
    return { list: n, warn: warn };
  }

  function syncPanel() {
    var st = state, sc = SCENES[st.scene], big = '', dl = [];
    setSeg('scene', st.scene); setSeg('metal', st.metal); setSeg('vol', st.vol); setSeg('liquid', st.liquid);
    setSeg('obj', st.obj); setSeg('liqs', Object.keys(B.LIQUIDS).filter(function (k) { return Math.abs(B.LIQUIDS[k].rho - st.rhoL) < 1e-9; })[0] || '');
    qa('[data-for]').forEach(function (el) { el.hidden = el.dataset.for.split(' ').indexOf(st.scene) < 0; });
    if (st.scene === 'weigh') {
      big = '<span class="fb">F浮 = <b>' + fmt(info.Fcalc) + '</b> N</span><span class="gp">G排 = <b>' + fmt(info.Gp) + '</b> N</span>';
      dl = [['物重 G', fmt(info.G) + ' N'], ['测力计示数 F示', fmt(info.F) + ' N'], ['浸入深度 h', fmt(info.h, 1) + ' cm'], ['V排', fmt(info.Vsub, 1) + ' cm³'],
        ['空桶重 G桶', fmt(B.BUCKET.G) + ' N'], ['桶和液体总重 G总', fmt(B.BUCKET.G + info.Gp) + ' N']];
    } else {
      var f = info.f, ph = st.held ? '手拿着' : B.PHASE[info.phase];
      big = '<span class="st">' + ph + '</span><span class="fb">F浮 = <b>' + fmt(f.Fb) + '</b> N</span><span class="g">G = <b>' + fmt(f.G) + '</b> N</span>';
      dl = [['物体密度 ρ物', fmt(st.rhoO) + ' g/cm³'], ['液体密度 ρ液', fmt(st.rhoL) + ' g/cm³'], ['物体体积 V物', fmt(info.shape.V, 0) + ' cm³'],
        ['排开体积 V排', fmt(f.Vsub, 0) + ' cm³（' + Math.round(f.Vsub / info.shape.V * 100) + '%）'], ['杯底支持力 N', st.held ? '—' : fmt(f.N) + ' N']];
    }
    $('rBig').innerHTML = big;
    $('rDl').innerHTML = dl.map(function (d) { return '<dt>' + d[0] + '</dt><dd>' + d[1] + '</dd>'; }).join('');
    var nn = notes();
    $('rNotes').innerHTML = nn.list.map(function (t) { return '<li>' + esc(t) + '</li>'; }).join('');
    $('rNotes').hidden = !nn.list.length;
    $('rNotes').className = nn.warn ? 'warn' : '';
    $('sceneNote').textContent = sc.note;
    $('hint').textContent = sc.hint;
    $('dRange').value = Math.round(st.d * 10); $('dOut').textContent = fmt(st.d, 1) + ' cm';
    $('notFull').checked = st.notFull; $('showForces').checked = st.showForces;
    $('rhoORange').value = Math.round(Math.min(st.rhoO, 2) * 100); $('rhoOOut').textContent = fmt(st.rhoO) + ' g/cm³';
    $('rhoLRange').value = Math.round(Math.min(st.rhoL, 1.6) * 100); $('rhoLOut').textContent = fmt(st.rhoL) + ' g/cm³';
    $('saltBtn').disabled = st.rhoL >= 1.3 - 1e-9;
    if (st.scene === 'weigh') syncTable();
  }
  function syncTable() {
    var d = state.dataBy.weigh;
    var head = '<th>#</th><th>液体</th><th>物体</th><th>h/cm</th><th>F示/N</th><th>F浮/N</th><th>G排/N</th>';
    var rows = d.map(function (r, i) {
      return '<tr><td>' + (i + 1) + '</td><td>' + r.liq + '</td><td>' + r.obj.replace('块', '') + r.V + '</td><td>' + r.h + (r.full ? '' : '*') + '</td><td>' + fmt(r.F) + '</td><td>' + fmt(r.Fb) + '</td><td' + (Math.abs(r.Fb - r.Gp) > 0.005 ? ' class="bad"' : '') + '>' + fmt(r.Gp) + '</td></tr>';
    });
    $('dataTable').innerHTML = '<thead><tr>' + head + '</tr></thead><tbody>' + (rows.length ? rows.join('') : '<tr><td colspan="7" class="muted">还没有数据</td></tr>') + '</tbody>';
    $('dataSum').innerHTML = (d.some(function (r) { return !r.full; }) ? '<p class="muted">* 部分浸入</p>' : '') + summary(d);
  }

  // ---------- 场景 ----------
  function resetWeigh() { state.d = 0; refill(); setD(0); }
  function loadScene(name) {
    state.scene = SCENES[name] ? name : 'weigh';
    state.hover = null; state.dragging = false; state.held = false;
    if (state.scene === 'weigh') resetWeigh();
    else { state.sim = { y: 4, v: 0 }; update(); }
  }
  function setObj(id) {
    state.obj = B.OBJECTS[id] ? id : 'wood';
    if (state.obj !== 'custom') state.rhoO = B.OBJECTS[state.obj].rho;
    B.OBJECTS.custom.rho = state.rhoO;
    release();
  }
  function setLiqS(id) { state.rhoL = B.LIQUIDS[id].rho; state.liqS = id; release(); }
  function release() { state.held = false; state.sim = { y: 4, v: 0 }; update(); }   // 浸没在液体中部后松手

  // ---------- 画布交互 ----------
  var drag = null;
  function pos(e) { var r = canvas.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; }
  canvas.addEventListener('pointerdown', function (e) {
    var p = pos(e), h = view.hit(state, info, p[0], p[1]);
    if (!h) return;
    var w = view.unP(p[0], p[1]);
    if (h === 'rig') drag = { kind: 'rig', y0: w[1], d0: state.d };
    else { drag = { kind: 'obj', y0: w[1], s0: state.sim.y }; state.held = true; state.sim.v = 0; }
    state.dragging = true;
    try { canvas.setPointerCapture(e.pointerId); } catch (err) {}
    e.preventDefault();
  });
  canvas.addEventListener('pointermove', function (e) {
    var p = pos(e), w = view.unP(p[0], p[1]);
    if (drag) {
      if (drag.kind === 'rig') setD(drag.d0 + (drag.y0 - w[1]));
      else { state.sim.y = B.clamp(drag.s0 + w[1] - drag.y0, 0, B.BEAKER.h + 6 - info.shape.h); state.sim.v = 0; update(); }
      return;
    }
    state.hover = view.hit(state, info, p[0], p[1]);
    canvas.style.cursor = state.hover ? (state.hover === 'rig' ? 'ns-resize' : 'grab') : 'default';
  });
  function up() {
    if (!drag) return;
    var k = drag.kind; drag = null; state.dragging = false;
    if (k === 'obj') { state.held = false; Analytics.track(NAME, '松手', B.OBJECTS[state.obj].name); }
    else Analytics.track(NAME, '拖动测力计', B.METALS[state.metal].name);
    update();
  }
  canvas.addEventListener('pointerup', up);
  canvas.addEventListener('pointercancel', up);
  canvas.addEventListener('pointerleave', function () { if (!drag) state.hover = null; });

  // ---------- 面板控件 ----------
  qa('[data-scene]').forEach(function (b) { b.addEventListener('click', function () { loadScene(b.dataset.scene); Analytics.track(NAME, '场景', SCENES[state.scene].name); }); });
  qa('[data-metal]').forEach(function (b) { b.addEventListener('click', function () { state.metal = b.dataset.metal; resetWeigh(); Analytics.track(NAME, '物体', b.textContent); }); });
  qa('[data-vol]').forEach(function (b) { b.addEventListener('click', function () { state.vol = +b.dataset.vol; resetWeigh(); Analytics.track(NAME, '体积', b.textContent); }); });
  qa('[data-liquid]').forEach(function (b) { b.addEventListener('click', function () { state.liquid = b.dataset.liquid; resetWeigh(); Analytics.track(NAME, '液体', b.textContent); }); });
  qa('[data-obj]').forEach(function (b) { b.addEventListener('click', function () { setObj(b.dataset.obj); Analytics.track(NAME, '浮沉物体', b.textContent); }); });
  qa('[data-liqs]').forEach(function (b) { b.addEventListener('click', function () { setLiqS(b.dataset.liqs); Analytics.track(NAME, '浮沉液体', b.textContent); }); });
  $('dRange').addEventListener('input', function () { setD($('dRange').value / 10); });
  $('notFull').addEventListener('change', function () { state.notFull = $('notFull').checked; resetWeigh(); Analytics.track(NAME, '溢水杯未装满', String(state.notFull)); });
  $('refill').addEventListener('click', function () { resetWeigh(); });
  $('recBtn').addEventListener('click', record);
  $('clearBtn').addEventListener('click', function () { state.dataBy.weigh.length = 0; syncPanel(); Analytics.track(NAME, '清除数据'); });
  $('rhoORange').addEventListener('input', function () { state.obj = 'custom'; state.rhoO = $('rhoORange').value / 100; B.OBJECTS.custom.rho = state.rhoO; state.held = false; update(); });
  $('rhoLRange').addEventListener('input', function () { state.rhoL = $('rhoLRange').value / 100; state.liqS = 'custom'; update(); });
  $('saltBtn').addEventListener('click', function () { state.rhoL = Math.min(1.3, Math.round((state.rhoL + 0.05) * 100) / 100); state.liqS = 'custom'; update(); Analytics.track(NAME, '加盐'); });
  $('releaseBtn').addEventListener('click', function () { release(); Analytics.track(NAME, '浸没后松手'); });
  $('surfBtn').addEventListener('click', function () { state.held = false; state.sim = { y: info.f.L + 0.2, v: 0 }; update(); });
  $('showForces').addEventListener('change', function () { state.showForces = $('showForces').checked; });

  // ---------- 面板开合 ----------
  $('panelToggle').addEventListener('click', function () { panel.classList.toggle('collapsed'); });
  if (window.matchMedia('(max-width: 760px)').matches) panel.classList.add('collapsed');

  function resize() { view.resize(stage.clientWidth, stage.clientHeight); }
  new ResizeObserver(resize).observe(stage);
  resize();

  // 演示数据：水中铝块浸入 5 cm、刚好浸没、浸没 12 cm，再换盐水、换铜块（溢水杯装满时 h = d − 5）
  function demo() {
    function at(d) { refill(); for (var x = 0; x < d; x += 0.5) setD(x); setD(d); record(); }
    state.metal = 'al'; state.vol = 100; state.liquid = 'water'; state.notFull = false;
    at(10); at(15); at(17);
    state.liquid = 'salt'; at(17);
    state.liquid = 'water'; state.metal = 'cu'; at(17);
    state.metal = 'al'; resetWeigh();
  }

  // 支持 ?scene=weigh|sink、&metal=al|fe|cu、&vol=50|100、&liquid=alcohol|water|salt、&d=0~20、&notfull=1、&demo=1、
  // &obj=wood|ice|egg|al|fe|custom、&rho=物体密度、&liq=alcohol|water|salt|mercury、&rhol=液体密度、&y=物体下表面高度（cm，手拿着）、&forces=0
  var qs = new URLSearchParams(location.search);
  if (B.METALS[qs.get('metal')]) state.metal = qs.get('metal');
  if (qs.get('vol') === '50') state.vol = 50;
  if (B.LIQUIDS[qs.get('liquid')] && qs.get('liquid') !== 'mercury') state.liquid = qs.get('liquid');
  if (qs.get('notfull') === '1') state.notFull = true;
  if (qs.get('forces') === '0') state.showForces = false;
  loadScene(qs.get('scene') || 'weigh');
  if (state.scene === 'weigh') {
    if (qs.get('demo') === '1') demo();
    if (qs.get('d') != null && isFinite(+qs.get('d'))) { var dd = B.clamp(+qs.get('d'), 0, B.DMAX); for (var x = 0; x < dd; x += 0.25) setD(x); setD(dd); }
  } else {
    if (B.OBJECTS[qs.get('obj')]) setObj(qs.get('obj'));
    if (qs.get('rho') != null && isFinite(+qs.get('rho')) && +qs.get('rho') > 0) { state.obj = qs.get('obj') && qs.get('obj') !== 'custom' && B.OBJECTS[qs.get('obj')] ? state.obj : 'custom'; state.rhoO = B.clamp(+qs.get('rho'), 0.1, 20); B.OBJECTS.custom.rho = state.rhoO; }
    if (B.LIQUIDS[qs.get('liq')]) setLiqS(qs.get('liq'));
    if (qs.get('rhol') != null && isFinite(+qs.get('rhol')) && +qs.get('rhol') > 0) { state.rhoL = B.clamp(+qs.get('rhol'), 0.5, 20); state.liqS = 'custom'; }
    if (qs.get('y') != null && isFinite(+qs.get('y'))) { state.held = true; state.sim.y = B.clamp(+qs.get('y'), 0, B.BEAKER.h); }
    else if (qs.get('settle') === '1') for (var i = 0; i < 600; i++) B.step(state.sim, state.rhoO, state.rhoL, B.shapeOf(state.obj), VW0, 1 / 30);
    update();
  }

  var lastT = performance.now(), panelT = 0;
  function frame(t) {
    var dt = Math.min((t - lastT) / 1000, 0.05);
    lastT = t;
    if (state.scene === 'weigh') { if (state.pour > 0) state.pour -= dt; }
    else if (!state.held) {
      B.step(state.sim, state.rhoO, state.rhoL, info.shape, VW0, dt);
      compute();
      panelT += dt; if (panelT > 0.15) { panelT = 0; syncPanel(); }
    }
    view.draw(state, info);
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // 调试用
  window.__model = { state: state, info: function () { return info; }, view: view, Buoy: B, load: loadScene, update: update, setD: setD, record: record, demo: demo, release: release };
})();
