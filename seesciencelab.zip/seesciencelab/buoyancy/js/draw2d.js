// 浮力绘图：称重法（弹簧测力计、溢水杯、小桶、F-h 图像）、浮沉条件（大烧杯、物体、受力示意图）
// 世界坐标用 cm（y 向上，桌面 y = 0），fit() 缩放进画面；F-h 图像画在画面右侧（窄而高时画在下方）
(function () {
  var B = window.Buoy, TAU = Math.PI * 2;
  var C = { text: '#e6ebf2', muted: '#8d99ab', line: '#2a3446', accent: '#ffc94a', glass: 'rgba(190,215,240,0.55)',
    G: '#ff7b6b', Fb: '#4fc3f7', T: '#7ee081', N: '#c9a7ff', hand: '#e6ebf2', table: '#2b3446', metal: '#cfd6e2' };

  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
  function hex2rgb(h) { var n = parseInt(h.slice(1), 16); return [n >> 16 & 255, n >> 8 & 255, n & 255]; }
  function rgba(h, a) { var c = hex2rgb(h); return 'rgba(' + c[0] + ',' + c[1] + ',' + c[2] + ',' + a + ')'; }

  function BuoyDraw(canvas) {
    var ctx = canvas.getContext('2d'), W = 0, H = 0, dpr = 1, L = {}, M = null;

    function resize(w, h) {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      W = w; H = h;
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
      canvas.style.width = w + 'px'; canvas.style.height = h + 'px';
      L.narrow = W <= 760; L.top = L.narrow ? 84 : 52; L.bottom = L.narrow ? 46 : 50;
    }
    function fit(box, area) {
      var s = Math.min(area[2] / (box[2] - box[0]), area[3] / (box[3] - box[1]));
      M = { s: s, ox: area[0] + (area[2] - s * (box[2] - box[0])) / 2 - box[0] * s, oy: area[1] + (area[3] + s * (box[3] - box[1])) / 2 + box[1] * s };
    }
    function P(x, y) { return [M.ox + x * M.s, M.oy - y * M.s]; }
    function unP(x, y) { return [(x - M.ox) / M.s, (M.oy - y) / M.s]; }

    function font(px, w) { ctx.font = (w || '') + ' ' + Math.round(px) + 'px -apple-system, "PingFang SC", "Microsoft YaHei", sans-serif'; }
    function text(s, x, y, col, align, px, w) { font(px, w); ctx.fillStyle = col; ctx.textAlign = align || 'center'; ctx.textBaseline = 'middle'; ctx.fillText(s, x, y); }
    function tag(s, x, y, col, px, align) {
      font(px || 13, '600'); var w = ctx.measureText(s).width + 10, h = (px || 13) + 8;
      var x0 = align === 'left' ? x : align === 'right' ? x - w : x - w / 2;
      ctx.fillStyle = 'rgba(11,15,24,0.82)'; rrect(x0, y - h / 2, w, h, 5); ctx.fill();
      text(s, x0 + w / 2, y, col, 'center', px || 13, '600');
    }
    function line(x1, y1, x2, y2) { ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke(); }
    function rrect(x, y, w, h, r) {
      ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r);
      ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
    }
    function wrect(x0, y0, x1, y1) { var a = P(x0, y1), b = P(x1, y0); ctx.beginPath(); ctx.rect(a[0], a[1], b[0] - a[0], b[1] - a[1]); }
    function arrow(x1, y1, x2, y2, col, w) {
      var a = Math.atan2(y2 - y1, x2 - x1), h = 10, l = Math.hypot(x2 - x1, y2 - y1);
      if (l < 2) return;
      ctx.strokeStyle = col; ctx.fillStyle = col; ctx.lineWidth = w || 3; ctx.lineCap = 'round';
      if (l > h) line(x1, y1, x2 - Math.cos(a) * h * 0.7, y2 - Math.sin(a) * h * 0.7);
      ctx.beginPath(); ctx.moveTo(x2, y2);
      ctx.lineTo(x2 - Math.cos(a - 0.42) * h, y2 - Math.sin(a - 0.42) * h);
      ctx.lineTo(x2 - Math.cos(a + 0.42) * h, y2 - Math.sin(a + 0.42) * h); ctx.closePath(); ctx.fill();
    }
    function dot(x, y, r, col) { ctx.fillStyle = col; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill(); }

    function table(x0, x1) {
      var a = P(x0, 0), b = P(x1, 0);
      ctx.fillStyle = C.table; ctx.fillRect(a[0], a[1], b[0] - a[0], Math.max(6, 0.8 * M.s));
      ctx.strokeStyle = '#46526a'; ctx.lineWidth = 1.5; line(a[0], a[1], b[0], b[1]);
    }
    // 容器：内壁 x0~x1、深 h；spout 为溢水口高度（右壁）
    function vessel(x0, x1, h, spout) {
      var t = 0.35, s = M.s;
      ctx.strokeStyle = C.glass; ctx.lineWidth = Math.max(1.5, t * s); ctx.lineJoin = 'round';
      var a = P(x0 - t / 2, h), b = P(x0 - t / 2, -t / 2), c = P(x1 + t / 2, -t / 2), d = P(x1 + t / 2, spout ? spout - 0.6 : h);
      ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); ctx.lineTo(c[0], c[1]); ctx.lineTo(d[0], d[1]); ctx.stroke();
      if (spout) {   // 溢水口：右壁开口接一段斜向下的短管
        var e = P(x1 + t / 2, spout + 0.6), f = P(x1 + t / 2, h);
        ctx.beginPath(); ctx.moveTo(e[0], e[1]); ctx.lineTo(f[0], f[1]); ctx.stroke();
        var p1 = P(x1, spout + 0.6), p2 = P(x1 + 2.6, spout - 0.2), p3 = P(x1, spout - 0.6), p4 = P(x1 + 2.6, spout - 1.2);
        ctx.lineWidth = Math.max(1.2, 0.25 * s);
        line(p1[0], p1[1], p2[0], p2[1]); line(p3[0], p3[1], p4[0], p4[1]);
      }
    }
    // 液体：先画后层（不透明度低），物体画完再盖一层，浸在液体中的部分看起来在水里
    function liquidBack(x0, x1, lv, col) { wrect(x0, 0, x1, lv); ctx.fillStyle = rgba(col, 0.32); ctx.fill(); }
    function liquidFront(x0, x1, lv, col) {
      wrect(x0, 0, x1, lv); ctx.fillStyle = rgba(col, 0.28); ctx.fill();
      var a = P(x0, lv), b = P(x1, lv); ctx.strokeStyle = rgba(col, 0.95); ctx.lineWidth = 2; line(a[0], a[1], b[0], b[1]);
    }
    function liquidColor(rho, id) {
      if (B.LIQUIDS[id] && Math.abs(B.LIQUIDS[id].rho - rho) < 1e-9) return B.LIQUIDS[id].color;
      if (rho > 5) return B.LIQUIDS.mercury.color;
      var k = clamp((rho - 0.7) / 0.6, 0, 1), c0 = hex2rgb('#a9dcff'), c1 = hex2rgb('#3fb7a8');
      var c = c0.map(function (v, i) { return Math.round(v + (c1[i] - v) * k); });
      return '#' + c.map(function (v) { return (v < 16 ? '0' : '') + v.toString(16); }).join('');
    }
    // 物体：正方体/长方体或椭球（鸡蛋）
    function body(shape, cx, yb, col) {
      if (shape.kind === 'egg') {
        var c = P(cx, yb + shape.b), rx = shape.r * M.s, ry = shape.b * M.s;
        var g = ctx.createRadialGradient(c[0] - rx * 0.35, c[1] - ry * 0.4, rx * 0.1, c[0], c[1], ry);
        g.addColorStop(0, '#fff8ec'); g.addColorStop(1, col);
        ctx.fillStyle = g; ctx.beginPath(); ctx.ellipse(c[0], c[1], rx, ry, 0, 0, TAU); ctx.fill();
        ctx.strokeStyle = 'rgba(0,0,0,0.25)'; ctx.lineWidth = 1; ctx.stroke();
        return;
      }
      var a = P(cx - shape.w / 2, yb + shape.h), b = P(cx + shape.w / 2, yb);
      var gr = ctx.createLinearGradient(a[0], 0, b[0], 0);
      gr.addColorStop(0, col); gr.addColorStop(0.45, '#ffffff'); gr.addColorStop(1, col);
      ctx.globalAlpha = 1; ctx.fillStyle = col; ctx.fillRect(a[0], a[1], b[0] - a[0], b[1] - a[1]);
      ctx.globalAlpha = 0.18; ctx.fillStyle = gr; ctx.fillRect(a[0], a[1], b[0] - a[0], b[1] - a[1]); ctx.globalAlpha = 1;
      ctx.strokeStyle = 'rgba(0,0,0,0.35)'; ctx.lineWidth = 1; ctx.strokeRect(a[0] + 0.5, a[1] + 0.5, b[0] - a[0] - 1, b[1] - a[1] - 1);
    }
    // 力的示意图：从物体中心（或底面）出发，长度按 k px/N
    function force(x, y, F, dir, col, label, k, side) {
      if (F < 1e-4) return;
      var len = Math.max(12, F * k), y2 = y - dir * len;
      arrow(x, y, x, y2, col, 3);
      tag(label, x + (side || 1) * 8, y2 + dir * 4, col, 12, (side || 1) > 0 ? 'left' : 'right');
    }

    // ======================= 称重法 =======================
    function weighLayout() {
      var top = L.top, bot = H - L.bottom, avail = bot - top;
      var side = W >= 640 || W > avail * 0.9;
      var gw, gh, area;
      if (side) {
        gw = clamp(W * 0.4, 200, 420); gh = Math.min(gw * 0.85, avail * 0.6);
        area = [12, top, W - gw - 36, avail];
        L.graph = { x: W - gw - 16, y: top + 8, w: gw, h: gh };
      } else {
        gh = clamp(avail * 0.3, 140, 230); gw = W - 32;
        area = [12, top, W - 24, avail - gh - 16];
        L.graph = { x: 16, y: bot - gh, w: gw, h: gh };
      }
      fit([-8.5, -1, 15, 50.5], area);
    }
    function drawWeigh(st, info) {
      weighLayout();
      var sh = info.shape, liq = info.liq, col = liquidColor(liq.rho, st.liquid), CUP = B.CUP, BK = B.BUCKET;
      var x0 = -CUP.w / 2, x1 = CUP.w / 2, bx0 = x1 + 2.9, bx1 = bx0 + BK.w;
      table(-8.5, 15);

      // 小桶与桶里的液体
      var bl = info.Vout / BK.A;
      if (bl > 0.01) { wrect(bx0, 0, bx1, bl); ctx.fillStyle = rgba(col, 0.6); ctx.fill(); }
      vessel(bx0, bx1, BK.h);
      var bt = P((bx0 + bx1) / 2, -1.6); text('小桶', bt[0], Math.min(bt[1], H - L.bottom + 14), C.muted, 'center', 11);

      // 溢水杯
      liquidBack(x0, x1, info.L, col);
      // 细线、物体
      var hookY = info.yb + info.press + sh.h + 3;   // 测力计挂钩下端（物体压在杯底时测力计继续下移，细线变松）
      var top = P(0, info.yb + sh.h), hk = P(0, hookY);
      ctx.strokeStyle = '#d7dce5'; ctx.lineWidth = 1.2;
      if (info.press > 0.05) {   // 松弛的细线
        var mid = P(0.9 * Math.min(1, info.press), (info.yb + sh.h + hookY) / 2);
        ctx.beginPath(); ctx.moveTo(hk[0], hk[1]); ctx.quadraticCurveTo(mid[0], mid[1], top[0], top[1]); ctx.stroke();
      } else line(hk[0], hk[1], top[0], top[1]);
      body(sh, 0, info.yb, info.metal.color);
      liquidFront(x0, x1, info.L, col);
      vessel(x0, x1, CUP.h, CUP.spout);
      var lt = P(x0 - 0.6, info.L); text(liq.name, lt[0], lt[1], col, 'right', 11);
      var ct = P(0, -1.6); text('溢水杯', ct[0], Math.min(ct[1], H - L.bottom + 14), C.muted, 'center', 11);

      // 溢出的水流
      if (st.pour > 0) {
        var s0 = P(x1 + 2.6, CUP.spout - 0.7), s1 = P(x1 + 3.6, Math.max(bl, 0) + 0.1);
        ctx.strokeStyle = rgba(col, 0.85); ctx.lineWidth = Math.max(2, 0.3 * M.s); ctx.lineCap = 'round';
        ctx.beginPath(); ctx.moveTo(s0[0], s0[1]); ctx.quadraticCurveTo(s1[0], s0[1], s1[0], s1[1]); ctx.stroke();
      }

      // 弹簧测力计（挂钩、外壳、刻度 0~10 N、指针）
      var bodyB = hookY + 2, bodyT = hookY + 16, zero = hookY + 14.5, F = info.F;
      var ha = P(0, hookY), hb = P(0, bodyB);
      ctx.strokeStyle = C.metal; ctx.lineWidth = 2; line(ha[0], ha[1], hb[0], hb[1]);
      ctx.beginPath(); ctx.arc(ha[0], ha[1] + 4, 4, -Math.PI / 2, Math.PI, false); ctx.stroke();
      var ba = P(-1.7, bodyT), bb = P(1.7, bodyB);
      ctx.fillStyle = '#e9edf3'; rrect(ba[0], ba[1], bb[0] - ba[0], bb[1] - ba[1], 4); ctx.fill();
      ctx.strokeStyle = '#9aa5b6'; ctx.lineWidth = 1; ctx.stroke();
      var slot0 = P(0.1, zero + 0.3), slot1 = P(0.9, zero - 10.3);
      ctx.fillStyle = '#c3cad6'; ctx.fillRect(slot0[0], slot0[1], slot1[0] - slot0[0], slot1[1] - slot0[1]);
      // 刻度
      for (var i = 0; i <= 50; i++) {
        var y = zero - i * 0.2, p = P(-0.1, y), long = i % 5 === 0;
        ctx.strokeStyle = '#3a4456'; ctx.lineWidth = long ? 1.2 : 0.7;
        line(p[0] - (long ? 0.9 : 0.5) * M.s, p[1], p[0], p[1]);
        if (long && (i / 5) % 2 === 0 && M.s >= 6) text(String(i / 5), p[0] - 1.25 * M.s, p[1], '#2a3446', 'center', clamp(M.s * 0.8, 8, 12), '600');
      }
      // 弹簧和指针
      var ptr = zero - Math.min(F, 10.4), sp0 = P(0.5, bodyT - 0.6), sp1 = P(0.5, ptr);
      ctx.strokeStyle = '#7a8496'; ctx.lineWidth = 1;
      var turns = 14; ctx.beginPath();
      for (var k = 0; k <= turns * 2; k++) {
        var yy = sp0[1] + (sp1[1] - sp0[1]) * k / (turns * 2), xx = sp0[0] + (k % 2 ? 0.35 : -0.35) * M.s;
        if (!k) ctx.moveTo(sp0[0], sp0[1]); else ctx.lineTo(xx, yy);
      }
      ctx.stroke();
      var pp = P(0.5, ptr); ctx.fillStyle = '#e04a3a';
      ctx.beginPath(); ctx.moveTo(pp[0] - 0.55 * M.s, pp[1]); ctx.lineTo(pp[0] + 0.55 * M.s, pp[1] - 3); ctx.lineTo(pp[0] + 0.55 * M.s, pp[1] + 3); ctx.closePath(); ctx.fill();
      // 拉环
      var ring = P(0, bodyT + 0.9); ctx.strokeStyle = C.metal; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(ring[0], ring[1], Math.max(4, 0.7 * M.s), 0, TAU); ctx.stroke();
      if (st.hover === 'rig' || st.dragging) { ctx.strokeStyle = rgba('#ffc94a', 0.7); ctx.setLineDash([4, 4]); ctx.strokeRect(ba[0] - 6, ba[1] - 14, bb[0] - ba[0] + 12, P(0, info.yb)[1] - ba[1] + 20); ctx.setLineDash([]); }
      var rt = P(1.9, (bodyT + bodyB) / 2);
      tag('F示 = ' + F.toFixed(2) + ' N', rt[0] + 4, rt[1], C.T, 13, 'left');
      var ga = P(-1.9, bodyT + 0.9);
      text('↕ 拖动', ga[0] - 4, ga[1], C.muted, 'right', 11);

      // 受力示意图
      if (st.showForces) {
        // G、F浮 画在重心两侧，拉力画在顶面（沿细线），支持力画在底面
        var c = P(0, info.yb + sh.h / 2), kf = Math.min(16, 4.2 * M.s / Math.max(1, info.G)), ox = Math.min(7, sh.w / 4 * M.s);
        force(c[0] - ox, c[1], info.G, -1, C.G, 'G', kf, -1);
        force(c[0] + ox, c[1], info.Fb, 1, C.Fb, 'F浮', kf, 1);
        var tp0 = P(0, info.yb + sh.h); force(tp0[0], tp0[1], info.F, 1, C.T, 'F拉', kf, 1);
        if (info.N > 1e-4) { var bb2 = P(sh.w / 4, info.yb); force(bb2[0], bb2[1], info.N, 1, C.N, 'N', kf, 1); }
      }
      // G排 标签
      if (info.Vout > 0.01) { var gt = P(bx1 + 0.3, BK.h + 1.2); tag('G排 = ' + info.Gp.toFixed(2) + ' N', gt[0], gt[1], C.Fb, 12, 'right'); }

      graph(st, info);
    }

    // F-h 图像：理论线（虚线）+ 实际描出的点
    function graph(st, info) {
      var g = L.graph, pad = { l: 40, r: 12, t: 28, b: 30 };
      var x0 = g.x + pad.l, x1 = g.x + g.w - pad.r, y0 = g.y + g.h - pad.b, y1 = g.y + pad.t;
      var hMax = 14, fMax = Math.max(1, Math.ceil(info.G * 1.15 * 2) / 2);
      function X(h) { return x0 + (x1 - x0) * h / hMax; }
      function Y(f) { return y0 - (y0 - y1) * f / fMax; }
      ctx.fillStyle = 'rgba(17,23,35,0.88)'; rrect(g.x, g.y, g.w, g.h, 10); ctx.fill();
      ctx.strokeStyle = C.line; ctx.lineWidth = 1; ctx.stroke();
      text('示数 F示、浮力 F浮 与浸入深度 h', g.x + 12, g.y + 15, C.text, 'left', 12, '600');
      // 网格与坐标
      ctx.strokeStyle = '#222b3b'; ctx.lineWidth = 1;
      var fStep = fMax > 6 ? 2 : fMax > 3 ? 1 : 0.5;
      for (var f = 0; f <= fMax + 1e-9; f += fStep) { line(x0, Y(f), x1, Y(f)); text(String(+f.toFixed(1)), x0 - 5, Y(f), C.muted, 'right', 10); }
      for (var h = 0; h <= hMax; h += 2) { line(X(h), y0, X(h), y1); text(String(h), X(h), y0 + 10, C.muted, 'center', 10); }
      text('h/cm', x1, y0 + 22, C.muted, 'right', 10);
      text('F/N', x0 - 5, y1 - 12, C.muted, 'right', 10);
      ctx.strokeStyle = '#46526a'; line(x0, y0, x1, y0); line(x0, y0, x0, y1);
      // 理论线
      ctx.setLineDash([5, 4]); ctx.lineWidth = 1.2;
      [['F', C.T], ['Fb', C.Fb]].forEach(function (s) {
        ctx.strokeStyle = rgba(s[1], 0.45); ctx.beginPath();
        for (var i = 0; i <= 140; i++) { var hh = i / 10, c = B.curve(info.G, info.liq.rho, info.shape, hh); var yy = Y(c[s[0]]); if (!i) ctx.moveTo(X(hh), yy); else ctx.lineTo(X(hh), yy); }
        ctx.stroke();
      });
      ctx.setLineDash([]);
      // 实测轨迹
      [['F', C.T], ['Fb', C.Fb]].forEach(function (s) {
        ctx.fillStyle = s[1];
        st.trace.forEach(function (p) { ctx.beginPath(); ctx.arc(X(Math.min(p.h, hMax)), Y(clamp(p[s[0]], 0, fMax)), 1.8, 0, TAU); ctx.fill(); });
      });
      // 当前点
      var ch = Math.min(info.h, hMax);
      dot(X(ch), Y(clamp(info.F, 0, fMax)), 4.5, C.T); dot(X(ch), Y(clamp(info.Fb, 0, fMax)), 4.5, C.Fb);
      // 物体高度处标一条竖线：浸没
      var hx = X(info.shape.h); ctx.strokeStyle = 'rgba(255,201,74,0.35)'; ctx.setLineDash([2, 3]); line(hx, y0, hx, y1); ctx.setLineDash([]);
      text('浸没', hx + 3, y1 + 6, 'rgba(255,201,74,0.75)', 'left', 10);
      // 图例
      var lx = x1 - 4, ly = y1 + 6;
      text('● F浮', lx, ly + 14, C.Fb, 'right', 11, '600'); text('● F示', lx - 52, ly + 14, C.T, 'right', 11, '600');
    }

    // ======================= 浮沉条件 =======================
    function drawSink(st, info) {
      var top = L.top, area = [12, top, W - 24, H - top - L.bottom];
      fit([-15, -2.2, 15, B.BEAKER.h + 7], area);
      var BK = B.BEAKER, x0 = -BK.w / 2, x1 = BK.w / 2, sh = info.shape, f = info.f, col = liquidColor(st.rhoL, st.liqS), ob = info.obj;
      table(-15, 15);
      liquidBack(x0, x1, f.L, col);
      body(sh, 0, st.sim.y, ob.color);
      liquidFront(x0, x1, f.L, col);
      vessel(x0, x1, BK.h);
      var lt = P(x1 - 0.5, f.L - 1); text(info.liqName + '  ρ液 = ' + fmtRho(st.rhoL), lt[0], lt[1], '#e6ebf2', 'right', 12, '600');
      if (st.hover === 'obj' || st.held) { var a = P(-sh.w / 2 - 0.3, st.sim.y + sh.h + 0.3), b = P(sh.w / 2 + 0.3, st.sim.y - 0.3); ctx.strokeStyle = rgba('#ffc94a', 0.8); ctx.setLineDash([4, 4]); ctx.strokeRect(a[0], a[1], b[0] - a[0], b[1] - a[1]); ctx.setLineDash([]); }

      // 受力示意图（重心处画 G、F浮，底面画支持力 N，手的力画在顶面）
      if (st.showForces) {
        var c = P(0, st.sim.y + sh.h / 2), maxF = Math.max(f.G, B.buoyant(st.rhoL, sh.V), 0.5);
        var kf = 4 * M.s / maxF;   // 最大的力画成 4 cm 长
        var dx = sh.w / 2 * M.s + 12;
        force(c[0] - dx, c[1], f.G, -1, C.G, 'G = ' + f.G.toFixed(2) + ' N', kf, -1);
        force(c[0] + dx, c[1], f.Fb, 1, C.Fb, 'F浮 = ' + f.Fb.toFixed(2) + ' N', kf, 1);
        if (f.N > 1e-4 && !st.held) { var bp = P(0, st.sim.y); force(bp[0], bp[1] - 2, f.N, 1, C.N, 'N = ' + f.N.toFixed(2) + ' N', kf, -1); }
        if (st.held) {
          var hf = f.G - f.Fb - (st.sim.y <= 1e-6 ? f.N : 0);   // > 0 手向上托，< 0 手向下按
          if (Math.abs(hf) > 1e-4) {
            // 手的力作用在物体表面：托的箭头从下方指向底面，按的箭头从上方指向顶面
            var tp = hf > 0 ? P(0, st.sim.y) : P(0, st.sim.y + sh.h), hl = Math.max(12, Math.abs(hf) * kf), sy = tp[1] + (hf > 0 ? hl : -hl);
            arrow(tp[0], sy, tp[0], tp[1], C.hand, 3);
            tag((hf > 0 ? '手托 ' : '手按 ') + Math.abs(hf).toFixed(2) + ' N', tp[0] - 8, sy, C.hand, 12, 'right');
          }
        }
      }
      // 状态
      var ph = st.held ? (st.sim.y > f.L ? '手提着' : '手拿着') : B.PHASE[info.phase];
      var pt = P(0, BK.h + 4.2);
      tag(ob.name + ' ρ物 = ' + fmtRho(st.rhoO) + '　' + ph, pt[0], pt[1], st.held ? C.text : C.accent, 15);
      if (!st.held && (info.phase === 'floating' || info.phase === 'suspend' || info.phase === 'bottom')) {
        var sub = f.Vsub / sh.V, r = P(x1 + 0.4, st.sim.y + sh.h / 2);
        if (W > 520) text('V排 = ' + Math.round(sub * 100) + '% V物', r[0] + 4, r[1], C.Fb, 'left', 12, '600');
      }
      if (st.hint2) { var ht = P(0, -1.3); text(st.hint2, ht[0], Math.min(ht[1], H - L.bottom + 16), C.muted, 'center', 11); }
    }
    function fmtRho(r) { return (+r.toFixed(2)) + ' g/cm³'; }

    function draw(st, info) {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, W, H);
      var bg = ctx.createLinearGradient(0, 0, 0, H); bg.addColorStop(0, '#0a0f1b'); bg.addColorStop(1, '#05070d');
      ctx.fillStyle = bg; ctx.fillRect(0, 0, W, H);
      if (st.scene === 'weigh') drawWeigh(st, info); else drawSink(st, info);
    }

    // 命中检测：称重法拖测力计或物体；浮沉拖物体
    function hit(st, info, x, y) {
      if (!M) return null;
      var w = unP(x, y), tol = 14 / M.s;
      if (st.scene === 'weigh') {
        var sh = info.shape, hookY = info.yb + info.press + sh.h + 3;
        if (Math.abs(w[0]) < Math.max(2.2, sh.w / 2) + tol && w[1] > info.yb - tol && w[1] < hookY + 18 + tol) return 'rig';
        return null;
      }
      var s2 = info.shape;
      if (Math.abs(w[0]) < s2.w / 2 + tol && w[1] > st.sim.y - tol && w[1] < st.sim.y + s2.h + tol) return 'obj';
      return null;
    }

    return { resize: resize, draw: draw, hit: hit, unP: unP, scale: function () { return M ? M.s : 10; } };
  }

  window.BuoyDraw = BuoyDraw;
})();
