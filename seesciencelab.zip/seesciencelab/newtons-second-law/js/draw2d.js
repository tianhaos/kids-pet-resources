/* CSS 像素坐标；两个轨道共用同一米尺和时钟。 */
(function () {
  'use strict';
  const colors = ['#ffc94a', '#78d9ff'];
  let ctx, W, H, g, targets = [];
  function text(str, x, y, color = '#95a8c1', size = 12, align = 'left') {
    ctx.fillStyle = color;
    ctx.font = `${size}px -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif`;
    ctx.textAlign = align;
    ctx.textBaseline = 'middle';
    ctx.fillText(str, x, y);
  }
  function line(x1, y1, x2, y2, color, width = 1, dash = []) {
    ctx.beginPath();
    ctx.strokeStyle = color;
    ctx.lineWidth = width;
    ctx.setLineDash(dash);
    ctx.moveTo(x1, y1);
    ctx.lineTo(x2, y2);
    ctx.stroke();
    ctx.setLineDash([]);
  }
  function box(x, y, w, h, fill, stroke, r = 5) {
    ctx.beginPath();
    ctx.roundRect(x, y, w, h, r);
    ctx.fillStyle = fill;
    ctx.fill();
    if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = 1; ctx.stroke(); }
  }
  function dot(x, y, r, color, fill) {
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fillStyle = fill || color;
    ctx.fill();
    ctx.strokeStyle = color;
    ctx.lineWidth = 1.5;
    ctx.stroke();
  }
  function arrow(x1, y, x2, color) {
    line(x1, y, x2, y, color, 2);
    line(x2 - 7, y - 4, x2, y, color, 2);
    line(x2 - 7, y + 4, x2, y, color, 2);
  }
  function geometry(w, h) {
    const mobile = w < 650;
    const left = mobile ? 42 : 72;
    const right = w - (mobile ? 86 : 140);
    const graphTop = Math.max(342, h * .58);
    const y1 = 162 + Math.max(0, graphTop - 420) * .15;
    const y2 = graphTop - 50;
    return { mobile, left, right, scale: (right - left) / 8,
      y1, y2, carW: mobile ? 52 : 80,
      graph: { x: mobile ? 48 : 72, y: graphTop + 39,
        w: w - (mobile ? 88 : 144), h: Math.max(70, h - graphTop - 168) } };
  }
  function car(x, y, m, i, ghost = false, t = 0) {
    const w = g.carW, col = colors[i];
    ctx.save();
    ctx.globalAlpha = ghost ? .17 : 1;
    // 轨道滑块而非真实滚动小车：车轮仅作器材外观示意。
    const metal = ctx.createLinearGradient(x, y - 29, x, y - 5);
    metal.addColorStop(0, i ? '#377b99' : '#b68a36');
    metal.addColorStop(.45, i ? '#29546d' : '#705227');
    metal.addColorStop(1, '#192330');
    box(x - w / 2, y - 27, w, 22, metal, col, 4);
    line(x - w / 2 + 4, y - 23, x + w / 2 - 4, y - 23, col, 1);
    for (const d of [-.3, .3]) {
      dot(x + w * d, y - 4, 7, '#8ca1b6', '#111a27');
      const angle = t * 8;
      line(x + w * d - Math.cos(angle) * 4, y - 4 - Math.sin(angle) * 4,
        x + w * d + Math.cos(angle) * 4, y - 4 + Math.sin(angle) * 4, '#465970');
    }
    // 每层代表 1 kg；半公斤以半层宽度表示，总质量仍以读数为准。
    for (let j = 1; j < Math.ceil(m); j++) {
      const bw = w * .65 * Math.min(1, m - j);
      box(x - bw / 2, y - 28 - j * 10, bw, 9, '#53677c', '#a0b1bf', 2);
      line(x - bw / 2 + 2, y - 26 - j * 10, x + bw / 2 - 2, y - 26 - j * 10, '#c4d1dc');
    }
    if (!ghost) text(`${m.toFixed(1)} kg`, x, y - 16, '#f1f3f5', 11, 'center');
    ctx.restore();
  }
  function track(s, c, i) {
    const y = i ? g.y2 : g.y1, col = colors[i];
    const r = Newton.at(c, s.t), x = g.left + r.x * g.scale;
    const labelY = y - 82;
    text(`${i ? 'B' : 'A'}  ${s.scene === 'force' ? `F合 = ${c.F.toFixed(2)} N` : `m = ${c.m.toFixed(1)} kg`}`,
      20, labelY, col, 13);
    text(`a = ${r.a.toFixed(2)} m/s²`, W - 20, labelY, col, 13, 'right');
    // 金属双轨、米尺以及固定起点，位移对应车中心位置。
    const beam = ctx.createLinearGradient(0, y + 2, 0, y + 16);
    beam.addColorStop(0, '#586e88');
    beam.addColorStop(.3, '#28394d');
    beam.addColorStop(1, '#101722');
    box(g.left - 28, y + 3, g.right - g.left + 65, 15, beam, '#40536d', 2);
    line(g.left - 28, y + 6, g.right + 37, y + 6, '#7f95aa');
    for (let k = 0; k <= 8; k++) {
      const xx = g.left + k * g.scale;
      line(xx, y + 18, xx, y + 23, '#5e7791');
      if (!g.mobile || k % 2 === 0) text(`${k}`, xx, y + 33, '#8295ad', 10, 'center');
    }
    text('m', g.right + 22, y + 33, '#8295ad', 10);
    line(g.left, y - 52, g.left, y + 3, '#526479', 1, [3, 4]);
    // 等时间位置：间距逐渐变大，清楚呈现加速。
    if (s.trails) {
      for (let t = .4; t < s.t - .08; t += .4) {
        const p = Newton.at(c, t);
        car(g.left + p.x * g.scale, y, c.m, i, true, t);
        dot(g.left + p.x * g.scale, y + 7, 2, col);
      }
    }
    line(g.left, y + 7, x, y + 7, col, 2);
    car(x, y, c.m, i, false, s.t);
    const ax = x + g.carW / 2 + 2, ay = y - 18;
    const end = ax + c.F * (g.mobile ? 10 : 17);
    if (c.F > 0) arrow(ax, ay, end, col);
    if (i === 1 && s.scene === 'force') {
      dot(end, ay, 5, col, '#101b2b');
      targets.push({ kind: 'force', x: end, y: ay, anchor: ax, unit: g.mobile ? 10 : 17 });
    }
    if (i === 1 && s.scene === 'mass') {
      const by = y - 33 - (Math.ceil(c.m) - 1) * 10;
      dot(x, by, 5, col, '#101b2b');
      targets.push({ kind: 'mass', x, y: by });
    }
    targets.push({ kind: 'car', index: i, x, y: y - 14, w: g.carW });
  }
  function chart(s, cs) {
    const q = g.graph, spec = Newton.graph(s);
    const px = x => q.x + x / spec.xmax * q.w;
    const py = a => q.y + q.h - a / spec.ymax * q.h;
    text(s.scene === 'force' ? '质量一定：a–F 图' : '合力一定：a–1/m 图', 20, q.y - 36, '#d5deea', g.mobile ? 13 : 15);
    text(s.theory ? '实线：理论关系' : '圆点：模拟记录', W - 20, q.y - 36, '#7f93ae', 11, 'right');
    text('a (m/s²)', q.x - 4, q.y - 14, '#a3b1c4', 11);
    for (let j = 0; j <= 4; j++) {
      const x = j * spec.xmax / 4, a = j * spec.ymax / 4;
      line(q.x, py(a), q.x + q.w, py(a), '#192334');
      line(px(x), q.y, px(x), q.y + q.h, '#192334');
      text(Number(a.toFixed(2)).toString(), q.x - 10, py(a), '#8295ad', 10, 'right');
      text(Number(x.toFixed(2)).toString(), px(x), q.y + q.h + 16, '#8295ad', 10, 'center');
    }
    line(q.x, q.y - 3, q.x, q.y + q.h, '#5d718a');
    line(q.x, q.y + q.h, q.x + q.w + 3, q.y + q.h, '#5d718a');
    text(spec.xlabel, q.x + q.w, q.y + q.h + 35, '#a3b1c4', 11, 'right');
    if (s.theory) line(px(0), py(0), px(spec.xmax), py(spec.ymax), '#8296ae', 1.5);
    const rows = s.records;
    for (let j = 0; j < rows.length; j++) {
      const p = rows[j], x = px(spec.x(p)), y = py(p.a);
      dot(x, y, 4, '#78d9ff', '#0c1e2c');
      targets.push({ kind: 'point', x, y, index: j });
    }
    cs.forEach((c, i) => {
      const x = px(spec.x(c)), y = py(c.F / c.m);
      dot(x, y, 6, colors[i], '#05070d');
      text(i ? 'B' : 'A', x + (x > q.x + q.w - 25 ? -13 : 13), y + (i ? 12 : -12), colors[i], 11, 'center');
    });
    if (s.hoverPoint !== null && rows[s.hoverPoint]) {
      const p = rows[s.hoverPoint];
      const label = `F=${p.F.toFixed(2)} N · m=${p.m.toFixed(1)} kg · a=${p.a.toFixed(2)}`;
      box(q.x + 4, q.y + 7, Math.min(330, q.w - 8), 28, '#182738', '#426382');
      text(label, q.x + 12, q.y + 21, '#dce8f5', g.mobile ? 10 : 12);
    }
  }
  function draw(canvas, s) {
    const rect = canvas.getBoundingClientRect(), dpr = Math.min(2, window.devicePixelRatio || 1);
    W = rect.width; H = rect.height;
    if (canvas.width !== Math.round(W * dpr) || canvas.height !== Math.round(H * dpr)) {
      canvas.width = Math.round(W * dpr);
      canvas.height = Math.round(H * dpr);
    }
    ctx = canvas.getContext('2d');
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.fillStyle = '#05070d'; ctx.fillRect(0, 0, W, H);
    g = geometry(W, H); targets = [];
    if (H < 520) {
      // 横屏较矮时让画面继续可用：轨道上移，压缩图像高度。
      g.y1 = 126; g.y2 = 235;
      g.graph.y = 304; g.graph.h = Math.max(45, H - 428);
    }
    const cs = Newton.cars(s);
    track(s, cs[0], 0); track(s, cs[1], 1);
    chart(s, cs);
    return g;
  }
  function hit(x, y) {
    // 参数柄优先于车身，图像点其次。
    for (const t of targets.filter(t => t.kind !== 'car')) {
      if (Math.hypot(x - t.x, y - t.y) <= (t.kind === 'point' ? 13 : 24)) return t;
    }
    for (const t of targets.filter(t => t.kind === 'car')) {
      if (Math.abs(x - t.x) < t.w / 2 + 10 && Math.abs(y - t.y) < 28) return t;
    }
    return null;
  }
  window.NewtonDraw = { draw, hit, geometry };
})();
