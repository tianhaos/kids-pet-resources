(function () {
  'use strict';
  const $ = id => document.getElementById(id), N = Newton;
  const query = new URLSearchParams(location.search);
  const scene = query.get('scene') === 'mass' ? 'mass' : 'force';
  function value(name, fallback, lo, hi) {
    const raw = query.get(name);
    return raw !== null && Number.isFinite(Number(raw)) ? N.clamp(Number(raw), lo, hi) : fallback;
  }
  const state = Object.assign(N.defaults(scene), {
    t: value('t', 1.6, 0, 2), playing: query.get('play') === '1',
    records: [], trails: query.get('trails') !== '0', theory: query.get('theory') !== '0',
    hoverPoint: null
  });
  state.common = value('common', state.common, scene === 'mass' ? .5 : 1, 4);
  state.variable = value('variable', state.variable, scene === 'mass' ? 1 : 0, 4);
  const commonStep = scene === 'mass' ? .25 : .5, variableStep = scene === 'mass' ? .5 : .25;
  state.common = Math.round(state.common / commonStep) * commonStep;
  state.variable = Math.round(state.variable / variableStep) * variableStep;
  let geom, dragging = null, last = 0;
  const canvas = $('lab');
  function track(action, label = state.scene) {
    if (window.Analytics) Analytics.track('牛顿第二定律', action, label);
  }
  function sync() {
    const mass = state.scene === 'mass';
    document.querySelectorAll('[data-scene]').forEach(b => {
      b.classList.toggle('on', b.dataset.scene === state.scene);
      b.setAttribute('aria-pressed', String(b.dataset.scene === state.scene));
    });
    $('subtitle').textContent = mass ? '合力相同，质量不同 · 从静止同时释放' : '质量相同，合力不同 · 从静止同时释放';
    $('commonLabel').textContent = mass ? '共同合力' : '共同质量';
    $('variableLabel').textContent = mass ? 'B车质量' : 'B车合力';
    $('common').min = mass ? .5 : 1;
    $('common').step = mass ? .25 : .5;
    $('variable').min = mass ? 1 : 0;
    $('variable').step = mass ? .5 : .25;
    $('common').value = state.common;
    $('variable').value = state.variable;
    $('commonValue').textContent = state.common.toFixed(mass ? 2 : 1) + (mass ? ' N' : ' kg');
    $('variableValue').textContent = state.variable.toFixed(mass ? 1 : 2) + (mass ? ' kg' : ' N');
    $('controlNote').textContent = mass
      ? 'A车质量固定为1 kg；两车合力始终相同。上下拖B车配重圆点改变质量。'
      : 'A车合力固定为1 N；两车质量始终相同。左右拖B车力柄圆点改变合力。';
    $('law').textContent = mass ? '合力一定，a 与 1/m 成正比' : '质量一定，a 与 F合 成正比';
    $('trails').checked = state.trails;
    $('theory').checked = state.theory;
    updateRows();
  }
  function updateRows() {
    $('records').innerHTML = '<thead><tr><th>F合 / N</th><th>m / kg</th><th>1/m / kg⁻¹</th><th>a / m·s⁻²</th></tr></thead><tbody>' +
      state.records.map(p => `<tr><td>${p.F.toFixed(2)}</td><td>${p.m.toFixed(1)}</td><td>${(1 / p.m).toFixed(2)}</td><td>${p.a.toFixed(2)}</td></tr>`).join('') + '</tbody>';
    $('empty').hidden = state.records.length > 0;
  }
  function setScene(next) {
    Object.assign(state, N.defaults(next === 'mass' ? 'mass' : 'force'),
      { t: 1.6, playing: false, records: [], hoverPoint: null });
    $('toast').textContent = '';
    sync(); track('切换场景');
  }
  function setParameter(key, n) {
    const min = key === 'common' ? (state.scene === 'mass' ? .5 : 1) : (state.scene === 'mass' ? 1 : 0);
    const step = key === 'common' ? (state.scene === 'mass' ? .25 : .5) : (state.scene === 'mass' ? .5 : .25);
    state[key] = N.clamp(Math.round(n / step) * step, min, 4);
    state.playing = false;
    // 保留同一时刻的对比；重新播放时两车再从静止同时出发。
    if (key === 'common') { state.records = []; state.hoverPoint = null; $('toast').textContent = ''; }
    sync();
  }
  document.querySelectorAll('[data-scene]').forEach(b => b.onclick = () => setScene(b.dataset.scene));
  ['common', 'variable'].forEach(key => {
    $(key).oninput = e => setParameter(key, Number(e.target.value));
    $(key).onchange = () => track('调整参数', key);
  });
  function togglePlay() {
    if (!state.playing) state.t = 0;
    state.playing = !state.playing;
    track(state.playing ? '同时释放' : '暂停');
  }
  $('play').onclick = togglePlay;
  $('reset').onclick = () => { state.t = 0; state.playing = false; track('回到起点'); };
  $('time').oninput = e => { state.t = Number(e.target.value); state.playing = false; };
  $('time').onchange = () => track('回看时刻');
  $('record').onclick = () => {
    const count = state.records.length;
    state.records = N.record(state.records, state);
    $('toast').textContent = count === state.records.length ? '这组数据已经记录' : '已记录B车这一组模拟数据';
    updateRows(); track('记录数据');
  };
  $('clear').onclick = () => { state.records = []; state.hoverPoint = null; updateRows(); $('toast').textContent = ''; };
  ['trails', 'theory'].forEach(key => $(key).onchange = e => { state[key] = e.target.checked; track('显示设置', key); });
  $('panelToggle').onclick = () => {
    $('panel').classList.toggle('collapsed');
    $('panelToggle').setAttribute('aria-expanded', String(!$('panel').classList.contains('collapsed')));
  };
  if (matchMedia('(max-width:760px)').matches) {
    $('panel').classList.add('collapsed');
    $('panelToggle').setAttribute('aria-expanded', 'false');
  }
  document.addEventListener('keydown', e => {
    if (e.code === 'Space' && !/INPUT|BUTTON|TEXTAREA|SELECT/.test(e.target.tagName)) {
      e.preventDefault(); togglePlay();
    }
  });
  function point(e) {
    const r = canvas.getBoundingClientRect();
    return { x: e.clientX - r.left, y: e.clientY - r.top };
  }
  canvas.onpointerdown = e => {
    const p = point(e), hit = NewtonDraw.hit(p.x, p.y);
    if (!hit) return;
    if (hit.kind === 'point') { state.hoverPoint = hit.index; return; }
    state.playing = false;
    dragging = { hit, start: p, initial: state.variable, t: state.t };
    canvas.setPointerCapture(e.pointerId);
    canvas.style.cursor = hit.kind === 'mass' ? 'ns-resize' : 'ew-resize';
    e.preventDefault();
  };
  canvas.onpointermove = e => {
    const p = point(e);
    if (dragging) {
      const h = dragging.hit;
      if (h.kind === 'force') setParameter('variable', dragging.initial + (p.x - dragging.start.x) / h.unit);
      if (h.kind === 'mass') setParameter('variable', dragging.initial - (p.y - dragging.start.y) / 30);
      if (h.kind === 'car') {
        const c = N.cars(state)[h.index];
        // 保留按下位置相对车身偏移，避免开始拖动时跳帧。
        const x = N.at(c, dragging.t).x + (p.x - dragging.start.x) / geom.scale;
        state.t = N.timeAt(c, x);
      }
    } else {
      const hit = NewtonDraw.hit(p.x, p.y);
      canvas.style.cursor = hit ? (hit.kind === 'mass' ? 'ns-resize' : hit.kind === 'point' ? 'pointer' : 'ew-resize') : 'default';
      state.hoverPoint = hit && hit.kind === 'point' ? hit.index : null;
    }
  };
  function endDrag() {
    if (dragging) track('画面拖动', dragging.hit.kind);
    dragging = null;
    canvas.style.cursor = 'default';
  }
  canvas.onpointerup = endDrag;
  canvas.onpointercancel = endDrag;
  canvas.onlostpointercapture = endDrag;
  canvas.onpointerleave = () => { if (!dragging) state.hoverPoint = null; };
  $('share').onclick = async () => {
    const u = new URL(location.href); u.search = '';
    for (const key of ['scene', 'common', 'variable', 't']) u.searchParams.set(key, state[key]);
    u.searchParams.set('trails', state.trails ? '1' : '0');
    u.searchParams.set('theory', state.theory ? '1' : '0');
    try { await navigator.clipboard.writeText(u.href); $('toast').textContent = '已复制当前实验链接'; }
    catch { $('shareLink').hidden = false; $('shareLink').value = u.href; $('shareLink').select(); $('toast').textContent = '请复制下方链接'; }
    track('复制链接');
  };
  function frame(now) {
    const dt = last ? Math.min(.05, (now - last) / 1000) : 0; last = now;
    if (state.playing) {
      state.t = Math.min(2, state.t + dt * .5);
      if (state.t >= 2) state.playing = false;
    }
    geom = NewtonDraw.draw(canvas, state);
    const cs = N.cars(state), a = cs.map(c => N.at(c, state.t));
    $('aA').textContent = `${a[0].a.toFixed(2)} m/s²`;
    $('aB').textContent = `${a[1].a.toFixed(2)} m/s²`;
    $('compare').textContent = `同一时刻：A车 ${a[0].x.toFixed(2)} m，B车 ${a[1].x.toFixed(2)} m。`;
    $('ratio').textContent = `aB / aA = ${(a[1].a / a[0].a).toFixed(2)}`;
    $('time').value = state.t;
    $('clock').textContent = state.t.toFixed(2) + ' s';
    $('play').textContent = state.playing ? '暂停' : '同时释放';
    requestAnimationFrame(frame);
  }
  sync(); requestAnimationFrame(frame);
  window.__model = { state, setScene, setParameter, setTime(t) { state.t = N.clamp(t, 0, 2); state.playing = false; },
    geometry: () => geom, solve: () => N.cars(state).map(c => N.at(c, state.t)) };
})();
