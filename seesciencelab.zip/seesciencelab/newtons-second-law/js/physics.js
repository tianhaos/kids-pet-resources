/* 理想水平直轨：合力恒定，从静止出发。SI 单位。 */
(function () {
  'use strict';
  const clamp = (x, lo, hi) => Math.max(lo, Math.min(hi, x));
  function cars(s) {
    return s.scene === 'mass'
      ? [{ m: 1, F: s.common }, { m: s.variable, F: s.common }]
      : [{ m: s.common, F: 1 }, { m: s.common, F: s.variable }];
  }
  function at(car, t) {
    const a = car.F / car.m;
    return { a, v: a * t, x: a * t * t / 2 };
  }
  function defaults(scene) {
    return { scene, common: scene === 'mass' ? 3 : 1, variable: 3 };
  }
  function graph(s) {
    const mass = s.scene === 'mass';
    return { xmax: mass ? 1 : 4, ymax: mass ? s.common : 4 / s.common,
      slope: mass ? s.common : 1 / s.common,
      x: car => mass ? 1 / car.m : car.F,
      xlabel: mass ? '1/m (kg⁻¹)' : 'F合 (N)' };
  }
  function sample(s) {
    const car = cars(s)[1];
    return { m: car.m, F: car.F, a: car.F / car.m };
  }
  // 各组分别存储；控制量改变后，旧点不可混在同一条直线上。
  function record(rows, s) {
    const p = sample(s);
    if (rows.some(r => r.m === p.m && r.F === p.F)) return rows;
    return rows.concat(p).sort((a, b) => s.scene === 'mass' ? 1 / a.m - 1 / b.m : a.F - b.F);
  }
  function timeAt(car, x) {
    return car.F > 0 ? clamp(Math.sqrt(Math.max(0, 2 * x * car.m / car.F)), 0, 2) : 0;
  }
  window.Newton = { clamp, cars, at, defaults, graph, sample, record, timeAt };
})();
