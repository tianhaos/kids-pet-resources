/* 运动场横纵同尺；箭头是分速度示意，角度手柄固定长度便于触摸。 */
(function () {
  'use strict';
  var B=window.Ballistics, geo={}, gold='#ffc94a', cyan='#65d8ff', muted='#90a4bc';
  function draw(canvas,s) {
    var w=canvas.clientWidth,h=canvas.clientHeight,dpr=Math.min(devicePixelRatio||1,2);
    if(canvas.width!==Math.round(w*dpr)||canvas.height!==Math.round(h*dpr)){canvas.width=Math.round(w*dpr);canvas.height=Math.round(h*dpr);}
    var c=canvas.getContext('2d');c.setTransform(dpr,0,0,dpr,0,0);c.clearRect(0,0,w,h);
    c.fillStyle='#05070d';c.fillRect(0,0,w,h);
    var small=w<600, left=small?36:65,right=w-35,ground=h*(small?.47:.63),top=small?132:120;
    var shots=[s];if(s.scene==='compare')shots.push(B.companion(s));
    var xmax=s.v0*s.v0/s.g*1.10+2, ymax=s.h+s.v0*s.v0/(2*s.g)+2;
    // 固定同一初速/高度下的视野，使调角前后的射程可直接比较。
    if(s.h>0)xmax=B.range(Object.assign({},s,{angle:B.optimum(s)}))*1.12+3;
    var scale=Math.min((right-left)/xmax,(ground-top)/ymax), X=function(x){return left+x*scale;},Y=function(y){return ground-y*scale;};
    var gridStep=xmax>100?50:xmax>50?10:5;
    function line(x1,y1,x2,y2,color,width,dash){c.beginPath();c.strokeStyle=color;c.lineWidth=width||1;c.setLineDash(dash||[]);c.moveTo(x1,y1);c.lineTo(x2,y2);c.stroke();c.setLineDash([]);}
    function text(t,x,y,color,size,align){c.fillStyle=color||muted;c.font=(size||11)+'px -apple-system,"PingFang SC",sans-serif';c.textAlign=align||'left';c.fillText(t,x,y);}
    function dot(x,y,r,color){c.beginPath();c.arc(x,y,r,0,Math.PI*2);c.fillStyle=color;c.fill();}
    function arrow(x,y,dx,dy,color){var len=Math.hypot(dx,dy);if(len<.8)return;line(x,y,x+dx,y+dy,color,2);var a=Math.atan2(dy,dx);line(x+dx,y+dy,x+dx-7*Math.cos(a-.45),y+dy-7*Math.sin(a-.45),color,2);line(x+dx,y+dy,x+dx-7*Math.cos(a+.45),y+dy-7*Math.sin(a+.45),color,2);}
    for(var x=0;x<=xmax;x+=gridStep){line(X(x),top,X(x),ground,'#16212f');text(x+'',X(x),ground+21,muted,10,'center');}
    for(var y=gridStep;y<=ymax;y+=gridStep){line(left,Y(y),right,Y(y),'#16212f');text(y+'',left-8,Y(y)+4,muted,10,'right');}
    text('y / m',left-15,top-12);text('x / m',right,ground+21,muted,10,'right');
    // 跑道与发射台，地面基准为质点球心接触面。
    var soil=c.createLinearGradient(0,ground,0,ground+45);soil.addColorStop(0,'#172b34');soil.addColorStop(1,'#080e16');c.fillStyle=soil;c.fillRect(0,ground,w,48);
    line(0,ground,w,ground,'#577b88',1.5);
    for(var r=left;r<right;r+=24)line(r,ground+34,r+9,ground+34,'#33434d');
    if(s.h>0){c.fillStyle='#1b2a3a';c.fillRect(left-22,Y(s.h),22,s.h*scale);line(left-24,Y(s.h),left+8,Y(s.h),'#718ba1',3);text('高台 '+s.h.toFixed(1)+' m',left+7,Y(s.h)+20,muted,11);}
    var origin={x:left,y:Y(s.h)}, al=s.angle*Math.PI/180, handle={x:left+64*Math.cos(al),y:origin.y-64*Math.sin(al)};
    c.save();c.translate(origin.x,origin.y);c.rotate(-al);c.fillStyle='#51616b';c.fillRect(-12,-7,34,14);c.strokeStyle='#9bb2bf';c.strokeRect(-12,-7,34,14);c.restore();dot(origin.x,origin.y+4,9,'#36434c');
    line(origin.x,origin.y,handle.x,handle.y,'#dbc983',1,[3,4]);dot(handle.x,handle.y,7,gold);c.strokeStyle='#ffc94a55';c.lineWidth=6;c.beginPath();c.arc(handle.x,handle.y,12,0,Math.PI*2);c.stroke();
    text(s.angle.toFixed(0)+'°',handle.x+12,handle.y-7,gold,12);
    geo={origin:origin,handle:handle,scale:scale,X:X,Y:Y,shots:shots,plot:{x:left,y:h*.79,w:right-left,h:Math.max(40,h*.21-58)},ground:ground};
    shots.forEach(function(a,i){
      var color=i?cyan:gold,T=B.duration(a),landed=s.t>=T-1e-7,q=B.at(a,s.t);
      // 完整预测轨迹淡虚线，已走轨迹实线。
      c.beginPath();c.strokeStyle=i?'#65d8ff55':'#ffc94a55';c.lineWidth=1.3;c.setLineDash([4,5]);
      for(var n=0;n<=120;n++){var p=B.at(a,T*n/120);if(n)c.lineTo(X(p.x),Y(p.y));else c.moveTo(X(p.x),Y(p.y));}c.stroke();c.setLineDash([]);
      c.beginPath();c.strokeStyle=color;c.lineWidth=2.2;
      for(var j=0;j<=100;j++){var v=B.at(a,Math.min(s.t,T)*j/100);if(j)c.lineTo(X(v.x),Y(v.y));else c.moveTo(X(v.x),Y(v.y));}c.stroke();
      if(s.marks){var dt=B.end(s)/12;for(var tm=0;tm<=Math.min(s.t,T)+1e-8;tm+=dt){var m=B.at(a,tm);dot(X(m.x),Y(m.y),2.6,color);}}
      var px=X(q.x),py=Y(q.y),glow=c.createRadialGradient(px-2,py-3,1,px,py,9);glow.addColorStop(0,'#fff6cf');glow.addColorStop(.35,color);glow.addColorStop(1,i?'#167399':'#a16b12');
      c.shadowColor=color;c.shadowBlur=12;dot(px,py,7,glow);c.shadowBlur=0;
      var R=B.range(a);line(X(R),ground-5,X(R),ground+5,color,2);
      // 落点相同时标签分列；高低角对照的同一物理落点保持不变。
      text(a.angle.toFixed(0)+'° · '+(landed?'已落地':'飞行中'),small?left+i*145:right-150,small?100:52+i*21,color,small?11:12);
      if(s.vectors&&!landed){var k=small?2:3;arrow(px,py,q.vx*k,0,color);arrow(px,py,0,-q.vy*k,'#9bddaa');if(!i){text('vₓ',px+q.vx*k+5,py-4,color,11);if(Math.abs(q.vy)>.3)text('vᵧ',px+6,py-q.vy*k,'#9bddaa',11);else text('vᵧ = 0',px+6,py+20,'#9bddaa',11);}}
    });
    text('拖金色手柄调角度 · 点轨迹回看时刻',left,ground+40,muted,small?10:12);
    if(small){
      var vt={x:left,y:ground+95,w:right-left,h:82},T=B.duration(s),u=B.components(s),limit=Math.max(u.vx,u.vy,Math.abs(B.at(s,T).vy))*1.15;
      var tx=function(t){return vt.x+t/T*vt.w;},vy=function(v){return vt.y+vt.h/2-v/limit*vt.h/2;};
      text('主球分速度 / m·s⁻¹',left,vt.y-16,muted,11);text((s.t>=T?'接触前 t = '+T.toFixed(2):'t = '+s.t.toFixed(2))+' s',right,vt.y-16,gold,11,'right');
      line(left,vy(0),right,vy(0),'#3a4c60');line(left,vt.y,left,vt.y+vt.h,'#243248');
      text('0',left-8,vy(0)+3,muted,9,'right');
      line(tx(0),vy(u.vx),tx(T),vy(u.vx),gold,1.5);line(tx(0),vy(u.vy),tx(T),vy(B.at(s,T).vy),'#9bddaa',1.5);
      var qt=B.at(s,s.t);line(tx(qt.t),vt.y,tx(qt.t),vt.y+vt.h,'#55708a',1,[3,4]);dot(tx(qt.t),vy(qt.vx),3,gold);dot(tx(qt.t),vy(qt.vy),3,'#9bddaa');
      text('vₓ 恒定',right,vy(u.vx)-6,gold,10,'right');text('vᵧ 斜率 −g',right,vt.y+vt.h+13,'#9bddaa',10,'right');text('0',left,vt.y+vt.h+13,muted,9);text(T.toFixed(2)+' s',right,vt.y+vt.h+27,muted,9,'right');
    }
    // 射程曲线与精确最优角，所有角度共用同一组初速、高度、g。
    var p=geo.plot,maxR=B.range(Object.assign({},s,{angle:B.optimum(s)}))*1.12;
    var gx=function(a){return p.x+a/90*p.w;},gy=function(R){return p.y+p.h-R/maxR*p.h;};
    geo.graphX=gx;geo.graphY=gy;
    text('射程 R / m · 点曲线选角',p.x,p.y-18,muted,11);text('最远角 '+B.optimum(s).toFixed(1)+'°',right,p.y-18,gold,11,'right');
    [0,.5,1].forEach(function(f){var yy=p.y+p.h-f*p.h;line(p.x,yy,right,yy,'#1b293b');text((f*maxR).toFixed(0),p.x-7,yy+3,muted,9,'right');});
    c.beginPath();c.strokeStyle='#778aa2';c.lineWidth=1.5;for(var ang=0;ang<=90;ang++){var R=B.range(Object.assign({},s,{angle:ang}));if(ang)c.lineTo(gx(ang),gy(R));else c.moveTo(gx(ang),gy(R));}c.stroke();
    [0,30,45,60,90].forEach(function(a){text(a+'°',gx(a),p.y+p.h+16,muted,10,'center');});
    shots.forEach(function(a,i){var xx=gx(a.angle),yy=gy(B.range(a));line(xx,yy,xx,p.y+p.h,i?cyan:gold,1,[3,4]);dot(xx,yy,4,i?cyan:gold);});
  }
  window.BallisticDraw={draw:draw,geometry:function(){return geo;}};
})();
