(function(){
  'use strict';
  var $=function(id){return document.getElementById(id);}, B=Ballistics,p=new URLSearchParams(location.search);
  function num(k,d,lo,hi){var x=Number(p.get(k));return p.has(k)&&Number.isFinite(x)?Math.max(lo,Math.min(hi,x)):d;}
  var scene=['single','compare','platform'].includes(p.get('scene'))?p.get('scene'):'compare';
  var s={scene:scene,angle:num('angle',30,10,80),v0:num('v0',20,8,30),h:scene==='platform'?num('h',10,0,20):0,g:num('g',10,1.6,12),t:0,playing:p.get('play')==='1',speed:.5,marks:p.get('marks')!=='0',vectors:p.get('vectors')!=='0'};
  s.t=num('t',B.apex(s),0,B.end(s));
  function track(a,b){if(window.Analytics)Analytics.track('斜抛运动',a,b||s.scene);}
  function update(){
    s.t=Math.max(0,Math.min(B.end(s),s.t));var q=B.at(s,s.t),landed=s.t>=B.duration(s)-1e-7;
    $('phase').textContent=landed?'主球已落地':Math.abs(q.vy)<.03?'最高点 · 水平速度仍在':q.vy>0?'上升 · 竖直分速度减小':'下降 · 竖直分速度增大';
    $('rt').textContent=s.t.toFixed(2)+' s';$('rx').textContent=q.x.toFixed(2)+' m';$('ry').textContent=q.y.toFixed(2)+' m';
    $('rv').textContent=landed?'接触前 '+q.speed.toFixed(2)+' m/s':q.speed.toFixed(2)+' m/s';
    $('components').textContent='vₓ = '+q.vx.toFixed(2)+'，vᵧ = '+q.vy.toFixed(2)+' m/s'+(landed?'（接触前）':'');
    $('rangeRead').textContent=B.range(s).toFixed(2)+' m';$('flightRead').textContent=B.duration(s).toFixed(2)+' s';
    $('compareRead').textContent=s.scene==='compare'?'对照 '+(90-s.angle).toFixed(0)+'°：射程 '+B.range(B.companion(s)).toFixed(2)+' m，飞行 '+B.duration(B.companion(s)).toFixed(2)+' s':'最远角 '+B.optimum(s).toFixed(1)+'°，射程 '+B.range(Object.assign({},s,{angle:B.optimum(s)})).toFixed(2)+' m';
    [['angle',s.angle,'°'],['v0',s.v0,' m/s'],['h',s.h,' m'],['g',s.g,' m/s²'],['time',s.t,' s']].forEach(function(a){$(a[0]).value=a[1];$('o-'+a[0]).textContent=a[1].toFixed(a[0]==='time'?2:a[0]==='angle'?0:1)+a[2];});
    $('time').max=B.end(s);$('h').disabled=s.scene!=='platform';$('play').textContent=s.playing?'❚❚ 暂停':s.t>0&&s.t<B.end(s)?'▶ 播放':'▶ 发射';
    document.querySelectorAll('[data-scene]').forEach(function(b){b.classList.toggle('on',b.dataset.scene===s.scene);b.setAttribute('aria-pressed',b.dataset.scene===s.scene);});
    document.querySelector('.stage-title h2').textContent=s.scene==='compare'?'同一个落点，两种飞行。':s.scene==='platform'?'站得更高，最远角会变。':'弯曲的轨迹，两个分运动。';
    $('caption').textContent=s.scene==='compare'?'同速、同高、同时发射 · 金色 θ / 蓝色 90°−θ':s.scene==='platform'?'从高台落到水平地面 · 最远角还会是45°吗？':'水平匀速 + 竖直匀变速 · 飞行中 a 始终向下';
    BallisticDraw.draw($('flight'),s);
  }
  function time(t){s.t=t;s.playing=false;update();}
  function changeScene(v){s.scene=v;s.h=v==='platform'?10:0;s.t=0;s.playing=false;track('切换场景');update();}
  function play(){if(s.t>=B.end(s))s.t=0;s.playing=!s.playing;track('播放暂停');update();}
  document.querySelectorAll('[data-scene]').forEach(function(b){b.onclick=function(){changeScene(b.dataset.scene);};});
  ['angle','v0','h','g'].forEach(function(k){$(k).oninput=function(){s[k]=+this.value;s.t=0;s.playing=false;update();};$(k).onchange=function(){track('改变条件',k);};});
  $('time').oninput=function(){time(+this.value);};$('time').onchange=function(){track('探测时间');};
  $('play').onclick=play;$('reset').onclick=function(){time(0);track('重置');};$('apex').onclick=function(){time(B.apex(s));track('最高点');};$('land').onclick=function(){time(B.duration(s));track('主球落地');};
  $('best').onclick=function(){s.angle=B.optimum(s);time(0);track('最远角');};
  $('speed').oninput=function(){s.speed=+this.value;$('o-speed').textContent=s.speed.toFixed(2)+'×';};
  ['marks','vectors'].forEach(function(k){$(k).checked=s[k];$(k).onchange=function(){s[k]=this.checked;track('显示选项',k);update();};});
  $('panelToggle').onclick=function(){$('panel').classList.toggle('collapsed');};
  $('share').onclick=async function(){var u=new URL(location.href);u.search='';Object.entries({scene:s.scene,angle:s.angle,v0:s.v0,h:s.h,g:s.g,t:s.t,play:0,marks:+s.marks,vectors:+s.vectors}).forEach(function(a){u.searchParams.set(a[0],a[1]);});try{await navigator.clipboard.writeText(u.href);$('shareNote').textContent='已复制当前条件与时刻';track('复制链接');}catch(e){$('shareNote').textContent=u.href;}};
  var canvas=$('flight'),drag=null;
  function pos(e){var r=canvas.getBoundingClientRect();return {x:e.clientX-r.left,y:e.clientY-r.top};}
  function probe(m,z){var best=Infinity,at=0;for(var n=0;n<=400;n++){var t=B.end(s)*n/400;z.shots.forEach(function(a){if(t>B.duration(a))return;var q=B.at(a,t),d=Math.hypot(z.X(q.x)-m.x,z.Y(q.y)-m.y);if(d<best){best=d;at=t;}});}return {distance:best,t:at};}
  function move(e){if(!drag)return;var m=pos(e),z=drag.geo;s.playing=false;
    if(drag.type==='angle'){s.angle=Math.max(10,Math.min(80,Math.atan2(z.origin.y-m.y,m.x-z.origin.x)*180/Math.PI));s.t=0;}
    else if(drag.type==='graph'){s.angle=Math.max(10,Math.min(80,(m.x-z.plot.x)/z.plot.w*90));s.t=0;}
    else s.t=probe(m,z).t;update();
  }
  canvas.onpointerdown=function(e){var m=pos(e),z=BallisticDraw.geometry(),type=null;
    if(Math.hypot(m.x-z.handle.x,m.y-z.handle.y)<28)type='angle';
    else if(m.x>=z.plot.x-10&&m.x<=z.plot.x+z.plot.w+10&&m.y>=z.plot.y-12&&m.y<=z.plot.y+z.plot.h+20)type='graph';
    else if(probe(m,z).distance<30)type='time';
    if(type){drag={type:type,geo:z};canvas.setPointerCapture(e.pointerId);canvas.style.cursor='grabbing';move(e);}
  };
  canvas.onpointermove=function(e){if(drag)move(e);else{var m=pos(e),z=BallisticDraw.geometry();canvas.style.cursor=Math.hypot(m.x-z.handle.x,m.y-z.handle.y)<28?'grab':probe(m,z).distance<25?'crosshair':'default';}};
  canvas.onpointerup=canvas.onpointercancel=function(){if(drag)track('画面操作',drag.type);drag=null;canvas.style.cursor='default';};
  window.addEventListener('keydown',function(e){if(e.code==='Space'&&!/INPUT|BUTTON|SELECT/.test(e.target.tagName)){e.preventDefault();play();}});
  window.addEventListener('resize',update);if(innerWidth<=760)$('panel').classList.add('collapsed');
  window.__model={state:s,setTime:time,setScene:changeScene,update:update};
  var last=0;function tick(now){var dt=last?Math.min(.05,(now-last)/1000):0;last=now;if(s.playing){s.t+=dt*s.speed;if(s.t>=B.end(s)){s.t=B.end(s);s.playing=false;}}update();requestAnimationFrame(tick);}requestAnimationFrame(tick);
})();
