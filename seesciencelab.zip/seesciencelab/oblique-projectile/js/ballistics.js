/* 理想斜抛：位置为球心，水平地面 y=0，落地后不模拟运动。 */
(function () {
  'use strict';
  var rad = Math.PI / 180;
  function components(s) { return {vx: s.v0 * Math.cos(s.angle * rad), vy: s.v0 * Math.sin(s.angle * rad)}; }
  function duration(s) { var u = components(s).vy; return (u + Math.sqrt(u*u + 2*s.g*s.h)) / s.g; }
  function at(s, t) {
    t = Math.max(0, Math.min(duration(s), t));
    var u = components(s), vy = u.vy - s.g*t;
    return {t:t, x:u.vx*t, y:Math.max(0, s.h+u.vy*t-s.g*t*t/2), vx:u.vx, vy:vy, speed:Math.hypot(u.vx,vy)};
  }
  function apex(s) { return components(s).vy / s.g; }
  function range(s) { return components(s).vx * duration(s); }
  function optimum(s) { return Math.atan(s.v0 / Math.sqrt(s.v0*s.v0 + 2*s.g*s.h)) / rad; }
  function companion(s) { return Object.assign({}, s, {angle:90-s.angle}); }
  function end(s) { return s.scene==='compare' ? Math.max(duration(s),duration(companion(s))) : duration(s); }
  window.Ballistics = {components:components, duration:duration, at:at, apex:apex, range:range, optimum:optimum, companion:companion, end:end};
})();
