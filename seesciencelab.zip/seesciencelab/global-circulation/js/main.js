// 状态、面板与主循环
(function () {
  var A = window.Astro, C = window.Circ;
  var $ = function (id) { return document.getElementById(id); };
  var stage = $('stage'), panel = $('panel');

  var now = new Date();
  var state = {
    mode: 'three',          // three 三圈环流 | single 单圈环流（地球不自转）
    step: 0,                // 0 不分步；1~6 形成过程
    day: A.dateToDay(now.getMonth() + 1, now.getDate()),
    play: false, playSpeed: 30, // 天/秒
    paused: false, flowSpeed: 1,
    spin: false,
    place: null,
    show: { belts: true, flow: true, arrows: true, cells: true, deflect: false, lat: true, labels: true },
    decl: 0, s: 0
  };

  // ---------- URL 参数 ----------
  var q = new URLSearchParams(location.search);
  if (q.get('mode') === 'single') state.mode = 'single';
  if (q.get('step')) state.step = Math.max(0, Math.min(C.STEPS.length, parseInt(q.get('step'), 10) || 0));
  var TERM_BY_KEY = {};
  A.TERMS.forEach(function (t) { TERM_BY_KEY[t.key] = t; });
  if (TERM_BY_KEY[q.get('term')]) state.day = TERM_BY_KEY[q.get('term')].day;
  if (q.get('month')) state.day = C.MID_DAYS[Math.max(1, Math.min(12, parseInt(q.get('month'), 10) || 1)) - 1];
  if (q.get('day')) state.day = A.wrapDay(Number(q.get('day')) || 1);
  if (q.get('play') === '1') state.play = true;
  if (q.get('spin') === '1') state.spin = true;
  Object.keys(state.show).forEach(function (k) {
    var name = k === 'lat' ? 'grid' : k; // lat= 留给地点纬度
    if (q.get(name) === '0') state.show[k] = false;
    if (q.get(name) === '1') state.show[k] = true;
  });
  function placeByKey(key) { return C.PLACES.filter(function (p) { return p.key === key; })[0] || null; }
  function customPlace(lat, lon) {
    return { key: 'custom', lat: lat, lon: lon, name: '所选地点（' + A.formatLat(lat) + '，' + fmtLon(lon) + '）', short: A.formatLat(lat) };
  }
  function fmtLon(lon) {
    var a = Math.abs(lon).toFixed(1);
    return Number(a) === 0 ? '0°' : a + '°' + (lon > 0 ? 'E' : 'W');
  }
  state.place = placeByKey(q.get('place') || 'athens');
  if (q.get('lat') != null && q.get('lon') != null) {
    var la = Number(q.get('lat')), lo = Number(q.get('lon'));
    if (isFinite(la) && isFinite(lo)) state.place = customPlace(Math.max(-89, Math.min(89, la)), lo);
  }
  if (q.get('place') === 'none') state.place = null;
  if (state.step) state.mode = 'three';

  var view = window.CircScene.create(stage);
  var az = Number(q.get('az')), el = Number(q.get('el'));
  if (q.get('az') != null && isFinite(az)) view.setView(az, isFinite(el) && q.get('el') != null ? el : 10);

  // ---------- 读数 ----------
  var cache = {};
  function setText(id, txt) {
    if (cache[id] !== txt) { cache[id] = txt; $(id).textContent = txt; }
  }
  function latCN(v) { return A.formatLatCN(v); }

  function updateReadouts() {
    var d = A.dayToDate(state.day);
    setText('rMode', state.mode === 'single' ? '单圈环流' : '三圈环流');
    var ti = A.termInfo(state.day);
    setText('rDate', d.month + '月' + d.date + '日' + (ti.exact ? ' · ' + ti.exact.name : ''));
    var move = A.declination(state.day + 1) - state.decl;
    var atSol = ti.exact && (ti.exact.key === 'summer' || ti.exact.key === 'winter');
    setText('rDecl', latCN(state.decl) + (atSol ? (state.decl > 0 ? '（最北）' : '（最南）') : move > 0 ? ' · 北移 ↑' : ' · 南移 ↓'));
    var s = state.s;
    var sTxt = Math.abs(s) < 0.3 ? '位于春秋分时的平均位置' : '比平均位置偏' + (s > 0 ? '北' : '南') + '约 ' + Math.abs(s).toFixed(1) + '°';
    setText('rShift', sTxt);
    setText('rEq', '赤道低气压带中心 ' + latCN(C.toReal(0, s)) + (state.mode === 'three' ? '，副热带高压 ' + C.toReal(30, s).toFixed(1) + '°N / ' + Math.abs(C.toReal(-30, s)).toFixed(1) + '°S' : ''));

    var P = state.place;
    if (!P) {
      ['rPlace', 'rCtrl', 'rWind', 'rClimate'].forEach(function (id) { setText(id, '—'); });
      setText('rCtrlDesc', '在地球上点一下，或在下方选择地点');
    } else {
      setText('rPlace', P.name);
      var z = C.zoneAt(P.lat, s, state.mode);
      setText('rCtrl', z.name);
      setText('rCtrlDesc', z.desc);
      var w = C.windAt(P.lat, s, state.mode);
      setText('rWind', C.windName(w));
      var cl = C.climateOf(P.lat, state.mode);
      setText('rClimate', cl.name);
      setText('climateNote', cl.text + (state.mode === 'three' ? ' 注：只考虑气压带风带，实际气候还受海陆位置、地形、洋流等影响。' : ''));
    }

    // 节气、模式、步骤按钮
    document.querySelectorAll('[data-term]').forEach(function (b) {
      var on = !!(ti.exact && ti.exact.key === b.dataset.term);
      if (b.classList.contains('on') !== on) b.classList.toggle('on', on);
    });
    if (!sliderActive) {
      var dv = String(Math.floor(A.wrapDay(state.day)));
      if (daySlider.value !== dv) daySlider.value = dv;
    }
    setText('dayOut', d.month + '/' + d.date);
  }

  // ---------- 全年受控条带 ----------
  var strip = $('yearStrip'), sctx = strip.getContext('2d');
  var stripKey = '';
  function drawStrip() {
    var P = state.place;
    var dpr = Math.min(window.devicePixelRatio || 1, 2);
    var w = strip.clientWidth || 300, h = 64;
    var month = A.dayToDate(state.day).month;
    var key = [P ? P.lat : 'x', state.mode, month, w, dpr].join('|');
    if (key === stripKey) return;
    stripKey = key;
    strip.width = w * dpr; strip.height = h * dpr;
    sctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    sctx.clearRect(0, 0, w, h);
    if (!P) return;
    var ys = C.yearControl(P.lat, state.mode);
    var cw = w / 12;
    ys.forEach(function (z, i) {
      sctx.fillStyle = z.color;
      sctx.globalAlpha = z.kind === 'W' ? 0.75 : 0.85;
      sctx.fillRect(i * cw + 1, 4, cw - 2, 26);
      sctx.globalAlpha = 1;
      sctx.fillStyle = '#0b1222';
      sctx.font = '600 11px -apple-system, "PingFang SC", "Microsoft YaHei", sans-serif';
      sctx.textAlign = 'center';
      var short = z.kind === 'H' ? '高' : z.kind === 'L' ? '低' : z.name.replace(/风带$/, '').replace('盛行', '').slice(0, 2);
      sctx.fillText(short, i * cw + cw / 2, 21);
      sctx.fillStyle = i + 1 === month ? '#ffc94a' : '#8d99ab';
      sctx.font = (i + 1 === month ? '600 ' : '') + '11px -apple-system, "PingFang SC", sans-serif';
      sctx.fillText((i + 1) + '月', i * cw + cw / 2, 46);
    });
    sctx.strokeStyle = '#ffc94a';
    sctx.lineWidth = 2;
    sctx.strokeRect((month - 1) * cw + 1, 3, cw - 2, 28);
    sctx.fillStyle = '#8d99ab';
    sctx.font = '10px -apple-system, "PingFang SC", sans-serif';
    sctx.textAlign = 'left';
    sctx.fillText('高 = 高气压带 · 低 = 低气压带 · 信风 / 西风 / 极地 = 风带', 0, 61);
  }

  // ---------- 形成过程 ----------
  function setStep(n) {
    state.step = Math.max(0, Math.min(C.STEPS.length, n));
    if (state.step) setMode('three', true);
    var cap = $('caption');
    if (!state.step) {
      cap.hidden = true;
      $('stepLabel').textContent = '未开始';
    } else {
      var S = C.STEPS[state.step - 1];
      cap.hidden = false;
      $('capTitle').textContent = S.title;
      $('capText').textContent = S.text;
      $('stepLabel').textContent = state.step + ' / ' + C.STEPS.length;
    }
    $('stepPrev').disabled = state.step <= 1;
    $('stepNext').disabled = state.step >= C.STEPS.length;
    $('stepExit').hidden = !state.step;
    $('stepNext').textContent = state.step ? '下一步 ›' : '▶ 开始讲解';
  }
  $('stepPrev').addEventListener('click', function () { setStep(state.step - 1); });
  $('stepNext').addEventListener('click', function () {
    setStep(state.step + 1);
    Analytics.track('三圈环流', '形成过程', String(state.step));
  });
  $('stepExit').addEventListener('click', function () { setStep(0); });
  $('capClose').addEventListener('click', function () { setStep(0); });

  // ---------- 模式 ----------
  function setMode(m, keepStep) {
    state.mode = m;
    if (m === 'single' && !keepStep) setStep(0);
    document.querySelectorAll('[data-mode]').forEach(function (b) { b.classList.toggle('on', b.dataset.mode === m); });
    $('modeNote').textContent = m === 'single'
      ? '假设地球不自转、地表均匀：赤道受热上升、极地冷却下沉，高空由赤道流向极地，近地面由极地流回赤道，每个半球只有一个环流圈。'
      : '地球自转产生地转偏向力，北半球向右偏、南半球向左偏，单圈环流被“拆”成低纬、中纬、高纬三个环流圈。';
    stripKey = '';
  }
  document.querySelectorAll('[data-mode]').forEach(function (b) {
    b.addEventListener('click', function () {
      setMode(b.dataset.mode);
      Analytics.track('三圈环流', '切换模式', b.dataset.mode);
    });
  });

  // ---------- 季节 ----------
  document.querySelectorAll('[data-term]').forEach(function (b) {
    b.addEventListener('click', function () {
      state.day = TERM_BY_KEY[b.dataset.term].day;
      setPlay(false);
      Analytics.track('三圈环流', '跳转节气', b.dataset.term);
    });
  });
  var daySlider = $('daySlider'), sliderActive = false;
  daySlider.addEventListener('pointerdown', function () { sliderActive = true; });
  window.addEventListener('pointerup', function () { sliderActive = false; });
  daySlider.addEventListener('input', function () { state.day = Number(daySlider.value); setPlay(false); });
  function setPlay(on) {
    state.play = on;
    $('playBtn').textContent = on ? '❚❚ 暂停季节变化' : '▶ 播放一年的变化';
    $('playBtn').classList.toggle('on', on);
  }
  $('playBtn').addEventListener('click', function () {
    setPlay(!state.play);
    if (state.play) Analytics.track('三圈环流', '播放季节');
  });

  // ---------- 地点 ----------
  var sel = $('placeSel');
  C.PLACES.forEach(function (p) {
    var o = document.createElement('option');
    o.value = p.key;
    o.textContent = p.name + '　' + A.formatLat(p.lat);
    sel.appendChild(o);
  });
  var optCustom = document.createElement('option');
  optCustom.value = 'custom'; optCustom.textContent = '（在地球上点选）';
  sel.appendChild(optCustom);
  var optNone = document.createElement('option');
  optNone.value = 'none'; optNone.textContent = '（不显示）';
  sel.appendChild(optNone);
  function syncSel() { sel.value = state.place ? state.place.key : 'none'; }
  sel.addEventListener('change', function () {
    if (sel.value === 'custom') { if (!state.place || state.place.key !== 'custom') state.place = customPlace(0, 100); }
    else state.place = placeByKey(sel.value);
    stripKey = '';
    Analytics.track('三圈环流', '选择地点', sel.value);
  });

  // 点击地球选点（拖动视角不算点击）
  var down = null;
  view.canvas.addEventListener('pointerdown', function (e) { down = { x: e.clientX, y: e.clientY }; });
  view.canvas.addEventListener('pointerup', function (e) {
    if (!down || Math.hypot(e.clientX - down.x, e.clientY - down.y) > 6) { down = null; return; }
    down = null;
    var hit = view.pick(e.clientX, e.clientY);
    if (!hit) return;
    state.place = customPlace(hit.lat, hit.lon);
    syncSel();
    stripKey = '';
    Analytics.track('三圈环流', '点选地点');
  });

  // ---------- 显示 ----------
  Object.keys(state.show).forEach(function (k) {
    var el = $('show-' + k);
    el.checked = state.show[k];
    el.addEventListener('change', function () { state.show[k] = el.checked; });
  });
  $('spinOn').checked = state.spin;
  $('spinOn').addEventListener('change', function () { state.spin = $('spinOn').checked; });
  var fs = $('flowSpeed');
  fs.addEventListener('input', function () { state.flowSpeed = Number(fs.value); $('flowOut').textContent = state.flowSpeed.toFixed(1) + '×'; });
  $('flowOut').textContent = state.flowSpeed.toFixed(1) + '×';
  $('resetView').addEventListener('click', function () { view.resetView(); });

  $('panelToggle').addEventListener('click', function () { panel.classList.toggle('collapsed'); });
  if (window.matchMedia('(max-width: 760px)').matches) panel.classList.add('collapsed');

  window.addEventListener('keydown', function (e) {
    var t = e.target.tagName;
    if (t === 'INPUT' || t === 'SELECT' || t === 'BUTTON' || t === 'TEXTAREA') return;
    if (e.code === 'Space') { e.preventDefault(); setPlay(!state.play); }
    else if (e.code === 'ArrowRight') setStep(state.step + 1);
    else if (e.code === 'ArrowLeft') setStep(state.step - 1);
    else if (e.code === 'KeyR' && !e.metaKey && !e.ctrlKey) view.resetView();
  });

  // ---------- 初始化 ----------
  setMode(state.mode, true);
  setStep(state.step);
  setPlay(state.play);
  syncSel();

  // ---------- 主循环 ----------
  var last = performance.now();
  function frame(t) {
    var dt = Math.min((t - last) / 1000, 0.1);
    last = t;
    if (state.play) state.day = A.wrapDay(state.day + state.playSpeed * dt);
    state.decl = A.declination(state.day);
    state.s = C.shiftOf(state.decl);
    view.update(state, dt);
    updateReadouts();
    drawStrip();
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // 调试用
  window.__model = {
    state: state, view: view, setStep: setStep, setMode: setMode,
    setDay: function (d) { state.day = d; }, setPlace: function (lat, lon) { state.place = customPlace(lat, lon); syncSel(); stripKey = ''; }
  };
})();
