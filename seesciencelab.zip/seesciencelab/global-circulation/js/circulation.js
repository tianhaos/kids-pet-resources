// 纯计算：三圈环流的气压带、风带、环流圈及其季节移动（不碰 DOM，依赖 shared/astro.js）
// 纬度一律用度，北正南负。“基准纬度” p 指春分、秋分时的位置（气压带在 0°、30°、60°、90°），
// 实际纬度 lat = p + s·w(p)：s 为季节移动量，w(p) 让赤道到副热带整体移动、副极地移动一半、极点不动。
(function () {
  var A = window.Astro;
  var K_SHIFT = 0.3; // 移动量 = 直射点纬度 × 0.3，最大约 7°（课本：约 5~10 个纬度）

  function weight(p) {
    var a = Math.abs(p);
    if (a <= 30) return 1;
    if (a <= 60) return 1 - 0.5 * (a - 30) / 30;
    if (a < 90) return 0.5 * (90 - a) / 30;
    return 0;
  }
  function shiftOf(decl) { return K_SHIFT * decl; }
  function shiftOfDay(day) { return shiftOf(A.declination(day)); }
  function toReal(p, s) { return p + s * weight(p); }
  // 反解：|s·w′| ≤ 7/60，不动点迭代很快收敛
  function toBase(lat, s) {
    var p = lat;
    for (var i = 0; i < 12; i++) p = lat - s * weight(p);
    return Math.max(-90, Math.min(90, p));
  }

  // ---------- 气压带与风带（基准纬度范围，自南向北） ----------
  var C_TRADE = '#ffb74d', C_WEST = '#7ee081', C_POLAR = '#80deea', C_LOW = '#ff6b5b', C_HIGH = '#4f9dff', C_PLAIN = '#d6deea';
  var ZONES3 = [
    { id: 'sPolarH', kind: 'H', name: '极地高气压带', from: -90, to: -84, c: -90, desc: '气温低，空气冷却收缩下沉，干燥少雨' },
    { id: 'sPolarE', kind: 'W', name: '极地东风带', wind: '东南风', from: -84, to: -65, color: C_POLAR, desc: '由极地吹向副极地，寒冷干燥' },
    { id: 'sSubpolarL', kind: 'L', name: '副极地低气压带', from: -65, to: -55, c: -60, desc: '冷暖气流相遇，暖空气抬升，多阴雨' },
    { id: 'sWesterly', kind: 'W', name: '盛行西风带', wind: '西北风', from: -55, to: -36, color: C_WEST, desc: '由较低纬吹向较高纬，从海洋带来水汽，温和湿润（大陆西岸）' },
    { id: 'sSubtropH', kind: 'H', name: '副热带高气压带', from: -36, to: -24, c: -30, desc: '盛行下沉气流，炎热干燥' },
    { id: 'sTrade', kind: 'W', name: '东南信风带', wind: '东南风', from: -24, to: -9, color: C_TRADE, desc: '由副热带吹向赤道，由较冷处吹向较热处，干燥少雨（大陆西岸）' },
    { id: 'eqL', kind: 'L', name: '赤道低气压带', from: -9, to: 9, c: 0, desc: '受热多，盛行上升气流，高温多雨' },
    { id: 'nTrade', kind: 'W', name: '东北信风带', wind: '东北风', from: 9, to: 24, color: C_TRADE, desc: '由副热带吹向赤道，由较冷处吹向较热处，干燥少雨（大陆西岸）' },
    { id: 'nSubtropH', kind: 'H', name: '副热带高气压带', from: 24, to: 36, c: 30, desc: '盛行下沉气流，炎热干燥' },
    { id: 'nWesterly', kind: 'W', name: '盛行西风带', wind: '西南风', from: 36, to: 55, color: C_WEST, desc: '由较低纬吹向较高纬，从海洋带来水汽，温和湿润（大陆西岸）' },
    { id: 'nSubpolarL', kind: 'L', name: '副极地低气压带', from: 55, to: 65, c: 60, desc: '冷暖气流相遇，暖空气抬升，多阴雨' },
    { id: 'nPolarE', kind: 'W', name: '极地东风带', wind: '东北风', from: 65, to: 84, color: C_POLAR, desc: '由极地吹向副极地，寒冷干燥' },
    { id: 'nPolarH', kind: 'H', name: '极地高气压带', from: 84, to: 90, c: 90, desc: '气温低，空气冷却收缩下沉，干燥少雨' }
  ];
  // 单圈环流（假设地球不自转、地表均匀）
  var ZONES1 = [
    { id: 'sPolarH', kind: 'H', name: '极地高气压', from: -90, to: -84, c: -90, desc: '极地寒冷，空气冷却下沉' },
    { id: 'sFlow', kind: 'W', name: '近地面南风', wind: '南风', from: -84, to: -9, color: C_PLAIN, desc: '近地面空气由极地流向赤道，不发生偏转' },
    { id: 'eqL', kind: 'L', name: '赤道低气压', from: -9, to: 9, c: 0, desc: '赤道受热，空气膨胀上升' },
    { id: 'nFlow', kind: 'W', name: '近地面北风', wind: '北风', from: 9, to: 84, color: C_PLAIN, desc: '近地面空气由极地流向赤道，不发生偏转' },
    { id: 'nPolarH', kind: 'H', name: '极地高气压', from: 84, to: 90, c: 90, desc: '极地寒冷，空气冷却下沉' }
  ];
  ZONES3.concat(ZONES1).forEach(function (z) {
    if (z.kind === 'L') z.color = C_LOW;
    if (z.kind === 'H') z.color = C_HIGH;
    if (z.kind === 'W') z.mid = (z.from + z.to) / 2;
  });
  // 七个气压带的顺序（着色器里 focus[7] 按此顺序）
  var BELT_IDS = ['nPolarH', 'nSubpolarL', 'nSubtropH', 'eqL', 'sSubtropH', 'sSubpolarL', 'sPolarH'];

  function zones(mode) { return mode === 'single' ? ZONES1 : ZONES3; }
  function zoneAtBase(p, mode) {
    var Z = zones(mode);
    for (var i = 0; i < Z.length; i++) if (p <= Z[i].to) return Z[i];
    return Z[Z.length - 1];
  }
  function zoneAt(lat, s, mode) { return zoneAtBase(toBase(lat, s), mode); }

  // 近地面风（u 向东、v 向北，大小 0~1）；气压带中心风速为 0（无风带）
  function windBase(p, mode) {
    var r = Math.PI / 180;
    if (mode === 'single') return { u: 0, v: -Math.sin(2 * p * r) };
    return { u: -Math.sin(6 * Math.abs(p) * r), v: -0.75 * Math.sin(6 * p * r) };
  }
  function windAt(lat, s, mode) { return windBase(toBase(lat, s), mode); }

  // 风向（“从哪里吹来”）的八方位名称
  function windName(w) {
    if (Math.hypot(w.u, w.v) < 0.12) return '风力微弱';
    var from = Math.atan2(-w.u, -w.v) * 180 / Math.PI; // 方位角：北 0、东 90
    var names = ['北风', '东北风', '东风', '东南风', '南风', '西南风', '西风', '西北风'];
    return names[((Math.round(from / 45) % 8) + 8) % 8];
  }

  // ---------- 环流圈（剖面上的闭合环线） ----------
  // rise：上升处的基准纬度，sink：下沉处；高空由 rise 流向 sink，近地面流回
  var CELLS3 = [
    { id: 'nPolar', name: '高纬环流', rise: 60, sink: 90, color: '#4fc3f7' },
    { id: 'nFerrel', name: '中纬环流', rise: 60, sink: 30, color: '#9ccc65' },
    { id: 'nHadley', name: '低纬环流', rise: 0, sink: 30, color: '#ff8a65' },
    { id: 'sHadley', name: '低纬环流', rise: 0, sink: -30, color: '#ff8a65' },
    { id: 'sFerrel', name: '中纬环流', rise: -60, sink: -30, color: '#9ccc65' },
    { id: 'sPolar', name: '高纬环流', rise: -60, sink: -90, color: '#4fc3f7' }
  ];
  var CELLS1 = [
    { id: 'nSingle', name: '单圈环流', rise: 0, sink: 90, color: '#ffd54f' },
    { id: 'sSingle', name: '单圈环流', rise: 0, sink: -90, color: '#ffd54f' }
  ];
  function cells(mode) { return mode === 'single' ? CELLS1 : CELLS3; }
  // t ∈ [0,1)：0 在上升处底部，沿 上升 → 高空 → 下沉 → 近地面 绕行；返回基准纬度 p 与高度 h（0 地面 ~ 1 对流层顶）
  function cellPoint(cell, t) {
    var a = t * 2 * Math.PI, c = Math.cos(a), sn = Math.sin(a);
    var x = -Math.sign(c) * Math.pow(Math.abs(c), 0.55);   // 方圆形环线
    var y = Math.sign(sn) * Math.pow(Math.abs(sn), 0.55);
    var span = cell.sink - cell.rise;
    return { p: cell.rise + span * (0.08 + 0.84 * (x + 1) / 2), h: 0.5 + 0.36 * y };
  }

  // ---------- 地转偏向示意路径（基准纬度 p、相对经度 dl） ----------
  // 前半段 t 线性推进纬度，经度按 t² 偏转（越走偏得越多）
  var PATHS = [
    { id: 'nAloft', zone: 'nTrade', aloft: true, from: [3, -22], to: [27, 18], color: '#ffccbc' },
    { id: 'nTrade', zone: 'nTrade', from: [27, 14], to: [4, -24], color: C_TRADE },
    { id: 'nWest', zone: 'nWesterly', from: [33, -18], to: [56, 20], color: C_WEST },
    { id: 'nPolarE', zone: 'nPolarE', from: [86, 14], to: [64, -22], color: C_POLAR },
    { id: 'sAloft', zone: 'sTrade', aloft: true, from: [-3, -22], to: [-27, 18], color: '#ffccbc' },
    { id: 'sTrade', zone: 'sTrade', from: [-27, 14], to: [-4, -24], color: C_TRADE },
    { id: 'sWest', zone: 'sWesterly', from: [-33, -18], to: [-56, 20], color: C_WEST },
    { id: 'sPolarE', zone: 'sPolarE', from: [-86, 14], to: [-64, -22], color: C_POLAR }
  ];
  function pathPoint(path, t) {
    return {
      p: path.from[0] + (path.to[0] - path.from[0]) * t,
      dl: path.from[1] + (path.to[1] - path.from[1]) * t * t
    };
  }

  // ---------- 形成过程（分步讲解，focus 中列出的对象高亮） ----------
  var STEPS = [
    { title: '① 赤道受热上升', text: '赤道地区终年受热多，空气膨胀上升，近地面形成赤道低气压带；上升气流到高空后流向两极。',
      belts: ['eqL'], cells: ['nHadley', 'sHadley'], paths: [] },
    { title: '② 高空偏转，30° 附近下沉', text: '高空气流在地转偏向力作用下，北半球向右偏、南半球向左偏，到南北纬 30° 附近已偏成西风，不能再向高纬流动，空气堆积下沉，近地面形成副热带高气压带。',
      belts: ['eqL', 'nSubtropH', 'sSubtropH'], cells: ['nHadley', 'sHadley'], paths: ['nAloft', 'sAloft'] },
    { title: '③ 回流赤道：信风与低纬环流', text: '副热带高气压带的空气一部分流回赤道低气压带，北半球右偏成东北信风，南半球左偏成东南信风，与上升、高空、下沉气流一起构成低纬环流。',
      belts: ['eqL', 'nSubtropH', 'sSubtropH'], winds: ['nTrade', 'sTrade'], cells: ['nHadley', 'sHadley'], paths: ['nTrade', 'sTrade'] },
    { title: '④ 极地下沉：极地东风', text: '极地气温低，空气冷却收缩下沉，近地面形成极地高气压带；气流流向较低纬度，偏转成极地东风（北半球东北风、南半球东南风）。',
      belts: ['nPolarH', 'sPolarH'], winds: ['nPolarE', 'sPolarE'], cells: [], paths: ['nPolarE', 'sPolarE'] },
    { title: '⑤ 60° 附近相遇：西风与中、高纬环流', text: '副热带高气压带的另一部分空气流向高纬，偏转成盛行西风；它与极地东风在 60° 附近相遇，较暖较轻的西风气流爬升到冷空气之上，形成副极地低气压带。上升气流在高空分别流向副热带和极地，形成中纬环流和高纬环流。',
      belts: ['nSubpolarL', 'sSubpolarL'], winds: ['nWesterly', 'sWesterly', 'nPolarE', 'sPolarE'], cells: ['nFerrel', 'sFerrel', 'nPolar', 'sPolar'], paths: ['nWest', 'sWest'] },
    { title: '⑥ 七个气压带、六个风带', text: '三圈环流在近地面形成 7 个气压带（高、低压相间分布）和 6 个风带，南北半球对称。它们随太阳直射点的季节移动而移动，就北半球而言，大致夏季北移、冬季南移。',
      all: true }
  ];

  // 某对象在当前步骤中的高亮程度（0 弱化 ~ 1 正常）
  function focusOf(step, kind, id) {
    if (!step) return 1;
    var S = STEPS[step - 1];
    if (S.all) return 1;
    var list = S[kind] || [];
    return list.indexOf(id) >= 0 ? 1 : 0;
  }

  // ---------- 地点：全年受控情况与气候类型（只考虑气压带风带） ----------
  var MID_DAYS = [15, 46, 74, 105, 135, 166, 196, 227, 258, 288, 319, 349];
  function yearControl(lat, mode) {
    return MID_DAYS.map(function (d) { return zoneAt(lat, shiftOfDay(d), mode); });
  }
  function climateOf(lat, mode) {
    if (mode === 'single') return { name: '—', text: '单圈环流只是假设，现实中地球自转，形成三圈环流。' };
    var ys = yearControl(lat, mode);
    var has = {};
    ys.forEach(function (z) {
      var k = /Trade/.test(z.id) ? 'trade' : /Westerly/.test(z.id) ? 'west' : /SubtropH/.test(z.id) ? 'high'
        : z.id === 'eqL' ? 'eq' : /SubpolarL/.test(z.id) ? 'subpolar' : 'polar';
      has[k] = (has[k] || 0) + 1;
    });
    var keys = Object.keys(has);
    var only = function () { var a = [].slice.call(arguments); return keys.every(function (k) { return a.indexOf(k) >= 0; }); };
    var summerN = lat >= 0;
    if (keys.length === 1 && has.eq) return { name: '热带雨林气候', text: '全年受赤道低气压带控制，盛行上升气流，全年高温多雨。' };
    if (has.eq && has.trade && only('eq', 'trade')) return { name: '热带草原气候', text: '赤道低气压带与信风带交替控制：受赤道低压控制时为湿季，受信风控制时为干季。' };
    if (only('trade', 'high')) return { name: '热带沙漠气候', text: '受副热带高气压带或信风带控制，盛行下沉气流或由较冷处吹来的干燥信风，全年炎热干燥。' };
    if (has.high && has.west && only('high', 'west', 'trade')) return { name: '地中海气候', text: '副热带高气压带与西风带交替控制：' + (summerN ? '夏季（6~8 月）' : '夏季（12~2 月）') + '受副热带高压控制，炎热干燥；冬季受西风带控制，温和多雨。' };
    if (has.west && only('west', 'subpolar')) return { name: '温带海洋性气候', text: '全年受西风带控制，西风从海洋带来水汽，冬无严寒、夏无酷暑，全年温和多雨。' };
    if (has.polar || has.subpolar) return { name: '高纬寒冷地区', text: '受极地东风带、副极地低压或极地高压影响，终年寒冷。' };
    return { name: '—', text: '' };
  }

  // 示例地点（大陆西岸或开阔地区，气候主要由气压带风带决定）
  var PLACES = [
    { key: 'singapore', name: '新加坡', lat: 1.3, lon: 103.8 },
    { key: 'darwin', name: '达尔文（澳大利亚）', lat: -12.5, lon: 130.8 },
    { key: 'riyadh', name: '利雅得（沙特阿拉伯）', lat: 24.7, lon: 46.7 },
    { key: 'athens', name: '雅典（希腊）', lat: 38.0, lon: 23.7 },
    { key: 'perth', name: '珀斯（澳大利亚）', lat: -31.95, lon: 115.9 },
    { key: 'paris', name: '巴黎（法国）', lat: 48.9, lon: 2.35 }
  ];

  window.Circ = {
    K_SHIFT: K_SHIFT,
    weight: weight, shiftOf: shiftOf, shiftOfDay: shiftOfDay, toReal: toReal, toBase: toBase,
    ZONES3: ZONES3, ZONES1: ZONES1, BELT_IDS: BELT_IDS, zones: zones, zoneAtBase: zoneAtBase, zoneAt: zoneAt,
    windBase: windBase, windAt: windAt, windName: windName,
    CELLS3: CELLS3, CELLS1: CELLS1, cells: cells, cellPoint: cellPoint,
    PATHS: PATHS, pathPoint: pathPoint,
    STEPS: STEPS, focusOf: focusOf,
    MID_DAYS: MID_DAYS, yearControl: yearControl, climateOf: climateOf, PLACES: PLACES,
    COLORS: { trade: C_TRADE, west: C_WEST, polar: C_POLAR, low: C_LOW, high: C_HIGH, plain: C_PLAIN }
  };
})();
