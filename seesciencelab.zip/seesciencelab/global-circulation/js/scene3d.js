// three.js 场景：地球、气压带色带、近地面风（粒子 + 箭头）、经线剖面上的环流圈、地转偏向示意
// 坐标：地球半径 1，地轴沿 +y；(lat, lon) → (cos φ cos λ, sin φ, −cos φ sin λ)，与 shared/earthtex.js 贴图一致
(function () {
  var C = window.Circ, DEG = Math.PI / 180, V3 = THREE.Vector3;
  var ATM = 0.36;       // 剖面上大气层厚度（地球半径的倍数，极度夸张）
  var LBL_R = 1 + ATM + 0.09;
  var N_PART = 1600;

  function ll(lat, lon, r, out) {
    var p = lat * DEG, l = lon * DEG;
    return (out || new V3()).set(Math.cos(p) * Math.cos(l), Math.sin(p), -Math.cos(p) * Math.sin(l)).multiplyScalar(r || 1);
  }
  function css(c) { return new THREE.Color(c); }
  function clampLat(x) { return Math.max(-89.5, Math.min(89.5, x)); }

  function create(stage) {
    var renderer = new THREE.WebGLRenderer({ antialias: true, preserveDrawingBuffer: false });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    stage.insertBefore(renderer.domElement, stage.firstChild);
    var canvas = renderer.domElement;

    var labelRenderer = new THREE.CSS2DRenderer();
    var ls = labelRenderer.domElement.style;
    ls.position = 'absolute'; ls.top = '0'; ls.left = '0'; ls.pointerEvents = 'none'; ls.zIndex = '2';
    stage.appendChild(labelRenderer.domElement);

    var scene = new THREE.Scene();
    scene.background = new THREE.Color('#05070d');
    var camera = new THREE.PerspectiveCamera(32, 1, 0.1, 100);
    var controls = new THREE.OrbitControls(camera, canvas);
    controls.enableDamping = true;
    controls.dampingFactor = 0.08;
    controls.enablePan = false;
    controls.minDistance = 2.4;
    controls.maxDistance = 20;

    scene.add(new THREE.AmbientLight(0xffffff, 0.62));
    var camLight = new THREE.DirectionalLight(0xffffff, 0.5);
    scene.add(camLight);

    var root = new THREE.Group();       // 不自转：剖面、偏转示意、纬线
    var spinGroup = new THREE.Group();  // 随地球自转：地球、色带、粒子、箭头、地点
    scene.add(root);
    root.add(spinGroup);

    var allLabels = [];
    function makeLabel(html, cls, parent) {
      var el = document.createElement('div');
      el.className = 'lbl ' + (cls || '');
      el.innerHTML = html;
      var o = new THREE.CSS2DObject(el);
      o.userData.want = true;
      parent.add(o);
      allLabels.push(o);
      return o;
    }

    // ---------- 地球 ----------
    var tex = new THREE.CanvasTexture(window.makeEarthCanvas());
    tex.anisotropy = renderer.capabilities.getMaxAnisotropy();
    var earth = new THREE.Mesh(new THREE.SphereGeometry(1, 96, 64),
      new THREE.MeshLambertMaterial({ map: tex, color: 0xc8ccd4 }));
    spinGroup.add(earth);

    // ---------- 气压带色带（着色器按纬度着色，季节移动由 uniform s 决定） ----------
    var beltUniforms = {
      s: { value: 0 }, single: { value: 0 }, alpha: { value: 1 },
      focus: { value: [1, 1, 1, 1, 1, 1, 1] },
      cLow: { value: css(C.COLORS.low) }, cHigh: { value: css(C.COLORS.high) }
    };
    var beltShell = new THREE.Mesh(new THREE.SphereGeometry(1.005, 128, 96), new THREE.ShaderMaterial({
      uniforms: beltUniforms, transparent: true, depthWrite: false,
      vertexShader: [
        'varying float vY;',
        'void main(){ vY = normalize(position).y; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }'
      ].join('\n'),
      fragmentShader: [
        'uniform float s; uniform float single; uniform float alpha; uniform float focus[7];',
        'uniform vec3 cLow; uniform vec3 cHigh; varying float vY;',
        'float wgt(float p){ float a = abs(p); if (a <= 30.0) return 1.0; if (a <= 60.0) return 1.0 - 0.5 * (a - 30.0) / 30.0; return max(0.0, 0.5 * (90.0 - a) / 30.0); }',
        'float band(float x, float lo, float hi){ return smoothstep(lo - 0.7, lo + 0.7, x) * (1.0 - smoothstep(hi - 0.7, hi + 0.7, x)); }',
        'void main(){',
        '  float lat = degrees(asin(clamp(vY, -1.0, 1.0)));',
        '  float p = lat; for (int i = 0; i < 8; i++) p = lat - s * wgt(p);',
        '  float multi = 1.0 - single;',
        '  float l = band(p, -9.0, 9.0) * focus[3] + multi * (band(p, 55.0, 65.0) * focus[1] + band(p, -65.0, -55.0) * focus[5]);',
        '  float h = band(p, 84.0, 95.0) * focus[0] + band(p, -95.0, -84.0) * focus[6] + multi * (band(p, 24.0, 36.0) * focus[2] + band(p, -36.0, -24.0) * focus[4]);',
        '  float a = clamp(l + h, 0.0, 1.0);',
        '  if (a < 0.01) discard;',
        '  vec3 c = (cLow * l + cHigh * h) / max(l + h, 0.001);',
        '  gl_FragColor = vec4(c, 0.5 * a * alpha);',
        '}'
      ].join('\n')
    }));
    spinGroup.add(beltShell);

    // ---------- 参考纬线（0°、±30°、±60°，不随季节移动）与直射纬线 ----------
    var refLines = new THREE.Group();
    root.add(refLines);
    var refLabels = [];
    [-60, -30, 0, 30, 60].forEach(function (lat) {
      var pts = [];
      for (var i = 0; i <= 180; i++) pts.push(ll(lat, i * 2, 1.009));
      refLines.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts),
        new THREE.LineBasicMaterial({ color: 0xffffff, transparent: true, opacity: lat === 0 ? 0.55 : 0.32 })));
      var lb = makeLabel(lat === 0 ? '0°' : Math.abs(lat) + '°' + (lat > 0 ? 'N' : 'S'), 'lbl-lat', refLines);
      lb.userData.lat = lat;
      refLabels.push(lb);
    });
    var sunRing = new THREE.Line(new THREE.BufferGeometry().setFromPoints((function () {
      var pts = []; for (var i = 0; i <= 180; i++) pts.push(new V3(Math.cos(i * 2 * DEG), 0, -Math.sin(i * 2 * DEG))); return pts;
    })()), new THREE.LineDashedMaterial({ color: 0xffe066, dashSize: 0.04, gapSize: 0.03 }));
    sunRing.computeLineDistances();
    root.add(sunRing);
    var sunLabel = makeLabel('', 'lbl-sun', root);

    // ---------- 近地面风：粒子 ----------
    var part = { lat: new Float32Array(N_PART), lon: new Float32Array(N_PART), age: new Float32Array(N_PART), life: new Float32Array(N_PART) };
    function spawn(i, randomAge) {
      part.lat[i] = Math.asin(Math.random() * 2 - 1) / DEG;
      part.lon[i] = Math.random() * 360 - 180;
      part.life[i] = 2.5 + Math.random() * 3;
      part.age[i] = randomAge ? Math.random() * part.life[i] : 0;
    }
    for (var i = 0; i < N_PART; i++) spawn(i, true);
    var pPos = new Float32Array(N_PART * 6), pCol = new Float32Array(N_PART * 6);
    var pGeo = new THREE.BufferGeometry();
    pGeo.setAttribute('position', new THREE.BufferAttribute(pPos, 3));
    pGeo.setAttribute('color', new THREE.BufferAttribute(pCol, 3));
    var particles = new THREE.LineSegments(pGeo, new THREE.LineBasicMaterial({ vertexColors: true, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false }));
    particles.frustumCulled = false;
    spinGroup.add(particles);

    // ---------- 近地面风：箭头（每个风带每隔 30° 经度一个） ----------
    var arrowShape = new THREE.Shape();
    arrowShape.moveTo(0.075, 0); arrowShape.lineTo(0.02, 0.035); arrowShape.lineTo(0.02, 0.012);
    arrowShape.lineTo(-0.065, 0.012); arrowShape.lineTo(-0.065, -0.012); arrowShape.lineTo(0.02, -0.012);
    arrowShape.lineTo(0.02, -0.035); arrowShape.closePath();
    var arrowGeo = new THREE.ShapeGeometry(arrowShape);
    var arrowGroup = new THREE.Group();
    spinGroup.add(arrowGroup);
    var arrows = [];
    function buildArrows(mode) {
      arrows.forEach(function (a) { arrowGroup.remove(a.mesh); a.mesh.material.dispose(); });
      arrows = [];
      C.zones(mode).forEach(function (z) {
        if (z.kind !== 'W') return;
        var lats = mode === 'single' ? [z.mid - 24, z.mid, z.mid + 24] : [z.mid];
        lats.forEach(function (p) {
          for (var lon = -165; lon < 180; lon += 30) {
            var m = new THREE.Mesh(arrowGeo, new THREE.MeshBasicMaterial({ color: z.color, side: THREE.DoubleSide, transparent: true, depthWrite: false }));
            arrowGroup.add(m);
            arrows.push({ mesh: m, p: p, lon: lon + (p > 0 ? 0 : 15), zone: z });
          }
        });
      });
    }

    // ---------- 经线剖面（始终摆在画面右侧边缘） ----------
    var slice = new THREE.Group();
    root.add(slice);
    slice.add(new THREE.Mesh(new THREE.RingGeometry(1.0, 1 + ATM, 96, 1, -Math.PI / 2, Math.PI),
      new THREE.MeshBasicMaterial({ color: 0x7fb4ff, transparent: true, opacity: 0.09, side: THREE.DoubleSide, depthWrite: false })));
    slice.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints((function () {
      var pts = []; for (var i = 0; i <= 90; i++) { var a = (-90 + i * 2) * DEG; pts.push(new V3(Math.cos(a) * (1 + ATM), Math.sin(a) * (1 + ATM), 0)); } return pts;
    })()), new THREE.LineDashedMaterial({ color: 0x7fb4ff, dashSize: 0.03, gapSize: 0.03, transparent: true, opacity: 0.5 })));
    slice.children[1].computeLineDistances();

    var cellObjs = [], beltLabels = [];
    var coneGeo = new THREE.ConeGeometry(0.022, 0.06, 10);
    coneGeo.rotateZ(-Math.PI / 2); // 尖朝 +x
    function slicePos(p, h, s, out) {
      var lat = C.toReal(p, s) * DEG, r = 1 + ATM * h;
      return (out || new V3()).set(Math.cos(lat) * r, Math.sin(lat) * r, 0);
    }
    function buildCells(mode) {
      cellObjs.forEach(function (c) { slice.remove(c.line); c.cones.forEach(function (k) { slice.remove(k); }); slice.remove(c.label); });
      beltLabels.forEach(function (o) { o.parent.remove(o); });
      allLabels = allLabels.filter(function (o) { return o.parent; });
      cellObjs = []; beltLabels = [];
      C.cells(mode).forEach(function (cell) {
        var n = 140, pos = new Float32Array(n * 3);
        var g = new THREE.BufferGeometry();
        g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
        var mat = new THREE.LineBasicMaterial({ color: cell.color, transparent: true });
        var line = new THREE.LineLoop(g, mat);
        slice.add(line);
        var cones = [];
        for (var k = 0; k < 4; k++) {
          var cone = new THREE.Mesh(coneGeo, new THREE.MeshBasicMaterial({ color: cell.color, transparent: true }));
          slice.add(cone); cones.push(cone);
        }
        var label = makeLabel(cell.name, 'lbl-cell', slice);
        label.element.style.color = cell.color;
        cellObjs.push({ cell: cell, line: line, n: n, cones: cones, label: label });
      });
      C.zones(mode).forEach(function (z) {
        var cls = z.kind === 'W' ? 'lbl-wind' : 'lbl-belt ' + (z.kind === 'L' ? 'low' : 'high');
        var html = z.kind === 'W' ? z.name : '<i>' + (z.kind === 'L' ? '低' : '高') + '</i>' + z.name;
        var o = makeLabel(html, cls, slice);
        if (z.kind === 'W') o.element.style.color = z.color;
        o.userData.zone = z;
        beltLabels.push(o);
      });
    }

    // ---------- 地转偏向示意（摆在正对相机的一侧） ----------
    var deflect = new THREE.Group();
    root.add(deflect);
    var pathObjs = C.PATHS.map(function (path) {
      var n = 48, g = new THREE.BufferGeometry();
      g.setAttribute('position', new THREE.BufferAttribute(new Float32Array(n * 3), 3));
      var mat = path.aloft
        ? new THREE.LineDashedMaterial({ color: path.color, dashSize: 0.03, gapSize: 0.02, transparent: true })
        : new THREE.LineBasicMaterial({ color: path.color, transparent: true });
      var line = new THREE.Line(g, mat);
      var head = new THREE.Mesh(new THREE.ConeGeometry(0.03, 0.08, 12), new THREE.MeshBasicMaterial({ color: path.color, transparent: true }));
      head.geometry.rotateZ(-Math.PI / 2);
      deflect.add(line); deflect.add(head);
      return { path: path, line: line, head: head, n: n };
    });
    var deflectLabel = makeLabel('', 'lbl-deflect', deflect);

    // ---------- 地点标记 ----------
    var placeMark = new THREE.Mesh(new THREE.SphereGeometry(0.022, 16, 12), new THREE.MeshBasicMaterial({ color: 0xff5252 }));
    spinGroup.add(placeMark);
    var placeRing = new THREE.Mesh(new THREE.RingGeometry(0.03, 0.042, 24), new THREE.MeshBasicMaterial({ color: 0xffffff, side: THREE.DoubleSide }));
    placeMark.add(placeRing);
    var placeLabel = makeLabel('', 'lbl-place', placeMark);

    // ---------- 相机 ----------
    var W = 1, H = 1;
    var VIEW_ELEV = 10 * DEG, VIEW_AZ = -15 * DEG; // 初始从赤道略上方、经度约 75°E 附近看
    function fitDistance() {
      var t = Math.tan(camera.fov / 2 * DEG);
      var needV = 1.8, needH = W / H < 1 ? 2.0 : 2.35; // 右侧要给剖面标签留位置
      return Math.max(needV / t, needH / (t * camera.aspect)) * 1.02;
    }
    function viewShift() { return W / H < 1 ? 0.1 * W : 0.11 * W; } // 把地球往左推，右边放标签
    function homePos() {
      var d = fitDistance();
      return new V3(Math.cos(VIEW_ELEV) * Math.sin(VIEW_AZ), Math.sin(VIEW_ELEV), Math.cos(VIEW_ELEV) * Math.cos(VIEW_AZ)).multiplyScalar(d);
    }
    var viewAnim = null;
    function resetView(instant) {
      if (instant) { camera.position.copy(homePos()); controls.target.set(0, 0, 0); return; }
      viewAnim = { t: 0, from: camera.position.clone() };
    }
    controls.addEventListener('start', function () { viewAnim = null; });
    function resize() {
      W = stage.clientWidth; H = stage.clientHeight;
      renderer.setSize(W, H);
      labelRenderer.setSize(W, H);
      camera.aspect = W / H;
      camera.setViewOffset(W, H, viewShift(), 0, W, H);
      camera.updateProjectionMatrix();
      if (!camera.userData.touched) resetView(true);
    }
    controls.addEventListener('change', function () { camera.userData.touched = true; });

    // ---------- 点选地球 ----------
    var raycaster = new THREE.Raycaster(), ndc = new THREE.Vector2();
    function pick(clientX, clientY) {
      var r = canvas.getBoundingClientRect();
      ndc.set((clientX - r.left) / r.width * 2 - 1, -(clientY - r.top) / r.height * 2 + 1);
      raycaster.setFromCamera(ndc, camera);
      var hit = raycaster.intersectObject(earth, false)[0];
      if (!hit) return null;
      var p = spinGroup.worldToLocal(hit.point.clone()).normalize();
      return { lat: Math.asin(p.y) / DEG, lon: Math.atan2(-p.z, p.x) / DEG };
    }

    // ---------- 每帧更新 ----------
    var clock = 0, tmp = new V3(), tmp2 = new V3(), camLocal = new V3();
    var lastMode = null;
    var zoneColor = {};
    function colorOfZone(z) { return zoneColor[z.id] || (zoneColor[z.id] = css(z.color)); }
    var cTmp = new THREE.Color(), cTmp2 = new THREE.Color();

    function updateParticles(st, s, dt) {
      var sp = 13 * st.flowSpeed; // 度/秒（风速 1 时）
      for (var i = 0; i < N_PART; i++) {
        part.age[i] += dt;
        var lat = part.lat[i];
        var p = C.toBase(lat, s), w = C.windBase(p, st.mode);
        var cl = Math.max(Math.cos(lat * DEG), 0.15);
        part.lat[i] = lat + w.v * sp * dt;
        part.lon[i] += w.u * sp * dt / cl;
        if (part.age[i] > part.life[i] || Math.abs(part.lat[i]) > 89) spawn(i, false);
        lat = part.lat[i];
        var lon = part.lon[i];
        var k = 4.5; // 尾迹长度（度/单位风速）
        var head = ll(lat, lon, 1.012, tmp), tail = ll(clampLat(lat - w.v * k), lon - w.u * k / cl, 1.012, tmp2);
        pPos[i * 6] = head.x; pPos[i * 6 + 1] = head.y; pPos[i * 6 + 2] = head.z;
        pPos[i * 6 + 3] = tail.x; pPos[i * 6 + 4] = tail.y; pPos[i * 6 + 5] = tail.z;
        var z = C.zoneAtBase(p, st.mode);
        var a = part.age[i], L = part.life[i];
        var fade = Math.min(1, a / 0.5, (L - a) / 0.5) * (0.2 + 0.8 * C.focusOf(st.step, 'winds', z.id));
        if (z.kind !== 'W') fade *= 0.6;
        cTmp.copy(z.kind === 'W' ? colorOfZone(z) : colorOfZone({ id: '_calm', color: '#cfd8dc' })).multiplyScalar(fade);
        pCol[i * 6] = cTmp.r; pCol[i * 6 + 1] = cTmp.g; pCol[i * 6 + 2] = cTmp.b;
        cTmp2.copy(cTmp).multiplyScalar(0.05); // 尾部近黑，加法混合下即透明
        pCol[i * 6 + 3] = cTmp2.r; pCol[i * 6 + 4] = cTmp2.g; pCol[i * 6 + 5] = cTmp2.b;
      }
      pGeo.attributes.position.needsUpdate = true;
      pGeo.attributes.color.needsUpdate = true;
    }

    var basis = new THREE.Matrix4();
    function updateArrows(st, s) {
      arrows.forEach(function (a) {
        var lat = C.toReal(a.p, s), w = C.windBase(a.p, st.mode);
        var l = a.lon * DEG, ph = lat * DEG;
        var e = new V3(-Math.sin(l), 0, -Math.cos(l));
        var n = new V3(-Math.sin(ph) * Math.cos(l), Math.cos(ph), Math.sin(ph) * Math.sin(l));
        var nrm = ll(lat, a.lon, 1);
        var d = e.multiplyScalar(w.u).add(n.multiplyScalar(w.v)).normalize();
        basis.makeBasis(d, nrm.clone().cross(d), nrm);
        a.mesh.matrixAutoUpdate = false;
        a.mesh.matrix.copy(basis).setPosition(nrm.multiplyScalar(1.016));
        a.mesh.material.opacity = 0.25 + 0.75 * C.focusOf(st.step, 'winds', a.zone.id);
      });
    }

    function update(st, dt) {
      clock += dt;
      var s = st.s;
      if (st.mode !== lastMode) { buildArrows(st.mode); buildCells(st.mode); lastMode = st.mode; }
      var single = st.mode === 'single';
      if (st.spin) spinGroup.rotation.y += dt * 0.12;

      if (viewAnim) {
        viewAnim.t = Math.min(1, viewAnim.t + dt / 0.8);
        var k = 1 - Math.pow(1 - viewAnim.t, 3);
        camera.position.lerpVectors(viewAnim.from, homePos(), k);
        if (viewAnim.t >= 1) { viewAnim = null; camera.userData.touched = false; }
      }
      controls.update();
      camLight.position.copy(camera.position);

      // 相机所在经度（root 坐标）：剖面放在画面右缘，偏转示意放在正面偏左
      camLocal.copy(camera.position);
      var camLon = Math.atan2(-camLocal.z, camLocal.x) / DEG;
      slice.rotation.y = (camLon + 80) * DEG;
      var frontLon = camLon - 12;

      // 色带
      beltUniforms.s.value = s;
      beltUniforms.single.value = single ? 1 : 0;
      C.BELT_IDS.forEach(function (id, i) { beltUniforms.focus.value[i] = 0.18 + 0.82 * C.focusOf(st.step, 'belts', id); });
      beltShell.visible = st.show.belts;

      // 直射纬线
      var dl = st.decl * DEG;
      sunRing.position.y = Math.sin(dl) * 1.011;
      sunRing.scale.set(Math.cos(dl) * 1.011, 1, Math.cos(dl) * 1.011);
      sunLabel.element.textContent = '☀ 直射 ' + (Math.abs(st.decl) < 0.05 ? '赤道' : Math.abs(st.decl).toFixed(1) + '°' + (st.decl > 0 ? 'N' : 'S'));
      sunLabel.position.copy(ll(st.decl, camLon - 38, 1.02));

      refLines.visible = st.show.lat;
      refLabels.forEach(function (o) {
        o.position.copy(ll(o.userData.lat, camLon - 88, 1.05));
        o.userData.want = st.show.lat;
      });

      // 粒子与箭头
      particles.visible = st.show.flow;
      if (st.show.flow) updateParticles(st, s, st.paused ? 0 : dt);
      arrowGroup.visible = st.show.arrows;
      if (st.show.arrows) updateArrows(st, s);

      // 剖面
      slice.visible = st.show.cells;
      cellObjs.forEach(function (o) {
        var arr = o.line.geometry.attributes.position.array;
        for (var i = 0; i < o.n; i++) {
          var q = C.cellPoint(o.cell, i / o.n);
          slicePos(q.p, q.h, s, tmp);
          arr[i * 3] = tmp.x; arr[i * 3 + 1] = tmp.y; arr[i * 3 + 2] = tmp.z;
        }
        o.line.geometry.attributes.position.needsUpdate = true;
        var f = C.focusOf(st.step, 'cells', o.cell.id);
        o.line.material.opacity = 0.2 + 0.8 * f;
        var speed = st.paused ? 0 : 0.07 * st.flowSpeed;
        o.phase = (o.phase || 0) + speed * dt;
        o.cones.forEach(function (cone, k) {
          var t = (o.phase + k / o.cones.length) % 1;
          var a = C.cellPoint(o.cell, t), b = C.cellPoint(o.cell, (t + 0.004) % 1);
          slicePos(a.p, a.h, s, tmp); slicePos(b.p, b.h, s, tmp2);
          cone.position.copy(tmp);
          cone.rotation.z = Math.atan2(tmp2.y - tmp.y, tmp2.x - tmp.x);
          cone.material.opacity = 0.2 + 0.8 * f;
        });
        var pc = (o.cell.rise + o.cell.sink) / 2;
        o.label.position.copy(slicePos(pc, 0.5, s, tmp));
        o.label.userData.want = st.show.cells && W > 560;
        o.label.element.style.opacity = 0.35 + 0.65 * f;
      });
      beltLabels.forEach(function (o) {
        var z = o.userData.zone;
        var p = z.kind === 'W' ? z.mid : z.c;
        var lat = C.toReal(p, s) * DEG;
        var r = Math.abs(p) === 90 ? LBL_R + 0.06 : LBL_R;
        o.position.set(Math.cos(lat) * r, Math.sin(lat) * r, 0);
        var f = C.focusOf(st.step, z.kind === 'W' ? 'winds' : 'belts', z.id);
        o.element.style.opacity = 0.3 + 0.7 * f;
        o.element.classList.toggle('pole', Math.abs(p) === 90);
        o.userData.want = st.show.cells;
      });

      // 地转偏向示意
      var showDef = !single && (st.show.deflect || st.step > 0);
      deflect.visible = showDef;
      var defText = '';
      pathObjs.forEach(function (o) {
        var on = st.step > 0 ? C.focusOf(st.step, 'paths', o.path.id) > 0 && !C.STEPS[st.step - 1].all : st.show.deflect;
        o.line.visible = o.head.visible = on;
        if (!on) return;
        var r = o.path.aloft ? 1.07 : 1.022;
        var arr = o.line.geometry.attributes.position.array;
        for (var i = 0; i < o.n; i++) {
          var q = C.pathPoint(o.path, i / (o.n - 1));
          ll(C.toReal(q.p, s), frontLon + q.dl, r).toArray(arr, i * 3);
        }
        o.line.geometry.attributes.position.needsUpdate = true;
        if (o.path.aloft) o.line.computeLineDistances();
        var e0 = C.pathPoint(o.path, 0.97), e1 = C.pathPoint(o.path, 1);
        var a = ll(C.toReal(e0.p, s), frontLon + e0.dl, r), b = ll(C.toReal(e1.p, s), frontLon + e1.dl, r);
        o.head.position.copy(b);
        var d = b.clone().sub(a).normalize(), nrm = b.clone().normalize();
        basis.makeBasis(d, nrm.clone().cross(d), nrm);
        o.head.quaternion.setFromRotationMatrix(basis);
        if (o.path.aloft) defText = '虚线：高空气流 · 北半球右偏、南半球左偏';
      });
      deflectLabel.element.textContent = defText;
      deflectLabel.position.copy(ll(-48, frontLon - 34, 1.1));
      deflectLabel.userData.want = showDef && !!defText && !st.step;

      // 地点
      placeMark.visible = !!st.place;
      if (st.place) {
        placeMark.position.copy(ll(st.place.lat, st.place.lon, 1.012));
        placeMark.lookAt(ll(st.place.lat, st.place.lon, 2).applyMatrix4(spinGroup.matrixWorld));
        placeLabel.element.textContent = st.place.short || st.place.name;
        var wp = placeMark.getWorldPosition(tmp);
        placeLabel.userData.want = wp.clone().normalize().dot(camera.position.clone().sub(wp).normalize()) > 0.1;
      }

      allLabels.forEach(function (o) { o.visible = st.show.labels && o.userData.want && (!o.parent || o.parent.visible !== false); });
      if (!st.show.labels) placeLabel.visible = false;

      renderer.render(scene, camera);
      labelRenderer.render(scene, camera);
    }

    new ResizeObserver(resize).observe(stage);
    resize();

    return {
      update: update, pick: pick, resetView: resetView, canvas: canvas, camera: camera, controls: controls,
      setView: function (az, elev) { VIEW_AZ = az * DEG; VIEW_ELEV = elev * DEG; resetView(true); }
    };
  }

  window.CircScene = { create: create, ll: ll };
})();
