/* 画面坐标使用 CSS 像素；粒子保持 300 × 180 的计算坐标。 */
(function () {
  'use strict';
  const colors = ['#ffc94a', '#66d5ff'];
  function draw(canvas, state) {
    const dpr = Math.min(devicePixelRatio || 1, 2), w = canvas.clientWidth, h = canvas.clientHeight;
    if (canvas.width !== Math.round(w*dpr) || canvas.height !== Math.round(h*dpr)) { canvas.width=Math.round(w*dpr); canvas.height=Math.round(h*dpr); }
    const c=canvas.getContext('2d'); c.setTransform(dpr,0,0,dpr,0,0);
    c.fillStyle='#05070d'; c.fillRect(0,0,w,h);
    const mobile=w<650, start=mobile?166:Math.max(175,h*.25), available=h-start-(mobile?190:126);
    const scale=Math.max(.2, mobile?Math.min((w-92)/300,(available-112)/360,1.05):Math.min((w-184)/600,(available-92)/180,1.65));
    const bw=300*scale,bh=180*scale;
    const rects=mobile?[{x:(w-bw-30)/2,y:start},{x:(w-bw-30)/2,y:start+bh+94}]:[{x:w/2-bw-57,y:start},{x:w/2+37,y:start}];
    state.hit=[];
    function text(t,x,y,size=12,color='#91a1b8',align='left') { c.font=`${size}px -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif`; c.fillStyle=color;c.textAlign=align;c.fillText(t,x,y); }
    rects.forEach((r,i)=>{
      const T=state.temps[i],b=state.boxes[i],accent=i?'#ffb38b':'#8ed9f3';
      text(`${i?'B':'A'} 组`,r.x,r.y-21,15,accent);
      text(`${T} °C`,r.x+bw,r.y-21,18,'#edf3fc','right');
      c.save();c.translate(r.x,r.y);c.scale(scale,scale);
      const glass=c.createLinearGradient(0,0,300,180);glass.addColorStop(0,'#142431');glass.addColorStop(.6,'#0a111c');glass.addColorStop(1,'#122431');
      c.fillStyle=glass;c.strokeStyle='#587087';c.lineWidth=1.5/scale;c.beginPath();c.roundRect(-5,-5,310,190,9);c.fill();c.stroke();
      c.strokeStyle='#bceaff20';c.lineWidth=1/scale;c.beginPath();c.moveTo(4,171);c.lineTo(4,5);c.lineTo(292,5);c.stroke();
      c.strokeStyle=state.open?'#8fa9c24d':'#d7e8f8';c.setLineDash(state.open?[3,6]:[]);c.lineWidth=state.open?1/scale:4;c.beginPath();c.moveTo(150,0);c.lineTo(150,180);c.stroke();c.setLineDash([]);
      const selected=b.particles[state.selected[i]];
      if(state.trace&&selected){c.strokeStyle='#fff1b699';c.lineWidth=1.4/scale;c.beginPath();selected.trail.forEach((p,j)=>j?c.lineTo(...p):c.moveTo(...p));c.stroke();}
      b.particles.forEach((p,j)=>{c.fillStyle=colors[p.kind];c.beginPath();c.arc(p.x,p.y,2.5,0,Math.PI*2);c.fill();if(j===state.selected[i]){c.strokeStyle='#fff';c.lineWidth=1.2/scale;c.beginPath();c.arc(p.x,p.y,6,0,Math.PI*2);c.stroke();}});
      c.restore();
      const tx=r.x+bw+27,ty=r.y+bh;
      c.fillStyle=state.drag===i?accent+'25':'#111c29';c.beginPath();c.roundRect(tx-12,r.y-8,24,bh+25,12);c.fill();
      c.strokeStyle='#506177';c.lineWidth=1;c.beginPath();c.roundRect(tx-4,r.y+5,8,bh-12,4);c.stroke();
      const level=(T+100)/400*(bh-25);c.strokeStyle=accent;c.lineWidth=4;c.lineCap='round';c.beginPath();c.moveTo(tx,ty-12);c.lineTo(tx,ty-12-level);c.stroke();c.lineCap='butt';c.fillStyle=accent;c.beginPath();c.arc(tx,ty-8,6,0,Math.PI*2);c.fill();
      text('↕',tx,r.y-17,15,accent,'center');
      state.hit.push({x:r.x,y:r.y,w:bw,h:bh,tx,scale,index:i});
      const f=Thermal.fraction(b),barY=ty+43;
      text('右侧金色',r.x,ty+27,11);text(`${Math.round(f*80)} / 80`,r.x+bw,ty+27,13,'#ffc94a','right');
      c.fillStyle='#223044';c.beginPath();c.roundRect(r.x,barY,bw,4,2);c.fill();c.fillStyle='#ffc94a';c.fillRect(r.x,barY,bw*f,4);c.fillStyle='#9cacc0';c.fillRect(r.x+bw*.5-.5,barY-3,1,10);
      if(!mobile)text(`穿过中线  → ${b.lr}    ← ${b.rl}`,r.x,ty+72,11);
    });

  }
  window.ThermalDraw={draw};
})();
