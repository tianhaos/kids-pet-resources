(function () {
  'use strict';
  const $=id=>document.getElementById(id), q=new URLSearchParams(location.search);
  const num=(key,d,lo,hi)=>{const v=q.get(key);return v===null||!Number.isFinite(Number(v))?d:Math.max(lo,Math.min(hi,Number(v)));};
  const state={scene:'diffusion',temps:[num('a',0,-100,300),num('b',100,-100,300)],boxes:[],time:0,open:true,play:q.get('play')==='1'||(q.get('play')!=='0'&&!matchMedia('(prefers-reduced-motion: reduce)').matches),trace:true,selected:[0,0],hit:[]};
  function track(action,label){if(window.Analytics) Analytics.track('分子热运动与扩散',action,String(label));}
  function preset(scene,initial) {
    state.scene=['motion','diffusion','equilibrium'].includes(scene)?scene:'diffusion';
    state.open=state.scene!=='motion'; state.time=0; state.boxes=[Thermal.create(42,state.scene==='equilibrium'),Thermal.create(42,state.scene==='equilibrium')];
    if(!initial)track('切换场景',state.scene); sync();
  }
  function sync(){
    document.querySelectorAll('[data-scene]').forEach(b=>{b.classList.toggle('on',b.dataset.scene===state.scene);b.setAttribute('aria-pressed',b.dataset.scene===state.scene);});
    state.temps.forEach((v,i)=>{$('temp'+i).value=v;$('out'+i).textContent=v+' °C';});
    $('gate').textContent=state.open?'↺ 放回隔板，重新分开':'↑ 移除隔板，开始混合';
    $('observation').textContent=state.scene==='motion'?'隔板挡住混合，挡不住热运动':state.scene==='equilibrium'?'分布趋于均匀，运动从未停止':'移除隔板后，粒子向两侧无规则扩散';
    $('play').textContent=state.play?'❚❚ 暂停':'▶ 播放';
    $('ratio').textContent=(Thermal.speed(state.temps[1])/Thermal.speed(state.temps[0])).toFixed(2)+' 倍';
  }
  preset(q.get('scene')||'diffusion',true);
  const t=num('t',6,0,120); state.boxes.forEach((b,i)=>Thermal.advance(b,state.temps[i],state.open,t));state.time=t;
  document.querySelectorAll('[data-scene]').forEach(b=>b.onclick=()=>preset(b.dataset.scene));
  state.temps.forEach((v,i)=>$('temp'+i).oninput=e=>{state.temps[i]=+e.target.value;sync();track('调温',i+':'+state.temps[i]);});
  $('play').onclick=()=>{state.play=!state.play;sync();track('播放',state.play);};
  $('reset').onclick=()=>preset(state.scene);
  $('gate').onclick=()=>{if(state.open)preset('motion');else{state.open=true;state.scene='diffusion';sync();}track('隔板',state.open);};
  $('trace').onchange=e=>{state.trace=e.target.checked;};
  $('share').onclick=async()=>{const u=new URL(location.href);u.search=new URLSearchParams({scene:state.scene,a:state.temps[0],b:state.temps[1],t:0,play:0});try{await navigator.clipboard.writeText(u.href);$('message').textContent='已复制当前条件链接，从初态开始';track('分享',state.scene);}catch{$('message').textContent=u.href;}};
  $('panelToggle').onclick=()=>{const closed=$('panel').classList.toggle('collapsed');$('panelToggle').setAttribute('aria-expanded',!closed);};if(innerWidth<=760)$('panel').classList.add('collapsed');
  const canvas=$('thermal');let drag=null;state.drag=null;
  function point(e){const r=canvas.getBoundingClientRect();return {x:e.clientX-r.left,y:e.clientY-r.top};}
  function change(e){const p=point(e),h=drag;if(!h)return;state.temps[h.index]=Math.round(Math.max(-100,Math.min(300,((h.y+h.h-12-p.y)/(h.h-25))*400-100)));sync();}
  canvas.onpointerdown=e=>{const p=point(e);for(const h of state.hit){if(Math.abs(p.x-h.tx)<23&&p.y>h.y-24&&p.y<h.y+h.h+20){drag=h;state.drag=h.index;canvas.setPointerCapture(e.pointerId);change(e);return;}if(p.x>=h.x&&p.x<=h.x+h.w&&p.y>=h.y&&p.y<=h.y+h.h){let best=Infinity,index=0;state.boxes[h.index].particles.forEach((v,j)=>{const d=Math.hypot(v.x-(p.x-h.x)/h.scale,v.y-(p.y-h.y)/h.scale);if(d<best){best=d;index=j;}});state.selected[h.index]=index;state.trace=true;$('trace').checked=true;track('追踪',h.index);}}};
  canvas.onpointermove=e=>{if(drag){change(e);return;}const p=point(e);canvas.style.cursor=state.hit.some(h=>Math.abs(p.x-h.tx)<23&&p.y>h.y-24&&p.y<h.y+h.h+20)?'ns-resize':'crosshair';};
  canvas.onpointerup=()=>{if(drag)track('拖动温度计',drag.index);drag=null;state.drag=null;};canvas.onpointercancel=()=>{drag=null;state.drag=null;};
  addEventListener('keydown',e=>{if(e.code==='Space'&&!/INPUT|BUTTON|SELECT/.test(document.activeElement.tagName)){e.preventDefault();$('play').click();}});
  let last=0,acc=0;
  function frame(now){const dt=last?Math.min((now-last)/1000,.05):0;last=now;if(state.play){acc+=dt;while(acc>=Thermal.DT){state.boxes.forEach((b,i)=>Thermal.step(b,state.temps[i],state.open,Thermal.DT));state.time+=Thermal.DT;acc-=Thermal.DT;}if(state.time>=120){state.play=false;sync();}}
    ThermalDraw.draw(canvas,state);$('time-note').textContent=`演示时间 ${state.time.toFixed(1)} · 非真实秒数`;$('counts').textContent=state.boxes.map((b,i)=>`${i?'B':'A'}：${Math.round(Thermal.fraction(b)*80)}/80`).join('　');requestAnimationFrame(frame);}
  window.__model={state,preset,reset:()=>preset(state.scene),advance:t=>{state.boxes.forEach((b,i)=>Thermal.advance(b,state.temps[i],state.open,t));state.time+=t;},sync};sync();requestAnimationFrame(frame);
})();
