/* 二维随机飞行教学模型：长度、时间均为示意单位。 */
(function () {
  'use strict';
  const W = 300, H = 180, N = 160, DT = 1 / 60;
  function rng(seed) { return function () { seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0; return seed / 4294967296; }; }
  function speed(T) { return Math.sqrt((T + 273.15) / 273.15); }
  function create(seed, mixed) {
    const random = rng(seed), particles = [];
    for (let i = 0; i < N; i++) {
      const kind = i < N / 2 ? 0 : 1;
      const x = mixed ? 4 + random() * (W - 8) : 4 + random() * (W / 2 - 8) + kind * W / 2;
      particles.push({ x, y: 4 + random() * (H - 8), kind, angle: random() * Math.PI * 2, age: random() * .35, factor: .5 + random(), trail: [] });
    }
    return { particles, random, time: 0, lr: 0, rl: 0, history: [] };
  }
  function reflect(x, lo, hi) { while (x < lo || x > hi) { if (x < lo) x = 2 * lo - x; if (x > hi) x = 2 * hi - x; } return x; }
  function step(box, T, open, dt) {
    box.time += dt;
    box.particles.forEach(p => {
      p.age += dt;
      if (p.age >= .35) { p.age -= .35; p.angle = box.random() * 2 * Math.PI; }
      const v = 92 * speed(T) * p.factor, old = p.x;
      let x = p.x + Math.cos(p.angle) * v * dt;
      let y = p.y + Math.sin(p.angle) * v * dt;
      const lo = open || p.kind === 0 ? 3 : W / 2 + 3;
      const hi = open || p.kind === 1 ? W - 3 : W / 2 - 3;
      if (x < lo || x > hi) p.angle = Math.PI - p.angle;
      if (y < 3 || y > H - 3) p.angle = -p.angle;
      p.x = reflect(x, lo, hi); p.y = reflect(y, 3, H - 3);
      if (open && old < W / 2 && p.x >= W / 2) box.lr++;
      if (open && old >= W / 2 && p.x < W / 2) box.rl++;
      p.trail.push([p.x, p.y]); if (p.trail.length > 100) p.trail.shift();
    });
    if (!box.history.length || box.time - box.history[box.history.length - 1][0] >= .5) {
      box.history.push([box.time, fraction(box)]); if (box.history.length > 241) box.history.shift();
    }
  }
  function fraction(box) { return box.particles.filter(p => p.kind === 0 && p.x >= W / 2).length / (N / 2); }
  function advance(box, T, open, t) { for (let i = 0; i < Math.round(t / DT); i++) step(box, T, open, DT); }
  window.Thermal = { W, H, N, DT, speed, create, step, fraction, advance, reflect };
})();
