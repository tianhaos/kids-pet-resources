(function () {
  var O = window.Orbit, D = window.OrbitDraw, f = O.f, C = D.COLORS;
  var $ = function (id) { return document.getElementById(id); };
  var qa = function (sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); };
  var NAME = '宇宙速度与卫星变轨';
  var P_ANG = Math.PI, Q_ANG = 0, TWO_PI = Math.PI * 2;

  var state = {
    scene: 'launch', paused: false, rot: 0,
    warp: { launch: 1000, circle: 3000, transfer: 3000 },
    la: { h: 200, v: 7.79, sat: null, pred: [], trail: [], hist: [], el: null, end: '', landPt: null, t: 0, viewR: 1.5, viewCy: 0, full: false, dragging: false },
    ci: { h: 20000, phis: [0.8, 2.6, 0.3], showV: true, showA: false, chart: true },
    tr: { mode: 'auto', h1: 300, h3: 35786, dv: 1, sat: null, stage: 1, pending: null, trail: [], flame: 0, flameDir: 1, olds: [], cur: null, viewR: 7.4, showV: true, showA: false },
    quiz: null, quizOnly: null, answered: false, correct: false, choice: null, score: { n: 0, ok: 0 }
  };

  var HINTS = {
    launch: '拖动“发射速度”滑块，看不同速度下的轨迹',
    circle: '改变卫星 A 的高度，比较 v 与 T',
    transfer: '点火加速或减速，看卫星怎样变轨',
    quiz: '宇宙速度与卫星变轨 · 判断练习'
  };
  var KIND = { land: '落回地面', circle: '圆轨道', ellipse: '椭圆轨道', parabola: '抛物线 · 逃逸', hyperbola: '双曲线 · 逃逸' };

  var stage = $('stage'), panel = $('panel'), cv = $('view');
  var view = D.View(cv);
  function setSeg(attr, val) { qa('[data-' + attr + ']').forEach(function (b) { b.classList.toggle('on', b.dataset[attr] === String(val)); }); }
  function kindOf(el, end) { return end === 'land' ? 'land' : el.type; }

  // ---------- 场景一：发射 ----------
  function fire(keep) {
    var la = state.la;
    if (keep && la.sat && la.pred.length > 1) {
      la.hist.push({ pts: la.pred, v: la.v, end: la.end });
      if (la.hist.length > 6) la.hist.shift();
    }
    var r0 = O.rOfH(la.h);
    la.sat = O.stateAt(r0, Math.PI / 2, la.v / O.V1);
    var res = O.path(la.sat, 40, 720);
    la.pred = res.pts; la.el = res.el; la.end = res.end;
    la.landPt = null; la.trail = [{ x: la.sat.x, y: la.sat.y }]; la.t = 0; la.full = false; la.out = false;
    if (res.end === 'land' && res.pts.length < 2) { la.sat.landed = true; la.landPt = { x: 0, y: 1 }; }
  }
  // 画面范围：{ r 半径, cy 中心的世界 y }；椭圆从发射点（上）到远地点（下），整条放进画面
  function launchTarget() {
    var la = state.la, r0 = O.rOfH(la.h), k = kindOf(la.el, la.end);
    if (k !== 'ellipse') return { r: k === 'land' || k === 'circle' ? Math.max(1.3, r0 * 1.15) : 8, cy: 0 };
    var ra = Math.min(la.el.ra, 60), half = (ra + r0) / 2, b = Math.sqrt(r0 * ra);
    if (ra < 1.4) return { r: 1.3, cy: 0 };
    return { r: Math.max(half * 1.06, b * 1.08, 1.3), cy: (r0 - ra) / 2 };
  }

  // ---------- 场景三：变轨 ----------
  function trR() { return { r1: O.rOfH(state.tr.h1), r3: O.rOfH(state.tr.h3) }; }
  function hm() { var r = trR(); return O.hohmann(r.r1, r.r3); }
  function resetTransfer() {
    var tr = state.tr, r = trR();
    tr.sat = O.stateAt(r.r1, Math.PI / 2, 1 / Math.sqrt(r.r1));
    tr.stage = 1; tr.pending = null; tr.trail = []; tr.flame = 0; tr.olds = [];
    tr.cur = O.path(tr.sat, 60, 480);
  }
  // 霍曼转移各阶段的按钮
  var STAGES = {
    1: [{ at: 'P', to: 2, sign: 1, text: '▲ P 点加速 → 椭圆轨道 2' }],
    2: [{ at: 'Q', to: 3, sign: 1, text: '▲ Q 点加速 → 圆轨道 3' }, { at: 'P', to: 1, sign: -1, text: '▼ P 点减速 → 轨道 1' }],
    3: [{ at: 'Q', to: 2, sign: -1, text: '▼ Q 点减速 → 椭圆轨道 2' }]
  };
  function doBurnAuto(b) {
    var tr = state.tr, h = hm(), r = trR(), v;
    if (b.at === 'P') { v = b.to === 2 ? h.vP : h.v1; tr.sat = O.stateAt(r.r1, P_ANG, v / O.V1); }
    else { v = b.to === 3 ? h.v3 : h.vQ; tr.sat = O.stateAt(r.r3, Q_ANG, v / O.V1); }
    tr.stage = b.to; tr.pending = null; tr.flame = 0.9; tr.flameDir = b.sign; tr.trail = [];
  }
  function doBurnFree(sign) {
    var tr = state.tr;
    if (tr.sat.landed) return;
    var old = O.path(tr.sat, 60, 480);
    tr.olds.push(old.pts); if (tr.olds.length > 3) tr.olds.shift();
    O.burn(tr.sat, sign * tr.dv / O.V1);
    tr.cur = O.path(tr.sat, 60, 480);
    tr.flame = 0.7; tr.flameDir = sign; tr.trail = [];
    Analytics.track(NAME, '自由点火', sign > 0 ? '加速' : '减速');
  }
  // 逆时针从角 a0 转过 d 时是否经过角 target
  function crossed(a0, d, target) {
    var x = ((target - a0) % TWO_PI + TWO_PI) % TWO_PI;
    return x > 1e-9 && x <= d;
  }
  function ellipsePts(r1, r3) {
    var a = (r1 + r3) / 2, c = a - r1, b = Math.sqrt(r1 * r3), pts = [];
    for (var i = 0; i <= 240; i++) { var t = TWO_PI * i / 240; pts.push({ x: c + a * Math.cos(t), y: b * Math.sin(t) }); }
    return pts;
  }
  function circlePts(r) {
    var pts = [];
    for (var i = 0; i <= 240; i++) { var t = TWO_PI * i / 240; pts.push({ x: r * Math.cos(t), y: r * Math.sin(t) }); }
    return pts;
  }

  // ---------- 场景 ----------
  qa('[data-scene]').forEach(function (b) {
    b.addEventListener('click', function () { setScene(b.dataset.scene); Analytics.track(NAME, '场景', b.textContent); });
  });
  function setScene(sc) {
    state.scene = sc;
    if (sc === 'quiz' && !state.quiz) newQuiz();
    $('rName').className = '';
    syncUI();
  }

  // ---------- 控件 ----------
  function bindSlider(id, get, set, out) {
    var el = $(id);
    el.addEventListener('input', function () { set(parseFloat(el.value)); });
    el.addEventListener('change', function () { Analytics.track(NAME, '滑块', id); });
    return { el: el, get: get, out: out };
  }
  function startDrag() { if (!state.la.dragging) { state.la.dragging = true; fire(true); } }
  ['v', 'h'].forEach(function (id) { $(id).addEventListener('change', function () { state.la.dragging = false; }); });
  var sliders = [
    bindSlider('v', function () { return state.la.v; }, function (x) { startDrag(); state.la.v = x; fire(false); },
      function () { return f(state.la.v, 2) + ' km/s'; }),
    bindSlider('h', function () { return state.la.h; }, function (x) { startDrag(); state.la.h = x; fire(false); },
      function () { return Math.round(state.la.h) + ' km'; }),
    bindSlider('hc', function () { return state.ci.h; }, function (x) { state.ci.h = x; },
      function () { return Math.round(state.ci.h) + ' km'; }),
    bindSlider('h1', function () { return state.tr.h1; }, function (x) { state.tr.h1 = Math.min(x, state.tr.h3 - 1000); resetTransfer(); },
      function () { return Math.round(state.tr.h1) + ' km'; }),
    bindSlider('h3', function () { return state.tr.h3; }, function (x) { state.tr.h3 = Math.max(x, state.tr.h1 + 1000); resetTransfer(); },
      function () { return Math.round(state.tr.h3) + ' km'; }),
    bindSlider('dv', function () { return state.tr.dv; }, function (x) { state.tr.dv = x; },
      function () { return f(state.tr.dv, 1) + ' km/s'; })
  ];
  qa('[data-vset]').forEach(function (b) {
    b.addEventListener('click', function () {
      var r0 = O.rOfH(state.la.h), k = b.dataset.vset;
      var v = k === 'circ' ? O.vCirc(r0) : k === 'esc' ? O.vEsc(r0) : parseFloat(k);
      state.la.v = O.clamp(Math.round(v * 100) / 100 + (k === 'esc' ? 0.01 : 0), O.V_LAUNCH[0], O.V_LAUNCH[1]);
      fire(true); state.paused = false; syncUI();
      Analytics.track(NAME, '发射速度', b.textContent);
    });
  });
  $('clearHist').addEventListener('click', function () { state.la.hist = []; });
  qa('[data-warp]').forEach(function (b) {
    b.addEventListener('click', function () { if (state.scene !== 'quiz') state.warp[state.scene] = parseInt(b.dataset.warp, 10); syncUI(); Analytics.track(NAME, '时间倍率', b.textContent); });
  });
  qa('[data-mode]').forEach(function (b) {
    b.addEventListener('click', function () { state.tr.mode = b.dataset.mode; resetTransfer(); syncUI(); Analytics.track(NAME, '变轨方式', b.textContent); });
  });
  qa('[data-preset]').forEach(function (b) {
    b.addEventListener('click', function () {
      var p = b.dataset.preset.split(',');
      state.tr.h1 = +p[0]; state.tr.h3 = +p[1]; resetTransfer(); syncUI();
      Analytics.track(NAME, '变轨预设', b.textContent);
    });
  });
  $('burnA').addEventListener('click', function () { autoClick(0); });
  $('burnB').addEventListener('click', function () { autoClick(1); });
  function autoClick(i) {
    var tr = state.tr;
    if (tr.mode === 'free') { doBurnFree(i === 0 ? 1 : -1); return; }
    var b = STAGES[tr.stage][i];
    if (!b || tr.pending) return;
    tr.pending = b; state.paused = false;
    Analytics.track(NAME, '变轨', b.text);
    syncUI();
  }
  [['showV', 'ci'], ['showA', 'ci'], ['chart', 'ci'], ['trV', 'tr'], ['trA', 'tr']].forEach(function (c) {
    var el = $(c[0]), key = c[0] === 'trV' ? 'showV' : c[0] === 'trA' ? 'showA' : c[0];
    el.addEventListener('change', function () { state[c[1]][key] = el.checked; });
  });
  function togglePause() { state.paused = !state.paused; syncUI(); }
  qa('.pause').forEach(function (b) { b.addEventListener('click', togglePause); });
  $('reset').addEventListener('click', function () {
    if (state.scene === 'launch') fire(false);
    else if (state.scene === 'transfer') resetTransfer();
    state.paused = false; syncUI();
    Analytics.track(NAME, '重来', state.scene);
  });

  // ---------- 练习 ----------
  function newQuiz() {
    state.quiz = O.quiz(Math.random, state.quiz && state.quiz.id, state.quizOnly);
    state.answered = false; state.choice = null;
    var box = $('quizOpts');
    box.innerHTML = '';
    box.classList.toggle('long', !!state.quiz.long);
    state.quiz.options.forEach(function (o) {
      var b = document.createElement('button');
      b.className = 'small';
      b.textContent = o;
      b.addEventListener('click', function () { answer(o); });
      box.appendChild(b);
    });
    syncUI();
  }
  function answer(o) {
    if (state.answered) return;
    state.answered = true;
    state.choice = o;
    state.correct = o === state.quiz.answer;
    state.score.n++; if (state.correct) state.score.ok++;
    Analytics.track(NAME, '练习', state.quiz.type + (state.correct ? ' 对' : ' 错'));
    syncUI();
  }
  $('nextQ').addEventListener('click', newQuiz);
  $('showQ').addEventListener('click', function () {
    var q = state.quiz;
    if (q.type === 'cosmic') {
      state.la.h = 0; state.la.v = O.clamp(q.v, O.V_LAUNCH[0], O.V_LAUNCH[1]); state.la.hist = []; fire(false); setScene('launch');
    } else if (q.type === 'compare') setScene('circle');
    else { state.tr.mode = 'auto'; state.tr.h1 = 300; state.tr.h3 = 35786; resetTransfer(); setScene('transfer'); }
    state.paused = false; syncUI();
  });

  // ---------- 面板 ----------
  $('panelToggle').addEventListener('click', function () { panel.classList.toggle('collapsed'); });
  if (window.matchMedia('(max-width: 760px)').matches) panel.classList.add('collapsed');
  window.addEventListener('keydown', function (e) {
    var tg = e.target.tagName;
    if (tg === 'INPUT' || tg === 'SELECT' || tg === 'BUTTON' || tg === 'TEXTAREA') return;
    if (e.code === 'Space' && state.scene !== 'quiz') { e.preventDefault(); togglePause(); }
  });

  function syncUI() {
    var sc = state.scene, tr = state.tr;
    setSeg('scene', sc);
    qa('[data-for]').forEach(function (el) { el.hidden = el.dataset.for.split(' ').indexOf(sc) < 0; });
    qa('[data-mode-for]').forEach(function (el) { el.hidden = el.dataset.modeFor !== tr.mode; });
    $('hint').textContent = HINTS[sc];
    if (sc !== 'quiz') setSeg('warp', state.warp[sc]);
    setSeg('mode', tr.mode);
    qa('[data-preset]').forEach(function (b) { var p = b.dataset.preset.split(','); b.classList.toggle('on', +p[0] === tr.h1 && +p[1] === tr.h3); });
    $('showV').checked = state.ci.showV; $('showA').checked = state.ci.showA; $('chart').checked = state.ci.chart;
    $('trV').checked = tr.showV; $('trA').checked = tr.showA;
    qa('.pause').forEach(function (b) { b.textContent = state.paused ? '▶ 继续' : '❚❚ 暂停'; });
    // 变轨按钮
    var A = $('burnA'), B = $('burnB');
    if (tr.mode === 'free') {
      A.textContent = '▲ 加速 +Δv'; B.textContent = '▼ 减速 −Δv'; B.hidden = false;
      A.disabled = B.disabled = !!(tr.sat && tr.sat.landed);
    } else {
      var bs = STAGES[tr.stage];
      if (tr.pending) { A.textContent = '等待到达 ' + tr.pending.at + ' 点…'; A.disabled = true; B.hidden = true; }
      else {
        A.textContent = bs[0].text; A.disabled = false;
        B.hidden = !bs[1]; if (bs[1]) { B.textContent = bs[1].text; B.disabled = false; }
      }
    }
    var q = state.quiz;
    if (q) {
      $('quizQ').textContent = q.prompt;
      qa('#quizOpts button').forEach(function (b) {
        b.disabled = state.answered;
        b.classList.toggle('on', state.answered && b.textContent === q.answer);
        b.classList.toggle('no', state.answered && b.textContent === state.choice && !state.correct);
      });
      $('quizMsg').innerHTML = !state.answered ? ''
        : '<b class="' + (state.correct ? 'ok">✓ 答对了' : 'bad">✗ 应选「' + q.answer + '」') + '</b>' + q.explain;
      $('nextQ').textContent = state.answered ? '下一题 →' : '换一题';
      $('showQ').hidden = !state.answered;
    }
  }

  // ---------- 读数 ----------
  var lastText = {};
  function setText(id, s) { if (lastText[id] !== s) { lastText[id] = s; $(id).textContent = s; } }
  function rows(list) {
    for (var k = 1; k <= 5; k++) {
      var r = list[k - 1] || ['', ''];
      setText('d' + k, r[0]); setText('r' + k, r[1]);
      $('d' + k).hidden = $('r' + k).hidden = !r[0];
    }
  }
  function hKm(r) { return O.fmtKm(O.hOfR(r)); }

  function readLaunch() {
    var la = state.la, r0 = O.rOfH(la.h), el = la.el, k = kindOf(el, la.end), vc = O.vCirc(r0), ve = O.vEsc(r0);
    setText('rName', 'v = ' + f(la.v, 2) + ' km/s');
    setText('rKind', KIND[k]);
    var tips = {
      land: 'v 小于该高度的环绕速度：引力大于所需的向心力，物体做向心运动落回地面。速度越大，落得越远。',
      circle: '万有引力恰好提供向心力：GMm/r² = mv²/r，v = √(GM/r)。贴着地面（r = R）时这个速度就是第一宇宙速度 7.9 km/s。',
      ellipse: 'v 大于环绕速度：引力不足以提供向心力，物体离心远去，沿椭圆轨道绕地球运行，发射点是近地点。速度越大，椭圆越扁长。',
      parabola: 'v 达到该高度的逃逸速度：物体挣脱地球引力，一去不返。地面附近的逃逸速度就是第二宇宙速度 11.2 km/s。',
      hyperbola: 'v 超过该高度的逃逸速度：物体挣脱地球引力，一去不返。地面附近的逃逸速度就是第二宇宙速度 11.2 km/s。'
    };
    setText('rTip', la.h === 0 && k === 'land' ? '贴着地面发射、速度小于 7.9 km/s 时，物体一出发就落回地面。把发射高度调高一些再看。' : tips[k]);
    var list = [['此高度', '环绕速度 ' + f(vc, 2) + ' km/s，逃逸速度 ' + f(ve, 2) + ' km/s']];
    if (k === 'land') {
      var lp = la.landPt || la.pred[la.pred.length - 1], ang = Math.abs(Math.atan2(lp.y, lp.x) - Math.PI / 2);
      list.push(['落点', '沿地面飞出 ' + O.fmtKm(ang * O.R_KM)]);
      list.push(['最高点', '发射点（h = ' + Math.round(la.h) + ' km）']);
    } else if (el.closed) {
      list.push(['近地点', 'h = ' + hKm(el.rp)]);
      list.push(['远地点', 'h = ' + hKm(el.ra) + (el.ra > 60 ? '（超出画面）' : '')]);
      list.push(['周期', O.fmtTime(O.sec(el.T))]);
    } else {
      list.push(['机械能', 'E = ½v² − GM/r = ' + f(O.energy(la.v, r0), 2) + ' MJ/kg ≥ 0']);
    }
    var s = la.sat, r = Math.hypot(s.x, s.y);
    list.push(['此刻', 't = ' + O.fmtTime(la.t) + '，h = ' + hKm(r) + '，v = ' + f(Math.hypot(s.vx, s.vy) * O.V1, 2) + ' km/s']);
    rows(list);
  }

  function ciSats() {
    return [
      { name: '近地卫星', r: 1.0001, phi: state.ci.phis[0], color: C.O1 },
      { name: '卫星 A', r: O.rOfH(state.ci.h), phi: state.ci.phis[1], color: C.SAT },
      { name: '同步卫星', r: O.GEO, phi: state.ci.phis[2], color: C.O3, geo: true }
    ];
  }
  function readCircle() {
    var rA = O.rOfH(state.ci.h);
    setText('rName', '卫星 A：h = ' + O.fmtKm(state.ci.h));
    setText('rKind', '匀速圆周运动');
    setText('rTip', '万有引力提供向心力：轨道越高，线速度、角速度、向心加速度越小，周期越大——“高轨低速长周期”。');
    rows([
      ['线速度', 'v = √(GM/r) = ' + f(O.vCirc(rA), 2) + ' km/s'],
      ['周期', 'T = 2π√(r³/GM) = ' + O.fmtTime(O.periodA(rA))],
      ['加速度', 'a = GM/r² = ' + f(O.accel(rA), rA > 3 ? 3 : 2) + ' m/s²'],
      ['角速度', 'ω = ' + f(O.omega(rA) * 1e4, 3) + ' × 10⁻⁴ rad/s'],
      ['半径', 'r = R + h = ' + O.fmtKm(O.km(rA))]
    ]);
    ciSats().forEach(function (s, i) {
      setText('c' + i + 'h', i === 0 ? '≈ 0' : O.fmtKm(O.hOfR(s.r)).replace(' km', ''));
      setText('c' + i + 'v', f(O.vCirc(s.r), 2));
      setText('c' + i + 't', f(O.periodA(s.r) / 3600, 1));
      setText('c' + i + 'a', f(O.accel(s.r), 2));
    });
  }
  function readTransfer() {
    var tr = state.tr, h = hm(), s = tr.sat, r = Math.hypot(s.x, s.y), v = Math.hypot(s.vx, s.vy) * O.V1;
    var now = '此刻 h = ' + hKm(r) + '，v = ' + f(v, 2) + ' km/s';
    if (tr.mode === 'auto') {
      var nm = { 1: '圆轨道 1', 2: '椭圆轨道 2', 3: '圆轨道 3' }[tr.stage];
      setText('rName', nm);
      setText('rKind', tr.pending ? '等待点火' : tr.stage === 2 ? '转移轨道' : '匀速圆周');
      var tips = {
        1: '在 P 点点火加速，卫星所需向心力大于引力，做离心运动进入椭圆轨道 2。',
        2: '在椭圆轨道上从 P 到 Q，引力做负功、速度减小；到远地点 Q 时 vQ < v3，再次加速才能进入圆轨道 3。',
        3: '两次加速后到达高轨道：速度反而比轨道 1 小（v3 < v1），但机械能更大。'
      };
      setText('rTip', tips[tr.stage] + ' ' + now + '。');
      rows([
        ['速度', 'vP ' + f(h.vP, 2) + ' > v1 ' + f(h.v1, 2) + ' > v3 ' + f(h.v3, 2) + ' > vQ ' + f(h.vQ, 2) + ' km/s'],
        ['点火', 'P 点 Δv = ' + f(h.dv1, 2) + '，Q 点 Δv = ' + f(h.dv2, 2) + ' km/s'],
        ['周期', 'T1 ' + O.fmtTime(h.T1) + ' < T2 ' + O.fmtTime(h.T2) + ' < T3 ' + O.fmtTime(h.T3)],
        ['加速度', 'P 点 ' + f(h.aP, 2) + ' m/s²、Q 点 ' + f(h.aQ, 3) + ' m/s²（同一点不论哪条轨道都相同）'],
        ['机械能', 'E1 ' + f(h.E1, 1) + ' < E2 ' + f(h.E2, 1) + ' < E3 ' + f(h.E3, 1) + ' MJ/kg']
      ]);
      return;
    }
    var el = O.elements(s);
    if (s.landed) {
      setText('rName', '坠落'); setText('rKind', '落回地面');
      setText('rTip', '近地点低于地面，卫星坠回地球（未计大气）。点“重来”回到轨道 1。');
      rows([]); return;
    }
    setText('rName', KIND[el.type] || '椭圆轨道');
    setText('rKind', el.closed ? (el.rp < 1 ? '会坠落' : '绕地球运行') : '逃逸');
    setText('rTip', (el.closed ? '沿速度方向加速，轨道的另一侧升高；减速则另一侧降低。点火处成为新轨道的近地点（加速）或远地点（减速）。'
      : '速度达到逃逸速度，卫星脱离地球。') + ' ' + now + '。');
    rows(el.closed ? [
      ['近地点', 'h = ' + hKm(el.rp) + (el.rp < 1 ? '（低于地面）' : '')],
      ['远地点', 'h = ' + hKm(el.ra)],
      ['周期', O.fmtTime(O.sec(el.T))],
      ['机械能', 'E = ' + f(O.energy(v, r), 2) + ' MJ/kg（加速后增大）']
    ] : [['机械能', 'E = ' + f(O.energy(v, r), 2) + ' MJ/kg ≥ 0']]);
  }
  function readQuiz() {
    var q = state.quiz, sc = state.score;
    setText('rName', !state.answered ? '判断练习' : state.correct ? '✓ 答对了' : '✗ 答错了');
    $('rName').className = !state.answered ? '' : state.correct ? 'ok' : 'bad';
    setText('rKind', '得分 ' + sc.ok + ' / ' + sc.n);
    setText('rTip', state.answered ? q.explain : q.prompt);
    rows([]);
  }

  // ---------- 推进 ----------
  function advLaunch(ts) {
    var la = state.la, s = la.sat;
    if (s.landed || la.out) return;
    var sim = ts / O.TAU;
    O.step(s, sim); la.t += ts;
    if (s.landed) { la.landPt = { x: s.x, y: s.y }; }
    if (la.el.closed && la.t >= O.sec(la.el.T)) la.full = true;
    if (!la.full) {
      var last = la.trail[la.trail.length - 1], vr = state.la.viewR;
      if (Math.hypot(s.x - last.x, s.y - last.y) > vr * 0.004) la.trail.push({ x: s.x, y: s.y });
    }
    if (Math.hypot(s.x, s.y) > 45) la.out = true;
  }
  function advTransfer(ts) {
    var tr = state.tr, s = tr.sat;
    if (s.landed) return;
    var a0 = Math.atan2(s.y, s.x);
    O.step(s, ts / O.TAU);
    var d = ((Math.atan2(s.y, s.x) - a0) % TWO_PI + TWO_PI) % TWO_PI;
    if (tr.mode === 'auto' && tr.pending && crossed(a0, d, tr.pending.at === 'P' ? P_ANG : Q_ANG)) doBurnAuto(tr.pending);
    else if (tr.mode === 'auto' && tr.stage !== 2) {
      // 圆轨道上把数值误差拉回去
      var r = trR(), rr = tr.stage === 1 ? r.r1 : r.r3, ang = Math.atan2(s.y, s.x), st = O.stateAt(rr, ang, 1 / Math.sqrt(rr));
      s.x = st.x; s.y = st.y; s.vx = st.vx; s.vy = st.vy;
    }
    var last = tr.trail[tr.trail.length - 1];
    if (!last || Math.hypot(s.x - last.x, s.y - last.y) > tr.viewR * 0.004) tr.trail.push({ x: s.x, y: s.y });
    if (tr.trail.length > 900) tr.trail.shift();
    if (s.landed) syncUI();
  }

  // ---------- 尺寸与主循环 ----------
  function resize() { view.resize(stage.clientWidth, stage.clientHeight); }
  new ResizeObserver(resize).observe(stage);

  // 支持 ?scene=launch|circle|transfer|quiz；发射 &h=0~2000（km）、&v=3~13（km/s）；环绕 &hc=200~40000（km）；
  // 变轨 &mode=auto|free、&h1=、&h3=（km）、&dv=0.1~3（km/s）；&warp=300|1000|3000|10000；练习 &q=cosmic|compare|transfer
  var qs = new URLSearchParams(location.search);
  function num(k, lo, hi) { var x = parseFloat(qs.get(k)); return isFinite(x) && x >= lo && x <= hi ? x : null; }
  var x;
  if (HINTS[qs.get('scene')]) state.scene = qs.get('scene');
  if ((x = num('h', O.H_LAUNCH[0], O.H_LAUNCH[1])) != null) state.la.h = x;
  if ((x = num('v', O.V_LAUNCH[0], O.V_LAUNCH[1])) != null) state.la.v = x;
  if ((x = num('hc', O.H_CIRC[0], O.H_CIRC[1])) != null) state.ci.h = x;
  if (qs.get('mode') === 'auto' || qs.get('mode') === 'free') state.tr.mode = qs.get('mode');
  if ((x = num('h1', O.H_LOW[0], O.H_LOW[1])) != null) state.tr.h1 = x;
  if ((x = num('h3', O.H_HIGH[0], O.H_HIGH[1])) != null) state.tr.h3 = x;
  if (state.tr.h3 < state.tr.h1 + 1000) state.tr.h3 = state.tr.h1 + 1000;
  if ((x = num('dv', O.DV[0], O.DV[1])) != null) state.tr.dv = x;
  if ([300, 1000, 3000, 10000].indexOf(parseInt(qs.get('warp'), 10)) >= 0 && state.warp[state.scene]) state.warp[state.scene] = parseInt(qs.get('warp'), 10);
  if (O.TYPES.indexOf(qs.get('q')) >= 0) state.quizOnly = qs.get('q');

  fire(false);
  state.la.viewR = launchTarget().r; state.la.viewCy = launchTarget().cy;
  resetTransfer();
  resize();
  setScene(state.scene);

  var lastT = performance.now();
  function frame(now) {
    var dt = Math.min((now - lastT) / 1000, 0.1);
    lastT = now;
    var sc = state.scene, tr = state.tr, la = state.la;
    var ts = state.paused || sc === 'quiz' ? 0 : dt * state.warp[sc];  // 本帧模拟的真实秒数
    state.rot = (state.rot + ts * TWO_PI / O.DAY) % TWO_PI;
    sliders.forEach(function (s) { if (document.activeElement !== s.el) s.el.value = s.get(); setText(s.el.id + 'Out', s.out()); });

    if (sc === 'launch') {
      if (ts) advLaunch(ts);
      var tg = launchTarget(), ease = Math.min(1, dt * 3);
      la.viewR += (tg.r - la.viewR) * ease; la.viewCy += (tg.cy - la.viewCy) * ease;
      view.drawLaunch({ h: la.h, r0: O.rOfH(la.h), v: la.v, sat: la.sat, trail: la.full ? la.pred : la.trail, pred: la.pred, hist: la.hist,
        viewR: la.viewR, viewCy: la.viewCy, rot: state.rot, landPt: la.landPt });
      readLaunch();
    } else if (sc === 'circle') {
      ciSats().forEach(function (s, i) { state.ci.phis[i] = (state.ci.phis[i] + ts * O.omega(s.r)) % TWO_PI; });
      // 同步卫星与地面站同步：地面站经度取同步卫星初始位置
      view.drawCircle({ sats: ciSats(), rot: state.rot, station: 0.3, showV: state.ci.showV, showA: state.ci.showA, showChart: state.ci.chart });
      readCircle();
    } else if (sc === 'transfer') {
      if (ts) advTransfer(ts);
      tr.flame = Math.max(0, tr.flame - dt);
      var r = trR(), orbits, marks = [], h = hm();
      if (tr.mode === 'auto') {
        var on = function (k) { return tr.stage === k ? 1 : 0.35; };
        orbits = [
          { pts: circlePts(r.r1), color: C.O1, alpha: on(1), name: '1', at: { x: r.r1 * Math.cos(2.4) * 1.0, y: r.r1 * Math.sin(2.4) + 0.35 * r.r3 / 6 } },
          { pts: ellipsePts(r.r1, r.r3), color: C.O2, alpha: on(2), name: '2', at: { x: (r.r3 - r.r1) / 2 + (r.r1 + r.r3) / 2 * Math.cos(1.1), y: Math.sqrt(r.r1 * r.r3) * Math.sin(1.1) + r.r3 * 0.06 } },
          { pts: circlePts(r.r3), color: C.O3, alpha: on(3), name: '3', at: { x: r.r3 * Math.cos(2.3), y: r.r3 * Math.sin(2.3) + r.r3 * 0.06 } }
        ];
        marks = [
          { name: 'P', x: -r.r1, y: 0, dx: -16, dy: 0 },
          { name: 'Q', x: r.r3, y: 0, dx: 16, dy: 0 }
        ];
        tr.viewR = r.r3 * 1.12;
        var cornerT = ['P：近地点，h = ' + O.fmtKm(tr.h1), 'Q：远地点，h = ' + O.fmtKm(tr.h3), '从 P 到 Q 用时 ' + O.fmtTime(h.tTransfer)];
      } else {
        orbits = [
          { pts: circlePts(r.r1), color: C.O1, alpha: 0.3, dash: [4, 5], width: 1.2 },
          { pts: circlePts(r.r3), color: C.O3, alpha: 0.3, dash: [4, 5], width: 1.2 }
        ];
        tr.olds.forEach(function (p) { orbits.push({ pts: p, color: '#8d99ab', alpha: 0.35, width: 1.2 }); });
        orbits.push({ pts: tr.cur.pts, color: C.O2, alpha: 0.9, width: 1.8 });
        var el = tr.cur.el, tgt = el.closed ? Math.max(r.r3 * 1.12, Math.min(el.ra, 30) * 1.08) : r.r3 * 2;
        tr.viewR += (tgt - tr.viewR) * Math.min(1, dt * 3);
        cornerT = ['虚线：轨道 1（h = ' + O.fmtKm(tr.h1) + '）、轨道 3（h = ' + O.fmtKm(tr.h3) + '）', '每次沿速度方向点火 Δv = ' + f(tr.dv, 1) + ' km/s', ''];
      }
      view.drawTransfer({ sat: tr.sat, trail: tr.trail, orbits: orbits, marks: marks, viewR: tr.viewR, rot: state.rot,
        flame: tr.flame > 0 ? tr.flameDir : 0, showV: tr.showV, showA: tr.showA, corner: cornerT });
      readTransfer();
    } else {
      view.drawQuiz(state.quiz, state.answered, { quizH: $('quizBar').offsetHeight });
      readQuiz();
    }
    if (sc === 'transfer' && tr.mode === 'auto' && !tr.pending && $('burnA').disabled) syncUI();
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // 调试用
  window.__model = {
    state: state, setScene: setScene, newQuiz: newQuiz, syncUI: syncUI, fire: fire, resetTransfer: resetTransfer,
    setV: function (v) { state.la.v = O.clamp(v, O.V_LAUNCH[0], O.V_LAUNCH[1]); fire(true); },
    setH: function (h) { state.la.h = O.clamp(h, O.H_LAUNCH[0], O.H_LAUNCH[1]); fire(true); },
    burn: function (i) { autoClick(i || 0); },
    // 按模拟秒数推进当前场景（分小步，便于在控制台或测试里检查变轨）
    advance: function (sec) {
      for (var t = 0; t < sec; t += 30) {
        var d = Math.min(30, sec - t);
        if (state.scene === 'launch') advLaunch(d); else if (state.scene === 'transfer') advTransfer(d);
      }
      syncUI();
    }
  };
})();
