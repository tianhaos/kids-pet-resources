// 2D 绘制：从北极上空俯视的地球（大陆轮廓随自转转动）、发射轨迹、圆轨道卫星与 v–r、T–r 曲线、变轨的三条轨道、练习题画面
// 世界坐标同 Orbit：原点在地心、x 右 y 上、单位地球半径 R；frame(R, viewR) 把半径 viewR 的圆放进屏幕矩形
(function () {
  var O = window.Orbit, f = O.f, C = window.Continents;
  var SAT = '#ffc94a', V = '#ff7a59', ACC = '#f48fb1', O1 = '#4fc3f7', O2 = '#c9a7ff', O3 = '#7ee081';
  var MUTED = '#8d99ab', TEXT = '#e6ebf2', HIST = ['#4fc3f7', '#7ee081', '#c9a7ff', '#ff7a59', '#f48fb1', '#80cbc4'];
  var FONT = '-apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", sans-serif';

  function font(px, w) { return (w ? w + ' ' : '') + px + 'px ' + FONT; }
  function label(ctx, s, x, y, o) {
    o = o || {};
    ctx.font = font(o.size || 12, o.bold ? 600 : null);
    ctx.textAlign = o.align || 'center'; ctx.textBaseline = o.base || 'middle';
    ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(5,7,13,.85)'; ctx.strokeText(s, x, y);
    ctx.fillStyle = o.color || TEXT; ctx.fillText(s, x, y);
  }
  function arrow(ctx, x1, y1, x2, y2, color, o) {
    o = o || {};
    var a = Math.atan2(y2 - y1, x2 - x1), len = Math.hypot(x2 - x1, y2 - y1), size = Math.min(o.size || 10, len * 0.6);
    if (len < 1) return;
    ctx.strokeStyle = ctx.fillStyle = color; ctx.lineWidth = o.width || 2.4; ctx.setLineDash(o.dash || []);
    ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2 - Math.cos(a) * size * 0.6, y2 - Math.sin(a) * size * 0.6); ctx.stroke();
    ctx.setLineDash([]);
    ctx.beginPath();
    ctx.moveTo(x2, y2);
    ctx.lineTo(x2 - size * Math.cos(a - 0.42), y2 - size * Math.sin(a - 0.42));
    ctx.lineTo(x2 - size * Math.cos(a + 0.42), y2 - size * Math.sin(a + 0.42));
    ctx.closePath(); ctx.fill();
  }
  function dot(ctx, p, color, r) { ctx.fillStyle = color; ctx.beginPath(); ctx.arc(p.x, p.y, r || 3.5, 0, 7); ctx.fill(); }

  // ---------- 世界 ⇄ 屏幕 ----------
  function frame(R, viewR, cx, cy) {
    var k = Math.min(R.w, R.h) / 2 / viewR, X = cx == null ? R.x + R.w / 2 : cx, Y = cy == null ? R.y + R.h / 2 : cy;
    return {
      k: k, R: R, c: { x: X, y: Y },
      p: function (x, y) { return { x: X + x * k, y: Y - y * k }; },
      w: function (sx, sy) { return { x: (sx - X) / k, y: (Y - sy) / k }; }
    };
  }
  function poly(ctx, fr, pts) {
    ctx.beginPath();
    pts.forEach(function (q, i) { var s = fr.p(q.x, q.y); if (i) ctx.lineTo(s.x, s.y); else ctx.moveTo(s.x, s.y); });
  }
  function strokePts(ctx, fr, pts, color, o) {
    o = o || {};
    if (pts.length < 2) return;
    poly(ctx, fr, pts);
    ctx.strokeStyle = color; ctx.lineWidth = o.width || 2; ctx.globalAlpha = o.alpha == null ? 1 : o.alpha;
    ctx.setLineDash(o.dash || []); ctx.stroke(); ctx.setLineDash([]); ctx.globalAlpha = 1;
  }
  function circle(ctx, fr, r, color, o) {
    o = o || {};
    ctx.strokeStyle = color; ctx.lineWidth = o.width || 2; ctx.globalAlpha = o.alpha == null ? 1 : o.alpha;
    ctx.setLineDash(o.dash || []);
    ctx.beginPath(); ctx.arc(fr.c.x, fr.c.y, r * fr.k, 0, 7); ctx.stroke();
    ctx.setLineDash([]); ctx.globalAlpha = 1;
  }

  // ---------- 地球：北极上空的正射投影，南半球的点压到边缘 ----------
  function earth(ctx, c, rp, rot) {
    var g = ctx.createRadialGradient(c.x, c.y, rp * 0.9, c.x, c.y, rp * 1.25);
    g.addColorStop(0, 'rgba(79,195,247,.35)'); g.addColorStop(1, 'rgba(79,195,247,0)');
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(c.x, c.y, rp * 1.25, 0, 7); ctx.fill();
    ctx.save();
    ctx.beginPath(); ctx.arc(c.x, c.y, rp, 0, 7); ctx.clip();
    ctx.fillStyle = '#2f6fb5'; ctx.fillRect(c.x - rp, c.y - rp, rp * 2, rp * 2);
    if (rp > 6) {
      var draw = function (polys, fill, stroke) {
        ctx.fillStyle = fill; ctx.strokeStyle = stroke; ctx.lineWidth = 1; ctx.lineJoin = 'round';
        polys.forEach(function (pl) {
          // 整块都在南半球的（南极洲、澳大利亚）从北极上空看不见
          if (!pl.some(function (q) { return q[1] > 0; })) return;
          ctx.beginPath();
          pl.forEach(function (q, i) {
            var lon = q[0] * Math.PI / 180 + rot, cl = q[1] >= 0 ? Math.cos(q[1] * Math.PI / 180) : 1;
            var x = c.x + rp * cl * Math.cos(lon), y = c.y - rp * cl * Math.sin(lon);
            if (i) ctx.lineTo(x, y); else ctx.moveTo(x, y);
          });
          ctx.closePath(); ctx.fill(); ctx.stroke();
        });
      };
      draw(C.LAND, '#6fa653', '#5d9444');
      draw(C.ICE, '#e8eef2', '#cfd8dc');
      draw(C.WATER, '#2f6fb5', '#2f6fb5');
    }
    // 球面明暗
    var sh = ctx.createRadialGradient(c.x - rp * 0.35, c.y - rp * 0.35, rp * 0.1, c.x, c.y, rp);
    sh.addColorStop(0, 'rgba(255,255,255,.12)'); sh.addColorStop(0.7, 'rgba(0,0,0,0)'); sh.addColorStop(1, 'rgba(0,0,20,.45)');
    ctx.fillStyle = sh; ctx.fillRect(c.x - rp, c.y - rp, rp * 2, rp * 2);
    ctx.restore();
  }

  // 卫星图标：主体 + 两翼太阳能板，ang 为速度方向（屏幕角）
  function satellite(ctx, p, ang, o) {
    o = o || {};
    var s = o.size || 1;
    ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(ang);
    if (o.flame) {
      // 发动机喷焰：加速时朝后喷，减速时朝前喷
      var d = o.flame > 0 ? -1 : 1, L = 16 * s * (0.7 + 0.3 * Math.random());
      ctx.fillStyle = 'rgba(255,160,60,.9)';
      ctx.beginPath(); ctx.moveTo(d * 6 * s, -3 * s); ctx.lineTo(d * (6 * s + L), 0); ctx.lineTo(d * 6 * s, 3 * s); ctx.closePath(); ctx.fill();
    }
    ctx.fillStyle = '#3b6fb0'; ctx.strokeStyle = '#9ec1ee'; ctx.lineWidth = 1;
    ctx.fillRect(-2.5 * s, -13 * s, 5 * s, 8 * s); ctx.strokeRect(-2.5 * s, -13 * s, 5 * s, 8 * s);
    ctx.fillRect(-2.5 * s, 5 * s, 5 * s, 8 * s); ctx.strokeRect(-2.5 * s, 5 * s, 5 * s, 8 * s);
    ctx.fillStyle = o.color || SAT;
    ctx.fillRect(-5 * s, -5 * s, 10 * s, 10 * s);
    ctx.restore();
  }

  // 背景星空（固定伪随机）
  var STARS = (function () {
    var a = [], x = 12345;
    function r() { x = (x * 16807) % 2147483647; return x / 2147483647; }
    for (var i = 0; i < 160; i++) a.push([r(), r(), r() * 1.2 + 0.3, r() * 0.5 + 0.2]);
    return a;
  })();

  // ---------- 视图 ----------
  function View(canvas) {
    var ctx = canvas.getContext('2d'), W = 0, H = 0, dpr = 1, narrow = false, geo = null;
    function resize(w, h) {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      W = w; H = h; narrow = w < 640;
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
      canvas.style.width = w + 'px'; canvas.style.height = h + 'px';
    }
    function bg() {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.fillStyle = '#04060c'; ctx.fillRect(0, 0, W, H);
      STARS.forEach(function (s) { ctx.globalAlpha = s[3]; ctx.fillStyle = '#cfd8e6'; ctx.fillRect(s[0] * W, s[1] * H, s[2], s[2]); });
      ctx.globalAlpha = 1;
    }
    function area(bottomExtra) {
      var t0 = narrow ? 84 : 44, bottom = (narrow ? 44 : 40) + (bottomExtra || 0);
      return { x: 12, y: t0, w: W - 24, h: Math.max(120, H - t0 - bottom) };
    }
    function corner(R, lines) {
      lines.forEach(function (s, i) { if (s) label(ctx, s, R.x + R.w - 6, R.y + 10 + i * 17, { align: 'right', size: 12, color: i ? MUTED : TEXT }); });
    }
    function velArrow(fr, s, kv, o) {
      o = o || {};
      var p = fr.p(s.x, s.y), vk = Math.hypot(s.vx, s.vy) * O.V1, L = vk * kv;
      if (L < 2) return;
      var ux = s.vx / Math.hypot(s.vx, s.vy), uy = -s.vy / Math.hypot(s.vx, s.vy);
      arrow(ctx, p.x, p.y, p.x + ux * L, p.y + uy * L, V, { width: 2.4 });
      if (o.label !== false) label(ctx, o.text || 'v', p.x + ux * (L + 12), p.y + uy * (L + 12), { color: V, bold: true, size: 12 });
    }
    function accArrow(fr, s, len) {
      var p = fr.p(s.x, s.y), r = Math.hypot(s.x, s.y);
      arrow(ctx, p.x, p.y, p.x - s.x / r * len, p.y + s.y / r * len, ACC, { width: 2, size: 8 });
    }
    function satAt(fr, s, o) {
      var p = fr.p(s.x, s.y), ang = Math.atan2(-s.vy, s.vx);
      satellite(ctx, p, ang, o);
      return p;
    }

    // ---------- 场景一：宇宙速度（牛顿的“大炮”） ----------
    // o: { h, r0, v, sat, trail, pred, hist: [{ pts, v }], viewR, rot, end, landPt }
    function drawLaunch(o) {
      bg();
      var R = area(), k0 = Math.min(R.w, R.h) / 2 / o.viewR;
      var fr = frame(R, o.viewR, null, R.y + R.h / 2 + (o.viewCy || 0) * k0), rp = fr.k;
      earth(ctx, fr.c, rp, o.rot);
      // 发射塔（高度按比例；太矮时至少 6 像素）
      var top = fr.p(0, o.r0), base = fr.p(0, 1), th = Math.max(top.y, base.y - 6);
      ctx.strokeStyle = '#b0bccd'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(base.x, base.y); ctx.lineTo(base.x, th); ctx.stroke();
      dot(ctx, { x: base.x, y: th }, '#b0bccd', 3);
      // 历次发射的轨迹
      o.hist.forEach(function (hh, i) {
        var col = HIST[i % HIST.length];
        strokePts(ctx, fr, hh.pts, col, { alpha: 0.45, width: 1.6 });
        var e = hh.pts[Math.min(hh.pts.length - 1, Math.floor(hh.pts.length * (hh.end === 'land' ? 1 : 0.42)))], ep = fr.p(e.x, e.y);
        if (ep.x > R.x && ep.x < R.x + R.w && ep.y > R.y && ep.y < R.y + R.h) label(ctx, f(hh.v) + ' km/s', ep.x, ep.y - 12, { size: 11, color: col });
      });
      // 预测轨迹（虚线）与已飞过的轨迹
      strokePts(ctx, fr, o.pred, SAT, { alpha: 0.4, dash: [5, 5], width: 1.4 });
      strokePts(ctx, fr, o.trail, SAT, { width: 2.4 });
      if (o.landPt) {
        var L = fr.p(o.landPt.x, o.landPt.y);
        ctx.strokeStyle = V; ctx.lineWidth = 2.2;
        ctx.beginPath(); ctx.moveTo(L.x - 5, L.y - 5); ctx.lineTo(L.x + 5, L.y + 5); ctx.moveTo(L.x + 5, L.y - 5); ctx.lineTo(L.x - 5, L.y + 5); ctx.stroke();
      }
      if (!o.sat.landed) {
        velArrow(fr, o.sat, Math.min(R.w, R.h) * 0.012);
        satAt(fr, o.sat, { size: 0.8 });
      }
      label(ctx, '发射点', base.x + 10, th - 10, { size: 11, color: MUTED, align: 'left' });
      corner(R, ['v = ' + f(o.v) + ' km/s', '只计地球引力，不计空气阻力', '地球与轨道按真实比例']);
      geo = { scene: 'launch', fr: fr };
    }

    // ---------- 场景二：环绕规律 ----------
    // o: { sats: [{ name, r, phi, color }], rot, station, showChart }
    function drawCircle(o) {
      bg();
      var R = area(), chart = o.showChart && W >= 900;
      var R2 = chart ? { x: R.x + 300, y: R.y, w: R.w - 300, h: R.h } : R;
      var fr = frame(R2, Math.max(7.3, o.sats.reduce(function (m, s) { return Math.max(m, s.r); }, 0) * 1.08));
      earth(ctx, fr.c, fr.k, o.rot);
      // 地面观测站（随地球转动；同步卫星始终在它正上方）
      var st = fr.p(Math.cos(o.station + o.rot), Math.sin(o.station + o.rot));
      dot(ctx, st, '#ff5252', 4);
      var kv = Math.min(R2.w, R2.h) * 0.011;
      o.sats.forEach(function (s, i) {
        circle(ctx, fr, s.r, s.color, { alpha: 0.6, width: 1.4, dash: s.geo ? [6, 4] : [] });
        var v = O.vCirc(s.r) / O.V1, ss = O.stateAt(s.r, s.phi, v);
        if (o.showV) velArrow(fr, ss, kv, { text: 'v' + (i + 1) });
        if (o.showA) accArrow(fr, ss, Math.max(6, Math.min(60, 60 * O.accel(s.r) / O.G0 * 1.2 + 4)));
        var p = satAt(fr, ss, { size: 0.75, color: s.color });
        label(ctx, s.name, p.x, p.y + 20, { size: 11, color: s.color, bold: true });
      });
      if (chart) charts({ x: R.x, y: R.y + 8, w: 280, h: Math.min(R.h - 16, 460) }, o.sats);
      corner(R, ['从北极上空看，地球自转与卫星运行均为逆时针', '红点：赤道上的地面站', '']);
      geo = { scene: 'circle', fr: fr };
    }
    // v–r 与 T–r 曲线
    function charts(B, sats) {
      var gap = 18, h = (B.h - gap) / 2;
      plot({ x: B.x, y: B.y, w: B.w, h: h }, 'v / (km/s)', 8, function (r) { return O.vCirc(r); }, sats, function (r) { return f(O.vCirc(r), 2); }, [2, 4, 6, 8]);
      plot({ x: B.x, y: B.y + h + gap, w: B.w, h: h }, 'T / h', 30, function (r) { return O.periodA(r) / 3600; }, sats, function (r) { return f(O.periodA(r) / 3600, 1) + ' h'; }, [6, 12, 18, 24, 30]);
    }
    function plot(B, yName, yMax, fn, sats, txt, yt) {
      ctx.fillStyle = 'rgba(17,23,35,.82)'; ctx.strokeStyle = '#263044'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.rect(B.x, B.y, B.w, B.h); ctx.fill(); ctx.stroke();
      var X0 = B.x + 40, X1 = B.x + B.w - 12, Y0 = B.y + B.h - 26, Y1 = B.y + 22, rMax = 8;
      function px(r) { return X0 + (r - 0) / rMax * (X1 - X0); }
      function py(y) { return Y0 - y / yMax * (Y0 - Y1); }
      ctx.strokeStyle = 'rgba(141,153,171,.15)'; ctx.beginPath();
      yt.forEach(function (y) { ctx.moveTo(X0, py(y)); ctx.lineTo(X1, py(y)); label(ctx, String(y), X0 - 6, py(y), { size: 10, color: MUTED, align: 'right' }); });
      for (var r = 1; r <= rMax; r++) { ctx.moveTo(px(r), Y0); ctx.lineTo(px(r), Y1); label(ctx, String(r), px(r), Y0 + 10, { size: 10, color: MUTED }); }
      ctx.stroke();
      ctx.strokeStyle = MUTED; ctx.beginPath(); ctx.moveTo(X0, Y1); ctx.lineTo(X0, Y0); ctx.lineTo(X1, Y0); ctx.stroke();
      label(ctx, yName, B.x + 8, B.y + 11, { size: 11, color: TEXT, align: 'left' });
      label(ctx, 'r / R', X1, Y0 + 20, { size: 10, color: MUTED, align: 'right' });
      ctx.save(); ctx.beginPath(); ctx.rect(X0, Y1 - 4, X1 - X0, Y0 - Y1 + 4); ctx.clip();
      ctx.strokeStyle = SAT; ctx.lineWidth = 1.8; ctx.beginPath();
      for (var i = 0; i <= 120; i++) { var rr = 1 + (rMax - 1) * i / 120, q = { x: px(rr), y: py(fn(rr)) }; if (i) ctx.lineTo(q.x, q.y); else ctx.moveTo(q.x, q.y); }
      ctx.stroke(); ctx.restore();
      sats.forEach(function (s) {
        if (s.r > rMax) return;
        var q = { x: px(s.r), y: py(Math.min(fn(s.r), yMax)) };
        dot(ctx, q, s.color, 4.5);
        label(ctx, txt(s.r), q.x + 7, q.y - 10, { size: 10, color: s.color, align: 'left' });
      });
    }

    // ---------- 场景三：变轨 ----------
    // o: { mode, hm (hohmann), sat, trail, orbits: [{ pts, color, alpha, name }], viewR, rot, flame, showV, showA, pts: [{ name, x, y }], stage }
    function drawTransfer(o) {
      bg();
      var R = area(44), fr = frame(R, o.viewR);
      earth(ctx, fr.c, fr.k, o.rot);
      o.orbits.forEach(function (ob) {
        strokePts(ctx, fr, ob.pts, ob.color, { alpha: ob.alpha == null ? 0.85 : ob.alpha, width: ob.width || 1.8, dash: ob.dash });
        if (ob.name && ob.at) {
          var lp = fr.p(ob.at.x, ob.at.y);
          label(ctx, ob.name, lp.x, lp.y, { size: 12, color: ob.color, bold: true });
        }
      });
      strokePts(ctx, fr, o.trail, SAT, { width: 2, alpha: 0.9 });
      (o.marks || []).forEach(function (m) {
        var p = fr.p(m.x, m.y);
        dot(ctx, p, TEXT, 3.5);
        label(ctx, m.name, p.x + (m.dx || 0), p.y + (m.dy || -14), { size: 13, bold: true });
        if (m.sub) label(ctx, m.sub, p.x + (m.dx || 0), p.y + (m.dy || -14) + (m.dy > 0 ? 16 : -16), { size: 11, color: MUTED });
      });
      if (!o.sat.landed) {
        if (o.showV) velArrow(fr, o.sat, Math.min(R.w, R.h) * 0.011);
        if (o.showA) { var r = Math.hypot(o.sat.x, o.sat.y); accArrow(fr, o.sat, Math.max(8, Math.min(70, 70 / (r * r) + 8))); }
        satAt(fr, o.sat, { size: 0.85, flame: o.flame });
      } else {
        var L = fr.p(o.sat.x, o.sat.y);
        label(ctx, '坠落', L.x, L.y - 14, { size: 12, color: V, bold: true });
      }
      corner(R, o.corner || []);
      geo = { scene: 'transfer', fr: fr };
    }

    // ---------- 练习 ----------
    function drawQuiz(q, answered, o) {
      bg();
      var R = area((o.quizH || 180) + 8);
      ctx.save(); ctx.beginPath(); ctx.rect(R.x - 6, R.y - 6, R.w + 12, R.h + 12); ctx.clip();
      if (q.type === 'cosmic') quizCosmic(R, q, answered);
      else if (q.type === 'compare') quizCompare(R, q, answered);
      else quizTransfer(R, q, answered);
      ctx.restore();
      geo = { scene: 'quiz' };
    }
    function quizCosmic(R, q, answered) {
      var vr = q.v / O.V1, far = q.fate === 'ellipse' ? Math.min(O.elements(O.stateAt(1, Math.PI / 2, vr)).ra, 12) : 2.2;
      var fr = frame(R, q.fate === 'ellipse' ? (far + 1) / 2 * 1.08 : 2, null, null);
      if (q.fate === 'ellipse') fr = frame(R, (far + 1) / 2 * 1.1, null, R.y + R.h / 2 - (far - 1) / 2 * Math.min(R.w, R.h) / 2 / ((far + 1) / 2 * 1.1));
      earth(ctx, fr.c, fr.k, 0.6);
      var top = fr.p(0, 1);
      if (answered) {
        var s0 = { x: 0, y: 1, vx: -Math.min(vr, 1.6), vy: 0 };
        if (q.fate === 'land') {
          // 示意：从高塔上以较小速度水平抛出，落回地面
          var s1 = { x: 0, y: 1.06, vx: -vr * 0.98, vy: 0 };
          strokePts(ctx, fr, O.path(s1, 3).pts, SAT, { width: 2.2 });
        } else if (q.fate === 'circle') circle(ctx, fr, 1, SAT, { width: 2.2 });
        else strokePts(ctx, fr, O.path(s0, 40).pts, SAT, { width: 2.2 });
        if (q.fate === 'escape' || q.fate === 'out') label(ctx, q.fate === 'out' ? '→ 飞出太阳系' : '→ 绕太阳运行', R.x + 70, R.y + 20, { size: 13, color: SAT, bold: true });
      }
      arrow(ctx, top.x, top.y - 4, top.x - 60, top.y - 4, V, { width: 2.6 });
      label(ctx, q.v + ' km/s', top.x - 30, top.y - 20, { size: 13, color: V, bold: true });
      satellite(ctx, { x: top.x, y: top.y - 4 }, Math.PI, { size: 0.8 });
    }
    function quizCompare(R, q, answered) {
      var big = Math.max(q.rA, q.rB), fr = frame(R, 1.12), unit = 1 / big;
      var re = Math.min(q.rA, q.rB) * unit * 0.55;
      earth(ctx, fr.c, fr.k * re, 1.2);
      [['A', q.rA, O1, 0.7], ['B', q.rB, O3, 2.6]].forEach(function (s) {
        var r = s[1] * unit;
        circle(ctx, fr, r, s[2], { width: 1.6 });
        var st = O.stateAt(r, s[3], 1), p = fr.p(st.x, st.y);
        satellite(ctx, p, Math.atan2(-st.vy, st.vx), { size: 0.7, color: s[2] });
        label(ctx, s[0], p.x + 16, p.y - 14, { size: 14, color: s[2], bold: true });
        if (answered) {
          var v = 1 / Math.sqrt(s[1]), L = 46 * v / (1 / Math.sqrt(Math.min(q.rA, q.rB)));
          arrow(ctx, p.x, p.y, p.x - Math.sin(s[3]) * L, p.y - Math.cos(s[3]) * L, V, { width: 2 });
        }
      });
      label(ctx, 'rA : rB = ' + q.rA + ' : ' + q.rB + '（示意图）', R.x + R.w / 2, R.y + 10, { size: 12, color: MUTED });
    }
    function quizTransfer(R, q, answered) {
      var r1 = 1.7, r3 = 4, fr = frame(R, r3 * 1.12);
      earth(ctx, fr.c, fr.k, 0.4);
      circle(ctx, fr, r1, O1, { width: 1.6 });
      circle(ctx, fr, r3, O3, { width: 1.6 });
      var a = (r1 + r3) / 2, c = a - r1, b = Math.sqrt(r1 * r3);
      // 椭圆：P 在左（-r1, 0），Q 在右（r3, 0）
      ctx.strokeStyle = O2; ctx.lineWidth = 1.8;
      ctx.beginPath(); ctx.ellipse(fr.c.x + c * fr.k, fr.c.y, a * fr.k, b * fr.k, 0, 0, 7); ctx.stroke();
      var P = fr.p(-r1, 0), Q = fr.p(r3, 0);
      dot(ctx, P, TEXT, 3.5); dot(ctx, Q, TEXT, 3.5);
      label(ctx, 'P', P.x - 12, P.y, { size: 14, bold: true });
      label(ctx, 'Q', Q.x + 14, Q.y, { size: 14, bold: true });
      var l1 = fr.p(r1 * Math.cos(2.2), r1 * Math.sin(2.2)), l2 = fr.p(c + a * Math.cos(1.2), b * Math.sin(1.2)), l3 = fr.p(r3 * Math.cos(2.4), r3 * Math.sin(2.4));
      label(ctx, '1', l1.x - 8, l1.y - 8, { size: 14, color: O1, bold: true });
      label(ctx, '2', l2.x + 8, l2.y - 8, { size: 14, color: O2, bold: true });
      label(ctx, '3', l3.x - 8, l3.y - 8, { size: 14, color: O3, bold: true });
      if (answered) {
        arrow(ctx, P.x, P.y, P.x, P.y + 54, V, { width: 2.2 }); label(ctx, 'vP > v1', P.x + 30, P.y + 50, { size: 12, color: V, align: 'left' });
        arrow(ctx, Q.x, Q.y, Q.x, Q.y - 24, V, { width: 2.2 }); label(ctx, 'vQ < v3', Q.x - 10, Q.y - 32, { size: 12, color: V, align: 'right' });
      }
    }

    return { resize: resize, drawLaunch: drawLaunch, drawCircle: drawCircle, drawTransfer: drawTransfer, drawQuiz: drawQuiz,
      geo: function () { return geo; }, narrow: function () { return narrow; } };
  }

  window.OrbitDraw = { View: View, frame: frame, COLORS: { SAT: SAT, V: V, ACC: ACC, O1: O1, O2: O2, O3: O3 } };
})();
