// 宇宙速度与卫星变轨的计算：二体问题（只计地球引力）、轨道要素、数值推进、霍曼转移、练习题
// 内部用归一化单位：长度以地球半径 R 计、GM = 1，时间单位 TAU = √(R³/GM) ≈ 806 s，速度单位 V1 = √(GM/R) ≈ 7.9 km/s
// 坐标 x 右、y 上，原点在地心；从北极上空看，地球自转与卫星运行都是逆时针
(function () {
  var GM = 3.986004e14, R_KM = 6371, R = R_KM * 1000;
  var TAU = Math.sqrt(R * R * R / GM);           // s
  var V1 = Math.sqrt(GM / R) / 1000;             // km/s，第一宇宙速度
  var V2 = V1 * Math.SQRT2;                      // km/s，第二宇宙速度
  var V3 = 16.7;                                 // km/s，第三宇宙速度（教材值）
  var G0 = GM / (R * R);                         // m/s²，地面附近的引力加速度
  var DAY = 86164;                               // s，恒星日（地球自转周期）
  var GEO = Math.cbrt(GM * DAY * DAY / (4 * Math.PI * Math.PI)) / R;  // 同步轨道半径 ≈ 6.62 R
  var H_LAUNCH = [0, 2000], V_LAUNCH = [3, 13];  // 场景一：发射高度（km）、速度（km/s）
  var H_CIRC = [200, 40000], H_LOW = [200, 8000], H_HIGH = [3000, 40000], DV = [0.1, 3];
  var TYPES = ['cosmic', 'compare', 'transfer'];

  function clamp(x, a, b) { return Math.max(a, Math.min(b, x)); }
  function f(x, n) { n = n == null ? 2 : n; var s = (+x).toFixed(n); if (s.indexOf('.') >= 0) s = s.replace(/0+$/, '').replace(/\.$/, ''); return s === '-0' ? '0' : s; }
  // 单位换算
  function rOfH(km) { return 1 + km / R_KM; }
  function hOfR(r) { return (r - 1) * R_KM; }
  function km(r) { return r * R_KM; }
  function kms(v) { return v * V1; }
  function sec(t) { return t * TAU; }

  // ---------- 圆轨道（归一化 r，返回带单位的量） ----------
  function vCirc(r) { return V1 / Math.sqrt(r); }               // km/s
  function vEsc(r) { return V2 / Math.sqrt(r); }                // km/s
  function periodA(a) { return 2 * Math.PI * Math.pow(a, 1.5) * TAU; }  // s，半长轴 a 的周期（开普勒第三定律）
  function accel(r) { return G0 / (r * r); }                    // m/s²
  function omega(r) { return 2 * Math.PI / periodA(r); }        // rad/s
  function energy(v, r) { return (v * v / 2 - V1 * V1 / r); }   // MJ/kg（v 用 km/s）：单位质量的机械能

  // ---------- 由位置、速度求轨道要素 ----------
  // s: { x, y, vx, vy }（归一化）
  function elements(s) {
    var r = Math.hypot(s.x, s.y), v2 = s.vx * s.vx + s.vy * s.vy, rv = s.x * s.vx + s.y * s.vy;
    var h = s.x * s.vy - s.y * s.vx, E = v2 / 2 - 1 / r;
    var ex = (v2 - 1 / r) * s.x - rv * s.vx, ey = (v2 - 1 / r) * s.y - rv * s.vy, e = Math.hypot(ex, ey);
    var p = h * h, a = Math.abs(E) > 1e-9 ? -1 / (2 * E) : Infinity;
    var w = e > 1e-6 ? Math.atan2(ey, ex) : Math.atan2(s.y, s.x);
    var type = e < 2e-3 ? 'circle' : e < 1 - 1e-3 ? 'ellipse' : e < 1 + 1e-3 ? 'parabola' : 'hyperbola';
    var rp = p / (1 + e), ra = e < 1 ? p / (1 - e) : Infinity;
    return { r: r, h: h, dir: h >= 0 ? 1 : -1, E: E, e: e, p: p, a: a, w: w, rp: rp, ra: ra, type: type,
      closed: e < 1 - 1e-3, T: e < 1 - 1e-3 ? 2 * Math.PI * Math.pow(a, 1.5) : Infinity };
  }
  // 极角 phi 处的轨道半径（无定义时返回 Infinity）
  function rAt(el, phi) {
    var c = 1 + el.e * Math.cos(phi - el.w);
    return c > 1e-6 ? el.p / c : Infinity;
  }
  // 从当前位置沿运动方向采样轨迹（归一化坐标），撞到地面或超出 rMax 时停止
  function path(s, rMax, n) {
    var el = elements(s), phi0 = Math.atan2(s.y, s.x), N = n || 360, pts = [{ x: s.x, y: s.y }], end = 'closed';
    var r0 = Math.hypot(s.x, s.y);
    // 贴地发射且向下：立即落地
    if (r0 <= 1 + 1e-9 && (s.x * s.vx + s.y * s.vy) < -1e-12) return { pts: pts, end: 'land', el: el };
    if (r0 <= 1 + 1e-9 && el.rp < 1 - 1e-6 && Math.abs(el.ra - r0) < 1e-6) return { pts: pts, end: 'land', el: el };
    for (var i = 1; i <= N; i++) {
      var phi = phi0 + el.dir * 2 * Math.PI * i / N, r = rAt(el, phi);
      if (r < 1 - 1e-9) {
        // 二分找落地点
        var lo = phi0 + el.dir * 2 * Math.PI * (i - 1) / N, hi = phi;
        for (var k = 0; k < 30; k++) { var mid = (lo + hi) / 2; if (rAt(el, mid) < 1) hi = mid; else lo = mid; }
        pts.push({ x: Math.cos(lo), y: Math.sin(lo) });
        return { pts: pts, end: 'land', el: el, landPhi: lo };
      }
      if (r > rMax) { var rr = Math.min(r, rMax * 1.5); pts.push({ x: rr * Math.cos(phi), y: rr * Math.sin(phi) }); end = 'out'; break; }
      pts.push({ x: r * Math.cos(phi), y: r * Math.sin(phi) });
    }
    return { pts: pts, end: el.closed ? (end === 'out' ? 'out' : 'closed') : 'out', el: el };
  }
  // 整条圆锥曲线（闭合轨道画一圈；开放轨道画到 rMax）
  function conic(el, rMax, n) {
    var N = n || 240, pts = [];
    if (el.closed) {
      for (var i = 0; i <= N; i++) { var phi = el.w + 2 * Math.PI * i / N, r = rAt(el, phi); pts.push({ x: r * Math.cos(phi), y: r * Math.sin(phi) }); }
      return pts;
    }
    var lim = Math.acos(-1 / el.e);
    for (i = 0; i <= N; i++) {
      var nu = -lim + 2 * lim * i / N, rr = rAt(el, el.w + nu);
      if (rr > rMax) continue;
      pts.push({ x: rr * Math.cos(el.w + nu), y: rr * Math.sin(el.w + nu) });
    }
    return pts;
  }

  // ---------- 数值推进（蛙跳法，步长随 r^1.5 自适应） ----------
  // 返回 'land'（落地）或 null；落地后 s.landed = true
  function step(s, T) {
    var rem = T;
    while (rem > 1e-12) {
      var r = Math.hypot(s.x, s.y), dt = Math.min(rem, 0.002 * Math.pow(r, 1.5));
      var a = -1 / (r * r * r);
      s.vx += a * s.x * dt / 2; s.vy += a * s.y * dt / 2;
      s.x += s.vx * dt; s.y += s.vy * dt;
      r = Math.hypot(s.x, s.y); a = -1 / (r * r * r);
      s.vx += a * s.x * dt / 2; s.vy += a * s.y * dt / 2;
      rem -= dt;
      if (r < 1 - 1e-4) { s.x /= r; s.y /= r; s.vx = s.vy = 0; s.landed = true; return 'land'; }
    }
    return null;
  }
  // 在圆周上极角 phi 处、沿逆时针方向、速率 v（归一化）的状态
  function stateAt(r, phi, v) { return { x: r * Math.cos(phi), y: r * Math.sin(phi), vx: -v * Math.sin(phi), vy: v * Math.cos(phi) }; }
  // 沿速度方向加速 dv（归一化，可为负）
  function burn(s, dv) {
    var v = Math.hypot(s.vx, s.vy);
    if (v < 1e-9) return;
    var k = Math.max(0, v + dv) / v;
    s.vx *= k; s.vy *= k;
  }

  // ---------- 霍曼转移：近地点 P（r1）、远地点 Q（r3），归一化半径 ----------
  function hohmann(r1, r3) {
    var a2 = (r1 + r3) / 2;
    var v1 = 1 / Math.sqrt(r1), vP = Math.sqrt(2 / r1 - 1 / a2), vQ = Math.sqrt(2 / r3 - 1 / a2), v3 = 1 / Math.sqrt(r3);
    return {
      r1: r1, r3: r3, a2: a2, e2: (r3 - r1) / (r3 + r1),
      v1: kms(v1), vP: kms(vP), vQ: kms(vQ), v3: kms(v3),      // km/s
      dv1: kms(vP - v1), dv2: kms(v3 - vQ),
      T1: periodA(r1), T2: periodA(a2), T3: periodA(r3),      // s
      tTransfer: periodA(a2) / 2,
      aP: accel(r1), aQ: accel(r3),                           // m/s²
      E1: energy(kms(v1), r1), E2: energy(kms(vP), r1), E3: energy(kms(v3), r3)
    };
  }
  // 地面附近水平发射的结果（练习用）
  function fate(v) {
    if (v < V1 - 0.05) return 'land';
    if (v < V1 + 0.05) return 'circle';
    if (v < V2 - 0.05) return 'ellipse';
    if (v < V3) return 'escape';
    return 'out';
  }

  // ---------- 格式化 ----------
  function fmtTime(s) {
    if (!isFinite(s)) return '—';
    if (s < 3600) return f(s / 60, s < 600 ? 1 : 0) + ' 分';
    if (s < 86400 * 2) { var hh = Math.floor(s / 3600), mm = Math.round((s - hh * 3600) / 60); if (mm === 60) { hh++; mm = 0; } return hh + ' 时 ' + mm + ' 分'; }
    return f(s / 86400, 1) + ' 天';
  }
  function fmtKm(k) {
    if (!isFinite(k)) return '∞';
    if (Math.abs(k) >= 1e5) return f(k / 1e4, 1) + ' 万 km';
    return Math.round(k).toLocaleString('en-US') + ' km';
  }

  // ---------- 练习 ----------
  function pick(rand, a) { return a[Math.floor(rand() * a.length)]; }
  function shuffle(rand, a) { a = a.slice(); for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(rand() * (i + 1)), t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
  function options(rand, ans, pool, n) {
    var out = [ans];
    shuffle(rand, pool).forEach(function (o) { if (out.length < (n || 4) && out.indexOf(o) < 0) out.push(o); });
    return shuffle(rand, out);
  }

  var FATES = {
    land: '落回地面', circle: '绕地球做匀速圆周运动', ellipse: '绕地球沿椭圆轨道运动',
    escape: '脱离地球，绕太阳运动', out: '飞出太阳系'
  };
  var FATE_WHY = {
    land: '小于第一宇宙速度 7.9 km/s，万有引力大于所需的向心力，物体做向心运动落回地面。',
    circle: '等于第一宇宙速度 7.9 km/s，万有引力恰好提供向心力，物体贴着地面做匀速圆周运动。',
    ellipse: '大于 7.9 km/s、小于第二宇宙速度 11.2 km/s，万有引力不足以提供向心力，物体离心远去，但仍被地球“拉回”，沿椭圆轨道绕地球运动，发射点是近地点。',
    escape: '达到或超过第二宇宙速度 11.2 km/s、小于第三宇宙速度 16.7 km/s，物体挣脱地球引力，成为绕太阳运动的“人造行星”。',
    out: '达到或超过第三宇宙速度 16.7 km/s，物体挣脱太阳引力，飞到太阳系以外。'
  };
  function quizCosmic(rand) {
    var v = pick(rand, [5, 6, 7.9, 7.9, 9, 10, 11.2, 13, 15, 17, 18]), k = fate(v);
    var ans = FATES[k];
    return { type: 'cosmic', v: v, fate: k, answer: ans, options: options(rand, ans, Object.keys(FATES).map(function (x) { return FATES[x]; })),
      prompt: '在地面附近将物体沿水平方向以 ' + v + ' km/s 的速度发射出去（不计空气阻力），物体将会？',
      explain: v + ' km/s ' + FATE_WHY[k] };
  }

  // 两颗圆轨道卫星 A、B 的比值（rA : rB）
  var RATIOS = [[1, 4], [4, 1], [1, 9], [9, 1], [1, 2], [2, 1]];
  var QTY = {
    v: { name: '线速度', sym: 'v', pow: -0.5, law: 'GMm/r² = mv²/r，v = √(GM/r) ∝ 1/√r' },
    w: { name: '角速度', sym: 'ω', pow: -1.5, law: 'GMm/r² = mω²r，ω = √(GM/r³) ∝ 1/√(r³)' },
    T: { name: '周期', sym: 'T', pow: 1.5, law: 'GMm/r² = m(2π/T)²r，T = 2π√(r³/GM) ∝ √(r³)' },
    a: { name: '向心加速度', sym: 'a', pow: -2, law: 'GMm/r² = ma，a = GM/r² ∝ 1/r²' }
  };
  // x^p 写成最简根式：x 为 1、2、4、9、1/2… 的整数比
  function powStr(n, p) {
    // n 为 1、2、3、4、9，p ∈ {±0.5, ±1.5, ±2}，返回 n^|p| 的字符串
    var q = Math.abs(p), val = Math.pow(n, q);
    if (Math.abs(val - Math.round(val)) < 1e-9) return String(Math.round(val));
    if (n === 2 && q === 0.5) return '√2';
    if (n === 2 && q === 1.5) return '2√2';
    return f(val, 2);
  }
  function ratioStr(ra, rb, p) {
    // (ra/rb)^p 写成 A : B
    var big = Math.max(ra, rb), n = big / Math.min(ra, rb), s = powStr(n, p);
    var aBig = (ra > rb) === (p > 0);
    return aBig ? s + ' : 1' : '1 : ' + s;
  }
  function quizCompare(rand) {
    var rr = pick(rand, RATIOS), key = pick(rand, ['v', 'w', 'T', 'a']), Q = QTY[key];
    var ans = ratioStr(rr[0], rr[1], Q.pow), pool = [];
    ['v', 'w', 'T', 'a'].forEach(function (k) { pool.push(ratioStr(rr[0], rr[1], QTY[k].pow), ratioStr(rr[1], rr[0], QTY[k].pow)); });
    pool.push(ratioStr(rr[0], rr[1], 1), ratioStr(rr[1], rr[0], 1));
    return { type: 'compare', rA: rr[0], rB: rr[1], key: key, answer: ans, options: options(rand, ans, pool),
      prompt: '两颗人造卫星 A、B 都绕地球做匀速圆周运动，轨道半径之比 rA : rB = ' + rr[0] + ' : ' + rr[1] + '，它们的' + Q.name + '之比 ' + Q.sym + 'A : ' + Q.sym + 'B = ？',
      explain: '万有引力提供向心力：' + Q.law + '，所以 ' + Q.sym + 'A : ' + Q.sym + 'B = ' + ans + '。轨道越高，v、ω、a 越小，T 越大（“高轨低速长周期”）。' };
  }

  var TRUE_S = [
    '卫星在轨道 2 上经过 P 点的速度大于在轨道 1 上经过 P 点的速度',
    '卫星在轨道 1 上经过 P 点的加速度等于在轨道 2 上经过 P 点的加速度',
    '卫星在轨道 3 上运行的速度小于在轨道 1 上运行的速度',
    '卫星在轨道 2 上运行的周期小于在轨道 3 上运行的周期',
    '卫星由轨道 2 进入轨道 3，需要在 Q 点点火加速',
    '卫星在轨道 3 上的机械能大于在轨道 1 上的机械能',
    '卫星在轨道 2 上从 P 运动到 Q 的过程中，速度逐渐减小'
  ];
  var FALSE_S = [
    '卫星在轨道 2 上经过 Q 点的加速度小于在轨道 3 上经过 Q 点的加速度',
    '卫星在轨道 3 上运行的速度大于 7.9 km/s',
    '卫星由轨道 1 进入轨道 2，需要在 P 点点火减速',
    '卫星在轨道 2 上经过 Q 点的速度大于在轨道 3 上运行的速度',
    '卫星在轨道 1 上运行的周期大于在轨道 2 上运行的周期',
    '卫星在轨道 2 上经过 P 点的速度小于经过 Q 点的速度',
    '卫星在轨道 2 上运行时机械能不断增大'
  ];
  var WHY = {
    0: 'P 点由轨道 1 加速才能进入轨道 2，所以 vP2 > v1。',
    1: '加速度 a = GM/r² 只由到地心的距离决定，同一点加速度相同。',
    2: '圆轨道 v = √(GM/r)，轨道 3 半径大，速度小。',
    3: '轨道 2 的半长轴小于轨道 3 的半径，由开普勒第三定律 a³/T² = k，T2 < T3。',
    4: '在 Q 点 vQ2 < v3，需加速才能进入轨道 3。',
    5: '两次点火都使卫星加速，发动机做正功，机械能 E1 < E2 < E3。',
    6: '从近地点 P 到远地点 Q，引力做负功，动能减小、速度减小。',
    10: '同一点 Q，到地心距离相同，加速度 a = GM/r² 相等。',
    11: '7.9 km/s 是最大的环绕速度，只有近地卫星才等于它，轨道 3 上速度小于 7.9 km/s。',
    12: '进入半径更大的轨道要做离心运动，需在 P 点加速。',
    13: '在 Q 点 vQ2 < v3（卫星在 Q 点做向心运动），需要加速才能进入轨道 3。',
    14: '轨道 1 半径小于轨道 2 的半长轴，T1 < T2。',
    15: 'P 是近地点、Q 是远地点，由开普勒第二定律，近地点速度大于远地点速度。',
    16: '在轨道 2 上只有引力做功，机械能守恒。'
  };
  function quizTransfer(rand) {
    var wantTrue = rand() < 0.6, pickI, others, ans, why = [];
    var ti = shuffle(rand, TRUE_S.map(function (s, i) { return i; })), fi = shuffle(rand, FALSE_S.map(function (s, i) { return i; }));
    var opts;
    if (wantTrue) {
      pickI = ti[0]; ans = TRUE_S[pickI];
      opts = [ans].concat(fi.slice(0, 3).map(function (i) { return FALSE_S[i]; }));
      why.push(WHY[pickI]); fi.slice(0, 3).forEach(function (i) { why.push('“' + FALSE_S[i] + '”错：' + WHY[10 + i]); });
    } else {
      pickI = fi[0]; ans = FALSE_S[pickI];
      opts = [ans].concat(ti.slice(0, 3).map(function (i) { return TRUE_S[i]; }));
      why.push(WHY[10 + pickI]);
    }
    return { type: 'transfer', want: wantTrue, answer: ans, options: shuffle(rand, opts), long: true,
      prompt: '发射地球同步卫星时，先将卫星送入近地圆轨道 1，在 P 点点火使其沿椭圆轨道 2 运行，再在远地点 Q 点火送入圆轨道 3。下列说法' + (wantTrue ? '正确' : '错误') + '的是？',
      explain: why.join(' ') };
  }
  function quiz(rand, avoid, only) {
    var gen = { cosmic: quizCosmic, compare: quizCompare, transfer: quizTransfer }, q;
    for (var i = 0; i < 10; i++) {
      q = gen[only && gen[only] ? only : pick(rand, TYPES)](rand);
      q.id = q.type + '|' + q.prompt + '|' + q.answer;
      if (q.id !== avoid && q.options.indexOf(q.answer) >= 0) break;
    }
    return q;
  }

  window.Orbit = {
    GM: GM, R_KM: R_KM, TAU: TAU, V1: V1, V2: V2, V3: V3, G0: G0, DAY: DAY, GEO: GEO,
    H_LAUNCH: H_LAUNCH, V_LAUNCH: V_LAUNCH, H_CIRC: H_CIRC, H_LOW: H_LOW, H_HIGH: H_HIGH, DV: DV, TYPES: TYPES,
    clamp: clamp, f: f, rOfH: rOfH, hOfR: hOfR, km: km, kms: kms, sec: sec,
    vCirc: vCirc, vEsc: vEsc, periodA: periodA, accel: accel, omega: omega, energy: energy,
    elements: elements, rAt: rAt, path: path, conic: conic, step: step, stateAt: stateAt, burn: burn,
    hohmann: hohmann, fate: fate, fmtTime: fmtTime, fmtKm: fmtKm, quiz: quiz
  };
})();
