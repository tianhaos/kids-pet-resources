// 质谱仪与回旋加速器的计算：速度选择器（正交电磁场中的数值积分）、质谱仪（加速电场 + 偏转磁场 / 速度选择器 + 偏转磁场）、回旋加速器（D 形盒中的半圆 + 缝隙中的加速）
// 世界坐标 x 右、y 上，单位 cm；时间单位 s；速度单位 m/s；电压 V；磁感应强度 T。磁场一律垂直纸面向里（⊗）
// 粒子质量取 A × 1.67×10⁻²⁷ kg（A 为质量数），电荷量取 Z × 1.60×10⁻¹⁹ C，不计重力和相对论效应
(function () {
  var E0 = 1.60e-19, MN = 1.67e-27, TAU = Math.PI * 2;

  // A：质量数，Z：电荷数（带符号）
  var PARTICLES = {
    p: { key: 'p', name: '质子', sym: '¹₁H', A: 1, Z: 1 },
    d: { key: 'd', name: '氘核', sym: '²₁H', A: 2, Z: 1 },
    t: { key: 't', name: '氚核', sym: '³₁H', A: 3, Z: 1 },
    a: { key: 'a', name: 'α 粒子', sym: '⁴₂He', A: 4, Z: 2 },
    h: { key: 'h', name: '负氢离子', sym: 'H⁻', A: 1, Z: -1 }
  };
  // 质谱仪的样品：每种离子带一个正电荷，w 为相对数量（天然丰度 % 或等量混合）
  var SAMPLES = {
    ne: { key: 'ne', name: '氖', note: '天然丰度', ions: [{ sym: '²⁰Ne⁺', A: 20, Z: 1, w: 90.5 }, { sym: '²¹Ne⁺', A: 21, Z: 1, w: 0.27 }, { sym: '²²Ne⁺', A: 22, Z: 1, w: 9.25 }] },
    cl: { key: 'cl', name: '氯', note: '天然丰度', ions: [{ sym: '³⁵Cl⁺', A: 35, Z: 1, w: 75.8 }, { sym: '³⁷Cl⁺', A: 37, Z: 1, w: 24.2 }] },
    c: { key: 'c', name: '碳', note: '等量混合', ions: [{ sym: '¹²C⁺', A: 12, Z: 1, w: 1 }, { sym: '¹³C⁺', A: 13, Z: 1, w: 1 }, { sym: '¹⁴C⁺', A: 14, Z: 1, w: 1 }] },
    h: { key: 'h', name: '氢', note: '等量混合', ions: [{ sym: '¹H⁺', A: 1, Z: 1, w: 1 }, { sym: '²H⁺', A: 2, Z: 1, w: 1 }, { sym: '³H⁺', A: 3, Z: 1, w: 1 }] },
    pda: { key: 'pda', name: '质子、氘核、α', note: '等量混合', ions: [{ sym: '¹₁H', A: 1, Z: 1, w: 1 }, { sym: '²₁H', A: 2, Z: 1, w: 1 }, { sym: '⁴₂He', A: 4, Z: 2, w: 1 }] }
  };

  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
  function mass(P) { return P.A * MN; }
  function charge(P) { return P.Z * E0; }

  // ---------- 通用公式 ----------
  function radius(P, v, B) { return mass(P) * v / (Math.abs(charge(P)) * B) * 100; }       // cm
  function period(P, B) { return TAU * mass(P) / (Math.abs(charge(P)) * B); }               // s
  function speedAfter(P, U) { return Math.sqrt(2 * Math.abs(charge(P)) * U / mass(P)); }   // 由静止经电压 U 加速后的速度
  function ekEV(P, v) { return 0.5 * mass(P) * v * v / E0; }                                 // eV

  // ---------- 速度选择器 ----------
  // 两块水平平行板 0 < x < L、y = ±d/2，上板接正极：E 竖直向下，E = U/d；磁场 B 垂直纸面向里
  // 正电荷向右运动时电场力向下、洛伦兹力向上，qE = qvB 即 v = E/B 时做匀速直线运动
  var SEL = { L: 24, d: 6, slit: 0.35, wall: 1, x0: -7, x1: 34 };
  function selField(x, y, o) {
    var inside = x > 0 && x < SEL.L && Math.abs(y) < SEL.d / 2;
    return { E: inside && o.eOn ? o.U / (SEL.d / 100) : 0, B: inside && o.bOn ? o.B : 0 };
  }
  // 正交电磁场中的加速度（SI）：a = q/m (E + v × B)，E = (0, −E)，B = (0, 0, −B)
  function selAcc(P, vx, vy, f) {
    var k = charge(P) / mass(P);
    return { x: k * (-vy * f.B), y: k * (-f.E + vx * f.B) };
  }
  // RK4 积分一条轨迹。dir = +1 从左侧射入、−1 从右侧射入。返回 { pts:[{x,y,t,vx,vy}], fate: pass|hit|block, hitAt }
  function selector(P, v, o, dir) {
    dir = dir || 1;
    var x = dir > 0 ? SEL.x0 : SEL.L - SEL.x0, y = 0, vx = dir * v, vy = 0, t = 0;
    var pts = [{ x: x, y: y, t: t, vx: vx, vy: vy }], fate = null;
    var Bmax = Math.max(o.B, 0.01), Tc = period(P, Bmax);
    var dt = Math.min(Tc / 600, 0.1 / 100 / v);
    var wallX = dir > 0 ? SEL.L + SEL.wall : -SEL.wall, xEnd = dir > 0 ? SEL.x1 : SEL.L - SEL.x1;
    function deriv(s) {
      var f = selField(s.x * 100, s.y * 100, o), a = selAcc(P, s.vx, s.vy, f);
      return { x: s.vx, y: s.vy, vx: a.x, vy: a.y };
    }
    var s = { x: x / 100, y: 0, vx: vx, vy: vy };
    for (var i = 0; i < 200000; i++) {
      var k1 = deriv(s);
      var k2 = deriv(add(s, k1, dt / 2)), k3 = deriv(add(s, k2, dt / 2)), k4 = deriv(add(s, k3, dt));
      var n = {
        x: s.x + dt / 6 * (k1.x + 2 * k2.x + 2 * k3.x + k4.x), y: s.y + dt / 6 * (k1.y + 2 * k2.y + 2 * k3.y + k4.y),
        vx: s.vx + dt / 6 * (k1.vx + 2 * k2.vx + 2 * k3.vx + k4.vx), vy: s.vy + dt / 6 * (k1.vy + 2 * k2.vy + 2 * k3.vy + k4.vy)
      };
      t += dt;
      var cx = n.x * 100, cy = n.y * 100, px = s.x * 100;
      // 打到极板
      if (cx > 0 && cx < SEL.L && Math.abs(cy) >= SEL.d / 2) {
        var yy = cy > 0 ? SEL.d / 2 : -SEL.d / 2;
        pts.push({ x: cx, y: yy, t: t, vx: n.vx, vy: n.vy });
        fate = 'hit'; break;
      }
      // 穿过出口挡板
      if ((px - wallX) * (cx - wallX) <= 0 && px !== wallX) {
        if (Math.abs(cy) > SEL.slit) { pts.push({ x: wallX, y: cy, t: t, vx: n.vx, vy: n.vy }); fate = 'block'; break; }
      }
      // 从入口一侧退回去
      if ((dir > 0 && cx < SEL.x0 - 0.5) || (dir < 0 && cx > SEL.L - SEL.x0 + 0.5)) { pts.push({ x: cx, y: cy, t: t, vx: n.vx, vy: n.vy }); fate = 'back'; break; }
      s = n;
      if (i % 4 === 0) pts.push({ x: cx, y: cy, t: t, vx: n.vx, vy: n.vy });
      if ((dir > 0 && cx > xEnd) || (dir < 0 && cx < xEnd)) { fate = 'pass'; break; }
    }
    if (!fate) fate = 'pass';
    var last = pts[pts.length - 1];
    if (last.t !== t) pts.push({ x: s.x * 100, y: s.y * 100, t: t, vx: s.vx, vy: s.vy });
    return { pts: pts, fate: fate, end: pts[pts.length - 1], t: t };
  }
  function add(s, k, h) { return { x: s.x + k.x * h, y: s.y + k.y * h, vx: s.vx + k.vx * h, vy: s.vy + k.vy * h }; }
  // 沿积分轨迹按时间取点
  function sampleAt(pts, t) {
    if (t <= pts[0].t) return pts[0];
    var lo = 0, hi = pts.length - 1;
    if (t >= pts[hi].t) return pts[hi];
    while (hi - lo > 1) { var m = (lo + hi) >> 1; if (pts[m].t <= t) lo = m; else hi = m; }
    var a = pts[lo], b = pts[hi], k = (t - a.t) / (b.t - a.t || 1);
    return { x: a.x + (b.x - a.x) * k, y: a.y + (b.y - a.y) * k, vx: a.vx + (b.vx - a.vx) * k, vy: a.vy + (b.vy - a.vy) * k, t: t, i: lo };
  }

  // ---------- 质谱仪 ----------
  // 竖直向下射入 y < 0 的偏转磁场（向里），正离子向右偏，转半圈打在 y = 0 的底片上，落点到入口狭缝 S₃ 的距离 x = 2r
  // 加速型（mode 'u'）：离子源 S₁ 在 y = top，经 S₁、S₂ 间电压 U 由静止加速，再匀速到 S₃
  // 速度选择器型（mode 'sel'）：选择器两极板 x = ±SP.gap/2、SP.selBot < y < SP.selTop，右板接正极（E 向左），磁场 B₁ 向里；只有 v = E/B₁ 的离子从 S₃ 进入 B₂
  // 加速型的 top/accBot 只影响画面（加速段长度不影响落点），由 spanFor() 随视野缩放；速度选择器的尺寸是真实的，影响筛选效果
  var SP = { selTop: 15, selBot: 3, gap: 3, src: 18, slit: 0.3 };
  var SPANS = [10, 16, 24, 32, 48, 64];
  // 视野宽度（cm）：按最远落点分档，只在跨档时缩放
  function spanFor(xMax) { return SPANS.filter(function (z) { return z >= xMax * 1.15; })[0] || SPANS[SPANS.length - 1]; }
  function accGeo(span) { return { top: 0.4 * span, accBot: 0.22 * span }; }
  function spectroU(ion, U, B) {
    var v = speedAfter(ion, U), r = radius(ion, v, B);
    return { v: v, r: r, x: 2 * r };
  }
  function spectroSel(ion, E, B1, B2) {
    var v = E / B1, r = radius(ion, v, B2);
    return { v: v, r: r, x: 2 * r };
  }
  // 由落点反求比荷 q/m（C/kg）
  function qmFromU(U, B, x) { var r = x / 200; return 2 * U / (B * B * r * r); }
  function qmFromSel(E, B1, B2, x) { var r = x / 200; return E / (B1 * B2 * r); }

  // 加速型的路径（按时间）：t₁ 加速段（匀加速，长 h）、t₂ 匀速段、半圆。返回 { T: 总时间, at(t) }
  function pathU(ion, U, B, g) {
    var res = spectroU(ion, U, B), v = res.v, h = (g.top - g.accBot) / 100, d2 = g.accBot / 100;
    var t1 = 2 * h / v, t2 = d2 / v, w = Math.abs(charge(ion)) * B / mass(ion), t3 = Math.PI / w, r = res.r;
    return {
      r: r, x: res.x, v: v, T: t1 + t2 + t3, tField: t1 + t2,
      at: function (t) {
        if (t < t1) { var s = 0.5 * (v / t1) * t * t * 100; return { x: 0, y: g.top - s, vx: 0, vy: -v * t / t1, field: false }; }
        if (t < t1 + t2) return { x: 0, y: g.accBot - (t - t1) * v * 100, vx: 0, vy: -v, field: false };
        var f = Math.min(t - t1 - t2, t3) * w, a = Math.PI + f; // 圆心 (r, 0)，从极角 π 逆时针转到 2π
        return { x: r + r * Math.cos(a), y: r * Math.sin(a), vx: -v * Math.sin(a), vy: v * Math.cos(a), field: true, done: t >= t1 + t2 + t3 };
      }
    };
  }
  // 速度选择器型：离子以速度 v 从 S₁ 竖直向下射入选择器，数值积分到选择器出口；通过狭缝的再转半圈
  function selVert(ion, v, E, B1) {
    // 坐标旋转：选择器的“前进方向”是 −y，横向 x；E 指向 −x，B 向里
    var k = charge(ion) / mass(ion), s = { x: 0, y: SP.src / 100, vx: 0, vy: -v }, t = 0;
    var pts = [{ x: 0, y: SP.src, t: 0, vx: 0, vy: -v }], fate = null, Tc = period(ion, Math.max(B1, 0.01));
    var dt = Math.min(Tc / 600, 0.1 / 100 / v);
    function deriv(q) {
      var X = q.x * 100, Y = q.y * 100, inside = Y > SP.selBot && Y < SP.selTop && Math.abs(X) < SP.gap / 2;
      var Ex = inside ? -E : 0, Bz = inside ? -B1 : 0;
      return { x: q.vx, y: q.vy, vx: k * (Ex + q.vy * Bz), vy: k * (-q.vx * Bz) };
    }
    for (var i = 0; i < 200000; i++) {
      var k1 = deriv(s), k2 = deriv(add(s, k1, dt / 2)), k3 = deriv(add(s, k2, dt / 2)), k4 = deriv(add(s, k3, dt));
      var n = {
        x: s.x + dt / 6 * (k1.x + 2 * k2.x + 2 * k3.x + k4.x), y: s.y + dt / 6 * (k1.y + 2 * k2.y + 2 * k3.y + k4.y),
        vx: s.vx + dt / 6 * (k1.vx + 2 * k2.vx + 2 * k3.vx + k4.vx), vy: s.vy + dt / 6 * (k1.vy + 2 * k2.vy + 2 * k3.vy + k4.vy)
      };
      t += dt;
      var X = n.x * 100, Y = n.y * 100;
      if (Y > SP.selBot && Y < SP.selTop && Math.abs(X) >= SP.gap / 2) { pts.push({ x: X > 0 ? SP.gap / 2 : -SP.gap / 2, y: Y, t: t, vx: n.vx, vy: n.vy }); fate = 'hit'; break; }
      if (Y <= 0) {
        // 到达 S₃ 所在的 y = 0
        var kk = s.y / (s.y - n.y), xs = (s.x + (n.x - s.x) * kk) * 100, ts = t - dt + dt * kk;
        pts.push({ x: xs, y: 0, t: ts, vx: n.vx, vy: n.vy });
        fate = Math.abs(xs) <= SP.slit ? 'pass' : 'block'; t = ts; break;
      }
      if (Y > SP.src + 1) { fate = 'back'; break; }
      s = n;
      if (i % 4 === 0) pts.push({ x: X, y: Y, t: t, vx: n.vx, vy: n.vy });
    }
    return { pts: pts, fate: fate || 'block', t: t };
  }
  function pathSel(ion, v, E, B1, B2) {
    var sv = selVert(ion, v, E, B1), t0 = sv.t, end = sv.pts[sv.pts.length - 1];
    var res = { fate: sv.fate, pts: sv.pts, T: t0, tField: t0, v: v };
    if (sv.fate !== 'pass') { res.at = function (t) { var p = sampleAt(sv.pts, t); p.field = false; p.done = t >= t0; return p; }; return res; }
    var sp = Math.hypot(end.vx, end.vy), r = radius(ion, sp, B2), w = Math.abs(charge(ion)) * B2 / mass(ion), t3 = Math.PI / w;
    var cx = end.x + r;
    res.r = r; res.x = end.x + 2 * r; res.T = t0 + t3;
    res.at = function (t) {
      if (t < t0) { var p = sampleAt(sv.pts, t); p.field = false; return p; }
      var a = Math.PI + Math.min(t - t0, t3) * w;
      return { x: cx + r * Math.cos(a), y: r * Math.sin(a), vx: -sp * Math.sin(a), vy: sp * Math.cos(a), field: true, done: t >= t0 + t3 };
    };
    return res;
  }

  // ---------- 回旋加速器 ----------
  // 两个 D 形盒以 y 轴为缝隙（缝宽 g）左右放置：右盒是圆心 (g/2, 0)、半径 R 的右半圆，左盒圆心 (−g/2, 0)；磁场 B 向里；缝隙中交变电压为方波，幅值 U、频率 f
  // u(t) = +U 时左盒电势高、缝中电场向右。理想化：忽略粒子在缝隙中的运动时间（教材做法），过缝时动能突变 ΔEk = ±qU
  // 粒子从缝隙左边缘由静止释放；方波相位取 u(t) = U · sq(f t + 1/4)，使 f = f₀ 时每次都在半个周期的正中过缝
  // 各半圆的圆心交替上下、逐渐收敛（交错级数），释放点的 y 取 −(收敛值)，让外圈轨迹的圆心落在 D 形盒圆心上，半径达到 R 时恰好引出
  function sq(x) { var f = x - Math.floor(x); return f < 0.5 ? 1 : -1; }
  function cycloFreq(P, B) { return Math.abs(charge(P)) * B / (TAU * mass(P)); }
  function ekMaxEV(P, B, Rcm) { var R = Rcm / 100, q = Math.abs(charge(P)); return q * q * B * B * R * R / (2 * mass(P)) / E0; }
  // f = f₀ 时第 k 次加速后半径 r_k = r(k·qU)，圆心 y 依次为 r₁, 2r₁ − r₂, 2r₁ − 2r₂ + r₃ …（正电荷），取最后一个
  function centerDrift(P, o) {
    var N = Math.max(1, Math.floor(ekMaxEV(P, o.B, o.R) / (Math.abs(P.Z) * o.U))), y = 0, c = 0, sgn = 1;
    for (var k = 1; k <= N; k++) {
      var r = radius(P, Math.sqrt(2 * k * Math.abs(P.Z) * o.U * E0 / mass(P)), o.B);
      c = y + sgn * r; y = c + sgn * r; sgn = -sgn;
    }
    return c;
  }
  // 返回 { segs:[{t:'gap'|'arc'|'out', ...}], crossings:[{t, dE, ek}], fate: 'out'|'stop'|'max', ek, n }
  // arc: { c, r, f0, sweep(弧度，逆时针为正), t0, dur } ；gap: { a, b, t, ek0, ek1 } ；out: { a, dir, t0, v }
  function cyclotron(P, o) {
    var g = o.g, R = o.R, q = charge(P), m = mass(P), s = q > 0 ? 1 : -1; // 正电荷在向里的磁场中逆时针转
    var T = period(P, o.B), w = TAU / T, U = o.U, f = o.f, maxN = o.maxN || 400;
    var ek = 0, t = 0, x = -g / 2, y = -centerDrift(P, o), dir = 1, segs = [], crossings = [], fate = 'max', n = 0;
    // 负电荷：u > 0 时电场向右，负电荷受力向左；把起点放在右边缘，第一次向左加速
    if (q < 0) { x = g / 2; dir = -1; }
    for (var k = 0; k < maxN; k++) {
      var u = U * sq(f * t + 0.25), dE = q / E0 * u * dir; // 正电荷向右过缝、电场向右时被加速（eV）
      var ek1 = ek + dE;
      if (ek1 <= 1e-9) { fate = 'stop'; break; }
      var xb = x + dir * g;
      segs.push({ t: 'gap', a: { x: x, y: y }, b: { x: xb, y: y }, time: t, ek0: ek, ek1: ek1 });
      crossings.push({ t: t, dE: dE, ek: ek1, u: u });
      ek = ek1; n++;
      x = xb;
      var v = Math.sqrt(2 * ek * E0 / m), r = radius(P, v, o.B);
      // 在 D 形盒中转半圈：速度方向 dir（水平），圆心在速度左侧（逆时针）或右侧（顺时针）
      var cy = y + s * dir * r, c = { x: x, y: cy }, f0 = Math.atan2(y - cy, 0), sweep = s * Math.PI;
      // 检查是否碰到 D 形盒边缘（离本盒圆心 (±g/2, 0) 的距离 > R）
      var hitF = null, ox = x > 0 ? g / 2 : -g / 2;
      function outside(ff) { var px = c.x + r * Math.cos(ff) - ox, py = c.y + r * Math.sin(ff); return px * px + py * py > R * R; }
      for (var j = 1; j <= 90; j++) if (outside(f0 + sweep * j / 90)) { hitF = j / 90; break; }
      if (hitF != null) {
        // 二分找出与 D 形盒边缘的交点，粒子沿切线引出
        var lo = (hitF * 90 - 1) / 90, hi = hitF;
        for (var it = 0; it < 30; it++) {
          var mid = (lo + hi) / 2;
          if (outside(f0 + sweep * mid)) hi = mid; else lo = mid;
        }
        var fe = f0 + sweep * hi, dur = T / 2 * hi;
        segs.push({ t: 'arc', c: c, r: r, f0: f0, sweep: sweep * hi, t0: t, dur: dur, v: v });
        var ex = { x: c.x + r * Math.cos(fe), y: c.y + r * Math.sin(fe) }, ad = fe + s * Math.PI / 2;
        segs.push({ t: 'out', a: ex, dir: ad, t0: t + dur, v: v });
        t += dur; fate = 'out';
        break;
      }
      segs.push({ t: 'arc', c: c, r: r, f0: f0, sweep: sweep, t0: t, dur: T / 2, v: v });
      t += T / 2;
      y = cy + (cy - y);
      dir = -dir;
    }
    return { segs: segs, crossings: crossings, fate: fate, ek: ek, n: n, T: T, tEnd: t, f0: 1 / T, y0: segs.length ? segs[0].a.y : 0 };
  }

  // ---------- 数字格式 ----------
  var SUP = { '-': '⁻', 0: '⁰', 1: '¹', 2: '²', 3: '³', 4: '⁴', 5: '⁵', 6: '⁶', 7: '⁷', 8: '⁸', 9: '⁹' };
  function sci(x, digits) {
    if (!isFinite(x) || x === 0) return String(x);
    var e = Math.floor(Math.log10(Math.abs(x))), m = x / Math.pow(10, e);
    if (Math.abs(m) >= 9.995) { m /= 10; e++; }
    return m.toFixed(digits == null ? 2 : digits) + '×10' + String(e).split('').map(function (c) { return SUP[c]; }).join('');
  }
  function fmtTime(sec) {
    if (sec < 1e-6) return (sec * 1e9).toFixed(sec < 1e-8 ? 1 : 0) + ' ns';
    return (sec * 1e6).toFixed(sec < 1e-5 ? 2 : 1) + ' μs';
  }
  function fmtEnergy(ev) { return ev >= 1e6 ? (ev / 1e6).toFixed(2) + ' MeV' : (ev / 1e3).toFixed(ev < 1e4 ? 2 : 1) + ' keV'; }
  function fmtSpeed(v) { return sci(v, 2) + ' m/s'; }

  window.Devices = {
    E0: E0, MN: MN, TAU: TAU, PARTICLES: PARTICLES, SAMPLES: SAMPLES, SEL: SEL, SP: SP, spanFor: spanFor, accGeo: accGeo,
    clamp: clamp, mass: mass, charge: charge,
    radius: radius, period: period, speedAfter: speedAfter, ekEV: ekEV,
    selector: selector, sampleAt: sampleAt,
    spectroU: spectroU, spectroSel: spectroSel, qmFromU: qmFromU, qmFromSel: qmFromSel, pathU: pathU, pathSel: pathSel,
    sq: sq, cycloFreq: cycloFreq, ekMaxEV: ekMaxEV, cyclotron: cyclotron,
    sci: sci, fmtTime: fmtTime, fmtEnergy: fmtEnergy, fmtSpeed: fmtSpeed
  };
})();
