(function () {
  var Dv = window.Devices, SD = window.SpectroDraw, P = Dv.PARTICLES, S = Dv.SAMPLES, C = SD.COLORS;
  var $ = function (id) { return document.getElementById(id); };
  var qa = function (sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); };
  var NAME = '质谱仪与回旋加速器';

  var state = {
    scene: 'selector', tau: 0, paused: false,
    // 速度选择器：v 单位 10⁶ m/s，U 单位 kV
    pk: 'p', v: 1, U: 6, B: 0.1, eOn: true, bOn: true, rev: false, beam: false, arrows: true,
    // 质谱仪：sU 单位 V，E 单位 10⁴ V/m
    sm: 'u', sample: 'ne', sU: 1000, sB: 0.5, E: 4, B1: 0.2, B2: 0.3, marks: true, ideal: true,
    // 回旋加速器：cU 单位 kV，cR 单位 cm，f 单位 MHz
    cpk: 'p', cB: 0.5, cU: 20, cR: 20, f: 0, auto: true, full: false, speed: 'mid'
  };
  var HINTS = {
    selector: '只有 v = E/B 的粒子能直线通过',
    spectro: '同位素转半圈，落在底片的不同位置',
    cyclo: '每过一次缝隙加速一次'
  };
  var SEL_K = [0.7, 0.8, 0.9, 0.95, 1, 1.05, 1.1, 1.2, 1.3];   // 不同速度的粒子束：v / v₀
  var SPEC_K = [0.7, 0.85, 1, 1.15, 1.3];                       // 速度选择器型质谱仪：离子源发出的速度 / v₀
  var SEL_SLOW = 2.5 / 4.1e-7;                                   // 速度选择器：1×10⁶ m/s 的粒子在屏幕上 2.5 s 走完 41 cm
  var CY_TOTAL = { slow: 28, mid: 14, fast: 6 };                 // 回旋加速器：整个加速过程在屏幕上用的秒数（大约）
  var GAP = 1.2;                                                 // D 形盒间的缝宽（cm，示意）

  var stage = $('stage'), panel = $('panel'), cv = $('view');
  var view = SD.View(cv);
  function setSeg(attr, val) { qa('[data-' + attr + ']').forEach(function (b) { b.classList.toggle('on', b.dataset[attr] === String(val)); }); }
  function relaunch() { state.tau = 0; sel.parts = []; sel.next = 0; cy.wait = 0; }

  // ---------- 场景 ----------
  qa('[data-scene]').forEach(function (b) {
    b.addEventListener('click', function () { setScene(b.dataset.scene); Analytics.track(NAME, '场景', b.textContent); });
  });
  function setScene(sc) { state.scene = sc; relaunch(); syncUI(); }

  // ---------- 控件 ----------
  function bindSeg(attr, key, after) {
    qa('[data-' + attr + ']').forEach(function (b) {
      b.addEventListener('click', function () {
        state[key] = b.dataset[attr];
        if (after) after();
        relaunch(); syncUI(); Analytics.track(NAME, attr, b.textContent);
      });
    });
  }
  bindSeg('pk', 'pk');
  bindSeg('sm', 'sm', clearFilm);
  bindSeg('sample', 'sample', clearFilm);
  bindSeg('cpk', 'cpk', matchF);
  bindSeg('speed', 'speed');
  qa('[data-beam]').forEach(function (b) {
    b.addEventListener('click', function () { state.beam = b.dataset.beam === '1'; relaunch(); syncUI(); Analytics.track(NAME, '发射', b.textContent); });
  });
  function bindSlider(id, get, set, after) {
    var el = $(id);
    el.addEventListener('input', function () { set(parseFloat(el.value)); if (after) after(); });
    el.addEventListener('change', function () { Analytics.track(NAME, '滑块', id); });
    return { el: el, get: get };
  }
  var sliders = [
    bindSlider('v', function () { return state.v; }, function (x) { state.v = x; }, relaunch),
    bindSlider('U', function () { return state.U; }, function (x) { state.U = x; }, relaunch),
    bindSlider('B', function () { return state.B; }, function (x) { state.B = x; }, relaunch),
    bindSlider('sU', function () { return state.sU; }, function (x) { state.sU = x; }, clearFilm),
    bindSlider('sB', function () { return state.sB; }, function (x) { state.sB = x; }, clearFilm),
    bindSlider('E', function () { return state.E; }, function (x) { state.E = x; }, clearFilm),
    bindSlider('B1', function () { return state.B1; }, function (x) { state.B1 = x; }, clearFilm),
    bindSlider('B2', function () { return state.B2; }, function (x) { state.B2 = x; }, clearFilm),
    bindSlider('cB', function () { return state.cB; }, function (x) { state.cB = x; }, function () { matchF(); relaunch(); }),
    bindSlider('cU', function () { return state.cU; }, function (x) { state.cU = x; }, relaunch),
    bindSlider('cR', function () { return state.cR; }, function (x) { state.cR = x; }, relaunch),
    bindSlider('f', function () { return state.f; }, function (x) { state.f = x; state.auto = false; }, function () { relaunch(); syncUI(); })
  ];
  [['eOn', 'eOn'], ['bOn', 'bOn'], ['rev', 'rev'], ['arrows', 'arrows'], ['marks', 'marks'], ['ideal', 'ideal'], ['auto', 'auto'], ['full', 'full']].forEach(function (p) {
    $(p[0]).addEventListener('change', function () {
      state[p[1]] = $(p[0]).checked;
      if (p[0] === 'auto') matchF();
      if (['eOn', 'bOn', 'rev', 'auto'].indexOf(p[0]) >= 0) relaunch();
      Analytics.track(NAME, '开关', p[0] + (state[p[1]] ? ' 开' : ' 关'));
    });
  });
  $('fitV').addEventListener('click', function () {
    if (!(state.B > 0) || !(state.U > 0)) return;
    state.v = Dv.clamp(Math.round(v0() / 1e6 * 1000) / 1000, 0.2, 3);
    relaunch(); Analytics.track(NAME, '一键', 'v=E/B');
  });
  $('fitF').addEventListener('click', function () { state.auto = true; matchF(); relaunch(); syncUI(); Analytics.track(NAME, '一键', 'f=f0'); });
  $('clearFilm').addEventListener('click', function () { clearFilm(); Analytics.track(NAME, '清空底片', state.sample); });
  qa('.pauseBtn').forEach(function (b) { b.addEventListener('click', function () { state.paused = !state.paused; syncUI(); }); });
  qa('.replayBtn').forEach(function (b) { b.addEventListener('click', function () { relaunch(); state.paused = false; syncUI(); Analytics.track(NAME, '重新开始', state.scene); }); });
  cv.addEventListener('pointerdown', function (e) {
    if (e.button !== 0 || state.scene === 'spectro') return;
    relaunch(); state.paused = false; syncUI();
  });

  // ---------- 速度选择器 ----------
  var sel = { parts: [], next: 0, cache: {} };
  function v0() { return state.U * 1000 / (Dv.SEL.d / 100) / state.B; }
  function selOpts() { return { U: state.U * 1000, B: state.B, eOn: state.eOn, bOn: state.bOn }; }
  function selTrack(v) {
    var o = selOpts(), key = [state.pk, v.toFixed(0), o.U, o.B, o.eOn, o.bOn, state.rev].join('|');
    if (!sel.cache[key]) {
      var keys = Object.keys(sel.cache);
      if (keys.length > 60) sel.cache = {};
      sel.cache[key] = Dv.selector(P[state.pk], v, o, state.rev ? -1 : 1);
    }
    return sel.cache[key];
  }
  function selBars() {
    var q = Math.abs(Dv.charge(P[state.pk])), fE = state.eOn ? q * state.U * 1000 / (Dv.SEL.d / 100) : 0, fB = state.bOn ? q * state.v * 1e6 * state.B : 0;
    var r = fE && fB ? fB / fE : NaN;
    return { fE: fE, fB: fB, color: Math.abs(r - 1) < 0.005 ? C.V : C.FB,
      text: !isFinite(r) ? '只有一个力，粒子必然偏转' : Math.abs(r - 1) < 0.005 ? 'qE = qvB，合力为零 → 匀速直线运动' : 'qvB / qE = v / v₀ = ' + r.toFixed(2) + (r > 1 ? '，洛伦兹力大' : '，电场力大') };
  }
  function refV() { return state.eOn && state.bOn && state.U > 0 ? v0() : state.v * 1e6; }
  function stepSelector(dt) {
    var tPhys = dt / SEL_SLOW;
    if (!state.beam) {
      var tr = selTrack(state.v * 1e6);
      if (!sel.parts.length) sel.parts = [{ tr: tr, t: 0, color: SD.speedColor(state.eOn && state.bOn && state.U > 0 ? state.v * 1e6 / v0() : 1), q: P[state.pk].Z }];
      var pt = sel.parts[0];
      pt.tr = tr; pt.t = state.tau / SEL_SLOW;
      if (pt.t > tr.t + 1.2 / SEL_SLOW * 1) relaunch();
      return;
    }
    // 粒子束：每 0.22 s 发射一个，速度在 0.7～1.3 倍 v₀ 之间
    sel.next -= dt;
    if (sel.next <= 0) {
      sel.next = 0.22;
      var k = SEL_K[Math.floor(Math.random() * SEL_K.length)], v = Dv.clamp(refV() * k, 1e4, 1e8);
      sel.parts.push({ v: v, k: k, t: 0, color: SD.speedColor(k), q: P[state.pk].Z });
    }
    sel.parts.forEach(function (pt) { pt.tr = selTrack(pt.v); pt.t += tPhys; pt.fade = pt.t > pt.tr.t ? Math.max(0, 1 - (pt.t - pt.tr.t) * SEL_SLOW / 1.2) : 1; });
    sel.parts = sel.parts.filter(function (pt) { return pt.fade > 0; });
  }

  // ---------- 质谱仪 ----------
  var spec = { ions: [], next: 0, film: [], paths: null, key: '', scale: 1, span: 16 };
  function clearFilm() { spec.ions = []; spec.film = []; spec.key = ''; }
  function sample() { return S[state.sample]; }
  function specKey() { return [state.sm, state.sample, state.sU, state.sB, state.E, state.B1, state.B2].join('|'); }
  function specPaths() {
    var key = specKey();
    if (spec.key === key) return spec.paths;
    spec.key = key; spec.ions = [];
    var ions = sample().ions, list;
    spec.span = Dv.spanFor(Math.max.apply(null, ions.map(function (ion) { return specTheory(ion).x; })));
    if (state.sm === 'u') list = ions.map(function (ion) { var g = Dv.accGeo(spec.span); return [Dv.pathU(ion, state.sU, state.sB, g)]; });
    else {
      var E = state.E * 1e4, vs = E / state.B1;
      list = ions.map(function (ion) { return SPEC_K.map(function (k) { return Dv.pathSel(ion, vs * k, E, state.B1, state.B2); }); });
    }
    spec.paths = list;
    // 最轻的离子走完全程在屏幕上用 2.4 s
    var ref = state.sm === 'u' ? list[0][0] : list[0][SPEC_K.indexOf(1)];
    spec.scale = ref.T / 2.4;
    spec.film = ions.map(function (ion, i) { return { n: 0, color: SD.ION_COLS[i], sym: ion.sym, x: 0 }; });
    return list;
  }
  function stepSpectro(dt) {
    var paths = specPaths(), ions = sample().ions, tPhys = dt * spec.scale;
    spec.next -= dt;
    if (spec.next <= 0) {
      spec.next = state.sm === 'u' ? 0.16 : 0.09;
      var tot = ions.reduce(function (s, x) { return s + x.w; }, 0), r = Math.random() * tot, i = 0;
      while (i < ions.length - 1 && r > ions[i].w) { r -= ions[i].w; i++; }
      var set = paths[i], pth = set[Math.floor(Math.random() * set.length)];
      spec.ions.push({ path: pth, sp: i, t: 0, color: SD.ION_COLS[i], linger: 0.5 * spec.scale, counted: false });
    }
    spec.ions.forEach(function (ion) {
      ion.t += tPhys;
      if (!ion.counted && ion.t >= ion.path.T) {
        ion.counted = true;
        if (!ion.path.fate || ion.path.fate === 'pass') { spec.film[ion.sp].n++; spec.film[ion.sp].x = ion.path.x; }
      }
    });
    spec.ions = spec.ions.filter(function (ion) { return ion.t < ion.path.T + ion.linger; });
  }
  function specTheory(ion) {
    return state.sm === 'u' ? Dv.spectroU(ion, state.sU, state.sB) : Dv.spectroSel(ion, state.E * 1e4, state.B1, state.B2);
  }

  // ---------- 回旋加速器 ----------
  var cy = { run: null, key: '', disp: [], total: 0, wait: 0 };
  function matchF() { if (state.auto) state.f = Math.round(Dv.cycloFreq(P[state.cpk], state.cB) / 1e6 * 1000) / 1000; }
  function cyRun() {
    var key = [state.cpk, state.cB, state.cU, state.cR, state.f, state.speed].join('|');
    if (cy.key === key) return cy.run;
    cy.key = key;
    // 自动匹配时用精确的 f₀，避免三位小数的舍入让相位慢慢漂移
    var f = state.auto ? Dv.cycloFreq(P[state.cpk], state.cB) : state.f * 1e6;
    var run = Dv.cyclotron(P[state.cpk], { g: GAP, R: state.cR, B: state.cB, U: state.cU * 1000, f: f, maxN: 400 });
    run.f = f;
    // 屏幕时间轴：半圈用 h 秒，过缝 0.3h（物理上忽略缝中运动时间），引出段 1.2 s
    var h = Dv.clamp(CY_TOTAL[state.speed] / Math.max(1, run.n * 1.3), 0.04, 0.8), acc = 0;
    cy.disp = run.segs.map(function (sg) {
      var d = sg.t === 'gap' ? 0.3 * h : sg.t === 'arc' ? h * sg.dur / (run.T / 2) : 1.2;
      var it = { t0: acc, d: d }; acc += d; return it;
    });
    cy.total = acc;
    cy.run = run;
    return run;
  }
  function cyPos(run, tau) {
    var segs = run.segs, n = segs.length;
    for (var i = 0; i < n; i++) {
      var ds = cy.disp[i];
      if (tau < ds.t0 + ds.d || i === n - 1) {
        var fr = Dv.clamp((tau - ds.t0) / ds.d, 0, 1), sg = segs[i], p, t;
        if (sg.t === 'gap') {
          var v0g = Math.sqrt(2 * sg.ek0 * Dv.E0 / Dv.mass(P[state.cpk])), v1g = Math.sqrt(2 * sg.ek1 * Dv.E0 / Dv.mass(P[state.cpk])), dirg = sg.b.x > sg.a.x ? 1 : -1;
          p = { x: sg.a.x + (sg.b.x - sg.a.x) * fr, y: sg.a.y, vx: dirg * (v0g + (v1g - v0g) * fr), vy: 0 };
          t = sg.time;
        } else if (sg.t === 'arc') {
          var f = sg.f0 + sg.sweep * fr, sgn = sg.sweep > 0 ? 1 : -1;
          p = { x: sg.c.x + sg.r * Math.cos(f), y: sg.c.y + sg.r * Math.sin(f), vx: -sgn * Math.sin(f) * sg.v, vy: sgn * Math.cos(f) * sg.v };
          t = sg.t0 + sg.dur * fr;
        } else {
          var L = 8 * fr;
          p = { x: sg.a.x + Math.cos(sg.dir) * L, y: sg.a.y + Math.sin(sg.dir) * L, vx: Math.cos(sg.dir) * sg.v, vy: Math.sin(sg.dir) * sg.v };
          t = sg.t0;
        }
        var nDone = 0;
        for (var j = 0; j <= i; j++) if (segs[j].t === 'gap' && (j < i || fr > 0.5)) nDone++;
        return { seg: i, frac: fr, p: p, t: t, nDone: nDone, end: tau >= cy.total };
      }
    }
    return { seg: 0, frac: 0, p: null, t: 0, nDone: 0 };
  }

  // ---------- 面板 ----------
  $('panelToggle').addEventListener('click', function () { panel.classList.toggle('collapsed'); });
  if (window.matchMedia('(max-width: 760px)').matches) panel.classList.add('collapsed');
  window.addEventListener('keydown', function (e) {
    var tg = e.target.tagName;
    if (tg === 'INPUT' || tg === 'SELECT' || tg === 'BUTTON' || tg === 'TEXTAREA') return;
    if (e.code === 'Space') { e.preventDefault(); state.paused = !state.paused; syncUI(); }
  });

  function syncUI() {
    var sc = state.scene;
    setSeg('scene', sc);
    qa('[data-for]').forEach(function (el) { el.hidden = el.dataset.for.split(' ').indexOf(sc) < 0; });
    qa('[data-sm-for]').forEach(function (el) { el.hidden = el.dataset.smFor !== state.sm; });
    $('hint').textContent = sc === 'spectro' && state.sm === 'sel' ? '只有 v = E/B₁ 的离子能进入 B₂，x ∝ m' : HINTS[sc];
    setSeg('pk', state.pk); setSeg('sm', state.sm); setSeg('sample', state.sample); setSeg('cpk', state.cpk); setSeg('speed', state.speed);
    setSeg('beam', state.beam ? '1' : '0');
    ['eOn', 'bOn', 'rev', 'arrows', 'marks', 'ideal', 'auto', 'full'].forEach(function (k) { $(k).checked = state[k]; });
    qa('.pauseBtn').forEach(function (b) { b.textContent = state.paused ? '▶ 继续' : '❚❚ 暂停'; });
  }

  // ---------- 读数 ----------
  var lastText = {};
  function setText(id, s) { if (lastText[id] !== s) { lastText[id] = s; $(id).textContent = s; } }
  function rows(list) {
    for (var k = 1; k <= 5; k++) {
      var r = list[k - 1] || ['', ''];
      setText('d' + k, r[0]); setText('r' + k, r[1]);
      $('d' + k).hidden = $('r' + k).hidden = !r[0];
    }
  }
  function fN(x) { return Dv.sci(x, 2) + ' N'; }

  function readSelector() {
    var Pp = P[state.pk], q = Dv.charge(Pp), E = state.U * 1000 / (Dv.SEL.d / 100), both = state.eOn && state.bOn && state.U > 0;
    var fE = state.eOn ? Math.abs(q) * E : 0, fB = state.bOn ? Math.abs(q) * state.v * 1e6 * state.B : 0;
    if (state.beam) {
      setText('rName', both ? 'v₀ = E/B = ' + Dv.fmtSpeed(v0()) : '粒子束');
      setText('rKind', '不同速度');
      setText('rTip', both ? '颜色表示速度：绿色 v = v₀ 直线穿过狭缝；橙色（v > v₀）洛伦兹力大，偏向洛伦兹力一侧；蓝色（v < v₀）电场力大，偏向电场力一侧。'
        : '只有电场或只有磁场时，所有粒子都会偏转，没有粒子能直线通过。');
      rows([
        ['电场', state.eOn ? 'E = U/d = ' + Dv.sci(E, 2) + ' V/m' : '关闭'],
        ['磁场', state.bOn ? 'B = ' + state.B.toFixed(2) + ' T' : '关闭'],
        ['速度范围', '0.7 v₀ ~ 1.3 v₀'],
        ['通过条件', 'qE = qv₀B，v₀ = E/B（与 q、m、电性无关）']
      ]);
      return;
    }
    var tr = selTrack(state.v * 1e6), k = both ? state.v * 1e6 / v0() : NaN, name, kind, tip;
    var fate = { pass: '直线穿过狭缝', hit: '打在极板上', block: '被出口挡板挡住', back: '折返' }[tr.fate];
    if (state.rev) {
      name = fate; kind = '从右侧射入';
      tip = '反向射入时，电场力方向不变，洛伦兹力反向，两力同向，不可能平衡：速度选择器对速度的方向也有选择性。';
    } else if (!both) {
      name = fate; kind = state.eOn && state.U > 0 ? '只有电场' : state.bOn ? '只有磁场' : '无场';
      tip = state.eOn && state.U > 0 ? '只有电场时，粒子做类平抛运动，' + (Pp.Z > 0 ? '向负极板偏转。' : '负电荷向正极板偏转。')
        : state.bOn ? '只有磁场时，洛伦兹力提供向心力，粒子做匀速圆周运动，r = mv/(qB) = ' + Dv.radius(Pp, state.v * 1e6, state.B).toFixed(1) + ' cm。' : '不受力，粒子做匀速直线运动。';
    } else if (Math.abs(k - 1) < 0.005) {
      name = '匀速直线通过'; kind = 'qE = qvB';
      tip = '电场力与洛伦兹力等大反向，合力为零。换成 α 粒子或负氢离子，同样能直线通过——速度选择器只选速度，不选电荷量、质量和电性。';
    } else if (k > 1) {
      name = '偏向洛伦兹力一侧'; kind = 'qvB > qE';
      tip = 'v > E/B，洛伦兹力大于电场力，粒子向洛伦兹力方向偏转；电场力做负功，速度变小。' + (Pp.Z < 0 ? '负电荷两个力都反向，同样偏向洛伦兹力一侧。' : '');
    } else {
      name = '偏向电场力一侧'; kind = 'qvB < qE';
      tip = 'v < E/B，电场力大于洛伦兹力，粒子向电场力方向偏转；电场力做正功，速度变大。';
    }
    setText('rName', name); setText('rKind', kind); setText('rTip', tip);
    rows([
      ['电场力', state.eOn ? 'F电 = qE = ' + fN(fE) : '—'],
      ['洛伦兹力', state.bOn ? 'F洛 = qvB = ' + fN(fB) : '—'],
      ['选择速度', both ? 'v₀ = E/B = ' + Dv.fmtSpeed(v0()) : '—'],
      ['本粒子', Pp.name + '，v = ' + Dv.fmtSpeed(state.v * 1e6) + (both ? '（' + k.toFixed(2) + ' v₀）' : '')],
      ['结果', fate]
    ]);
  }

  function readSpectro() {
    var smp = sample(), ions = smp.ions, U = state.sm === 'u';
    setText('rName', smp.name + (state.sample === 'pda' ? '' : ' 的同位素'));
    setText('rKind', smp.note);
    var tip = U ? '离子由静止经电压 U 加速，qU = ½mv²，在磁场中 r = mv/(qB)，落点 x = 2r = (2/B)√(2mU/q)：电荷量相同时，质量越大落点越远，x ∝ √m。'
      : '只有 v₀ = E/B₁ 的离子能穿过速度选择器，进入 B₂ 后 r = mv₀/(qB₂)，x = 2r = 2mE/(qB₁B₂)：电荷量相同时 x ∝ m，刻度均匀。';
    if (state.sample === 'pda') tip = '氘核（2mp、e）与 α 粒子（4mp、2e）的比荷相同，落在底片上的同一点；质谱仪实际区分的是比荷 q/m。';
    setText('rTip', tip);
    var list = ions.map(function (ion, i) {
      var xx = specTheory(ion).x;
      return [ion.sym, 'x = 2r = ' + xx.toFixed(2) + ' cm，' + (xx > spec.span ? '超出画面' : '已记录 ' + spec.film[i].n + ' 个')];
    });
    var i0 = ions[0], qm0 = i0.Z * Dv.E0 / Dv.mass(i0);
    list.push(['比荷', (U ? 'q/m = 8U/(B²x²)' : 'q/m = 2E/(B₁B₂x)') + '，' + i0.sym + ' 为 ' + Dv.sci(qm0, 2) + ' C/kg']);
    rows(list);
  }

  function readCyclo(run, pos) {
    var Pp = P[state.cpk], f0 = Dv.cycloFreq(Pp, state.cB), ekMax = Dv.ekMaxEV(Pp, state.cB, state.cR), ek = 0;
    for (var i = 0; i < pos.nDone; i++) ek = run.crossings[i].ek;
    setText('rName', 'Ek = ' + Dv.fmtEnergy(ek));
    setText('rKind', '第 ' + pos.nDone + ' 次加速');
    var match = Math.abs(run.f / f0 - 1) < 1e-4, tip;
    if (run.fate === 'out') tip = '轨道半径增大到 D 形盒半径 R 时被引出：Ekmax = q²B²R²/(2m)，与加速电压 U 无关；U 越大，加速次数越少，在 D 形盒中运动的时间越短。';
    else if (run.fate === 'stop') tip = '交变电压的频率与粒子的回旋频率 f₀ 不相等，过缝时电压方向逐渐错开，粒子先加速、后减速，到不了 D 形盒边缘。点「令 f = f₀」恢复同步。';
    else tip = '电压频率与回旋频率不同步，粒子时而加速时而减速。';
    if (match && run.fate === 'out' && state.cpk !== 'p') tip += ' 氘核与 α 粒子比荷相同，所需频率也相同。';
    setText('rTip', tip);
    var N = ekMax / (Math.abs(Pp.Z) * state.cU * 1000);
    if (run.fate !== 'out') {
      var top = Math.max.apply(null, run.crossings.map(function (c) { return c.ek; }));
      rows([
        ['回旋频率', 'f₀ = qB/(2πm) = ' + (f0 / 1e6).toFixed(2) + ' MHz'],
        ['电压频率', 'f = ' + (run.f / 1e6).toFixed(2) + ' MHz，≠ f₀ ✗'],
        ['最高动能', Dv.fmtEnergy(top) + '（同步时可达 ' + Dv.fmtEnergy(ekMax) + '）'],
        ['过缝', run.crossings.filter(function (c) { return c.dE > 0; }).length + ' 次加速，' + run.crossings.filter(function (c) { return c.dE < 0; }).length + ' 次减速']
      ]);
      return;
    }
    rows([
      ['回旋频率', 'f₀ = qB/(2πm) = ' + (f0 / 1e6).toFixed(2) + ' MHz（T = ' + Dv.fmtTime(1 / f0) + '）'],
      ['电压频率', 'f = ' + (run.f / 1e6).toFixed(2) + ' MHz' + (match ? '，与 f₀ 相等 ✓' : '，≠ f₀ ✗')],
      ['最大动能', 'Ekmax = q²B²R²/(2m) = ' + Dv.fmtEnergy(ekMax)],
      ['加速次数', 'n = Ekmax/(qU) ≈ ' + N.toFixed(1) + (run.fate === 'out' ? '，模拟 ' + run.n + ' 次' : '')],
      ['运动时间', 't = n · T/2 ≈ ' + Dv.fmtTime(N / 2 / f0) + '（忽略缝中时间）']
    ]);
  }

  // ---------- 尺寸与主循环 ----------
  function resize() { view.resize(stage.clientWidth, stage.clientHeight); }
  new ResizeObserver(resize).observe(stage);

  // 支持 ?scene=selector|spectro|cyclo
  // 速度选择器 &p=p|d|a|h、&v=0.2~3（×10⁶ m/s）、&U=0~20（kV）、&B=0.02~0.3（T）、&e=0、&b=0、&rev=1、&beam=1
  // 质谱仪 &mode=u|sel、&sample=ne|cl|c|h|pda、&U=100~5000（V）、&B=0.05~1、&E=1~10（×10⁴ V/m）、&B1=、&B2=
  // 快进 &t=0~60（秒，屏幕时间）
  // 回旋加速器 &p=p|d|a、&B=0.2~1、&U=10~50（kV）、&R=10~25（cm）、&f=（MHz，给出后不再自动匹配）、&full=1、&speed=slow|mid|fast
  var qs = new URLSearchParams(location.search);
  function num(k, lo, hi) { var x = parseFloat(qs.get(k)); return isFinite(x) && x >= lo && x <= hi ? x : null; }
  var x;
  if (HINTS[qs.get('scene')]) state.scene = qs.get('scene');
  if (state.scene === 'selector') {
    if (P[qs.get('p')] && qs.get('p') !== 't') state.pk = qs.get('p');
    if ((x = num('v', 0.2, 3)) != null) state.v = x;
    if ((x = num('U', 0, 20)) != null) state.U = x;
    if ((x = num('B', 0.02, 0.3)) != null) state.B = x;
    if (qs.get('e') === '0') state.eOn = false;
    if (qs.get('b') === '0') state.bOn = false;
    if (qs.get('rev') === '1') state.rev = true;
    if (qs.get('beam') === '1') state.beam = true;
  } else if (state.scene === 'spectro') {
    if (qs.get('mode') === 'sel') state.sm = 'sel';
    if (S[qs.get('sample')]) state.sample = qs.get('sample');
    if ((x = num('U', 100, 5000)) != null) state.sU = x;
    if ((x = num('B', 0.05, 1)) != null) state.sB = x;
    if ((x = num('E', 1, 10)) != null) state.E = x;
    if ((x = num('B1', 0.1, 0.5)) != null) state.B1 = x;
    if ((x = num('B2', 0.1, 1)) != null) state.B2 = x;
  } else {
    if (['p', 'd', 'a'].indexOf(qs.get('p')) >= 0) state.cpk = qs.get('p');
    if ((x = num('B', 0.2, 1)) != null) state.cB = x;
    if ((x = num('U', 10, 50)) != null) state.cU = x;
    if ((x = num('R', 10, 25)) != null) state.cR = x;
    if (qs.get('full') === '1') state.full = true;
    if (CY_TOTAL[qs.get('speed')]) state.speed = qs.get('speed');
  }
  matchF();
  if (state.scene === 'cyclo' && (x = num('f', 1, 20)) != null) { state.f = x; state.auto = false; }

  resize();
  setScene(state.scene);
  // &t=秒：打开时先快进一段（截图、分享时直接看到积累的谱线或加速到一半的轨迹）
  if ((x = num('t', 0, 60)) != null) {
    if (state.scene === 'cyclo') { cyRun(); state.tau = x; }
    else for (var ft = 0; ft < x; ft += 0.05) { state.tau += 0.05; if (state.scene === 'selector') stepSelector(0.05); else stepSpectro(0.05); }
  }

  var lastT = performance.now();
  function frame(now) {
    var dt = Math.min((now - lastT) / 1000, 0.1), sc = state.scene;
    lastT = now;
    if (state.paused) dt = 0;
    state.tau += dt;
    sliders.forEach(function (s) { if (document.activeElement !== s.el) s.el.value = s.get(); });
    setText('vOut', state.v.toFixed(2) + '×10⁶ m/s');
    setText('UOut', state.U.toFixed(1) + ' kV');
    setText('BOut', state.B.toFixed(2) + ' T');
    setText('sUOut', state.sU.toFixed(0) + ' V');
    setText('sBOut', state.sB.toFixed(2) + ' T');
    setText('EOut', state.E.toFixed(1) + '×10⁴ V/m');
    setText('B1Out', state.B1.toFixed(2) + ' T');
    setText('B2Out', state.B2.toFixed(2) + ' T');
    setText('cBOut', state.cB.toFixed(2) + ' T');
    setText('cUOut', state.cU.toFixed(0) + ' kV');
    setText('cROut', state.cR.toFixed(0) + ' cm');
    setText('fOut', state.f.toFixed(2) + ' MHz');

    if (sc === 'selector') {
      stepSelector(dt);
      view.drawSelector({ U: state.U * 1000, B: state.B, eOn: state.eOn, bOn: state.bOn, dir: state.rev ? -1 : 1, parts: sel.parts, arrows: state.arrows, bars: state.beam ? null : selBars() });
      readSelector();
    } else if (sc === 'spectro') {
      stepSpectro(dt);
      var smp = sample();
      view.drawSpectro({
        mode: state.sm, U: state.sU, B: state.sB, E: state.E * 1e4, B1: state.B1, B2: state.B2,
        ions: spec.ions, film: spec.film, span: spec.span,
        marks: state.marks ? smp.ions.map(function (ion, i) { return { x: specTheory(ion).x, sym: ion.sym, color: SD.ION_COLS[i] }; }) : [],
        ideal: state.ideal ? smp.ions.map(function (ion, i) { return { r: specTheory(ion).r, x0: 0, color: SD.ION_COLS[i] }; }) : []
      });
      readSpectro();
    } else {
      var run = cyRun();
      if (state.tau > cy.total + 2.5) relaunch();
      var pos = cyPos(run, state.tau);
      view.drawCyclo({
        R: state.cR, g: GAP, B: state.cB, U: state.cU * 1000, f: run.f, run: run, t: pos.t, pos: pos, full: state.full, P: P[state.cpk],
        uNow: state.cU * 1000 * Dv.sq(run.f * pos.t + 0.25), nDone: pos.nDone, ekMax: Dv.ekMaxEV(P[state.cpk], state.cB, state.cR)
      });
      readCyclo(run, pos);
    }
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // 调试用
  window.__model = {
    state: state, setScene: setScene, syncUI: syncUI, relaunch: relaunch, clearFilm: clearFilm,
    setV: function (v) { state.v = Dv.clamp(v, 0.2, 3); relaunch(); },
    setTau: function (t) { state.tau = t; },
    run: function () { return cy.run; }
  };
})();
