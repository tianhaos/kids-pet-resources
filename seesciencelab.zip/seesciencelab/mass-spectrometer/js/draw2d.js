// 2D 绘制：速度选择器（平行板 + 正交磁场）、质谱仪（加速电场或速度选择器 + 偏转磁场 + 底片）、回旋加速器（D 形盒、缝隙电场、u-t 与 Ek-t 图像）
// 世界坐标同 Devices：x 右、y 上，单位 cm；frame(R, box) 把世界范围 box 等比放进屏幕矩形 R
(function () {
  var D = window.Devices;
  var POS = '#ff7a59', NEG = '#4fc3f7', V_COL = '#7ee081', FB_COL = '#ffc94a', FE_COL = '#4fc3f7', ALT = '#c9a7ff';
  var MUTED = '#8d99ab', TEXT = '#e6ebf2', EDGE = '#6f86c9', MARK = 'rgba(141,153,171,.3)', PLUS = '#ff7a59', MINUS = '#4fc3f7';
  var FONT = '-apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", sans-serif';
  // 质谱仪中不同离子的颜色
  var ION_COLS = ['#ffc94a', '#7ee081', '#ff7a59', '#c9a7ff'];

  function font(px, w) { return (w ? w + ' ' : '') + px + 'px ' + FONT; }
  function label(ctx, s, x, y, o) {
    o = o || {};
    ctx.font = font(o.size || 12, o.bold ? 600 : null);
    ctx.textAlign = o.align || 'center'; ctx.textBaseline = o.base || 'middle';
    ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(5,7,13,.85)'; ctx.strokeText(s, x, y);
    ctx.fillStyle = o.color || TEXT; ctx.fillText(s, x, y);
  }
  function arrow(ctx, x1, y1, x2, y2, size, color, width) {
    var a = Math.atan2(y2 - y1, x2 - x1), len = Math.hypot(x2 - x1, y2 - y1);
    if (len < 1) return;
    size = Math.min(size, len * 0.8);
    ctx.strokeStyle = ctx.fillStyle = color; ctx.lineWidth = width || 2.4; ctx.setLineDash([]);
    ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2 - Math.cos(a) * size * 0.6, y2 - Math.sin(a) * size * 0.6); ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(x2, y2);
    ctx.lineTo(x2 - size * Math.cos(a - 0.42), y2 - size * Math.sin(a - 0.42));
    ctx.lineTo(x2 - size * Math.cos(a + 0.42), y2 - size * Math.sin(a + 0.42));
    ctx.closePath(); ctx.fill();
  }
  function frame(R, box) {
    var k = Math.min(R.w / (box.x1 - box.x0), R.h / (box.y1 - box.y0));
    var cx = R.x + R.w / 2, cy = R.y + R.h / 2, mx = (box.x0 + box.x1) / 2, my = (box.y0 + box.y1) / 2;
    return {
      k: k, R: R,
      p: function (x, y) { return { x: cx + (x - mx) * k, y: cy - (y - my) * k }; },
      w: function (sx, sy) { return { x: mx + (sx - cx) / k, y: my - (sy - cy) / k }; }
    };
  }
  function particle(ctx, p, q, color, r) {
    r = r || 7;
    var g = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, r * 2.4);
    g.addColorStop(0, color); g.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.globalAlpha = 0.45; ctx.fillStyle = g; ctx.beginPath(); ctx.arc(p.x, p.y, r * 2.4, 0, 7); ctx.fill(); ctx.globalAlpha = 1;
    ctx.fillStyle = color; ctx.beginPath(); ctx.arc(p.x, p.y, r, 0, 7); ctx.fill();
    if (r < 5) return;
    ctx.strokeStyle = '#111'; ctx.lineWidth = 1.6;
    var d = r * 0.5;
    ctx.beginPath(); ctx.moveTo(p.x - d, p.y); ctx.lineTo(p.x + d, p.y);
    if (q > 0) { ctx.moveTo(p.x, p.y - d); ctx.lineTo(p.x, p.y + d); }
    ctx.stroke();
  }
  // 屏幕矩形（或任意路径）内画 ⊗ 符号
  function bMarks(ctx, x0, y0, x1, y1, sp, color) {
    var rr = Math.max(3, Math.min(5, sp * 0.13));
    ctx.strokeStyle = color || MARK; ctx.lineWidth = 1.2; ctx.setLineDash([]);
    for (var x = x0 + sp / 2; x < x1; x += sp) for (var y = y0 + sp / 2; y < y1; y += sp) {
      var d = rr * 0.7;
      ctx.beginPath(); ctx.arc(x, y, rr, 0, 7); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(x - d, y - d); ctx.lineTo(x + d, y + d); ctx.moveTo(x + d, y - d); ctx.lineTo(x - d, y + d); ctx.stroke();
    }
  }
  function bLegend(ctx, x, y, text) {
    var r = 7, d = r * 0.7;
    ctx.strokeStyle = TEXT; ctx.lineWidth = 1.4;
    ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(x - d, y - d); ctx.lineTo(x + d, y + d); ctx.moveTo(x + d, y - d); ctx.lineTo(x - d, y + d); ctx.stroke();
    label(ctx, text, x + r + 6, y, { align: 'left', size: 12 });
  }
  function plate(ctx, a, b, thick, sign) {
    var col = sign > 0 ? PLUS : sign < 0 ? MINUS : '#56627a';
    ctx.fillStyle = col; ctx.globalAlpha = 0.85;
    var x = Math.min(a.x, b.x), y = Math.min(a.y, b.y), w = Math.abs(b.x - a.x), h = Math.abs(b.y - a.y);
    if (w < h) ctx.fillRect(x - thick / 2, y, thick, h); else ctx.fillRect(x, y - thick / 2, w, thick);
    ctx.globalAlpha = 1;
  }
  function polyline(ctx, fr, pts, i1, color, o) {
    o = o || {};
    if (i1 < 1) return;
    ctx.beginPath();
    for (var i = 0; i <= i1 && i < pts.length; i++) { var s = fr.p(pts[i].x, pts[i].y); if (i) ctx.lineTo(s.x, s.y); else ctx.moveTo(s.x, s.y); }
    if (o.tip) { var t = fr.p(o.tip.x, o.tip.y); ctx.lineTo(t.x, t.y); }
    ctx.strokeStyle = color; ctx.lineWidth = o.width || 2; ctx.globalAlpha = o.alpha == null ? 1 : o.alpha;
    ctx.setLineDash(o.dash || []); ctx.stroke(); ctx.setLineDash([]); ctx.globalAlpha = 1;
  }
  function scaleBar(ctx, k, x, y) {
    var opts = [1, 2, 5, 10, 20], cm = opts[0];
    for (var i = 0; i < opts.length; i++) if (opts[i] * k <= 110) cm = opts[i];
    var w = cm * k;
    ctx.strokeStyle = MUTED; ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.moveTo(x, y - 4); ctx.lineTo(x, y); ctx.lineTo(x + w, y); ctx.lineTo(x + w, y - 4); ctx.stroke();
    label(ctx, cm + ' cm', x + w / 2, y - 10, { size: 11, color: MUTED });
  }
  function speedColor(k) {
    // k = v / v₀：慢（蓝）→ 恰好（绿）→ 快（橙）
    var t = D.clamp((k - 1) / 0.4, -1, 1);
    if (Math.abs(t) < 0.02) return V_COL;
    return t < 0 ? mix('#7ee081', '#4fc3f7', Math.min(1, -t * 1.5)) : mix('#7ee081', '#ff7a59', Math.min(1, t * 1.5));
  }
  function mix(c1, c2, k) {
    var a = parseInt(c1.slice(1), 16), b = parseInt(c2.slice(1), 16);
    var r = Math.round((a >> 16) + ((b >> 16) - (a >> 16)) * k), g = Math.round((a >> 8 & 255) + ((b >> 8 & 255) - (a >> 8 & 255)) * k),
      bl = Math.round((a & 255) + ((b & 255) - (a & 255)) * k);
    return 'rgb(' + r + ',' + g + ',' + bl + ')';
  }

  // ---------- 视图 ----------
  function View(canvas) {
    var ctx = canvas.getContext('2d'), W = 0, H = 0, dpr = 1, narrow = false, geo = null;
    function resize(w, h) {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      W = w; H = h; narrow = w < 640;
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
      canvas.style.width = w + 'px'; canvas.style.height = h + 'px';
    }
    function bg() {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      var g = ctx.createLinearGradient(0, 0, 0, H);
      g.addColorStop(0, '#04060c'); g.addColorStop(1, '#0a1120');
      ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    }
    function area(bottomExtra) {
      var t0 = narrow ? 76 : 48, bottom = (narrow ? 44 : 50) + (bottomExtra || 0);
      return { x: 14, y: t0, w: W - 28, h: Math.max(120, H - t0 - bottom) };
    }

    // ================= 场景一：速度选择器 =================
    // o: { U, B, eOn, bOn, dir, parts:[{ tr, t, color, q, k }], arrows, P }
    function drawSelector(o) {
      bg();
      var S = D.SEL, R = area(narrow ? 40 : 30);
      var fr = frame(R, { x0: S.x0 - 2, x1: S.x1, y0: -S.d / 2 - 3.2, y1: S.d / 2 + 3.2 }), k = fr.k;
      var tl = fr.p(0, S.d / 2), br = fr.p(S.L, -S.d / 2), th = Math.max(5, k * 0.45);
      // 场区
      ctx.fillStyle = 'rgba(111,134,201,.07)'; ctx.fillRect(tl.x, tl.y, br.x - tl.x, br.y - tl.y);
      if (o.bOn) { ctx.save(); ctx.beginPath(); ctx.rect(tl.x, tl.y, br.x - tl.x, br.y - tl.y); ctx.clip(); bMarks(ctx, tl.x, tl.y, br.x, br.y, Math.max(24, Math.min(40, k * 2))); ctx.restore(); }
      if (o.eOn && o.U > 0) {
        // 电场线：竖直向下的箭头
        var n = Math.max(4, Math.round((br.x - tl.x) / 70));
        for (var i = 0; i < n; i++) {
          var x = tl.x + (i + 0.5) * (br.x - tl.x) / n + (o.bOn ? 12 : 0);
          ctx.globalAlpha = 0.55; arrow(ctx, x, tl.y + th, x, br.y - th, 8, FE_COL, 1.2); ctx.globalAlpha = 1;
        }
      }
      plate(ctx, tl, { x: br.x, y: tl.y }, th, o.U > 0 && o.eOn ? 1 : 0);
      plate(ctx, { x: tl.x, y: br.y }, br, th, o.U > 0 && o.eOn ? -1 : 0);
      if (o.eOn && o.U > 0) {
        label(ctx, '+', tl.x - 12, tl.y, { size: 16, bold: true, color: PLUS });
        label(ctx, '−', tl.x - 12, br.y, { size: 16, bold: true, color: MINUS });
      }
      // 入口与出口挡板
      var wx = o.dir > 0 ? S.L + S.wall : -S.wall, w0 = fr.p(wx, S.d / 2 + 2), w1 = fr.p(wx, S.slit), w2 = fr.p(wx, -S.slit), w3 = fr.p(wx, -S.d / 2 - 2);
      ctx.strokeStyle = '#8d99ab'; ctx.lineWidth = 4;
      ctx.beginPath(); ctx.moveTo(w0.x, w0.y); ctx.lineTo(w1.x, w1.y); ctx.moveTo(w2.x, w2.y); ctx.lineTo(w3.x, w3.y); ctx.stroke();
      label(ctx, '出口狭缝', w0.x, w0.y - 12, { size: 11, color: MUTED });
      var sx = o.dir > 0 ? S.x0 : S.L - S.x0, sp = fr.p(sx, 0);
      ctx.fillStyle = '#2a3446'; ctx.fillRect(sp.x - (o.dir > 0 ? 18 : 0), sp.y - 10, 18, 20);
      label(ctx, '粒子源', sp.x + (o.dir > 0 ? -9 : 9), sp.y + 22, { size: 11, color: MUTED });
      // 中心线
      var c0 = fr.p(S.x0, 0), c1 = fr.p(S.x1, 0);
      ctx.strokeStyle = 'rgba(141,153,171,.25)'; ctx.lineWidth = 1; ctx.setLineDash([4, 5]);
      ctx.beginPath(); ctx.moveTo(c0.x, c0.y); ctx.lineTo(c1.x, c1.y); ctx.stroke(); ctx.setLineDash([]);

      // 轨迹与粒子
      ctx.save(); ctx.beginPath(); ctx.rect(R.x - 10, R.y - 20, R.w + 20, R.h + 40); ctx.clip();
      o.parts.forEach(function (pt) {
        var s = D.sampleAt(pt.tr.pts, pt.t), i1 = s.i == null ? (pt.t <= 0 ? 0 : pt.tr.pts.length - 1) : s.i;
        polyline(ctx, fr, pt.tr.pts, i1, pt.color, { tip: s, width: o.parts.length > 1 ? 1.6 : 2.2, alpha: pt.fade == null ? 1 : pt.fade });
        if (pt.t >= pt.tr.t && pt.tr.fate !== 'pass') {
          var e = fr.p(pt.tr.end.x, pt.tr.end.y);
          ctx.strokeStyle = pt.color; ctx.lineWidth = 1.6; ctx.globalAlpha = pt.fade == null ? 1 : pt.fade;
          ctx.beginPath(); ctx.moveTo(e.x - 5, e.y - 5); ctx.lineTo(e.x + 5, e.y + 5); ctx.moveTo(e.x + 5, e.y - 5); ctx.lineTo(e.x - 5, e.y + 5); ctx.stroke();
          ctx.globalAlpha = 1;
          return;
        }
        if (pt.t >= pt.tr.t) return;
        var p = fr.p(s.x, s.y), inField = s.x > 0 && s.x < S.L && Math.abs(s.y) < S.d / 2;
        if (o.arrows && o.parts.length === 1) forceArrows(p, s, pt, o, inField, k);
        particle(ctx, p, pt.q, pt.color, o.parts.length > 1 ? 5 : 7);
      });
      ctx.restore();

      if (o.bars) forceBars(fr.p(0, -S.d / 2 - 3.2).y + 8, R, o.bars);
      // 角标
      var y0 = R.y + 10;
      bLegend(ctx, R.x + 10, y0, o.bOn ? 'B = ' + o.B.toFixed(2) + ' T，垂直纸面向里' : '磁场已关闭');
      label(ctx, o.eOn && o.U > 0 ? 'E = U/d = ' + D.sci(o.U / (S.d / 100), 2) + ' V/m，竖直向下' : '电场已关闭', R.x + (narrow ? 2 : 230), y0 + (narrow ? 22 : 0),
        { align: 'left', size: 12, color: FE_COL });
      scaleBar(ctx, k, R.x + 6, R.y + R.h + (narrow ? 30 : 20));
      geo = { scene: 'selector', fr: fr };
      return geo;
    }
    // 受力对比：两根横条，长度正比于 qE 与 qvB
    function forceBars(top, R, b) {
      if (R.y + R.h - top < 70) return;
      var x = R.x + R.w / 2 - Math.min(220, R.w / 2 - 10), w = Math.min(440, R.w - 20), bw = w - 90, big = Math.max(b.fE, b.fB, 1e-30);
      label(ctx, '受力大小对比（刚进入极板时）', x, top + 6, { align: 'left', size: 12, color: MUTED, bold: true });
      [['F电 = qE', b.fE, FE_COL], ['F洛 = qvB', b.fB, FB_COL]].forEach(function (it, i) {
        var y = top + 26 + i * 22;
        label(ctx, it[0], x, y, { align: 'left', size: 12, color: it[2] });
        ctx.fillStyle = it[2]; ctx.globalAlpha = 0.85; ctx.fillRect(x + 82, y - 6, bw * it[1] / big, 12); ctx.globalAlpha = 1;
      });
      label(ctx, b.text, x, top + 74, { align: 'left', size: 12, color: b.color || TEXT });
    }
    function forceArrows(p, s, pt, o, inField, k) {
      var v = Math.hypot(s.vx, s.vy), L = 46;
      arrow(ctx, p.x, p.y, p.x + s.vx / v * L, p.y - s.vy / v * L, 10, V_COL);
      label(ctx, 'v', p.x + s.vx / v * (L + 12), p.y - s.vy / v * (L + 12), { color: V_COL, bold: true, size: 13 });
      if (!inField) return;
      var q = pt.q, S = D.SEL, fE = o.eOn ? q * o.U / (S.d / 100) : 0, fB = o.bOn ? q * v * o.B : 0;
      var big = Math.max(Math.abs(fE), Math.abs(fB), 1e-9), sc = 44 / big;
      // 电场力竖直：qE 向下（q>0）；洛伦兹力 qv × B，垂直速度
      if (fE) {
        var le = -fE * sc;
        arrow(ctx, p.x - 6, p.y, p.x - 6, p.y - le, 9, FE_COL, 2.2);
        label(ctx, 'F电', p.x - 24, p.y - le + (le > 0 ? -6 : 6), { color: FE_COL, bold: true, size: 12 });
      }
      if (fB) {
        // B 指向 −z：v × B = (−vy·B, vx·B)
        var fx = -s.vy / v * fB * sc, fy = s.vx / v * fB * sc;
        arrow(ctx, p.x + 6, p.y, p.x + 6 + fx, p.y - fy, 9, FB_COL, 2.2);
        label(ctx, 'F洛', p.x + 26 + fx, p.y - fy + (fy > 0 ? -6 : 6), { color: FB_COL, bold: true, size: 12 });
      }
    }

    // ================= 场景二：质谱仪 =================
    // o: { mode:'u'|'sel', U, B, E, B1, B2, sample, ions:[{ path, t, color, q }], film:[{x, n, color, sym}], marks:[{x, sym, color}], ideal:[{r, x0, color}] }
    function drawSpectro(o) {
      bg();
      var SP = D.SP, sel = o.mode === 'sel', R = area();
      // 视野按最远的落点分档（Devices.spanFor），只在跨档时缩放，调参数时能看出落点移动
      var span = o.span, G = D.accGeo(span), dep = span / 2 + 1, yTop = sel ? SP.src + 2.5 : G.top + 0.16 * span;
      var fr = frame(R, { x0: -Math.max(6, span * 0.2), x1: span + 0.5, y0: -dep, y1: yTop }), k = fr.k;
      // 偏转磁场区
      var a = fr.p(-2, 0), b = fr.p(span, -dep + 0.3);
      ctx.fillStyle = 'rgba(111,134,201,.08)'; ctx.fillRect(a.x, a.y, b.x - a.x, b.y - a.y);
      ctx.save(); ctx.beginPath(); ctx.rect(a.x, a.y, b.x - a.x, b.y - a.y); ctx.clip();
      bMarks(ctx, a.x, a.y, b.x, b.y, Math.max(24, Math.min(40, k * 2.2)));
      ctx.restore();
      ctx.strokeStyle = EDGE; ctx.lineWidth = 1.5; ctx.strokeRect(a.x, a.y, b.x - a.x, b.y - a.y);
      label(ctx, (sel ? 'B₂ = ' + o.B2.toFixed(2) : 'B = ' + o.B.toFixed(2)) + ' T', b.x - 8, b.y - 14, { align: 'right', size: 12, color: TEXT });

      // 底片：y = 0、x 从 0.6 到 plate，刻度以 S₃ 为零点
      var f0 = fr.p(SP.slit + 0.3, 0), f1 = fr.p(span, 0), fh = Math.max(7, Math.min(12, k * 0.5));
      ctx.fillStyle = '#2b3242'; ctx.fillRect(f0.x, f0.y - fh, f1.x - f0.x, fh);
      ctx.fillStyle = '#56627a'; ctx.fillRect(fr.p(-2, 0).x, f0.y - fh, fr.p(-SP.slit, 0).x - fr.p(-2, 0).x, fh);
      // 感光斑
      o.film.forEach(function (f) {
        if (!f.n) return;
        var p = fr.p(f.x, 0), al = 1 - Math.exp(-f.n / 6), w = Math.max(3, k * 0.25);
        ctx.globalAlpha = 0.25 + 0.75 * al; ctx.fillStyle = f.color;
        ctx.fillRect(p.x - w / 2, p.y - fh, w, fh);
        ctx.globalAlpha = 0.3 * al; ctx.fillRect(p.x - w * 1.5, p.y - fh, w * 3, fh);
        ctx.globalAlpha = 1;
      });
      ctx.strokeStyle = MUTED; ctx.lineWidth = 1; ctx.fillStyle = MUTED;
      var step = k > 22 ? 1 : 2;
      for (var c = 0; c <= span; c += step) {
        var tp = fr.p(c, 0), big = c % 5 === 0;
        ctx.beginPath(); ctx.moveTo(tp.x, tp.y - fh); ctx.lineTo(tp.x, tp.y - fh - (big ? 6 : 3)); ctx.stroke();
        if (big && c > 0) label(ctx, String(c), tp.x, tp.y - fh - 14, { size: 10, color: MUTED });
      }
      label(ctx, '底片（cm）', f1.x, f1.y - fh - 28, { align: 'right', size: 11, color: MUTED });
      label(ctx, 'S₃', fr.p(0, 0).x - 14, f0.y - fh - 8, { size: 12, color: TEXT });
      // 理论落点
      o.marks.forEach(function (m, i) {
        // 落点很近时标签依次往下错开，用细线连到落点
        var p = fr.p(m.x, 0), yy = p.y + 18 + i * 16, lx = p.x + 10;
        ctx.fillStyle = m.color; ctx.beginPath(); ctx.moveTo(p.x, p.y + 2); ctx.lineTo(p.x - 4, p.y + 8); ctx.lineTo(p.x + 4, p.y + 8); ctx.fill();
        ctx.strokeStyle = m.color; ctx.globalAlpha = 0.6; ctx.lineWidth = 1;
        ctx.beginPath(); ctx.moveTo(p.x, p.y + 8); ctx.lineTo(p.x, yy); ctx.lineTo(lx - 2, yy); ctx.stroke(); ctx.globalAlpha = 1;
        label(ctx, m.sym, lx, yy, { size: 11, color: m.color, bold: true, align: 'left' });
      });
      // 理论轨迹（半圆）
      o.ideal.forEach(function (it) {
        var c = fr.p(it.x0 + it.r, 0);
        ctx.strokeStyle = it.color; ctx.globalAlpha = 0.35; ctx.lineWidth = 1.2; ctx.setLineDash([4, 5]);
        ctx.beginPath(); ctx.arc(c.x, c.y, it.r * k, 0, Math.PI); ctx.stroke(); ctx.setLineDash([]); ctx.globalAlpha = 1;
      });

      if (!sel) {
        // 离子源 + 加速电场 S₁、S₂
        var s1 = fr.p(0, G.top), s2 = fr.p(0, G.accBot), u = span * k, pw = 0.11 * u, th = Math.max(4, Math.min(8, u * 0.012)), hole = Math.max(4, 0.012 * u);
        ctx.fillStyle = '#2a3446'; ctx.fillRect(s1.x - 0.04 * u, s1.y - 0.1 * u, 0.08 * u, 0.07 * u);
        label(ctx, '离子源', s1.x + 0.06 * u, s1.y - 0.065 * u, { align: 'left', size: 11, color: MUTED });
        [[s1, 1, 'S₁'], [s2, -1, 'S₂']].forEach(function (it) {
          var p = it[0];
          ctx.fillStyle = it[1] > 0 ? PLUS : MINUS; ctx.globalAlpha = 0.85;
          ctx.fillRect(p.x - pw, p.y - th / 2, pw - hole, th); ctx.fillRect(p.x + hole, p.y - th / 2, pw - hole, th); ctx.globalAlpha = 1;
          label(ctx, it[2], p.x - pw - 14, p.y, { size: 12 });
          label(ctx, it[1] > 0 ? '+' : '−', p.x + pw + 10, p.y, { size: 15, bold: true, color: it[1] > 0 ? PLUS : MINUS });
        });
        ctx.globalAlpha = 0.5; arrow(ctx, s1.x + pw * 0.6, s1.y + th, s1.x + pw * 0.6, s2.y - th, 8, FE_COL, 1.2); ctx.globalAlpha = 1;
        label(ctx, 'U = ' + fmtV(o.U), s1.x + pw + 26, (s1.y + s2.y) / 2, { align: 'left', size: 12, color: FE_COL });
      } else {
        // 离子源 + 竖直的速度选择器（左 −、右 +，E 向左，B₁ 向里）
        var src = fr.p(0, SP.src), tt = fr.p(-SP.gap / 2, SP.selTop), bb = fr.p(SP.gap / 2, SP.selBot), tw = Math.max(5, k * 0.4);
        ctx.fillStyle = '#2a3446'; ctx.fillRect(src.x - 1.2 * k, src.y - 0.2 * k, 2.4 * k, 1.6 * k);
        label(ctx, '离子源（速度不一）', src.x + 1.6 * k, src.y + 0.6 * k, { align: 'left', size: 11, color: MUTED });
        ctx.fillStyle = 'rgba(111,134,201,.08)'; ctx.fillRect(tt.x, tt.y, bb.x - tt.x, bb.y - tt.y);
        ctx.save(); ctx.beginPath(); ctx.rect(tt.x, tt.y, bb.x - tt.x, bb.y - tt.y); ctx.clip();
        bMarks(ctx, tt.x, tt.y, bb.x, bb.y, Math.max(18, (bb.x - tt.x) / 2)); ctx.restore();
        plate(ctx, tt, { x: tt.x, y: bb.y }, tw, -1);
        plate(ctx, { x: bb.x, y: tt.y }, bb, tw, 1);
        label(ctx, '−', tt.x - 14, (tt.y + bb.y) / 2, { size: 15, bold: true, color: MINUS });
        label(ctx, '+', bb.x + 14, (tt.y + bb.y) / 2, { size: 15, bold: true, color: PLUS });
        ctx.globalAlpha = 0.5; arrow(ctx, bb.x - tw, tt.y + 10, tt.x + tw, tt.y + 10, 7, FE_COL, 1.2); arrow(ctx, bb.x - tw, bb.y - 10, tt.x + tw, bb.y - 10, 7, FE_COL, 1.2); ctx.globalAlpha = 1;
        label(ctx, '速度选择器', bb.x + 28, tt.y + 8, { align: 'left', size: 12, color: TEXT, bold: true });
        label(ctx, 'E = ' + D.sci(o.E, 1) + ' V/m', bb.x + 28, tt.y + 28, { align: 'left', size: 12, color: FE_COL });
        label(ctx, 'B₁ = ' + o.B1.toFixed(2) + ' T', bb.x + 28, tt.y + 46, { align: 'left', size: 12 });
        label(ctx, 'v₀ = E/B₁ = ' + D.sci(o.E / o.B1, 2) + ' m/s', bb.x + 28, tt.y + 64, { align: 'left', size: 12, color: V_COL });
      }

      // 离子
      ctx.save(); ctx.beginPath(); ctx.rect(R.x - 10, R.y - 10, R.w + 20, R.h + 20); ctx.clip();
      o.ions.forEach(function (ion) {
        var pth = ion.path, n = 14, t0 = Math.max(0, ion.t - pth.T * 0.12);
        if (ion.t > pth.T + ion.linger) return;
        var tEnd = Math.min(ion.t, pth.T);
        ctx.beginPath();
        for (var i = 0; i <= n; i++) {
          var q = pth.at(t0 + (tEnd - t0) * i / n), s = fr.p(q.x, q.y);
          if (i) ctx.lineTo(s.x, s.y); else ctx.moveTo(s.x, s.y);
        }
        ctx.strokeStyle = ion.color; ctx.lineWidth = 1.6; ctx.globalAlpha = 0.6; ctx.stroke(); ctx.globalAlpha = 1;
        var cur = pth.at(tEnd), cp = fr.p(cur.x, cur.y);
        if (ion.t >= pth.T) {
          if (pth.fate && pth.fate !== 'pass') {
            ctx.strokeStyle = ion.color; ctx.lineWidth = 1.4;
            ctx.beginPath(); ctx.moveTo(cp.x - 4, cp.y - 4); ctx.lineTo(cp.x + 4, cp.y + 4); ctx.moveTo(cp.x + 4, cp.y - 4); ctx.lineTo(cp.x - 4, cp.y + 4); ctx.stroke();
          }
          return;
        }
        particle(ctx, cp, 1, ion.color, 4);
      });
      ctx.restore();
      bLegend(ctx, R.x + 10, R.y + 8, '磁场垂直纸面向里');
      scaleBar(ctx, k, R.x + 6, R.y + R.h + 26);
      geo = { scene: 'spectro', fr: fr };
      return geo;
    }
    function fmtV(U) { return U >= 1000 ? (U / 1000).toFixed(U >= 10000 ? 0 : 2).replace(/\.?0+$/, '') + ' kV' : U.toFixed(0) + ' V'; }

    // ================= 场景三：回旋加速器 =================
    // o: { R, g, B, U, run, t(物理时间), pos:{x,y,vx,vy,seg}, full, P, uNow }
    function drawCyclo(o) {
      bg();
      var gH = narrow ? 118 : 140, R = area(gH + 8), Rc = o.R, g = o.g, run = o.run;
      var fr = frame(R, { x0: -Rc - g / 2 - 1.5, x1: Rc + g / 2 + 1.5, y0: -Rc - 6.5, y1: Rc + 1.5 }), k = fr.k;
      var cL = fr.p(-g / 2, 0), cR = fr.p(g / 2, 0), rr = Rc * k;
      // D 形盒
      [[cL, Math.PI / 2, Math.PI * 1.5, -1, 'D₁'], [cR, -Math.PI / 2, Math.PI / 2, 1, 'D₂']].forEach(function (it) {
        var c = it[0];
        // 屏幕角度顺时针：左盒从下（π/2）经左到上（3π/2），右盒从上（−π/2）经右到下（π/2）
        ctx.beginPath(); ctx.arc(c.x, c.y, rr, it[3] < 0 ? Math.PI / 2 : -Math.PI / 2, it[3] < 0 ? Math.PI * 1.5 : Math.PI / 2); ctx.closePath();
        var gr = ctx.createRadialGradient(c.x, c.y, 0, c.x, c.y, rr);
        gr.addColorStop(0, 'rgba(70,86,120,.30)'); gr.addColorStop(1, 'rgba(70,86,120,.12)');
        ctx.fillStyle = gr; ctx.fill();
        ctx.strokeStyle = '#7d8aa3'; ctx.lineWidth = 2; ctx.stroke();
        label(ctx, it[4], c.x + it[3] * rr * 0.78, c.y - rr * 0.78, { size: 13, bold: true, color: MUTED });
      });
      ctx.save();
      ctx.beginPath(); ctx.arc(cL.x, cL.y, rr, Math.PI / 2, Math.PI * 1.5); ctx.closePath(); ctx.arc(cR.x, cR.y, rr, -Math.PI / 2, Math.PI / 2); ctx.closePath(); ctx.clip();
      bMarks(ctx, cL.x - rr, cL.y - rr, cR.x + rr, cR.y + rr, Math.max(26, Math.min(44, rr / 6)), 'rgba(141,153,171,.2)');
      ctx.restore();
      // 缝隙中的电场（随 u 的正负翻转）
      var u = o.uNow, gt = fr.p(0, Rc * 0.92), gb = fr.p(0, -Rc * 0.92);
      if (u) {
        var n = 5, mx = (cL.x + cR.x) / 2, hw = Math.max(5, g * k / 2 + 3), sgn = u > 0 ? 1 : -1;
        for (var i = 0; i < n; i++) {
          var yy = gt.y + (gb.y - gt.y) * (i + 0.5) / n;
          ctx.globalAlpha = 0.75; arrow(ctx, mx - sgn * hw, yy, mx + sgn * hw, yy, 6, FE_COL, 1.4); ctx.globalAlpha = 1;
        }
        label(ctx, u > 0 ? '+' : '−', cL.x - rr * 0.35, cL.y + rr * 0.55, { size: 18, bold: true, color: u > 0 ? PLUS : MINUS });
        label(ctx, u > 0 ? '−' : '+', cR.x + rr * 0.35, cR.y + rr * 0.55, { size: 18, bold: true, color: u > 0 ? MINUS : PLUS });
      }
      // 交变电源
      var py = fr.p(0, -Rc - 2.8).y, lx = cL.x - rr * 0.5, rx = cR.x + rr * 0.5, by = cL.y + Math.sqrt(Math.max(0, 1 - 0.25)) * rr;
      ctx.strokeStyle = '#7d8aa3'; ctx.lineWidth = 1.4;
      ctx.beginPath(); ctx.moveTo(lx, by); ctx.lineTo(lx, py); ctx.lineTo((cL.x + cR.x) / 2 - 14, py); ctx.moveTo((cL.x + cR.x) / 2 + 14, py); ctx.lineTo(rx, py); ctx.lineTo(rx, by); ctx.stroke();
      ctx.beginPath(); ctx.arc((cL.x + cR.x) / 2, py, 14, 0, 7); ctx.stroke();
      ctx.beginPath();
      for (var j = 0; j <= 20; j++) { var xx = (cL.x + cR.x) / 2 - 8 + j * 0.8, y2 = py - Math.sin(j / 20 * Math.PI * 2) * 5; if (j) ctx.lineTo(xx, y2); else ctx.moveTo(xx, y2); }
      ctx.stroke();
      label(ctx, '交变电压 U = ' + (o.U / 1000).toFixed(0) + ' kV，f = ' + (o.f / 1e6).toFixed(2) + ' MHz', (cL.x + cR.x) / 2, py + 26, { size: 12, color: MUTED });

      // 轨迹
      ctx.save(); ctx.beginPath(); ctx.rect(R.x - 10, R.y - 10, R.w + 20, R.h + 20); ctx.clip();
      var cur = o.pos;
      run.segs.forEach(function (sg, idx) {
        var done = idx < cur.seg, now = idx === cur.seg;
        if (!done && !now && !o.full) return;
        ctx.beginPath();
        var frac = done ? 1 : now ? cur.frac : 1;
        if (sg.t === 'gap') {
          var a = fr.p(sg.a.x, sg.a.y), b = fr.p(sg.b.x, sg.b.y);
          ctx.moveTo(a.x, a.y); ctx.lineTo(a.x + (b.x - a.x) * frac, a.y + (b.y - a.y) * frac);
          if (!done && !now) { ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); }
        } else if (sg.t === 'arc') {
          var c = fr.p(sg.c.x, sg.c.y), fEnd = sg.f0 + sg.sweep * (done || (!now) ? 1 : frac);
          ctx.arc(c.x, c.y, sg.r * k, -sg.f0, -fEnd, sg.sweep > 0);
        } else {
          var e = fr.p(sg.a.x, sg.a.y), L = 8 * k * (done ? 1 : now ? frac : 1);
          ctx.moveTo(e.x, e.y); ctx.lineTo(e.x + Math.cos(sg.dir) * L, e.y - Math.sin(sg.dir) * L);
        }
        var ghost = !done && !now;
        ctx.strokeStyle = ghost ? 'rgba(255,122,89,.28)' : sg.t === 'gap' ? FE_COL : POS;
        ctx.lineWidth = ghost ? 1 : sg.t === 'gap' ? 2.4 : 1.8;
        if (ghost) ctx.setLineDash([3, 4]);
        ctx.stroke(); ctx.setLineDash([]);
      });
      if (cur.p) {
        var sp = fr.p(cur.p.x, cur.p.y), vv = Math.hypot(cur.p.vx, cur.p.vy);
        if (vv > 0) arrow(ctx, sp.x, sp.y, sp.x + cur.p.vx / vv * 36, sp.y - cur.p.vy / vv * 36, 9, V_COL);
        particle(ctx, sp, o.P.Z, o.P.Z > 0 ? POS : NEG, 6);
      }
      ctx.restore();
      bLegend(ctx, R.x + 10, R.y + 8, 'B = ' + o.B.toFixed(2) + ' T');
      label(ctx, 'D 形盒半径 R = ' + Rc.toFixed(0) + ' cm', R.x + 10, R.y + 30, { align: 'left', size: 12, color: MUTED });

      // 图像
      var GY = H - (narrow ? 40 : 46) - gH, gw = (W - 28 - 16) / 2;
      graphU({ x: 14, y: GY, w: gw, h: gH }, o);
      graphE({ x: 14 + gw + 16, y: GY, w: gw, h: gH }, o);
      geo = { scene: 'cyclo', fr: fr };
      return geo;
    }
    function graphBox(G, title) {
      ctx.fillStyle = 'rgba(17,23,35,.85)'; ctx.strokeStyle = '#2a3446'; ctx.lineWidth = 1;
      ctx.fillRect(G.x, G.y, G.w, G.h); ctx.strokeRect(G.x + 0.5, G.y + 0.5, G.w - 1, G.h - 1);
      label(ctx, title, G.x + 8, G.y + 12, { align: 'left', size: 11, color: MUTED, bold: true });
      return { x: G.x + 30, y: G.y + 24, w: G.w - 40, h: G.h - 42 };
    }
    // u-t：方波，滚动窗口约 6 个周期；标出每次过缝的时刻（绿=加速，红=减速）
    function graphU(G, o) {
      var A = graphBox(G, G.w < 380 ? '电压 u-t' : '缝隙电压 u-t（u > 0：D₁ 电势高）'), run = o.run, T = run.T, span = Math.min(Math.max(run.tEnd, T), 6 * T);
      var t0 = D.clamp(o.t - span * 0.7, 0, Math.max(0, run.tEnd - span)), mid = A.y + A.h / 2, amp = A.h / 2 - 4;
      function X(t) { return A.x + (t - t0) / span * A.w; }
      ctx.strokeStyle = 'rgba(141,153,171,.4)'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(A.x, mid); ctx.lineTo(A.x + A.w, mid); ctx.moveTo(A.x, A.y); ctx.lineTo(A.x, A.y + A.h); ctx.stroke();
      label(ctx, '+U', A.x - 4, mid - amp, { align: 'right', size: 10, color: MUTED });
      label(ctx, '−U', A.x - 4, mid + amp, { align: 'right', size: 10, color: MUTED });
      label(ctx, 't', A.x + A.w + 4, mid + 10, { align: 'left', size: 10, color: MUTED });
      ctx.beginPath();
      var N = 400;
      for (var i = 0; i <= N; i++) {
        var t = t0 + span * i / N, y = mid - D.sq(o.f * t + 0.25) * amp;
        if (i) ctx.lineTo(X(t), y); else ctx.moveTo(X(t), y);
      }
      ctx.strokeStyle = FE_COL; ctx.lineWidth = 1.6; ctx.stroke();
      run.crossings.forEach(function (c, j) {
        if (c.t < t0 - 1e-15 || c.t > t0 + span || j >= o.nDone) return;
        ctx.fillStyle = c.dE > 0 ? V_COL : POS;
        ctx.beginPath(); ctx.arc(X(c.t), mid - Math.sign(c.u) * amp, 3.5, 0, 7); ctx.fill();
      });
      ctx.strokeStyle = FB_COL; ctx.lineWidth = 1.2;
      ctx.beginPath(); ctx.moveTo(X(o.t), A.y); ctx.lineTo(X(o.t), A.y + A.h); ctx.stroke();
      label(ctx, '● 减速', A.x + A.w, G.y + 12, { align: 'right', size: 10, color: POS });
      label(ctx, '● 加速', A.x + A.w - 46, G.y + 12, { align: 'right', size: 10, color: V_COL });
    }
    // Ek-t：台阶状上升，虚线为 Ekmax = q²B²R²/(2m)
    function graphE(G, o) {
      var A = graphBox(G, '动能 Ek-t'), run = o.run, tE = Math.max(run.tEnd, run.T / 2), eMax = Math.max(o.ekMax, run.ek) * 1.08;
      function X(t) { return A.x + t / tE * A.w; }
      function Y(e) { return A.y + A.h - e / eMax * A.h; }
      ctx.strokeStyle = 'rgba(141,153,171,.4)'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(A.x, A.y); ctx.lineTo(A.x, A.y + A.h); ctx.lineTo(A.x + A.w, A.y + A.h); ctx.stroke();
      ctx.setLineDash([4, 4]); ctx.strokeStyle = FB_COL;
      ctx.beginPath(); ctx.moveTo(A.x, Y(o.ekMax)); ctx.lineTo(A.x + A.w, Y(o.ekMax)); ctx.stroke(); ctx.setLineDash([]);
      label(ctx, 'Ekmax = ' + D.fmtEnergy(o.ekMax), A.x + 6, Y(o.ekMax) - 8, { align: 'left', size: 10, color: FB_COL });
      label(ctx, 't', A.x + A.w + 4, A.y + A.h, { align: 'left', size: 10, color: MUTED });
      ctx.beginPath(); ctx.moveTo(X(0), Y(0));
      var ek = 0;
      run.crossings.forEach(function (c, j) {
        if (j >= o.nDone || c.t > o.t + 1e-15) return;
        ctx.lineTo(X(c.t), Y(ek)); ctx.lineTo(X(c.t), Y(c.ek)); ek = c.ek;
      });
      ctx.lineTo(X(Math.min(o.t, run.tEnd)), Y(ek));
      ctx.strokeStyle = POS; ctx.lineWidth = 1.8; ctx.stroke();
      label(ctx, D.fmtEnergy(ek), X(Math.min(o.t, run.tEnd)) + 4, Y(ek) - 9, { align: Math.min(o.t, run.tEnd) / tE > 0.7 ? 'right' : 'left', size: 10, color: POS });
    }

    return { resize: resize, drawSelector: drawSelector, drawSpectro: drawSpectro, drawCyclo: drawCyclo, geo: function () { return geo; }, isNarrow: function () { return narrow; } };
  }

  window.SpectroDraw = { View: View, frame: frame, speedColor: speedColor, ION_COLS: ION_COLS, COLORS: { POS: POS, NEG: NEG, ALT: ALT, V: V_COL, FB: FB_COL, FE: FE_COL } };
})();
