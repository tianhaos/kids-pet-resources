// 串联和并联电路绘图：网格电路板上画电路图符号（电源、开关、小灯泡、电流表、电压表、导线）、灯泡发光、电流（或自由电子）流动、电表表盘读数
(function () {
  var Cc = window.Circuit, COLS = Cc.COLS, ROWS = Cc.ROWS;
  var TAU = Math.PI * 2;
  var C = { text: '#e6ebf2', muted: '#8d99ab', line: '#2a3446', panel: '#111723', accent: '#ffc94a', wire: '#c8d2e0',
    amm: '#4fc3f7', volt: '#7ee081', red: '#ff6b6b', electron: '#4fc3f7' };
  var SYM = { lamp: 0.19, switch: 0.24, battery: 0.16, amm: 0.16, volt: 0.16, wire: 0 };   // 符号占边长的一半（以 u 为单位）

  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }

  function CircuitDraw(canvas) {
    var ctx = canvas.getContext('2d'), W = 0, H = 0, dpr = 1, G = null, extra = 0;
    var flow = {};          // 每个元件上电流点走过的路程（px）

    function resize(w, h) {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      W = w; H = h;
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
      canvas.style.width = w + 'px'; canvas.style.height = h + 'px';
      layout();
    }
    function layout() {
      var narrow = W <= 760;
      var top = narrow ? 92 : 56, bottom = narrow ? 126 : 132;
      // 竖长的窄屏：整块电路板顺时针转 90° 画（列变成行），格子能大一些
      var rot = narrow && H - top - bottom > W * 1.15, nx = rot ? ROWS : COLS, ny = rot ? COLS : ROWS;
      // extra：第 0 行有电表时，读数框要伸到网格上方（转 90° 后是右侧）
      var ex = rot ? extra : 0, ey = rot ? 0 : extra;
      var u = Math.min((W - 40) / (nx - 1 + 0.5 + ex), (H - top - bottom) / (ny - 1 + 0.5 + ey), 150);
      u = Math.max(u, 36);
      G = { u: u, rot: rot, ox: (W - u * (nx - 1 + ex)) / 2, oy: top + ey * u + Math.max(0, (H - top - bottom - u * (ny - 1 + ey)) / 2) };
    }
    function relayout(st) {
      var e = 0;
      if (st.showRead) Object.keys(st.circ.parts).forEach(function (k) {
        var t = st.circ.parts[k].t;
        if ((t === 'amm' || t === 'volt') && k[0] === 'h' && Cc.ends(k)[0][1] === 0) e = 0.85;
      });
      if (e !== extra) { extra = e; layout(); }
    }
    function P(c, r) { return G.rot ? [G.ox + (ROWS - 1 - r) * G.u, G.oy + c * G.u] : [G.ox + c * G.u, G.oy + r * G.u]; }
    function sv(v) { return G.rot ? [-v[1], v[0]] : v; }      // 网格方向 → 屏幕方向
    function geo(key) {
      var e = Cc.ends(key), a = P(e[0][0], e[0][1]), b = P(e[1][0], e[1][1]), dir = [(b[0] - a[0]) / G.u, (b[1] - a[1]) / G.u];
      return { a: a, b: b, m: [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2], h: key[0] === 'h', sh: Math.abs(dir[1]) < 0.5,
        dir: dir, ang: Math.atan2(dir[1], dir[0]), c: e[0][0], r: e[0][1] };
    }

    function font(px, w) { ctx.font = (w || '') + ' ' + Math.round(px) + 'px -apple-system, "PingFang SC", "Microsoft YaHei", sans-serif'; }
    function text(s, x, y, col, align, px, w) {
      font(px, w); ctx.fillStyle = col; ctx.textAlign = align || 'center'; ctx.textBaseline = 'middle'; ctx.fillText(s, x, y);
    }
    function line(x1, y1, x2, y2) { ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke(); }
    function rrect(x, y, w, h, r) {
      ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r);
      ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
    }

    // ---------- 元件符号（在局部坐标里画：a 端在原点，b 端在 (u, 0)） ----------
    function drawPart(key, part, st, info) {
      var g = geo(key), u = G.u, half = u / 2, s = SYM[part.t] * u;
      var hot = info.I > Cc.SHORT_I;
      ctx.save();
      ctx.translate(g.a[0], g.a[1]);
      ctx.rotate(g.ang);
      ctx.lineCap = 'round'; ctx.lineJoin = 'round';
      ctx.strokeStyle = hot ? C.red : C.wire; ctx.lineWidth = Math.max(2, u * 0.022);
      if (part.t === 'wire') { line(0, 0, u, 0); ctx.restore(); return; }
      line(0, 0, half - s, 0); line(half + s, 0, u, 0);
      var lw = ctx.lineWidth;
      if (part.t === 'lamp') {
        var r = s, lt = info.lamp;
        if (part.out) {
          ctx.setLineDash([4, 4]); ctx.strokeStyle = C.muted; ctx.beginPath(); ctx.arc(half, 0, r, 0, TAU); ctx.stroke(); ctx.setLineDash([]);
          line(half - s, 0, half - r, 0); line(half + r, 0, half + s, 0);
        } else {
          var b = lt ? lt.b : 0;
          if (b > 0) {
            var R = r * (1.6 + 2.2 * b), gr = ctx.createRadialGradient(half, 0, r * 0.3, half, 0, R);
            gr.addColorStop(0, 'rgba(255,236,170,' + clamp(0.9 * b, 0, 0.95) + ')');
            gr.addColorStop(0.35, 'rgba(255,201,74,' + clamp(0.45 * b, 0, 0.6) + ')');
            gr.addColorStop(1, 'rgba(255,201,74,0)');
            ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(half, 0, R, 0, TAU); ctx.fill();
          }
          ctx.fillStyle = b > 0 ? 'rgba(255,240,190,' + clamp(0.25 + 0.6 * b, 0, 0.9) + ')' : '#0b0f18';
          ctx.beginPath(); ctx.arc(half, 0, r, 0, TAU); ctx.fill();
          ctx.strokeStyle = b > 0 ? C.accent : C.wire; ctx.stroke();
          var d = r * 0.707;
          ctx.strokeStyle = b > 0 ? '#8a5a00' : C.wire;
          line(half - d, -d, half + d, d); line(half - d, d, half + d, -d);
        }
      } else if (part.t === 'switch') {
        var x1 = half - s, x2 = half + s, rr = Math.max(3, u * 0.032);
        ctx.fillStyle = '#0b0f18'; ctx.lineWidth = Math.max(1.5, lw * 0.75);
        ctx.beginPath(); ctx.arc(x1, 0, rr, 0, TAU); ctx.fill(); ctx.stroke();
        ctx.beginPath(); ctx.arc(x2, 0, rr, 0, TAU); ctx.fill(); ctx.stroke();
        ctx.lineWidth = lw;
        var ang = part.on ? 0 : -0.5, len = 2 * s;
        // 开关刀片总画在上方/左侧（竖直边旋转后为右侧，统一往外翘）
        ctx.strokeStyle = part.on ? (hot ? C.red : C.wire) : C.accent;
        line(x1, 0, x1 + len * Math.cos(ang), len * Math.sin(ang));
      } else if (part.t === 'battery') {
        // 长线为正极、短粗线为负极；E/1.5 节电池串联
        var n = Math.max(1, Math.round(st.E / Cc.CELL)), gap = u * 0.07, w0 = (n - 1) * gap * 2 + gap;
        var plusA = !part.p, x0 = half - w0 / 2;
        line(half - s, 0, x0, 0); line(x0 + w0, 0, half + s, 0);
        for (var i = 0; i < n; i++) {
          var xl = x0 + i * gap * 2, xs = xl + gap;            // a 端在左
          var xLong = plusA ? xl : xs, xShort = plusA ? xs : xl;
          ctx.lineWidth = lw; line(xLong, -u * 0.15, xLong, u * 0.15);
          ctx.lineWidth = lw * 2.4; line(xShort, -u * 0.075, xShort, u * 0.075);
          if (i < n - 1) { ctx.lineWidth = lw; ctx.setLineDash([2, 3]); line(xs, 0, xs + gap, 0); ctx.setLineDash([]); }
        }
        ctx.lineWidth = lw;
      } else if (part.t === 'amm' || part.t === 'volt') {
        var col = part.t === 'amm' ? C.amm : C.volt, mr = s;
        ctx.fillStyle = '#0b0f18'; ctx.beginPath(); ctx.arc(half, 0, mr, 0, TAU); ctx.fill();
        ctx.strokeStyle = info.meter && (info.meter.rev || info.meter.over) ? C.red : col; ctx.stroke();
      }
      ctx.restore();
      // 直立的文字
      if (part.t === 'amm' || part.t === 'volt') {
        text(part.t === 'amm' ? 'A' : 'V', g.m[0], g.m[1] + 0.5, part.t === 'amm' ? C.amm : C.volt, 'center', u * 0.17, '700');
        polarMarks(g, part, u * (SYM[part.t] + 0.07));
      }
      if (part.t === 'battery') polarMarks(g, part, u * 0.2);
    }
    // “+”“−”标记：放在元件两侧、偏到外面
    function polarMarks(g, part, off) {
      var u = G.u, dirx = g.dir[0], diry = g.dir[1], nx = g.sh ? 0 : 1, ny = g.sh ? -1 : 0, k = u * 0.12;
      var sgn = part.p ? -1 : 1;  // + 在 a 端：位于 m - off
      var px = g.m[0] - sgn * dirx * off + nx * k, py = g.m[1] - sgn * diry * off + ny * k;
      var mx = g.m[0] + sgn * dirx * off + nx * k, my = g.m[1] + sgn * diry * off + ny * k;
      text('+', px, py, C.red, 'center', u * 0.12, '700');
      text('−', mx, my, C.muted, 'center', u * 0.12, '700');
    }

    // ---------- 电流（或自由电子）流动 ----------
    function speed(I) { return G.u * 1.3 * Math.min(1.4, Math.pow(Math.abs(I) / 0.6, 0.5)); }
    function drawFlow(st, dt) {
      if (st.flow === 'off' || !st.sol) return;
      var u = G.u, gap = u / 4, rad = Math.max(2, u * 0.026), el = st.flow === 'electron';
      Object.keys(st.circ.parts).forEach(function (key) {
        var part = st.circ.parts[key], I = st.sol.I[key];
        if (I == null || part.t === 'volt' || Math.abs(I) < 2e-4) { flow[key] = 0; return; }
        flow[key] = ((flow[key] || 0) + speed(I) * dt) % gap;
        var g = geo(key), dir = (I > 0) !== el ? 1 : -1;   // 1：从 a 往 b 走
        var from = dir > 0 ? g.a : g.b, to = dir > 0 ? g.b : g.a, s = SYM[part.t] * u, half = u / 2;
        ctx.fillStyle = Math.abs(I) > Cc.SHORT_I ? C.red : el ? C.electron : C.accent;
        for (var d = flow[key]; d < u; d += gap) {
          if (s && Math.abs(d - half) < s + rad) continue;
          var f = d / u;
          ctx.beginPath(); ctx.arc(from[0] + (to[0] - from[0]) * f, from[1] + (to[1] - from[1]) * f, rad, 0, TAU); ctx.fill();
        }
      });
    }

    // ---------- 电表读数框 ----------
    function boxSide(g) {   // 网格方向，用 sv() 转成屏幕方向
      if (g.h) return g.r === ROWS - 1 ? [0, -1] : g.r >= 3 ? [0, 1] : [0, -1];
      return g.c === 0 ? [1, 0] : g.c <= 2 ? [-1, 0] : [1, 0];
    }
    function boxGeom(g) {
      var u = G.u, side = sv(boxSide(g)), dial = u >= 84;
      var bw = dial ? u * 0.62 : Math.max(u * 0.62, 46), bh = dial ? u * 0.58 : Math.max(u * 0.3, 18), d = u * 0.22;
      var cx = g.m[0] + side[0] * (d + bw / 2), cy = g.m[1] + side[1] * (d + bh / 2);
      if (cx - bw / 2 < 2 || cx + bw / 2 > W - 2 || cy - bh / 2 < (W > 760 ? 48 : 2)) {     // 出了画布就放到另一侧
        side = [-side[0], -side[1]];
        cx = g.m[0] + side[0] * (d + bw / 2); cy = g.m[1] + side[1] * (d + bh / 2);
      }
      return { side: side, cx: cx, cy: cy, bw: bw, bh: bh, dial: dial };
    }
    function drawMeterBox(key, part, m) {
      var g = geo(key), u = G.u, B = boxGeom(g), dial = B.dial, bw = B.bw, bh = B.bh, cx = B.cx, cy = B.cy;
      var x = cx - bw / 2, y = cy - bh / 2, col = part.t === 'amm' ? C.amm : C.volt, warn = m.rev || m.over;
      ctx.fillStyle = 'rgba(11,15,24,0.92)'; ctx.strokeStyle = warn ? C.red : col; ctx.lineWidth = 1;
      rrect(x, y, bw, bh, 5); ctx.fill(); ctx.stroke();
      var unit = part.t === 'amm' ? ' A' : ' V', val = m.v, fs = Math.max(10, u * 0.115);
      var vs = (val < -0.005 ? '−' : '') + Math.abs(val).toFixed(2) + unit;
      if (m.over) vs = '超量程';
      if (dial) {
        // 表盘：0 在左，满偏在右；反接时指针向左打到头
        var ax = cx, ay = y + bh * 0.66, R = bw * 0.27, a0 = Math.PI * 1.17, a1 = Math.PI * 1.83;
        ctx.strokeStyle = C.muted; ctx.lineWidth = 1;
        ctx.beginPath(); ctx.arc(ax, ay, R, a0, a1); ctx.stroke();
        for (var i = 0; i <= 6; i++) {
          var a = a0 + (a1 - a0) * i / 6, l = i % 3 ? 0.88 : 0.8;
          line(ax + Math.cos(a) * R, ay + Math.sin(a) * R, ax + Math.cos(a) * R * l, ay + Math.sin(a) * R * l);
        }
        var f = clamp(val / m.range, -0.12, 1.08), an = a0 + (a1 - a0) * f;
        ctx.strokeStyle = warn ? C.red : C.text; ctx.lineWidth = 1.5;
        line(ax, ay, ax + Math.cos(an) * R * 0.95, ay + Math.sin(an) * R * 0.95);
        ctx.fillStyle = C.text; ctx.beginPath(); ctx.arc(ax, ay, 2, 0, TAU); ctx.fill();
        text(part.n + '  0~' + m.range + unit, cx, y + bh * 0.13, C.muted, 'center', fs * 0.7);
        text(vs, cx, y + bh * 0.85, warn ? C.red : col, 'center', fs, '700');
      } else text(vs, cx, cy + 0.5, warn ? C.red : col, 'center', fs, '700');
    }

    // ---------- 名称 ----------
    function drawName(key, part, st, lamp) {
      var g = geo(key), u = G.u, side = (part.t === 'amm' || part.t === 'volt') && st.showRead ? boxGeom(g).side.map(function (v) { return -v; })
        : sv(g.h ? (g.r === ROWS - 1 ? [0, 1] : [0, -1]) : (g.c >= COLS - 1 ? [-1, 0] : [1, 0]));
      var off = u * (part.t === 'lamp' ? 0.32 : part.t === 'battery' ? 0.36 : 0.28);
      var x = g.m[0] + side[0] * off, y = g.m[1] + side[1] * off, fs = Math.max(11, u * 0.12);
      var name = part.n, sub = '';
      if (part.t === 'battery') sub = st.E + ' V';
      if (part.t === 'lamp') sub = st.showSpec ? Cc.LAMPS[part.spec].U + ' V' : '';
      var col = part.t === 'lamp' && lamp && lamp.on ? C.accent : C.text;
      var align = side[0] > 0 ? 'left' : side[0] < 0 ? 'right' : 'center';
      if (side[0]) x -= side[0] * u * 0.08;
      if (sub && side[1]) {
        var y0 = side[1] < 0 ? y - fs * 1.05 : y;      // 名称在上、规格在下
        text(name, x, y0, col, align, fs, '600');
        text(sub, x, y0 + fs * 1.05, C.muted, align, fs * 0.82);
      } else if (sub) {
        text(name, x, y - fs * 0.5, col, align, fs, '600');
        text(sub, x, y + fs * 0.55, C.muted, align, fs * 0.82);
      } else text(name, x, y, col, align, fs, '600');
    }

    // ---------- 主绘制 ----------
    function draw(st, dt) {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, W, H);
      relayout(st);
      var u = G.u, parts = st.circ.parts, keys = Object.keys(parts), edit = st.tool !== 'hand';
      var lampBy = {}, meterBy = {};
      if (st.ana) { st.ana.lamps.forEach(function (l) { lampBy[l.key] = l; }); st.ana.meters.forEach(function (m) { meterBy[m.key] = m; }); }

      // 网格：编辑时画出所有可放元件的位置
      var c, r;
      ctx.fillStyle = edit ? 'rgba(141,153,171,0.55)' : 'rgba(141,153,171,0.18)';
      for (r = 0; r < ROWS; r++) for (c = 0; c < COLS; c++) { var p = P(c, r); ctx.beginPath(); ctx.arc(p[0], p[1], edit ? 2.2 : 1.4, 0, TAU); ctx.fill(); }
      if (edit) {
        ctx.strokeStyle = 'rgba(141,153,171,0.13)'; ctx.lineWidth = 1; ctx.setLineDash([3, 5]);
        for (r = 0; r < ROWS; r++) for (c = 0; c < COLS; c++) {
          if (c < COLS - 1 && !parts['h,' + c + ',' + r]) { var a = P(c, r), b = P(c + 1, r); line(a[0], a[1], b[0], b[1]); }
          if (r < ROWS - 1 && !parts['v,' + c + ',' + r]) { a = P(c, r); b = P(c, r + 1); line(a[0], a[1], b[0], b[1]); }
        }
        ctx.setLineDash([]);
      }
      // 悬停高亮
      if (st.hover && Cc.validKey(st.hover)) {
        var hg = geo(st.hover);
        ctx.strokeStyle = st.tool === 'erase' ? 'rgba(255,107,107,0.5)' : 'rgba(255,201,74,0.45)'; ctx.lineWidth = u * 0.12; ctx.lineCap = 'round';
        line(hg.a[0], hg.a[1], hg.b[0], hg.b[1]);
      }

      // 先画导线，再画元件（灯光盖在导线上）
      keys.sort(function (x, y) { return (parts[x].t === 'wire' ? 0 : 1) - (parts[y].t === 'wire' ? 0 : 1); });
      keys.forEach(function (k) {
        drawPart(k, parts[k], st, { I: st.sol ? Math.abs(st.sol.I[k] || 0) : 0, lamp: lampBy[k], meter: meterBy[k] });
      });

      // 连接点：三条及以上导线相接处画实心圆点，悬空的线头画空心圈
      var deg = {};
      keys.forEach(function (k) { var e = Cc.ends(k); e.forEach(function (n) { var id = n[0] + ',' + n[1]; deg[id] = (deg[id] || 0) + 1; }); });
      Object.keys(deg).forEach(function (id) {
        var n = id.split(','), p = P(+n[0], +n[1]);
        if (deg[id] >= 3) { ctx.fillStyle = C.wire; ctx.beginPath(); ctx.arc(p[0], p[1], Math.max(3, u * 0.035), 0, TAU); ctx.fill(); }
        else if (deg[id] === 1) { ctx.strokeStyle = C.muted; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(p[0], p[1], Math.max(3, u * 0.03), 0, TAU); ctx.stroke(); }
      });

      drawFlow(st, dt);

      keys.forEach(function (k) {
        var part = parts[k];
        if ((part.t === 'amm' || part.t === 'volt') && st.showRead && meterBy[k]) drawMeterBox(k, part, meterBy[k]);
        if (st.showNames && part.t !== 'wire' && !((part.t === 'amm' || part.t === 'volt') && st.showRead && boxGeom(geo(k)).dial)) drawName(k, part, st, lampBy[k]);
      });

      // 电源短路警示
      if (st.ana && st.ana.status === 'short' && (st.time * 2.5 % 1) < 0.6) {
        var bk = keys.filter(function (k) { return parts[k].t === 'battery'; })[0];
        if (bk) { var bg = geo(bk); ctx.strokeStyle = C.red; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(bg.m[0], bg.m[1], u * 0.25, 0, TAU); ctx.stroke(); }
      }
    }

    // 画布坐标 → 最近的节点和边
    function hit(px, py) {
      var u = G.u, node = nearestNode(px, py, 0.24), edge = null, best = u * 0.3;
      for (var rr = 0; rr < ROWS; rr++) for (var cc = 0; cc < COLS; cc++) {
        ['h', 'v'].forEach(function (t) {
          var key = t + ',' + cc + ',' + rr;
          if (!Cc.validKey(key)) return;
          var g = geo(key), dx = px - g.a[0], dy = py - g.a[1];
          var along = dx * g.dir[0] + dy * g.dir[1], perp = Math.abs(dx * g.dir[1] - dy * g.dir[0]);
          if (along < u * 0.15 || along > u * 0.85) return;
          if (perp < best) { best = perp; edge = key; }
        });
      }
      return { node: node, edge: edge };
    }
    function nearestNode(px, py, tol) {
      var best = G.u * (tol || 0.4), n = null;
      for (var r = 0; r < ROWS; r++) for (var c = 0; c < COLS; c++) {
        var p = P(c, r), d = Math.hypot(px - p[0], py - p[1]);
        if (d < best) { best = d; n = [c, r]; }
      }
      return n;
    }

    return { resize: resize, draw: draw, hit: hit, nearestNode: nearestNode, unit: function () { return G.u; } };
  }

  window.CircuitDraw = CircuitDraw;
})();
