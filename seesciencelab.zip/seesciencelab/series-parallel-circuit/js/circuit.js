// 串联和并联电路：网格电路板的数据结构、节点电压法求解、电路分析（通路/断路/短路、串并联关系、电表测量对象）
// 不碰 DOM。单位：V、A、Ω、W。
(function () {
  var COLS = 7, ROWS = 5;                 // 网格节点数：列 c = 0..6，行 r = 0..4
  var R_WIRE = 1e-5, R_AMM = 1e-4, R_VOLT = 1e7, R_CELL = 2e-3;   // 导线、电流表、电压表内阻，每节电池内阻
  var CELL = 1.5;                          // 一节干电池 1.5 V
  var SHORT_I = 5;                         // 电源电流超过 5 A 视为电源短路
  var LAMPS = {                            // 小灯泡规格（电阻按额定值算，忽略温度对灯丝电阻的影响）
    a: { name: '2.5 V 0.3 A', U: 2.5, I: 0.3 },
    b: { name: '3.8 V 0.3 A', U: 3.8, I: 0.3 }
  };
  Object.keys(LAMPS).forEach(function (k) { var s = LAMPS[k]; s.R = s.U / s.I; s.P = s.U * s.I; });
  var PREFIX = { lamp: 'L', switch: 'S', battery: 'E', amm: 'A', volt: 'V' };
  var POLAR = { battery: 1, amm: 1, volt: 1 };

  // 边的键：'h,c,r' 连接 (c,r)-(c+1,r)；'v,c,r' 连接 (c,r)-(c,r+1)。a 端是左/上端，b 端是右/下端
  function ends(key) {
    var p = key.split(','), c = +p[1], r = +p[2];
    return p[0] === 'h' ? [[c, r], [c + 1, r]] : [[c, r], [c, r + 1]];
  }
  function nodeId(c, r) { return r * COLS + c; }
  function edgeKey(c1, r1, c2, r2) {
    if (r1 === r2 && Math.abs(c1 - c2) === 1) return 'h,' + Math.min(c1, c2) + ',' + r1;
    if (c1 === c2 && Math.abs(r1 - r2) === 1) return 'v,' + c1 + ',' + Math.min(r1, r2);
    return null;
  }
  function validKey(key) {
    var e = ends(key);
    return /^[hv],\d+,\d+$/.test(key) && e[1][0] < COLS && e[1][1] < ROWS;
  }

  // ---------- 元件 ----------
  // part：{ t: wire|lamp|switch|battery|amm|volt, n: 名称, on: 开关闭合, spec: 'a'|'b', out: 灯泡已取下, p: 0 正极/“+”接线柱在 a 端，1 在 b 端 }
  function create() { return { parts: {} }; }
  function nextName(circ, t) {
    var pre = PREFIX[t]; if (!pre) return '';
    var used = {};
    Object.keys(circ.parts).forEach(function (k) { used[circ.parts[k].n] = 1; });
    for (var i = 1; ; i++) if (!used[pre + i]) return pre + i;
  }
  function place(circ, key, t, opt) {
    var part = { t: t };
    if (t === 'switch') part.on = false;
    if (t === 'lamp') { part.spec = 'a'; part.out = false; }
    if (POLAR[t]) part.p = 0;
    for (var k in opt) part[k] = opt[k];
    if (!part.n) part.n = nextName(circ, t);
    circ.parts[key] = part;
    return part;
  }
  function clone(circ) { return JSON.parse(JSON.stringify(circ)); }

  // 预设场景（坐标见 CLAUDE.md）。spec 'diff' 时 L2 换成另一种规格
  function wires(circ, keys) { keys.forEach(function (k) { place(circ, k, 'wire'); }); }
  var SCENES = {
    series: function (c, o) {             // 串联：S、L1、L2
      seriesBase(c, o, {});
    },
    'i-series': function (c, o) {         // 探究串联电路的电流规律：A1、A2、A3 分别在 L1 前、L1 与 L2 之间、L2 后
      seriesBase(c, o, { amm: true });
    },
    'u-series': function (c, o) {         // 探究串联电路的电压规律：V1、V2、V
      seriesBase(c, o, { volt: true });
    },
    parallel: function (c, o) {           // 并联：干路开关 S，支路开关 S1、S2
      parallelBase(c, o, {});
    },
    'i-parallel': function (c, o) { parallelBase(c, o, { amm: true }); },
    'u-parallel': function (c, o) { parallelBase(c, o, { volt: true }); },
    short: function (c, o) {              // 短路：S2 闭合把 L2 短路，S3 闭合把电源短路
      seriesBase(c, o, {});
      wires(c, ['v,4,0', 'v,5,0', 'h,0,3', 'h,0,4']);
      place(c, 'h,4,0', 'switch', { n: 'S2' });
      place(c, 'v,0,3', 'switch', { n: 'S3' });
    },
    free: function (c, o) {               // 自由搭建：只放电源和一个开关
      place(c, 'v,1,3', 'battery', { n: '电源' });
      place(c, 'h,1,2', 'switch', { n: 'S' });
      place(c, 'v,1,2', 'wire');
    }
  };
  function seriesBase(c, o, m) {
    place(c, 'v,1,3', 'battery', { n: '电源' });
    place(c, 'h,1,2', 'switch', { n: 'S', on: true });
    place(c, 'h,2,1', 'lamp', { n: 'L1', spec: 'a' });
    place(c, 'h,4,1', 'lamp', { n: 'L2', spec: o.spec === 'diff' ? 'b' : 'a' });
    wires(c, ['v,1,2', 'v,5,1', 'h,4,4', 'h,3,4', 'h,2,4', 'h,1,4', 'v,5,3']);
    if (m.amm) {
      place(c, 'v,2,1', 'amm', { n: 'A1', p: 1 });
      place(c, 'h,3,1', 'amm', { n: 'A2' });
      place(c, 'v,5,2', 'amm', { n: 'A3' });
    } else wires(c, ['v,2,1', 'h,3,1', 'v,5,2']);
    if (m.volt) {
      wires(c, ['v,2,0', 'v,3,0', 'v,4,0', 'v,5,0', 'h,0,3', 'h,0,4']);
      place(c, 'h,2,0', 'volt', { n: 'V1' });
      place(c, 'h,4,0', 'volt', { n: 'V2' });
      place(c, 'v,0,3', 'volt', { n: 'V' });
    }
  }
  function parallelBase(c, o, m) {
    place(c, 'v,1,3', 'battery', { n: '电源' });
    place(c, 'h,1,2', 'switch', { n: 'S', on: true });
    place(c, 'h,2,1', 'switch', { n: 'S1', on: true });
    place(c, 'h,2,3', 'switch', { n: 'S2', on: true });
    place(c, 'h,3,1', 'lamp', { n: 'L1', spec: 'a' });
    place(c, 'h,3,3', 'lamp', { n: 'L2', spec: o.spec === 'diff' ? 'b' : 'a' });
    wires(c, ['v,1,2', 'v,2,1', 'v,2,2', 'v,5,1', 'v,5,2', 'v,5,3', 'h,4,4', 'h,2,4', 'h,1,4']);
    if (m.amm) {
      place(c, 'h,3,4', 'amm', { n: 'A', p: 1 });
      place(c, 'h,4,1', 'amm', { n: 'A1' });
      place(c, 'h,4,3', 'amm', { n: 'A2' });
    } else wires(c, ['h,3,4', 'h,4,1', 'h,4,3']);
    if (m.volt) {
      wires(c, ['v,3,0', 'v,4,0', 'v,3,2', 'v,4,2', 'h,0,3', 'h,0,4']);
      place(c, 'h,3,0', 'volt', { n: 'V1' });
      place(c, 'h,3,2', 'volt', { n: 'V2' });
      place(c, 'v,0,3', 'volt', { n: 'V' });
    }
  }
  function scene(name, opt) {
    var c = create();
    (SCENES[name] || SCENES.series)(c, opt || {});
    return c;
  }

  // ---------- 求解 ----------
  // ov：{ key: 'open' | 'wire' } 临时把某个元件当作断开或导线（分析电表测量对象时用）
  function elements(circ, E, ov) {
    var els = [];
    Object.keys(circ.parts).forEach(function (key) {
      var part = circ.parts[key], e = ends(key), o = ov && ov[key];
      var el = { key: key, t: part.t, a: nodeId(e[0][0], e[0][1]), b: nodeId(e[1][0], e[1][1]) };
      if (o === 'open') return;
      if (o === 'wire') { el.R = R_WIRE; els.push(el); return; }
      switch (part.t) {
        case 'wire': el.R = R_WIRE; break;
        case 'switch': if (!part.on) return; el.R = R_WIRE; break;
        case 'lamp': if (part.out) return; el.R = LAMPS[part.spec].R; break;
        case 'amm': el.R = R_AMM; break;
        case 'volt': el.R = R_VOLT; break;
        case 'battery': el.E = E; el.R = R_CELL * Math.max(1, Math.round(E / CELL)); el.pos = part.p ? el.b : el.a; break;
        default: return;
      }
      els.push(el);
    });
    return els;
  }

  function uf(n) {
    var p = []; for (var i = 0; i < n; i++) p[i] = i;
    function find(x) { while (p[x] !== x) { p[x] = p[p[x]]; x = p[x]; } return x; }
    return { find: find, union: function (a, b) { p[find(a)] = find(b); } };
  }

  // 高斯消元（列主元）
  function gauss(A, z) {
    var n = z.length;
    for (var i = 0; i < n; i++) {
      var piv = i;
      for (var k = i + 1; k < n; k++) if (Math.abs(A[k][i]) > Math.abs(A[piv][i])) piv = k;
      if (Math.abs(A[piv][i]) < 1e-300) continue;
      var t = A[i]; A[i] = A[piv]; A[piv] = t; t = z[i]; z[i] = z[piv]; z[piv] = t;
      for (k = i + 1; k < n; k++) {
        var f = A[k][i] / A[i][i]; if (!f) continue;
        for (var j = i; j < n; j++) A[k][j] -= f * A[i][j];
        z[k] -= f * z[i];
      }
    }
    var x = new Array(n);
    for (i = n - 1; i >= 0; i--) {
      var s = z[i];
      for (j = i + 1; j < n; j++) s -= A[i][j] * x[j];
      x[i] = Math.abs(A[i][i]) < 1e-300 ? 0 : s / A[i][i];
    }
    return x;
  }

  // 节点电压法：电池用诺顿等效（电导 1/r 并联电流源 E/r）。每个连通块各取一个参考点；不含电池的块电压全为 0
  // 返回 V[node]，I[key]（元件中从 a 端流向 b 端的电流，电池为内部电流），bat（各电池从正极流出的电流）
  function solve(circ, E, ov) {
    var els = elements(circ, E, ov), N = COLS * ROWS, V = new Array(N).fill(0), I = {}, bat = {};
    var U = uf(N);
    els.forEach(function (el) { U.union(el.a, el.b); });
    var groups = {};
    els.forEach(function (el) {
      var g = U.find(el.a);
      (groups[g] = groups[g] || { els: [], nodes: {} }).els.push(el);
      groups[g].nodes[el.a] = groups[g].nodes[el.b] = 1;
    });
    Object.keys(groups).forEach(function (g) {
      var G = groups[g];
      if (!G.els.some(function (el) { return el.E != null; })) return;
      var nodes = Object.keys(G.nodes).map(Number), idx = {};
      nodes.slice(1).forEach(function (nd, i) { idx[nd] = i; });   // nodes[0] 为参考点
      var n = nodes.length - 1, A = [], z = new Array(n).fill(0);
      for (var i = 0; i < n; i++) A.push(new Array(n).fill(0));
      function stamp(p, q, g) {
        var ip = idx[p], iq = idx[q];
        if (ip != null) A[ip][ip] += g;
        if (iq != null) A[iq][iq] += g;
        if (ip != null && iq != null) { A[ip][iq] -= g; A[iq][ip] -= g; }
      }
      G.els.forEach(function (el) {
        stamp(el.a, el.b, 1 / el.R);
        if (el.E != null) {
          var neg = el.pos === el.a ? el.b : el.a, is = el.E / el.R;
          if (idx[el.pos] != null) z[idx[el.pos]] += is;
          if (idx[neg] != null) z[idx[neg]] -= is;
        }
      });
      var x = gauss(A, z);
      nodes.forEach(function (nd) { V[nd] = idx[nd] != null ? x[idx[nd]] : 0; });
    });
    els.forEach(function (el) {
      if (el.E != null) {
        var neg = el.pos === el.a ? el.b : el.a, out = (el.E - (V[el.pos] - V[neg])) / el.R;
        bat[el.key] = out;
        I[el.key] = el.pos === el.b ? out : -out;      // 电池内部电流从负极流向正极
      } else I[el.key] = (V[el.a] - V[el.b]) / el.R;
    });
    return { V: V, I: I, bat: bat };
  }

  function partU(sol, key) { var e = ends(key); return sol.V[nodeId(e[0][0], e[0][1])] - sol.V[nodeId(e[1][0], e[1][1])]; }
  // 电表示数：电流表为从“+”接线柱流入的电流，电压表为“+”接线柱与“−”接线柱的电势差
  function meterValue(part, key, sol) {
    if (part.t === 'amm') { var i = sol.I[key] || 0; return part.p ? -i : i; }
    var u = partU(sol, key); return part.p ? -u : u;
  }
  function ammRange(v) { return Math.abs(v) <= 0.6 ? 0.6 : 3; }
  function voltRange(v) { return Math.abs(v) <= 3 ? 3 : 15; }

  // ---------- 串并联关系：把导线、闭合的开关、电流表看成一点，对灯泡做串并联化简 ----------
  function topology(circ) {
    var U = uf(COLS * ROWS), lamps = [], bats = [];
    Object.keys(circ.parts).forEach(function (key) {
      var part = circ.parts[key], e = ends(key), a = nodeId(e[0][0], e[0][1]), b = nodeId(e[1][0], e[1][1]);
      if (part.t === 'wire' || part.t === 'amm' || (part.t === 'switch' && part.on)) U.union(a, b);
      if (part.t === 'lamp' && !part.out) lamps.push({ key: key, n: part.n, a: a, b: b });
      if (part.t === 'battery') bats.push({ key: key, pos: part.p ? b : a, neg: part.p ? a : b });
    });
    var res = { find: U.find, shorted: [], dangling: [], items: [], expr: null, complex: false, srcShort: false, T: null };
    lamps.forEach(function (l) { l.a = U.find(l.a); l.b = U.find(l.b); });
    if (bats.length !== 1) { res.multi = bats.length > 1; return res; }
    var T = [U.find(bats[0].pos), U.find(bats[0].neg)];
    res.T = T;
    if (T[0] === T[1]) { res.srcShort = true; return res; }
    var items = [];
    lamps.forEach(function (l) {
      if (l.a === l.b) res.shorted.push(l.n);
      else items.push({ a: l.a, b: l.b, ex: { leaf: l.n } });
    });
    var hist = items.slice();
    function deg() {
      var d = {};
      items.forEach(function (it) { d[it.a] = (d[it.a] || 0) + 1; d[it.b] = (d[it.b] || 0) + 1; });
      return d;
    }
    function pinned(nd) { return nd === T[0] || nd === T[1]; }
    function combine(type, x, y) {
      var kids = [];
      [x, y].forEach(function (e) { if (e.type === type) kids = kids.concat(e.kids); else kids.push(e); });
      return { type: type, kids: kids };
    }
    for (var guard = 0; guard < 100; guard++) {
      var d = deg(), changed = false, i, j;
      // 一端悬空的灯泡（所在支路断开）
      for (i = 0; i < items.length; i++) {
        var it = items[i];
        if ((d[it.a] === 1 && !pinned(it.a)) || (d[it.b] === 1 && !pinned(it.b))) {
          res.dangling = res.dangling.concat(leaves(it.ex)); items.splice(i, 1); changed = true; break;
        }
      }
      if (changed) continue;
      // 并联：两端接在同样两点
      for (i = 0; i < items.length && !changed; i++) {
        for (j = i + 1; j < items.length; j++) {
          var p = items[i], q = items[j];
          if ((p.a === q.a && p.b === q.b) || (p.a === q.b && p.b === q.a)) {
            var m = { a: p.a, b: p.b, ex: combine('P', p.ex, q.ex) };
            items.splice(j, 1); items[i] = m; hist.push(m); changed = true; break;
          }
        }
      }
      if (changed) continue;
      // 串联：中间连接点只接这两个用电器
      for (var nd in d) {
        nd = +nd;
        if (d[nd] !== 2 || pinned(nd)) continue;
        var two = items.filter(function (it) { return it.a === nd || it.b === nd; });
        var x = two[0], y = two[1], xo = x.a === nd ? x.b : x.a, yo = y.a === nd ? y.b : y.a;
        if (xo === yo) continue;                      // 两个灯泡首尾相接成环、不接电源，交给悬空判断
        var s = { a: xo, b: yo, ex: combine('S', x.ex, y.ex) };
        items.splice(items.indexOf(y), 1); items[items.indexOf(x)] = s; hist.push(s); changed = true; break;
      }
      if (!changed) break;
    }
    res.items = hist;
    var between = function (it) { return (it.a === T[0] && it.b === T[1]) || (it.a === T[1] && it.b === T[0]); };
    if (items.length === 1 && between(items[0])) res.expr = items[0].ex;
    else if (items.length === 1) res.dangling = res.dangling.concat(leaves(items[0].ex));
    else if (items.length > 1) res.complex = true;
    return res;
  }
  function leaves(ex) { return ex.leaf ? [ex.leaf] : ex.kids.reduce(function (a, k) { return a.concat(leaves(k)); }, []); }
  function sortNames(a) { return a.slice().sort(function (x, y) { return x.localeCompare(y, 'zh', { numeric: true }); }); }
  function relText(ex) {
    if (ex.leaf) return ex.leaf;
    var allLeaf = ex.kids.every(function (k) { return k.leaf; });
    var word = ex.type === 'S' ? '串联' : '并联';
    if (allLeaf) return sortNames(ex.kids.map(function (k) { return k.leaf; })).join('、') + ' ' + word;
    return ex.kids.map(function (k) { return k.leaf ? k.leaf : '（' + relText(k) + '）'; }).join(' 与 ') + ' ' + word;
  }

  // ---------- 分析 ----------
  function analyze(circ, E, sol) {
    var top = topology(circ), parts = circ.parts, keys = Object.keys(parts);
    var batKeys = keys.filter(function (k) { return parts[k].t === 'battery'; });
    var Ibat = batKeys.length ? Math.max.apply(null, batKeys.map(function (k) { return Math.abs(sol.bat[k] || 0); })) : 0;
    var res = { lamps: [], meters: [], notes: [], top: top, Ibat: Ibat };

    // 灯泡
    keys.filter(function (k) { return parts[k].t === 'lamp'; }).forEach(function (k) {
      var part = parts[k], s = LAMPS[part.spec], u = part.out ? 0 : partU(sol, k), i = part.out ? 0 : (sol.I[k] || 0);
      var P = Math.abs(u * i), on = P > s.P * 0.01 && Ibat <= SHORT_I;   // 亮度按实际功率算（以 0.75 W 为 1）
      var why = part.out ? '已取下' : on ? (Math.abs(u) > s.U * 1.3 ? '很亮（超过额定电压）' : '发光') :
        Ibat > SHORT_I ? '不亮（电源短路）' : top.shorted.indexOf(part.n) >= 0 && Ibat > 1e-3 ? '不亮（被短路）' :
        Math.abs(u) < 1e-3 ? '不亮（断路）' : '不亮（电流太小）';
      res.lamps.push({ key: k, n: part.n, spec: part.spec, U: Math.abs(u), I: Math.abs(i), P: P, on: on,
        b: on ? Math.min(1.4, Math.sqrt(P / LAMPS.a.P)) : 0, why: why });
    });
    res.lamps.sort(function (x, y) { return x.n.localeCompare(y.n, 'zh', { numeric: true }); });
    var lit = res.lamps.filter(function (l) { return l.on; });

    // 电路状态
    if (!batKeys.length) { res.status = 'nobat'; res.statusText = '没有电源'; }
    else if (Ibat > SHORT_I) { res.status = 'short'; res.statusText = '电源短路！'; }
    else if (Ibat < 1e-4) { res.status = 'open'; res.statusText = '断路（开路）'; }
    else { res.status = 'closed'; res.statusText = '通路'; }

    // 串并联关系
    if (top.multi) res.rel = '电路中有多个电源，未判断串并联关系';
    else if (top.srcShort) res.rel = '导线直接把电源两极连了起来';
    else if (top.expr) res.rel = top.expr.leaf ? '只有 ' + top.expr.leaf + ' 一个用电器' : relText(top.expr);
    else if (top.complex) res.rel = '复杂连接（不是简单的串联或并联）';
    else res.rel = '';
    res.kind = top.expr && !top.expr.leaf && top.expr.kids.every(function (k) { return k.leaf; }) ? top.expr.type : top.expr && top.expr.leaf ? 'single' : '';

    // 规律验证（纯串联或纯并联且灯都亮）
    var src = batKeys.length === 1 ? Math.abs(partU(sol, batKeys[0])) : 0;
    if ((res.kind === 'S' || res.kind === 'P') && res.status === 'closed') {
      var ls = res.lamps.filter(function (l) { return leaves(top.expr).indexOf(l.n) >= 0; });
      if (ls.every(function (l) { return l.on; })) {
        var Is = ls.map(function (l) { return l.I; }), Us = ls.map(function (l) { return l.U; });
        var sumI = Is.reduce(function (a, b) { return a + b; }, 0), sumU = Us.reduce(function (a, b) { return a + b; }, 0);
        if (res.kind === 'S') res.law = { type: 'S', text: 'I = ' + ls.map(function (l, j) { return fA(Is[j]); }).join(' = ') + '（电流处处相等）', text2: 'U = ' + ls.map(function (l, j) { return fV(Us[j]); }).join(' + ') + ' = ' + fV(sumU) + '（等于电源电压 ' + fV(src) + '）' };
        else res.law = { type: 'P', text: 'I = ' + ls.map(function (l, j) { return fA(Is[j]); }).join(' + ') + ' = ' + fA(sumI) + '（干路电流等于各支路电流之和）', text2: 'U = ' + ls.map(function (l, j) { return fV(Us[j]); }).join(' = ') + '（各支路两端电压相等，等于电源电压）' };
        res.law.names = ls.map(function (l) { return l.n; });
      }
    }

    // 电表
    keys.filter(function (k) { return parts[k].t === 'amm' || parts[k].t === 'volt'; }).forEach(function (k) {
      var part = parts[k], v = meterValue(part, k, sol), m = { key: k, n: part.n, t: part.t, v: v };
      m.range = part.t === 'amm' ? ammRange(v) : voltRange(v);
      m.over = Math.abs(v) > (part.t === 'amm' ? 3 : 15) * 1.02;
      m.rev = v < -(part.t === 'amm' ? 0.005 : 0.02);
      m.what = part.t === 'amm' ? ammTarget(circ, E, sol, k, res, lit) : voltTarget(circ, E, sol, k, res, top, lit);
      res.meters.push(m);
    });
    res.meters.sort(function (x, y) { return x.t === y.t ? x.n.localeCompare(y.n, 'zh', { numeric: true }) : x.t === 'amm' ? -1 : 1; });
    res.meters.forEach(function (m) {
      if (m.rev) res.notes.push(m.n + ' 指针反偏：电流从“−”接线柱流入了，正、负接线柱接反了');
      if (m.over) res.notes.push(m.n + ' 超过最大量程，可能损坏' + (m.t === 'amm' ? '电流表' : '电压表'));
    });
    if (res.status === 'short') res.notes.unshift('电流不经过用电器、直接从电源正极流回负极，电流很大，会烧坏电源和导线，绝对不允许！');
    return res;
  }

  // 电流表测谁：把它断开，看哪些灯的电流变小
  function ammTarget(circ, E, sol, key, res, lit) {
    var probe = solve(circ, E, one(key, 'open')), parts = circ.parts;
    var Ip = Math.max.apply(null, [0].concat(Object.keys(probe.bat).map(function (k) { return Math.abs(probe.bat[k]); })));
    if (res.Ibat > SHORT_I && Ip < SHORT_I) return { text: '直接接在电源两极上，造成电源短路', warn: true };
    var lostOn = [], gainOn = [];
    res.lamps.forEach(function (l) {
      if (parts[l.key].out) return;
      var ip = Math.abs(probe.I[l.key] || 0);
      if (l.on && ip < l.I * 0.5) lostOn.push(l.n);
      if (!l.on && ip * ip * LAMPS[l.spec].R > LAMPS[l.spec].P * 0.01) gainOn.push(l.n);
    });
    if (gainOn.length) return { text: '与 ' + gainOn.join('、') + ' 并联，把它短路了', warn: true };
    if (!lit.length || !lostOn.length) return { text: Math.abs(sol.I[key] || 0) < 1e-4 ? '没有电流通过' : '' };
    if (lostOn.length === lit.length) return { text: res.kind === 'P' || (res.top.expr && res.top.expr.type === 'P') ? '测干路电流' : '测电路中的电流' };
    return { text: '测通过 ' + lostOn.join('、') + ' 的电流' };
  }
  // 电压表测谁：比较它两端所接的点和各灯（组）、电源两端的点
  function voltTarget(circ, E, sol, key, res, top, lit) {
    var e = ends(key), f = top.find, a = f(nodeId(e[0][0], e[0][1])), b = f(nodeId(e[1][0], e[1][1]));
    if (a === b) return { text: '两端接在同一段导线上，示数为 0' };
    var probe = solve(circ, E, one(key, 'wire'));
    var series = res.lamps.some(function (l) { return !l.on && !circ.parts[l.key].out && Math.abs(probe.I[l.key] || 0) > 0.02; });
    if (series) return { text: '串联在电路中：几乎没有电流通过，灯不亮，示数接近电源电压', warn: true };
    function same(p, q) { return (p === a && q === b) || (p === b && q === a); }
    var matched = [];
    top.items.forEach(function (it) { if (same(it.a, it.b)) matched.push(leaves(it.ex)); });
    var isSrc = top.T && same(top.T[0], top.T[1]);
    if (!matched.length) return { text: isSrc ? '测电源两端的电压' : '' };
    // 并联时几盏灯（和电源）两端的电压是同一个：按导线连接的远近，挑离电压表最近的说
    var D = wireDist(circ), va = nodeId(e[0][0], e[0][1]), vb = nodeId(e[1][0], e[1][1]);
    function score(p, q) { return Math.min(D(va, p) + D(vb, q), D(va, q) + D(vb, p)); }
    var all = sortNames(matched.reduce(function (s, g) { g.forEach(function (n) { if (s.indexOf(n) < 0) s.push(n); }); return s; }, []));
    var singles = matched.filter(function (g) { return g.length === 1; }).map(function (g) { return g[0]; });
    var txt;
    if (singles.length) {
      var best = null, bs = Infinity;
      singles.forEach(function (n) {
        var l = res.lamps.filter(function (x) { return x.n === n; })[0], le = ends(l.key);
        var sc = score(nodeId(le[0][0], le[0][1]), nodeId(le[1][0], le[1][1]));
        if (sc < bs) { bs = sc; best = n; }
      });
      if (isSrc) {
        var bk = Object.keys(circ.parts).filter(function (k) { return circ.parts[k].t === 'battery'; })[0], be = ends(bk);
        if (score(nodeId(be[0][0], be[0][1]), nodeId(be[1][0], be[1][1])) < bs) return { text: '测电源两端的电压（也是 ' + all.join('、') + ' 两端的电压）' };
      }
      var others = all.filter(function (n) { return n !== best; });
      txt = '测 ' + best + ' 两端的电压';
      if (others.length) txt += '（' + others.join('、') + ' 与它并联，电压相等' + (isSrc ? '，都等于电源电压' : '') + '）';
      else if (isSrc) txt += '，也是电源两端的电压';
    } else {
      matched.sort(function (x, y) { return x.length - y.length; });
      txt = '测 ' + sortNames(matched[0]).join('、') + ' 两端的总电压' + (isSrc ? '，也是电源两端的电压' : '');
    }
    return { text: txt };
  }

  // 只走导线、闭合的开关、电流表时两个节点之间的边数（不连通为 99）
  function wireDist(circ) {
    var adj = {};
    Object.keys(circ.parts).forEach(function (key) {
      var part = circ.parts[key];
      if (!(part.t === 'wire' || part.t === 'amm' || (part.t === 'switch' && part.on))) return;
      var e = ends(key), a = nodeId(e[0][0], e[0][1]), b = nodeId(e[1][0], e[1][1]);
      (adj[a] = adj[a] || []).push(b); (adj[b] = adj[b] || []).push(a);
    });
    var memo = {};
    return function (p, q) {
      if (p === q) return 0;
      if (!memo[p]) {
        var d = {}, Q = [p]; d[p] = 0;
        while (Q.length) { var x = Q.shift(); (adj[x] || []).forEach(function (y) { if (d[y] == null) { d[y] = d[x] + 1; Q.push(y); } }); }
        memo[p] = d;
      }
      return memo[p][q] != null ? memo[p][q] : 99;
    };
  }
  function one(k, v) { var o = {}; o[k] = v; return o; }
  function fA(v) { return Math.abs(v).toFixed(2) + ' A'; }
  function fV(v) { return Math.abs(v).toFixed(2) + ' V'; }

  window.Circuit = {
    COLS: COLS, ROWS: ROWS, LAMPS: LAMPS, CELL: CELL, SHORT_I: SHORT_I, PREFIX: PREFIX, POLAR: POLAR, SCENES: Object.keys(SCENES),
    ends: ends, nodeId: nodeId, edgeKey: edgeKey, validKey: validKey,
    create: create, place: place, clone: clone, scene: scene, nextName: nextName,
    solve: solve, analyze: analyze, topology: topology, partU: partU, meterValue: meterValue,
    ammRange: ammRange, voltRange: voltRange, relText: relText, leaves: leaves, fA: fA, fV: fV
  };
})();
