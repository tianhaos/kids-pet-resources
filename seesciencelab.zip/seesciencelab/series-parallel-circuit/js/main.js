(function () {
  var Cc = window.Circuit;
  var $ = function (id) { return document.getElementById(id); };
  var qa = function (sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); };
  var NAME = '串联和并联电路';

  var SCENES = {
    series: { name: '串联电路', spec: 'same', note: '用电器逐个顺次连接，电流只有一条路径。断开开关 S 或取下任意一个灯泡，另一个灯泡也不亮；把开关挪到别的位置，它照样控制整个电路。' },
    parallel: { name: '并联电路', spec: 'same', note: '用电器并列连接，电流有两条路径：S 在干路，控制整个电路；S1、S2 在支路，只控制本支路的灯泡。取下 L1，L2 照样发光。' },
    'i-series': { name: '串联电路的电流', spec: 'diff', note: '电流表 A1、A2、A3 分别串联在 L1 前、L1 与 L2 之间、L2 后。换用不同规格的灯泡、改变电源电压，三处电流总相等。' },
    'i-parallel': { name: '并联电路的电流', spec: 'diff', note: '电流表 A 测干路电流，A1、A2 测两条支路的电流。换用不同规格的灯泡，看 I = I₁ + I₂ 是否总成立；断开 S1，看各表示数怎样变。' },
    'u-series': { name: '串联电路的电压', spec: 'diff', note: '电压表 V1、V2 分别并联在 L1、L2 两端，V 并联在电源两端。换用不同规格的灯泡，U₁ 与 U₂ 不一定相等，但 U₁ + U₂ 总等于 U。' },
    'u-parallel': { name: '并联电路的电压', spec: 'diff', note: '电压表 V1、V2 分别并联在 L1、L2 两端，V 并联在电源两端。灯泡规格不同、亮度不同，两端的电压却相等，都等于电源电压。' },
    short: { name: '短路', spec: 'same', note: '闭合 S2：导线把 L2 两端直接连起来，L2 被短路而熄灭，L1 变亮。闭合 S3：导线直接连接电源两极，电源短路——这是绝对不允许的。' },
    free: { name: '自由搭建', spec: 'same', note: '选下方工具栏里的元件，点网格上的空位放置；选“导线”可以从一个点拖到相邻的点连续画线。同一工具再点一次已放的元件：电源和电表对调正负极，灯泡换规格。' }
  };
  var TOOL_NAME = { hand: '操作', wire: '导线', lamp: '小灯泡', switch: '开关', battery: '电源', amm: '电流表', volt: '电压表', erase: '擦除' };

  var state = {
    scene: 'series', E: 3, spec: 'same', flow: 'current', showRead: true, showNames: true, showSpec: false,
    tool: 'hand', circ: null, sol: null, ana: null, hover: null, time: 0, edited: false
  };

  var stage = $('stage'), canvas = $('circuit'), panel = $('panel');
  var view = window.CircuitDraw(canvas);

  function setSeg(attr, val) { qa('[data-' + attr + ']').forEach(function (b) { b.classList.toggle('on', b.dataset[attr] === String(val)); }); }

  // ---------- 电路 ----------
  function loadScene(name) {
    state.scene = SCENES[name] ? name : 'series';
    state.spec = SCENES[state.scene].spec;
    state.circ = Cc.scene(state.scene, { spec: state.spec });
    state.edited = false;
    update();
  }
  function applySpec() {
    var lamps = Object.keys(state.circ.parts).map(function (k) { return state.circ.parts[k]; }).filter(function (p) { return p.t === 'lamp'; });
    lamps.sort(function (x, y) { return x.n.localeCompare(y.n, 'zh', { numeric: true }); });
    lamps.forEach(function (p, i) { p.spec = state.spec === 'diff' && i % 2 ? 'b' : 'a'; });
  }
  function update() {
    state.sol = Cc.solve(state.circ, state.E);
    state.ana = Cc.analyze(state.circ, state.E, state.sol);
    var specs = {};
    Object.keys(state.circ.parts).forEach(function (k) { var p = state.circ.parts[k]; if (p.t === 'lamp') specs[p.spec] = 1; });
    state.showSpec = Object.keys(specs).length > 1;
    syncPanel();
  }

  // 点一下某条边：按当前工具操作
  function applyTool(key) {
    var parts = state.circ.parts, part = parts[key], t = state.tool;
    if (t === 'hand') {
      if (!part) return;
      if (part.t === 'switch') { part.on = !part.on; Analytics.track(NAME, part.on ? '闭合开关' : '断开开关', part.n); }
      else if (part.t === 'lamp') { part.out = !part.out; Analytics.track(NAME, part.out ? '取下灯泡' : '装上灯泡', part.n); }
      else if (Cc.POLAR[part.t]) { part.p = part.p ? 0 : 1; Analytics.track(NAME, '对调正负极', TOOL_NAME[part.t]); }
      else return;
    } else if (t === 'erase') {
      if (!part) return;
      delete parts[key];
    } else if (part && part.t === t) {
      if (Cc.POLAR[t]) part.p = part.p ? 0 : 1;
      else if (t === 'lamp') { part.spec = part.spec === 'a' ? 'b' : 'a'; part.out = false; }
      else if (t === 'switch') part.on = !part.on;
      else return;
    } else {
      if (part) delete parts[key];
      Cc.place(state.circ, key, t, t === 'switch' ? { on: true } : null);
      Analytics.track(NAME, '放置元件', TOOL_NAME[t]);
    }
    if (t !== 'hand') state.edited = true;
    update();
  }

  // ---------- 指针：点击操作，“导线”拖动连续画线，“擦除”拖动连续擦 ----------
  var drag = null;
  function pos(e) { var r = canvas.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; }
  canvas.addEventListener('pointerdown', function (e) {
    var p = pos(e), h = view.hit(p[0], p[1]);
    drag = { x: p[0], y: p[1], edge: h.edge, node: state.tool === 'wire' ? h.node : null, moved: false, id: e.pointerId };
    if (state.tool === 'wire' || state.tool === 'erase') { try { canvas.setPointerCapture(e.pointerId); } catch (err) {} }
    state.hover = h.edge;
  });
  canvas.addEventListener('pointermove', function (e) {
    var p = pos(e), h = view.hit(p[0], p[1]);
    state.hover = state.tool === 'hand' && !(h.edge && state.circ.parts[h.edge] && /switch|lamp|battery|amm|volt/.test(state.circ.parts[h.edge].t)) ? null : h.edge;
    canvas.style.cursor = state.hover ? 'pointer' : 'default';
    if (!drag) return;
    if (Math.hypot(p[0] - drag.x, p[1] - drag.y) > view.unit() * 0.2) drag.moved = true;
    if (state.tool === 'wire' && drag.node) {
      var n = view.nearestNode(p[0], p[1]);
      if (n && (n[0] !== drag.node[0] || n[1] !== drag.node[1])) {
        var key = Cc.edgeKey(drag.node[0], drag.node[1], n[0], n[1]);
        if (key) {
          if (!state.circ.parts[key]) { Cc.place(state.circ, key, 'wire'); state.edited = true; update(); }
          drag.node = n;
        } else if (Math.abs(n[0] - drag.node[0]) + Math.abs(n[1] - drag.node[1]) > 1) drag.node = n;
      }
    } else if (state.tool === 'erase' && drag.moved && h.edge && state.circ.parts[h.edge]) {
      delete state.circ.parts[h.edge]; state.edited = true; update();
    }
  });
  function up(e) {
    if (!drag) return;
    var d = drag; drag = null;
    if (!d.moved && d.edge) applyTool(d.edge);
    if (e.pointerType !== 'mouse') state.hover = null;
  }
  canvas.addEventListener('pointerup', up);
  canvas.addEventListener('pointercancel', function () { drag = null; state.hover = null; });
  canvas.addEventListener('pointerleave', function () { if (!drag) state.hover = null; });

  // ---------- 面板控件 ----------
  qa('[data-tool]').forEach(function (b) {
    b.addEventListener('click', function () { setTool(b.dataset.tool); Analytics.track(NAME, '工具', TOOL_NAME[state.tool]); });
  });
  function setTool(t) {
    state.tool = TOOL_NAME[t] ? t : 'hand';
    setSeg('tool', state.tool);
    canvas.style.touchAction = state.tool === 'hand' ? 'pan-y' : 'none';
    $('toolNote').textContent = toolNote();
  }
  function toolNote() {
    switch (state.tool) {
      case 'hand': return '点开关：断开 / 闭合；点灯泡：取下 / 装上；点电源或电表：对调正负极';
      case 'wire': return '点空位放一段导线，或从一个点拖到相邻的点连续画线';
      case 'erase': return '点元件或导线把它去掉（可以拖动连续擦）';
      default: return '点网格上的空位放' + TOOL_NAME[state.tool] + (Cc.POLAR[state.tool] ? '；再点一次对调正负极' : state.tool === 'lamp' ? '；再点一次换规格' : '');
    }
  }
  qa('[data-scene]').forEach(function (b) {
    b.addEventListener('click', function () { loadScene(b.dataset.scene); Analytics.track(NAME, '场景', SCENES[state.scene].name); });
  });
  $('resetBtn').addEventListener('click', function () { loadScene(state.scene); });
  $('clearBtn').addEventListener('click', function () {
    state.circ = Cc.scene('free'); state.scene = 'free'; state.edited = false; setTool('lamp'); update();
    Analytics.track(NAME, '清空电路');
  });
  qa('[data-e]').forEach(function (b) {
    b.addEventListener('click', function () { state.E = +b.dataset.e; update(); Analytics.track(NAME, '电源电压', state.E + ' V'); });
  });
  qa('[data-spec]').forEach(function (b) {
    b.addEventListener('click', function () { state.spec = b.dataset.spec; applySpec(); update(); Analytics.track(NAME, '灯泡规格', state.spec); });
  });
  qa('[data-flow]').forEach(function (b) {
    b.addEventListener('click', function () { state.flow = b.dataset.flow; setSeg('flow', state.flow); syncFlowNote(); Analytics.track(NAME, '流动显示', state.flow); });
  });
  $('showRead').addEventListener('change', function () { state.showRead = $('showRead').checked; });
  $('showNames').addEventListener('change', function () { state.showNames = $('showNames').checked; });
  function syncFlowNote() {
    $('flowNote').textContent = state.flow === 'electron'
      ? '金属导线中定向移动的是带负电的自由电子，它的移动方向与电流方向相反（在电源外部从负极流向正极）。'
      : state.flow === 'current' ? '规定正电荷定向移动的方向为电流方向：在电源外部，电流从电源正极经过用电器流向负极。' : '';
  }

  // ---------- 读数 ----------
  function esc(s) { return String(s).replace(/[&<>]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]; }); }
  function syncPanel() {
    var a = state.ana, sc = SCENES[state.scene];
    setSeg('scene', state.scene); setSeg('e', state.E); setSeg('spec', state.spec); setSeg('flow', state.flow);
    $('rStatus').textContent = a.statusText;
    $('rStatus').className = 'st ' + a.status;
    $('rScene').textContent = sc.name + (state.edited ? '（已改动）' : '');
    $('rRel').textContent = a.rel ? a.rel + (a.kind === 'S' ? '：电流只有一条路径' : a.kind === 'P' ? '：电流有多条路径' : '') : '';
    $('rRel').hidden = !a.rel;
    $('rLaw').innerHTML = a.law ? '<b>' + (a.law.type === 'S' ? '串联' : '并联') + '</b> ' + esc(a.law.text) + '<br>' + esc(a.law.text2) : '';
    $('rLaw').hidden = !a.law;
    $('rNotes').innerHTML = a.notes.map(function (n) { return '<li>' + esc(n) + '</li>'; }).join('');
    $('rNotes').hidden = !a.notes.length;

    $('lampTable').innerHTML = '<thead><tr><th>灯泡</th><th>状态</th><th>U</th><th>I</th></tr></thead><tbody>' +
      (a.lamps.length ? a.lamps.map(function (l) {
        return '<tr class="' + (l.on ? 'on' : '') + '"><td>' + esc(l.n) + ' <small>' + Cc.LAMPS[l.spec].U + ' V</small></td><td>' + esc(l.why) + '</td><td>' +
          l.U.toFixed(2) + ' V</td><td>' + l.I.toFixed(2) + ' A</td></tr>';
      }).join('') : '<tr><td colspan="4" class="muted">电路中没有灯泡</td></tr>') + '</tbody>';
    $('meterList').innerHTML = a.meters.map(function (m) {
      var unit = m.t === 'amm' ? ' A' : ' V';
      return '<li class="' + m.t + (m.rev || m.over || (m.what && m.what.warn) ? ' warn' : '') + '"><b>' + esc(m.n) + '</b><span class="v">' +
        (m.v < -0.005 ? '−' : '') + Math.abs(m.v).toFixed(2) + unit + '</span><small>量程 0~' + m.range + unit + '</small>' +
        (m.what && m.what.text ? '<p>' + esc(m.what.text) + '</p>' : '') + '</li>';
    }).join('');
    $('meterSec').hidden = !a.meters.length;
    $('sceneNote').textContent = sc.note;
  }

  // ---------- 面板开合 ----------
  $('panelToggle').addEventListener('click', function () { panel.classList.toggle('collapsed'); });
  if (window.matchMedia('(max-width: 760px)').matches) panel.classList.add('collapsed');
  if (window.matchMedia('(max-width: 640px)').matches) $('hint').hidden = true;

  // ---------- 尺寸与主循环 ----------
  function resize() { view.resize(stage.clientWidth, stage.clientHeight); }
  new ResizeObserver(resize).observe(stage);
  resize();

  // 支持 ?scene=…、&E=1.5|3|4.5、&spec=same|diff、&flow=current|electron|off、&tool=…、&close=S2,S3、&open=S1、&out=L1、&read=0、&names=0
  var qs = new URLSearchParams(location.search);
  loadScene(qs.get('scene') || 'series');
  if (['1.5', '3', '4.5'].indexOf(qs.get('E')) >= 0) state.E = +qs.get('E');
  if (/^(same|diff)$/.test(qs.get('spec') || '')) { state.spec = qs.get('spec'); applySpec(); }
  if (/^(current|electron|off)$/.test(qs.get('flow') || '')) state.flow = qs.get('flow');
  function byName(list, fn) {
    (list || '').split(',').filter(Boolean).forEach(function (n) {
      Object.keys(state.circ.parts).forEach(function (k) { if (state.circ.parts[k].n === n) fn(state.circ.parts[k]); });
    });
  }
  byName(qs.get('close'), function (p) { if (p.t === 'switch') p.on = true; });
  byName(qs.get('open'), function (p) { if (p.t === 'switch') p.on = false; });
  byName(qs.get('out'), function (p) { if (p.t === 'lamp') p.out = true; });
  if (qs.get('read') === '0') state.showRead = false;
  if (qs.get('names') === '0') state.showNames = false;
  $('showRead').checked = state.showRead; $('showNames').checked = state.showNames;
  setTool(qs.get('tool') || (state.scene === 'free' ? 'lamp' : 'hand'));
  syncFlowNote();
  update();

  var lastT = performance.now();
  function frame(t) {
    var dt = Math.min((t - lastT) / 1000, 0.1);
    lastT = t;
    state.time += dt;
    view.draw(state, dt);
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // 调试用
  window.__model = { state: state, view: view, Circuit: Cc, load: loadScene, apply: applyTool, setTool: setTool, update: update };
})();
