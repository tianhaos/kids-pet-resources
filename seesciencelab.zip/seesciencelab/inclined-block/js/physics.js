/* 沿坡向下为正，SI单位；静止与滑动的分段解析推进。 */
(function(){
 const g=9.8;
 function forces(s){
  const t=s.angle*Math.PI/180,N=s.mass*g*Math.cos(t),P=s.mass*g*Math.sin(t);
  const staticOK=P<=s.mus*N+1e-10;
  let f=Math.abs(s.v)<1e-10&&staticOK?-P:-Math.sign(s.v||1)*s.muk*N;
  return {N,P,f,a:(P+f)/s.mass,G:s.mass*g,staticOK,critical:Math.atan(s.mus)*180/Math.PI};
 }
 function step(s,dt){
  const elapsed=dt;let r=forces(s),a=r.a;
  if(s.v*a<0&&-s.v/a<=dt){
   const stop=-s.v/a;s.x+=s.v*stop+.5*a*stop*stop;s.v=0;dt-=stop;r=forces(s);a=r.a;
  }
  s.x+=s.v*dt+.5*a*dt*dt;s.v+=a*dt;s.time+=elapsed;
 }
 window.Incline={g,forces,step};
})();
