(function () {
  const $ = id => document.getElementById(id);
  const query = new URLSearchParams(location.search);
  const state = { angle: 25, mass: 2, mus: .5, muk: .3, scene: 'rest', v: 0, x: 0, time: 0, playing: false, components: false };
  const fields = { angle: [0, '°'], mass: [1, ' kg'], mus: [2, ''], muk: [2, ''] };
  const presets = document.querySelectorAll('[data-scene]');
  const track = (action, label) => window.Analytics && Analytics.track('受力分析与斜面物块', action, label);

  for (const key of Object.keys(fields)) {
    const value = Number(query.get(key));
    if (query.has(key) && Number.isFinite(value)) state[key] = Math.max(+$(key).min, Math.min(+$(key).max, value));
  }
  state.muk = Math.min(state.muk, state.mus);
  const play = $('play'), playText = $('playText');
  const threshold = document.querySelector('.threshold-track');
  const motion = document.querySelector('.motion-state');

  function syncPlay() {
    play.firstElementChild.textContent = state.playing ? 'Ⅱ' : '▶';
    playText.textContent = state.playing ? '暂停' : state.time ? '继续运动' : '开始运动';
  }

  function reset() {
    state.v = state.scene === 'up' ? -3 : state.scene === 'slide' ? 3 : 0;
    state.x = state.time = 0;
    state.playing = false;
    syncPlay();
  }
  function sync() {
    for (const [key, [digits, unit]] of Object.entries(fields)) {
      $(key).value = state[key];
      $(key + 'Value').value = state[key].toFixed(digits) + unit;
    }
    presets.forEach(button => button.setAttribute('aria-pressed', button.dataset.scene === state.scene));
  }
  function setScene(scene) {
    state.scene = ['rest', 'slide', 'up'].includes(scene) ? scene : 'rest';
    reset();
    sync();
  }
  setScene(query.get('scene'));
  presets.forEach(button => button.onclick = () => {
    setScene(button.dataset.scene);
    track('场景', state.scene);
  });
  for (const key of Object.keys(fields)) {
    $(key).oninput = () => {
      state[key] = +$(key).value;
      if (key === 'muk') state.mus = Math.max(state.mus, state.muk);
      else state.muk = Math.min(state.muk, state.mus);
      reset();
      sync();
      track('参数', key);
    };
  }
  play.onclick = () => {
    state.playing = !state.playing;
    syncPlay();
    track('播放', String(state.playing));
  };
  $('reset').onclick = reset;
  $('components').onchange = () => state.components = $('components').checked;

  const panel = $('panel'), toggle = $('panelToggle');
  panel.classList.add('collapsed');
  function showPanel(open) {
    panel.classList.toggle('collapsed', !open);
    toggle.setAttribute('aria-expanded', open);
    toggle.textContent = open ? '收起设置' : '实验设置';
  }
  toggle.onclick = () => showPanel(panel.classList.contains('collapsed'));
  panel.addEventListener('keydown', event => {
    if (event.key === 'Escape' && toggle.offsetWidth) {
      showPanel(false);
      toggle.focus();
    }
  });

  const canvas = $('canvas');
  let geometry, pointer;
  function point(event) {
    const bounds = canvas.getBoundingClientRect();
    return { x: event.clientX - bounds.left, y: event.clientY - bounds.top };
  }
  function hitsHandle({ x, y }) {
    return geometry && Math.hypot(x - geometry.end.x, y - geometry.end.y) <= 26;
  }
  canvas.onpointerdown = event => {
    if (pointer !== undefined || !hitsHandle(point(event))) return;
    pointer = event.pointerId;
    state.drag = true;
    canvas.setPointerCapture(pointer);
    canvas.style.cursor = 'grabbing';
  };
  let pivot;
  canvas.onpointermove = event => {
    const pos = point(event);
    if (pointer !== event.pointerId) {
      state.hover = hitsHandle(pos);
      canvas.style.cursor = state.hover ? 'grab' : '';
      return;
    }
    state.angle = Math.round(Math.max(0, Math.min(60, Math.atan2(pivot.oy - pos.y, pos.x - pivot.ox) * 180 / Math.PI)));
    reset();
    sync();
  };
  canvas.onpointerleave = () => { state.hover = false; };
  canvas.onlostpointercapture = () => {
    track('拖动', '倾角');
    pointer = undefined;
    state.drag = state.hover = false;
    canvas.style.cursor = '';
  };

  function show(id, value) {
    const el = $(id);
    if (el.textContent !== value) el.textContent = value;
  }
  function number(value, places = 2) {
    return (Math.abs(value) < .5 * 10 ** -places ? 0 : value).toFixed(places);
  }
  let last, thresholdAngle, thresholdLimit;
  function frame(now) {
    if (state.playing && last !== undefined) Incline.step(state, Math.min(.04, (now - last) / 1000));
    last = now;
    const r = Incline.forces(state);
    geometry = InclineDraw.render(canvas, state, r, state.drag ? pivot : null);
    if (!state.drag) pivot = geometry;
    const atRest = state.v === 0;
    const balanced = atRest && r.staticOK;
    const status = atRest ? (balanced ? '静止平衡' : '即将下滑') : (state.v > 0 ? '沿坡下滑' : '沿坡上滑');
    const frictionType = balanced ? '静摩擦' : atRest ? '下滑后摩擦' : '滑动摩擦';
    const friction = Math.abs(r.f) < 1e-10 ? '摩擦力为零' :
      frictionType + (r.f > 0 ? '沿坡向下' : '沿坡向上');
    const moving = String(!balanced);
    if (motion.dataset.moving !== moving) motion.dataset.moving = moving;
    show('status', status);
    show('frictionState', friction);
    show('speed', number(state.v));
    show('acceleration', number(r.a));
    show('distance', number(state.x));
    show('critical', number(r.critical, 1) + '°');
    show('thresholdState', r.staticOK ? '静止释放可保持平衡' : '超过临界角，释放后下滑');
    if (thresholdAngle !== state.angle || thresholdLimit !== r.critical) {
      threshold.style.setProperty('--current', state.angle / 60 * 100 + '%');
      threshold.style.setProperty('--critical', r.critical / 60 * 100 + '%');
      thresholdAngle = state.angle;
      thresholdLimit = r.critical;
    }
    show('normal', number(r.N) + ' N');
    show('parallel', number(r.P) + ' N');
    show('friction', number(r.f) + ' N');
    show('maximum', number(state.mus * r.N) + ' N');
    show('elapsed', number(state.time) + ' s');
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
  window.__model = { state, setScene, reset, get geometry() { return geometry; } };
})();
