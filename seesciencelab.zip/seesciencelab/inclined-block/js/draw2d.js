/* 实验台按 CSS 像素作图；全部力箭头共用比例尺。 */
(function () {
  const gold = '#ffcc6e', blue = '#80dcff', coral = '#ff9989';
  function render(canvas, state, forces, pivot) {
    const w = canvas.clientWidth, h = canvas.clientHeight;
    const dpi = Math.min(devicePixelRatio || 1, 2);
    const pixelWidth = Math.round(w * dpi), pixelHeight = Math.round(h * dpi);
    if (canvas.width !== pixelWidth || canvas.height !== pixelHeight) {
      canvas.width = pixelWidth;
      canvas.height = pixelHeight;
    }
    const ctx = canvas.getContext('2d');
    ctx.setTransform(dpi, 0, 0, dpi, 0, 0);
    ctx.clearRect(0, 0, w, h);
    const compact = w < 540;
    const angle = state.angle * Math.PI / 180;
    const tx = Math.cos(angle), ty = -Math.sin(angle), nx = ty, ny = -tx;
    const maxRise = Math.sin(Math.PI / 3);
    const length = Math.min(w * .78, h * .9, Math.max(1, (h - 62) / maxRise), 750);
    const ox = pivot?.ox ?? (w - length) / 2;
    const oy = pivot?.oy ?? Math.max(28 + length * maxRise, h * .46 + length * .37);
    const end = { x: ox + length * tx, y: oy + length * ty };
    const blockHeight = compact ? 35 : 52;
    const blockWidth = compact ? 54 : 84;
    // 先显示物块位移，接近视窗边缘时由刻度补足相对位移。
    const displacement = state.x * length * .13;
    const limit = length * .18;
    const travel = limit * Math.tanh(displacement / Math.max(1, limit));
    const contact = length * .53 - travel;
    const cx = ox + contact * tx + nx * blockHeight / 2;
    const cy = oy + contact * ty + ny * blockHeight / 2;

    function path(points, fill, stroke, width = 1, dash = []) {
      ctx.beginPath();
      ctx.moveTo(...points[0]);
      for (const point of points.slice(1)) ctx.lineTo(...point);
      if (fill) { ctx.fillStyle = fill; ctx.fill(); }
      if (stroke) {
        ctx.setLineDash(dash);
        ctx.strokeStyle = stroke;
        ctx.lineWidth = width;
        ctx.stroke();
        ctx.setLineDash([]);
      }
    }
    function label(value, x, y, color, align = 'left') {
      ctx.font = `600 ${compact ? 11 : 13}px system-ui`;
      ctx.textAlign = align;
      ctx.textBaseline = 'middle';
      ctx.lineWidth = 4;
      ctx.strokeStyle = '#05070d';
      ctx.strokeText(value, x, y);
      ctx.fillStyle = color;
      ctx.fillText(value, x, y);
    }
    const light = ctx.createRadialGradient(w / 2, oy - 25, 0, w / 2, oy - 25, Math.max(1, length * .75));
    light.addColorStop(0, '#172337');
    light.addColorStop(1, '#05070d');
    ctx.fillStyle = light;
    ctx.fillRect(0, 0, w, h);

    // 斜面导轨、侧面支撑和底座。
    const base = oy + 17;
    const depth = compact ? 8 : 14;
    const side = ctx.createLinearGradient(0, end.y, 0, base);
    side.addColorStop(0, '#314760');
    side.addColorStop(1, '#152030');
    path([[ox, oy], [end.x, end.y], [end.x, base], [ox, base]], side);
    if (oy - end.y > 28) {
      for (const u of [.28, .52, .76]) {
        const x = ox + length * u * tx, y = oy + length * u * ty;
        path([[x - length * .11 * tx, base - 5], [x, y + 8], [x + length * .11 * tx, base - 5]], null, '#54708a6e', compact ? 1.5 : 2.5);
      }
    }
    path([[ox, oy], [end.x, end.y], [end.x + depth, end.y + 5], [ox + depth, oy + 5]], '#425871');
    path([[ox + depth, oy + 5], [end.x + depth, end.y + 5], [end.x + depth, base], [end.x, base], [end.x, end.y]], '#172332');
    path([[ox - 12, base], [end.x + depth + 12, base]], null, '#516882', 3);
    path([[ox, oy], [end.x, end.y]], null, '#b4c9df', 2);
    const pitch = compact ? 17 : 23;
    const shift = (displacement - travel) % pitch;
    for (let u = pitch + shift; u < length - 10; u += pitch) {
      if (u < 10) continue;
      const x = ox + u * tx, y = oy + u * ty;
      path([[x, y], [x - nx * 5, Math.min(base - 1, y - ny * 5)]], null, '#8ca4bf');
    }
    const radius = compact ? 30 : 40;
    ctx.beginPath();
    ctx.arc(ox, oy, radius, -angle, 0);
    ctx.strokeStyle = gold;
    ctx.lineWidth = 1.5;
    ctx.stroke();
    label(`${state.angle.toFixed(0)}°`, ox + radius + 6, base + 15, gold);
    ctx.beginPath();
    ctx.arc(end.x, end.y, state.drag || state.hover ? 11 : 9, 0, Math.PI * 2);
    ctx.fillStyle = state.drag ? gold : '#14283b';
    ctx.fill();
    ctx.lineWidth = 2;
    ctx.strokeStyle = blue;
    ctx.stroke();
    path([[end.x - 3, end.y], [end.x + 3, end.y]], null, state.drag ? '#211708' : blue, 1.4);
    path([[end.x, end.y - 3], [end.x, end.y + 3]], null, state.drag ? '#211708' : blue, 1.4);
    label('拖动倾角', Math.min(w - 33, end.x), end.y - 19, blue, 'center');

    ctx.save();
    ctx.translate(cx, cy);
    ctx.rotate(-angle);
    const x = -blockWidth / 2, y = -blockHeight / 2;
    const wood = ctx.createLinearGradient(0, y, 0, -y);
    wood.addColorStop(0, '#e9b872');
    wood.addColorStop(.48, '#b98044');
    wood.addColorStop(1, '#80502c');
    ctx.fillStyle = wood;
    ctx.strokeStyle = '#f0bf7b';
    ctx.beginPath();
    ctx.roundRect(x, y, blockWidth, blockHeight, 4);
    ctx.fill();
    ctx.stroke();
    for (const offset of [.24, .45, .72, .86]) {
      const grain = y + blockHeight * offset;
      path([[x + 5, grain], [x + blockWidth * .36, grain - 2], [-x - 5, grain + 1]], null, '#6d432978');
    }
    ctx.restore();

    // 上、下坡方向由速度决定，位移靠导轨刻度呈现。
    if (Math.abs(state.v) > .001) {
      const dir = -Math.sign(state.v);
      const x = cx + nx * (blockHeight / 2 + 10) + tx * 21;
      const y = cy + ny * (blockHeight / 2 + 10) + ty * 21;
      const tip = [x + tx * dir * 14, y + ty * dir * 14];
      path([[x - tx * dir * 14, y - ty * dir * 14], tip], null, '#c7d4e2', 1.4);
      path([[tip[0] - tx * dir * 6 + nx * 3, tip[1] - ty * dir * 6 + ny * 3], tip,
        [tip[0] - tx * dir * 6 - nx * 3, tip[1] - ty * dir * 6 - ny * 3]], null, '#c7d4e2', 1.4);
    }

    const scale = Math.min(5.5, Math.min(w * .26, h * .22, 143) / forces.G);
    function arrow(fx, fy, color, value, dx, dy, dashed = false) {
      const x = fx * scale, y = fy * scale, size = Math.hypot(x, y);
      if (size < 2) return;
      const ux = x / size, uy = y / size;
      const tip = [cx + x, cy + y], head = Math.min(9, size * .45);
      if (!dashed) path([[cx, cy], tip], null, '#101724bd', 4.8);
      path([[cx, cy], tip], null, color, dashed ? 1.4 : 2.6, dashed ? [4, 4] : []);
      path([[tip[0] - ux * head + uy * head * .46, tip[1] - uy * head - ux * head * .46], tip,
        [tip[0] - ux * head - uy * head * .46, tip[1] - uy * head + ux * head * .46]], null, color, dashed ? 1.4 : 2.3);
      label(value, tip[0] + dx, tip[1] + dy, color, dx < 0 ? 'right' : 'left');
    }
    if (state.components && state.angle > 0) {
      arrow(-tx * forces.P, -ty * forces.P, '#d7a95e', 'mg sinθ', -7, 12, true);
      arrow(-nx * forces.N, -ny * forces.N, '#d7a95e', 'mg cosθ', 7, -9, true);
    }
    arrow(0, forces.G, gold, 'mg', 8, 8);
    arrow(nx * forces.N, ny * forces.N, blue, 'N', -8, -6);
    arrow(-tx * forces.f, -ty * forces.f, coral, 'f', forces.f > 0 ? -8 : 8, -8);
    ctx.beginPath();
    ctx.arc(cx, cy, 3, 0, Math.PI * 2);
    ctx.fillStyle = '#f6ead5';
    ctx.fill();
    return { ox, oy, end };
  }
  window.InclineDraw = { render };
})();
