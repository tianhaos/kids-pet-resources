// 2D 光路图：Canvas 绘制透镜、焦点、蜡烛、三条特殊光线和像
// 世界坐标单位 cm，透镜光心在原点，x 向右、y 向上。
(function () {
  var O = window.Optics;
  var APERTURE = 12;          // 透镜半口径（cm）
  var HV = 21;                // 竖直方向至少显示 ±21cm

  var C = {
    axis: '#5b677b', text: '#c9d2df', muted: '#8d99ab', grid: 'rgba(255,255,255,0.035)',
    lens: 'rgba(120,190,255,0.20)', lensEdge: '#8fd0ff',
    r1: '#ff7a59', r2: '#4fc3f7', r3: '#7ee081', fan: 'rgba(255,201,74,0.22)',
    real: '#ffc94a', virt: '#c9a7ff', focus: '#ffc94a',
    zone: { near: 'rgba(201,167,255,', mid: 'rgba(255,122,89,', far: 'rgba(79,195,247,' }
  };

  function Ray2D(canvas) {
    var ctx = canvas.getContext('2d');
    var W = 1, H = 1, dpr = 1, s = 10, cx = 0, cy = 0;

    function X(x) { return cx + x * s; }
    function Y(y) { return cy - y * s; }

    function resize(w, h) {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      W = w; H = h;
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
      canvas.style.width = w + 'px'; canvas.style.height = h + 'px';
      var narrow = w < 640;                     // 窄屏只显示约 56cm 宽，透镜略偏右，给物体留更多空间
      var hw = narrow ? 28 : 50;
      s = Math.min(w / (2 * hw), h / (2 * HV));
      cx = narrow ? w * 0.56 : w / 2; cy = h * 0.5;
    }

    // ---------- 基本绘图 ----------
    function line(x1, y1, x2, y2, color, width, dash) {
      ctx.beginPath();
      ctx.setLineDash(dash || []);
      ctx.strokeStyle = color; ctx.lineWidth = width || 1.5;
      ctx.moveTo(X(x1), Y(y1)); ctx.lineTo(X(x2), Y(y2));
      ctx.stroke();
      ctx.setLineDash([]);
    }

    function arrowHead(x1, y1, x2, y2, color) {
      // 在线段中点画一个指示传播方向的小箭头
      var ax = X(x1), ay = Y(y1), bx = X(x2), by = Y(y2);
      var len = Math.hypot(bx - ax, by - ay);
      if (len < 40) return;
      var mx = (ax + bx) / 2, my = (ay + by) / 2, a = Math.atan2(by - ay, bx - ax);
      ctx.save();
      ctx.translate(mx, my); ctx.rotate(a);
      ctx.beginPath(); ctx.moveTo(6, 0); ctx.lineTo(-4, -4); ctx.lineTo(-4, 4); ctx.closePath();
      ctx.fillStyle = color; ctx.fill();
      ctx.restore();
    }

    function text(str, px, py, color, align, size, weight) {
      ctx.font = (weight || '') + ' ' + (size || 12) + 'px -apple-system, "PingFang SC", "Microsoft YaHei", sans-serif';
      ctx.fillStyle = color || C.text;
      ctx.textAlign = align || 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(str, px, py);
    }

    function tag(str, px, py, color) {
      ctx.font = '12px -apple-system, "PingFang SC", "Microsoft YaHei", sans-serif';
      var w = ctx.measureText(str).width + 12;
      ctx.fillStyle = 'rgba(11,15,23,0.85)';
      ctx.strokeStyle = color; ctx.lineWidth = 1;
      roundRect(px - w / 2, py - 10, w, 20, 10);
      ctx.fill(); ctx.stroke();
      text(str, px, py, color);
    }

    function roundRect(x, y, w, h, r) {
      ctx.beginPath();
      ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r);
      ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
    }

    // 沿方向 (dx,dy) 从 (x,y) 延伸到画面左/右边界
    function toEdge(x, y, dx, dy) {
      var edge = dx > 0 ? (W - cx) / s + 5 : -cx / s - 5;
      var t = (edge - x) / dx;
      return [edge, y + dy * t];
    }

    // ---------- 蜡烛 ----------
    // 在像素坐标 (px, py) 处画蜡烛，hp 为带符号的像素高度（负数即倒立）
    function candle(px, py, hp, style) {
      if (Math.abs(hp) < 0.5) return;
      var k = Math.abs(hp);
      // 局部坐标：y 向上 0..1，经 m 变换到像素坐标
      var m = new DOMMatrix().translate(px, py).scale(k, -hp);
      var body = new Path2D();
      body.rect(-0.08, 0, 0.16, 0.68);
      var flame = new Path2D();
      flame.moveTo(0, 1);
      flame.bezierCurveTo(0.03, 0.93, 0.085, 0.86, 0.075, 0.8);
      flame.bezierCurveTo(0.068, 0.74, 0.03, 0.72, 0, 0.72);
      flame.bezierCurveTo(-0.03, 0.72, -0.068, 0.74, -0.075, 0.8);
      flame.bezierCurveTo(-0.085, 0.86, -0.03, 0.93, 0, 1);
      var inner = new Path2D();
      inner.ellipse(0, 0.79, 0.03, 0.055, 0, 0, Math.PI * 2);
      // 用变换后的路径填充/描边，线宽保持像素单位
      function P(p) { var q = new Path2D(); q.addPath(p, m); return q; }
      var b = P(body), fl = P(flame), inn = P(inner);
      var wick = new Path2D(); wick.moveTo(0, 0.68); wick.lineTo(0, 0.74);
      var wk = P(wick);

      ctx.save();
      if (style === 'virtual') {
        ctx.globalAlpha = 0.22;
        ctx.fillStyle = '#efe6d2'; ctx.fill(b);
        ctx.fillStyle = '#ffb347'; ctx.fill(fl);
        ctx.globalAlpha = 1;
        ctx.setLineDash([5, 4]);
        ctx.strokeStyle = C.virt; ctx.lineWidth = 1.5;
        ctx.stroke(b); ctx.stroke(fl);
        ctx.setLineDash([]);
      } else {
        ctx.fillStyle = style === 'real' ? '#f6e7c1' : '#efe6d2';
        ctx.fill(b);
        ctx.strokeStyle = '#3a3a3a'; ctx.lineWidth = 1; ctx.stroke(wk);
        ctx.shadowColor = 'rgba(255,170,60,0.9)'; ctx.shadowBlur = Math.min(24, k * 0.4);
        ctx.fillStyle = '#ff9a3c'; ctx.fill(fl);
        ctx.shadowBlur = 0;
        ctx.fillStyle = '#fff3b0'; ctx.fill(inn);
        if (style === 'real') {
          ctx.strokeStyle = C.real; ctx.lineWidth = 1.5;
          ctx.stroke(b); ctx.stroke(fl);
        }
      }
      ctx.restore();
    }

    // ---------- 透镜 ----------
    function lens(f, extendTo) {
      var top = Y(APERTURE), bot = Y(-APERTURE), x0 = X(0);
      var half = Math.min(Math.max(20 / f, 0.6), 3) * s;   // 焦距越短，透镜越鼓
      ctx.beginPath();
      ctx.moveTo(x0, top);
      ctx.quadraticCurveTo(x0 + half * 2, cy, x0, bot);
      ctx.quadraticCurveTo(x0 - half * 2, cy, x0, top);
      ctx.fillStyle = C.lens; ctx.fill();
      ctx.strokeStyle = C.lensEdge; ctx.lineWidth = 1.5; ctx.stroke();
      // 主光轴所在的透镜中心线
      line(0, APERTURE, 0, -APERTURE, 'rgba(143,208,255,0.35)', 1);
      if (extendTo > APERTURE) {
        line(0, APERTURE, 0, extendTo + 1, 'rgba(143,208,255,0.6)', 1.2, [4, 4]);
        line(0, -APERTURE, 0, -extendTo - 1, 'rgba(143,208,255,0.6)', 1.2, [4, 4]);
      }
    }

    // ---------- 主绘制 ----------
    function draw(st) {
      var u = st.u, f = st.f, h = st.h, show = st.show;
      var img = O.image(u, f), zn = O.zone(u, f);
      var v = img.v, m = img.m;
      var focal = zn.key === 'focal';
      var real = !focal && v > 0;
      var hi = focal ? Infinity : m * h;           // 像高（带符号）
      var xl = -cx / s, xr = (W - cx) / s;

      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, W, H);

      // 背景网格（每 5cm）
      ctx.strokeStyle = C.grid; ctx.lineWidth = 1;
      ctx.beginPath();
      for (var gx = Math.ceil(xl / 5) * 5; gx <= xr; gx += 5) { ctx.moveTo(X(gx), 0); ctx.lineTo(X(gx), H); }
      for (var gy = -60; gy <= 60; gy += 5) { ctx.moveTo(0, Y(gy)); ctx.lineTo(W, Y(gy)); }
      ctx.stroke();

      // 物距区间底纹
      if (show.zones) {
        var bands = [['near', -f, 0, 'u < f'], ['mid', -2 * f, -f, 'f < u < 2f'], ['far', xl, -2 * f, 'u > 2f']];
        bands.forEach(function (b) {
          var on = zn.key === b[0];
          var x1 = X(Math.max(b[1], xl)), x2 = X(b[2]);
          if (x2 <= x1) return;
          ctx.fillStyle = C.zone[b[0]] + (on ? 0.16 : 0.05) + ')';
          ctx.fillRect(x1, cy, x2 - x1, 26);
          if (show.labels && x2 - x1 > 54) text(b[3], (x1 + x2) / 2, cy + 15, on ? C.text : C.muted, 'center', 11);
        });
      }

      // 主光轴
      line(xl, 0, xr, 0, C.axis, 1);

      // 光线打在透镜上的最大高度，超出口径时把透镜画虚线延长
      var hits = [Math.abs(h)];
      if (!focal && show.rays) hits.push(Math.abs(hi));
      lens(f, Math.min(Math.max.apply(null, hits), 200));

      // 焦点与 2 倍焦点
      [[-2 * f, '2F'], [-f, 'F'], [f, 'F′'], [2 * f, '2F′']].forEach(function (p) {
        if (p[0] < xl || p[0] > xr) return;
        ctx.beginPath(); ctx.arc(X(p[0]), cy, p[1].length === 1 || p[1] === 'F′' ? 4 : 3.2, 0, Math.PI * 2);
        ctx.fillStyle = p[1].indexOf('2') === 0 ? '#9aa6b8' : C.focus; ctx.fill();
        if (show.labels) text(p[1], X(p[0]), cy - 13, p[1].indexOf('2') === 0 ? '#9aa6b8' : C.focus, 'center', 13, '600');
      });
      if (show.labels) text('O', X(0) + 10, cy + 12, C.muted, 'left', 12);

      var T = [-u, h];
      var I = focal ? null : [v, hi];

      // 更多光线：从烛焰顶点射向透镜各处
      if (show.fan) {
        for (var i = -5; i <= 5; i++) {
          var ly = i / 5 * APERTURE * 0.95;
          var d = focal ? [u, -h] : real ? [v, hi - ly] : [-v, ly - hi];
          if (real && Math.abs(v) < 1e-6) continue;
          var e = toEdge(0, ly, d[0], d[1]);
          line(T[0], T[1], 0, ly, C.fan, 1);
          line(0, ly, e[0], e[1], C.fan, 1);
          if (!focal && !real) line(0, ly, I[0], I[1], 'rgba(201,167,255,0.18)', 1, [3, 4]);
        }
      }

      // 三条特殊光线
      if (show.rays) {
        var rays = [
          { c: C.r1, L: [0, h], d: [f, -h] },
          { c: C.r2, L: [0, 0], d: [u, -h] }
        ];
        if (!focal) rays.push({ c: C.r3, L: [0, hi], d: [1, 0], viaF: !real });
        rays.forEach(function (r) {
          if (r.viaF) line(-f, 0, T[0], T[1], r.c, 1.2, [5, 5]);    // u<f 时：反向延长线过 F
          line(T[0], T[1], r.L[0], r.L[1], r.c, 2);
          arrowHead(T[0], T[1], r.L[0], r.L[1], r.c);
          var e = toEdge(r.L[0], r.L[1], r.d[0], r.d[1]);
          line(r.L[0], r.L[1], e[0], e[1], r.c, 2);
          arrowHead(r.L[0], r.L[1], real ? I[0] : e[0], real ? I[1] : e[1], r.c);
          if (!focal && !real) line(r.L[0], r.L[1], I[0], I[1], r.c, 1.2, [5, 5]);   // 虚像：反向延长线
        });
      }

      // 物（蜡烛）
      var objOff = -u < xl + 1;
      if (!objOff) candle(X(-u), cy, h * s, 'object');
      else {
        tag('← 蜡烛在 u = ' + u.toFixed(0) + ' cm 处' + (u / f >= O.K_MAX - 0.01 ? '（≈ 无穷远）' : ''),
          Math.min(170, W / 2 - 10), cy - 40, C.text);
      }

      // 像
      var imgOff = false;
      if (focal) {
        if (show.labels) tag('u = f：折射光平行，不成像', X(f * 2.2) > W - 120 ? W - 120 : X(f * 2.2), Y(h) - 30, C.muted);
      } else if (v > xr || v < xl) {
        imgOff = true;
        var side = v > 0 ? W - 130 : 130;
        tag((v > 0 ? '实像在 v = ' : '虚像在左侧 ') + Math.abs(v).toFixed(0) + ' cm 处（画面外）' + (v > 0 ? ' →' : ''),
          Math.max(130, Math.min(W - 130, side)), cy + (v > 0 ? 50 : -60), real ? C.real : C.virt);
      }
      if (!focal && !imgOff) {
        candle(X(v), cy, hi * s, real ? 'real' : 'virtual');
        if (show.labels) {
          var ty = Y(hi) + (hi > 0 ? -18 : 20);
          ty = Math.max(14, Math.min(H - 14, ty));
          tag(real ? '实像' : '虚像', X(v), ty, real ? C.real : C.virt);
        }
      }

      // 物距、像距标注
      if (show.labels) {
        var base = Math.min(H - 40, Math.max(cy + 40, real && !imgOff ? Y(hi) + 44 : 0));
        dim(objOff ? xl : -u, 0, base, 'u = ' + u.toFixed(1) + ' cm', C.text);
        if (!focal && !imgOff) dim(Math.min(0, v), Math.max(0, v), real ? base : base + 22, (real ? 'v = ' : '|v| = ') + Math.abs(v).toFixed(1) + ' cm', real ? C.real : C.virt);
      }
    }

    // 尺寸标注线
    function dim(x1, x2, py, label, color) {
      var a = X(x1), b = X(x2);
      if (b - a < 24) return;
      ctx.strokeStyle = color; ctx.globalAlpha = 0.6; ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(a, py); ctx.lineTo(b, py);
      ctx.moveTo(a, py - 4); ctx.lineTo(a, py + 4);
      ctx.moveTo(b, py - 4); ctx.lineTo(b, py + 4);
      ctx.stroke(); ctx.globalAlpha = 1;
      ctx.font = '12px -apple-system, "PingFang SC", sans-serif';
      var w = ctx.measureText(label).width + 8;
      ctx.fillStyle = '#05070d'; ctx.fillRect((a + b) / 2 - w / 2, py - 8, w, 16);
      text(label, (a + b) / 2, py, color, 'center', 12);
    }

    // 命中蜡烛（用于拖拽）
    function hitObject(px, py, st) {
      var x = X(-st.u), top = Y(st.h);
      var half = Math.max(16, st.h * s * 0.15);
      return Math.abs(px - x) < half && py > top - 12 && py < cy + 10;
    }

    return {
      resize: resize, draw: draw, hitObject: hitObject,
      toWorldX: function (px) { return (px - cx) / s; },
      toPx: function (x) { return X(x); },
      leftEdge: function () { return -cx / s; }
    };
  }

  window.Ray2D = Ray2D;
})();
