(function () {
  var O = window.Optics;
  var $ = function (id) { return document.getElementById(id); };

  var state = {
    u: 30, f: 10, h: 5,
    show: { rays: true, fan: false, zones: true, labels: true },
    auto: false, autoMult: 1, autoSt: { k: 3, dir: 1, pause: 0 },
    view: 'ray', cam: 'side'
  };

  var stage = $('stage'), canvas = $('ray'), panel = $('panel');
  var ray = window.Ray2D(canvas);
  var bench = null, benchLoading = false;

  // ---------- 拖动蜡烛 ----------
  var dragging = false, dragOff = 0;
  var SNAP_PX = 8;

  function localXY(e) {
    var r = canvas.getBoundingClientRect();
    return [e.clientX - r.left, e.clientY - r.top];
  }

  canvas.addEventListener('pointerdown', function (e) {
    var p = localXY(e);
    if (!ray.hitObject(p[0], p[1], state)) return;
    dragging = true;
    dragOff = ray.toWorldX(p[0]) + state.u;
    try { canvas.setPointerCapture(e.pointerId); } catch (err) { /* 合成事件无法捕获指针 */ }
    canvas.classList.add('grabbing');
    setAuto(false);
  });
  canvas.addEventListener('pointermove', function (e) {
    var p = localXY(e);
    if (!dragging) {
      canvas.classList.toggle('grab', ray.hitObject(p[0], p[1], state));
      return;
    }
    var x = ray.toWorldX(p[0]) - dragOff;
    var u = -x;
    var uMax = -ray.leftEdge() - 2;
    u = Math.max(0.2 * state.f, Math.min(uMax, u));
    // 靠近 F、2F 时吸附
    [state.f, 2 * state.f].forEach(function (s) {
      if (Math.abs(ray.toPx(-u) - ray.toPx(-s)) < SNAP_PX) u = s;
    });
    setU(u);
  });
  function endDrag(e) {
    if (!dragging) return;
    dragging = false;
    canvas.classList.remove('grabbing');
    if (canvas.hasPointerCapture(e.pointerId)) canvas.releasePointerCapture(e.pointerId);
  }
  canvas.addEventListener('pointerup', endDrag);
  canvas.addEventListener('pointercancel', endDrag);

  function setU(u) {
    state.u = u;
    state.autoSt.k = u / state.f;
  }

  // ---------- 面板控件 ----------
  var presetBtns = document.querySelectorAll('[data-k]');
  presetBtns.forEach(function (b) {
    b.addEventListener('click', function () {
      setAuto(false);
      setU(parseFloat(b.dataset.k) * state.f);
    });
  });

  var autoOn = $('autoOn');
  function setAuto(on) {
    state.auto = on;
    autoOn.checked = on;
    if (on) {
      var k = state.u / state.f;
      state.autoSt.k = Math.max(O.K_MIN, Math.min(O.K_MAX, k));
      state.autoSt.pause = 0;
      // 从当前位置朝较远的一端出发
      state.autoSt.dir = k < O.K_MAX - 0.01 ? 1 : -1;
    }
  }
  autoOn.addEventListener('change', function () {
    setAuto(autoOn.checked);
    if (autoOn.checked) Analytics.track('凸透镜', '开启自动移动');
  });

  function bindRange(id, outId, fmt, apply) {
    var el = $(id), out = $(outId);
    function upd() { var v = parseFloat(el.value); apply(v); out.textContent = fmt(v); }
    el.addEventListener('input', upd);
    upd();
  }
  bindRange('autoSpeed', 'autoOut', function (v) { return v + '×'; }, function (v) { state.autoMult = v; });
  bindRange('focal', 'focalOut', function (v) { return v + ' cm'; }, function (v) {
    // 改焦距时保持 u/f 不变，蜡烛所在区间不跳变
    var k = state.u / state.f;
    state.f = v;
    state.u = k * v;
  });
  bindRange('height', 'heightOut', function (v) { return v + ' cm'; }, function (v) { state.h = v; });

  [['showRays', 'rays'], ['showFan', 'fan'], ['showZones', 'zones'], ['showLabels', 'labels']].forEach(function (p) {
    var el = $(p[0]);
    el.addEventListener('change', function () { state.show[p[1]] = el.checked; });
    state.show[p[1]] = el.checked;
  });

  $('panelToggle').addEventListener('click', function () { panel.classList.toggle('collapsed'); });
  if (window.matchMedia('(max-width: 760px)').matches) panel.classList.add('collapsed');

  window.addEventListener('keydown', function (e) {
    var t = e.target.tagName;
    if (t === 'INPUT' || t === 'SELECT' || t === 'BUTTON' || t === 'TEXTAREA') return;
    if (e.code === 'Space') { e.preventDefault(); setAuto(!state.auto); }
  });

  // ---------- 视图切换（3D 实验台按需加载） ----------
  function loadScript(src) {
    return new Promise(function (resolve, reject) {
      var s = document.createElement('script');
      s.src = src; s.onload = resolve; s.onerror = function () { reject(new Error('加载失败：' + src)); };
      document.head.appendChild(s);
    });
  }

  function ensureBench() {
    if (bench || benchLoading) return;
    benchLoading = true;
    $('benchNote').hidden = false;
    $('benchNote').textContent = '正在加载 3D 实验台…';
    loadScript('../shared/vendor/three.min.js')
      .then(function () { return loadScript('../shared/vendor/CSS2DRenderer.js'); })
      .then(function () { return loadScript('js/bench3d.js'); })
      .then(function () {
        bench = window.Bench3D($('bench'));
        resize();
      })
      .catch(function (err) { $('benchNote').textContent = err.message; })
      .then(function () { benchLoading = false; });
  }

  function setView(v) {
    state.view = v;
    document.querySelectorAll('[data-view]').forEach(function (b) { b.classList.toggle('on', b.dataset.view === v); });
    canvas.hidden = v !== 'ray';
    $('bench').hidden = v !== 'bench';
    $('camSeg').hidden = v !== 'bench';
    $('benchNote').hidden = v !== 'bench';
    $('hint').textContent = v === 'ray'
      ? '拖动蜡烛改变物距 · 靠近 F、2F 时会自动吸附'
      : '光屏会自动移到成像位置 · 在面板中调整蜡烛位置';
    if (v === 'bench') ensureBench();
    resize();
  }
  document.querySelectorAll('[data-view]').forEach(function (b) {
    b.addEventListener('click', function () {
      if (b.dataset.view !== state.view) Analytics.track('凸透镜', '切换视图', b.dataset.view);
      setView(b.dataset.view);
    });
  });
  document.querySelectorAll('[data-cam]').forEach(function (b) {
    b.addEventListener('click', function () {
      state.cam = b.dataset.cam;
      document.querySelectorAll('[data-cam]').forEach(function (x) { x.classList.toggle('on', x === b); });
    });
  });

  // ---------- 读数 ----------
  var last = {};
  function setText(id, s) { if (last[id] !== s) { last[id] = s; $(id).textContent = s; } }

  function updateReadouts() {
    var u = state.u, f = state.f;
    var img = O.image(u, f), zn = O.zone(u, f);
    setText('rNature', zn.nature);
    setText('rUse', '应用：' + zn.use);
    setText('rU', u.toFixed(1) + ' cm');
    setText('rK', '= ' + (u / f).toFixed(2) + ' f' + (u / f >= O.K_MAX - 0.01 ? '（≈ 无穷远）' : ''));
    if (zn.key === 'focal') {
      setText('rV', '∞（不成像）');
      setText('rM', '—');
    } else {
      setText('rV', img.v > 0
        ? img.v.toFixed(1) + ' cm（透镜右侧）'
        : Math.abs(img.v).toFixed(1) + ' cm（与蜡烛同侧）');
      var am = Math.abs(img.m);
      setText('rM', am.toFixed(am < 10 ? 2 : 0) + ' 倍' + (am > 1.005 ? '（放大）' : am < 0.995 ? '（缩小）' : '（等大）'));
    }
    setText('rZone', zn.cond + '，像：' + zn.img);
    presetBtns.forEach(function (b) {
      var k = parseFloat(b.dataset.k);
      var key = O.zone(k * f, f).key;
      b.classList.toggle('on', key === zn.key);
    });
  }

  // ---------- 尺寸与主循环 ----------
  function resize() {
    var w = stage.clientWidth, h = stage.clientHeight;
    ray.resize(w, h);
    if (bench) bench.resize(w, h);
  }
  new ResizeObserver(resize).observe(stage);
  resize();

  var lastT = performance.now();
  function frame(t) {
    var dt = Math.min((t - lastT) / 1000, 0.1);
    lastT = t;
    if (state.auto && !dragging) {
      O.autoStep(state.autoSt, dt, state.autoMult);
      state.u = state.autoSt.k * state.f;
    }
    if (state.view === 'ray') ray.draw(state);
    else if (bench) {
      bench.update(state, dt);
      var note = bench.note(state);
      setText('benchNote', note);
      $('benchNote').hidden = !note;
    }
    updateReadouts();
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // 调试用
  window.__model = { state: state, setU: setU, setAuto: setAuto, setView: setView, getBench: function () { return bench; } };
})();
