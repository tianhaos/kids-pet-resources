(function () {
  'use strict';
  var $=function(id){return document.getElementById(id);},P=AirPressure,qs=new URLSearchParams(location.search);
  function num(key,fallback,min,max){var v=qs.has(key)?Number(qs.get(key)):fallback;return Number.isFinite(v)?P.clamp(v,min,max):fallback;}
  var state={scene:qs.get('scene')==='hemispheres'?'hemispheres':'barometer',altitude:num('altitude',0,0,5000),angle:num('angle',20,0,50),ratio:num('ratio',0,0,1),radius:num('radius',15,5,20),pull:num('pull',0,0,15000),separated:false};
  var canvas=$('experiment'),drag=null,startX=0,startForce=0,lastHits;
  var reducedMotion=matchMedia('(prefers-reduced-motion: reduce)');
  function track(action,label){if(window.Analytics)Analytics.track('大气压',action,String(label));}
  function settle(){var q=P.solve(state);if(state.scene==='hemispheres'&&state.pull>q.force+0.01){state.separated=true;state.ratio=1;}}
  function sync(){
    settle();var q=P.solve(state);
    document.querySelectorAll('[data-scene]').forEach(function(b){var on=b.dataset.scene===state.scene;b.classList.toggle('on',on);b.setAttribute('aria-pressed',on);});
    $('barometerControls').hidden=state.scene!=='barometer';$('sphereControls').hidden=state.scene!=='hemispheres';
    ['altitude','angle','ratio','radius','pull'].forEach(function(k){$(k).value=state[k];});
    $('altitudeOut').textContent=state.altitude.toFixed(0)+' m';$('angleOut').textContent=state.angle.toFixed(0)+'°';$('ratioOut').textContent=(state.ratio*100).toFixed(0)+'%';$('radiusOut').textContent=state.radius.toFixed(0)+' cm';$('pullOut').textContent=state.pull.toFixed(0)+' N';
    $('primary').textContent=state.scene==='barometer'?(q.height*100).toFixed(1)+' cm':q.force.toFixed(0)+' N / 侧';
    $('stageMetric').textContent=$('primary').textContent;
    $('sceneTitle').textContent=state.scene==='barometer'?'倾斜的是管，还是高度？':'空气，能把铜半球压多紧？';
    $('sceneIntro').textContent=state.scene==='barometer'?'拖动管顶，比较竖直高度与沿管长度。':'向外拖动把手，或点阀门让空气进入。';
    $('stageMetricLabel').textContent=state.scene==='barometer'?'竖直高度 h':'分离阈值 · 每侧';
    $('stageConclusion').textContent=state.scene==='barometer'?(state.ratio===1?'内外等压，两个液面相平':state.ratio>0?'管内进气，液柱高度下降':'管变斜，竖直高度不变'):(state.separated?'半球已分开，压强差消失':state.ratio===1?'内外等压，分离阈值为零':'外压大于内压，半球被压紧');
    $('stageContext').textContent='海拔 '+state.altitude.toFixed(0)+' m · '+(state.scene==='barometer'?(state.ratio===0?'上端近似真空':'管内气压 '+(q.inside/1000).toFixed(1)+' kPa'):'每侧施力 '+state.pull.toFixed(0)+' N');
    $('vacuum').setAttribute('aria-pressed',state.ratio===0);$('air').setAttribute('aria-pressed',state.ratio===.25);
    $('vent').disabled=state.separated;
    $('vent').textContent=state.separated?'分离后已通气':state.ratio===1?'关闭并抽气':'打开通气阀';
    $('primaryLabel').textContent=state.scene==='barometer'?'液面竖直高度差':'理想分离所需拉力';
    $('outside').textContent=(q.pressure/1000).toFixed(2)+' kPa';$('inside').textContent=(q.inside/1000).toFixed(2)+' kPa';
    $('detailLabel').textContent=state.scene==='barometer'?'沿管液柱长度':'剖分面圆面积';
    $('detail').textContent=state.scene==='barometer'?(q.length*100).toFixed(1)+' cm':(q.area*10000).toFixed(1)+' cm²';
    $('status').textContent=state.scene==='barometer'?(state.ratio>0?'管内气体也在施压，水银高度下降；只用 ρgh 会低估大气压。':'上端近似真空：改变倾角，比较沿管长度与竖直高度差。'):(state.separated?'拉力已超过所需值，半球拉开并通气。点“合拢并抽气”重做。':state.ratio===1?'内外压强相等，理想分离力为零。':'两侧各需同样大的拉力，不要把单侧结果再乘 2。');
    $('hint').textContent=state.scene==='barometer'?'拖动玻璃管顶部金色圆点，或用面板调节倾角':(state.separated?'点“合拢并抽气”重做实验':'拖动半球把手施力；点下方阀门通气');
  }
  document.querySelectorAll('[data-scene]').forEach(function(b){b.onclick=function(){state.scene=b.dataset.scene;state.pull=0;state.separated=false;state.ratio=state.scene==='barometer'?0:.1;sync();track('场景',state.scene);};});
  ['altitude','angle','ratio','radius','pull'].forEach(function(k){$(k).oninput=function(){state[k]=Number(this.value);if(k==='ratio'&&state.separated){state.separated=false;state.pull=0;}sync();};$(k).onchange=function(){track(k,state[k]);};});
  $('vacuum').onclick=function(){state.ratio=0;sync();track('管内','近似真空');};
  $('air').onclick=function(){state.ratio=.25;sync();track('管内','进气25%');};
  $('pump').onclick=function(){state.separated=false;state.pull=0;state.ratio=.1;sync();track('半球','合拢抽气');};
  function valve(){if(state.separated)return;state.ratio=state.ratio<1?1:.1;state.pull=0;sync();track('半球','阀门');}
  $('vent').onclick=valve;
  $('reset').onclick=function(){Object.assign(state,{altitude:0,angle:20,ratio:state.scene==='barometer'?0:.1,radius:15,pull:0,separated:false});sync();track('重置',state.scene);};
  $('share').onclick=async function(){var p=new URLSearchParams();['scene','altitude','angle','ratio','radius','pull'].forEach(function(k){p.set(k,state[k]);});var url=location.origin+location.pathname+'?'+p.toString();try{await navigator.clipboard.writeText(url);this.textContent='链接已复制';}catch(e){$('shareLink').hidden=false;$('shareLink').value=url;$('shareLink').select();this.textContent='请复制下方链接';}track('分享',state.scene);};
  $('panelToggle').onclick=function(){var collapsed=$('panel').classList.toggle('collapsed');this.setAttribute('aria-expanded',!collapsed);this.textContent=collapsed?'实验设置':'收起设置';};
  canvas.addEventListener('pointerdown',function(e){var p=AirDraw.point(e),hit=AirDraw.hit(p);if(!hit)return;e.preventDefault();if(hit==='valve'){valve();return;}drag=hit;startX=p.x;startForce=state.pull;canvas.setPointerCapture(e.pointerId);canvas.style.cursor='grabbing';});
  canvas.addEventListener('pointermove',function(e){var p=AirDraw.point(e);if(!drag){canvas.style.cursor=AirDraw.hit(p)?'grab':'default';return;}if(drag==='tube'){var pivot=AirDraw.getHits().pivot;state.angle=P.clamp(Math.atan2(p.x-pivot.x,pivot.y-p.y)*180/Math.PI,0,50);}else{var sign=drag==='left'?-1:1;state.pull=P.clamp(Math.round(startForce+(p.x-startX)*sign*90),0,15000);}sync();});
  function end(e){if(!drag)return;track('拖动',drag);drag=null;canvas.style.cursor='grab';if(canvas.hasPointerCapture(e.pointerId))canvas.releasePointerCapture(e.pointerId);}
  canvas.addEventListener('pointerup',end);canvas.addEventListener('pointercancel',end);
  if(innerWidth<=760)$('panel').classList.add('collapsed');else $('panelToggle').setAttribute('aria-expanded','true');
  sync();function frame(t){lastHits=AirDraw.draw(canvas,state,P.solve(state),reducedMotion.matches?0:t/1000);requestAnimationFrame(frame);}requestAnimationFrame(frame);
  window.__model={state:state,solve:function(){return P.solve(state);},set:function(values){Object.keys(values).forEach(function(k){if(!(k in state))return;if(k==='scene'){state.scene=values[k]==='hemispheres'?'hemispheres':'barometer';}else if(typeof values[k]==='number'&&Number.isFinite(values[k])){var ranges={altitude:[0,5000],angle:[0,50],ratio:[0,1],radius:[5,20],pull:[0,15000]};if(ranges[k])state[k]=P.clamp(values[k],ranges[k][0],ranges[k][1]);}});sync();},hits:function(){return lastHits;}};
})();
