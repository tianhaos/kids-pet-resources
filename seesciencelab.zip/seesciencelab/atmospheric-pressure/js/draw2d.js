/* 装置剖面与命中区域。长度按比例，横向装饰不作计量。 */
(function () {
  'use strict';
  var c, ctx, W, H, scale, ox, oy, hits = {}, mobile;
  var gold='#ffc94a', blue='#71d8ff', ink='#d9e7f1', dim='#8ba7ba';
  function line(x1,y1,x2,y2,color,width,dash) {
    ctx.beginPath();ctx.moveTo(x1,y1);ctx.lineTo(x2,y2);ctx.strokeStyle=color;ctx.lineWidth=width||2;ctx.setLineDash(dash||[]);ctx.stroke();ctx.setLineDash([]);
  }
  function text(t,x,y,size,color,align) {ctx.fillStyle=color||ink;ctx.font=(size||16)+'px -apple-system,"PingFang SC",sans-serif';ctx.textAlign=align||'left';ctx.fillText(t,x,y);}
  function rect(x,y,w,h,color,r) {ctx.fillStyle=color;ctx.beginPath();ctx.roundRect(x,y,w,h,r||0);ctx.fill();}
  function circle(x,y,r,color) {ctx.beginPath();ctx.arc(x,y,r,0,Math.PI*2);ctx.fillStyle=color;ctx.fill();}
  function arrow(x1,y1,x2,y2,color,width) {
    line(x1,y1,x2,y2,color,width||3);var a=Math.atan2(y2-y1,x2-x1);ctx.beginPath();ctx.moveTo(x2,y2);ctx.lineTo(x2-11*Math.cos(a-.45),y2-11*Math.sin(a-.45));ctx.lineTo(x2-11*Math.cos(a+.45),y2-11*Math.sin(a+.45));ctx.closePath();ctx.fillStyle=color;ctx.fill();
  }
  function tag(t,x,y,color) {ctx.font='16px -apple-system,"PingFang SC",sans-serif';var w=ctx.measureText(t).width+24;rect(x-12,y-23,w,32,'#101a28',7);text(t,x,y,16,color);}
  function gradient(x0,y0,x1,y1,stops) {var g=ctx.createLinearGradient(x0,y0,x1,y1);stops.forEach(function(s){g.addColorStop(s[0],s[1]);});return g;}
  function background(s) {
    ctx.fillStyle='#05070d';ctx.fillRect(0,0,W,760);
    var glow=ctx.createRadialGradient(W*.48,365,15,W*.48,365,W*.56);
    glow.addColorStop(0,'#11202d');glow.addColorStop(1,'#05070d');
    ctx.fillStyle=glow;ctx.fillRect(0,0,W,760);
    for(var x=30;x<W;x+=40)for(var y=100;y<630;y+=40)circle(x,y,1,'#7392b016');
    line(24,680,W-24,680,'#243243',1);
  }
  function barometer(s,q,time) {
    var px=mobile?148:W*.38, base=600, unit=310, a=s.angle*Math.PI/180;
    var pivotY=base+AirPressure.DEPTH*unit;
    var top={x:px+AirPressure.LENGTH*unit*Math.sin(a),y:pivotY-AirPressure.LENGTH*unit*Math.cos(a)};
    var end={x:px+(q.height+AirPressure.DEPTH)*unit*Math.tan(a),y:base-q.height*unit};
    // 支架与量尺固定竖直，读数零点始终是槽内自由液面。
    line(px-52,596,px-52,118,'#40536a',8);rect(px-90,625,110,12,'#40536a',5);
    line(px-53,151,px+12,151,'#40536a',6);
    rect(53,base-0.95*unit,44,.95*unit+10,'#152131',4);
    for(var i=0;i<=90;i+=5) {var y=base-i/100*unit;line(79,y,97,y,'#6b859b',1);if(i%10===0)text(String(i),75,y+4,11,'#91a6ba','right');}
    text('cm',70,base+30,16,dim,'center');
    // 以管口为转轴；内部液面保持水平（裁切斜管）。
    ctx.save();ctx.translate(px,pivotY);ctx.rotate(a);
    var metal=gradient(-16,0,16,0,[[0,'#5c96a7'],[.23,'#e6f6fa'],[.44,'#81b0c0'],[.8,'#264b5d'],[1,'#b6e1eb']]);
    rect(-17,-AirPressure.LENGTH*unit,34,AirPressure.LENGTH*unit,metal,16);
    rect(-12,-AirPressure.LENGTH*unit+6,24,AirPressure.LENGTH*unit,'#0b1522',11);
    ctx.beginPath();ctx.roundRect(-11,-AirPressure.LENGTH*unit+7,22,AirPressure.LENGTH*unit,10);ctx.clip();
    ctx.rotate(-a);ctx.translate(-px,-pivotY);
    ctx.fillStyle=gradient(px-20,0,px+420,0,[[0,'#cedbe2'],[.4,'#7e9caa'],[.7,'#eff7f9'],[1,'#859da9']]);
    ctx.fillRect(px-30,end.y,W,760-end.y);line(px-30,end.y,W,end.y,'#f5fcff',3);ctx.restore();
    // 宽槽近似，液面不因窄管内水银移动而变化。
    ctx.fillStyle=gradient(0,base,0,660,[[0,'#dde7e9'],[.15,'#a6bac3'],[1,'#567985']]);
    ctx.beginPath();ctx.moveTo(px-98,base);ctx.lineTo(px+99,base);ctx.lineTo(px+80,665);ctx.quadraticCurveTo(px,685,px-80,665);ctx.closePath();ctx.fill();
    ctx.strokeStyle='#abc6d4';ctx.lineWidth=4;ctx.stroke();
    ctx.beginPath();ctx.ellipse(px,base,99,12,0,0,Math.PI*2);ctx.fillStyle='#d8e6ea';ctx.fill();ctx.stroke();
    line(px-94,base,Math.max(px+110,end.x+52),base,blue,1,[6,5]);
    line(104,end.y,end.x+20,end.y,gold,2,[6,4]);
    arrow(118,base,118,end.y,gold,3);arrow(118,end.y,118,base,gold,3);
    text('竖直高度 h',W-32,base-133,17,dim,'right');
    text((q.height*100).toFixed(1)+' cm',W-32,base-101,26,gold,'right');
    text('水银槽 · 零高度',W-32,base+50,17,dim,'right');
    var vacX=(top.x+end.x)/2,vacY=(top.y+end.y)/2;
    text(s.ratio===0?'上端近似真空':'上端含有气体',W-32,158,17,blue,'right');
    line(W-170,170,vacX+15,vacY, '#3d6379',1,[4,4]);
    text('沿管长度 '+(q.length*100).toFixed(1)+' cm',W-32,base-62,17,ink,'right');
    // 大气在开放液面上施压；轻微脉动仅提示方向，无真实动力学含义。
    for(var j=0;j<3;j++){var x=px-75+j*63;arrow(x,base-55-3*Math.sin(time*2),x,base-15,blue,3);}
    text('蓝色箭头：大气施压',32,94,15,blue);
    circle(top.x,top.y,23,'#ffc94a30');circle(top.x,top.y,8,gold);
    text('拖动管顶',top.x-22,top.y-30,16,gold,'right');
    hits.tube={x:top.x,y:top.y,r:Math.max(38,24/scale)};hits.pivot={x:px,y:pivotY};
    text('偏离竖直 '+s.angle.toFixed(0)+'°',W-32,111,17,ink,'right');
    text('p外 = p管内 + ρgh',32,64,18,dim);
  }
  function hemispheres(s,q,time) {
    var cx=W/2,cy=360,r=(mobile?112:140)*s.radius/15,gap=s.separated?(mobile?40:58):0;
    var copper=gradient(cx-r,cy-r,cx+r,cy+r,[[0,'#ffe3a0'],[.22,'#c99754'],[.5,'#8e572d'],[.75,'#dfb36a'],[1,'#704528']]);
    [-1,1].forEach(function(side){
      var x=cx+side*gap;
      ctx.save();ctx.beginPath();ctx.rect(side<0?0:x,cy-r-20,side<0?x:W,2*r+40);ctx.clip();
      ctx.beginPath();ctx.ellipse(x,cy,r,r,0,0,Math.PI*2);ctx.fillStyle=copper;ctx.fill();ctx.lineWidth=4;ctx.strokeStyle='#ffe0a1';ctx.stroke();
      // 金属表面经线增强球形辨识。
      ctx.beginPath();ctx.ellipse(x,cy,r*.65,r*.95,0,0,Math.PI*2);ctx.strokeStyle='#ffe6af45';ctx.lineWidth=2;ctx.stroke();ctx.restore();
      rect(x-5,cy-r-5,10,r*2+10,'#e8c283',3);
      var hx=x+side*(r+26);
      ctx.beginPath();ctx.ellipse(hx,cy,29,18,0,0,Math.PI*2);ctx.lineWidth=9;ctx.strokeStyle='#cca45e';ctx.stroke();
      // 外界压力指向球面，拉力向外。
      for(var j=-1;j<=1;j++){var ay=cy+j*r*.46,ax=x+side*(r+65);arrow(ax,ay,ax-side*43,ay,blue,3);}
      if(s.pull>0)arrow(hx,cy,hx+side*Math.min(mobile?35:80,20+s.pull/150),cy,gold,5);
      hits[side<0?'left':'right']={x:hx,y:cy,r:Math.max(42,24/scale)};
    });
    // 阀门连至下方抽气口。
    var vx=cx+gap+r*.55;
    line(vx,cy+r*.78,vx,546,'#b99b6b',12);
    rect(vx-22,521,44,24,'#735b39',5);line(vx,510,vx,550,'#f0cc76',4);line(vx-24,512,vx+24,512,s.ratio<.95?gold:blue,7);
    hits.valve={x:vx,y:524,r:Math.max(34,24/scale)};
    text(s.separated?'已通气 · 在设置中合拢':s.ratio===1?'点阀门关闭并抽气':'点阀门通气',vx,594,17,blue,'center');
    text('铜半球 · 剖分面半径 '+s.radius+' cm',cx,115,18,ink,'center');
    text(s.separated?'已经拉开：空气进入，压强差消失':s.ratio===1?'已通气：内外等压':s.pull>0?'仍压紧：拉力未超过所需值':'抽去部分空气后，外界大气压紧半球',cx,153,17,s.separated?gold:blue,'center');
    text('外界 '+(q.pressure/1000).toFixed(1)+' kPa',32,cy+r+55,17,blue);
    text('内部 '+(q.inside/1000).toFixed(1)+' kPa',W-32,cy+r+55,17,ink,'right');
    text('每侧 F = (p外 − p内) × πr²',cx,675,19,gold,'center');
    text('所需拉力 '+q.force.toFixed(0)+' N / 侧',cx,717,18,ink,'center');
  }
  function draw(canvas,s,q,time) {
    c=canvas;ctx=c.getContext('2d');var box=c.getBoundingClientRect(),dpr=Math.min(devicePixelRatio||1,2);
    if(c.width!==Math.round(box.width*dpr)||c.height!==Math.round(box.height*dpr)){c.width=Math.round(box.width*dpr);c.height=Math.round(box.height*dpr);}
    mobile=box.width<700;W=mobile?600:940;H=760;
    scale=Math.min(box.width/W,Math.max(180,box.height-258)/H);ox=(box.width-W*scale)/2;oy=136+(box.height-258-H*scale)/2;
    ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,box.width,box.height);
    ctx.fillStyle='#05070d';ctx.fillRect(0,0,box.width,box.height);
    ctx.translate(ox,oy);ctx.scale(scale,scale);hits={};background(s);
    if(s.scene==='barometer')barometer(s,q,time);else hemispheres(s,q,time);
    return hits;
  }
  function point(e) {var b=c.getBoundingClientRect();return {x:(e.clientX-b.left-ox)/scale,y:(e.clientY-b.top-oy)/scale};}
  function hit(p) {return ['tube','left','right','valve'].find(function(k){var h=hits[k];return h&&Math.hypot(p.x-h.x,p.y-h.y)<h.r;});}
  window.AirDraw={draw:draw,point:point,hit:hit,getHits:function(){return hits;}};
})();
