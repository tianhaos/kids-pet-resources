/* 静态教学计算；SI单位，计算不访问DOM。 */
(function () {
  'use strict';
  var RHO = 13595.1, G = 9.80665, P0 = 101325, LENGTH = 1.5, DEPTH = 0.08;
  function clamp(x, a, b) { return Math.max(a, Math.min(b, x)); }
  // 对流层标准大气（0—5000m），不代表当地实时天气。
  function atmosphere(z) { return P0 * Math.pow(1 - 0.0065 * clamp(z, 0, 5000) / 288.15, G / (287.05287 * 0.0065)); }
  function solve(s) {
    var p = atmosphere(s.altitude), inside = p * clamp(s.ratio, 0, 1);
    var h = (p - inside) / (RHO * G), a = s.angle * Math.PI / 180;
    var radius = s.radius / 100, area = Math.PI * radius * radius;
    return { pressure: p, inside: inside, difference: p - inside, height: h,
      length: h / Math.cos(a), wetLength: (h + DEPTH) / Math.cos(a),
      topHeight: LENGTH * Math.cos(a) - DEPTH,
      force: (p - inside) * area, area: area };
  }
  window.AirPressure = { RHO: RHO, G: G, P0: P0, LENGTH: LENGTH, DEPTH: DEPTH, clamp: clamp, atmosphere: atmosphere, solve: solve };
})();
