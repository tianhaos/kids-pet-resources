// 动植物细胞的结构：各结构的资料（分布、膜、功能、比喻）、两种细胞的对比、判断练习（纯数据与计算，不碰 DOM）
// 层次 lv：1 = 初中（光学显微镜下的基本结构，含线粒体）；2 = 高中必修 1 新增的亚显微结构
(function () {
  // where：p 植物细胞、a 动物细胞（高等植物/一般动物细胞）；mem：膜结构；lm：光学显微镜下能否看到
  var ORGS = [
    { id: 'wall', name: '细胞壁', lv: 1, p: true, a: false, mem: '不是膜结构', col: '#b8c46a',
      fn: '对细胞起保护和支持作用。',
      fn2: '主要由纤维素和果胶构成，对植物细胞起支持与保护作用；细胞壁是全透性的，不能控制物质进出。',
      lm: '能看到', where: '植物细胞有，动物细胞没有' },
    { id: 'membrane', name: '细胞膜', lv: 1, p: true, a: true, mem: '单层膜', col: '#ff9ec7',
      fn: '控制物质进出细胞：有用的物质能进入，有害的物质不能轻易进入，代谢废物能排出。',
      fn2: '主要由脂质（磷脂）和蛋白质组成。将细胞与外界环境分隔开，控制物质进出细胞，进行细胞间的信息交流。',
      lm: '动物细胞能看到边界；植物细胞的细胞膜紧贴细胞壁，不易看清', where: '动植物细胞都有' },
    { id: 'cytoplasm', name: '细胞质', lv: 1, p: true, a: true, mem: '—', col: '#5fb3a8',
      fn: '细胞膜以内、细胞核以外的部分，是流动的，加快了细胞与外界环境的物质交换。',
      fn2: '包括细胞质基质和细胞器。细胞质基质呈溶胶状，是许多化学反应进行的场所（细胞代谢的主要场所）。',
      lm: '能看到；黑藻叶片中可借叶绿体的运动观察细胞质的流动', where: '动植物细胞都有' },
    { id: 'nucleus', name: '细胞核', lv: 1, p: true, a: true, mem: '双层膜（核膜，有核孔）', col: '#a07be0',
      fn: '含有遗传物质（DNA），是细胞的控制中心，控制着生物的发育和遗传。',
      fn2: '遗传信息库，是细胞代谢和遗传的控制中心。由核膜（双层膜，有核孔）、核仁、染色质等组成；核孔实现核质之间频繁的物质交换和信息交流。',
      lm: '能看到，用碘液等染色后更清楚', alias: '遗传信息库', where: '动植物细胞都有（哺乳动物成熟的红细胞等少数细胞没有）' },
    { id: 'vacuole', name: '液泡', lv: 1, p: true, a: false, mem: '单层膜', col: '#4fc3f7',
      fn: '内有细胞液，溶解着糖分、色素等多种物质。西瓜的甜味、花瓣的颜色主要来自液泡。',
      fn2: '主要存在于植物细胞中，内有细胞液，含糖类、无机盐、色素和蛋白质等；可以调节植物细胞内的环境，充盈的液泡还可以使植物细胞保持坚挺。成熟植物细胞有一个大的中央液泡。',
      lm: '能看到（紫色洋葱鳞片叶外表皮细胞的液泡带颜色）', where: '主要存在于植物细胞中（成熟植物细胞有大液泡）' },
    { id: 'chloroplast', name: '叶绿体', lv: 1, p: true, a: false, mem: '双层膜', col: '#5ccf6a',
      fn: '光合作用的场所，能把光能转变成化学能，储存在它所制造的有机物中。',
      fn2: '绿色植物能进行光合作用的细胞含有的细胞器，是“养料制造车间”和“能量转换站”。双层膜，内部有许多类囊体堆叠成的基粒，含有光合色素。',
      lm: '能看到（绿色颗粒）', alias: '能量转换器、养料制造车间', where: '只存在于植物体绿色部分的细胞中（叶肉细胞有，根尖细胞、洋葱鳞片叶表皮细胞没有）' },
    { id: 'mito', name: '线粒体', lv: 1, p: true, a: true, mem: '双层膜（内膜折叠成嵴）', col: '#ff7a59',
      fn: '呼吸作用的场所，能把有机物中的化学能释放出来，供细胞利用。',
      fn2: '有氧呼吸的主要场所，细胞生命活动所需的能量大约 95% 来自线粒体，是细胞的“动力车间”。双层膜，内膜向内折叠形成嵴。',
      lm: '很小，染色后在高倍镜下才能看到', alias: '能量转换器、动力车间', where: '动植物细胞都有' },
    { id: 'er', name: '内质网', lv: 2, p: true, a: true, mem: '单层膜', col: '#79b8ff',
      fn: '由膜围成的网状结构，是蛋白质等大分子物质的合成、加工场所和运输通道。',
      fn2: '由膜围成的管状、泡状或扁平囊状结构连接形成的网状结构。附着有核糖体的叫粗面内质网，与分泌蛋白的合成、加工有关；光面内质网与脂质的合成有关。',
      lm: '不能，亚显微结构（要用电子显微镜）', where: '动植物细胞都有' },
    { id: 'golgi', name: '高尔基体', lv: 2, p: true, a: true, mem: '单层膜', col: '#ffc94a',
      fn: '对来自内质网的蛋白质进行加工、分类和包装的“车间”及“发送站”。',
      fn2: '由扁平囊和囊泡组成，对来自内质网的蛋白质进行加工、分类和包装；在植物细胞中还与细胞壁的形成有关。',
      lm: '不能，亚显微结构（要用电子显微镜）', alias: '车间及发送站', where: '动植物细胞都有' },
    { id: 'ribosome', name: '核糖体', lv: 2, p: true, a: true, mem: '无膜', col: '#eef2f8',
      fn: '“生产蛋白质的机器”，是合成蛋白质的场所。',
      fn2: '没有膜的颗粒状小体，主要由 RNA 和蛋白质组成。有的附着在内质网上，有的游离在细胞质基质中。原核细胞也有核糖体。',
      lm: '不能，亚显微结构（要用电子显微镜）', alias: '生产蛋白质的机器', where: '动植物细胞都有' },
    { id: 'lysosome', name: '溶酶体', lv: 2, p: false, a: true, mem: '单层膜', col: '#e070d8',
      fn: '细胞的“消化车间”，内含多种水解酶。',
      fn2: '主要分布在动物细胞中，内部含有多种水解酶，能分解衰老、损伤的细胞器，吞噬并杀死侵入细胞的病毒或细菌。',
      lm: '不能，亚显微结构（要用电子显微镜）', alias: '消化车间', where: '主要分布在动物细胞中' },
    { id: 'centrosome', name: '中心体', lv: 2, p: false, a: true, mem: '无膜', col: '#f4e27a',
      fn: '由两个互相垂直排列的中心粒及周围物质组成，与细胞的有丝分裂有关。',
      fn2: '分布在动物和低等植物细胞中，由两个互相垂直排列的中心粒及周围物质组成，没有膜；与细胞的有丝分裂有关（发出星射线形成纺锤体）。',
      lm: '很小，结构要用电子显微镜观察', where: '动物细胞和低等植物细胞有，高等植物细胞没有' },
    { id: 'nucleolus', name: '核仁', lv: 2, p: true, a: true, mem: '无膜（细胞核内）', col: '#6a48b8', sub: 'nucleus',
      fn: '细胞核内颜色较深的小体，与某种 RNA 的合成以及核糖体的形成有关。',
      fn2: '细胞核内的球形小体，与某种 RNA（rRNA）的合成以及核糖体的形成有关。蛋白质合成旺盛的细胞核仁较大。',
      lm: '染色后能看到', where: '细胞核内' },
    { id: 'chromatin', name: '染色质', lv: 2, p: true, a: true, mem: '无膜（细胞核内）', col: '#d7c2ff', sub: 'nucleus',
      fn: '主要由 DNA 和蛋白质组成，容易被碱性染料染成深色；DNA 是遗传信息的载体。',
      fn2: '主要由 DNA 和蛋白质组成，容易被碱性染料染成深色。细胞分裂时，染色质高度螺旋化、缩短变粗成为染色体——染色质和染色体是同一物质在细胞不同时期的两种存在状态。',
      lm: '染色后能看到', where: '细胞核内' }
  ];
  var BY = {};
  ORGS.forEach(function (o) { BY[o.id] = o; });
  var TYPES_CELL = { plant: '植物细胞', animal: '动物细胞' };

  function get(id) { return BY[id] || null; }
  function has(type, id) { var o = BY[id]; return !!o && (type === 'plant' ? o.p : o.a); }
  // 某层次下要显示的结构
  function list(lv, type) {
    return ORGS.filter(function (o) { return o.lv <= lv && (!type || type === 'both' || has(type, o.id)); });
  }
  function memKind(id) {
    var m = BY[id].mem;
    return /双层/.test(m) ? 2 : /单层/.test(m) ? 1 : /无膜/.test(m) ? 0 : -1;
  }
  // 对比：植物细胞特有、动物细胞特有、共有
  function compare(lv) {
    var r = { plant: [], animal: [], both: [] };
    list(lv).forEach(function (o) {
      if (o.sub) return;
      (o.p && o.a ? r.both : o.p ? r.plant : r.animal).push(o.name);
    });
    return r;
  }
  // 按膜结构给细胞器分类（只算细胞器：不含细胞壁、细胞膜、细胞质、细胞核及核内结构）
  var NOT_ORGANELLE = ['wall', 'membrane', 'cytoplasm', 'nucleus', 'nucleolus', 'chromatin'];
  function byMembrane() {
    var r = { 2: [], 1: [], 0: [] };
    ORGS.forEach(function (o) { if (NOT_ORGANELLE.indexOf(o.id) < 0) r[memKind(o.id)].push(o.name); });
    return r;
  }

  // ---------- 判断练习 ----------
  var TYPES = ['name', 'func', 'diff', 'fact'];
  function pick(a, rnd) { return a[Math.floor(rnd() * a.length)]; }
  function shuffle(a, rnd) {
    for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(rnd() * (i + 1)), t = a[i]; a[i] = a[j]; a[j] = t; }
    return a;
  }
  function uniq(a) { return a.filter(function (x, i) { return a.indexOf(x) === i; }); }

  // 根据功能认结构：[描述, 答案 id, 层次]
  var FUNCS = [
    ['光合作用的场所，能把光能转变成化学能，储存在有机物中', 'chloroplast', 1],
    ['呼吸作用的场所，能把有机物中的化学能释放出来供细胞利用', 'mito', 1],
    ['控制物质进出细胞', 'membrane', 1],
    ['含有遗传物质，是细胞的控制中心', 'nucleus', 1],
    ['对植物细胞起保护和支持作用', 'wall', 1],
    ['内有细胞液，西瓜的甜味物质、花瓣的色素主要存在于这里', 'vacuole', 1],
    ['能够流动，加快细胞与外界环境的物质交换', 'cytoplasm', 1],
    ['被称为“生产蛋白质的机器”', 'ribosome', 2],
    ['细胞的“消化车间”，内含多种水解酶，能分解衰老、损伤的细胞器', 'lysosome', 2],
    ['对来自内质网的蛋白质进行加工、分类和包装的“车间”及“发送站”', 'golgi', 2],
    ['蛋白质等大分子物质的合成、加工场所和运输通道', 'er', 2],
    ['由两个互相垂直排列的中心粒及周围物质组成，与细胞的有丝分裂有关', 'centrosome', 2],
    ['有氧呼吸的主要场所，被称为细胞的“动力车间”', 'mito', 2],
    ['与某种 RNA 的合成以及核糖体的形成有关', 'nucleolus', 2],
    ['主要由 DNA 和蛋白质组成，容易被碱性染料染成深色', 'chromatin', 2],
    ['细胞代谢和遗传的控制中心', 'nucleus', 2]
  ];

  // 比较动植物细胞：[题干, 答案, 干扰项×3, 解析, 层次, 在模型里看的细胞]
  var DIFFS = [
    ['与人的口腔上皮细胞相比，洋葱鳞片叶内表皮细胞特有的结构是', '细胞壁和液泡',
      ['细胞壁、叶绿体和液泡', '细胞膜和细胞核', '叶绿体和线粒体'],
      '洋葱鳞片叶埋在土里、不见光，表皮细胞没有叶绿体，所以它比口腔上皮细胞多的只有细胞壁和液泡。这是常见的陷阱：不是所有植物细胞都有叶绿体。', 1, 'both'],
    ['菠菜叶肉细胞有、而人的肌肉细胞没有的结构是', '细胞壁、叶绿体和液泡',
      ['细胞壁和液泡', '细胞膜、细胞质和细胞核', '叶绿体和线粒体'],
      '叶肉细胞是绿色部分的植物细胞，有细胞壁、叶绿体和液泡，这三种是它比动物细胞多的结构；线粒体动植物细胞都有。', 1, 'both'],
    ['植物细胞和动物细胞都具有的结构是', '细胞膜、细胞质、细胞核和线粒体',
      ['细胞壁、细胞膜和细胞核', '细胞膜、叶绿体和线粒体', '细胞膜、液泡和细胞核'],
      '动植物细胞都有细胞膜、细胞质、细胞核，细胞质中都有线粒体；细胞壁、叶绿体、（大）液泡是植物细胞特有的。', 1, 'both'],
    ['植物叶肉细胞中的能量转换器是', '叶绿体和线粒体',
      ['只有叶绿体', '只有线粒体', '细胞核和液泡'],
      '叶绿体把光能转变成化学能储存在有机物中，线粒体把有机物中的化学能释放出来供细胞利用，二者都是能量转换器。', 1, 'plant'],
    ['动物细胞中的能量转换器是', '线粒体',
      ['叶绿体和线粒体', '叶绿体', '细胞核'],
      '动物细胞没有叶绿体，能量转换器只有线粒体。', 1, 'animal'],
    ['下列细胞中，没有叶绿体的是', '洋葱鳞片叶内表皮细胞',
      ['菠菜叶肉细胞', '黑藻叶片细胞', '天竺葵叶肉细胞'],
      '叶绿体只存在于植物体绿色部分的细胞中。洋葱鳞片叶表皮细胞、根尖细胞都没有叶绿体。', 1, 'plant'],
    ['下列细胞器中，具有双层膜的是', '线粒体和叶绿体',
      ['内质网和高尔基体', '核糖体和中心体', '液泡和溶酶体'],
      '具有双层膜的细胞器是线粒体和叶绿体（细胞核的核膜也是双层膜，但细胞核不叫细胞器）。', 2, 'plant'],
    ['下列细胞器中，没有膜结构的是', '核糖体和中心体',
      ['线粒体和叶绿体', '内质网和高尔基体', '液泡和溶酶体'],
      '核糖体和中心体没有膜；内质网、高尔基体、液泡、溶酶体是单层膜，线粒体、叶绿体是双层膜。', 2, 'animal'],
    ['高等植物细胞中没有、而动物细胞中有的细胞器是', '中心体',
      ['核糖体', '高尔基体', '线粒体'],
      '中心体分布在动物和低等植物细胞中，高等植物细胞没有；核糖体、高尔基体、线粒体动植物细胞都有。', 2, 'both'],
    ['下列都是具有单层膜的细胞器的一组是', '内质网、高尔基体、溶酶体、液泡',
      ['线粒体、叶绿体、高尔基体', '核糖体、中心体、内质网', '内质网、核糖体、液泡'],
      '单层膜细胞器：内质网、高尔基体、溶酶体、液泡；双层膜：线粒体、叶绿体；无膜：核糖体、中心体。', 2, 'both'],
    ['在植物细胞中，与细胞壁的形成有关的细胞器是', '高尔基体',
      ['内质网', '核糖体', '液泡'],
      '高尔基体在动物细胞中与分泌物的形成有关，在植物细胞中与细胞壁的形成有关。', 2, 'plant']
  ];

  // 叙述判断：选出错误的一项
  var TRUE_ST = [
    ['细胞膜能控制物质进出细胞', 1],
    ['叶绿体和线粒体都是细胞中的能量转换器', 1],
    ['细胞核中含有遗传物质', 1],
    ['动物细胞没有细胞壁', 1],
    ['西瓜的甜味物质主要存在于液泡中', 1],
    ['线粒体是有氧呼吸的主要场所', 2],
    ['核糖体没有膜结构，是合成蛋白质的场所', 2],
    ['溶酶体内含有多种水解酶，主要分布在动物细胞中', 2],
    ['附着有核糖体的内质网叫粗面内质网', 2],
    ['核孔能实现核质之间频繁的物质交换和信息交流', 2],
    ['染色质和染色体是同一物质在细胞不同时期的两种存在状态', 2]
  ];
  var FALSE_ST = [
    ['所有植物细胞都有叶绿体', '叶绿体只存在于植物体绿色部分的细胞中，例如洋葱鳞片叶表皮细胞、根尖细胞就没有叶绿体。', 1],
    ['细胞壁能控制物质进出细胞', '控制物质进出的是细胞膜；细胞壁是全透性的，主要起保护和支持作用。', 1],
    ['动物细胞也有叶绿体，能进行光合作用', '动物细胞没有叶绿体，不能进行光合作用。', 1],
    ['植物细胞没有线粒体', '植物细胞也有线粒体，呼吸作用在线粒体中进行。', 1],
    ['中心体存在于所有植物细胞中', '中心体分布在动物和低等植物细胞中，高等植物细胞没有中心体。', 2],
    ['核糖体具有单层膜', '核糖体和中心体都没有膜结构。', 2],
    ['细胞核是细胞代谢的主要场所', '细胞代谢的主要场所是细胞质基质；细胞核是细胞代谢和遗传的控制中心。', 2],
    ['高尔基体是“生产蛋白质的机器”', '“生产蛋白质的机器”是核糖体；高尔基体对来自内质网的蛋白质进行加工、分类和包装。', 2],
    ['叶绿体和线粒体都只有一层膜', '叶绿体和线粒体都具有双层膜。', 2]
  ];

  // 一题：{ type, prompt, options, answer, explain, show: { type 细胞, sel 结构 id }, mark（name 题在 3D 中高亮的结构） }
  // lv：1 只出初中题，2 全部；no3d：不出需要 3D 画面的看图题
  function quiz(rnd, prev, only, lv, no3d) {
    lv = lv || 2;
    for (var tries = 0; tries < 30; tries++) {
      var type = only || pick(no3d ? TYPES.slice(1) : TYPES, rnd);
      if (no3d && type === 'name') type = 'func';
      var q = make(type, rnd, lv);
      if (!q) continue;
      if (prev && prev.prompt === q.prompt && prev.answer === q.answer) continue;
      if (q.options.length !== 4 || uniq(q.options).length !== 4 || q.options.indexOf(q.answer) < 0) continue;
      q.type = type;
      q.options = shuffle(q.options.slice(), rnd);
      return q;
    }
    return null;
  }
  function names(ids) { return ids.map(function (id) { return BY[id].name; }); }
  function make(type, rnd, lv) {
    if (type === 'name') {
      var ct = rnd() < 0.5 ? 'plant' : 'animal';
      var pool = list(lv, ct).filter(function (o) { return o.id !== 'cytoplasm' && o.id !== 'chromatin'; });
      var ans = pick(pool, rnd);
      var others = shuffle(pool.filter(function (o) { return o.id !== ans.id; }), rnd).slice(0, 3);
      return {
        prompt: '图中' + TYPES_CELL[ct] + '里闪烁高亮的结构是',
        answer: ans.name, options: [ans.name].concat(names(others.map(function (o) { return o.id; }))),
        explain: ans.name + '：' + ans.fn, mark: ans.id, cell: ct, show: { type: ct, sel: ans.id }
      };
    }
    if (type === 'func') {
      var fs = FUNCS.filter(function (f) { return f[2] <= lv; }), f = pick(fs, rnd), o = BY[f[1]];
      var pool2 = list(lv).filter(function (x) { return x.id !== o.id && !(o.id === 'nucleus' && x.sub) && !(o.sub && x.id === 'nucleus'); });
      // 干扰项优先取同一层次的结构
      pool2.sort(function (a, b) { return Math.abs(a.lv - f[2]) - Math.abs(b.lv - f[2]) || rnd() - 0.5; });
      var ds = shuffle(pool2.slice(0, 6), rnd).slice(0, 3);
      return {
        prompt: '下列细胞结构中，' + f[0] + '的是',
        answer: o.name, options: [o.name].concat(names(ds.map(function (x) { return x.id; }))),
        explain: o.name + '：' + (lv > 1 ? o.fn2 : o.fn), show: { type: o.p ? 'plant' : 'animal', sel: o.id }
      };
    }
    if (type === 'diff') {
      var d = pick(DIFFS.filter(function (x) { return x[4] <= lv; }), rnd);
      return {
        prompt: d[0], answer: d[1], options: [d[1]].concat(d[2]), explain: d[3],
        show: { type: d[5], sel: null }
      };
    }
    // fact：选出错误的叙述
    var fl = pick(FALSE_ST.filter(function (x) { return x[2] <= lv; }), rnd);
    var tr = shuffle(TRUE_ST.filter(function (x) { return x[1] <= lv; }), rnd).slice(0, 3).map(function (x) { return x[0]; });
    return {
      prompt: '下列关于动植物细胞结构的叙述，错误的是',
      answer: fl[0], options: tr.concat([fl[0]]), explain: fl[1], show: { type: 'both', sel: null }
    };
  }

  window.Cell = {
    ORGS: ORGS, TYPES: TYPES, CELLS: TYPES_CELL, NOT_ORGANELLE: NOT_ORGANELLE,
    FUNCS: FUNCS, DIFFS: DIFFS, TRUE_ST: TRUE_ST, FALSE_ST: FALSE_ST,
    get: get, has: has, list: list, memKind: memKind, compare: compare, byMembrane: byMembrane, quiz: quiz
  };
})();
