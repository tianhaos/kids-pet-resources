// 动植物细胞的结构：three.js 场景（植物细胞、动物细胞，可单独看或并排对比；剖开、点选、高亮、名称标注、细胞质流动）
// 单位为示意长度（植物细胞约 24 × 16 × 14），细胞器大小、数量不按真实比例；y 向上
// 剖切面跟随相机：保留离相机较远的一半（ĉ·(p − 细胞中心) ≤ c，ĉ 为由观察中心指向相机的方向）
(function () {
  var C = window.Cell;
  var V3 = THREE.Vector3, Y = new V3(0, 1, 0);

  function rng(seed) {
    return function () {
      seed |= 0; seed = seed + 0x6D2B79F5 | 0;
      var t = Math.imul(seed ^ seed >>> 15, 1 | seed);
      t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
      return ((t ^ t >>> 14) >>> 0) / 4294967296;
    };
  }
  function sp(v, e) { return v < 0 ? -Math.pow(-v, e) : Math.pow(v, e); }
  // 超椭球 |x/a|^(2/e) + |y/b|^(2/e) + |z/c|^(2/e) = 1（e < 1 时偏方，像植物细胞）
  function Super(a, b, c, e, cx) { return { a: a, b: b, c: c, e: e, cx: cx || 0, cy: 0, cz: 0 }; }
  function superAt(S, d, out) { return (out || new V3()).set(S.cx + S.a * sp(d.x, S.e), S.cy + S.b * sp(d.y, S.e), S.cz + S.c * sp(d.z, S.e)); }
  function superF(S, p, k) {
    k = k || 1;
    var e = 2 / S.e;
    return Math.pow(Math.abs((p.x - S.cx) / (S.a * k)), e) + Math.pow(Math.abs((p.y - S.cy) / (S.b * k)), e) + Math.pow(Math.abs((p.z - S.cz) / (S.c * k)), e);
  }
  function superN(S, p) {
    var e = 2 / S.e - 1, x = (p.x - S.cx) / S.a, y = (p.y - S.cy) / S.b, z = (p.z - S.cz) / S.c;
    return new V3(sp(x, e) / S.a, sp(y, e) / S.b, sp(z, e) / S.c).normalize();
  }
  // 动物细胞膜：略不规则的椭球，沿方向 d 的半径
  function blobR(d) {
    var r = 1 / Math.sqrt(d.x * d.x / 92 + d.y * d.y / 67 + d.z * d.z / 77);
    return r * (1 + 0.035 * Math.sin(3 * Math.atan2(d.z, d.x) + 0.7) * (1 - d.y * d.y) + 0.02 * Math.sin(4 * d.y + 2 * d.x));
  }
  // 由单位球变形出几何体
  function morph(fn, ws, hs) {
    var g = new THREE.SphereGeometry(1, ws || 72, hs || 48), p = g.attributes.position, d = new V3(), o = new V3();
    for (var i = 0; i < p.count; i++) {
      d.fromBufferAttribute(p, i).normalize();
      fn(d, o);
      p.setXYZ(i, o.x, o.y, o.z);
    }
    g.computeVertexNormals();
    return g;
  }
  function fib(n) {
    var out = [], ga = Math.PI * (3 - Math.sqrt(5));
    for (var i = 0; i < n; i++) {
      var y = 1 - 2 * (i + 0.5) / n, r = Math.sqrt(1 - y * y);
      out.push(new V3(Math.cos(ga * i) * r, y, Math.sin(ga * i) * r));
    }
    return out;
  }

  // 植物细胞几何（细胞壁外表面、细胞膜、液泡、细胞核、叶绿体所在的“中层”）
  var PL = {
    wall: Super(12, 8, 7, 0.4), mem: 0.95, vac: Super(7.6, 5.4, 4.5, 0.45, 2.4),
    N: new V3(-8, 0.6, 0), NR: new V3(1.9, 2.4, 2.5), mid: Super(9.5, 6.6, 5.6, 0.4, 1.2), band: [-3.4, 4.6]
  };
  var AN = { N: new V3(-0.6, 0.4, 0), NR: 3, golgi: new V3(4.4, 1.6, -1.6), cs: new V3(2.4, -3.8, -2.6) };

  window.CellScene = function (container) {
    var renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.localClippingEnabled = true;
    container.appendChild(renderer.domElement);
    var canvas = renderer.domElement;
    canvas.id = 'view3d';

    var labelRenderer = new THREE.CSS2DRenderer();
    var ls = labelRenderer.domElement.style;
    ls.position = 'absolute'; ls.top = '0'; ls.left = '0'; ls.pointerEvents = 'none'; ls.zIndex = '2';
    container.appendChild(labelRenderer.domElement);

    var scene = new THREE.Scene();
    scene.background = new THREE.Color('#05070d');
    var camera = new THREE.PerspectiveCamera(32, 1, 1, 2000);
    scene.add(camera);
    scene.add(new THREE.AmbientLight(0xffffff, 0.55));
    var key = new THREE.DirectionalLight(0xffffff, 0.75);
    key.position.set(-5, 7, 8);
    camera.add(key);
    var rim = new THREE.DirectionalLight(0x9fc8ff, 0.3);
    rim.position.set(6, -4, -5);
    camera.add(rim);

    var controls = new THREE.OrbitControls(camera, canvas);
    controls.enableDamping = true;
    controls.dampingFactor = 0.08;
    controls.enablePan = false;
    controls.autoRotateSpeed = 0.6;
    var moved = false;
    controls.addEventListener('start', function () { controls.autoRotate = false; moved = true; });

    var sphere = new THREE.SphereGeometry(1, 20, 14);
    var smallSphere = new THREE.SphereGeometry(1, 6, 4);
    var capsule = new THREE.CapsuleGeometry(0.42, 1.3, 6, 12);
    var cyl = new THREE.CylinderGeometry(0.22, 0.22, 1.1, 12);
    var pore = new THREE.TorusGeometry(0.2, 0.07, 6, 12);

    // ---------- 每个细胞 ----------
    function makeCell(type) {
      var cell = { type: type, g: new THREE.Group(), plane: new THREE.Plane(new V3(0, 0, -1), 1e6), mats: {}, items: {}, labels: {}, anchors: {}, stream: [], picks: [] };
      cell.CLIP = [cell.plane];
      scene.add(cell.g);
      var R = rng(type === 'plant' ? 7 : 11);

      function mat(id, col, o) {
        o = o || {};
        var m = new THREE.MeshStandardMaterial({
          color: new THREE.Color(col), roughness: o.rough == null ? 0.6 : o.rough, metalness: 0,
          transparent: true, opacity: o.op == null ? 1 : o.op, depthWrite: o.dw == null ? true : o.dw,
          side: o.side == null ? THREE.DoubleSide : o.side, clippingPlanes: cell.CLIP
        });
        m.userData = { op: m.opacity, dw: m.depthWrite, col: new THREE.Color(col) };
        (cell.mats[id] = cell.mats[id] || []).push(m);
        return m;
      }
      function add(id, obj, lv) {
        obj.userData.id = id;
        obj.userData.lv = lv || C.get(id).lv;
        (cell.items[id] = cell.items[id] || []).push(obj);
        cell.g.add(obj);
        if (obj.isMesh) cell.picks.push(obj);
        return obj;
      }
      function mesh(id, geo, m, pos, lv) {
        var o = new THREE.Mesh(geo, m);
        if (pos) o.position.copy(pos);
        return add(id, o, lv);
      }
      function label(id) {
        var el = document.createElement('div');
        el.className = 'lab';
        el.textContent = C.get(id).name;
        var o = new THREE.CSS2DObject(el);
        cell.g.add(o);
        cell.labels[id] = o;
      }
      cell.mesh = mesh; cell.mat = mat; cell.add = add; cell.R = R;
      if (type === 'plant') buildPlant(cell); else buildAnimal(cell);
      C.ORGS.forEach(function (o) { if (cell.items[o.id]) label(o.id); });
      return cell;
    }

    // 内质网：围着细胞核的几层弯曲膜片（局部球壳，带起伏），粗面内质网上附着核糖体
    function erSheets(cell, N, S, layers, phi0, phiL, th0, thL) {
      var m = cell.mat('er', C.get('er').col, { rough: 0.5 }), pts = [];
      layers.forEach(function (k, j) {
        var g = new THREE.SphereGeometry(1, 48, 24, phi0 + j * 0.15, phiL - j * 0.3, th0 + j * 0.08, thL - j * 0.16);
        var p = g.attributes.position, v = new V3();
        for (var i = 0; i < p.count; i++) {
          v.fromBufferAttribute(p, i);
          var w = 1 + 0.045 * Math.sin(7 * Math.atan2(v.z, v.x) + j * 1.7) * Math.sin(5 * Math.acos(Math.max(-1, Math.min(1, v.y))) + j);
          p.setXYZ(i, v.x * S.x * k * w, v.y * S.y * k * w, v.z * S.z * k * w);
          if (i % 7 === 3) pts.push(new V3(v.x * S.x * k * w, v.y * S.y * k * w, v.z * S.z * k * w).multiplyScalar(1.03).add(N));
        }
        g.computeVertexNormals();
        cell.mesh('er', g, m, N);
      });
      cell.anchors.er = pts.filter(function (_, i) { return i % 9 === 0; });
      return pts;
    }
    // 核糖体：一个 InstancedMesh（附着的 + 游离的）
    function ribosomes(cell, pts) {
      var im = new THREE.InstancedMesh(smallSphere, cell.mat('ribosome', C.get('ribosome').col, { rough: 0.4 }), pts.length);
      var mm = new THREE.Matrix4();
      pts.forEach(function (p, i) { mm.makeScale(0.13, 0.13, 0.13).setPosition(p); im.setMatrixAt(i, mm); });
      cell.add('ribosome', im);
      cell.anchors.ribosome = pts.filter(function (_, i) { return i % 6 === 0; });
    }
    // 高尔基体：一叠弯曲的扁平囊（同心球冠，边缘膨大）+ 囊泡；axis 为凸面朝向
    function golgi(cell, pos, axis, k) {
      var m = cell.mat('golgi', C.get('golgi').col, { rough: 0.45 }), g = new THREE.Group(), th = 0.55;
      for (var j = 0; j < 5; j++) {
        var r = (2.0 + j * 0.3) * k, t = th - j * 0.03;
        var cap = new THREE.Mesh(new THREE.SphereGeometry(r, 28, 6, 0, Math.PI * 2, 0, t), m);
        cap.position.y = -2.0 * k;
        var rimT = new THREE.Mesh(new THREE.TorusGeometry(r * Math.sin(t), 0.1 * k + 0.04, 6, 32), m);
        rimT.rotation.x = Math.PI / 2;
        rimT.position.y = r * Math.cos(t) - 2.0 * k;
        [cap, rimT].forEach(function (o) { o.userData.id = 'golgi'; o.userData.lv = 2; g.add(o); cell.picks.push(o); });
      }
      for (j = 0; j < 7; j++) {
        var a = j / 7 * Math.PI * 2 + 0.3, rr = (2.9 + 0.5 * cell.R()) * k * Math.sin(th);
        var ves = new THREE.Mesh(sphere, m);
        ves.scale.setScalar((0.22 + 0.08 * cell.R()) * k);
        ves.position.set(Math.cos(a) * rr * 1.15, -0.5 * k - 0.6 * cell.R() * k, Math.sin(a) * rr * 1.15);
        ves.userData.id = 'golgi'; ves.userData.lv = 2; g.add(ves); cell.picks.push(ves);
      }
      g.position.copy(pos);
      g.quaternion.setFromUnitVectors(Y, axis.clone().normalize());
      cell.add('golgi', g);
      cell.picks = cell.picks.filter(function (o) { return o !== g; });
      cell.anchors.golgi = [pos.clone().addScaledVector(axis.clone().normalize(), 0.3)];
    }
    // 细胞核：核膜（外表面）、核质（内表面，剖开后看到实心）、核孔、核仁、染色质
    function nucleus(cell, N, S) {
      var col = C.get('nucleus').col;
      var env = cell.mesh('nucleus', sphere, cell.mat('nucleus', col, { side: THREE.FrontSide, rough: 0.5 }), N);
      env.scale.copy(S); env.geometry = new THREE.SphereGeometry(1, 40, 28);
      var inner = cell.mesh('nucleus', env.geometry, cell.mat('nucleus', '#3d2a66', { side: THREE.BackSide }), N);
      inner.scale.copy(S).multiplyScalar(0.94);
      // 核孔（高中）
      var pm = cell.mat('nucleus', '#2b1d4a', { rough: 0.8 });
      fib(26).forEach(function (d) {
        var p = new V3(d.x * S.x, d.y * S.y, d.z * S.z).multiplyScalar(1.005).add(N);
        var n = new V3(d.x / S.x, d.y / S.y, d.z / S.z).normalize();
        var o = cell.mesh('nucleus', pore, pm, p, 2);
        o.quaternion.setFromUnitVectors(new V3(0, 0, 1), n);
      });
      var nl = cell.mesh('nucleolus', sphere, cell.mat('nucleolus', C.get('nucleolus').col, { rough: 0.7 }), N.clone().add(new V3(S.x * 0.15, S.y * 0.2, S.z * 0.1)));
      nl.scale.setScalar(Math.min(S.x, S.y, S.z) * 0.36);
      cell.anchors.nucleolus = [nl.position.clone()];
      // 染色质：核内细丝（随机游走）
      var pts = [], R = cell.R, v = new V3();
      for (var t = 0; t < 7; t++) {
        v.set(R() - 0.5, R() - 0.5, R() - 0.5).multiplyScalar(1.2);
        var dir = new V3(R() - 0.5, R() - 0.5, R() - 0.5).normalize();
        for (var i = 0; i < 46; i++) {
          var a = v.clone();
          dir.add(new V3(R() - 0.5, R() - 0.5, R() - 0.5).multiplyScalar(0.9)).normalize();
          v.addScaledVector(dir, 0.13);
          if (v.length() > 0.8) v.multiplyScalar(0.8 / v.length());
          pts.push(new V3(a.x * S.x, a.y * S.y, a.z * S.z).add(N), new V3(v.x * S.x, v.y * S.y, v.z * S.z).add(N));
        }
      }
      var lm = new THREE.LineBasicMaterial({ color: C.get('chromatin').col, transparent: true, opacity: 0.85, clippingPlanes: cell.CLIP });
      lm.userData = { op: 0.85, dw: true };
      (cell.mats.chromatin = []).push(lm);
      add2(cell, 'chromatin', new THREE.LineSegments(new THREE.BufferGeometry().setFromPoints(pts), lm));
      cell.anchors.chromatin = pts.filter(function (_, i) { return i % 40 === 0; });
      cell.anchors.nucleus = [N.clone()];
      cell.nucBox = { N: N, S: S };
    }
    function add2(cell, id, obj) { obj.userData.id = id; obj.userData.lv = C.get(id).lv; (cell.items[id] = cell.items[id] || []).push(obj); cell.g.add(obj); }

    function mito(cell, pos, axis, s) {
      var o = cell.mesh('mito', capsule, cell.mats.mito ? cell.mats.mito[0] : cell.mat('mito', C.get('mito').col, { rough: 0.5 }), pos);
      o.quaternion.setFromUnitVectors(Y, axis);
      o.scale.setScalar(s || 1);
      return o;
    }

    function buildPlant(cell) {
      var W = PL.wall, R = cell.R;
      // 细胞壁（外、内两层表面）、细胞膜、细胞质（膜内表面）
      var wm = cell.mat('wall', C.get('wall').col, { op: 0.42, dw: false, rough: 0.8 });
      var wallGeo = morph(function (d, o) { superAt(W, d, o); });
      cell.mesh('wall', wallGeo, wm).renderOrder = 4;
      var wi = cell.mesh('wall', wallGeo, wm); wi.scale.setScalar(0.968); wi.renderOrder = 4;
      var mem = cell.mesh('membrane', wallGeo, cell.mat('membrane', C.get('membrane').col, { op: 0.38, dw: false, side: THREE.FrontSide }));
      mem.scale.setScalar(PL.mem); mem.renderOrder = 3;
      var cyto = cell.mesh('cytoplasm', wallGeo, cell.mat('cytoplasm', '#1b2b2f', { side: THREE.BackSide, rough: 0.9 }));
      cyto.scale.setScalar(PL.mem - 0.006);
      // 液泡
      var V = PL.vac;
      var vac = cell.mesh('vacuole', morph(function (d, o) { superAt(Super(V.a, V.b, V.c, V.e), d, o); }, 56, 36),
        cell.mat('vacuole', C.get('vacuole').col, { op: 0.36, dw: false, rough: 0.2 }), new V3(V.cx, 0, 0));
      vac.renderOrder = 2;
      nucleus(cell, PL.N, PL.NR);
      var pts = erSheets(cell, PL.N, PL.NR, [1.3, 1.55], -1.25, 2.5, 0.5, 2.1);
      // 叶绿体、线粒体：在液泡和细胞膜之间的一层里，细胞质流动时绕液泡（绕 y 轴）转动；避开细胞核所在的一段高度
      var M = PL.mid, cm = cell.mat('chloroplast', C.get('chloroplast').col, { rough: 0.55 }), placed = [];
      var dirs = fib(170), mitoM = cell.mat('mito', C.get('mito').col, { rough: 0.5 });
      function free(p, r) { return placed.every(function (q) { return q.distanceTo(p) > r; }); }
      dirs.forEach(function (d, i) {
        var p = superAt(M, d);
        if (p.y > PL.band[0] && p.y < PL.band[1]) return;
        if (!free(p, 2.1)) return;
        placed.push(p);
        var o = cell.mesh(i % 5 === 2 ? 'mito' : 'chloroplast', sphere, i % 5 === 2 ? mitoM : cm);
        if (i % 5 === 2) { o.geometry = capsule; o.scale.setScalar(0.85); } else o.scale.set(1.05, 0.38, 0.72);
        cell.stream.push({ o: o, d: d.clone(), chl: i % 5 !== 2 });
      });
      // 核附近一圈高度里的线粒体（不随流动）
      dirs.forEach(function (d) {
        var p = superAt(M, d);
        if (p.y < PL.band[0] + 0.8 || p.y > PL.band[1] - 0.8 || p.x < -4.2 || !free(p, 2.4) || p.distanceTo(new V3(3, 0.6, -5.5)) < 3.4) return;
        placed.push(p);
        var t = new V3().crossVectors(superN(M, p), Y).normalize();
        mito(cell, p, t.lengthSq() ? t : new V3(1, 0, 0), 0.85);
      });
      golgi(cell, new V3(3, 0.6, -5.4), new V3(0, 0, -1), 0.62);
      // 游离核糖体：在细胞质里随机撒
      var vacS = Super(V.a * 1.05, V.b * 1.05, V.c * 1.05, V.e, V.cx);
      for (var n = 0; n < 900 && pts.length < 420; n++) {
        var q = new V3((R() * 2 - 1) * 11.4, (R() * 2 - 1) * 7.6, (R() * 2 - 1) * 6.6);
        if (superF(W, q, PL.mem * 0.97) > 1 || superF(vacS, q) < 1) continue;
        var dn = q.clone().sub(PL.N);
        if (dn.x * dn.x / 9 + dn.y * dn.y / 16 + dn.z * dn.z / 17 < 1) continue;
        pts.push(q);
      }
      ribosomes(cell, pts);
      cell.surf = function (d, k) { var t = Math.pow(superF(W, d), -W.e / 2); return d.clone().multiplyScalar(t * (k || 1)); };
      cell.R0 = 13;
      placeStream(cell, 0);
    }
    // 细胞质流动：叶绿体、线粒体的方向绕 y 轴转 phi，再映射到中层表面
    var qTmp = new THREE.Quaternion(), mTmp = new THREE.Matrix4();
    function placeStream(cell, phi) {
      var M = PL.mid, c = Math.cos(phi), s = Math.sin(phi);
      cell.stream.forEach(function (it) {
        var d = it.d, dr = new V3(d.x * c + d.z * s, d.y, -d.x * s + d.z * c);
        var p = superAt(M, dr), n = superN(M, p), t = new V3(-dr.z, 0, dr.x);    // 绕 y 轴转动的切向
        t.addScaledVector(n, -t.dot(n));
        if (t.lengthSq() < 1e-6) t.set(1, 0, 0).addScaledVector(n, -n.x);
        t.normalize();
        it.o.position.copy(p);
        if (it.chl) {
          mTmp.makeBasis(t, n, new V3().crossVectors(t, n));
          it.o.quaternion.setFromRotationMatrix(mTmp);
        } else it.o.quaternion.setFromUnitVectors(Y, t);
      });
      cell.anchors.chloroplast = cell.stream.filter(function (it) { return it.chl; }).map(function (it) { return it.o.position; });
      var ms = cell.stream.filter(function (it) { return !it.chl; }).map(function (it) { return it.o.position; });
      cell.anchors.mito = ms.concat(cell.items.mito.filter(function (o) { return !cell.stream.some(function (it) { return it.o === o; }); }).map(function (o) { return o.position; }));
    }

    function buildAnimal(cell) {
      var R = cell.R;
      var geo = morph(function (d, o) { o.copy(d).multiplyScalar(blobR(d)); });
      var mem = cell.mesh('membrane', geo, cell.mat('membrane', C.get('membrane').col, { op: 0.55, dw: false, side: THREE.FrontSide }));
      mem.renderOrder = 3;
      var cyto = cell.mesh('cytoplasm', geo, cell.mat('cytoplasm', '#18363b', { side: THREE.BackSide, rough: 0.9 }));
      cyto.scale.setScalar(0.99);
      var N = AN.N, NS = new V3(AN.NR, AN.NR * 0.95, AN.NR);
      nucleus(cell, N, NS);
      var pts = erSheets(cell, N, NS, [1.22, 1.42, 1.62], 2.9, 3.2, 0.45, 2.2);
      var gAxis = AN.golgi.clone().sub(N).normalize();
      golgi(cell, AN.golgi, gAxis, 1);
      // 中心体：两个互相垂直的中心粒 + 周围物质
      var cm = cell.mat('centrosome', C.get('centrosome').col, { rough: 0.4 });
      var c1 = cell.mesh('centrosome', cyl, cm, AN.cs.clone().add(new V3(-0.35, 0, 0)));
      c1.rotation.z = Math.PI / 2;
      cell.mesh('centrosome', cyl, cm, AN.cs.clone().add(new V3(0.35, 0.1, 0)));
      var halo = cell.mesh('centrosome', sphere, cell.mat('centrosome', C.get('centrosome').col, { op: 0.16, dw: false }), AN.cs);
      halo.scale.setScalar(1.15);
      cell.anchors.centrosome = [AN.cs.clone()];
      // 线粒体、溶酶体：在细胞质中随机摆放，互不重叠，避开细胞核、内质网、高尔基体、中心体
      var placed = [], lm = cell.mat('lysosome', C.get('lysosome').col, { rough: 0.35 });
      function ok(p, r) {
        if (p.length() > blobR(p.clone().normalize()) * 0.86 - r) return false;
        if (p.distanceTo(N) < AN.NR * 1.75 + r) return false;
        if (p.distanceTo(AN.golgi) < 2.6 + r || p.distanceTo(AN.cs) < 1.4 + r) return false;
        return placed.every(function (q) { return q[0].distanceTo(p) > q[1] + r + 0.3; });
      }
      var nm = 0, nl = 0;
      for (var i = 0; i < 4000 && (nm < 15 || nl < 6); i++) {
        var p = new V3(R() * 2 - 1, R() * 2 - 1, R() * 2 - 1).multiplyScalar(9);
        if (nm < 15 && ok(p, 1.05)) {
          placed.push([p, 1.05]); nm++;
          mito(cell, p, new V3(R() - 0.5, R() - 0.5, R() - 0.5).normalize(), 0.9 + 0.25 * R());
        } else if (nm >= 6 && nl < 6 && ok(p, 0.55)) {
          placed.push([p, 0.55]); nl++;
          cell.mesh('lysosome', sphere, lm, p).scale.setScalar(0.42 + 0.12 * R());
        }
      }
      cell.anchors.mito = cell.items.mito.map(function (o) { return o.position; });
      cell.anchors.lysosome = cell.items.lysosome.map(function (o) { return o.position; });
      for (var n = 0; n < 1600 && pts.length < 520; n++) {
        var q = new V3(R() * 2 - 1, R() * 2 - 1, R() * 2 - 1).multiplyScalar(9.6);
        if (q.length() > blobR(q.clone().normalize()) * 0.95 || q.distanceTo(N) < AN.NR * 1.1) continue;
        pts.push(q);
      }
      ribosomes(cell, pts);
      cell.surf = function (d, k) { return d.clone().multiplyScalar(blobR(d) * (k || 1)); };
      cell.R0 = 10.4;
    }

    var cells = { plant: makeCell('plant'), animal: makeCell('animal') };

    // ---------- 每帧更新 ----------
    // o：{ type: plant|animal|both, lv: 1|2, sel, iso, cut 0~1, labels, stream, mark, t }
    var cur = { type: '' }, camDir = new V3(), up = new V3(), right = new V3(), tmp = new V3();
    var phi = 0, lastT = performance.now();
    function layout(type) {
      var wide = (camera.aspect || 1) > 1.05;
      if (type === 'both') {
        cells.plant.g.position.set(wide ? -12.6 : 0, wide ? 0 : 9.4, 0);
        cells.animal.g.position.set(wide ? 12.4 : 0, wide ? 0 : -11.8, 0);
      } else { cells.plant.g.position.set(0, 0, 0); cells.animal.g.position.set(0, 0, 0); }
      cells.plant.g.visible = type !== 'animal';
      cells.animal.g.visible = type !== 'plant';
      return wide;
    }
    function show(o) {
      if (o.type !== cur.type) { cur.type = o.type; fit(); }
      var now = performance.now(), dt = Math.min(0.05, (now - lastT) / 1000);
      lastT = now;
      if (o.stream) { phi += dt * 0.16; placeStream(cells.plant, phi); }
      camDir.copy(camera.position).sub(controls.target).normalize();
      up.set(0, 1, 0).applyQuaternion(camera.quaternion);
      right.set(1, 0, 0).applyQuaternion(camera.quaternion);
      var cutC = o.cut > 0.001 ? (1 - o.cut) * 16 : 1e6;
      var pulse = 0.5 + 0.5 * Math.sin(now / 1000 * 4.5);
      ['plant', 'animal'].forEach(function (k) {
        var cell = cells[k];
        if (!cell.g.visible) {        // CSS2DRenderer 不管父物体是否可见，要逐个隐藏标注
          Object.keys(cell.labels).forEach(function (id) { cell.labels[id].visible = false; });
          return;
        }
        var ctr = cell.g.position;
        cell.plane.normal.copy(camDir).negate();
        cell.plane.constant = cutC + camDir.dot(ctr);
        var hot = o.mark || o.sel;
        Object.keys(cell.items).forEach(function (id) {
          cell.items[id].forEach(function (ob) { ob.visible = ob.userData.lv <= o.lv; });
        });
        Object.keys(cell.mats).forEach(function (id) {
          var on = !hot || id === hot || (hot === 'nucleus' && (id === 'nucleolus' || id === 'chromatin'));
          cell.mats[id].forEach(function (m) {
            var shell = id === 'wall' || id === 'membrane' || id === 'cytoplasm';
            var fade = (o.iso || o.mark) && hot && !on;
            m.opacity = fade ? (o.mark ? m.userData.op * (shell ? 0.4 : 0.3) : shell ? 0.05 : 0.12) : m.userData.op;
            m.depthWrite = fade ? false : m.userData.dw;
            if (m.emissive) {
              if (hot && id === hot) m.emissive.copy(m.userData.col).multiplyScalar((o.mark ? 0.25 : 0.12) + (o.mark ? 0.55 : 0.3) * pulse);
              else m.emissive.setHex(0);
            }
          });
        });
        labelCell(cell, o, cutC);
      });
    }
    function visibleAt(p, cutC) { return camDir.dot(p) <= cutC - 0.3; }
    // 名称标注：多个同类结构时，取未被剖去、离相机最近的一个
    function labelCell(cell, o, cutC) {
      var cut = o.cut > 0.5;
      Object.keys(cell.labels).forEach(function (id) {
        var lab = cell.labels[id], org = C.get(id), p = null;
        var shell = id === 'wall' || id === 'membrane';
        var show = o.labels && org.lv <= o.lv && (cut || shell || id === o.sel) && !(o.iso && o.sel && id !== o.sel);
        lab.element.classList.toggle('on', id === o.sel);
        if (show) {
          if (id === 'wall') p = cell.surf(tmp.copy(up).multiplyScalar(0.72).addScaledVector(right, 0.69).normalize());
          else if (id === 'membrane') p = cell.surf(tmp.copy(up).multiplyScalar(0.72).addScaledVector(right, -0.69).normalize(), cell.type === 'plant' ? PL.mem : 1);
          else if (id === 'cytoplasm') p = cell.surf(tmp.copy(up).multiplyScalar(-0.86).addScaledVector(right, 0.5).normalize(), cell.type === 'plant' ? 0.9 : 0.8);
          else if (id === 'nucleus') p = cell.nucBox.N.clone().addScaledVector(up, cell.nucBox.S.y * 1.08);
          else if (id === 'vacuole') p = new V3(PL.vac.cx, 0, 0).addScaledVector(up, -1.4).addScaledVector(camDir, -2);
          else if (id === 'chromatin') p = cell.nucBox.N.clone().addScaledVector(up, -cell.nucBox.S.y * 0.5).addScaledVector(right, cell.nucBox.S.x * 0.1);
          else {
            var best = -1e9, list = cell.anchors[id] || [];
            for (var i = 0; i < list.length; i++) {
              var d = camDir.dot(list[i]);
              if (d > best && (!cut || visibleAt(list[i], cutC))) { best = d; p = list[i]; }
            }
          }
          if (p && cut && id !== 'wall' && id !== 'membrane' && !visibleAt(p, cutC + 0.6)) p = null;
        }
        lab.visible = !!p;
        if (p) lab.position.copy(p);
      });
    }

    // ---------- 取景 ----------
    var VIEW = new V3(0.32, 0.42, 1).normalize();
    function fit() {
      var aspect = camera.aspect || 1, wide = layout(cur.type);
      var hw, hh;
      if (cur.type === 'both') { hw = wide ? 25 : 12.5; hh = wide ? 9.5 : 21.5; }
      else if (cur.type === 'plant') { hw = 12.5; hh = 9.5; }
      else { hw = 10.5; hh = 9.5; }
      var half = Math.tan(camera.fov * Math.PI / 360);
      hh /= 1 - pad;                 // 画面下方留给练习题
      var dist = Math.max(hh / half, hw / half / aspect) * 1.18 + 7;
      controls.target.set(0, -hh * pad * 1.1, 0);
      camera.position.copy(VIEW).multiplyScalar(dist).add(controls.target);
      camera.up.set(0, 1, 0);
      controls.minDistance = dist * 0.3;
      controls.maxDistance = dist * 2.4;
      controls.update();
    }
    function home() { moved = false; fit(); }
    var pad = 0;
    function setPad(p) { if (Math.abs(p - pad) > 0.01) { pad = p; if (!moved) fit(); } }

    // ---------- 拾取 ----------
    var ray = new THREE.Raycaster(), ndc = new THREE.Vector2();
    function pick(cx, cy, o) {
      var r = canvas.getBoundingClientRect();
      ndc.set((cx - r.left) / r.width * 2 - 1, -(cy - r.top) / r.height * 2 + 1);
      ray.setFromCamera(ndc, camera);
      var best = null;
      ['plant', 'animal'].forEach(function (k) {
        var cell = cells[k];
        if (!cell.g.visible) return;
        var objs = cell.picks.filter(function (ob) {
          for (var a = ob; a; a = a.parent) if (!a.visible) return false;
          return ob.material.opacity > 0.2;
        });
        var cutC = cell.plane.constant - camDir.dot(cell.g.position);
        ray.intersectObjects(objs, false).some(function (h) {
          var lp = h.point.clone().sub(cell.g.position);
          if (camDir.dot(lp) > cutC + 0.02) return false;            // 被剖去的部分
          if (!best || h.distance < best.d) best = { d: h.distance, id: h.object.userData.id, cell: k };
          return true;
        });
      });
      return best;
    }

    function resize(w, h) {
      camera.aspect = w / Math.max(1, h);
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
      labelRenderer.setSize(w, h);
      if (!moved) fit(); else layout(cur.type);
    }
    var spinOn = true;
    function render() {
      controls.autoRotate = spinOn && !moved;
      controls.update();
      renderer.render(scene, camera);
      labelRenderer.render(scene, camera);
    }
    // resume：重新勾选“自动旋转”时，即使拖动过视角也恢复转动
    function spin(on, resume) { spinOn = !!on; if (on && resume) moved = false; }

    return { show: show, render: render, setPad: setPad, resize: resize, home: home, spin: spin, pick: pick,
      canvas: canvas, labels: labelRenderer.domElement, camera: camera, controls: controls, cells: cells };
  };
})();
