(function () {
  var C = window.Cell;
  var $ = function (id) { return document.getElementById(id); };
  var qa = function (sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); };
  var NAME = '动植物细胞的结构';

  var state = {
    scene: 'cell', type: 'plant', lv: 1, sel: null, iso: false, cut: 1, cutT: 1, labels: true, stream: false, spin: true,
    quiz: null, quizOnly: null, answered: false, correct: false, choice: null, score: { n: 0, ok: 0 }
  };
  var HINTS = {
    cell: '拖动旋转、滚轮或双指缩放；点一个结构看它的名称和功能',
    quiz: '动植物细胞的结构 · 判断练习'
  };
  var TYPE_NAME = { plant: '植物细胞', animal: '动物细胞', both: '动植物细胞对比' };
  var LV_NAME = { 1: '初中', 2: '高中' };

  var stage = $('stage'), panel = $('panel');
  var sc3 = null;
  try { sc3 = window.CellScene(stage); } catch (e) { sc3 = null; }
  function setSeg(attr, val) { qa('[data-' + attr + ']').forEach(function (b) { b.classList.toggle('on', b.dataset[attr] === String(val)); }); }
  function dot(id) { return '<i style="background:' + C.get(id).col + '"></i>'; }

  // ---------- 控件 ----------
  qa('[data-scene]').forEach(function (b) {
    b.addEventListener('click', function () { setScene(b.dataset.scene); Analytics.track(NAME, '场景', b.textContent); });
  });
  function setScene(s) {
    state.scene = s;
    if (s === 'quiz' && !state.quiz) newQuiz();
    syncUI();
  }
  qa('[data-type]').forEach(function (b) {
    b.addEventListener('click', function () { setType(b.dataset.type); Analytics.track(NAME, '细胞', b.textContent); });
  });
  function setType(t) {
    state.type = t;
    if (t === 'animal') state.stream = false;
    syncUI();
  }
  qa('[data-lv]').forEach(function (b) {
    b.addEventListener('click', function () { setLevel(+b.dataset.lv); Analytics.track(NAME, '层次', b.textContent); });
  });
  function setLevel(lv) {
    state.lv = lv;
    if (state.sel && C.get(state.sel).lv > lv) state.sel = null;
    if (state.scene === 'quiz') newQuiz();
    buildList();
    syncUI();
  }
  function select(id, from) {
    state.sel = state.sel === id && from === 'list' ? null : id;
    syncUI();
    if (state.sel) Analytics.track(NAME, '选中', C.get(id).name + (from ? ' · ' + from : ''));
  }
  $('cut').addEventListener('change', function () { state.cutT = $('cut').checked ? 1 : 0; syncUI(); Analytics.track(NAME, '剖开', state.cutT ? '开' : '关'); });
  $('labels').addEventListener('change', function () { state.labels = $('labels').checked; syncUI(); });
  $('iso').addEventListener('change', function () { state.iso = $('iso').checked; syncUI(); Analytics.track(NAME, '只看选中', state.iso ? '开' : '关'); });
  $('stream').addEventListener('change', function () {
    state.stream = $('stream').checked;
    if (state.stream && state.type === 'animal') state.type = 'plant';
    syncUI(); Analytics.track(NAME, '细胞质流动', state.stream ? '开' : '关');
  });
  $('spin').addEventListener('change', function () { state.spin = $('spin').checked; if (sc3) sc3.spin(state.spin, true); syncUI(); });
  qa('.homeBtn').forEach(function (b) { b.addEventListener('click', function () { if (sc3) sc3.home(); }); });
  $('clearSel').addEventListener('click', function () { state.sel = null; syncUI(); });

  // 结构清单：点一行选中
  function buildList() {
    var lv = state.lv;
    $('orgHead').innerHTML = '<tr><th>结构</th><th>植物细胞</th><th>动物细胞</th>' + (lv > 1 ? '<th>膜</th>' : '') + '</tr>';
    $('orgs').querySelector('tbody').innerHTML = C.list(lv).map(function (o) {
      return '<tr data-org="' + o.id + '"' + (o.sub ? ' class="sub"' : '') + '><td>' + dot(o.id) + o.name + '</td>'
        + '<td class="' + (o.p ? 'y">✓' : 'n">—') + '</td><td class="' + (o.a ? 'y">✓' : 'n">—') + '</td>'
        + (lv > 1 ? '<td class="mem">' + memShort(o.id) + '</td>' : '') + '</tr>';
    }).join('');
    qa('[data-org]').forEach(function (tr) { tr.addEventListener('click', function () { select(tr.dataset.org, 'list'); }); });
  }
  function memShort(id) {
    var k = C.memKind(id);
    return C.get(id).sub ? '核内' : k === 2 ? '双层' : k === 1 ? '单层' : k === 0 ? '无膜' : '—';
  }

  // 画布点击：3D 拾取
  var down = null;
  stage.addEventListener('pointerdown', function (e) { down = [e.clientX, e.clientY]; });
  stage.addEventListener('pointerup', function (e) {
    if (!down || Math.hypot(e.clientX - down[0], e.clientY - down[1]) > 6) { down = null; return; }
    down = null;
    if (state.scene !== 'cell' || !sc3 || e.target !== sc3.canvas) return;
    var p = sc3.pick(e.clientX, e.clientY);
    if (!p) { if (state.sel) { state.sel = null; syncUI(); } return; }
    select(p.id, '3D');
  });

  // ---------- 练习 ----------
  function newQuiz() {
    state.quiz = C.quiz(Math.random, state.quiz, state.quizOnly, state.lv, !sc3);
    state.answered = false; state.choice = null;
    var box = $('quizOpts');
    box.innerHTML = '';
    state.quiz.options.forEach(function (o) {
      var b = document.createElement('button');
      b.className = 'small';
      b.textContent = o;
      b.dataset.opt = o;
      b.addEventListener('click', function () { answer(o); });
      box.appendChild(b);
    });
    box.className = 'answer' + (state.quiz.options.some(function (o) { return o.length > 12; }) ? ' one' : '');
    syncUI();
  }
  function answer(o) {
    if (state.answered) return;
    state.answered = true; state.choice = o;
    state.correct = o === state.quiz.answer;
    state.score.n++; if (state.correct) state.score.ok++;
    Analytics.track(NAME, '练习', state.quiz.type + (state.correct ? ' 对' : ' 错'));
    syncUI();
  }
  $('nextQ').addEventListener('click', newQuiz);
  $('showQ').addEventListener('click', function () {
    var sh = state.quiz.show;
    state.type = sh.type; state.sel = sh.sel; state.iso = false; state.cutT = 1;
    setScene('cell');
    Analytics.track(NAME, '练习 → 模型', state.quiz.type);
  });

  // ---------- 面板 ----------
  $('panelToggle').addEventListener('click', function () { panel.classList.toggle('collapsed'); });
  if (window.matchMedia('(max-width: 760px)').matches) panel.classList.add('collapsed');

  function quizView() {
    var q = state.quiz;
    if (!q) return { type: 'plant' };
    if (q.type === 'name') return { type: q.cell, mark: state.answered ? null : q.mark, sel: state.answered ? q.mark : null };
    return { type: q.show.type, sel: state.answered ? q.show.sel : null };
  }
  function syncUI() {
    var s = state.scene;
    setSeg('scene', s);
    qa('[data-for]').forEach(function (el) { el.hidden = el.dataset.for.split(' ').indexOf(s) < 0; });
    $('hint').textContent = !sc3 ? '此浏览器不支持 WebGL，无法显示 3D 细胞模型；结构清单和练习仍可使用' : HINTS[s];
    setSeg('type', state.type); setSeg('lv', state.lv);
    $('cut').checked = state.cutT > 0; $('labels').checked = state.labels; $('iso').checked = state.iso;
    $('stream').checked = state.stream; $('spin').checked = state.spin;
    $('stream').disabled = state.type === 'animal';
    $('clearSel').hidden = !state.sel;
    qa('[data-org]').forEach(function (tr) { tr.classList.toggle('on', tr.dataset.org === state.sel); });
    $('cmpTable').innerHTML = cmpRows();
    if (sc3) { sc3.canvas.style.display = sc3.labels.style.display = ''; sc3.spin(state.spin); }
    var q = state.quiz;
    if (q) {
      $('quizQ').textContent = q.prompt;
      qa('#quizOpts button').forEach(function (b) {
        b.disabled = state.answered;
        b.classList.toggle('on', state.answered && b.dataset.opt === q.answer);
        b.classList.toggle('no', state.answered && b.dataset.opt === state.choice && !state.correct);
      });
      $('quizMsg').innerHTML = !state.answered ? ''
        : '<b class="' + (state.correct ? 'ok">✓ 答对了' : 'bad">✗ 应选「' + q.answer + '」') + '</b>' + q.explain;
      $('nextQ').textContent = state.answered ? '下一题 →' : '换一题';
      $('showQ').hidden = !state.answered;
    }
  }
  function cmpRows() {
    var c = C.compare(state.lv), rows = [
      ['植物细胞特有', c.plant.join('、')],
      ['动物细胞有、高等植物细胞没有', c.animal.join('、') || '—'],
      ['共有', c.both.join('、')]
    ];
    if (state.lv > 1) {
      var m = C.byMembrane();
      rows.push(['双层膜', m[2].join('、') + '（以及核膜）'], ['单层膜', m[1].join('、')], ['无膜', m[0].join('、')]);
    } else rows.push(['能量转换器', '叶绿体（植物绿色部分）、线粒体（动植物都有）']);
    return rows.map(function (r) { return '<tr><td>' + r[0] + '</td><td>' + r[1] + '</td></tr>'; }).join('');
  }

  // ---------- 读数 ----------
  var lastText = {};
  function setText(id, t, html) { if (lastText[id] !== t) { lastText[id] = t; $(id)[html ? 'innerHTML' : 'textContent'] = t; } }
  function rows(list) {
    for (var k = 1; k <= 5; k++) {
      var r = list[k - 1] || ['', ''];
      setText('d' + k, r[0]); setText('r' + k, r[1], true);
      $('d' + k).hidden = $('r' + k).hidden = !r[0];
    }
  }
  function readCell() {
    var id = state.sel, t = state.type;
    $('rName').className = '';
    if (!id) {
      setText('rName', TYPE_NAME[t]);
      setText('rKind', LV_NAME[state.lv]);
      var cmp = C.compare(state.lv), names = function (tt) { return C.list(state.lv, tt).filter(function (o) { return !o.sub; }).map(function (o) { return o.name; }).join('、'); };
      if (t === 'both') {
        rows([['共有', cmp.both.join('、')], ['植物细胞特有', cmp.plant.join('、')], ['动物细胞', cmp.animal.length ? '有' + cmp.animal.join('、') + '（高等植物细胞没有）' : '没有植物细胞所没有的基本结构']]);
        setText('rTip', '左边（或上边）是植物细胞，右边（或下边）是动物细胞。点结构清单里的一行，两个细胞中同一结构一起高亮，看哪个细胞没有。');
      } else {
        rows([['结构', names(t)], [t === 'plant' ? '与动物细胞比' : '与植物细胞比', t === 'plant' ? '多了' + cmp.plant.join('、') : '没有' + cmp.plant.join('、') + (cmp.animal.length ? '；有' + cmp.animal.join('、') : '')]]);
        setText('rTip', t === 'plant'
          ? '植物细胞：最外面是细胞壁，紧贴着细胞膜；成熟的植物细胞中央有一个大液泡，细胞质和细胞核被挤到四周。'
          : '动物细胞：没有细胞壁、叶绿体和大液泡，形状多不规则；细胞核常位于细胞中央。');
      }
      return;
    }
    var o = C.get(id), senior = state.lv > 1;
    setText('rName', dot(id) + o.name, true);
    setText('rKind', senior ? o.mem : o.where.length < 12 ? o.where : (o.p && o.a ? '动植物细胞都有' : o.p ? '植物细胞' : '动物细胞'));
    var list = [['分布', o.where], ['功能', senior ? o.fn2 : o.fn]];
    if (o.alias) list.push(['俗称', o.alias]);
    if (senior) list.push(['膜结构', o.mem]);
    list.push(['显微镜', o.lm]);
    rows(list);
    var miss = t !== 'both' && !C.has(t, id), tip;
    if (miss) tip = TYPE_NAME[t] + '没有' + o.name + '。' + (id === 'centrosome' ? '中心体分布在动物和低等植物细胞中。' : id === 'lysosome' ? '溶酶体主要分布在动物细胞中。' : '切换到“植物细胞”或“对比”看看。');
    else tip = TIPS[id] || '';
    setText('rTip', tip);
  }
  var TIPS = {
    wall: '细胞壁在细胞膜的外面，植物细胞因此能保持一定的形状；动物细胞没有细胞壁。',
    membrane: '植物细胞的细胞膜很薄，紧贴着细胞壁，在显微镜下不易看清；动物细胞最外面就是细胞膜。',
    cytoplasm: '勾选“细胞质流动”，看叶绿体随着细胞质绕着液泡流动（黑藻叶片的经典实验）。',
    nucleus: '剖开后能看到细胞核里面（高中层次显示核仁、染色质和核膜上的核孔）。',
    vacuole: '成熟的植物细胞中，液泡可占细胞体积的 90%，把细胞质和细胞核挤到靠近细胞壁的地方。',
    chloroplast: '只有植物体绿色部分的细胞才有叶绿体：洋葱鳞片叶表皮细胞、根尖细胞没有叶绿体。',
    mito: '叶绿体和线粒体都是能量转换器：叶绿体储存能量（光合作用），线粒体释放能量（呼吸作用）。',
    er: '粗面内质网上附着着核糖体（白色小点），与分泌蛋白的合成、加工有关。',
    golgi: '分泌蛋白依次经过核糖体 → 内质网 → 高尔基体 → 细胞膜分泌到细胞外，线粒体提供能量。',
    ribosome: '核糖体有的附着在内质网上，有的游离在细胞质基质中。',
    lysosome: '溶酶体破裂后水解酶会释放出来，分解细胞自身的结构。',
    centrosome: '有丝分裂时，中心体发出星射线形成纺锤体。',
    nucleolus: '核仁与核糖体的形成有关，所以蛋白质合成旺盛的细胞，核仁较大。',
    chromatin: '染色质（细丝状）在细胞分裂时螺旋化、缩短变粗，成为光学显微镜下清晰可见的染色体。'
  };
  function readQuiz() {
    var q = state.quiz, s = state.score;
    setText('rName', !state.answered ? '判断练习' : state.correct ? '✓ 答对了' : '✗ 答错了');
    $('rName').className = !state.answered ? '' : state.correct ? 'ok' : 'bad';
    setText('rKind', '得分 ' + s.ok + ' / ' + s.n);
    setText('rTip', state.answered ? q.explain : q.prompt);
    rows([]);
  }

  // ---------- 画面 ----------
  var W = 0, H = 0;
  function resize() {
    W = stage.clientWidth; H = stage.clientHeight;
    if (sc3) sc3.resize(W, H);
  }
  new ResizeObserver(resize).observe(stage);

  // 对比时在两个细胞上方写上名称
  var tags = $('cellTags'), v = new THREE.Vector3();
  function cellTags(type) {
    if (!sc3 || type !== 'both') { tags.innerHTML = ''; return; }
    if (!tags.children.length) tags.innerHTML = '<span>植物细胞</span><span>动物细胞</span>';
    ['plant', 'animal'].forEach(function (k, i) {
      var g = sc3.cells[k].g;
      v.copy(g.position).add(new THREE.Vector3(0, k === 'plant' ? 9.2 : 9.4, 0)).project(sc3.camera);
      var el = tags.children[i];
      el.style.left = ((v.x + 1) / 2 * W) + 'px';
      el.style.top = Math.max(W <= 760 ? 84 : 40, (1 - v.y) / 2 * H - 34) + 'px';
    });
  }

  // ---------- 主循环 ----------
  // 支持 ?scene=cell|quiz、&type=plant|animal|both、&level=junior|senior、&sel=<结构 id>、&cut=0、&labels=0、&iso=1、&stream=1、&spin=0、
  // 练习 &q=name|func|diff|fact
  var qs = new URLSearchParams(location.search);
  if (HINTS[qs.get('scene')]) state.scene = qs.get('scene');
  if (TYPE_NAME[qs.get('type')]) state.type = qs.get('type');
  if (qs.get('level') === 'senior') state.lv = 2;
  if (C.get(qs.get('sel'))) { state.sel = qs.get('sel'); if (C.get(state.sel).lv > state.lv) state.lv = 2; }
  if (qs.get('cut') === '0') state.cut = state.cutT = 0;
  if (qs.get('labels') === '0') state.labels = false;
  if (qs.get('iso') === '1') state.iso = true;
  if (qs.get('stream') === '1' && state.type !== 'animal') state.stream = true;
  if (qs.get('spin') === '0') state.spin = false;
  if (C.TYPES.indexOf(qs.get('q')) >= 0) state.quizOnly = qs.get('q');
  buildList();
  resize();
  setScene(state.scene);

  var last = performance.now();
  function frame(now) {
    var dt = Math.min(0.05, (now - last) / 1000);
    last = now;
    var d = state.cutT - state.cut;
    state.cut += Math.sign(d) * Math.min(Math.abs(d), dt * 1.5);
    var o;
    if (state.scene === 'cell') {
      o = { type: state.type, lv: state.lv, sel: state.sel, iso: state.iso, cut: state.cut, labels: state.labels, stream: state.stream };
      readCell();
    } else {
      var qv = quizView();
      o = { type: qv.type, lv: state.lv, sel: qv.sel, mark: qv.mark, iso: false, cut: 1, labels: state.answered, stream: false };
      readQuiz();
    }
    if (sc3) {
      sc3.setPad(state.scene === 'quiz' && H ? Math.min(0.45, ($('quizBar').offsetHeight + 50) / H) : 0);
      sc3.show(o); sc3.render();
    }
    cellTags(o.type);
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // 调试用
  window.__model = {
    state: state, C: C, scene: sc3, setScene: setScene, setType: setType, setLevel: setLevel, select: select, newQuiz: newQuiz, sync: syncUI,
    answer: function (o) { answer(o == null ? state.quiz.answer : o); }
  };
})();
