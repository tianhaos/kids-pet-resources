(function () {
  'use strict';
  const $=id=>document.getElementById(id),q=new URLSearchParams(location.search);
  function num(key,fallback,min,max){const raw=q.get(key);if(raw===null||!Number.isFinite(+raw))return fallback;return Thermal.clamp(+raw,min,max);}
  const state={scene:Thermal.SCENES[q.get('scene')]?q.get('scene'):'sea-day',delta:num('delta',12,0,20),height:num('height',0,0,3000),step:Math.round(num('step',4,1,4)),flip:q.get('flip')==='1',isobars:q.has('isobars')?q.get('isobars')!=='0':q.get('scene')==='heat',play:q.get('play')!=='0',time:0};
  const draw=ThermalDraw.create($('view'));
  const track=(a,l)=>window.Analytics&&Analytics.track('热力环流',a,String(l));
  const notes=['受热不均是驱动；温差设为0可观察无驱动对照。','暖空气趋于上升、冷空气趋于下沉；山谷场景看沿坡运动。','平地气压标签比较同一高度，紫线表示等压面，金色虚线是可拖动探针。','水平气流与垂直运动组成环流；动画只表示方向。'];
  function update(){
    const r=Thermal.read(state),c=r.config,m=c.mountain;
    const left=state.scene==='heat'?(r.warmRight?'冷却区':'加热区'):c.left;
    const right=state.scene==='heat'?(r.warmRight?'加热区':'冷却区'):c.right;
    $('name').textContent=c.name;
    $('summary').textContent=!r.active?'温差为0，无热力驱动':m?(c.sign>0?'谷地 → 山坡：谷风':'山坡 → 谷地：山风'):(r.warmRight?'近地面：'+left+' → '+right:'近地面：'+right+' → '+left);
    $('leftName').textContent=left;$('rightName').textContent=right;
    r.temps.forEach((t,i)=>$(i?'rightTemp':'leftTemp').textContent=(t-273.15).toFixed(1)+' °C');
    $('heightRead').textContent=m?'沿坡示意':state.height+' m';
    $('pLeft').textContent=m?'不作平地双柱比较':r.pressures[0].toFixed(1)+' hPa';
    $('pRight').textContent=m?'不作平地双柱比较':r.pressures[1].toFixed(1)+' hPa';
    $('pressureNote').textContent=m?'山坡温度与同高度自由大气比较，图中不显示等压面。':'左减右：'+r.difference.toFixed(2)+' hPa；两柱在1.5 km处设为等压。';
    ['delta','height','step'].forEach(k=>$(k).value=state[k]);
    ['isobars','play'].forEach(k=>$(k).checked=state[k]);
    $('height').disabled=m;$('isobars').disabled=m;
    $('deltaRead').textContent=state.delta+' K';$('heightOut').textContent=(state.height/1000).toFixed(2)+' km';
    $('stepNote').textContent=notes[state.step-1];
    document.querySelectorAll('[data-scene]').forEach(b=>b.classList.toggle('on',b.dataset.scene===state.scene));
    draw.draw(state);
  }
  function setScene(scene){if(!Thermal.SCENES[scene])return;state.scene=scene;state.flip=false;state.isobars=scene==='heat';track('切换场景',scene);update();}
  document.querySelectorAll('[data-scene]').forEach(b=>b.onclick=()=>setScene(b.dataset.scene));
  ['delta','height','step'].forEach(k=>{$(k).oninput=()=>{state[k]=+$(k).value;update();};$(k).onchange=()=>track('调节'+k,state[k]);});
  ['isobars','play'].forEach(k=>$(k).onchange=()=>{state[k]=$(k).checked;track('显示'+k,state[k]);update();});
  $('reverse').onclick=()=>{if(state.scene==='heat'){state.flip=!state.flip;track('交换冷热',state.flip);}else setScene(state.scene.replace(/day|night/,x=>x==='day'?'night':'day'));update();};
  $('panelToggle').onclick=()=>$('panel').classList.toggle('collapsed');
  function stateURL(){const p=new URLSearchParams();['scene','delta','height','step','flip','isobars','play'].forEach(k=>p.set(k,typeof state[k]==='boolean'?+state[k]:state[k]));return location.origin+location.pathname+'?'+p;}
  $('share').onclick=async()=>{const u=stateURL();try{await navigator.clipboard.writeText(u);$('shareStatus').textContent='已复制当前状态链接';}catch(e){$('shareStatus').textContent=u;}track('分享',state.scene);};
  let dragging=false;
  $('view').onpointerdown=e=>{if(Thermal.SCENES[state.scene].mountain)return;dragging=true;$('view').setPointerCapture(e.pointerId);state.height=draw.heightAt(e.clientY);update();};
  $('view').onpointermove=e=>{if(dragging){state.height=draw.heightAt(e.clientY);update();}};
  $('view').onpointerup=()=>{if(dragging)track('拖动高度',state.height);dragging=false;};$('view').onpointercancel=()=>dragging=false;
  if(matchMedia('(max-width:760px)').matches)$('panel').classList.add('collapsed');
  if(state.scene!=='heat')state.flip=false;
  let previous=performance.now();
  function frame(now){if(state.play)state.time+=Math.min((now-previous)/1000,.05);previous=now;draw.draw(state);requestAnimationFrame(frame);}
  window.__model={state,update,setScene,stateURL};update();requestAnimationFrame(frame);
})();
