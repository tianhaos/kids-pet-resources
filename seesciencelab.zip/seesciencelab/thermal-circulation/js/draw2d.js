/* 环境、地形、气流与读数分层绘制。地形为程序绘制的教学剖面，不对应真实地点。 */
(function () {
  'use strict';
  function create(canvas) {
    const ctx = canvas.getContext('2d');
    let W = 0, H = 0, plot = {};
    const C = { warm: '#ffbe83', cold: '#8de5ff', gold: '#ffe09a', ink: '#10283a' };

    function text(value, x, y, color = '#fff', size = 14, align = 'center', weight = 500) {
      ctx.font = `${weight} ${size}px -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif`;
      ctx.textAlign = align;
      ctx.fillStyle = color;
      ctx.fillText(value, x, y);
    }
    function round(x, y, w, h, radius = 12) {
      ctx.beginPath(); ctx.roundRect(x, y, w, h, radius);
    }
    function badge(value, x, y, color = '#fff', size = 13) {
      ctx.font = `600 ${size}px -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif`;
      const w = ctx.measureText(value).width + 22;
      round(x - w / 2, y - 19, w, 29, 10);
      ctx.fillStyle = 'rgba(8,27,44,.82)'; ctx.fill();
      text(value, x, y, color, size, 'center', 600);
    }
    function polygon(points, color) {
      ctx.beginPath(); points.forEach(([x,y],i) => i ? ctx.lineTo(x,y) : ctx.moveTo(x,y));
      ctx.closePath(); ctx.fillStyle = color; ctx.fill();
    }
    function gradient(y0, y1, stops) {
      const g = ctx.createLinearGradient(0,y0,0,y1);
      stops.forEach(([p,c]) => g.addColorStop(p,c)); return g;
    }
    function glow(x, y, radius, color) {
      const g = ctx.createRadialGradient(x,y,0,x,y,radius);
      g.addColorStop(0,color); g.addColorStop(1,'rgba(255,190,120,0)');
      ctx.fillStyle = g; ctx.fillRect(x-radius,y-radius,radius*2,radius*2);
    }
    function line(x1,y1,x2,y2,color,width=1,dash=[]) {
      ctx.beginPath(); ctx.moveTo(x1,y1); ctx.lineTo(x2,y2);
      ctx.strokeStyle=color; ctx.lineWidth=width; ctx.setLineDash(dash);ctx.stroke();ctx.setLineDash([]);
    }
    function cloud(x,y,scale,alpha) {
      ctx.save();ctx.translate(x,y);ctx.scale(scale,scale);ctx.fillStyle=`rgba(239,252,255,${alpha})`;
      ctx.beginPath();ctx.ellipse(0,0,40,8,0,0,Math.PI*2);ctx.ellipse(-15,-7,17,11,0,0,Math.PI*2);ctx.ellipse(7,-11,22,15,0,0,Math.PI*2);ctx.fill();ctx.restore();
    }
    function sky(day,s) {
      ctx.fillStyle = day ? gradient(0,H,[[0,'#255f8c'],[.5,'#79b9ca'],[1,'#e4d7aa']]) : gradient(0,H,[[0,'#080f2b'],[.55,'#1b3458'],[1,'#497283']]);
      ctx.fillRect(0,0,W,H);
      if (!day) {
        for(let i=0;i<65;i++) {
          const x=((i*137.51)%997)/997*W, y=60+((i*81.73)%401)/401*H*.52;
          ctx.globalAlpha=.3+(i%5)/9;ctx.fillStyle='#e0edff';ctx.beginPath();ctx.arc(x,y,i%3===0?1.3:.7,0,Math.PI*2);ctx.fill();
        }ctx.globalAlpha=1;
      }
      const sx=W*.84,sy=Math.max(122,H*.18),sr=W<600?22:30;
      glow(sx,sy,sr*4,day?'rgba(255,229,157,.34)':'rgba(185,220,255,.17)');
      if(day){
        ctx.save();ctx.translate(sx,sy);ctx.strokeStyle='rgba(255,229,157,.5)';ctx.lineWidth=2;
        for(let i=0;i<12;i++){const a=i*Math.PI/6;line(Math.cos(a)*(sr+9),Math.sin(a)*(sr+9),Math.cos(a)*(sr+17),Math.sin(a)*(sr+17),'rgba(255,229,157,.6)',2);}ctx.restore();
        ctx.fillStyle='#fff0b5';ctx.beginPath();ctx.arc(sx,sy,sr,0,Math.PI*2);ctx.fill();
      }else{
        ctx.save();ctx.beginPath();ctx.arc(sx,sy,sr,0,Math.PI*2);ctx.clip();ctx.fillStyle='#e0ebee';ctx.fillRect(sx-sr,sy-sr,sr*2,sr*2);
        for(let i=0;i<7;i++){ctx.fillStyle='rgba(112,144,169,.25)';ctx.beginPath();ctx.arc(sx-sr*.5+(i%3)*sr*.5,sy-sr*.6+Math.floor(i/3)*sr*.6,3+i%3,0,Math.PI*2);ctx.fill();}
        ctx.restore();
      }
      cloud(W*.15,H*.24,W<600?.65:1.1,day?.32:.09);
      cloud(W*.62,H*.30,W<600?.65:1.3,day?.24:.06);
      if(day&&s.delta>0){
        ctx.save();ctx.strokeStyle='rgba(255,235,171,.16)';ctx.lineWidth=2;
        for(let i=0;i<5;i++)line(sx-10-i*14,sy+sr+20,W*(.56+i*.065),plot.bottom,'rgba(255,235,171,.13)',2);
        ctx.restore();
      }
    }
    function tree(x,y,size,day) {
      ctx.fillStyle=day?'#6c5946':'#263544';ctx.fillRect(x-size*.07,y-size*.28,size*.14,size*.35);
      const col=day?'#275d4c':'#193c45';
      for(let i=0;i<3;i++)polygon([[x,y-size*(1-i*.22)],[x-size*(.3+i*.04),y-size*(.35-i*.15)],[x+size*(.3+i*.04),y-size*(.35-i*.15)]],col);
    }
    function house(x,y,size,day) {
      ctx.fillStyle=day?'#ead5ad':'#466071';ctx.fillRect(x-size*.5,y-size*.65,size,size*.65);
      polygon([[x-size*.65,y-size*.65],[x,y-size*1.12],[x+size*.65,y-size*.65]],day?'#ac6752':'#263c53');
      ctx.fillStyle=day?'#537886':'#ffd28a';ctx.fillRect(x-size*.3,y-size*.47,size*.2,size*.22);ctx.fillRect(x+size*.1,y-size*.47,size*.2,size*.22);
      ctx.fillStyle='#485253';ctx.fillRect(x-size*.06,y-size*.3,size*.17,size*.3);
      if(!day)glow(x,y-size*.3,size*1.7,'rgba(255,196,104,.08)');
    }
    function shore(s,day) {
      const g=plot.bottom,coast=W*.5;
      // 远处海岬与缓坡，不占据气流剖面。
      polygon([[W*.47,g+8],[W*.58,g-27],[W*.70,g-46],[W*.83,g-37],[W,g-70],[W,H],[W*.47,H]],day?'#6d9989':'#274e5c');
      polygon([[W*.5,g+12],[W*.65,g-12],[W*.78,g+2],[W*.92,g-22],[W,g-16],[W,H],[W*.5,H]],day?'#537a58':'#213f46');
      const water=gradient(g,H,[[0,day?'#218ba0':'#204e74'],[1,day?'#10475e':'#122b4a']]);
      polygon([[0,g],[coast,g],[coast+W*.025,g+26],[coast-W*.04,g+65],[coast+W*.025,H],[0,H]],water);
      ctx.save();ctx.beginPath();ctx.moveTo(0,g);ctx.lineTo(coast,g);ctx.lineTo(coast+W*.025,g+26);ctx.lineTo(coast-W*.04,g+65);ctx.lineTo(coast+W*.025,H);ctx.lineTo(0,H);ctx.closePath();ctx.clip();
      for(let row=0;row<16;row++){
        const yy=g+10+row*12;
        for(let i=0;i<7;i++){
          const xx=(i*W*.095+Math.sin(row*2+i)*18+s.time*3*(row%2?1:-1))%(coast+40);
          line(xx,yy,xx+15+row*2,yy,day?'rgba(161,234,235,.4)':'rgba(144,199,225,.22)',1.2);
        }
      }ctx.restore();
      ctx.beginPath();ctx.moveTo(coast,g);ctx.bezierCurveTo(coast+W*.08,g+40,coast-W*.1,g+55,coast+W*.025,H);ctx.strokeStyle=day?'#e6d5ab':'#81918a';ctx.lineWidth=8;ctx.stroke();
      // 灯塔、房屋与树林给海陆提供可直接辨认的尺度线索。
      const lx=W*.57,ly=g-10,ls=W<600?15:22;
      polygon([[lx-ls*.3,ly],[lx-ls*.23,ly-ls*1.6],[lx+ls*.23,ly-ls*1.6],[lx+ls*.3,ly]],day?'#f6e9d2':'#c0cbd0');
      ctx.fillStyle='#b95f50';ctx.fillRect(lx-ls*.24,ly-ls*.8,ls*.48,ls*.25);
      ctx.fillStyle=day?'#384c54':'#ffd995';ctx.fillRect(lx-ls*.3,ly-ls*1.85,ls*.6,ls*.3);
      polygon([[lx-ls*.4,ly-ls*1.85],[lx,ly-ls*2.12],[lx+ls*.4,ly-ls*1.85]],day?'#a95d4e':'#344654');
      house(W*.77,g+5,W<600?20:30,day);
      [ [.67,9,25],[.86,-5,38],[.91,-11,31],[.96,-5,40] ].forEach(([u,dy,z])=>tree(W*u,g+dy,z*(W<600?.75:1),day));
      if(s.delta>0)glow(W*(day?.76:.25),g-5,W*.25,day?'rgba(255,172,92,.22)':'rgba(255,183,118,.12)');
      badge('海 洋',W*.22,g+46,'#c1f3ff',W<600?15:18);
      badge('陆 地',W*.79,g+46,'#f9e4b8',W<600?15:18);
    }
    function terrain(s,day) {
      const b=plot,w=b.right-b.left,h=b.bottom-b.top;
      const x=u=>b.left+w*u,y=v=>b.top+h*v;
      // 远山与两侧前景岩层。谷底、山坡与远处山脊具有不同的轮廓和颜色。
      polygon([[0,y(.43)],[W*.09,y(.18)],[W*.19,y(.34)],[W*.29,y(.13)],[W*.42,y(.38)],[W*.59,y(.23)],[W*.72,y(.36)],[W*.87,y(.12)],[W,y(.34)],[W,H],[0,H]],day?'#7fa9ad':'#294563');
      polygon([[0,y(.48)],[W*.14,y(.27)],[W*.27,y(.49)],[W*.37,y(.35)],[W*.52,y(.61)],[W*.67,y(.43)],[W*.78,y(.29)],[W,y(.45)],[W,H],[0,H]],day?'#5a8f8e':'#223d57');
      const left=[[0,y(.32)],[x(.04),y(.26)],[x(.12),y(.36)],[x(.19),y(.54)],[x(.29),y(.67)],[x(.39),y(.85)],[x(.47),y(.94)],[x(.5),y(.97)]];
      const right=left.map(([xx,yy])=>[W-xx,yy]).reverse();
      const edge=[...left,...right];
      polygon([...edge,[W,H],[0,H]],gradient(y(.3),H,[[0,day?'#66846a':'#2b4b50'],[.7,day?'#3c7057':'#173c43'],[1,day?'#244f40':'#122c39']]));
      ctx.beginPath();edge.forEach(([xx,yy],i)=>i?ctx.lineTo(xx,yy):ctx.moveTo(xx,yy));ctx.strokeStyle=day?'#bfcc94':'#63808a';ctx.lineWidth=3;ctx.stroke();
      // 山体岩层纹理随坡面走势，避免只有一个空洞三角形。
      for(const side of [0,1])for(let i=0;i<8;i++){
        const xx=side?W-x(.04+i*.034):x(.04+i*.034),yy=y(.42+i*.056);
        line(xx,yy,xx+(side?1:-1)*w*.1,yy+h*.16,day?'rgba(204,193,139,.16)':'rgba(135,163,173,.12)',2);
      }
      for(const side of [0,1])[[.075,.40,26],[.15,.56,31],[.23,.68,25],[.31,.80,23],[.36,.88,18]].forEach(([u,v,z])=>tree(side?W-x(u):x(u),y(v),z*(W<600?.7:1),day));
      // 溪流沿谷底向观众延伸，村落建立空间感。
      ctx.beginPath();ctx.moveTo(W*.5,y(.95));ctx.bezierCurveTo(W*.46,y(1.04),W*.56,H-70,W*.49,H);ctx.strokeStyle=day?'#76c6c9':'#5c93b0';ctx.lineWidth=W<600?9:16;ctx.stroke();
      house(W*.59,y(.99),W<600?17:26,day);
      glow(W*.5,y(.88),w*.35,day?'rgba(255,205,116,.07)':'rgba(117,207,255,.14)');
      badge('谷 地',W*.5,y(1.06),'#e2efdd',W<600?13:16);
    }
    // 三次贝塞尔流线：同一路径既画箭头也驱动粒子，确保方向与贴合位置一致。
    function point(path,t){const a=1-t;return [a*a*a*path[0]+3*a*a*t*path[2]+3*a*t*t*path[4]+t*t*t*path[6],a*a*a*path[1]+3*a*a*t*path[3]+3*a*t*t*path[5]+t*t*t*path[7]];}
    function flow(path,color,s,reverse=false,particles=7) {
      ctx.save();ctx.lineCap='round';
      ctx.beginPath();ctx.moveTo(path[0],path[1]);ctx.bezierCurveTo(...path.slice(2));
      ctx.strokeStyle=color;ctx.globalAlpha=.10;ctx.lineWidth=W<600?13:20;ctx.stroke();
      ctx.globalAlpha=.7;ctx.lineWidth=2;ctx.stroke();
      for(const t of [.34,.72]){
        const a=point(path,t),b=point(path,t+(reverse?-.015:.015)),ang=Math.atan2(b[1]-a[1],b[0]-a[0]);
        ctx.globalAlpha=.95;ctx.fillStyle=color;ctx.beginPath();ctx.moveTo(a[0]+Math.cos(ang)*7,a[1]+Math.sin(ang)*7);ctx.lineTo(a[0]-Math.cos(ang-.5)*7,a[1]-Math.sin(ang-.5)*7);ctx.lineTo(a[0]-Math.cos(ang+.5)*7,a[1]-Math.sin(ang+.5)*7);ctx.closePath();ctx.fill();
      }
      for(let i=0;i<particles;i++){
        let t=(i/particles+s.time*.06)%1;if(reverse)t=1-t;
        const p=point(path,t);ctx.globalAlpha=Math.sin(t*Math.PI)*.85;
        ctx.beginPath();ctx.arc(p[0],p[1],W<600?2.4:3,0,Math.PI*2);ctx.fillStyle='#fff6da';ctx.shadowBlur=8;ctx.shadowColor=color;ctx.fill();
      }ctx.restore();
    }
    function flatFlow(s,r) {
      const b=plot,w=b.right-b.left,h=b.bottom-b.top,x=u=>b.left+u*w,y=v=>b.top+v*h;
      if(!r.active)return;
      const rev=!r.warmRight;
      if(s.step>=2){
        flow([x(.78),y(.86),x(.87),y(.65),x(.86),y(.25),x(.74),y(.17)],r.warmRight?C.warm:C.cold,s,rev);
        flow([x(.25),y(.17),x(.12),y(.35),x(.13),y(.7),x(.22),y(.86)],r.warmRight?C.cold:C.warm,s,rev);
        badge(r.warmRight?'冷空气下沉':'暖空气上升',x(.12),y(.48),r.warmRight?C.cold:C.warm,W<600?11:13);
        badge(r.warmRight?'暖空气上升':'冷空气下沉',x(.89),y(.48),r.warmRight?C.warm:C.cold,W<600?11:13);
      }
      if(s.step>=4){
        flow([x(.23),y(.86),x(.4),y(.94),x(.61),y(.94),x(.78),y(.86)],r.warmRight?C.cold:C.warm,s,rev,11);
        flow([x(.74),y(.17),x(.6),y(.05),x(.42),y(.05),x(.25),y(.17)],r.warmRight?C.warm:C.cold,s,rev,8);
        badge(r.config===Thermal.SCENES.heat?'近地面气流':(s.scene==='sea-day'?'海风 · 海 → 陆':'陆风 · 陆 → 海'),W*.5,y(.91)-15,C.gold,W<600?12:15);
      }
    }
    function mountainFlow(s,r){
      if(!r.active)return;
      const b=plot,w=b.right-b.left,h=b.bottom-b.top,x=u=>b.left+w*u,y=v=>b.top+h*v,day=r.config.sign>0;
      if(s.step>=2){
        for(const sign of [-1,1]){
          const xx=u=>W*.5+sign*w*u;
          flow([xx(.07),y(.84),xx(.19),y(.77),xx(.28),y(.45),xx(.43),y(.28)],day?C.warm:C.cold,s,!day,10);
        }
        badge(day?'山坡受热':'山坡冷却',x(.13),y(.65),day?C.warm:C.cold,W<600?11:14);
        badge(day?'沿坡上升':'沿坡下滑',x(.87),y(.65),day?C.warm:C.cold,W<600?11:14);
      }
      if(s.step>=4){
        flow([x(.08),y(.20),x(.25),y(.08),x(.38),y(.07),x(.5),y(.2)],C.cold,s,!day,5);
        flow([x(.92),y(.20),x(.75),y(.08),x(.62),y(.07),x(.5),y(.2)],C.cold,s,!day,5);
        flow([x(.5),y(.20),x(.5),y(.35),x(.5),y(.48),x(.5),y(.57)],day?C.cold:C.warm,s,!day,4);
        badge('高处补偿气流',W*.5,y(.02), '#dbecf4',W<600?11:13);
      }
    }
    function pressure(s,r) {
      if(s.step<3||!s.isobars)return;
      const b=plot,w=b.right-b.left,h=b.bottom-b.top,x=u=>b.left+w*u,y=z=>b.bottom-h*z/3000;
      [970,850,750].forEach(p=>{
        ctx.beginPath();
        for(let j=0;j<=80;j++){
          const u=j/80,t=r.temps[0]+(r.temps[1]-r.temps[0])*(.5-.5*Math.cos(Math.PI*u));
          const z0=Thermal.altitude(p,288),z=z0+3*(Thermal.altitude(p,t)-z0);
          if(j===0)ctx.moveTo(x(u),y(z));else ctx.lineTo(x(u),y(z));
        }
        ctx.strokeStyle='rgba(231,209,255,.60)';ctx.lineWidth=1.2;ctx.stroke();
        badge(p+' hPa',x(p===970?.11:.5),y(Thermal.altitude(p,288))-7,'#ead8ff',10);
      });
      const py=y(s.height);line(b.left,py,b.right,py,'#ffebaf',1.5,[5,6]);
      r.pressures.forEach((p,i)=>{
        const xx=x(i?.77:.23);ctx.beginPath();ctx.arc(xx,py,5,0,Math.PI*2);ctx.fillStyle=C.gold;ctx.fill();
        badge(p.toFixed(1),xx,py-15,C.gold,11);
      });
      badge((s.height/1000).toFixed(2)+' km · 同高度',x(.5),py+24,C.gold,10);
    }
    function heatGround(s,r){
      const g=plot.bottom;
      polygon([[0,g],[W,g],[W,H],[0,H]],gradient(g,H,[[0,'#456e61'],[1,'#172f32']]));
      ctx.fillStyle='#bb8a59';ctx.fillRect(r.warmRight?W*.5:0,g,W*.5,7);
      const warmX=r.warmRight?W*.78:W*.22,coldX=r.warmRight?W*.22:W*.78;
      glow(warmX,g,W*.25,'rgba(255,154,71,.32)');glow(coldX,g,W*.22,'rgba(100,208,255,.2)');
      tree(W*.12,g,36,true);tree(W*.15,g+5,24,true);house(W*.86,g,26,true);
      badge(r.warmRight?'冷却区':'加热区',W*.22,g+40,r.warmRight?C.cold:C.warm,15);
      badge(r.warmRight?'加热区':'冷却区',W*.78,g+40,r.warmRight?C.warm:C.cold,15);
    }
    function footer(s,r,day){
      const narrow=W<600,m=r.config.mountain,yy=H-96;
      round(20,yy,W-40,58,14);ctx.fillStyle='rgba(6,24,38,.83)';ctx.fill();
      const message=!r.active?'温差为零 · 热力驱动消失':m?(day?'谷风：从谷地沿坡向上':'山风：从山坡沿坡向下'):(s.scene==='heat'?'受热不均 → 垂直运动 → 水平环流':day?'白天陆地增温较快，海风吹向陆地':'夜间陆地降温较快，陆风吹向海洋');
      text(message,W/2,yy+23,C.gold,narrow?12:16,'center',600);
      text(m?'坡面与同高度自由大气比较 · 气流为方向示意':'空气温度为教学设定 · 气流不表示真实风速',W/2,yy+44,'#b1c9d7',narrow?10:11);
    }
    function draw(s){
      const box=canvas.getBoundingClientRect(),dpr=Math.min(devicePixelRatio||1,2);
      W=box.width;H=box.height;if(W<1||H<1)return;
      if(canvas.width!==Math.round(W*dpr)||canvas.height!==Math.round(H*dpr)){canvas.width=Math.round(W*dpr);canvas.height=Math.round(H*dpr);}
      ctx.setTransform(dpr,0,0,dpr,0,0);
      const r=Thermal.read(s),narrow=W<600,m=r.config.mountain,day=!s.scene.endsWith('night');
      plot={top:narrow?190:155,bottom:H-190,left:narrow?23:50,right:W-(narrow?23:50)};
      sky(day,s);
      // 标题与日月分别占据左右区域，环境承担昼夜识别。
      text(r.config.name,28,narrow?113:102,'#fff6e3',narrow?22:29,'left',700);
      text(m?'山坡的冷暖，驱动沿坡的风':s.scene==='heat'?'从地表冷热，看一整圈空气运动':'海与陆的热响应不同，风随昼夜反转',28,narrow?139:129,'#d5e9ec',narrow?11:13,'left');
      if(m){terrain(s,day);mountainFlow(s,r);}else{
        if(s.scene==='heat')heatGround(s,r);else shore(s,day);
        // 温度着色用无边框的局地热羽，融入天空，不覆盖为矩形色块。
        if(r.active){glow(W*(r.warmRight?.78:.22),plot.bottom-50,(plot.bottom-plot.top)*.72,'rgba(255,150,81,.14)');}
        pressure(s,r);flatFlow(s,r);
        r.temps.forEach((t,i)=>badge((t-273.15).toFixed(1)+' °C',W*(i?.78:.22),plot.bottom+74,t>288?C.warm:C.cold,narrow?12:14));
      }
      footer(s,r,day);
    }
    function heightAt(clientY){const b=canvas.getBoundingClientRect();return Thermal.clamp(Math.round((plot.bottom-(clientY-b.top))/(plot.bottom-plot.top)*3000/50)*50,0,3000);}
    return {draw,heightAt};
  }
  window.ThermalDraw={create};
})();
