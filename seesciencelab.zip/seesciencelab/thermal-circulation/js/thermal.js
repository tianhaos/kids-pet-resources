/* 双等温气柱；所有计算不接触 DOM。 */
(function () {
  'use strict';
  const SCENES = {
    heat: {name:'热力环流',left:'冷却区',right:'加热区',sign:1},
    'sea-day': {name:'白天 · 海风',left:'海洋',right:'陆地',sign:1},
    'sea-night': {name:'夜间 · 陆风',left:'海洋',right:'陆地',sign:-1},
    'valley-day': {name:'白天 · 谷风',left:'山坡',right:'同高度自由大气',sign:1,mountain:true},
    'valley-night': {name:'夜间 · 山风',left:'山坡',right:'同高度自由大气',sign:-1,mountain:true}
  };
  const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
  function temps(s) {
    const c=SCENES[s.scene] || SCENES.heat;
    const sign=c.sign*(s.flip?-1:1), d=clamp(s.delta,0,20);
    return c.mountain ? [288+sign*d/2,288-sign*d/2] : [288-sign*d/2,288+sign*d/2];
  }
  function pressure(z,t) { return 850*Math.exp(-9.8*(z-1500)/(287*t)); }
  function altitude(p,t) { return 1500-287*t/9.8*Math.log(p/850); }
  function read(s) {
    const c=SCENES[s.scene] || SCENES.heat, ts=temps(s);
    const ps=ts.map(t=>pressure(s.height,t));
    return {config:c,temps:ts,pressures:ps,difference:ps[0]-ps[1],warmRight:ts[1]>ts[0],active:s.delta>0};
  }
  // 矩形环流路径，t 随时间增加。下边由冷侧流向暖侧。
  function loop(t,warmRight) {
    t=((t%1)+1)%1;
    if(!warmRight)t=1-t;
    const k=t*4;
    if(k<1)return [.22+.56*k,.78];
    if(k<2)return [.78,.78-.56*(k-1)];
    if(k<3)return [.78-.56*(k-2),.22];
    return [.22,.22+.56*(k-3)];
  }
  window.Thermal={SCENES,clamp,temps,pressure,altitude,read,loop};
})();
