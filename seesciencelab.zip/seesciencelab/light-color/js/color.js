(function(){
'use strict';
var R=Math.PI/180;
var colors={white:{name:'白',rgb:[1,1,1]},red:{name:'红',rgb:[1,0,0]},green:{name:'绿',rgb:[0,1,0]},blue:{name:'蓝',rgb:[0,0,1]},yellow:{name:'黄',rgb:[1,1,0]},cyan:{name:'青',rgb:[0,1,1]},magenta:{name:'品红',rgb:[1,0,1]},black:{name:'黑',rgb:[0,0,0]}};
function index(w){return 1.50+0.004/Math.pow(w/1000,2);}
// nm与度；y朝下。入射点固定在左面，求与右面交点。
function prism(i,w){var n=index(w),r=Math.asin(Math.sin(i*R)/n)/R,r2=60-r,s=n*Math.sin(r2*R);if(Math.abs(s)>1)return{n:n,tir:true};var e=Math.asin(s)/R,a=(30-r)*R,m=Math.tan(a),x=(460-340*m/Math.sqrt(3))/(1-m/Math.sqrt(3));return{n:n,r:r,r2:r2,e:e,delta:i+e-60,entry:[340,220],exit:[x,220+(x-340)*m],inside:a,out:(e-30)*R,inc:(30-i)*R,tir:false};}
function reflect(l,p){return colors[l].rgb.map(function(v,k){return v*colors[p].rgb[k];});}
function name(rgb){var key=Object.keys(colors).find(function(k){return colors[k].rgb.every(function(v,i){return v===rgb[i];});});return colors[key].name;}
window.LightColor={colors:colors,index:index,prism:prism,reflect:reflect,name:name};
})();
