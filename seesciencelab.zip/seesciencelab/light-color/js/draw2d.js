// 绘图层：900×650逻辑舞台；窄屏600×800，缩短光源和光屏距离以放大装置，折射角不变。
(function(){
'use strict';
var C=window.LightColor,S=window.Spectrum;
function draw(canvas,s,t){
var ctx=canvas.getContext('2d'),box=canvas.getBoundingClientRect(),dpr=Math.min(devicePixelRatio||1,2),w=box.width,h=box.height;
if(canvas.width!==Math.round(w*dpr)||canvas.height!==Math.round(h*dpr)){canvas.width=Math.round(w*dpr);canvas.height=Math.round(h*dpr);}
var mobile=w<650,W=mobile?600:900,H=mobile?800:650,k=Math.min(w/W,h/H),ox=(w-W*k)/2,oy=(h-H*k)/2;
ctx.setTransform(dpr,0,0,dpr,0,0);ctx.fillStyle='#05070d';ctx.fillRect(0,0,w,h);ctx.translate(ox,oy);ctx.scale(k,k);
var hits=[];
function text(str,x,y,size,color,align){ctx.fillStyle=color||'#c5d4e4';ctx.font=((size||17)*(mobile?1:.85))+'px -apple-system,"PingFang SC",sans-serif';ctx.textAlign=align||'left';ctx.fillText(str,x,y);}
function line(pts,color,width,glow){ctx.beginPath();pts.forEach(function(p,i){i?ctx.lineTo(p[0],p[1]):ctx.moveTo(p[0],p[1]);});ctx.strokeStyle=color;ctx.lineWidth=width||2;ctx.shadowColor=color;ctx.shadowBlur=glow||0;ctx.stroke();ctx.shadowBlur=0;}
function rect(x,y,a,b,color,stroke){ctx.fillStyle=color;ctx.beginPath();ctx.roundRect(x,y,a,b,12);ctx.fill();if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=1.5;ctx.stroke();}}
function circle(x,y,r,color){ctx.beginPath();ctx.arc(x,y,r,0,Math.PI*2);ctx.fillStyle=color;ctx.fill();}
function pulse(pts,color,phase){var lengths=[],total=0;for(var i=1;i<pts.length;i++){var l=Math.hypot(pts[i][0]-pts[i-1][0],pts[i][1]-pts[i-1][1]);lengths.push(l);total+=l;}var a=((t*.15+phase)%1)*total;for(i=0;i<lengths.length;i++){if(a<=lengths[i]){var f=a/lengths[i];circle(pts[i][0]+(pts[i+1][0]-pts[i][0])*f,pts[i][1]+(pts[i+1][1]-pts[i][1])*f,3,color);return;}a-=lengths[i];}}
var bg=ctx.createRadialGradient(W*.5,H*.35,0,W*.5,H*.35,W*.8);bg.addColorStop(0,'#0e1928');bg.addColorStop(1,'#05070d');ctx.fillStyle=bg;ctx.fillRect(0,0,W,H);
text(s.scene==='prism'?(s.mono?'一束单色光，会被分开吗？':'让白光展开，看看里面有什么'):'换一盏灯，纸片会变色吗？',32,36,mobile?24:18,'#eef6ff');
text(s.scene==='prism'?'拖动发光端调角度 · 点光谱选波长':'点选纸片 · × 表示光被吸收',32,65,16,'#90aabe');
if(s.scene==='prism'){
var scale=mobile?.9:1,py=mobile?65:10,shift=mobile?-95:0,screenX=mobile?700:852,lampDistance=mobile?160:240;
ctx.save();ctx.translate(shift,py);ctx.scale(scale,scale);
// 光学暗室：台面、棱镜底座、屏幕与可拖动灯。
var table=ctx.createLinearGradient(0,330,0,450);table.addColorStop(0,'#23394a');table.addColorStop(1,'#0b1623');ctx.fillStyle=table;ctx.fillRect(20,337,860,100);line([[20,337],[880,337]],'#496174',2);
rect(322,329,165,14,'#455564');rect(365,324,80,10,'#8b9ba8');
var glass=ctx.createLinearGradient(290,160,520,320);glass.addColorStop(0,'#9ee6ff25');glass.addColorStop(.5,'#d6faff0a');glass.addColorStop(1,'#5ac8ff40');
ctx.beginPath();ctx.moveTo(400,116);ctx.lineTo(520,324);ctx.lineTo(280,324);ctx.closePath();ctx.fillStyle=glass;ctx.fill();ctx.strokeStyle='#a0d9f0';ctx.lineWidth=2;ctx.stroke();line([[400,116],[410,102],[535,311],[520,324]],'#6899b0',1);line([[410,102],[290,310],[280,324]],'#6899b0',1);
text('60°',394,157,18);text('三棱镜',400,376,20,'#bce9fa','center');
rect(screenX,147,18,260,'#263b4a','#8a9aa6');text('光屏',screenX+10,437,18,'#b8d0df','center');
var q=C.prism(s.angle,s.wave),source=[340-lampDistance*Math.cos(q.inc),220-lampDistance*Math.sin(q.inc)];
var beam=s.mono?S.lamCSS(s.wave):'#fff8df';
line([source,[340,220]],beam,6,12);
ctx.save();ctx.translate(source[0],source[1]);ctx.rotate(q.inc);rect(-65,-20,65,40,'#364b5e','#9aafbf');rect(-62,-15,20,30,'#1b2a38');ctx.fillStyle=beam;ctx.fillRect(-5,-17,8,34);ctx.restore();circle(source[0],source[1],26,'#ffffff08');
text('↕ 拖动光源',source[0],source[1]-38,17,'#ffe5a8','center');
hits.push({kind:'lamp',x:source[0]*scale+shift,y:source[1]*scale+py,r:40});
// 真实Snell光路；波长连续采样，几何分离不放大。
var waves=s.mono?[s.wave]:Array.from({length:101},function(_,j){return 700-j*3;});
ctx.save();ctx.globalAlpha=s.mono?1:.6;
waves.forEach(function(wave){var a=C.prism(s.angle,wave);if(a.tir)return;var end=[screenX,a.exit[1]+(screenX-a.exit[0])*Math.tan(a.out)],col=S.lamCSS(wave);line([a.entry,a.exit,end],col,s.mono?3:1.4,s.mono?5:0);line([[screenX+1,end[1]],[screenX+15,end[1]]],col,3);});ctx.restore();
var end=[screenX,q.exit[1]+(screenX-q.exit[0])*Math.tan(q.out)];line([q.entry,q.exit,end],S.lamCSS(s.wave),2,5);
pulse([source,q.entry,q.exit,end],s.mono?S.lamCSS(s.wave):'#fff',0);pulse([source,q.entry,q.exit,end],S.lamCSS(s.wave),.5);
if(!mobile)text(s.mono?'单色光经过棱镜，只改变传播方向':'紫光偏折更多，红光偏折较少',450,450,18,'#e2edf6','center');
ctx.restore();
var sy=mobile?500:515,barW=W-80;
rect(25,sy-35,W-50,118,'#0b111c','#30485d');text('光谱选择尺（非光屏位置）',40,sy-9,17,'#b6c9d9');
for(var j=0;j<barW;j++){ctx.fillStyle=S.lamCSS(400+j/barW*300);ctx.fillRect(40+j,sy+8,1.5,27);}
var sx=40+(s.wave-400)/300*barW;line([[sx,sy+3],[sx,sy+42]],'#fff',3);text('400 nm 紫',40,sy+65,16);text('700 nm 红',W-40,sy+65,16,null,'right');text(s.wave+' nm',W-40,sy-9,16,'#fff','right');
hits.push({kind:'spectrum',x:40,y:sy,width:barW,height:45});
if(mobile){text(s.mono?'单色光只改变方向':'紫光偏折更多 · 红光偏折较少',32,658,23,'#e0efff');text('真实光路的屏上色带较窄，选色请点光谱尺。',32,692,17);text('入射 '+s.angle.toFixed(1)+'°   /   偏向 '+q.delta.toFixed(2)+'°',32,738,20,'#ffc94a');}
}else{
var lamp=C.colors[s.lamp],rgb=C.reflect(s.lamp,s.paper),col=S.css(rgb),paper=C.colors[s.paper],lampCol=S.css(lamp.rgb),cx=W/2,top=150,bottom=mobile?380:400;
// 有灯罩、支杆的照明灯，聚光区照在摊开的纸片上。
line([[cx-140,top-35],[cx-140,bottom+30],[cx-65,bottom+30]],'#637b90',9);
ctx.save();ctx.globalAlpha=.12;ctx.beginPath();ctx.moveTo(cx-30,top+6);ctx.lineTo(cx+30,top+6);ctx.lineTo(cx+160,bottom+25);ctx.lineTo(cx-160,bottom+25);ctx.closePath();ctx.fillStyle=lampCol;ctx.fill();ctx.restore();
ctx.beginPath();ctx.moveTo(cx-55,top+5);ctx.lineTo(cx-30,top-45);ctx.lineTo(cx+30,top-45);ctx.lineTo(cx+55,top+5);ctx.closePath();ctx.fillStyle='#466176';ctx.fill();ctx.fillStyle=lampCol;ctx.fillRect(cx-47,top,94,8);text(lamp.name+'光灯',cx+80,top-10,22,'#eff5ff');
rect(25,bottom+35,W-50,34,'#263b4c');
ctx.save();ctx.shadowColor=col;ctx.shadowBlur=rgb.some(Boolean)?25:0;ctx.beginPath();ctx.moveTo(cx-125,bottom-105);ctx.lineTo(cx+105,bottom-105);ctx.lineTo(cx+145,bottom+30);ctx.lineTo(cx-145,bottom+30);ctx.closePath();ctx.fillStyle=rgb.some(Boolean)?col:'#07090d';ctx.fill();ctx.shadowBlur=0;ctx.strokeStyle='#a1b2c1';ctx.stroke();ctx.restore();
line([[cx+110,bottom-89],[cx+126,bottom-39],[cx+101,bottom-46]],'#ffffff55',2);
text(paper.name+'纸',cx,bottom+5,24,rgb.some(Boolean)?'#10202a':'#a6b6c5','center');
// 三通道沿入射路径到达纸片，能反射的通道才向观察者传播。
['#ff6b62','#60e890','#6baaff'].forEach(function(color,j){var x=cx-45+j*45,start=[x,top+25],hit=[x,bottom-65];if(lamp.rgb[j]){line([start,hit],color,3,3);pulse([start,hit],color,j/3);if(paper.rgb[j]){var dest=[cx+185,bottom-140+j*10];line([hit,dest],color,3,3);pulse([hit,dest],color,j/3);}else{line([[x-6,bottom-71],[x+6,bottom-59]],color,2);line([[x+6,bottom-71],[x-6,bottom-59]],color,2);}}});
ctx.beginPath();ctx.ellipse(cx+205,bottom-130,33,22,0,0,Math.PI*2);ctx.fillStyle='#dcebf5';ctx.fill();circle(cx+200,bottom-130,15,'#5b96ad');circle(cx+198,bottom-130,8,'#08131e');circle(cx+193,bottom-137,4,'#fff');
text(rgb.some(Boolean)?'反射光进入眼睛':'没有可反射的照明通道',W-25,bottom-190,16,'#a6c0d5','right');
text('白光参考区：点选一种纸片',32,bottom+(mobile?110:90),18,'#b8cfdf');
var keys=Object.keys(C.colors),sw=(W-64)/8;
keys.forEach(function(key,j){var x=32+j*sw,y=bottom+(mobile?130:110);rect(x,y,sw-7,55,S.css(C.colors[key].rgb),key===s.paper?'#ffc94a':'#5b7084');text(C.colors[key].name,x+(sw-7)/2,y+75,16,'#dce9f5','center');hits.push({kind:'paper',key:key,x:x,y:y,width:sw,height:72});});
text('此刻：'+lamp.name+'光 × '+paper.name+'纸 → '+(rgb.some(Boolean)?C.name(rgb)+'色反射光':'无反射光（理想近似）'),32,mobile?660:610,19,'#ffc94a');
}
window.LightDraw.layout={k:k,ox:ox,oy:oy,hits:hits,W:W,H:H};
}
window.LightDraw={draw:draw,layout:null};
})();
