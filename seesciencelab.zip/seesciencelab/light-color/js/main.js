(function(){
'use strict';
var C=window.LightColor,p=new URLSearchParams(location.search),$=function(id){return document.getElementById(id);};
function num(key,def,min,max){var v=Number(p.get(key));return p.has(key)&&Number.isFinite(v)?Math.max(min,Math.min(max,v)):def;}
var state={scene:p.get('scene')==='paper'?'paper':'prism',angle:num('angle',50,45,65),wave:num('wave',550,400,700),mono:p.get('mono')==='1',lamp:C.colors[p.get('lamp')]&&p.get('lamp')!=='black'?p.get('lamp'):'white',paper:C.colors[p.get('paper')]?p.get('paper'):'green',play:p.has('play')?p.get('play')!=='0':!matchMedia('(prefers-reduced-motion: reduce)').matches};
var canvas=$('view'),time=0,previous=0,drag=false,dragOffsetY=0;
function track(action,label){if(window.Analytics)Analytics.track('光的色散与物体颜色',action,String(label));}
function update(){
state.angle=Math.max(45,Math.min(65,Number(state.angle)||50));state.wave=Math.max(400,Math.min(700,Number(state.wave)||550));
$('angle').value=state.angle;$('wave').value=state.wave;$('mono').checked=state.mono;$('lamp').value=state.lamp;$('paper').value=state.paper;
$('angleOut').textContent=state.angle.toFixed(1)+'°';$('waveOut').textContent=state.wave+' nm';$('prismControls').hidden=state.scene!=='prism';$('paperControls').hidden=state.scene!=='paper';
document.querySelectorAll('[data-scene]').forEach(function(b){b.classList.toggle('on',b.dataset.scene===state.scene);});
$('quickLights').hidden=state.scene!=='paper';
document.querySelectorAll('[data-lamp]').forEach(function(b){b.classList.toggle('on',b.dataset.lamp===state.lamp);b.setAttribute('aria-pressed',String(b.dataset.lamp===state.lamp));});
document.querySelectorAll('[data-scene]').forEach(function(b){b.setAttribute('aria-pressed',String(b.dataset.scene===state.scene));});
$('play').textContent=state.play?'暂停光路动画':'播放光路动画';
if(state.scene==='prism'){var q=C.prism(state.angle,state.wave);$('result').textContent=state.mono?'单色光只改变方向':'白光展开成连续光谱';$('explain').textContent='选中'+Spectrum.colorName(state.wave)+'：'+state.wave+' nm。短波光在本模型中偏折更多；下方光谱尺不代表屏上位置。';$('numbers').innerHTML='<dt>折射率 n</dt><dd>'+q.n.toFixed(4)+'</dd><dt>偏向角 δ</dt><dd>'+q.delta.toFixed(2)+'°</dd><dt>400 / 700 nm偏向角</dt><dd>'+C.prism(state.angle,400).delta.toFixed(2)+'° / '+C.prism(state.angle,700).delta.toFixed(2)+'°</dd>';}
else{var rgb=C.reflect(state.lamp,state.paper);$('result').textContent=rgb.some(Boolean)?'看起来是'+C.name(rgb)+'色':'纸片看起来很暗';$('explain').textContent=C.colors[state.lamp].name+'光照'+C.colors[state.paper].name+'纸。只有照明光中存在、又能被纸片反射的通道才能返回观察者。';$('numbers').innerHTML='<dt>入射 R G B</dt><dd>'+C.colors[state.lamp].rgb.join(' · ')+'</dd><dt>反射比例 R G B</dt><dd>'+C.colors[state.paper].rgb.join(' · ')+'</dd><dt>反射光 R G B</dt><dd>'+rgb.join(' · ')+'</dd>';}
}
['lamp','paper'].forEach(function(id){Object.keys(C.colors).filter(function(key){return id==='paper'||key!=='black';}).forEach(function(key){var op=document.createElement('option');op.value=key;op.textContent=C.colors[key].name+(id==='lamp'?'光':'纸');$(id).appendChild(op);});$(id).addEventListener('change',function(){state[id]=this.value;update();track(id,state[id]);});});
document.querySelectorAll('[data-scene]').forEach(function(b){b.onclick=function(){scene(b.dataset.scene);};});
document.querySelectorAll('[data-lamp]').forEach(function(b){b.onclick=function(){state.lamp=b.dataset.lamp;update();track('画面照明',state.lamp);};});
function scene(name){state.scene=name==='paper'?'paper':'prism';update();track('场景',state.scene);}
['angle','wave'].forEach(function(id){$(id).oninput=function(){state[id]=Number(this.value);update();};$(id).onchange=function(){track(id,state[id]);};});
$('mono').onchange=function(){state.mono=this.checked;update();track('单色光',state.mono);};$('play').onclick=function(){state.play=!state.play;update();track('播放',state.play);};
$('reset').onclick=function(){Object.assign(state,{angle:50,wave:550,mono:false,lamp:'white',paper:'green',play:!matchMedia('(prefers-reduced-motion: reduce)').matches});time=0;update();track('重置',state.scene);};
$('share').onclick=async function(){var u=new URL(location.href);u.hash='';u.search=new URLSearchParams({scene:state.scene,angle:state.angle,wave:state.wave,mono:state.mono?'1':'0',lamp:state.lamp,paper:state.paper,play:state.play?'1':'0'}).toString();try{await navigator.clipboard.writeText(u.href);$('status').textContent='已复制当前实验链接';}catch(e){$('status').textContent=u.href;}track('分享',state.scene);};
$('panelToggle').onclick=function(){$('panel').classList.toggle('collapsed');$('panelToggle').setAttribute('aria-expanded',String(!$('panel').classList.contains('collapsed')));};if(innerWidth<=760)$('panel').classList.add('collapsed');$('panelToggle').setAttribute('aria-expanded',String(!$('panel').classList.contains('collapsed')));
function point(e){var r=canvas.getBoundingClientRect(),l=LightDraw.layout;return l?{x:(e.clientX-r.left-l.ox)/l.k,y:(e.clientY-r.top-l.oy)/l.k}:null;}
function hit(p){return LightDraw.layout.hits.find(function(h){return h.r?Math.hypot(p.x-h.x,p.y-h.y)<=h.r:p.x>=h.x&&p.x<=h.x+h.width&&p.y>=h.y&&p.y<=h.y+h.height;});}
function move(p){var l=LightDraw.layout;if(drag==='lamp'){var scale=l.W===600?.9:1,py=l.W===600?65:10,distance=l.W===600?160:240;var y=(p.y-dragOffsetY-py)/scale;state.angle=30-Math.asin(Math.max(-1,Math.min(1,(220-y)/distance)))*180/Math.PI;update();}else if(drag==='spectrum'){var bar=l.hits.find(function(h){return h.kind==='spectrum';});state.wave=Math.round(400+(p.x-bar.x)/bar.width*300);update();}}
canvas.onpointerdown=function(e){var p=point(e);if(!p)return;var h=hit(p);if(!h)return;if(h.kind==='paper'){state.paper=h.key;update();track('点选纸片',h.key);}else{drag=h.kind;dragOffsetY=p.y-h.y;canvas.setPointerCapture(e.pointerId);canvas.classList.add('dragging');move(p);}};
canvas.onpointermove=function(e){var p=point(e);if(!p)return;if(drag)move(p);else canvas.style.cursor=hit(p)?'pointer':'default';};
function stop(){if(drag)track('画面拖动',drag);drag=false;canvas.classList.remove('dragging');}canvas.onpointerup=stop;canvas.onpointercancel=stop;canvas.onlostpointercapture=stop;
function frame(ms){if(state.play)time+=Math.min((ms-previous)/1000,.05);previous=ms;LightDraw.draw(canvas,state,time);requestAnimationFrame(frame);}
window.__model={state:state,update:update,scene:scene,setAngle:function(a){state.angle=a;update();}};update();requestAnimationFrame(frame);
})();
