/* 质量 g、体积 mL（=cm³）、密度 g/cm³；计算不依赖DOM。 */
(function () {
  'use strict';
  const samples = {
    stone: { name: '矿石', mass: 54, volume: 20, color: '#b7b1a3' },
    metal: { name: '金属块', mass: 78, volume: 10, color: '#a0bcc9' }
  };
  const weights = [100, 50, 20, 20, 10, 5];
  function solve(s) {
    const sample = samples[s.sample] || samples.stone;
    const left = s.scene === 'solid' ? (s.place === 'scale' ? sample.mass : 0) : 40 + (80 - s.poured) * 1.1;
    const right = weights.reduce((a, w, i) => a + (s.weights[i] ? w : 0), 0) + s.rider;
    return { left, right, difference: left - right, balanced: Math.abs(left - right) < 0.051,
      cylinder: s.scene === 'solid' ? s.water + (s.place === 'water' ? sample.volume : 0) : s.poured,
      sample, density: sample.mass / sample.volume };
  }
  function balance(mass) {
    const placed = weights.map(w => { if (mass >= w - 1e-8) { mass -= w; return true; } return false; });
    return { weights: placed, rider: Math.round(mass * 10) / 10 };
  }
  function result(s) {
    if (s.scene === 'solid') {
      if (s.m === null || s.v1 === null || s.v2 === null || s.v2 <= s.v1) return null;
      return { mass: s.m, volume: s.v2 - s.v1, density: s.m / (s.v2 - s.v1) };
    }
    if (s.m1 === null || s.m2 === null || s.v === null || s.v <= 0 || s.m1 <= s.m2) return null;
    return { mass: s.m1 - s.m2, volume: s.v, density: (s.m1 - s.m2) / s.v };
  }
  window.DensityPhysics = { samples, weights, solve, balance, result };
}());
