(function () {
  'use strict';
  const P=window.DensityPhysics,D=window.DensityDraw,$=id=>document.getElementById(id),canvas=$('experiment');
  const params=new URLSearchParams(location.search);
  const state={scene:'solid',sample:'stone',place:'scale',water:40,weights:[false,true,false,false,false,false],rider:4,poured:0,m:null,v1:null,v2:null,m1:null,m2:null,v:null,records:[]};
  let hover=null,drag=null,start=null,layout;
  const track=(a,l)=>window.Analytics?.track('密度测量',a,String(l||state.scene));
  function number(name,min,max,fallback){const raw=params.get(name);const n=raw===null?NaN:Number(raw);return Number.isFinite(n)?Math.max(min,Math.min(max,n)):fallback;}
  function clearMeasurements(){for(const k of ['m','v1','v2','m1','m2','v'])state[k]=null;}
  function setScene(scene){state.scene=scene==='liquid'?'liquid':'solid';state.place='scale';state.poured=0;state.weights=P.balance(P.solve(state).left).weights;state.rider=P.balance(P.solve(state).left).rider;clearMeasurements();update();track('切换场景');}
  function move(place){if(state.scene!=='solid')return;state.place=['scale','table','water'].includes(place)?place:'table';update();track('移动物体',state.place);}
  function pour(){if(state.scene!=='liquid')return;if(state.poured){message('本轮已经倒出40 mL；点“重新实验”可再次操作。');return;}state.poured=40;update();track('倒出液体');}
  function message(s){$('status').textContent=s;$('stageStatus').textContent=s;}
  function update(){
    const q=P.solve(state),r=P.result(state);
    document.querySelectorAll('[data-scene]').forEach(b=>{b.classList.toggle('on',b.dataset.scene===state.scene);b.setAttribute('aria-pressed',b.dataset.scene===state.scene);});
    $('sampleRow').hidden=state.scene!=='solid';$('solidActions').hidden=state.scene!=='solid';$('liquidActions').hidden=state.scene!=='liquid';
    $('sample').value=state.sample;$('water').value=state.water;$('waterValue').textContent=state.water+' mL';$('rider').value=state.rider;$('riderValue').textContent=state.rider.toFixed(1)+' g';
    $('readMass').textContent=q.right.toFixed(1)+' g';$('balanceState').textContent=q.balanced?'已平衡，可以记录':q.difference>0?'左重：增加砝码或右移游码':'右重：减小砝码或左移游码';
    $('readVolume').textContent=q.cylinder.toFixed(0)+' mL';$('density').textContent=r?r.density.toFixed(2)+' g/cm³':'等待实验记录';
    $('massBtn').disabled=!q.balanced||(state.scene==='solid'&&state.place!=='scale');
    $('volumeBtn').disabled=state.scene==='solid'?state.place==='scale':state.poured===0;
    $('pourBtn').disabled=state.poured>0;
    $('weightButtons').innerHTML=P.weights.map((w,i)=>`<button type="button" data-weight="${i}" aria-pressed="${state.weights[i]}" class="${state.weights[i]?'on':''}">${w} g${i===3?' ②':''}</button>`).join('');
    $('ledger').innerHTML=state.scene==='solid'?`<dt>干燥物体 m</dt><dd>${fmt(state.m,'g')}</dd><dt>原水面 V₁</dt><dd>${fmt(state.v1,'mL')}</dd><dt>浸没后 V₂</dt><dd>${fmt(state.v2,'mL')}</dd>`:`<dt>倒出前 m₁</dt><dd>${fmt(state.m1,'g')}</dd><dt>倒出后 m₂</dt><dd>${fmt(state.m2,'g')}</dd><dt>倒出体积 V</dt><dd>${fmt(state.v,'mL')}</dd>`;
    $('saveBtn').disabled=!r;
    document.querySelectorAll('[data-place]').forEach(b=>{b.classList.toggle('on',b.dataset.place===state.place);b.setAttribute('aria-pressed',b.dataset.place===state.place);});
    const solid=state.scene==='solid';
    const phase=solid?(state.m===null?0:state.v1===null?1:state.v2===null?2:3):(state.m1===null?0:!state.poured?1:state.m2===null?2:state.v===null?3:4);
    $('stepCount').textContent=r?'测量完成':`${Math.min(phase+1,solid?3:4)} / ${solid?3:4}`;
    let label,action;
    if(solid){
      if(state.m===null){label=state.place!=='scale'?'放回左盘':!q.balanced?'配平天平（示范）':'记录质量 m';action=state.place!=='scale'?()=>move('scale'):!q.balanced?()=>$('hintBtn').click():recordMass;}
      else if(state.v1===null){label=state.place!=='table'?'移到桌面，读原水面':'记录原水面 V₁';action=state.place!=='table'?()=>move('table'):recordVolume;}
      else if(state.v2===null){label=state.place!=='water'?'放入量筒，观察排水':'记录浸没后 V₂';action=state.place!=='water'?()=>move('water'):recordVolume;}
    }else{
      if(state.m1===null&&state.poured){label='重新实验，先记录 m₁';action=()=>$('resetBtn').click();}
      else if(state.m1===null||state.poured&&state.m2===null){label=!q.balanced?'配平天平（示范）':state.poured?'记录倒出后 m₂':'记录倒出前 m₁';action=!q.balanced?()=>$('hintBtn').click():recordMass;}
      else if(!state.poured){label='倒入量筒 40 mL';action=pour;}
      else if(state.v===null){label='记录倒出体积 V';action=recordVolume;}
    }
    if(!label&&!r){label='读数不完整，重新测量';action=()=>$('resetBtn').click();}
    $('nextBtn').textContent=label||'保存本轮结果';$('nextBtn').onclick=action||(()=>$('saveBtn').click());
    $('stageResult').classList.toggle('complete',!!r);
    $('stageResult').textContent=r?`${r.mass.toFixed(1)} g ÷ ${r.volume.toFixed(0)} cm³ = ${r.density.toFixed(2)} g/cm³`:solid?'ρ = m / (V₂ − V₁)':'ρ = (m₁ − m₂) / V';
    $('records').innerHTML=state.records.length?'<table><tr><th>对象</th><th>m / g</th><th>V / cm³</th><th>ρ / g·cm⁻³</th></tr>'+state.records.map(a=>`<tr><td>${a.name}</td><td>${a.mass.toFixed(1)}</td><td>${a.volume.toFixed(0)}</td><td>${a.density.toFixed(2)}</td></tr>`).join('')+'</table>':'<p class="note">完成一轮测量后，在这里保留结果。</p>';
    message(r?(state.scene==='solid'?'测量完成：物体体积取两次读数之差。':'测量完成：质量差与体积对应同一份液体。'):state.scene==='solid'?(state.m===null?'① 先称干燥'+q.sample.name+'：平衡后记录质量。':state.v1===null?'② 把物体移到桌面，记录原水面。':state.v2===null?'③ 将物体放进量筒，记录浸没后读数。':'④ 用两次水面读数之差计算体积。'):(state.m1===null?'① 先称烧杯和液体，记录倒出前质量。':!state.poured?'② 点烧杯倒出40 mL；不要冲洗烧杯。':state.m2===null?'③ 重新调砝码和游码，记录倒出后质量。':'④ 记录量筒体积，用质量差计算密度。'));
  }
  function fmt(v,u){return v===null?'—':v.toFixed(u==='g'?1:0)+' '+u;}
  function toggleWeight(i){state.weights[i]=!state.weights[i];update();track('取放砝码',P.weights[i]);}
  function recordMass(){const q=P.solve(state);if(!q.balanced)return;if(state.scene==='solid'){if(state.place!=='scale')return;state.m=q.right;}else if(!state.poured)state.m1=q.right;else state.m2=q.right;update();track('记录质量');}
  function recordVolume(){if(state.scene==='solid'){if(state.place==='table')state.v1=P.solve(state).cylinder;else if(state.place==='water')state.v2=P.solve(state).cylinder;else return;}else{if(!state.poured)return;state.v=state.poured;}update();track('记录体积');}
  $('scenes').onclick=e=>{if(e.target.dataset.scene)setScene(e.target.dataset.scene);};
  $('weightButtons').onclick=e=>{const b=e.target.closest('[data-weight]');if(b)toggleWeight(Number(b.dataset.weight));};
  $('rider').oninput=e=>{state.rider=Number(e.target.value);update();};$('rider').onchange=()=>track('移动游码',state.rider);
  $('sample').onchange=e=>{state.sample=e.target.value;state.place='scale';clearMeasurements();state.weights=Array(6).fill(false);state.rider=0;update();track('更换物体',state.sample);};
  $('water').oninput=e=>{state.water=Number(e.target.value);state.v1=null;state.v2=null;update();};$('water').onchange=()=>track('改变水量',state.water);
  document.querySelectorAll('[data-place]').forEach(b=>b.onclick=()=>move(b.dataset.place));
  $('quickReset').onclick=()=>$('resetBtn').click();$('pourBtn').onclick=pour;$('massBtn').onclick=recordMass;$('volumeBtn').onclick=recordVolume;
  $('resetBtn').onclick=()=>{setScene(state.scene);track('重做');};
  $('hintBtn').onclick=()=>{const a=P.balance(P.solve(state).left);state.weights=a.weights;state.rider=a.rider;update();message('已按当前左盘质量配平；试着自己增减砝码，观察指针。');track('配平示范');};
  $('saveBtn').onclick=()=>{const r=P.result(state);if(r){state.records.unshift({...r,name:state.scene==='solid'?P.samples[state.sample].name:'液体'});state.records.length=Math.min(6,state.records.length);update();track('保存结果');}};
  $('clearBtn').onclick=()=>{state.records=[];update();};
  function shareURL(){const p=new URLSearchParams({scene:state.scene,sample:state.sample,water:state.water,place:state.place,rider:state.rider,weights:state.weights.map(v=>v?'1':'0').join(''),poured:state.poured});for(const k of ['m','v1','v2','m1','m2','v'])if(state[k]!==null)p.set(k,state[k]);return location.origin+location.pathname+'?'+p;}
  $('shareBtn').onclick=async()=>{const url=shareURL();try{await navigator.clipboard.writeText(url);message('实验条件链接已复制。');}catch{$('shareLink').hidden=false;$('shareLink').value=url;$('shareLink').select();message('请复制下方实验条件链接。');}track('分享条件');};
  function togglePanel(){const closed=$('panel').classList.toggle('collapsed');$('panelToggle').textContent=closed?'实验设置':'收起设置';$('panelToggle').setAttribute('aria-expanded',String(!closed));} $('panelToggle').onclick=togglePanel;if(matchMedia('(max-width:760px)').matches){$('panel').classList.add('collapsed');$('panelToggle').setAttribute('aria-expanded','false');}
  canvas.onpointerdown=e=>{const p=D.point(e),h=D.hit(p);if(!h)return;canvas.setPointerCapture(e.pointerId);start={...p};drag={...h,x:p.x,y:p.y};hover=h;};
  canvas.onpointermove=e=>{const p=D.point(e);if(drag){drag.x=p.x;drag.y=p.y;if(drag.id==='rider'){state.rider=Math.round(Math.max(0,Math.min(5,(p.x-(layout.b.x-75))/150*5))*5)/5;update();}}else hover=D.hit(p);canvas.style.cursor=drag?'grabbing':hover?'grab':'default';};
  canvas.onpointerup=e=>{if(!drag)return;const p=D.point(e),id=drag.id,moved=Math.hypot(p.x-start.x,p.y-start.y)>7;
    if(id==='object'){if(!moved)move(state.place==='scale'?'table':state.place==='table'?'water':'scale');else if(Math.abs(p.x-layout.cy.x)<70&&p.y>layout.cy.top-40)move('water');else if(Math.abs(p.x-(layout.b.x-134))<75&&p.y<layout.b.y+95)move('scale');else move('table');}
    if(id==='weight'){if(!moved||p.y>layout.b.y+110){state.weights[drag.index]=false;update();track('移除砝码');}}
    if(id==='rack'){if(!moved||(Math.abs(p.x-(layout.b.x+134))<80&&p.y<layout.b.y+110)){state.weights[drag.index]=true;update();track('添加砝码');}}
    if(id==='beaker'&&!moved)pour();if(id==='rider')track('拖动游码',state.rider);
    drag=null;hover=null;};
  canvas.onpointercancel=()=>{drag=null;hover=null;};canvas.onpointerleave=()=>{if(!drag)hover=null;};
  if(params.get('scene')==='liquid')state.scene='liquid';if(P.samples[params.get('sample')])state.sample=params.get('sample');
  if(['scale','table','water'].includes(params.get('place')))state.place=params.get('place');state.water=Math.round(number('water',20,60,40)/2)*2;
  state.poured=params.get('poured')==='40'?40:0;const a=P.balance(P.solve(state).left);state.weights=a.weights;state.rider=a.rider;
  if(/^[01]{6}$/.test(params.get('weights')||''))state.weights=params.get('weights').split('').map(v=>v==='1');
  state.rider=Math.round(number('rider',0,5,state.rider)*5)/5;
  for(const k of ['m','m1','m2'])if(params.has(k))state[k]=Math.round(number(k,0,210,0)*10)/10;
  for(const k of ['v1','v2','v'])if(params.has(k))state[k]=Math.round(number(k,0,100,0));
  update();
  function frame(){layout=D.draw(canvas,state,hover,drag);requestAnimationFrame(frame);}requestAnimationFrame(frame);
  window.__model={state,update,setScene,move,pour,recordMass,recordVolume,shareURL,solve:()=>P.solve(state),result:()=>P.result(state),get layout(){return layout;},get targets(){return D.targets;}};
}());
