(function () {
  'use strict';
  const P = window.DensityPhysics;
  let c, ctx, layout, targets = [];
  const gold = '#ffc94a', blue = '#74d8ec', muted = '#94a6bb';
  function text(t, x, y, size = 16, color = muted, align = 'center') {
    ctx.font = `${size}px -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif`;
    ctx.fillStyle = color; ctx.textAlign = align; ctx.fillText(t, x, y);
  }
  function line(x1,y1,x2,y2,color,width=1) { ctx.beginPath();ctx.moveTo(x1,y1);ctx.lineTo(x2,y2);ctx.strokeStyle=color;ctx.lineWidth=width;ctx.stroke(); }
  function box(x,y,w,h,color,r=8) { ctx.beginPath();ctx.roundRect(x,y,w,h,r);ctx.fillStyle=color;ctx.fill(); }
  function ellipse(x,y,rx,ry,fill,stroke) {ctx.beginPath();ctx.ellipse(x,y,rx,ry,0,0,Math.PI*2);if(fill){ctx.fillStyle=fill;ctx.fill();}if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=1.5;ctx.stroke();}}
  function target(id,x,y,w,h,extra) {targets.push({id,x,y,w,h,...extra});}
  function stone(x,y,s,ghost=false) {
    ctx.save();ctx.translate(x,y);ctx.globalAlpha=ghost?.6:1;
    ctx.beginPath();ctx.moveTo(-25,-15);ctx.lineTo(-13,-32);ctx.lineTo(14,-29);ctx.lineTo(27,-7);ctx.lineTo(20,15);ctx.lineTo(-8,20);ctx.lineTo(-28,7);ctx.closePath();
    const g=ctx.createLinearGradient(-25,-30,25,20);g.addColorStop(0,'#dfd5b6');g.addColorStop(.4,P.samples[s.sample].color);g.addColorStop(1,'#616975');ctx.fillStyle=g;ctx.fill();ctx.strokeStyle='#d9d9c0';ctx.stroke();
    line(-13,-30,-3,-9,'#e2daca88');line(-3,-9,24,-5,'#d8dfda88');line(-3,-9,-8,18,'#4f586777');ctx.restore();
  }
  function beaker(x,y,amount,small=false) {
    const w=small?48:62,h=small?54:70;
    const level=y-amount/80*(h-10);
    ctx.fillStyle='#64ccdf44';ctx.fillRect(x-w/2+3,level,w-6,y-level);
    ellipse(x,level,(w-6)/2,4,'#90e1eb55','#8dd4dd99');
    ctx.beginPath();ctx.moveTo(x-w/2-5,y-h);ctx.lineTo(x-w/2,y-h+7);ctx.lineTo(x-w/2,y);ctx.quadraticCurveTo(x,y+8,x+w/2,y);ctx.lineTo(x+w/2,y-h);ctx.strokeStyle='#b0d8df';ctx.lineWidth=2;ctx.stroke();
    line(x-w/2+8,y-h+8,x-w/2+8,y-7,'#e0f4f044',3);
  }
  function weight(x,y,w,on) {
    const g=ctx.createLinearGradient(x-16,y,x+16,y);g.addColorStop(0,'#565f6a');g.addColorStop(.45,'#cbd0cd');g.addColorStop(1,'#68747d');
    box(x-16,y-29,32,29,g,4);box(x-7,y-36,14,9,'#b8c0c2',3);text(w,x,y-10,13,'#17232c');
    if(on)ellipse(x,y+3,18,3,'#00000033');
  }
  function draw(canvas,s,hover,drag) {
    c=canvas;ctx=c.getContext('2d');const rect=c.getBoundingClientRect(),dpr=Math.min(devicePixelRatio||1,2);
    if(c.width!==Math.round(rect.width*dpr)||c.height!==Math.round(rect.height*dpr)){c.width=Math.round(rect.width*dpr);c.height=Math.round(rect.height*dpr);}
    const mobile=rect.width<600,W=mobile?420:900,H=mobile?730:650;
    const scale=Math.min(rect.width/W,rect.height/H),ox=(rect.width-W*scale)/2,oy=(rect.height-H*scale)/2;
    ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,rect.width,rect.height);ctx.translate(ox,oy);ctx.scale(scale,scale);
    targets=[];const b={x:mobile?210:290,y:mobile?145:245};const cy={x:mobile?300:700,bottom:mobile?660:515,top:mobile?400:255};const home={x:mobile?90:465,y:mobile?565:500};
    layout={W,H,scale,ox,oy,b,cy,home};const q=P.solve(s);
    // 装置区域：细边框与低亮台面保留器材的视觉主导地位。
    if(mobile){box(12,52,396,664,'#0c121e',16);}
    else {box(28,94,520,508,'#0c121e',18);box(568,94,304,508,'#0c121e',18);}
    text(s.scene==='solid'?'密度测量 · 固体排水法':'密度测量 · 液体差量法',mobile?20:40,mobile?30:52,mobile?17:18,'#e6edf7','left');
    if(!mobile)text('称质量，量体积，让两份读数对应同一物体。',40,77,12,muted,'left');
    text('01  天平 · 左物右码',b.x,mobile?80:133,14,'#c8d5e7');
    // 不平衡时重的一侧降低；仅示意，不计算天平动力学。
    const angle=-Math.max(-.075,Math.min(.075,q.difference*.008));
    const leftY=b.y-Math.sin(angle)*134,rightY=b.y+Math.sin(angle)*134;
    const metal=ctx.createLinearGradient(0,b.y-10,0,b.y+145);metal.addColorStop(0,'#8396a1');metal.addColorStop(.6,'#35485e');metal.addColorStop(1,'#172234');
    box(b.x-94,b.y+114,188,23,metal,12);box(b.x-17,b.y+9,34,109,metal,8);
    ctx.save();ctx.translate(b.x,b.y);ctx.rotate(angle);box(-144,-4,288,8,'#8d9ca4',3);ctx.restore();
    for(const [x,y] of [[b.x-134,leftY],[b.x+134,rightY]]){
      line(x,y,x-42,y+52,'#a8b4b7',1.5);line(x,y,x+42,y+52,'#a8b4b7',1.5);
      ellipse(x,y+54,45,8,'#8c9da4','#ced9da');ellipse(x,y+51,41,5,'#536b79');
    }
    // 指针与中央零位刻度，指针随横梁偏转。
    ctx.beginPath();ctx.arc(b.x,b.y-26,36,Math.PI,2*Math.PI);ctx.strokeStyle='#6e8b9c';ctx.stroke();
    for(let i=-3;i<=3;i++)line(b.x+i*9,b.y-61,b.x+i*9,b.y-55,i===0?gold:'#657e8e',i===0?2:1);
    line(b.x,b.y-7,b.x+Math.sin(angle)*210,b.y-58,gold,2.5);ellipse(b.x,b.y,8,8,'#d5dde0');
    text(q.balanced?'平衡':q.difference>0?'左盘较重':'右盘较重',b.x,b.y+91,16,q.balanced?'#8cddbb':gold);
    if(s.scene==='solid'&&s.place==='scale'&&drag?.id!=='object')stone(b.x-134,leftY+27,s);
    if(s.scene==='liquid'){beaker(b.x-134,leftY+44,80-s.poured,true);target('beaker',b.x-134,leftY+12,68,70);}
    const on=s.weights.map((v,i)=>v?i:-1).filter(i=>i>=0);
    on.forEach((i,j)=>{let x=b.x+134+(j%3-1)*25,y=rightY+47-Math.floor(j/3)*37;weight(x,y,P.weights[i],true);target('weight',x,y-17,36,48,{index:i});});
    // 标尺的游码以左边缘读数：0..5g，分度0.2g。
    const rx=b.x-75,ry=b.y+153,rw=150;
    box(rx-10,ry-8,rw+26,44,'#b2b9bd',4);
    for(let i=0;i<=25;i++){const x=rx+i*rw/25;line(x,ry,x,ry+(i%5===0?13:7),'#273641');if(i%5===0)text(i/5,x,ry+28,12,'#25323b');}
    const riderX=rx+s.rider/5*rw;box(riderX,ry-12,10,33,'#dd9952',2);line(riderX,ry-13,riderX,ry+15,'#ffefbc',2);target('rider',riderX+5,ry+4,44,50);
    text('游码左边缘 '+s.rider.toFixed(1)+' g',b.x,ry+59,14,'#c2cbc8');
    const rackY=mobile?426:552,rackX=mobile?38:140;
    if(mobile) text('砝码盒 · 点取 / 拖到右盘',116,377,12,muted);
    else text('砝码盒 · 点取或拖动',b.x,500,12,muted);
    box(rackX-22,rackY-44,225,55,'#203440',8);
    P.weights.forEach((w,i)=>{const x=rackX+i*36;if(!s.weights[i])weight(x,rackY,w,false);else{ellipse(x,rackY-10,14,5,null,'#52616a');}target('rack',x,rackY-17,35,50,{index:i});});
    // 量筒100mL、最小分度2mL，弯月面底恰与体积刻度同高。
    text('02  量筒 · 平视凹液面底',mobile?28:cy.x,mobile?460:133,14,'#c4d7db',mobile?'left':'center');
    const y=v=>cy.bottom-v*2.4;
    if(s.scene==='solid'){
      ctx.setLineDash([4,4]);line(cy.x-39,y(s.water),cy.x+69,y(s.water),'#a6cad680');ctx.setLineDash([]);
      text('V₁',cy.x+62,y(s.water)+17,13,'#abc6ce');
    }
    const level=y(q.cylinder);
    const water=ctx.createLinearGradient(cy.x-36,0,cy.x+36,0);water.addColorStop(0,'#4cbbdb55');water.addColorStop(.5,'#1c718755');water.addColorStop(1,'#60d8e077');
    ctx.beginPath();ctx.moveTo(cy.x-34,level-5);ctx.quadraticCurveTo(cy.x,level+5,cy.x+34,level-5);ctx.lineTo(cy.x+34,cy.bottom);ctx.lineTo(cy.x-34,cy.bottom);ctx.closePath();ctx.fillStyle=water;ctx.fill();
    if(s.scene==='solid'&&s.place==='water'&&drag?.id!=='object'){
      line(cy.x,cy.top-14,cy.x,cy.bottom-58,'#c6d6ca',1);stone(cy.x,cy.bottom-29,s);
    }
    ctx.beginPath();ctx.moveTo(cy.x-40,cy.top-2);ctx.lineTo(cy.x-38,cy.bottom);ctx.quadraticCurveTo(cy.x,cy.bottom+14,cy.x+38,cy.bottom);ctx.lineTo(cy.x+38,cy.top-2);ctx.strokeStyle='#b1d6dd';ctx.lineWidth=2;ctx.stroke();
    ellipse(cy.x,cy.top-2,39,6,null,'#95b8c6');box(cy.x-52,cy.bottom+11,104,9,'#6d8b98',4);
    line(cy.x-29,cy.top+11,cy.x-29,cy.bottom-5,'#e0faff22',4);
    for(let v=10;v<=100;v+=2){const yy=y(v);line(cy.x+12,yy,cy.x+(v%10===0?36:25),yy,'#b7d0d5',v%10===0?1.5:1);if(v%10===0)text(v,cy.x+44,yy+4,12,'#c3d9df','left');}
    if(q.cylinder>0){ctx.beginPath();ctx.moveTo(cy.x-34,level-5);ctx.quadraticCurveTo(cy.x,level+5,cy.x+34,level-5);ctx.strokeStyle=blue;ctx.lineWidth=2;ctx.stroke();line(cy.x-73,level,cy.x-36,level,blue);text(q.cylinder.toFixed(0)+' mL',cy.x-40,level-12,17,blue,'right');}
    text('100 mL · 分度 2 mL',cy.x,cy.bottom+43,12,muted);
    if(s.scene==='solid'&&s.place==='water'){text('排水体积',mobile?96:cy.x, mobile?499:185,12,muted);text(`${q.cylinder} − ${s.water} = ${q.sample.volume} cm³`,mobile?96:cy.x,mobile?523:211,16,gold);}
    target('cylinder',cy.x,(cy.top+cy.bottom)/2,100,cy.bottom-cy.top+30);
    if(s.scene==='solid'){
      if(s.place==='table'&&drag?.id!=='object')stone(home.x,home.y,s);
      const pos=s.place==='scale'?{x:b.x-134,y:leftY+27}:s.place==='water'?{x:cy.x,y:cy.bottom-29}:home;
      target('object',pos.x,pos.y,65,70);
      if(drag?.id==='object')stone(drag.x,drag.y,s,true);
      text('拖待测物到左盘 / 量筒',mobile?103:290,mobile?612:580,12,muted);
    } else {
      text(s.poured?'量筒接住了倒出的液体':'点烧杯，倒出40 mL',mobile?105:290,mobile?551:575,12,blue);
      text('烧杯留在左盘上称量',mobile?105:290,mobile?577:594,12,muted);
    }
    if(hover) {const t=targets.find(t=>t.id===hover.id&&t.index===hover.index);if(t){ctx.strokeStyle='#ffc94a99';ctx.lineWidth=2;ctx.beginPath();ctx.roundRect(t.x-t.w/2,t.y-t.h/2,t.w,t.h,10);ctx.stroke();}}
    return layout;
  }
  function point(e) {const r=c.getBoundingClientRect();return{x:(e.clientX-r.left-layout.ox)/layout.scale,y:(e.clientY-r.top-layout.oy)/layout.scale};}
  function hit(p) {return targets.filter(t=>Math.abs(p.x-t.x)<Math.max(t.w/2,22/layout.scale)&&Math.abs(p.y-t.y)<Math.max(t.h/2,22/layout.scale)).sort((a,b)=>(a.id==='object'?-1:0)-(b.id==='object'?-1:0)||Math.hypot(p.x-a.x,p.y-a.y)-Math.hypot(p.x-b.x,p.y-b.y))[0];}
  window.DensityDraw={draw,point,hit,get layout(){return layout;},get targets(){return targets;}};
}());
