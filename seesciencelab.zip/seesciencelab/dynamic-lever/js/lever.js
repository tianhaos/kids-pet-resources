// 均匀直杆绕固定铰链缓慢转动；所有距离沿杆量取，SI 单位。
(function () {
  'use strict';
  const L = 2, g = 10, loadAt = 0.75;
  function solve(s, angle = s.angle) {
    const rad = angle * Math.PI / 180, c = Math.cos(rad), sn = Math.sin(rad);
    const effortR = L * (1 - s.pivot), loadR = L * (loadAt - s.pivot);
    const centerR = L * (0.5 - s.pivot);
    const torque0 = g * (s.load * loadR + s.mass * centerR);
    const torque = torque0 * c;
    const vertical = torque0 / effortR, normal = vertical * c;
    const force = s.scene === 'normal' ? normal : vertical;
    const fx = s.scene === 'normal' ? -force * sn : 0;
    const fy = s.scene === 'normal' ? force * c : force;
    const arm = s.scene === 'normal' ? effortR : effortR * c;
    return {rad,c,sn,effortR,loadR,centerR,torque,vertical,normal,force,arm,
      loadArm:loadR*c, centerArm:centerR*c,
      rx:-fx, ry:g*(s.mass+s.load)-fy, fx, fy};
  }
  window.DynamicLever = {L,g,loadAt,solve};
})();
