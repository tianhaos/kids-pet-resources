(function () {
  'use strict';
  const blue='#78d9ff', violet='#c9a7ff', gold='#ffc94a', coral='#f29e88', green='#8dd4ad';
  function render(canvas,s,hover) {
    const w=canvas.clientWidth,h=canvas.clientHeight,dpr=Math.min(devicePixelRatio||1,2);
    if(canvas.width!==Math.round(w*dpr)||canvas.height!==Math.round(h*dpr)){canvas.width=Math.round(w*dpr);canvas.height=Math.round(h*dpr);}
    const ctx=canvas.getContext('2d');ctx.setTransform(dpr,0,0,dpr,0,0);
    ctx.clearRect(0,0,w,h);ctx.fillStyle='#05070d';ctx.fillRect(0,0,w,h);
    if(w<100||h<145)return null;
    const mobile=w<600;
    const top=69, floor=h-Math.max(111, h*.245)-27;
    const chart={x:43,y:floor+58,w:w-60,h:h-floor-82};
    // 杆的比例不随角度或载荷改变，给最大倾角和力箭头预留空间。
    const scale=Math.max(8,Math.min((w-60)/2.28,(floor-top-20)/2.75,260));
    const O={x:(w-2*scale)/2+2*s.pivot*scale,y:top+14+2.12*scale};
    const forceColor=s.scene==='vertical'?blue:violet;
    const q=DynamicLever.solve(s);
    const P=r=>({x:O.x+r*q.c*scale,y:O.y-r*q.sn*scale});
    const B=P(q.effortR), C=P(q.centerR), D=P(q.loadR);
    function line(a,b,color,width=1,dash=[]){ctx.beginPath();ctx.setLineDash(dash);ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);ctx.strokeStyle=color;ctx.lineWidth=width;ctx.stroke();ctx.setLineDash([]);}
    function txt(t,x,y,c='#95a8c1',size=12,align='left'){ctx.font=`${size}px -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif`;const tw=ctx.measureText(t).width;const lo=align==='right'?tw+10:align==='center'?tw/2+10:10,hi=align==='left'?w-tw-10:align==='center'?w-tw/2-10:w-10;x=Math.max(lo,Math.min(hi,x));ctx.fillStyle=c;ctx.textAlign=align;ctx.fillText(t,x,y);}
    function circle(p,r,color,fill){ctx.beginPath();ctx.arc(p.x,p.y,r,0,Math.PI*2);ctx.strokeStyle=color;ctx.lineWidth=1.5;if(fill){ctx.fillStyle=fill;ctx.fill();}ctx.stroke();}
    function arrow(origin,dx,dy,color){
      const length=Math.hypot(dx,dy);
      if(length<.5)return;
      const tip={x:origin.x+dx,y:origin.y+dy};
      const angle=Math.atan2(dy,dx), head=Math.min(8,length*.52);
      line(origin,tip,color,2);
      for(const offset of [-.48,.48]){
        line(tip,{x:tip.x-head*Math.cos(angle+offset),y:tip.y-head*Math.sin(angle+offset)},color,2);
      }
    }
    // 工作台和竖直悬挂物提供固定参照，力图层限制在装置内。
    ctx.save();ctx.beginPath();ctx.rect(0,top-7,w, floor-top+29);ctx.clip();
    const glow=ctx.createRadialGradient(w*.5,O.y,0,w*.5,O.y,w*.45);
    glow.addColorStop(0,'#142035');glow.addColorStop(1,'#05070d');
    ctx.fillStyle=glow;ctx.fillRect(0,top-7,w,floor-top+29);
    for(let y=floor-23;y>top;y-=23)
      for(let x=14;x<w;x+=23){ctx.fillStyle='#26354a';ctx.fillRect(x,y,1,1);}
    const footY=Math.min(floor,O.y+Math.max(40,scale*.62));
    const bg=ctx.createLinearGradient(0,floor-10,0,floor+36);bg.addColorStop(0,'#1b2634');bg.addColorStop(1,'#090e17');
    ctx.fillStyle=bg;ctx.fillRect(0,floor,w,32);line({x:0,y:floor},{x:w,y:floor},'#34445a');
    ctx.fillStyle='#253247';ctx.fillRect(O.x-8,O.y+12,16,Math.max(0,footY-O.y-12));
    if(footY<floor)ctx.fillRect(O.x-5,footY,10,floor-footY);
    ctx.fillStyle='#35475d';ctx.beginPath();ctx.moveTo(O.x-23,O.y+27);ctx.lineTo(O.x,O.y-3);ctx.lineTo(O.x+23,O.y+27);ctx.closePath();ctx.fill();
    ctx.fillRect(O.x-37,floor-8,74,8);
    line({x:O.x-37,y:floor-8},{x:O.x+37,y:floor-8},'#70869a');
    if(s.angle>=5){
      const radius=Math.min(32,scale*.35);
      line(O,{x:O.x+radius+8,y:O.y},'#687b93',1,[3,3]);
      ctx.beginPath();ctx.arc(O.x,O.y,radius,-q.rad,0);ctx.strokeStyle='#8da1bb';ctx.lineWidth=1;ctx.stroke();
    }
    ctx.save();ctx.translate(O.x,O.y);ctx.rotate(-q.rad);
    const metal=ctx.createLinearGradient(0,-8,0,8);metal.addColorStop(0,'#c9b78e');metal.addColorStop(.4,'#ad8b4b');metal.addColorStop(1,'#6d4d26');ctx.fillStyle=metal;
    ctx.fillRect(-2*s.pivot*scale,-7,2*scale,14);ctx.strokeStyle='#dbc99b';ctx.strokeRect(-2*s.pivot*scale,-7,2*scale,14);
    for(let t=0;t<=2.001;t+=.1){const x=(t-2*s.pivot)*scale;line({x,y:-6},{x,y:t%.5<.05?2:-2},'#352b1d');}
    ctx.restore();circle(O,6,'#bdd1df','#182738');txt('O',O.x-17,O.y+7,'#edf2f6',13);
    const cord=Math.min(25,scale*.13), weightTop=D.y+cord;
    line(D,{x:D.x,y:weightTop},'#b9bec0',2);
    const weightW=Math.min(mobile?34:46,scale*.39),weightH=Math.min(25+s.load*2,scale*.38);
    const wg=ctx.createLinearGradient(D.x-weightW/2,0,D.x+weightW/2,0);wg.addColorStop(0,'#664730');wg.addColorStop(.4,'#c38d52');wg.addColorStop(1,'#785334');
    ctx.fillStyle=wg;ctx.fillRect(D.x-weightW/2,weightTop,weightW,weightH);ctx.strokeStyle='#d1a377';ctx.strokeRect(D.x-weightW/2,weightTop,weightW,weightH);
    if(weightW>=30)txt(s.load.toFixed(1),D.x,weightTop+weightH/2+4,'#16100a',11,'center');
    circle(C,4,gold,'#b79135');
    // 同屏箭头共用随画布尺寸确定的标度。
    const fs=scale*.008;
    if(s.arms){
      // 阻力的竖直作用线，以及到支点的水平垂线。
      line({x:D.x,y:Math.min(D.y-18,O.y-26)},{x:D.x,y:floor},coral,1,[4,5]);
      line(O,{x:D.x,y:O.y},coral,1.5);
      line({x:D.x-7,y:O.y},{x:D.x-7,y:O.y-7},coral);line({x:D.x-7,y:O.y-7},{x:D.x,y:O.y-7},coral);
      if(D.x-O.x>32)txt('l₂',D.x-11,O.y+17,coral,12,'right');
      const u={x:q.fx/(q.force||1),y:-q.fy/(q.force||1)};
      const dot=(O.x-B.x)*u.x+(O.y-B.y)*u.y;
      const foot={x:B.x+dot*u.x,y:B.y+dot*u.y};
      const start=Math.min(0,dot)-17, end=Math.max(0,dot)+q.force*fs+18;
      line({x:B.x+u.x*start,y:B.y+u.y*start},{x:B.x+u.x*end,y:B.y+u.y*end},forceColor,1,[4,5]);
      line(O,foot,forceColor,1.5);
      const v={x:(O.x-foot.x)/(q.arm*scale),y:(O.y-foot.y)/(q.arm*scale)};
      const a={x:foot.x+u.x*7,y:foot.y+u.y*7},b={x:a.x+v.x*7,y:a.y+v.y*7};
      line(a,b,forceColor);line(b,{x:foot.x+v.x*7,y:foot.y+v.y*7},forceColor);
      if(q.arm*scale>30)txt('l₁',(O.x+foot.x)/2,(O.y+foot.y)/2-11,forceColor,12,'center');
    }
    if(s.mass)arrow(C,0,s.mass*10*fs,gold);
    arrow(D,0,s.load*10*fs,coral);
    if(s.reaction && Math.hypot(q.rx,q.ry)>.01)arrow(O,q.rx*fs,-q.ry*fs,green);
    circle(B,hover==='tip'?12:8,forceColor,hover==='tip'?'#354954':'#152433');
    circle(B,2,forceColor,forceColor);
    arrow(B,q.fx*fs,-q.fy*fs,forceColor);
    ctx.restore();
    txt('拉力（N）随角度变化',11,chart.y-17,'#d3dfed',12);
    // 同条件两条理论曲线；图内点选可改变角度。
    const maxF=Math.ceil(q.vertical*1.1/5)*5;
    const xy=(a,f)=>({x:chart.x+a/80*chart.w,y:chart.y+chart.h-f/maxF*chart.h});
    for(let i=0;i<=2;i++){let f=maxF*i/2;const y=xy(0,f).y;line({x:chart.x,y},{x:chart.x+chart.w,y},'#1c293b');txt(String(f),chart.x-8,y+4,'#95a8c1',10,'right');}
    for(let a=0;a<=80;a+=20){const p=xy(a,0);txt(a+'°',p.x,p.y+18,'#95a8c1',10,'center');}
    for(const scene of ['vertical','normal']){const col=scene==='vertical'?blue:violet;let prev;for(let a=0;a<=80;a++){const r=DynamicLever.solve(s,a),p=xy(a,r[scene]);if(prev)line(prev,p,col,scene===s.scene?2.5:1.5);prev=p;}const p=xy(s.angle,q[scene]);circle(p,4,col,col);}
    line(xy(s.angle,0),xy(s.angle,maxF),hover==='chart'?'#d4e5f5':'#8a9cb3',1,[3,4]);
    return {O,B,chart,scale};
  }
  window.DynamicDraw={render};
})();
