(function () {
  'use strict';
  const $=id=>document.getElementById(id),params=new URLSearchParams(location.search);
  function number(key,def,min,max){const n=params.has(key)?Number(params.get(key)):def;return Number.isFinite(n)?Math.max(min,Math.min(max,n)):def;}
  const state={scene:params.get('scene')==='normal'?'normal':'vertical',angle:number('angle',30,0,80),mass:number('mass',2,0,5),load:number('load',3,.5,6),pivot:number('pivot',.2,.1,.4),arms:params.get('arms')!=='0',reaction:false,playing:false};
  const canvas=$('canvas');let geometry,hover='',drag='',last=0,direction=1;
  const records=[];
  let lastMass=state.mass||2;
  const compact=matchMedia('(max-width: 760px)');
  function setPanel(open){
    const visible=!compact.matches||open;
    $('panel').classList.toggle('collapsed',!visible);
    $('panel').inert=!visible;
    $('panelToggle').setAttribute('aria-expanded',String(visible));
    $('panelToggle').textContent=visible?'收起设置':'实验设置';
  }
  compact.addEventListener('change',()=>setPanel(false));
  setPanel(false);
  function track(action,label){if(window.Analytics)Analytics.track('杠杆的动态问题',action,label||state.scene);}
  function sync(){
    for(const key of ['angle','mass','load','pivot']){$(key).value=state[key];$(key+'Value').textContent=key==='angle'?state.angle.toFixed(0)+'°':key==='pivot'?(state.pivot*2).toFixed(2)+' m':state[key].toFixed(1)+' kg';}
    document.querySelectorAll('[data-scene]').forEach(b=>{const active=b.dataset.scene===state.scene;b.classList.toggle('on',active);b.setAttribute('aria-pressed',String(active));});
    $('arms').checked=state.arms;$('reaction').checked=state.reaction;
    $('play').textContent=state.playing?'暂停':'播放';
    $('liveAngle').textContent=state.angle.toFixed(0)+'°';
    const q=DynamicLever.solve(state);
    $('stage').dataset.scene=state.scene;
    $('verticalForce').textContent=q.vertical.toFixed(2)+' N';
    $('normalForce').textContent=q.normal.toFixed(2)+' N';
    $('massless').textContent=state.mass===0?'恢复杆重':'忽略杆重';
    if(state.mass>0)lastMass=state.mass;
    $('arm').textContent=q.arm.toFixed(3)+' m';
    $('loadArm').textContent=q.loadArm.toFixed(3)+' m';
    $('torque').textContent=q.torque.toFixed(2)+' N·m';
    $('explain').textContent=state.scene==='vertical'?'竖直拉力与两重力的力臂都乘 cosθ，比例不变，拉力不变。':'动力臂始终为支点到杆端的距离；重力力臂随抬高缩短，拉力减小。';
    $('equation').textContent=`${q.force.toFixed(2)} × ${q.arm.toFixed(3)} ≈ ${q.torque.toFixed(2)} N·m`;
  }
  function update(patch){Object.assign(state,patch);sync();}
  function setScene(scene){update({scene:scene==='normal'?'normal':'vertical',playing:false});track('切换拉力方向');}
  document.querySelectorAll('[data-scene]').forEach(b=>b.onclick=()=>setScene(b.dataset.scene));
  for(const key of ['angle','mass','load','pivot']){$(key).oninput=()=>update({[key]:Number($(key).value),playing:false});$(key).onchange=()=>track('调整'+key,String(state[key]));}
  for(const key of ['arms','reaction'])$(key).onchange=()=>update({[key]:$(key).checked});
  $('play').onclick=()=>{if(state.angle>=80)direction=-1;else if(state.angle<=0)direction=1;update({playing:!state.playing});track('播放');};
  $('reset').onclick=()=>{direction=1;update({angle:0,playing:false});track('放回水平');};
  $('massless').onclick=()=>{update({mass:state.mass===0?lastMass:0,playing:false});track('对比杆重');};
  $('record').onclick=()=>{const q=DynamicLever.solve(state);records.unshift({scene:state.scene,angle:state.angle,force:q.force,mass:state.mass,load:state.load,pivot:state.pivot});records.length=Math.min(6,records.length);$('records').innerHTML='<tr><th>拉力 / 角度</th><th>条件 m杆/m物/O</th><th>F/N</th></tr>'+records.map(r=>`<tr><td>${r.scene==='vertical'?'竖直':'垂杆'} ${r.angle.toFixed(0)}°</td><td>${r.mass.toFixed(1)}/${r.load.toFixed(1)}/${(r.pivot*2).toFixed(2)}</td><td>${r.force.toFixed(2)}</td></tr>`).join('');track('记录');};
  function shareURL(){const p=new URLSearchParams();for(const k of ['scene','angle','mass','load','pivot'])p.set(k,state[k]);if(!state.arms)p.set('arms','0');return location.origin+location.pathname+'?'+p;}
  $('share').onclick=async()=>{const url=shareURL();try{await navigator.clipboard.writeText(url);$('status').textContent='已复制当前条件链接';}catch{ $('status').textContent=url;}track('分享');};
  $('panelToggle').onclick=()=>setPanel($('panel').classList.contains('collapsed'));
  function point(e){const r=canvas.getBoundingClientRect();return{x:e.clientX-r.left,y:e.clientY-r.top};}
  function hit(p){if(!geometry)return '';const g=geometry;if(Math.hypot(p.x-g.B.x,p.y-g.B.y)<30)return 'tip';if(p.x>=g.chart.x-12&&p.x<=g.chart.x+g.chart.w+12&&p.y>=g.chart.y-15&&p.y<=g.chart.y+g.chart.h+25)return 'chart';return '';}
  function move(p){if(drag==='tip'){const g=geometry;update({angle:Math.max(0,Math.min(80,Math.atan2(g.O.y-p.y,p.x-g.O.x)*180/Math.PI)),playing:false});}else if(drag==='chart'){update({angle:Math.max(0,Math.min(80,(p.x-geometry.chart.x)/geometry.chart.w*80)),playing:false});}}
  canvas.onpointerdown=e=>{const p=point(e);drag=hit(p);if(drag){canvas.setPointerCapture(e.pointerId);move(p);e.preventDefault();}};
  canvas.onpointermove=e=>{const p=point(e);if(drag)move(p);hover=hit(p);canvas.style.cursor=drag?'grabbing':hover?'grab':'default';};
  canvas.onpointerleave=()=>{if(!drag)hover='';};
  function end(){if(drag)track('画面拖动',drag);drag='';}
  canvas.onpointerup=end;canvas.onpointercancel=end;canvas.onlostpointercapture=end;
  document.addEventListener('keydown',e=>{
    if(e.defaultPrevented||e.altKey||e.ctrlKey||e.metaKey||document.activeElement.closest('input,button,a,summary,select,textarea,[contenteditable]'))return;
    if(e.code==='Space'){e.preventDefault();$('play').click();}
    if(e.code==='ArrowRight'||e.code==='ArrowLeft'){
      e.preventDefault();
      const delta=e.code==='ArrowRight'?1:-1;
      update({angle:Math.max(0,Math.min(80,state.angle+delta)),playing:false});
    }
  });
  function frame(now){const dt=Math.min(.05,(now-last)/1000||0);last=now;if(state.playing){let a=state.angle+direction*dt*8;if(a>=80){a=80;direction=-1;}if(a<=0){a=0;direction=1;state.playing=false;}state.angle=a;sync();}geometry=DynamicDraw.render(canvas,state,hover);requestAnimationFrame(frame);}
  window.__model={state,update,setScene,solve:()=>DynamicLever.solve(state),shareURL,get geometry(){return geometry;},records};
  sync();requestAnimationFrame(frame);
})();
