(function () {
  var A = window.Astro, DEG = A.DEG;
  var V3 = THREE.Vector3;
  var ORBIT_R = 40;
  var Y = new V3(0, 1, 0), Z = new V3(0, 0, 1);

  var CITIES = [
    { key: 'none', name: '（不显示）' },
    { key: 'beijing', name: '北京', lat: 39.9, lon: 116.4 },
    { key: 'harbin', name: '哈尔滨', lat: 45.8, lon: 126.6 },
    { key: 'mohe', name: '漠河', lat: 53.0, lon: 122.5 },
    { key: 'shanghai', name: '上海', lat: 31.2, lon: 121.5 },
    { key: 'guangzhou', name: '广州', lat: 23.1, lon: 113.3 },
    { key: 'sanya', name: '三亚', lat: 18.3, lon: 109.5 },
    { key: 'singapore', name: '新加坡', lat: 1.3, lon: 103.8 },
    { key: 'sydney', name: '悉尼', lat: -33.9, lon: 151.2 },
    { key: 'murmansk', name: '摩尔曼斯克', lat: 69.0, lon: 33.1 }
  ];

  var now = new Date();
  var state = {
    day: A.dateToDay(now.getMonth() + 1, now.getDate()),
    spin: 0,
    tilt: 23.44,
    sunR: 6,
    earthR: 2.4,
    revolve: true, revolveSpeed: 8,   // 天/秒
    rotate: true, rotateSpeed: 0.4,   // 圈/秒
    showLat: true, showTerm: true, showRays: true, showLabels: true, showInset: true,
    follow: false,
    insetMode: 'side',
    city: 'beijing'
  };

  var $ = function (id) { return document.getElementById(id); };
  var stage = $('stage'), insetEl = $('inset'), panel = $('panel');

  // ---------- 渲染器 ----------
  var renderer = new THREE.WebGLRenderer({ antialias: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  stage.insertBefore(renderer.domElement, stage.firstChild);
  var canvas = renderer.domElement;

  var labelRenderer = new THREE.CSS2DRenderer();
  var ls = labelRenderer.domElement.style;
  ls.position = 'absolute'; ls.top = '0'; ls.left = '0'; ls.pointerEvents = 'none'; ls.zIndex = '2';
  stage.appendChild(labelRenderer.domElement);

  var scene = new THREE.Scene();
  scene.background = new THREE.Color('#05070d');

  var camera = new THREE.PerspectiveCamera(45, 1, 0.1, 4000);
  var HOME_POS = new V3(0, 46, 82), HOME_TARGET = new V3(0, 0, 0);
  camera.position.copy(HOME_POS);
  var insetCam = new THREE.PerspectiveCamera(35, 1, 0.05, 4000);

  // ---------- 拖动地球（须在 OrbitControls 之前注册，才能拦截它的 pointerdown） ----------
  var raycaster = new THREE.Raycaster();
  var ndc = new THREE.Vector2();
  var orbitPlane = new THREE.Plane(Y, 0);
  var dragging = false;
  var earthMesh; // 下面创建

  function setNdc(e) {
    var r = canvas.getBoundingClientRect();
    ndc.set((e.clientX - r.left) / r.width * 2 - 1, -(e.clientY - r.top) / r.height * 2 + 1);
    raycaster.setFromCamera(ndc, camera);
  }
  function hitEarth() { return raycaster.intersectObject(earthMesh, false).length > 0; }

  canvas.addEventListener('pointerdown', function (e) {
    if (e.button !== 0) return;
    setNdc(e);
    if (hitEarth()) {
      dragging = true;
      e.stopImmediatePropagation();
      canvas.setPointerCapture(e.pointerId);
      canvas.style.cursor = 'grabbing';
    }
  });
  canvas.addEventListener('pointermove', function (e) {
    setNdc(e);
    if (dragging) {
      var p = raycaster.ray.intersectPlane(orbitPlane, new V3());
      if (p) state.day = A.phiToDay(Math.atan2(-p.z, p.x) / DEG);
    } else if (e.buttons === 0) {
      canvas.style.cursor = hitEarth() ? 'grab' : '';
    }
  });
  function endDrag(e) {
    if (!dragging) return;
    dragging = false;
    if (canvas.hasPointerCapture(e.pointerId)) canvas.releasePointerCapture(e.pointerId);
    canvas.style.cursor = 'grab';
  }
  canvas.addEventListener('pointerup', endDrag);
  canvas.addEventListener('pointercancel', endDrag);

  var controls = new THREE.OrbitControls(camera, canvas);
  controls.enableDamping = true;
  controls.dampingFactor = 0.08;
  controls.minDistance = 4;
  controls.maxDistance = 400;

  // 只在主视角显示的物体（轨道装饰等）放在第 1 层，避免挡住特写小窗
  var MAIN_ONLY = 1;
  camera.layers.enable(MAIN_ONLY);
  function mainOnly(o) { o.layers.set(MAIN_ONLY); return o; }

  // ---------- 标签 ----------
  var allLabels = [];
  function makeLabel(html, cls, parent, onClick) {
    var el = document.createElement('div');
    el.className = 'lbl ' + (cls || '');
    el.innerHTML = html;
    if (onClick) el.addEventListener('click', onClick);
    var obj = new THREE.CSS2DObject(el);
    obj.userData.want = true; // 业务上是否应显示（再叠加“文字标签”总开关）
    parent.add(obj);
    allLabels.push(obj);
    return obj;
  }

  // ---------- 星空 ----------
  (function () {
    var n = 2500, pos = new Float32Array(n * 3);
    for (var i = 0; i < n; i++) {
      var v = new V3().randomDirection().multiplyScalar(900 + Math.random() * 600);
      pos[i * 3] = v.x; pos[i * 3 + 1] = v.y; pos[i * 3 + 2] = v.z;
    }
    var g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    scene.add(new THREE.Points(g, new THREE.PointsMaterial({
      color: 0xffffff, size: 1.4, sizeAttenuation: false, transparent: true, opacity: 0.75
    })));
  })();

  // ---------- 太阳 ----------
  var sun = new THREE.Mesh(new THREE.SphereGeometry(1, 48, 32), new THREE.MeshBasicMaterial({ color: 0xffd54f }));
  scene.add(sun);
  var glow = new THREE.Sprite(new THREE.SpriteMaterial({
    map: (function () {
      var c = document.createElement('canvas'); c.width = c.height = 256;
      var x = c.getContext('2d');
      var g = x.createRadialGradient(128, 128, 0, 128, 128, 128);
      g.addColorStop(0, 'rgba(255,220,120,1)');
      g.addColorStop(0.25, 'rgba(255,190,60,0.55)');
      g.addColorStop(0.6, 'rgba(255,140,30,0.12)');
      g.addColorStop(1, 'rgba(255,120,0,0)');
      x.fillStyle = g; x.fillRect(0, 0, 256, 256);
      return new THREE.CanvasTexture(c);
    })(),
    blending: THREE.AdditiveBlending, depthWrite: false, transparent: true
  }));
  scene.add(glow);
  var sunLabel = makeLabel('太阳', 'lbl-sun', scene);

  // ---------- 轨道 ----------
  function orbitPos(phiDeg, r) {
    var p = phiDeg * DEG;
    return new V3((r || ORBIT_R) * Math.cos(p), 0, -(r || ORBIT_R) * Math.sin(p));
  }
  (function () {
    var pts = [];
    for (var i = 0; i < 256; i++) pts.push(orbitPos(i / 256 * 360));
    scene.add(mainOnly(new THREE.LineLoop(new THREE.BufferGeometry().setFromPoints(pts),
      new THREE.LineBasicMaterial({ color: 0x5b6b85 }))));
    // 公转方向箭头
    [45, 135, 225, 315].forEach(function (phi) {
      var cone = new THREE.Mesh(new THREE.ConeGeometry(0.5, 1.6, 12), new THREE.MeshBasicMaterial({ color: 0x7d8da8 }));
      cone.position.copy(orbitPos(phi));
      var p = phi * DEG;
      cone.quaternion.setFromUnitVectors(Y, new V3(-Math.sin(p), 0, -Math.cos(p)));
      scene.add(mainOnly(cone));
    });
  })();

  // 四个节气标记 + 平行的“地轴方向”虚线（说明地轴指向不变）
  var ghostAxes = [], termMarkers = [];
  A.TERMS.forEach(function (t) {
    var p = orbitPos(t.phi);
    var m = new THREE.Mesh(new THREE.SphereGeometry(0.45, 16, 12), new THREE.MeshBasicMaterial({ color: 0xffc94a }));
    m.position.copy(p);
    scene.add(mainOnly(m));
    var line = new THREE.Line(new THREE.BufferGeometry().setFromPoints([new V3(), new V3()]),
      new THREE.LineDashedMaterial({ color: 0x9fb3c8, dashSize: 0.5, gapSize: 0.35, transparent: true, opacity: 0.7 }));
    line.userData.center = p;
    scene.add(mainOnly(line));
    ghostAxes.push(line);
    m.userData.termLabel = true;
    termMarkers.push(m);
    var lbl = makeLabel('<b>' + t.name + '</b><small>' + t.date + '</small>', 'lbl-term', m, function () { jumpTo(t); });
    lbl.position.set(0, -1.2, 0);
  });

  // ---------- 地球 ----------
  var earthRoot = new THREE.Group();    // 位置 + 大小；不旋转
  var tiltGroup = new THREE.Group();    // 地轴倾斜；不自转
  var spinGroup = new THREE.Group();    // 自转
  scene.add(earthRoot);
  earthRoot.add(tiltGroup);
  tiltGroup.add(spinGroup);

  var tex = new THREE.CanvasTexture(window.makeEarthCanvas());
  tex.anisotropy = renderer.capabilities.getMaxAnisotropy();
  var earthUniforms = { map: { value: tex }, sunDir: { value: new V3(1, 0, 0) } };
  earthMesh = new THREE.Mesh(new THREE.SphereGeometry(1, 128, 64), new THREE.ShaderMaterial({
    uniforms: earthUniforms,
    vertexShader: [
      'varying vec2 vUv; varying vec3 vN;',
      'void main(){ vUv = uv; vN = normalize(mat3(modelMatrix) * normal);',
      '  gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }'
    ].join('\n'),
    fragmentShader: [
      'uniform sampler2D map; uniform vec3 sunDir; varying vec2 vUv; varying vec3 vN;',
      'void main(){',
      '  vec3 c = texture2D(map, vUv).rgb;',
      '  float d = dot(normalize(vN), sunDir);',
      '  float day = smoothstep(-0.025, 0.025, d);',
      '  vec3 dayC = c * (0.78 + 0.32 * max(d, 0.0));',
      '  vec3 nightC = c * 0.14 + vec3(0.0, 0.01, 0.04);',
      '  gl_FragColor = vec4(mix(nightC, dayC, day), 1.0);',
      '}'
    ].join('\n')
  }));
  spinGroup.add(earthMesh);

  // 地轴
  var axisMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.014, 0.014, 3, 8), new THREE.MeshBasicMaterial({ color: 0xffffff }));
  tiltGroup.add(axisMesh);
  var northTip = new THREE.Mesh(new THREE.ConeGeometry(0.05, 0.14, 12), new THREE.MeshBasicMaterial({ color: 0xffffff }));
  northTip.position.y = 1.55;
  tiltGroup.add(northTip);
  var nLabel = makeLabel('N 北极', 'lbl-pole', tiltGroup); nLabel.position.set(0, 1.75, 0);
  var sLabel = makeLabel('S 南极', 'lbl-pole', tiltGroup); sLabel.position.set(0, -1.7, 0);

  // 重要纬线：挂在 tiltGroup（纬线绕地轴对称，不需要随自转转）
  var latGroup = new THREE.Group();
  tiltGroup.add(latGroup);
  var LAT_R = 1.006;
  var latLines = [
    { id: 'n-polar', color: 0x4fc3f7, name: '北极圈', lat: function () { return 90 - state.tilt; } },
    { id: 'n-trop', color: 0xffa726, name: '北回归线', lat: function () { return state.tilt; } },
    { id: 'eq', color: 0xff5252, name: '赤道', lat: function () { return 0; } },
    { id: 's-trop', color: 0xffa726, name: '南回归线', lat: function () { return -state.tilt; } },
    { id: 's-polar', color: 0x4fc3f7, name: '南极圈', lat: function () { return -(90 - state.tilt); } }
  ];
  latLines.forEach(function (L) {
    L.mesh = new THREE.Mesh(new THREE.BufferGeometry(), new THREE.MeshBasicMaterial({ color: L.color }));
    latGroup.add(L.mesh);
    L.label = makeLabel('', 'lbl-lat', tiltGroup);
    L.label.element.style.color = '#' + L.color.toString(16).padStart(6, '0');
  });
  function rebuildLatLines() {
    latLines.forEach(function (L) {
      var lat = L.lat();
      var r = Math.cos(lat * DEG) * LAT_R;
      L.mesh.geometry.dispose();
      L.mesh.geometry = new THREE.TorusGeometry(Math.max(r, 0.001), L.id === 'eq' ? 0.014 : 0.011, 6, 180);
      L.mesh.rotation.x = Math.PI / 2;
      L.mesh.position.y = Math.sin(lat * DEG) * LAT_R;
      // 倾角为 0 时回归线与赤道重合、极圈缩到极点，隐藏它们
      L.degenerate = L.id !== 'eq' && state.tilt < 0.5;
      L.mesh.visible = !L.degenerate;
      L.label.element.textContent = L.name + ' ' + A.formatDMS(lat);
    });
    ghostAxes.forEach(function (line) {
      var a = axisDir().multiplyScalar(4);
      var c = line.userData.center;
      line.geometry.setFromPoints([c.clone().sub(a), c.clone().add(a)]);
      line.computeLineDistances();
    });
  }

  // 晨昏线（以地心为圆心、垂直于太阳光的大圆）
  var terminator = new THREE.Mesh(new THREE.TorusGeometry(1.009, 0.013, 6, 200), new THREE.MeshBasicMaterial({ color: 0xffe066 }));
  earthRoot.add(terminator);

  // 直射点
  var subsolar = new THREE.Mesh(new THREE.SphereGeometry(0.05, 16, 12), new THREE.MeshBasicMaterial({ color: 0xfff59d }));
  earthRoot.add(subsolar);
  var subLabel = makeLabel('', 'lbl-sub', subsolar);

  // 平行太阳光（中间一条正好射到直射点）
  var RAY_K = [-0.8, -0.55, -0.3, 0, 0.3, 0.55, 0.8];
  var RAY_START = 4.2;
  var rays = RAY_K.map(function (k) {
    var main = k === 0;
    var a = new THREE.ArrowHelper(new V3(-1, 0, 0), new V3(), 1, main ? 0xfff176 : 0xffb74d, 0.2, 0.1);
    earthRoot.add(a);
    return a;
  });
  var sunLine = new THREE.Line(new THREE.BufferGeometry().setFromPoints([new V3(), new V3()]),
    new THREE.LineBasicMaterial({ color: 0xffcc66, transparent: true, opacity: 0.35 }));
  scene.add(mainOnly(sunLine));

  // 城市
  var cityMarker = new THREE.Mesh(new THREE.SphereGeometry(0.04, 12, 8), new THREE.MeshBasicMaterial({ color: 0xff5252 }));
  spinGroup.add(cityMarker);
  var cityLabel = makeLabel('', 'lbl-city', cityMarker);

  function latLonToLocal(lat, lon, r) {
    var p = lat * DEG, l = lon * DEG;
    return new V3(Math.cos(p) * Math.cos(l), Math.sin(p), -Math.cos(p) * Math.sin(l)).multiplyScalar(r);
  }
  function currentCity() {
    return CITIES.filter(function (c) { return c.key === state.city; })[0];
  }

  // ---------- 几何计算 ----------
  var earthPos = new V3(), sunDir = new V3(1, 0, 0);
  function axisDir() {
    return new V3(Math.sin(state.tilt * DEG), Math.cos(state.tilt * DEG), 0);
  }
  function declAt(day) {
    var phi = A.dayToPhi(day) * DEG;
    var s = new V3(-Math.cos(phi), 0, Math.sin(phi));
    return Math.asin(axisDir().dot(s)) / DEG;
  }
  // 太阳在“地轴坐标系”里的经度方向（弧度）；城市地方时 = 12 + (城市经度 + 自转角 − 它) / 15°
  function sunLongitudeInTiltFrame() {
    var q = tiltGroup.quaternion.clone().invert();
    var s = sunDir.clone().applyQuaternion(q);
    return Math.atan2(-s.z, s.x);
  }
  function wrapPi(a) {
    a = (a + Math.PI) % (2 * Math.PI);
    if (a < 0) a += 2 * Math.PI;
    return a - Math.PI;
  }

  var decl = 0;
  function updateScene() {
    earthPos.copy(orbitPos(A.dayToPhi(state.day)));
    earthRoot.position.copy(earthPos);
    earthRoot.scale.setScalar(state.earthR);
    tiltGroup.rotation.set(0, 0, -state.tilt * DEG);
    spinGroup.rotation.y = state.spin;

    sunDir.copy(earthPos).negate().normalize();
    decl = Math.asin(axisDir().dot(sunDir)) / DEG;
    earthUniforms.sunDir.value.copy(sunDir);

    sun.scale.setScalar(state.sunR);
    glow.scale.setScalar(state.sunR * 4.2);
    sunLabel.position.set(0, state.sunR + 1.5, 0);

    terminator.quaternion.setFromUnitVectors(Z, sunDir);
    terminator.visible = state.showTerm;
    subsolar.position.copy(sunDir).multiplyScalar(1.01);
    latGroup.visible = state.showLat;

    // 光线：垂直于光线方向的偏移取“世界竖直方向”，侧视图中可看到光线射向不同纬度
    var up = Y.clone().sub(sunDir.clone().multiplyScalar(Y.dot(sunDir))).normalize();
    var back = sunDir.clone().negate();
    rays.forEach(function (a, i) {
      var k = RAY_K[i];
      var start = up.clone().multiplyScalar(k).add(sunDir.clone().multiplyScalar(RAY_START));
      a.position.copy(start);
      a.setDirection(back);
      a.setLength(RAY_START - Math.sqrt(1 - k * k), 0.2, 0.1);
      a.visible = state.showRays;
    });
    var sp = sunLine.geometry.attributes.position;
    var from = earthPos.clone().normalize().multiplyScalar(state.sunR); // 太阳表面朝向地球的一点
    var to = earthPos.clone().add(sunDir.clone().multiplyScalar(state.earthR * RAY_START));
    sp.setXYZ(0, from.x, from.y, from.z); sp.setXYZ(1, to.x, to.y, to.z); sp.needsUpdate = true;
    sunLine.visible = state.showRays;

    var city = currentCity();
    cityMarker.visible = city.key !== 'none';
    if (cityMarker.visible) cityMarker.position.copy(latLonToLocal(city.lat, city.lon, 1.0));
  }

  // ---------- 标签位置与可见性 ----------
  var tmp = new V3();
  function facingCamera(worldPos) {
    // 地表某点是否朝向相机（不被地球挡住）
    var n = worldPos.clone().sub(earthPos).normalize();
    var c = camera.position.clone().sub(worldPos).normalize();
    return n.dot(c) > 0.05;
  }
  function earthPixelRadius() {
    var d = camera.position.distanceTo(earthPos);
    return state.earthR / d * H / (2 * Math.tan(camera.fov / 2 * DEG));
  }
  function updateLabels() {
    var big = earthPixelRadius() > 90; // 地球在屏幕上太小时，纬线等文字会挤成一团，先隐藏
    // 纬线标签放在“相机看过去的右前方”，始终可见
    var camLocal = tiltGroup.worldToLocal(camera.position.clone());
    var h = new V3(camLocal.x, 0, camLocal.z);
    if (h.lengthSq() < 1e-6) h.set(0, 0, 1);
    h.normalize();
    var right = Y.clone().cross(h);
    var dir = h.clone().multiplyScalar(Math.cos(62 * DEG)).add(right.multiplyScalar(Math.sin(62 * DEG)));
    latLines.forEach(function (L) {
      var lat = L.lat() * DEG;
      L.label.position.set(dir.x * Math.cos(lat) * LAT_R, Math.sin(lat) * LAT_R, dir.z * Math.cos(lat) * LAT_R);
      L.label.userData.want = big && state.showLat && !L.degenerate;
    });

    subLabel.element.textContent = '直射点 ' + A.formatLat(decl);
    subLabel.userData.want = big && facingCamera(subsolar.getWorldPosition(tmp));

    var city = currentCity();
    if (city.key !== 'none') {
      cityLabel.element.textContent = city.name;
      cityLabel.userData.want = facingCamera(cityMarker.getWorldPosition(tmp));
    } else {
      cityLabel.userData.want = false;
    }

    // 地球停在节气点上且画面很近时，节气牌会挡住地球
    termMarkers.forEach(function (m) {
      m.children[0].userData.want = !(big && m.position.distanceTo(earthPos) < state.earthR * 2);
    });

    allLabels.forEach(function (o) { o.visible = state.showLabels && o.userData.want; });
  }

  // ---------- 读数 ----------
  var cache = {};
  function setText(id, txt) {
    if (cache[id] !== txt) { cache[id] = txt; $(id).textContent = txt; }
  }
  function seasonOf(month, north) {
    var s = month >= 3 && month <= 5 ? 0 : month >= 6 && month <= 8 ? 1 : month >= 9 && month <= 11 ? 2 : 3;
    if (!north) s = (s + 2) % 4;
    return ['春季', '夏季', '秋季', '冬季'][s];
  }
  function updateReadouts() {
    var d = A.dayToDate(state.day);
    setText('rDate', d.month + '月' + d.date + '日');
    var ti = A.termInfo(state.day);
    setText('rTerm', ti.exact ? '今天是' + ti.exact.name : ti.from ? ti.from.name + ' → ' + ti.to.name + '，距' + ti.to.name + ' ' + ti.left + ' 天' : '');

    var eps = 0.05;
    var note = '';
    if (Math.abs(decl) < 0.3) note = '（赤道附近）';
    else if (state.tilt >= 0.5 && Math.abs(Math.abs(decl) - state.tilt) < 0.3) note = decl > 0 ? '（北回归线）' : '（南回归线）';
    setText('rDecl', A.formatLatCN(decl) + note);
    var move = declAt(state.day + 1) - decl;
    var atSolstice = ti.exact && (ti.exact.key === 'summer' || ti.exact.key === 'winter');
    setText('rDeclMove', state.tilt < 0.5 ? '始终在赤道'
      : atSolstice ? (decl > 0 ? '到达最北，之后南移' : '到达最南，之后北移')
      : move > 0 ? '正在向北移动 ↑' : '正在向南移动 ↓');

    function hemi(north) {
      var s = north ? decl : -decl;
      var dn = s > eps ? '昼长夜短，纬度越高昼越长' : s < -eps ? '昼短夜长，纬度越高昼越短' : '昼夜等长';
      return seasonOf(d.month, north) + ' · ' + dn;
    }
    setText('rNorth', hemi(true));
    setText('rSouth', hemi(false));
    if (Math.abs(decl) < eps) {
      setText('rPolar', '无，全球昼夜平分');
    } else {
      var x = A.formatDMS(90 - Math.abs(decl)).replace(/[NS]$/, '');
      setText('rPolar', decl > 0
        ? '北纬 ' + x + ' 以北极昼；南纬 ' + x + ' 以南极夜'
        : '北纬 ' + x + ' 以北极夜；南纬 ' + x + ' 以南极昼');
    }

    var city = currentCity();
    if (city.key === 'none') {
      ['cDay', 'cRise', 'cNoon', 'cNow'].forEach(function (id) { setText(id, '—'); });
    } else {
      var L = A.dayLength(city.lat, decl);
      setText('cDay', L >= 24 ? '24 小时（极昼）' : L <= 0 ? '0（极夜）' : A.formatHours(L));
      setText('cRise', L >= 24 || L <= 0 ? '—' : A.formatClock(12 - L / 2) + ' / ' + A.formatClock(12 + L / 2) + '（地方时）');
      var h = A.noonAltitude(city.lat, decl);
      setText('cNoon', h.toFixed(1) + '°  = 90° − |' + city.lat.toFixed(1) + '° − (' + (Math.abs(decl) < 0.05 ? '0.0' : decl.toFixed(1)) + '°)|' + (h <= 0 ? '，太阳不升起' : ''));
      var local = 12 + wrapPi(city.lon * DEG + state.spin - sunLongitudeInTiltFrame()) / DEG / 15;
      var isDay = cityMarker.getWorldPosition(tmp).sub(earthPos).normalize().dot(sunDir) > 0;
      setText('cNow', '地方时 ' + A.formatClock(local) + ' · ' + (isDay ? '白天 ☀' : '黑夜 ☾'));
    }

    // 节气按钮高亮
    document.querySelectorAll('[data-term]').forEach(function (b) {
      var on = !!(ti.exact && ti.exact.key === b.dataset.term);
      if (b.classList.contains('on') !== on) b.classList.toggle('on', on);
    });
    if (!daySliderActive) {
      var dv = String(Math.floor(A.wrapDay(state.day)));
      if (daySlider.value !== dv) daySlider.value = dv;
    }
    setText('dayOut', d.month + '/' + d.date);
  }

  // ---------- 画中画相机 ----------
  var INSET_TITLES = { side: '侧视光照图（阳光从左侧射来）', polar: '北极上空俯视' };
  function updateInsetCam() {
    var dist = state.earthR * 5.4;
    if (state.insetMode === 'side') {
      var perp = Y.clone().cross(sunDir).normalize(); // 让太阳位于画面左侧
      insetCam.position.copy(earthPos).add(perp.multiplyScalar(dist));
      insetCam.up.copy(Y);
    } else {
      var a = axisDir();
      insetCam.position.copy(earthPos).add(a.clone().multiplyScalar(dist));
      insetCam.up.copy(sunDir.clone().cross(a).normalize());
    }
    insetCam.lookAt(earthPos);
  }

  // ---------- 交互：面板 ----------
  function jumpTo(term) {
    state.day = term.day;
    setRevolve(false);
  }
  function setRevolve(on) {
    state.revolve = on;
    $('revolveOn').checked = on;
  }

  document.querySelectorAll('[data-term]').forEach(function (b) {
    b.addEventListener('click', function () {
      jumpTo(A.TERMS.filter(function (t) { return t.key === b.dataset.term; })[0]);
      Analytics.track('地日', '跳转节气', b.dataset.term);
    });
  });

  var daySlider = $('daySlider');
  var daySliderActive = false;
  daySlider.addEventListener('pointerdown', function () { daySliderActive = true; });
  window.addEventListener('pointerup', function () { daySliderActive = false; });
  daySlider.addEventListener('input', function () { state.day = Number(daySlider.value); });

  function bindRange(id, outId, key, fmt, onChange) {
    var el = $(id);
    el.value = state[key];
    var render = function () { $(outId).textContent = fmt(state[key]); };
    el.addEventListener('input', function () {
      state[key] = Number(el.value);
      render();
      if (onChange) onChange();
    });
    render();
  }
  bindRange('revolveSpeed', 'revolveOut', 'revolveSpeed', function (v) { return v + ' 天/秒'; });
  bindRange('rotateSpeed', 'rotateOut', 'rotateSpeed', function (v) { return v.toFixed(2) + ' 圈/秒'; });
  bindRange('tilt', 'tiltOut', 'tilt', function (v) { return v.toFixed(1) + '°'; }, rebuildLatLines);
  bindRange('sunSize', 'sunOut', 'sunR', function (v) { return v.toFixed(1); });
  bindRange('earthSize', 'earthOut', 'earthR', function (v) { return v.toFixed(1); });

  $('tiltReset').addEventListener('click', function () {
    state.tilt = 23.44;
    $('tilt').value = 23.44;
    $('tiltOut').textContent = '23.4°';
    rebuildLatLines();
  });

  function bindCheck(id, key, onChange) {
    var el = $(id);
    el.checked = state[key];
    el.addEventListener('change', function () { state[key] = el.checked; if (onChange) onChange(); });
  }
  bindCheck('revolveOn', 'revolve');
  bindCheck('rotateOn', 'rotate');
  bindCheck('showLat', 'showLat');
  bindCheck('showTerm', 'showTerm');
  bindCheck('showRays', 'showRays');
  bindCheck('showLabels', 'showLabels');
  bindCheck('showInset', 'showInset', function () { insetEl.classList.toggle('hidden', !state.showInset); });
  bindCheck('follow', 'follow', function () {
    if (state.follow) {
      // 拉近到地球附近，保持当前观察方向
      var dir = camera.position.clone().sub(controls.target).normalize();
      controls.target.copy(earthPos);
      camera.position.copy(earthPos).add(dir.multiplyScalar(state.earthR * 9));
      lastEarthPos.copy(earthPos);
    } else {
      resetView();
    }
  });

  // 视角回正：平滑飞回“太阳在中央”的初始视角
  var viewAnim = null;
  function resetView() {
    if (state.follow) { state.follow = false; $('follow').checked = false; }
    viewAnim = {
      t: 0,
      fromPos: camera.position.clone(), fromTarget: controls.target.clone()
    };
  }
  function stepViewAnim(dt) {
    if (!viewAnim) return;
    viewAnim.t = Math.min(viewAnim.t + dt / 0.8, 1);
    var k = 1 - Math.pow(1 - viewAnim.t, 3); // easeOutCubic
    camera.position.lerpVectors(viewAnim.fromPos, HOME_POS, k);
    controls.target.lerpVectors(viewAnim.fromTarget, HOME_TARGET, k);
    if (viewAnim.t >= 1) viewAnim = null;
  }
  $('resetView').addEventListener('click', resetView);
  controls.addEventListener('start', function () { viewAnim = null; }); // 用户一拖就中止动画

  var citySel = $('city');
  CITIES.forEach(function (c) {
    var o = document.createElement('option');
    o.value = c.key;
    o.textContent = c.lat == null ? c.name : c.name + '（' + A.formatLat(c.lat) + '）';
    citySel.appendChild(o);
  });
  citySel.value = state.city;
  citySel.addEventListener('change', function () {
    state.city = citySel.value;
    Analytics.track('地日', '选择城市', citySel.value);
  });

  document.querySelectorAll('[data-inset]').forEach(function (b) {
    b.addEventListener('click', function () {
      state.insetMode = b.dataset.inset;
      document.querySelectorAll('[data-inset]').forEach(function (x) { x.classList.toggle('on', x === b); });
      $('insetTitle').textContent = INSET_TITLES[state.insetMode];
    });
  });
  $('insetTitle').textContent = INSET_TITLES[state.insetMode];

  $('panelToggle').addEventListener('click', function () { panel.classList.toggle('collapsed'); });
  if (window.matchMedia('(max-width: 760px)').matches) panel.classList.add('collapsed');

  window.addEventListener('keydown', function (e) {
    var t = e.target.tagName;
    if (t === 'INPUT' || t === 'SELECT' || t === 'BUTTON' || t === 'TEXTAREA') return;
    if (e.code === 'Space') {
      e.preventDefault();
      setRevolve(!state.revolve);
    } else if (e.code === 'KeyR' && !e.metaKey && !e.ctrlKey) {
      resetView();
    }
  });

  // ---------- 尺寸 ----------
  var W = 1, H = 1;
  function resize() {
    W = stage.clientWidth; H = stage.clientHeight;
    renderer.setSize(W, H);
    labelRenderer.setSize(W, H);
    camera.aspect = W / H;
    camera.updateProjectionMatrix();
  }
  new ResizeObserver(resize).observe(stage);
  resize();

  // ---------- 初始化 ----------
  rebuildLatLines();
  updateScene();
  // 初始让北京正对太阳（正午）
  state.spin = sunLongitudeInTiltFrame() - 116.4 * DEG;
  updateScene();

  // ---------- 主循环 ----------
  var last = performance.now();
  var lastEarthPos = earthPos.clone();
  var mainClear = new THREE.Color('#05070d'), insetClear = new THREE.Color('#0b1222');

  function frame(t) {
    var dt = Math.min((t - last) / 1000, 0.1);
    last = t;
    if (state.revolve && !dragging) state.day = A.wrapDay(state.day + state.revolveSpeed * dt);
    if (state.rotate) state.spin = (state.spin + state.rotateSpeed * 2 * Math.PI * dt) % (2 * Math.PI);

    updateScene();
    if (state.follow) {
      var delta = earthPos.clone().sub(lastEarthPos);
      camera.position.add(delta);
      controls.target.add(delta);
    }
    lastEarthPos.copy(earthPos);
    stepViewAnim(dt);
    controls.update();
    updateLabels();
    updateReadouts();

    renderer.setScissorTest(false);
    renderer.setViewport(0, 0, W, H);
    scene.background = mainClear;
    renderer.render(scene, camera);
    labelRenderer.render(scene, camera);

    if (state.showInset) {
      var cr = canvas.getBoundingClientRect(), ir = insetEl.getBoundingClientRect();
      var x = ir.left - cr.left, y = cr.bottom - ir.bottom, w = ir.width, h = ir.height;
      updateInsetCam();
      insetCam.aspect = w / h;
      insetCam.updateProjectionMatrix();
      renderer.setScissorTest(true);
      renderer.setScissor(x, y, w, h);
      renderer.setViewport(x, y, w, h);
      scene.background = insetClear;
      renderer.render(scene, insetCam);
      renderer.setScissorTest(false);
    }
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // 调试用
  window.__model = { state: state, getDecl: function () { return decl; }, camera: camera, controls: controls, stepViewAnim: stepViewAnim };
})();
