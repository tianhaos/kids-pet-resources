// 纯计算：日期 ⇄ 轨道角、直射点、昼长、正午太阳高度等（不依赖 three.js；地日、正午太阳高度共用）
(function () {
  var DEG = Math.PI / 180;

  // 四个节气：年内第几天（1月1日 = 第1天，按平年）与轨道角 phi（度）
  // 地球位置 = (R·cos phi, 0, -R·sin phi)，从北极上方看逆时针公转
  // 地轴北端倾向 +x，因此地球在 -x（phi=180°）时北极朝向太阳 → 夏至
  var TERMS = [
    { key: 'spring', name: '春分', date: '3月21日前后', day: 80, phi: 90 },
    { key: 'summer', name: '夏至', date: '6月22日前后', day: 173, phi: 180 },
    { key: 'autumn', name: '秋分', date: '9月23日前后', day: 266, phi: 270 },
    { key: 'winter', name: '冬至', date: '12月22日前后', day: 356, phi: 360 }
  ];
  // 分段线性锚点（最后一个是下一年的春分）
  var ANCHORS = TERMS.map(function (t) { return { day: t.day, phi: t.phi }; })
    .concat([{ day: 80 + 365, phi: 450 }]);

  var MONTH_DAYS = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

  function wrapDay(d) {
    return (((d - 1) % 365) + 365) % 365 + 1; // [1, 366)
  }

  function dayToPhi(day) {
    var d = wrapDay(day);
    if (d < 80) d += 365;
    for (var i = 0; i < ANCHORS.length - 1; i++) {
      var a = ANCHORS[i], b = ANCHORS[i + 1];
      if (d >= a.day && d <= b.day) {
        return a.phi + (d - a.day) / (b.day - a.day) * (b.phi - a.phi);
      }
    }
    return 90;
  }

  function phiToDay(phi) {
    var p = ((phi - 90) % 360 + 360) % 360 + 90; // [90, 450)
    for (var i = 0; i < ANCHORS.length - 1; i++) {
      var a = ANCHORS[i], b = ANCHORS[i + 1];
      if (p >= a.phi && p <= b.phi) {
        return wrapDay(a.day + (p - a.phi) / (b.phi - a.phi) * (b.day - a.day));
      }
    }
    return 80;
  }

  function dayToDate(day) {
    var d = Math.floor(wrapDay(day));
    for (var m = 0; m < 12; m++) {
      if (d <= MONTH_DAYS[m]) return { month: m + 1, date: d };
      d -= MONTH_DAYS[m];
    }
    return { month: 12, date: 31 };
  }

  function dateToDay(month, date) {
    var d = date;
    for (var m = 0; m < month - 1; m++) d += MONTH_DAYS[m];
    return d;
  }

  // 当前处于哪两个节气之间
  function termInfo(day) {
    var d = wrapDay(day);
    for (var i = 0; i < TERMS.length; i++) {
      var diff = Math.abs(d - TERMS[i].day);
      diff = Math.min(diff, 365 - diff);
      if (diff < 1) return { exact: TERMS[i] };
    }
    var dd = d < 80 ? d + 365 : d;
    for (var j = 0; j < TERMS.length; j++) {
      var from = TERMS[j], to = TERMS[(j + 1) % 4];
      var toDay = j === 3 ? to.day + 365 : to.day;
      if (dd >= from.day && dd < toDay) {
        return { from: from, to: to, left: Math.ceil(toDay - dd) };
      }
    }
    return {};
  }

  // 太阳直射点纬度（度）：与地日模型的轨道几何一致，sin δ = −sin ε · cos phi；tilt 默认 23.44°
  function declination(day, tilt) {
    var e = (tilt == null ? 23.44 : tilt) * DEG;
    return Math.asin(-Math.sin(e) * Math.cos(dayToPhi(day) * DEG)) / DEG;
  }

  // 昼长（小时）；lat、decl 为度
  function dayLength(lat, decl) {
    var x = -Math.tan(lat * DEG) * Math.tan(decl * DEG);
    if (x <= -1) return 24;
    if (x >= 1) return 0;
    return 2 * Math.acos(x) / DEG / 15;
  }

  // 正午太阳高度（度）
  function noonAltitude(lat, decl) {
    return 90 - Math.abs(lat - decl);
  }

  function formatLat(v, digits) {
    digits = digits == null ? 1 : digits;
    var a = Math.abs(v).toFixed(digits);
    if (Number(a) === 0) return '0°';
    return a + '°' + (v > 0 ? 'N' : 'S');
  }

  // 度分格式，如 23°26′N（课本写法）
  function formatDMS(v) {
    var a = Math.abs(v), d = Math.floor(a), m = Math.round((a - d) * 60);
    if (m === 60) { d += 1; m = 0; }
    if (d === 0 && m === 0) return '0°';
    return d + '°' + (m ? m + '′' : '') + (v > 0 ? 'N' : 'S');
  }

  function formatLatCN(v, digits) {
    digits = digits == null ? 1 : digits;
    var a = Math.abs(v).toFixed(digits);
    if (Number(a) === 0) return '赤道 0°';
    return (v > 0 ? '北纬 ' : '南纬 ') + a + '°';
  }

  function formatHours(h) {
    var total = Math.round(h * 60);
    var hh = Math.floor(total / 60), mm = total % 60;
    return hh + ' 小时 ' + (mm < 10 ? '0' : '') + mm + ' 分';
  }

  function formatClock(h) {
    h = ((h % 24) + 24) % 24;
    var total = Math.round(h * 60) % (24 * 60);
    var hh = Math.floor(total / 60), mm = total % 60;
    return (hh < 10 ? '0' : '') + hh + ':' + (mm < 10 ? '0' : '') + mm;
  }

  window.Astro = {
    DEG: DEG,
    TERMS: TERMS,
    wrapDay: wrapDay,
    dayToPhi: dayToPhi,
    phiToDay: phiToDay,
    dayToDate: dayToDate,
    dateToDay: dateToDay,
    termInfo: termInfo,
    declination: declination,
    dayLength: dayLength,
    noonAltitude: noonAltitude,
    formatLat: formatLat,
    formatLatCN: formatLatCN,
    formatDMS: formatDMS,
    formatHours: formatHours,
    formatClock: formatClock
  };
})();
