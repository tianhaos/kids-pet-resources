// 理见 · 全站顶栏与模型搜索：首页和各模型页共用，依赖 shared/models.js（window.MODELS）
// 首页大搜索框与顶栏搜索都用 SiteSearch.attach；模型页额外把正文末尾的「下一个实验」复制到面板底部
(function () {
  var bar = document.querySelector('.site-bar');
  var base = bar ? bar.dataset.base || '' : '';          // 链接前缀：首页 ''，模型页 '../'
  var here = location.pathname.split('/').filter(Boolean).pop() || '';
  var MODELS = window.MODELS || [], SUBJECTS = window.SUBJECTS || {};
  var byDir = {};
  var items = MODELS.map(function (m, i) {
    var it = {
      i: i, s: m.s, href: base + m.dir + '/', dir: m.dir, title: m.title, tag: m.tag, grade: m.grade,
      t: m.title.toLowerCase(), g: m.tag.toLowerCase(), k: (m.kw || '').toLowerCase()
    };
    byDir[it.dir] = it;
    return it;
  });

  function track(category, action, label) {
    if (window.Analytics) Analytics.track(category, action, label);
  }
  function esc(s) { return s.replace(/[&<>"]/g, function (c) { return '&#' + c.charCodeAt(0) + ';'; }); }

  // 搜索框：数据取自 MODELS（标题、tag、kw 别名），未输入时提示 hot.js 里的热门模型
  // opts.label 是打点分类；opts.onClose 在输入框失焦时调用
  function attach(box, opts) {
    var input = box.querySelector('input');
    var list = box.querySelector('.search-list');
    var MAX = 12;
    var cur = [], active = -1, raf = 0, terms = [];
    var pre = list.id;

    // 每个词都要命中：标题开头 > 标题包含 > 标签 > 别名
    function score(it) {
      var sum = 0;
      for (var j = 0; j < terms.length; j++) {
        var w = terms[j], p = it.t.indexOf(w);
        var v = p === 0 ? 4 : p > 0 ? 3 : it.g.indexOf(w) >= 0 ? 2 : it.k.indexOf(w) >= 0 ? 1 : 0;
        if (!v) return 0;
        sum += v;
      }
      return sum;
    }
    function mark(title) {
      var low = title.toLowerCase(), on = [];
      terms.forEach(function (w) {
        for (var p = low.indexOf(w); p >= 0; p = low.indexOf(w, p + 1)) for (var k = 0; k < w.length; k++) on[p + k] = 1;
      });
      var out = '';
      for (var j = 0; j < title.length; j++) {
        if (on[j] && !on[j - 1]) out += '<mark>';
        out += esc(title[j]);
        if (on[j] && !on[j + 1]) out += '</mark>';
      }
      return out;
    }
    function row(it, sub, dot) {
      var n = cur.push(it) - 1;
      return '<a class="search-item" role="option" id="' + pre + n + '" href="' + esc(it.href) + '" data-s="' + it.s + '" data-n="' + n + '">' +
        (dot ? '<i></i>' : '') + '<span class="ti">' + mark(it.title) + '</span><span class="sub">' + esc(sub) + '</span></a>';
    }

    function render() {
      raf = 0;
      var q = input.value.trim().toLowerCase();
      terms = q ? q.split(/\s+/) : [];
      cur = [];
      var html = '';
      if (!terms.length) {
        var hot = (window.HOT_MODELS || []).map(function (d) { return byDir[d]; })
          .filter(function (it) { return it && it.dir !== here; });
        if (!hot.length) return close();
        html = '<div class="search-head">热门模型</div>' + hot.map(function (it) {
          return row(it, SUBJECTS[it.s] + ' · ' + it.grade, true);
        }).join('');
      } else {
        var hits = [];
        items.forEach(function (it) { var v = score(it); if (v) hits.push({ it: it, v: v }); });
        hits.sort(function (a, b) { return b.v - a.v || a.it.i - b.it.i; });
        var total = hits.length;
        // 按学科聚合，组的先后取组内最高分（最相关的结果排在最前，回车即进入它）
        var groups = {}, seq = [];
        hits.slice(0, MAX).forEach(function (h) {
          var s = h.it.s;
          if (!groups[s]) { groups[s] = []; seq.push(s); }
          groups[s].push(h.it);
        });
        html = seq.map(function (s) {
          return '<div class="search-group" data-s="' + s + '"><i></i>' + SUBJECTS[s] + '<b>' + groups[s].length + '</b></div>' +
            groups[s].map(function (it) { return row(it, it.grade + ' · ' + it.tag, false); }).join('');
        }).join('');
        if (!total) html = '<div class="search-empty">没有找到相关模型，试试 光学、电路、地球</div>';
        else if (total > MAX) html += '<div class="search-empty">共 ' + total + ' 个结果，再多输入几个字缩小范围</div>';
      }
      list.innerHTML = html;
      list.hidden = false;
      input.setAttribute('aria-expanded', 'true');
      setActive(terms.length && cur.length ? 0 : -1);
    }
    function schedule() { if (!raf) raf = requestAnimationFrame(render); }
    function close() {
      list.hidden = true;
      input.setAttribute('aria-expanded', 'false');
      input.removeAttribute('aria-activedescendant');
      active = -1;
    }
    function setActive(n) {
      var old = list.querySelector('.on');
      if (old) { old.classList.remove('on'); old.removeAttribute('aria-selected'); }
      active = n;
      var el = n >= 0 && document.getElementById(pre + n);
      if (!el) return input.removeAttribute('aria-activedescendant');
      el.classList.add('on');
      el.setAttribute('aria-selected', 'true');
      input.setAttribute('aria-activedescendant', el.id);
      el.scrollIntoView({ block: 'nearest' });
    }
    function go(it) {
      track(opts.label, input.value.trim() || '热门', (here ? here + '→' : '') + it.dir);
    }

    box.hidden = false;
    input.addEventListener('focus', schedule);
    input.addEventListener('blur', function () { close(); if (opts.onClose) opts.onClose(); });
    // 输入法组字期间（拼音未上屏）不匹配，上屏后再刷新
    input.addEventListener('input', function (e) { if (!e.isComposing) schedule(); });
    input.addEventListener('compositionend', schedule);
    input.addEventListener('keydown', function (e) {
      if (e.isComposing || e.keyCode === 229) return;
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
        e.preventDefault();
        if (list.hidden) return render();
        if (!cur.length) return;
        var d = e.key === 'ArrowDown' ? 1 : -1;
        setActive(active < 0 ? (d > 0 ? 0 : cur.length - 1) : (active + d + cur.length) % cur.length);
      } else if (e.key === 'Enter') {
        var it = !list.hidden && cur[active];
        if (!it) return;
        e.preventDefault();
        go(it);
        location.href = it.href;
      } else if (e.key === 'Escape') {
        if (input.value) { input.value = ''; render(); } else input.blur();
      }
    });
    // 点选结果时不让输入框先失焦关掉列表
    list.addEventListener('mousedown', function (e) { e.preventDefault(); });
    list.addEventListener('click', function (e) {
      var a = e.target.closest('.search-item');
      if (a) go(cur[+a.dataset.n]);
    });
    return input;
  }

  window.SiteSearch = { attach: attach };

  // 顶栏：搜索按钮展开输入框，失焦且没输入内容时收起
  var hero = document.querySelector('.hero .search');
  var heroInput = hero && attach(hero, { label: '首页搜索' });
  var find = bar && bar.querySelector('.site-find');
  var barBox = bar && bar.querySelector('.site-search');
  var barInput = null;
  // 首页：大搜索框还在视口里时，顶栏不显示搜索按钮，避免同屏两个搜索框
  var heroVisible = !!hero && !!window.IntersectionObserver;
  if (barBox) {
    barInput = attach(barBox, {
      label: '顶栏搜索',
      onClose: function () { if (!barInput.value) { barBox.hidden = true; find.hidden = heroVisible; } }
    });
    barBox.hidden = true;
    find.hidden = heroVisible;
    find.addEventListener('click', openBar);
    barBox.querySelector('.site-close').addEventListener('mousedown', function (e) {
      e.preventDefault();
      barInput.value = '';
      barInput.blur();
    });
  }
  function openBar() {
    find.hidden = true;
    barBox.hidden = false;
    barInput.focus();
  }

  if (heroVisible && find) {
    new IntersectionObserver(function (es) {
      heroVisible = es[0].isIntersecting;
      if (barBox.hidden) find.hidden = heroVisible;
    }, { rootMargin: '-' + bar.offsetHeight + 'px 0px 0px 0px' }).observe(hero);
  }

  // 「/」聚焦搜索：首页大搜索框可见时用它，否则展开顶栏搜索
  document.addEventListener('keydown', function (e) {
    if (e.key !== '/' || e.ctrlKey || e.metaKey || e.altKey) return;
    var t = e.target;
    if (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName)) return;
    if (heroInput && (heroVisible || !barBox)) { e.preventDefault(); heroInput.focus(); }
    else if (barBox) { e.preventDefault(); openBar(); }
  });

  // 留存打点：顶栏 logo、「全部模型」、下一个实验
  document.addEventListener('click', function (e) {
    var a = e.target.closest('a');
    if (!a) return;
    if (a.classList.contains('site-logo')) track('留存', 'home', here);
    else if (a.classList.contains('site-all')) track('留存', 'all', here);
    else if (a.closest('.related')) track('留存', a.closest('#panel') ? 'related-panel' : 'related-learn',
      here + '→' + a.getAttribute('href').replace(/^\.\.\/|\/$/g, ''));
  });

  // 「全部模型」后面显示模型总数
  var all = bar && bar.querySelector('.site-all');
  if (all && MODELS.length) all.insertAdjacentHTML('beforeend', ' <b>' + MODELS.length + '</b>');

  // 模型页：正文末尾的「下一个实验」复制一份到控制面板底部
  var rel = document.querySelector('.learn .related');
  var panel = document.getElementById('panel');
  if (rel && panel) panel.appendChild(rel.cloneNode(true));
})();
