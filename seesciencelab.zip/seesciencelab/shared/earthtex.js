// 地球贴图：用 shared/continents.js 的大陆轮廓画等距圆柱投影（地日、月相共用，挂在 window.makeEarthCanvas）
(function () {
  var LAND = window.Continents.LAND, ICE = window.Continents.ICE, WATER = window.Continents.WATER;

  function drawPolys(ctx, polys, W, H) {
    polys.forEach(function (poly) {
      ctx.beginPath();
      poly.forEach(function (p, i) {
        var x = (p[0] + 180) / 360 * W;
        var y = (90 - p[1]) / 180 * H;
        if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
      });
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
    });
  }

  // 生成等距圆柱投影贴图（u=0 对应西经180°）
  function makeEarthCanvas() {
    var W = 2048, H = 1024;
    var c = document.createElement('canvas');
    c.width = W; c.height = H;
    var ctx = c.getContext('2d');

    var g = ctx.createLinearGradient(0, 0, 0, H);
    g.addColorStop(0, '#2a5f9e');
    g.addColorStop(0.5, '#2f74bd');
    g.addColorStop(1, '#2a5f9e');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, W, H);

    ctx.lineJoin = 'round';
    ctx.lineWidth = 2;
    ctx.fillStyle = '#7cb35b';
    ctx.strokeStyle = '#5d9444';
    drawPolys(ctx, LAND, W, H);
    ctx.fillStyle = '#eef3f6';
    ctx.strokeStyle = '#cfd8dc';
    drawPolys(ctx, ICE, W, H);
    drawPolys(ctx, [LAND[3]], W, H); // 格陵兰画成冰雪色
    ctx.fillStyle = '#2f6fb2';
    ctx.strokeStyle = '#2f6fb2';
    drawPolys(ctx, WATER, W, H);

    // 经纬网（每 30°）
    ctx.strokeStyle = 'rgba(255,255,255,0.22)';
    ctx.lineWidth = 1.5;
    for (var lon = -180; lon <= 180; lon += 30) {
      var x = (lon + 180) / 360 * W;
      ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke();
    }
    for (var lat = -60; lat <= 60; lat += 30) {
      var y = (90 - lat) / 180 * H;
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke();
    }
    return c;
  }

  window.makeEarthCanvas = makeEarthCanvas;
})();
