// 光的波长与颜色：波长（nm）→ 显示颜色、色光名称。光电效应、玻尔模型共用
// 可见光取 380～750 nm；紫外线画成暗淡的蓝紫色、红外线画成暗淡的红褐色，表示看不见
(function () {
  var VIS = [380, 750];
  function clamp(x, a, b) { return Math.max(a, Math.min(b, x)); }
  // 波长（nm）→ [r, g, b]（0–1）
  function lamRGB(lam) {
    if (lam < VIS[0]) return [0.62, 0.5, 1];
    if (lam > VIS[1]) return [0.66, 0.32, 0.26];
    var r = 0, g = 0, b = 0;
    if (lam < 440) { r = -(lam - 440) / 60; b = 1; }
    else if (lam < 490) { g = (lam - 440) / 50; b = 1; }
    else if (lam < 510) { g = 1; b = -(lam - 510) / 20; }
    else if (lam < 580) { r = (lam - 510) / 70; g = 1; }
    else if (lam < 645) { r = 1; g = -(lam - 645) / 65; }
    else r = 1;
    var k = lam < 420 ? 0.7 + 0.3 * (lam - 380) / 40 : lam > 680 ? 0.55 + 0.45 * (750 - lam) / 70 : 1;
    k = clamp(k, 0.55, 1);
    return [Math.pow(r * k, 0.8), Math.pow(g * k, 0.8), Math.pow(b * k, 0.8)];
  }
  function css(rgb, a) {
    return 'rgba(' + Math.round(rgb[0] * 255) + ',' + Math.round(rgb[1] * 255) + ',' + Math.round(rgb[2] * 255) + ',' + (a == null ? 1 : a) + ')';
  }
  function lamCSS(lam, a) { return css(lamRGB(lam), a); }
  function visible(lam) { return lam >= VIS[0] && lam <= VIS[1]; }
  // 色光名称：可见光返回“红光”等，否则返回“紫外线”“红外线”
  function colorName(lam) {
    if (lam < VIS[0]) return '紫外线';
    if (lam > VIS[1]) return '红外线';
    return (lam < 450 ? '紫' : lam < 490 ? '蓝' : lam < 500 ? '青' : lam < 570 ? '绿' : lam < 590 ? '黄' : lam < 620 ? '橙' : '红') + '光';
  }
  window.Spectrum = { VIS: VIS, lamRGB: lamRGB, css: css, lamCSS: lamCSS, visible: visible, colorName: colorName };
})();
