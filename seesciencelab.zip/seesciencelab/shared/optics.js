// 薄透镜成像计算（纯函数，2D/3D 共用）
// 约定：物距 u > 0（物在透镜左侧），像距 v > 0 为实像（右侧），v < 0 为虚像（左侧）。
(function () {
  var EPS = 0.004;            // 判断「等于 f / 2f」的容差（以 f 为单位）
  var K_MIN = 0.4;            // 自动移动近端：0.4f，虚像仍在画面内
  var K_MAX = 40;             // 自动移动远端：40f，此时 v≈1.026f，像已与 F′ 视觉重合，视为「无穷远」
  var K_SLOW = 4;             // 4f 以内匀速慢行，4f 以外越远越快
  var V0 = 0.6;               // 基础速度（f/秒）
  var PAUSE = 0.8;            // 两端停顿（秒）

  // 1/u + 1/v = 1/f
  function image(u, f) {
    if (Math.abs(u - f) < 1e-9) return { v: Infinity, m: Infinity };
    var v = u * f / (u - f);
    return { v: v, m: -v / u };
  }

  var ZONES = {
    far:    { key: 'far',    cond: 'u > 2f',      nature: '倒立 · 缩小 · 实像', use: '照相机、人眼',   img: 'f < v < 2f' },
    double: { key: 'double', cond: 'u = 2f',      nature: '倒立 · 等大 · 实像', use: '测焦距（u = v = 2f）', img: 'v = 2f' },
    mid:    { key: 'mid',    cond: 'f < u < 2f',  nature: '倒立 · 放大 · 实像', use: '投影仪、幻灯机', img: 'v > 2f' },
    focal:  { key: 'focal',  cond: 'u = f',       nature: '不成像',             use: '折射光平行射出（探照灯原理）', img: '—' },
    near:   { key: 'near',   cond: 'u < f',       nature: '正立 · 放大 · 虚像', use: '放大镜',         img: '与物同侧' }
  };

  function zone(u, f) {
    var k = u / f;
    if (Math.abs(k - 2) < EPS) return ZONES.double;
    if (Math.abs(k - 1) < EPS) return ZONES.focal;
    if (k > 2) return ZONES.far;
    if (k > 1) return ZONES.mid;
    return ZONES.near;
  }

  function smoothstep(a, b, x) {
    var t = Math.min(Math.max((x - a) / (b - a), 0), 1);
    return t * t * (3 - 2 * t);
  }

  // 自动移动速度 dk/dt（f/秒）：
  //  k ≤ 4：慢速匀速，在 F、2F 附近再减速到 30%，便于看清「不成像」「等大」的转折；
  //  k > 4：v0·(k/4)²，越远越快（4f→40f 约 6 秒），返回时越近越慢。
  function autoSpeed(k) {
    if (k > K_SLOW) return V0 * (k / K_SLOW) * (k / K_SLOW);
    var d = Math.min(Math.abs(k - 1), Math.abs(k - 2));
    return V0 * (0.3 + 0.7 * smoothstep(0, 0.3, d));
  }

  // 推进一帧。st = { k, dir: +1 远离透镜 / -1 靠近, pause }
  function autoStep(st, dt, mult) {
    if (st.pause > 0) { st.pause -= dt; return st; }
    st.k += st.dir * autoSpeed(st.k) * mult * dt;
    if (st.k >= K_MAX) { st.k = K_MAX; st.dir = -1; st.pause = PAUSE; }
    else if (st.k <= K_MIN) { st.k = K_MIN; st.dir = 1; st.pause = PAUSE; }
    return st;
  }

  window.Optics = {
    image: image, zone: zone, ZONES: ZONES, autoSpeed: autoSpeed, autoStep: autoStep,
    K_MIN: K_MIN, K_MAX: K_MAX, K_SLOW: K_SLOW
  };
})();
