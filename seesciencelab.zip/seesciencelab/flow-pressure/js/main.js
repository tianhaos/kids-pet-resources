(function () {
  'use strict';
  const $ = id => document.getElementById(id), params = new URLSearchParams(location.search);
  const defaults = { scene: 'narrow', ratio: .4, speed: 1.8, probe: .5, play: true };
  const state = { ...defaults };
  function number(key, fallback, lo, hi) {
    const n = params.has(key) ? Number(params.get(key)) : fallback;
    return Flow.clamp(Number.isFinite(n) ? n : fallback, lo, hi);
  }
  state.scene = params.get('scene') === 'uniform' ? 'uniform' : 'narrow';
  state.ratio = state.scene === 'uniform' ? 1 : number('ratio', .4, .35, 1);
  state.speed = number('speed', 1.8, 0, 2); state.probe = number('probe', .5, .02, .98);
  const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)');
  state.play = params.has('play') ? params.get('play') !== '0' : !reducedMotion.matches;
  reducedMotion.addEventListener('change', e => { if (e.matches) { state.play = false; sync(); } });
  let time = 0, last = 0, table = Flow.transport(state), dragging = null, hover = null;
  const canvas = $('experiment');
  function track(action, label) { if (window.Analytics) Analytics.track('流速与压强', action, String(label)); }
  function sync() {
    const r = Flow.solve(state);
    ['ratio', 'speed', 'probe'].forEach(k => { $(k).value = state[k]; });
    $('ratioOut').textContent = Math.round(state.ratio * 100) + '%';
    $('speedOut').textContent = state.speed.toFixed(2) + ' m/s';
    $('probeOut').textContent = Math.round(state.probe * 100) + '%';
    $('primary').textContent = (r.delta / 1000).toFixed(2) + ' kPa';
    $('throatV').textContent = r.throat.v.toFixed(2) + ' m/s';
    $('throatP').textContent = (r.throat.p / 1000).toFixed(2) + ' kPa';
    $('flow').textContent = (r.flow * 1000).toFixed(1) + ' L/s';
    $('head').textContent = r.throat.head.toFixed(2) + ' m';
    $('status').textContent = state.speed === 0 ? '停止供流：各处等压，液面相平。' : state.ratio === 1 ? '等截面：速度相同，理想静压沿程不变。' : '喉部更快、静压更低；扩张后理想静压恢复。';
    $('play').textContent = state.play ? '暂停示踪' : '播放示踪';
    $('play').setAttribute('aria-pressed', String(!state.play));
    $('stop').textContent = state.speed ? '停止供流' : '恢复供流';
    document.querySelectorAll('[data-scene]').forEach(b => b.classList.toggle('on', b.dataset.scene === state.scene));
    document.querySelectorAll('[data-scene]').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.scene === state.scene)));
  }
  function set(values) {
    Object.assign(state, values);
    state.ratio = Flow.clamp(Number(state.ratio) || .35, .35, 1);
    state.speed = Flow.clamp(Number(state.speed) || 0, 0, 2);
    state.probe = Flow.clamp(Number(state.probe) || .02, .02, .98);
    state.scene = state.ratio === 1 ? 'uniform' : 'narrow';
    table = Flow.transport(state); sync();
  }
  ['ratio', 'speed', 'probe'].forEach(k => {
    $(k).addEventListener('input', e => set({ [k]: Number(e.target.value) }));
    $(k).addEventListener('change', () => track('参数', k + ':' + state[k]));
  });
  document.querySelectorAll('[data-scene]').forEach(b => b.onclick = () => { set({ ratio: b.dataset.scene === 'uniform' ? 1 : .4 }); track('场景', state.scene); });
  $('play').onclick = () => { state.play = !state.play; sync(); track('示踪', state.play); };
  $('stop').onclick = () => { set({ speed: state.speed ? 0 : 1.8 }); track('供流', state.speed); };
  $('reset').onclick = () => { set({ ...defaults, play: !reducedMotion.matches }); time = 0; track('重置', '默认'); };
  $('share').onclick = async () => {
    const url = new URL(location.href); url.search = ''; url.hash = '';
    ['scene', 'ratio', 'speed', 'probe'].forEach(k => url.searchParams.set(k, state[k])); url.searchParams.set('play', '0');
    $('shareLink').hidden = false; $('shareLink').value = url.href;
    try { await navigator.clipboard.writeText(url.href); $('share').textContent = '已复制链接'; } catch { $('shareLink').select(); $('share').textContent = '请复制下方链接'; }
    track('分享', state.scene);
  };
  $('panelToggle').onclick = () => {
    const collapsed = $('panel').classList.toggle('collapsed'); $('panelToggle').setAttribute('aria-expanded', String(!collapsed)); $('panelToggle').textContent = collapsed ? '实验设置' : '收起设置';
  };
  function move(e) {
    const p = FlowDraw.point(canvas, e), layout = FlowDraw.layout();
    if (dragging === 'probe') set({ probe: (p.x - layout.left) / (layout.right - layout.left) });
    if (dragging === 'throat') set({ ratio: (p.y - layout.cy) / layout.half });
    hover = dragging || FlowDraw.hit(p); canvas.style.cursor = hover === 'probe' ? 'ew-resize' : hover === 'throat' ? 'ns-resize' : 'default';
  }
  canvas.addEventListener('pointerdown', e => {
    const p = FlowDraw.point(canvas, e); dragging = FlowDraw.hit(p);
    // 也可在管道或曲线区域点选探测位置。
    const l = FlowDraw.layout();
    if (!dragging && p.x >= l.left && p.x <= l.right && ((Math.abs(p.y-l.cy) < l.half+12) || (p.y >= l.graphTop && p.y <= l.graphBottom+12))) dragging = 'probe';
    if (dragging) { canvas.setPointerCapture(e.pointerId); move(e); }
  });
  canvas.addEventListener('pointermove', move);
  function end(e) { if (dragging) track('拖动', dragging); dragging = null; if (canvas.hasPointerCapture(e.pointerId)) canvas.releasePointerCapture(e.pointerId); }
  canvas.addEventListener('pointerup', end); canvas.addEventListener('pointercancel', end);
  canvas.addEventListener('pointerleave', () => { if (!dragging) hover = null; });
  function frame(now) {
    if (state.play && last) time += Math.min(.05, (now - last) / 1000);
    last = now; FlowDraw.draw(canvas, state, time, table, hover); requestAnimationFrame(frame);
  }
  if (innerWidth <= 760) $('panel').classList.add('collapsed');
  sync(); requestAnimationFrame(frame);
  window.__model = { state, set, solve: () => Flow.solve(state), hits: () => FlowDraw.hits() };
})();
