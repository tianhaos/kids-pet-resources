/* 装置、测压液柱与独立静压图；读数和示踪输运均来自 Flow。 */
(function () {
  'use strict';
  const GOLD = '#ffc94a', BLUE = '#67d8ef', MUTED = '#8d9eb5';
  let layout, hits = [];
  function draw(canvas, s, time, table, hover) {
    const rect = canvas.getBoundingClientRect(), dpr = window.devicePixelRatio || 1;
    if (canvas.width !== Math.round(rect.width * dpr) || canvas.height !== Math.round(rect.height * dpr)) {
      canvas.width = Math.round(rect.width * dpr); canvas.height = Math.round(rect.height * dpr);
    }
    const c = canvas.getContext('2d'), mobile = rect.width < 650, W = mobile ? 390 : 900, H = 700;
    const scale = Math.min(rect.width / W, rect.height / H), ox = (rect.width - W * scale) / 2, oy = (rect.height - H * scale) / 2;
    c.setTransform(dpr, 0, 0, dpr, 0, 0); c.clearRect(0, 0, rect.width, rect.height);
    c.translate(ox, oy); c.scale(scale, scale);
    layout = { W, H, scale, ox, oy, left: mobile ? 40 : 78, right: W - (mobile ? 40 : 78), cy: 345, half: 57, graphTop: 552, graphBottom: 628 };
    const { left, right, cy, half } = layout, len = right - left, result = Flow.solve(s);
    const px = x => left + x * len, wall = x => half * Flow.areaRatio(x, s.ratio);
    const txt = (t, x, y, color = MUTED, size = 12, align = 'left') => {
      c.fillStyle = color; c.font = `${size}px -apple-system, "PingFang SC", sans-serif`; c.textAlign = align; c.fillText(t, x, y);
    };
    const line = (x1, y1, x2, y2, color, width = 1) => {
      c.strokeStyle = color; c.lineWidth = width; c.beginPath(); c.moveTo(x1, y1); c.lineTo(x2, y2); c.stroke();
    };
    const box = (x, y, w, h, fill, stroke) => { c.beginPath(); c.roundRect(x,y,w,h,10); c.fillStyle=fill;c.fill();if(stroke){c.strokeStyle=stroke;c.lineWidth=1;c.stroke();} };
    const glow = c.createRadialGradient(W/2,310,10,W/2,310,W*.65);glow.addColorStop(0,'#102633');glow.addColorStop(1,'#05070d');c.fillStyle=glow;c.fillRect(0,0,W,H);
    txt('流速与压强', 24, 91, '#ecf3fb', mobile ? 16 : 18);
    txt(s.speed === 0 ? '停止供流 · 同高等压，液面相平' : s.ratio === 1 ? '等截面 · 流速相同，液面相平' : '通道变窄，水流加快，液柱降低', 24, 116, BLUE, mobile ? 13 : 14);
    txt('01  观察测压液柱',24,151,MUTED,11);
    txt('开口与大气相通',W-24,151,MUTED,11,'right');
    // 实验台的支座与中性基线，不添加未计算的流场。
    line(left-15,423,right+15,423,'#304052',3);
    for (const x of [px(.08),px(.92)]) { box(x-10,cy+half,20,20,'#2a394a');line(x-19,421,x+19,421,'#516075',3); }
    const meters = [.1,.5,.9];
    meters.forEach((x,i)=>{
      const r=Flow.sample(s,x), xx=px(x), top=cy-r.head*70;
      line(xx,178,xx,cy,'#344d61',14);line(xx,178,xx,cy,'#08121e',9);
      line(xx,top,xx,cy,BLUE,7);line(xx-9,top,xx+9,top,'#d3f9ff',2);
      for(let h=0;h<=2;h+=.5){const yy=cy-h*70;line(xx+10,yy,xx+15,yy,'#4c657b');}
      txt((r.p/1000).toFixed(1),xx,top-22,i===1?GOLD:BLUE,mobile?16:18,'center');
      txt('kPa',xx,top-7,MUTED,10,'center');
    });
    // 等深通道：剖面高度与面积成正比。
    c.beginPath();
    for(let i=0;i<=180;i++){const x=i/180;i?c.lineTo(px(x),cy-wall(x)):c.moveTo(px(x),cy-wall(x));}
    for(let i=180;i>=0;i--){const x=i/180;c.lineTo(px(x),cy+wall(x));}c.closePath();
    const water=c.createLinearGradient(0,cy-half,0,cy+half);water.addColorStop(0,'#16475b');water.addColorStop(.5,'#0a2533');water.addColorStop(1,'#103548');
    c.fillStyle=water;c.fill();c.strokeStyle='#6eafc5';c.lineWidth=3;c.stroke();
    for(let row=-2;row<=2;row++){
      c.beginPath();for(let i=0;i<=100;i++){const x=i/100,y=cy+row/3*wall(x);i?c.lineTo(px(x),y):c.moveTo(px(x),y);}c.strokeStyle='#67d8ef22';c.lineWidth=1;c.stroke();
      for(let j=0;j<16;j++){
        const x=Flow.position(table,j/16+row*.021+time*s.speed/(6*table.length));
        c.fillStyle=j%4===0?GOLD:'#91d9e8';c.beginPath();c.arc(px(x),cy+row/3*wall(x),j%4===0?2.5:1.7,0,Math.PI*2);c.fill();
      }
    }
    meters.forEach(x=>{c.fillStyle='#d8f5ff';c.beginPath();c.arc(px(x),cy,3,0,Math.PI*2);c.fill();});
    // 喉部手柄在下壁；上下方向的拖动对应开口大小。
    const handle={type:'throat',x:px(.5),y:cy+wall(.5),radius:23};
    box(handle.x-17,handle.y-7,34,14,hover==='throat'?'#ffe393':GOLD);
    for(const x of [-5,0,5])line(handle.x+x,handle.y-3,handle.x+x,handle.y+3,'#6b521d');
    txt('↕ 拖动开口',handle.x,cy+half+(s.ratio > .85 ? 33 : 13),GOLD,11,'center');
    const probeX=px(s.probe), probeY=cy-17;
    c.setLineDash([3,4]);line(probeX,cy-76,probeX,cy+10,GOLD);c.setLineDash([]);
    c.fillStyle=GOLD;c.beginPath();c.arc(probeX,probeY,hover==='probe'?9:7,0,Math.PI*2);c.fill();
    hits=[handle,{type:'probe',x:probeX,y:probeY,radius:23}];
    const cardW=mobile?100:190;
    meters.forEach((x,i)=>{const r=Flow.sample(s,x),xx=px(x),accent=i===1?GOLD:BLUE;
      box(xx-cardW/2,441,cardW,60,'#0c1420',i===1?'#685631':'#233346');
      txt(['A · 入口','B · 喉部','C · 出口'][i],xx,461,MUTED,11,'center');
      txt(r.v.toFixed(2)+' m/s',xx,485,accent,mobile?15:17,'center');
    });
    txt('02  沿程静压',24,533,'#d7e4ef',13);txt('表压 / kPa',W-24,533,MUTED,11,'right');
    const gy=layout.graphBottom,gh=gy-layout.graphTop;
    [0,10,20].forEach(p=>{const y=gy-p/22*gh;line(left,y,right,y,'#213043');txt(String(p),left-9,y+4,MUTED,10,'right');});
    c.beginPath();c.moveTo(left,gy);
    for(let i=0;i<=200;i++){const x=i/200;c.lineTo(px(x),gy-Flow.sample(s,x).p/22000*gh);}c.lineTo(right,gy);c.closePath();c.fillStyle='#67d8ef0c';c.fill();
    c.beginPath();for(let i=0;i<=200;i++){const x=i/200,y=gy-Flow.sample(s,x).p/22000*gh;i?c.lineTo(px(x),y):c.moveTo(px(x),y);}c.strokeStyle=BLUE;c.lineWidth=2;c.stroke();
    const py=gy-result.probe.p/22000*gh;line(probeX,gy,probeX,py,GOLD);c.fillStyle=GOLD;c.beginPath();c.arc(probeX,py,4,0,Math.PI*2);c.fill();
    txt('探头 '+result.probe.v.toFixed(2)+' m/s  ·  '+(result.probe.p/1000).toFixed(2)+' kPa',W/2,651,GOLD,13,'center');
    txt('拖金色探头或点曲线读数 · 水平、等深通道',W/2,674,MUTED,11,'center');
  }
  function point(canvas,event){const r=canvas.getBoundingClientRect();return{x:(event.clientX-r.left-layout.ox)/layout.scale,y:(event.clientY-r.top-layout.oy)/layout.scale};}
  function hit(p){return hits.find(h=>Math.hypot(p.x-h.x,p.y-h.y)<=h.radius)?.type;}
  window.FlowDraw={draw,point,hit,layout:()=>layout,hits:()=>hits};
})();
