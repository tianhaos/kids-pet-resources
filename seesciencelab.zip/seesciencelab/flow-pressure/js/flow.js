/* 水平、等深矩形通道的截面平均一维模型；SI单位。 */
(function () {
  'use strict';
  const RHO = 1000, G = 9.8, A1 = .01, P1 = 20000;
  function clamp(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); }
  // 光滑收缩与扩张，x 为全长的比例，喉部为 .42—.58。
  function areaRatio(x, ratio) {
    const u = clamp((Math.abs(x - .5) - .08) / .27, 0, 1);
    return ratio + (1 - ratio) * u * u * (3 - 2 * u);
  }
  function sample(s, x) {
    const ratio = areaRatio(x, s.ratio), area = A1 * ratio;
    const v = s.speed / ratio;
    const p = P1 + .5 * RHO * (s.speed * s.speed - v * v);
    return { x, ratio, area, v, p, head: p / (RHO * G), dynamic: .5 * RHO * v * v };
  }
  function solve(s) {
    const inlet = sample(s, .1), throat = sample(s, .5), probe = sample(s, s.probe);
    return { inlet, throat, probe, flow: A1 * s.speed, delta: inlet.p - throat.p,
      total: P1 + .5 * RHO * s.speed * s.speed };
  }
  // 用行程积分坐标输运粒子，确保收缩段按局部截面平均速度前进。
  function transport(s) {
    const n = 400, distance = [0];
    for (let i = 1; i <= n; i++) distance.push(distance[i - 1] + (areaRatio((i - 1) / n, s.ratio) + areaRatio(i / n, s.ratio)) / (2 * n));
    return { distance, length: distance[n], n };
  }
  function position(table, phase) {
    const target = ((phase % 1) + 1) % 1 * table.length;
    let lo = 0, hi = table.n;
    while (hi - lo > 1) { const m = (lo + hi) >> 1; if (table.distance[m] <= target) lo = m; else hi = m; }
    return (lo + (target - table.distance[lo]) / (table.distance[hi] - table.distance[lo])) / table.n;
  }
  window.Flow = { RHO, G, A1, P1, clamp, areaRatio, sample, solve, transport, position };
})();
