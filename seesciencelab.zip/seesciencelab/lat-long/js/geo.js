// 经纬网纯计算：经纬度格式化、半球与纬度带判断、纬线长度、两点方向、练习题（不碰 DOM）
// 约定：纬度 lat ∈ [−90, 90]，北纬为正；经度 lon ∈ (−180, 180]，东经为正；单位均为度
(function () {
  var DEG = Math.PI / 180;
  var EQUATOR_KM = 40076;   // 赤道周长
  var MERIDIAN_KM = 20004;  // 一条经线（半圆）长
  var TROPIC = 23 + 26 / 60, POLAR = 66 + 34 / 60;  // 回归线 23°26′、极圈 66°34′
  var EW_WEST = -20, EW_EAST = 160;                 // 东西半球分界：20°W 和 160°E

  // 特殊纬线、经线（标签用）
  var SPECIAL_LATS = [
    { key: 'equator', name: '赤道', lat: 0 },
    { key: 'tropicN', name: '北回归线', lat: TROPIC },
    { key: 'tropicS', name: '南回归线', lat: -TROPIC },
    { key: 'polarN', name: '北极圈', lat: POLAR },
    { key: 'polarS', name: '南极圈', lat: -POLAR }
  ];

  var PLACES = [
    { key: 'beijing', name: '北京', lat: 39.9, lon: 116.4 },
    { key: 'shanghai', name: '上海', lat: 31.2, lon: 121.5 },
    { key: 'greenwich', name: '格林尼治天文台（伦敦）', lat: 51.48, lon: 0 },
    { key: 'newyork', name: '纽约', lat: 40.7, lon: -74.0 },
    { key: 'sydney', name: '悉尼', lat: -33.9, lon: 151.2 },
    { key: 'rio', name: '里约热内卢', lat: -22.9, lon: -43.2 },
    { key: 'cairo', name: '开罗', lat: 30.0, lon: 31.2 },
    { key: 'singapore', name: '新加坡', lat: 1.3, lon: 103.8 },
    { key: 'northpole', name: '北极点', lat: 90, lon: 0 },
    { key: 'southpole', name: '南极点', lat: -90, lon: 0 }
  ];

  function normLon(lon) {
    var x = ((lon + 180) % 360 + 360) % 360 - 180;
    return x === -180 ? 180 : x;
  }
  // b 相对 a 的经度差（−180, 180]，正值表示 b 在 a 以东
  function dLon(a, b) { return normLon(b - a); }

  function num(v, digits) {
    var d = digits == null ? (Math.abs(v - Math.round(v)) < 0.05 ? 0 : 1) : digits;
    return Number(Math.abs(v).toFixed(d)).toString();
  }
  // 30°N / 0° / 23°26′N 式样
  function fmtLat(lat, digits) {
    if (Math.abs(lat) < 0.05) return '0°';
    if (Math.abs(Math.abs(lat) - TROPIC) < 0.01) return '23°26′' + (lat > 0 ? 'N' : 'S');
    if (Math.abs(Math.abs(lat) - POLAR) < 0.01) return '66°34′' + (lat > 0 ? 'N' : 'S');
    return num(lat, digits) + '°' + (lat > 0 ? 'N' : 'S');
  }
  function fmtLon(lon, digits) {
    lon = normLon(lon);
    if (Math.abs(lon) < 0.05) return '0°';
    if (Math.abs(Math.abs(lon) - 180) < 0.05) return '180°';
    return num(lon, digits) + '°' + (lon > 0 ? 'E' : 'W');
  }
  function fmtLatCN(lat, digits) {
    if (Math.abs(lat) < 0.05) return '0°（赤道）';
    if (Math.abs(lat) > 89.95) return (lat > 0 ? '北纬' : '南纬') + ' 90°（' + (lat > 0 ? '北' : '南') + '极点）';
    return (lat > 0 ? '北纬 ' : '南纬 ') + num(lat, digits) + '°';
  }
  function fmtLonCN(lon, digits) {
    lon = normLon(lon);
    if (Math.abs(lon) < 0.05) return '0°（本初子午线）';
    if (Math.abs(Math.abs(lon) - 180) < 0.05) return '180°';
    return (lon > 0 ? '东经 ' : '西经 ') + num(lon, digits) + '°';
  }
  function fmtPoint(lat, lon) {
    if (Math.abs(lat) > 89.95) return lat > 0 ? '北极点（90°N）' : '南极点（90°S）';
    return '(' + fmtLat(lat) + '，' + fmtLon(lon) + ')';
  }

  // 南北半球：赤道上的点不属于任何一侧
  function hemiNS(lat) { return Math.abs(lat) < 1e-6 ? '' : lat > 0 ? 'N' : 'S'; }
  // 东西半球：20°W 以东到 160°E 为东半球；正好在 20°W 或 160°E 上返回 ''
  function hemiEW(lon) {
    lon = normLon(lon);
    if (Math.abs(lon - EW_WEST) < 1e-6 || Math.abs(lon - EW_EAST) < 1e-6) return '';
    return lon > EW_WEST && lon < EW_EAST ? 'E' : 'W';
  }
  function hemiText(lat, lon) {
    var ns = hemiNS(lat), ew = hemiEW(lon);
    var a = ew === 'E' ? '东半球' : ew === 'W' ? '西半球' : '东西半球分界线上';
    var b = ns === 'N' ? '北半球' : ns === 'S' ? '南半球' : '赤道上';
    if (Math.abs(lat) > 89.95) a = '（极点不分东西）';
    return { ew: a, ns: b };
  }
  // 低纬度 0~30°、中纬度 30~60°、高纬度 60~90°
  function latZone(lat) {
    var a = Math.abs(lat);
    return a < 30 ? '低纬度' : a < 60 ? '中纬度' : '高纬度';
  }
  // 五带（以回归线、极圈为界）
  function heatZone(lat) {
    var a = Math.abs(lat);
    if (a < TROPIC) return '热带';
    if (a < POLAR) return (lat > 0 ? '北' : '南') + '温带';
    return (lat > 0 ? '北' : '南') + '寒带';
  }
  // 纬线圈长度、该纬线上经度相差 1° 的距离（km）
  function parallelKm(lat) { return EQUATOR_KM * Math.cos(lat * DEG); }
  function lonDegKm(lat) { return parallelKm(lat) / 360; }

  // b 在 a 的什么方向（经纬网定方向：南北看纬度，东西看劣弧方向的经度差）
  function direction(a, b) {
    var ns = b.lat > a.lat + 1e-6 ? '北' : b.lat < a.lat - 1e-6 ? '南' : '';
    var d = dLon(a.lon, b.lon);
    var ew = Math.abs(d) < 1e-6 || Math.abs(Math.abs(d) - 180) < 1e-6 ? '' : d > 0 ? '东' : '西';
    if (!ns && !ew) return '同一点';
    if (!ns) return '正' + ew;
    if (!ew) return '正' + ns;
    return ew + ns; // 东北、西南……
  }

  // ---------- 练习 ----------
  function pick(rng, arr) { return arr[Math.floor(rng() * arr.length)]; }
  function shuffle(rng, arr) {
    for (var i = arr.length - 1; i > 0; i--) { var j = Math.floor(rng() * (i + 1)), t = arr[i]; arr[i] = arr[j]; arr[j] = t; }
    return arr;
  }
  function uniqOptions(rng, ans, wrong, n) {
    var out = [ans];
    wrong.forEach(function (w) { if (out.length < n && out.indexOf(w) < 0) out.push(w); });
    return shuffle(rng, out);
  }
  function randLat(rng, noZero) {
    var v = (Math.floor(rng() * 8) + 1) * 10 * (rng() < 0.5 ? 1 : -1); // ±10~80
    return !noZero && rng() < 0.08 ? 0 : v;
  }
  function randLon(rng) {
    var v = (Math.floor(rng() * 36) - 17) * 10; // −170~180
    return v === 0 && rng() < 0.6 ? 30 : v;
  }

  // 读出标记点的经纬度
  function quizRead(rng) {
    var lat = randLat(rng), lon = randLon(rng);
    if (lat === 0 && (lon === 0 || lon === 180)) lon = 60;
    var ans = fmtPoint(lat, lon);
    var wrong = [fmtPoint(-lat, lon), fmtPoint(lat, -lon), fmtPoint(-lat, -lon)];
    if (Math.abs(lon) <= 80 && lat !== 0 && lon !== 0) wrong.push(fmtPoint(lon, lat)); // 经纬度写反
    wrong.push(fmtPoint(lat + (lat >= 0 ? 10 : -10) * (Math.abs(lat) === 80 ? -1 : 1), lon), fmtPoint(lat, normLon(lon + 10))); // 数错一格
    wrong = wrong.filter(function (w) { return w !== ans; });
    var latWhy = lat === 0 ? '它在赤道上，纬度为 0°' : '它在赤道以' + (lat > 0 ? '北' : '南') + '，纬度越往' + (lat > 0 ? '北' : '南') + '越大，是' + (lat > 0 ? '北纬' : '南纬') + '（' + fmtLat(lat) + '）';
    var lonWhy = Math.abs(lon) === 180 ? '经度为 180°（东西经的分界，不写 E 或 W）'
      : '它在本初子午线以' + (lon > 0 ? '东' : '西') + '，经度越往' + (lon > 0 ? '东' : '西') + '越大，是' + (lon > 0 ? '东经' : '西经') + '（' + fmtLon(lon) + '）';
    return {
      type: 'read', a: { lat: lat, lon: lon },
      prompt: '地球仪上 A 点的经纬度是？',
      answer: ans, options: uniqOptions(rng, ans, wrong, 4),
      explain: '先看纬度：' + latWhy + '；再看经度：' + lonWhy + '。所以 A 点是 ' + ans + '。'
    };
  }

  // 在地球上点出给定经纬度（容差 ±TOL°）
  var TOL = 5;
  function quizFind(rng) {
    var lat = randLat(rng, true), lon = randLon(rng);
    return {
      type: 'find', a: { lat: lat, lon: lon },
      prompt: '在地球仪上点出 ' + fmtPoint(lat, lon) + '，即' + fmtLatCN(lat) + '、' + (lon === 0 ? '本初子午线上' : fmtLonCN(lon)) + '的点',
      explain: fmtLat(lat) + '：从赤道往' + (lat > 0 ? '北' : '南') + '数到第 ' + Math.abs(lat / 10) + ' 条纬线（每格 10°）；' +
        (lon === 0 ? '0° 经线就是本初子午线' : Math.abs(lon) === 180 ? '180° 经线在本初子午线的正对面'
          : fmtLon(lon) + '：从本初子午线往' + (lon > 0 ? '东' : '西') + '数到第 ' + Math.abs(lon / 10) + ' 条经线') + '。两线的交点就是所求的点。'
    };
  }
  function checkFind(q, lat, lon) {
    var ok = Math.abs(lat - q.a.lat) <= TOL && Math.abs(dLon(lon, q.a.lon)) * Math.max(Math.cos(q.a.lat * DEG), 0.35) <= TOL;
    return ok;
  }

  // 判断东西半球、南北半球（经度偏向 20°W、160°E 附近，最容易出错）
  var HEMI_OPTIONS = ['东半球、北半球', '东半球、南半球', '西半球、北半球', '西半球、南半球'];
  function quizHemi(rng) {
    var lat = randLat(rng, true);
    var lon = rng() < 0.65 ? pick(rng, [-40, -30, -10, 0, 10, 150, 170, 180, -170, 140]) : randLon(rng);
    if (lon === -20 || lon === 160) lon += 10;
    var ew = hemiEW(lon), ns = hemiNS(lat);
    var ans = (ew === 'E' ? '东半球' : '西半球') + '、' + (ns === 'N' ? '北半球' : '南半球');
    var why;
    if (lon === 180) why = '180° 经线在 160°E 以东，属于西半球';
    else if (lon < 0 && lon > EW_WEST) why = fmtLon(lon) + ' 虽然是西经，但在 20°W 以东，属于东半球';
    else if (lon > EW_EAST) why = fmtLon(lon) + ' 虽然是东经，但在 160°E 以东，属于西半球';
    else if (ew === 'E') why = fmtLon(lon) + ' 在 20°W 以东、160°E 以西，属于东半球';
    else why = fmtLon(lon) + ' 在 20°W 以西，属于西半球';
    return {
      type: 'hemi', a: { lat: lat, lon: lon },
      prompt: 'A 点 ' + fmtPoint(lat, lon) + ' 位于？',
      answer: ans, options: HEMI_OPTIONS.slice(),
      explain: '东西半球以 20°W 和 160°E 组成的经线圈为界，不是以 0° 和 180° 为界：' + why + '；' + fmtLat(lat) + ' 在赤道以' + (lat > 0 ? '北' : '南') + '，属于' + (lat > 0 ? '北' : '南') + '半球。'
    };
  }

  // 两点方向（含跨 180° 经线的情形）
  var DIRS = ['正北', '正南', '正东', '正西', '东北', '西北', '东南', '西南'];
  function quizDir(rng) {
    var a, b, guard = 0;
    do {
      a = { lat: (Math.floor(rng() * 12) - 6) * 10 || 10, lon: randLon(rng) };
      if (rng() < 0.3) a.lon = pick(rng, [160, 170, -170, -160]); // 靠近 180° 经线，练跨 180° 的东西判断
      var dl = (Math.floor(rng() * 7) - 3) * 10 * (rng() < 0.4 ? 2 : 1);
      var dp = (Math.floor(rng() * 5) - 2) * 10;
      b = { lat: Math.max(-80, Math.min(80, a.lat + dp)), lon: normLon(a.lon + dl) };
    } while ((direction(a, b) === '同一点' || Math.abs(dLon(a.lon, b.lon)) > 90) && ++guard < 50);
    var ans = direction(a, b);
    var d = dLon(a.lon, b.lon);
    var raw = a.lon + d, cross = Math.abs(d) > 1e-6 && (raw > 180 || raw <= -180 || Math.abs(b.lon) === 180 || Math.abs(a.lon) === 180);
    var ewWhy = Math.abs(d) < 1e-6 ? '两点在同一条经线上，没有东西之分'
      : 'B 点在 A 点以' + (d > 0 ? '东' : '西') + '（两地经度相差 ' + Math.abs(d) + '°，沿相差小于 180° 的一侧判断' +
        (cross ? '；这一侧要经过 180° 经线：170°E 往东是 180°，再往东就是西经度数变小' : '') + '）';
    var nsWhy = b.lat === a.lat ? '两点在同一条纬线上，南北方向相同' : 'B 点纬度 ' + fmtLat(b.lat) + ' 在 A 点 ' + fmtLat(a.lat) + ' 以' + (b.lat > a.lat ? '北' : '南');
    return {
      type: 'dir', a: a, b: b,
      prompt: 'A ' + fmtPoint(a.lat, a.lon) + '，B ' + fmtPoint(b.lat, b.lon) + '。B 点在 A 点的什么方向？',
      answer: ans, options: uniqOptions(rng, ans, shuffle(rng, DIRS.filter(function (x) { return x !== ans; })), 4),
      explain: '经纬网定方向：纬线指示东西方向，经线指示南北方向。' + nsWhy + '；' + ewWhy + '。所以 B 在 A 的' + ans + '方向。'
    };
  }

  var MAKERS = { read: quizRead, find: quizFind, hemi: quizHemi, dir: quizDir };
  var QUIZ_TYPES = ['read', 'find', 'hemi', 'dir'];
  function quiz(rng, only) {
    rng = rng || Math.random;
    return MAKERS[only && MAKERS[only] ? only : pick(rng, QUIZ_TYPES)](rng);
  }

  window.Geo = {
    DEG: DEG, EQUATOR_KM: EQUATOR_KM, MERIDIAN_KM: MERIDIAN_KM, TROPIC: TROPIC, POLAR: POLAR,
    EW_WEST: EW_WEST, EW_EAST: EW_EAST, SPECIAL_LATS: SPECIAL_LATS, PLACES: PLACES,
    normLon: normLon, dLon: dLon, fmtLat: fmtLat, fmtLon: fmtLon, fmtLatCN: fmtLatCN, fmtLonCN: fmtLonCN, fmtPoint: fmtPoint,
    hemiNS: hemiNS, hemiEW: hemiEW, hemiText: hemiText, latZone: latZone, heatZone: heatZone,
    parallelKm: parallelKm, lonDegKm: lonDegKm, direction: direction,
    quiz: quiz, checkFind: checkFind, QUIZ_TYPES: QUIZ_TYPES, TOL: TOL
  };
})();
