// three.js 场景：地球仪（地轴、支架、经纬网、特殊纬线、半球着色、标记点、所在经线/纬线、自转方向）
// 坐标：地球半径 1，地轴沿 tiltGroup 的 +y；(lat, lon) → (cos φ cos λ, sin φ, −cos φ sin λ)，与 shared/earthtex.js 贴图一致
(function () {
  var G = window.Geo, DEG = Math.PI / 180, V3 = THREE.Vector3;
  var TILT = 23.5;           // 地球仪地轴与竖直方向的夹角（地轴与“桌面”成 66.5°）
  var C_LAT = 0x4fc3f7, C_LON = 0xff8a65, C_EQ = 0xff6b5b, C_PM = 0xffc94a;

  function ll(lat, lon, r, out) {
    var p = lat * DEG, l = lon * DEG;
    return (out || new V3()).set(Math.cos(p) * Math.cos(l), Math.sin(p), -Math.cos(p) * Math.sin(l)).multiplyScalar(r || 1);
  }
  function parallelPts(lat, r, step) {
    var pts = [];
    for (var lon = 0; lon <= 360; lon += step || 2) pts.push(ll(lat, lon, r));
    return pts;
  }
  function meridianPts(lon, r) {
    var pts = [];
    for (var lat = -90; lat <= 90; lat += 2) pts.push(ll(lat, lon, r));
    return pts;
  }
  function lineOf(pts, mat) {
    var l = new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts), mat);
    if (mat.isLineDashedMaterial) l.computeLineDistances();
    return l;
  }
  // 粗线：纬线用圆环，经线用半圆环（从南极经 (0°, lon) 到北极）
  function parallelTube(lat, r, tube, color) {
    var m = new THREE.Mesh(new THREE.BufferGeometry(), new THREE.MeshBasicMaterial({ color: color }));
    m.rotation.x = Math.PI / 2;
    m.userData.setLat = function (la) {
      if (m.userData.lat === la) return;
      m.userData.lat = la;
      m.geometry.dispose();
      m.geometry = new THREE.TorusGeometry(Math.max(Math.cos(la * DEG), 0.02) * r, tube, 6, 160);
      m.position.y = Math.sin(la * DEG) * r;
    };
    m.userData.setLat(lat);
    return m;
  }
  function meridianTube(lon, r, tube, color, arc) {
    var g = new THREE.TorusGeometry(r, tube, 6, 120, arc || Math.PI);
    g.rotateZ(-Math.PI / 2);
    var m = new THREE.Mesh(g, new THREE.MeshBasicMaterial({ color: color }));
    m.rotation.y = lon * DEG;
    return m;
  }

  function create(stage) {
    var renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    stage.insertBefore(renderer.domElement, stage.firstChild);
    var canvas = renderer.domElement;

    var labelRenderer = new THREE.CSS2DRenderer();
    var ls = labelRenderer.domElement.style;
    ls.position = 'absolute'; ls.top = '0'; ls.left = '0'; ls.pointerEvents = 'none'; ls.zIndex = '2';
    stage.appendChild(labelRenderer.domElement);

    var scene = new THREE.Scene();
    scene.background = new THREE.Color('#05070d');
    var camera = new THREE.PerspectiveCamera(30, 1, 0.1, 100);
    var controls = new THREE.OrbitControls(camera, canvas);
    controls.enableDamping = true;
    controls.dampingFactor = 0.08;
    controls.enablePan = false;
    controls.minDistance = 2.6;
    controls.maxDistance = 16;
    controls.rotateSpeed = 0.7;

    scene.add(new THREE.AmbientLight(0xffffff, 0.66));
    var camLight = new THREE.DirectionalLight(0xffffff, 0.48);
    scene.add(camLight);

    var tiltGroup = new THREE.Group();   // 地轴倾斜（支架不随之倾斜）
    var spinGroup = new THREE.Group();   // 随地球自转：地球、经纬网、标记点
    scene.add(tiltGroup);
    tiltGroup.add(spinGroup);

    var labels = [];
    function makeLabel(html, cls, parent) {
      var el = document.createElement('div');
      el.className = 'lbl ' + (cls || '');
      el.innerHTML = html;
      var o = new THREE.CSS2DObject(el);
      o.userData.want = true;
      o.userData.face = true;   // 只在朝向相机的一面显示
      parent.add(o);
      labels.push(o);
      return o;
    }

    // ---------- 地球 ----------
    var tex = new THREE.CanvasTexture(window.makeEarthCanvas());
    tex.anisotropy = renderer.capabilities.getMaxAnisotropy();
    var earth = new THREE.Mesh(new THREE.SphereGeometry(1, 96, 64),
      new THREE.MeshLambertMaterial({ map: tex, color: 0xc4c9d2 }));
    spinGroup.add(earth);

    // ---------- 半球着色（着色器按经纬度着色） ----------
    var hemiUniforms = { mode: { value: 0 }, cA: { value: new THREE.Color('#ffb74d') }, cB: { value: new THREE.Color('#4fc3f7') } };
    var hemiShell = new THREE.Mesh(new THREE.SphereGeometry(1.002, 96, 64), new THREE.ShaderMaterial({
      uniforms: hemiUniforms, transparent: true, depthWrite: false,
      vertexShader: [
        'varying vec3 vP;',
        'void main(){ vP = normalize(position); gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }'
      ].join('\n'),
      fragmentShader: [
        'uniform float mode; uniform vec3 cA; uniform vec3 cB; varying vec3 vP;',
        'void main(){',
        '  float a;',
        '  if (mode < 1.5) { float lon = degrees(atan(-vP.z, vP.x)); a = (lon > -20.0 && lon < 160.0) ? 1.0 : 0.0; }',
        '  else a = vP.y > 0.0 ? 1.0 : 0.0;',
        '  gl_FragColor = vec4(mix(cB, cA, a), 0.34);',
        '}'
      ].join('\n')
    }));
    hemiShell.visible = false;
    spinGroup.add(hemiShell);
    var ewRing = new THREE.Group();   // 20°W 与 160°E 组成的经线圈
    ewRing.add(meridianTube(-20, 1.004, 0.007, 0xe1bee7));
    ewRing.add(meridianTube(160, 1.004, 0.007, 0xe1bee7));
    spinGroup.add(ewRing);
    var hemiLabels = {
      E: makeLabel('东半球', 'lbl-hemi e', spinGroup), W: makeLabel('西半球', 'lbl-hemi w', spinGroup),
      N: makeLabel('北半球', 'lbl-hemi e', spinGroup), S: makeLabel('南半球', 'lbl-hemi w', spinGroup)
    };
    var ewLabels = [makeLabel('20°W', 'lbl-ew', spinGroup), makeLabel('160°E', 'lbl-ew', spinGroup)];

    // ---------- 经纬网（按间隔重建） ----------
    var grid = new THREE.Group();
    spinGroup.add(grid);
    var latLabels = [], lonLabels = [], lastGrid = null;
    var gridMat = new THREE.LineBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.42 });
    function buildGrid(step) {
      while (grid.children.length) grid.remove(grid.children[0]);
      latLabels.concat(lonLabels).forEach(function (o) { o.parent.remove(o); });
      labels = labels.filter(function (o) { return latLabels.indexOf(o) < 0 && lonLabels.indexOf(o) < 0; });
      latLabels = []; lonLabels = [];
      for (var lat = -90 + step; lat < 90; lat += step) {
        if (lat !== 0) grid.add(lineOf(parallelPts(lat, 1.003), gridMat));
        var lb = makeLabel(G.fmtLat(lat), 'lbl-lat' + (lat === 0 ? ' zero' : ''), spinGroup);
        lb.userData.lat = lat;
        latLabels.push(lb);
      }
      for (var lon = -180 + step; lon <= 180; lon += step) {
        if (lon !== 0) grid.add(lineOf(meridianPts(lon, 1.003), gridMat));
      }
      var lstep = step === 10 ? 20 : 30;
      for (var lo = -180 + lstep; lo <= 180; lo += lstep) {
        var lb2 = makeLabel(G.fmtLon(lo), 'lbl-lon' + (lo === 0 ? ' zero' : ''), spinGroup);
        lb2.userData.lon = lo;
        lonLabels.push(lb2);
      }
    }

    // ---------- 特殊纬线、经线 ----------
    var special = new THREE.Group();
    spinGroup.add(special);
    var equator = parallelTube(0, 1.003, 0.006, C_EQ);
    special.add(equator);
    var prime = meridianTube(0, 1.003, 0.006, C_PM);
    special.add(prime);
    special.add(lineOf(meridianPts(180, 1.003), new THREE.LineBasicMaterial({ color: 0xfff3c4, transparent: true, opacity: 0.8 })));
    var dashMat = { tropic: new THREE.LineDashedMaterial({ color: 0xffe066, dashSize: 0.035, gapSize: 0.025 }),
      polar: new THREE.LineDashedMaterial({ color: 0x80deea, dashSize: 0.035, gapSize: 0.025 }) };
    var specialLabels = [];
    G.SPECIAL_LATS.forEach(function (s) {
      if (s.lat !== 0) special.add(lineOf(parallelPts(s.lat, 1.004, 1), /tropic/.test(s.key) ? dashMat.tropic : dashMat.polar));
      var o = makeLabel(s.name + (s.lat ? ' ' + G.fmtLat(s.lat) : ''), 'lbl-sp ' + s.key, spinGroup);
      o.userData.lat = s.lat;
      specialLabels.push(o);
    });
    var pmLabel = makeLabel('本初子午线 0°', 'lbl-sp pm', spinGroup);
    var antiLabel = makeLabel('180° 经线', 'lbl-sp anti', spinGroup);

    // ---------- 地轴、两极、支架 ----------
    var axisGroup = new THREE.Group();
    tiltGroup.add(axisGroup);
    var axis = new THREE.Mesh(new THREE.CylinderGeometry(0.008, 0.008, 2.5, 8), new THREE.MeshBasicMaterial({ color: 0xdfe6ee }));
    axisGroup.add(axis);
    var poleN = makeLabel('北极 N', 'lbl-pole', axisGroup); poleN.position.set(0, 1.32, 0); poleN.userData.face = false;
    var poleS = makeLabel('南极 S', 'lbl-pole', axisGroup); poleS.position.set(0, -1.32, 0); poleS.userData.face = false;
    var axisLabel = makeLabel('地轴', 'lbl-axis', axisGroup); axisLabel.position.set(0, 1.2, 0); axisLabel.userData.face = false;

    var stand = new THREE.Group();
    scene.add(stand);
    var brass = new THREE.MeshLambertMaterial({ color: 0xb08d57 });
    // 子午环：经过两极，向下延伸到与立柱相接（倾斜后环的最低点在局部 −(90° + 倾角) 处）
    var ringGeo = new THREE.TorusGeometry(1.1, 0.016, 8, 160, (90 + TILT + 12 + 102) * DEG);
    ringGeo.rotateZ(-(90 + TILT + 12) * DEG);
    var ring = new THREE.Mesh(ringGeo, brass);
    tiltGroup.add(ring);
    var post = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.05, 0.42, 16), brass);
    post.position.y = -1.1 - 0.21;
    stand.add(post);
    var base = new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.5, 0.08, 40), new THREE.MeshLambertMaterial({ color: 0x5d4037 }));
    base.position.y = -1.56;
    stand.add(base);

    // ---------- 自转方向箭头（北极上空） ----------
    var spinArrow = new THREE.Group();
    tiltGroup.add(spinArrow);
    var arcGeo = new THREE.TorusGeometry(0.26, 0.011, 6, 48, Math.PI * 1.5);
    arcGeo.rotateX(-Math.PI / 2); // θ 增大即从北极上空看逆时针
    var arcMat = new THREE.MeshBasicMaterial({ color: 0x7ee081 });
    var arc = new THREE.Mesh(arcGeo, arcMat);
    arc.position.y = 1.14;
    spinArrow.add(arc);
    var head = new THREE.Mesh(new THREE.ConeGeometry(0.035, 0.09, 12), arcMat);
    var th = Math.PI * 1.5;
    head.position.set(0.26 * Math.cos(th), 1.14, -0.26 * Math.sin(th));
    head.quaternion.setFromUnitVectors(new V3(0, 1, 0), new V3(-Math.sin(th), 0, -Math.cos(th)));
    spinArrow.add(head);
    var spinLabel = makeLabel('自西向东', 'lbl-spin', spinArrow);
    spinLabel.position.set(0.34, 1.2, 0.1); spinLabel.userData.face = false;

    // ---------- 所选点：标记与所在纬线、经线 ----------
    var selLat = parallelTube(0, 1.005, 0.0065, C_LAT);
    var selLon = meridianTube(0, 1.005, 0.0065, C_LON);
    spinGroup.add(selLat); spinGroup.add(selLon);
    var markers = [];
    function makeMarker(color) {
      var m = new THREE.Mesh(new THREE.SphereGeometry(0.024, 16, 12), new THREE.MeshBasicMaterial({ color: color }));
      var rr = new THREE.Mesh(new THREE.RingGeometry(0.032, 0.044, 28), new THREE.MeshBasicMaterial({ color: 0xffffff, side: THREE.DoubleSide }));
      m.add(rr);
      m.userData.label = makeLabel('', 'lbl-mark', m);
      m.userData.label.userData.face = false;
      m.visible = false;
      spinGroup.add(m);
      markers.push(m);
      return m;
    }
    for (var mi = 0; mi < 3; mi++) makeMarker(0xffffff);

    // ---------- 相机 ----------
    var W = 1, H = 1, standOn = true, tiltNow = TILT, tiltTarget = TILT, first = true;
    function fitDistance() {
      var t = Math.tan(camera.fov / 2 * DEG);
      var needV = standOn ? 1.72 : 1.52, needH = 1.45;
      return Math.max(needV / t, needH / (t * camera.aspect)) * 1.04;
    }
    var viewAnim = null, spinAnim = null, viewName = 'front';
    // 正面：像转动真的地球仪一样，先把该点的经度转到正对相机（+z），相机仰角限制在 −15°~30°
    function frontDir(lat) {
      var p = lat * DEG, t = tiltTarget * DEG;
      var d = new V3(-Math.sin(t) * Math.sin(p), Math.cos(t) * Math.sin(p), Math.cos(p));
      var el = Math.max(-15, Math.min(30, Math.asin(d.y) / DEG)) * DEG, az = Math.atan2(d.x, d.z);
      return new V3(Math.cos(el) * Math.sin(az), Math.sin(el), Math.cos(el) * Math.cos(az));
    }
    function spinTo(lon, instant) {
      var target = (-90 - lon) * DEG, cur = spinGroup.rotation.y;
      var delta = ((target - cur) % (2 * Math.PI) + 3 * Math.PI) % (2 * Math.PI) - Math.PI;
      if (instant) { spinGroup.rotation.y = cur + delta; spinAnim = null; return; }
      spinAnim = { t: 0, from: cur, to: cur + delta };
    }
    function dirFor(name, lat) {
      if (name === 'north' || name === 'south') {
        var t = tiltTarget * DEG, ax = new V3(-Math.sin(t), Math.cos(t), 0);
        if (name === 'south') ax.negate();
        return ax.add(new V3(0, 0, 0.02)).normalize();
      }
      return frontDir(lat);
    }
    function animateTo(dir, dist) {
      viewAnim = { t: 0, from: camera.position.clone(), dir: dir, dist: dist || fitDistance() };
    }
    // focus 为 {lat, lon}：正面视角下把该点转到前方
    function setView(name, focus, instant) {
      viewName = name;
      var f = focus || { lat: 18, lon: 105 };
      if (name === 'front') spinTo(f.lon, instant);
      var d = dirFor(name, Math.max(-60, Math.min(60, f.lat))), dist = fitDistance();
      if (instant) { camera.position.copy(d.multiplyScalar(dist)); controls.target.set(0, 0, 0); camera.lookAt(0, 0, 0); return; }
      animateTo(d, dist);
    }
    controls.addEventListener('start', function () { viewAnim = null; camera.userData.touched = true; });
    function resize() {
      W = stage.clientWidth; H = stage.clientHeight;
      renderer.setSize(W, H);
      labelRenderer.setSize(W, H);
      camera.aspect = W / H;
      camera.updateProjectionMatrix();
      if (!camera.userData.touched) camera.position.setLength(fitDistance());
    }

    // ---------- 点选 ----------
    var raycaster = new THREE.Raycaster(), ndc = new THREE.Vector2();
    function pick(clientX, clientY) {
      var r = canvas.getBoundingClientRect();
      ndc.set((clientX - r.left) / r.width * 2 - 1, -(clientY - r.top) / r.height * 2 + 1);
      raycaster.setFromCamera(ndc, camera);
      var hit = raycaster.intersectObject(earth, false)[0];
      if (!hit) return null;
      var p = spinGroup.worldToLocal(hit.point.clone()).normalize();
      return { lat: Math.asin(Math.max(-1, Math.min(1, p.y))) / DEG, lon: Math.atan2(-p.z, p.x) / DEG };
    }

    // ---------- 每帧更新 ----------
    var tmp = new V3(), tmp2 = new V3(), camLocal = new V3();
    function faceOK(o) {
      o.getWorldPosition(tmp);
      tmp2.copy(camera.position).sub(tmp).normalize();
      return tmp.normalize().dot(tmp2) > 0.12;
    }

    function update(st, dt) {
      if (st.grid !== lastGrid) { buildGrid(st.grid); lastGrid = st.grid; }

      // 地轴倾斜（支架开关时平滑过渡）
      var want = tiltTarget = st.stand ? TILT : 0;
      if (first) { first = false; tiltNow = want; }
      tiltNow += (want - tiltNow) * Math.min(1, dt * 6);
      if (Math.abs(want - tiltNow) < 0.01) tiltNow = want;
      tiltGroup.rotation.z = tiltNow * DEG;
      if (standOn !== st.stand) { standOn = st.stand; if (!camera.userData.touched) camera.position.setLength(fitDistance()); }
      if (st.spin) { spinGroup.rotation.y += dt * 0.35; spinAnim = null; }
      if (spinAnim) {
        spinAnim.t = Math.min(1, spinAnim.t + dt / 0.8);
        spinGroup.rotation.y = spinAnim.from + (spinAnim.to - spinAnim.from) * (1 - Math.pow(1 - spinAnim.t, 3));
        if (spinAnim.t >= 1) spinAnim = null;
      }

      if (viewAnim) {
        viewAnim.t = Math.min(1, viewAnim.t + dt / 0.8);
        var k = 1 - Math.pow(1 - viewAnim.t, 3);
        var len = viewAnim.from.length() + (viewAnim.dist - viewAnim.from.length()) * k;
        tmp.copy(viewAnim.from).normalize().lerp(viewAnim.dir, k);
        if (tmp.lengthSq() < 1e-4) tmp.set(0, 0, 1);
        camera.position.copy(tmp.normalize().multiplyScalar(len));
        if (viewAnim.t >= 1) viewAnim = null;
      }
      controls.update();
      camLight.position.copy(camera.position);

      // 相机在 spinGroup 里的经纬度：标签沿正对相机的经线、纬线摆放
      spinGroup.updateMatrixWorld(true);
      camLocal.copy(camera.position);
      spinGroup.worldToLocal(camLocal);
      var camLon = Math.atan2(-camLocal.z, camLocal.x) / DEG;
      var camLat = Math.asin(Math.max(-1, Math.min(1, camLocal.y / camLocal.length()))) / DEG;
      var polar = Math.abs(camLat) > 55;
      stand.visible = st.stand && Math.abs(camLat) < 70;   // 俯视时支架和子午环挡住极点，隐藏
      ring.visible = st.stand && Math.abs(camLat) < 60;

      grid.visible = st.show.grid;
      latLabels.forEach(function (o) {
        o.position.copy(ll(o.userData.lat, camLon + (polar ? 32 : -22), 1.03));
        o.userData.want = st.show.grid && st.show.nums && (!polar || o.userData.lat * camLat > 0 && Math.abs(o.userData.lat) > 25);
      });
      var lonLat = polar ? (camLat > 0 ? 22 : -22) : Math.max(-35, Math.min(35, camLat - 14));
      lonLabels.forEach(function (o) {
        o.position.copy(ll(lonLat, o.userData.lon, 1.03));
        // 正面视角下避开纬度标签所在的那条经线
        o.userData.want = st.show.grid && st.show.nums && (polar || Math.abs(G.dLon(camLon - 22, o.userData.lon)) > 8);
      });

      special.visible = st.show.special;
      specialLabels.forEach(function (o) {
        o.position.copy(ll(o.userData.lat, camLon + (polar ? -32 : 28), 1.035));
        o.userData.want = st.show.special && st.show.names && (!polar || o.userData.lat * camLat >= 0);
      });
      pmLabel.position.copy(ll(polar ? (camLat > 0 ? 30 : -30) : Math.max(-40, Math.min(40, camLat + 30)), 0, 1.035));
      antiLabel.position.copy(ll(polar ? (camLat > 0 ? 30 : -30) : Math.max(-40, Math.min(40, camLat - 30)), 180, 1.035));
      pmLabel.userData.want = antiLabel.userData.want = st.show.special && st.show.names;

      // 半球
      var hm = st.hemi === 'ew' ? 1 : st.hemi === 'ns' ? 2 : 0;
      hemiShell.visible = hm > 0;
      hemiUniforms.mode.value = hm;
      ewRing.visible = hm === 1;
      var hl = polar ? (camLat > 0 ? 40 : -40) : 20;
      hemiLabels.E.position.copy(ll(hl, 70, 1.05));
      hemiLabels.W.position.copy(ll(hl, -110, 1.05));
      hemiLabels.N.position.copy(ll(45, camLon - 8, 1.05));
      hemiLabels.S.position.copy(ll(-45, camLon - 8, 1.05));
      hemiLabels.E.userData.want = hemiLabels.W.userData.want = hm === 1;
      hemiLabels.N.userData.want = hemiLabels.S.userData.want = hm === 2;
      ewLabels[0].position.copy(ll(polar ? (camLat > 0 ? 25 : -25) : Math.max(-45, Math.min(45, camLat + 34)), -20, 1.04));
      ewLabels[1].position.copy(ll(polar ? (camLat > 0 ? 25 : -25) : Math.max(-45, Math.min(45, camLat + 34)), 160, 1.04));
      ewLabels[0].userData.want = ewLabels[1].userData.want = hm === 1 && st.show.names;

      axisGroup.visible = st.show.axis;
      poleN.userData.want = st.show.axis && !(polar && camLat < 0);
      poleS.userData.want = st.show.axis && !(polar && camLat > 0);
      axisLabel.userData.want = st.show.axis && st.show.names && !polar;
      spinArrow.visible = st.show.spinDir;
      spinLabel.userData.want = st.show.spinDir;

      // 标记点
      var ms = st.marks || [];
      markers.forEach(function (m, i) {
        var d = ms[i];
        m.visible = !!d;
        m.userData.label.userData.want = !!d;
        if (!d) return;
        m.position.copy(ll(d.lat, d.lon, 1.012));
        m.lookAt(ll(d.lat, d.lon, 2).applyMatrix4(spinGroup.matrixWorld));
        m.material.color.set(d.color);
        if (m.userData.html !== d.label) { m.userData.label.element.innerHTML = d.label; m.userData.html = d.label; }
        m.userData.label.element.style.color = d.color;
        m.userData.label.userData.want = faceOK(m);
      });
      var sp = st.sel;
      selLat.visible = selLon.visible = !!sp && st.show.selLines;
      if (sp) {
        selLat.userData.setLat(sp.lat);
        selLat.visible = selLat.visible && Math.abs(sp.lat) < 89.5;
        selLon.rotation.y = sp.lon * DEG;
        selLon.visible = selLon.visible && Math.abs(sp.lat) < 89.5;
      }

      labels.forEach(function (o) {
        var on = o.userData.want && (!o.parent || o.parent.visible !== false) && (!o.userData.face || faceOK(o));
        if (on && !st.show.labels && o.element.className.indexOf('lbl-mark') < 0) on = false;
        o.visible = on;
      });

      renderer.render(scene, camera);
      labelRenderer.render(scene, camera);
    }

    new ResizeObserver(resize).observe(stage);
    resize();

    return {
      update: update, pick: pick, setView: setView, canvas: canvas, camera: camera, controls: controls,
      view: function () { return viewName; },
      setTilt: function (on) { tiltTarget = on ? TILT : 0; },
      focus: function (lat, lon, instant) {
        viewName = 'front';
        spinTo(lon, instant);
        var d = frontDir(Math.max(-60, Math.min(60, lat)));
        if (instant) { viewAnim = null; camera.position.copy(d.multiplyScalar(camera.position.length())); }
        else animateTo(d, camera.position.length());
      }
    };
  }

  window.LatLongScene = { create: create, ll: ll, TILT: TILT };
})();
