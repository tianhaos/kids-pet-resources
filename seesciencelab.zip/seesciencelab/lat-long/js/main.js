// 状态、面板与主循环
(function () {
  var G = window.Geo;
  var $ = function (id) { return document.getElementById(id); };
  var stage = $('stage'), panel = $('panel');
  var NAME = '经纬网与地球仪';
  var C_A = '#ffc94a', C_B = '#4fc3f7', C_OK = '#7ee081', C_BAD = '#ff6b5b';

  var state = {
    scene: 'explore',       // explore 认识地球仪 | quiz 练习
    grid: 15,               // 经纬网间隔（度）
    hemi: 'none',           // none | ew 东西半球 | ns 南北半球
    stand: true, spin: false,
    show: { grid: true, nums: true, special: true, names: true, axis: true, spinDir: false, selLines: true, labels: true },
    sel: { lat: 39.9, lon: 116.4, name: '北京' },
    marks: [],
    quiz: { only: '', q: null, done: false, ok: false, click: null, right: 0, total: 0 }
  };
  var exploreGrid = 15;

  // ---------- URL 参数 ----------
  var qs = new URLSearchParams(location.search);
  function placeByKey(k) { return G.PLACES.filter(function (p) { return p.key === k; })[0] || null; }
  if (qs.get('scene') === 'quiz') state.scene = 'quiz';
  if (G.QUIZ_TYPES.indexOf(qs.get('q')) >= 0) { state.scene = 'quiz'; state.quiz.only = qs.get('q'); }
  if (['10', '15', '30'].indexOf(qs.get('grid')) >= 0) exploreGrid = state.grid = Number(qs.get('grid'));
  if (['ew', 'ns', 'none'].indexOf(qs.get('hemi')) >= 0) state.hemi = qs.get('hemi');
  if (qs.get('stand') === '0') state.stand = false;
  if (qs.get('spin') === '1') { state.spin = true; state.show.spinDir = true; }
  ['grid', 'special', 'axis', 'labels'].forEach(function (k) {
    if (qs.get(k) === '0') state.show[k] = false;
  });
  if (placeByKey(qs.get('place'))) { var P0 = placeByKey(qs.get('place')); state.sel = { lat: P0.lat, lon: P0.lon, name: P0.name }; }
  if (qs.get('lat') != null && qs.get('lon') != null) {
    var la = Number(qs.get('lat')), lo = Number(qs.get('lon'));
    if (isFinite(la) && isFinite(lo)) state.sel = { lat: Math.max(-90, Math.min(90, la)), lon: G.normLon(lo) };
  }

  var view = window.LatLongScene.create(stage);
  view.setTilt(state.stand);
  var initView = qs.get('view');
  if (initView === 'north' || initView === 'south') view.setView(initView, null, true);
  else view.setView('front', state.scene === 'explore' ? state.sel : null, true);

  // ---------- 读数 ----------
  var cache = {};
  function setText(id, txt) { if (cache[id] !== txt) { cache[id] = txt; $(id).textContent = txt; } }
  function km(v) { return v >= 10000 ? (v / 10000).toFixed(2).replace(/\.?0+$/, '') + ' 万 km' : Math.round(v) + ' km'; }

  function updateReadouts() {
    var p = state.sel;
    if (!p) {
      ['rCoord', 'rCN', 'rHemi', 'rZone', 'rPar', 'rMer'].forEach(function (id) { setText(id, '—'); });
      setText('rName', '点击地球选一个点');
      return;
    }
    var pole = Math.abs(p.lat) > 89.95;
    setText('rName', p.name || '所选点');
    setText('rCoord', G.fmtPoint(p.lat, p.lon));
    setText('rCN', pole ? '纬度 90°，所有经线在此相交，没有经度' : G.fmtLatCN(p.lat) + '，' + G.fmtLonCN(p.lon));
    var h = G.hemiText(p.lat, p.lon);
    setText('rHemi', pole ? h.ns + '（极点）' : h.ew + ' · ' + h.ns);
    setText('rZone', G.latZone(p.lat) + ' · ' + G.heatZone(p.lat));
    if (pole) setText('rPar', '极点是一个点，纬线长度为 0');
    else if (Math.abs(p.lat) < 0.05) setText('rPar', '赤道，最长的纬线，约 ' + km(G.EQUATOR_KM) + '；经度 1° 约 ' + Math.round(G.lonDegKm(0)) + ' km');
    else setText('rPar', G.fmtLat(p.lat) + ' 纬线长约 ' + km(G.parallelKm(p.lat)) + '（赤道的 ' + Math.cos(p.lat * G.DEG).toFixed(2) + ' 倍）；经度 1° 约 ' + Math.round(G.lonDegKm(p.lat)) + ' km');
    setText('rMer', pole ? '所有经线都交于极点' : G.fmtLon(p.lon) + ' 经线长约 2 万 km，与所有经线等长；纬度 1° 约 111 km');
  }

  // ---------- 场景 ----------
  function setScene(s) {
    state.scene = s;
    document.querySelectorAll('[data-scene]').forEach(function (b) { b.classList.toggle('on', b.dataset.scene === s); });
    document.querySelectorAll('.only-explore').forEach(function (el) { el.hidden = s !== 'explore'; });
    document.querySelectorAll('.only-quiz').forEach(function (el) { el.hidden = s !== 'quiz'; });
    $('quizCard').hidden = s !== 'quiz';
    if (s === 'quiz') {
      state.grid = 10;
      state.hemi = 'none';
      state.show.grid = state.show.nums = true;
      if (!state.quiz.q) nextQuestion(!booted);
      $('hint').textContent = '拖动旋转地球 · 滚轮缩放 · 每格 10°';
    } else {
      state.grid = exploreGrid;
      if (!state.sel) state.sel = { lat: 39.9, lon: 116.4, name: '北京' };
      syncSel();
      $('hint').textContent = '拖动旋转地球 · 滚轮缩放 · 点击地球选一个点，读它的经纬度';
    }
    syncControls();
  }
  document.querySelectorAll('[data-scene]').forEach(function (b) {
    b.addEventListener('click', function () {
      setScene(b.dataset.scene);
      Analytics.track(NAME, '切换场景', b.dataset.scene);
    });
  });

  // ---------- 认识地球仪：选点 ----------
  var latS = $('latSlider'), lonS = $('lonSlider'), sliderActive = false;
  function setSel(p, focus) {
    state.sel = p;
    if (focus) view.focus(p.lat, p.lon);
    syncSel();
  }
  function syncSel() {
    var p = state.sel;
    if (!p) return;
    if (!sliderActive) { latS.value = String(Math.round(p.lat)); lonS.value = String(Math.round(p.lon)); }
    $('latOut').textContent = G.fmtLat(Number(latS.value));
    $('lonOut').textContent = G.fmtLon(Number(lonS.value));
    var key = (G.PLACES.filter(function (x) { return x.name === p.name; })[0] || {}).key;
    $('placeSel').value = key || 'custom';
  }
  [latS, lonS].forEach(function (el) {
    el.addEventListener('pointerdown', function () { sliderActive = true; });
    el.addEventListener('input', function () {
      setSel({ lat: Number(latS.value), lon: G.normLon(Number(lonS.value)) }, true);
    });
    el.addEventListener('change', function () { Analytics.track(NAME, '拖动经纬度', el.id); });
  });
  window.addEventListener('pointerup', function () { sliderActive = false; });

  var sel = $('placeSel');
  G.PLACES.forEach(function (p) {
    var o = document.createElement('option');
    o.value = p.key;
    o.textContent = p.name + '　' + G.fmtPoint(p.lat, p.lon).replace(/[()]/g, '');
    sel.appendChild(o);
  });
  var oc = document.createElement('option');
  oc.value = 'custom'; oc.textContent = '（在地球上点选 / 拖动滑块）';
  sel.appendChild(oc);
  sel.addEventListener('change', function () {
    var P = placeByKey(sel.value);
    if (!P) return;
    setSel({ lat: P.lat, lon: P.lon, name: P.name }, true);
    if (Math.abs(P.lat) > 89) view.setView(P.lat > 0 ? 'north' : 'south');
    Analytics.track(NAME, '选择地点', sel.value);
  });

  // 点击地球（拖动视角不算点击）
  var down = null;
  view.canvas.addEventListener('pointerdown', function (e) { down = { x: e.clientX, y: e.clientY }; });
  view.canvas.addEventListener('pointerup', function (e) {
    if (!down || Math.hypot(e.clientX - down.x, e.clientY - down.y) > 6) { down = null; return; }
    down = null;
    var hit = view.pick(e.clientX, e.clientY);
    if (!hit) return;
    if (state.scene === 'explore') {
      setSel({ lat: Math.round(hit.lat * 10) / 10, lon: Math.round(hit.lon * 10) / 10 });
      Analytics.track(NAME, '点选地点');
    } else if (state.quiz.q && state.quiz.q.type === 'find' && !state.quiz.done) {
      answerFind(hit);
    }
  });

  // ---------- 练习 ----------
  var TYPE_NAME = { read: '读经纬度', find: '找位置', hemi: '判断半球', dir: '判断方向' };
  function nextQuestion(instant) {
    var Q = state.quiz;
    Q.q = G.quiz(Math.random, Q.only);
    Q.done = false; Q.ok = false; Q.click = null;
    state.sel = null;
    var q = Q.q;
    $('qType').textContent = TYPE_NAME[q.type];
    $('qPrompt').textContent = q.prompt;
    var box = $('qOpts');
    box.innerHTML = '';
    if (q.options) {
      q.options.forEach(function (opt) {
        var b = document.createElement('button');
        b.className = 'opt';
        b.textContent = opt;
        b.addEventListener('click', function () { answerOption(opt, b); });
        box.appendChild(b);
      });
    } else {
      box.innerHTML = '<p class="note">在地球上点一下作答（误差 ' + G.TOL + '° 以内算对）。</p>';
    }
    $('qFeedback').hidden = true;
    $('qNext').hidden = true;
    if (q.type === 'dir') {
      var mid = { lat: (q.a.lat + q.b.lat) / 2, lon: q.a.lon + G.dLon(q.a.lon, q.b.lon) / 2 };
      view.focus(mid.lat, mid.lon, instant);
    } else if (q.type !== 'find') view.focus(q.a.lat, q.a.lon, instant);
  }
  function finish(ok, text) {
    var Q = state.quiz;
    Q.done = true; Q.ok = ok;
    Q.total++; if (ok) Q.right++;
    var fb = $('qFeedback');
    fb.hidden = false;
    fb.className = 'feedback ' + (ok ? 'ok' : 'bad');
    fb.innerHTML = '<b>' + (ok ? '✓ 正确' : '✗ 不对') + '</b>' + (text ? text + ' ' : '') + Q.q.explain;
    $('qNext').hidden = false;
    $('score').textContent = Q.right + ' / ' + Q.total;
    if (Q.q.type !== 'dir') state.sel = { lat: Q.q.a.lat, lon: Q.q.a.lon };
    Analytics.track(NAME, '练习作答', Q.q.type + (ok ? '·对' : '·错'));
  }
  function answerOption(opt, btn) {
    var Q = state.quiz;
    if (Q.done) return;
    var ok = opt === Q.q.answer;
    document.querySelectorAll('#qOpts .opt').forEach(function (b) {
      if (b.textContent === Q.q.answer) b.classList.add('right');
      b.disabled = true;
    });
    if (!ok) btn.classList.add('wrong');
    finish(ok, ok ? '' : '正确答案：' + Q.q.answer + '。');
  }
  function answerFind(hit) {
    var Q = state.quiz;
    Q.click = { lat: hit.lat, lon: hit.lon };
    var ok = G.checkFind(Q.q, hit.lat, hit.lon);
    finish(ok, '你点的是 ' + G.fmtPoint(Math.round(hit.lat), Math.round(hit.lon)) + '。');
  }
  $('qNext').addEventListener('click', function () { nextQuestion(); });
  document.querySelectorAll('[data-qtype]').forEach(function (b) {
    b.addEventListener('click', function () {
      state.quiz.only = b.dataset.qtype;
      syncControls();
      nextQuestion();
      Analytics.track(NAME, '练习题型', b.dataset.qtype || 'mix');
    });
  });

  function computeMarks() {
    var m = [];
    if (state.scene === 'explore') {
      var p = state.sel;
      if (p) m.push({ lat: p.lat, lon: p.lon, color: C_A, label: (p.name ? p.name + ' ' : '') + G.fmtPoint(p.lat, p.lon) });
    } else {
      var Q = state.quiz, q = Q.q;
      if (!q) return m;
      if (q.type === 'find') {
        if (Q.click) m.push({ lat: Q.click.lat, lon: Q.click.lon, color: Q.ok ? C_OK : C_BAD, label: '你点的' });
        if (Q.done && !Q.ok) m.push({ lat: q.a.lat, lon: q.a.lon, color: C_OK, label: '正确位置 ' + G.fmtPoint(q.a.lat, q.a.lon) });
      } else {
        m.push({ lat: q.a.lat, lon: q.a.lon, color: C_A, label: 'A' + (Q.done && q.type === 'read' ? ' ' + G.fmtPoint(q.a.lat, q.a.lon) : '') });
        if (q.b) m.push({ lat: q.b.lat, lon: q.b.lon, color: C_B, label: 'B' });
      }
    }
    return m;
  }

  // ---------- 视角、显示 ----------
  document.querySelectorAll('[data-view]').forEach(function (b) {
    b.addEventListener('click', function () {
      view.setView(b.dataset.view, b.dataset.view === 'front' ? (state.sel || state.quiz.q && state.quiz.q.a) : null);
      Analytics.track(NAME, '切换视角', b.dataset.view);
    });
  });
  document.querySelectorAll('[data-hemi]').forEach(function (b) {
    b.addEventListener('click', function () {
      state.hemi = b.dataset.hemi;
      if (state.hemi === 'ew' && view.view() !== 'front') view.setView('front', { lat: 15, lon: -20 });
      syncControls();
      Analytics.track(NAME, '半球划分', state.hemi);
    });
  });
  document.querySelectorAll('[data-grid]').forEach(function (b) {
    b.addEventListener('click', function () {
      exploreGrid = state.grid = Number(b.dataset.grid);
      syncControls();
    });
  });
  Object.keys(state.show).forEach(function (k) {
    var el = $('show-' + k);
    if (!el) return;
    el.checked = state.show[k];
    el.addEventListener('change', function () { state.show[k] = el.checked; });
  });
  $('standOn').addEventListener('change', function () { state.stand = $('standOn').checked; });
  $('spinOn').addEventListener('change', function () {
    state.spin = $('spinOn').checked;
    if (state.spin) { state.show.spinDir = true; $('show-spinDir').checked = true; Analytics.track(NAME, '地球自转'); }
  });

  function syncControls() {
    document.querySelectorAll('[data-hemi]').forEach(function (b) { b.classList.toggle('on', b.dataset.hemi === state.hemi); });
    document.querySelectorAll('[data-grid]').forEach(function (b) { b.classList.toggle('on', Number(b.dataset.grid) === state.grid); });
    document.querySelectorAll('[data-qtype]').forEach(function (b) { b.classList.toggle('on', b.dataset.qtype === state.quiz.only); });
    $('standOn').checked = state.stand;
    $('spinOn').checked = state.spin;
    Object.keys(state.show).forEach(function (k) { var el = $('show-' + k); if (el) el.checked = state.show[k]; });
    var hn = { none: '', ew: '东西半球以 20°W 和 160°E 组成的经线圈为界（不是 0° 和 180°），这样划分不会把欧洲、非洲的国家分在两个半球。橙色为东半球，蓝色为西半球。',
      ns: '南北半球以赤道为界：赤道以北是北半球（北纬），以南是南半球（南纬）。' };
    $('hemiNote').textContent = hn[state.hemi];
    $('hemiNote').hidden = !hn[state.hemi];
  }

  $('panelToggle').addEventListener('click', function () { panel.classList.toggle('collapsed'); });
  if (window.matchMedia('(max-width: 760px)').matches) panel.classList.add('collapsed');

  window.addEventListener('keydown', function (e) {
    var t = e.target.tagName;
    if (t === 'INPUT' || t === 'SELECT' || t === 'BUTTON' || t === 'TEXTAREA') return;
    if (e.code === 'Space') { e.preventDefault(); state.spin = !state.spin; if (state.spin) state.show.spinDir = true; syncControls(); }
    else if (e.code === 'KeyN' && state.scene === 'quiz') nextQuestion();
    else if (e.code === 'KeyR' && !e.metaKey && !e.ctrlKey) view.setView('front', state.sel);
  });

  // ---------- 初始化 ----------
  var booted = false;
  setScene(state.scene);
  syncSel();
  booted = true;

  // ---------- 主循环 ----------
  var last = performance.now();
  function frame(t) {
    var dt = Math.max(0, Math.min((t - last) / 1000, 0.1));
    last = t;
    state.marks = computeMarks();
    view.update(state, dt);
    if (state.scene === 'explore') updateReadouts();
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // 调试用
  window.__model = {
    state: state, view: view, setScene: setScene, nextQuestion: nextQuestion,
    setPoint: function (lat, lon) { setSel({ lat: lat, lon: G.normLon(lon) }, true); }
  };
})();
