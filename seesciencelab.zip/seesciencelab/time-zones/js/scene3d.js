/* global THREE, TimeZones, makeEarthCanvas */
// 地球坐标与共享贴图一致。屏幕标记投影到 HTML 层，保留清晰的原生文字。
(function () {
  'use strict';
  const T = THREE, Z = TimeZones;
  const radians = Math.PI / 180;
  const dated = 0xff7d86, meridian = 0x9bbddc, gold = 0xffca58;
  const point = (lat, lon, r = 1) => {
    const phi = lat * radians, theta = lon * radians;
    return new T.Vector3(r * Math.cos(phi) * Math.cos(theta), r * Math.sin(phi), -r * Math.cos(phi) * Math.sin(theta));
  };

  function create(host) {
    const scene = new T.Scene();
    const renderer = new T.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    host.prepend(renderer.domElement);
    const canvas = renderer.domElement;
    const camera = new T.PerspectiveCamera(34, 1, 0.05, 20);
    camera.position.copy(point(15, 119, 4.08));
    const controls = new T.OrbitControls(camera, canvas);
    controls.enablePan = false;
    controls.minDistance = 2.38;
    controls.maxDistance = 9;
    controls.enableDamping = true;
    controls.rotateSpeed = 0.58;
    controls.zoomSpeed = 0.75;

    const sphere = new T.SphereGeometry(1, 96, 64);
    const map = new T.CanvasTexture(makeEarthCanvas());
    map.anisotropy = Math.min(8, renderer.capabilities.getMaxAnisotropy());
    const earth = new T.Mesh(sphere, new T.ShaderMaterial({
      uniforms: {
        map: { value: map },
        sun: { value: point(0, 0) },
        selected: { value: 8 },
        bands: { value: true }
      },
      vertexShader: `
        varying vec2 tex;
        varying vec3 surface;
        void main() {
          tex = uv;
          surface = position;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }`,
      fragmentShader: `
        uniform sampler2D map;
        uniform vec3 sun;
        uniform float selected;
        uniform bool bands;
        varying vec2 tex;
        varying vec3 surface;
        void main() {
          vec3 n = normalize(surface);
          float lon = tex.x * 360.0 - 180.0;
          float zone = floor((lon + 7.5) / 15.0);
          vec3 albedo = texture2D(map, tex).rgb;
          albedo = mix(albedo, vec3(albedo.r * .83, albedo.g * .95, albedo.b * 1.13), .40);
          float grid = 1.0 - smoothstep(.015, .10, abs(fract(lon / 15.0) - .5));
          float polar = smoothstep(.06, .33, length(n.xz));
          if (bands) {
            float shade = mod(zone, 2.0);
            albedo *= mix(.82, 1.02, shade);
            albedo = mix(albedo, vec3(.78, .89, .98), grid * polar * .11);
            if (abs(zone - selected) < .1) {
              albedo = mix(albedo, vec3(.94, .63, .22), .39 + grid * polar * .38);
            }
          }
          float sunlight = dot(n, sun);
          float day = smoothstep(-.13, .15, sunlight);
          vec3 base = mix(albedo * vec3(.27, .41, .66), albedo * (.71 + .29 * max(0.0, sunlight)), day);
          vec3 eye = normalize(cameraPosition - surface);
          float rim = pow(1.0 - max(0.0, dot(n, eye)), 3.2);
          base = mix(base, vec3(.31, .66, .91), rim * (.28 + .24 * day));
          gl_FragColor = vec4(base, 1.0);
        }`
    }));
    scene.add(earth);

    function curve(points, color, opacity, thickness) {
      if (thickness) {
        const geometry = new T.TubeGeometry(new T.CatmullRomCurve3(points), points.length * 2, thickness, 6, false);
        const mesh = new T.Mesh(geometry, new T.MeshBasicMaterial({ color, transparent: true, opacity }));
        scene.add(mesh);
        return mesh;
      }
      const line = new T.Line(new T.BufferGeometry().setFromPoints(points),
        new T.LineBasicMaterial({ color, transparent: true, opacity }));
      scene.add(line);
      return line;
    }

    const arc = (lon, from = -88, to = 88) =>
      Array.from({ length: 61 }, (_, i) => point(from + (to - from) * i / 60, lon, 1.007));
    curve(arc(180), dated, 0.88, 0.0047);
    curve(arc(0), meridian, 0.75, 0.0028);
    const path = Array.from({ length: 31 }, (_, i) => point(Z.LAT, Z.WEST + (Z.EAST - Z.WEST) * i / 30, 1.023));
    const track = curve(path, gold, 0.9, 0.005);
    const endGeometry = new T.SphereGeometry(0.017, 16, 12);
    const endMaterial = new T.MeshBasicMaterial({ color: gold });
    const ends = [path[0], path[path.length - 1]].map(p => {
      const end = new T.Mesh(endGeometry, endMaterial);
      end.position.copy(p);
      scene.add(end);
      return end;
    });

    const pointer = new T.Vector2();
    const ray = new T.Raycaster();
    const probe = new T.Sphere(new T.Vector3(), 1);
    const hit = new T.Vector3();
    const projected = new T.Vector3();
    let width = 1, height = 1;
    new ResizeObserver(() => {
      width = host.clientWidth || 1;
      height = host.clientHeight || 1;
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      renderer.setSize(width, height);
    }).observe(host);

    function focus(lat, lon, close = false) {
      const aspect = host.clientWidth / Math.max(host.clientHeight, 1);
      const widthScale = close ? 1.28 : 0.94;
      const fitDistance = Math.hypot(1, 1 / (Math.tan(17 * radians) * widthScale * aspect));
      camera.position.copy(point(lat, lon, Math.max(close ? 3.53 : 3.97, fitDistance)));
      controls.update();
    }

    function pick(clientX, clientY) {
      const rect = canvas.getBoundingClientRect();
      pointer.set((clientX - rect.left) / rect.width * 2 - 1, 1 - (clientY - rect.top) / rect.height * 2);
      ray.setFromCamera(pointer, camera);
      if (!ray.ray.intersectSphere(probe, hit)) return null;
      return { lat: Math.asin(hit.y) / radians, lon: Math.atan2(-hit.z, hit.x) / radians };
    }

    function locate(element, lat, lon, scale = 1.012) {
      const surface = point(lat, lon, scale);
      const facing = surface.dot(camera.position) > 1.06;
      projected.copy(surface).project(camera);
      const x = (projected.x + 1) * width / 2, y = (1 - projected.y) * height / 2;
      const inside = facing && x >= 18 && x <= width - 18 && y >= 15 && y <= height - 15;
      element.hidden = !inside;
      if (inside) {
        const half = element.offsetWidth / 2;
        element.style.left = `${Math.max(half + 3, Math.min(width - half - 3, x))}px`;
        element.style.top = `${y}px`;
      }
      return inside;
    }

    function render(state) {
      controls.update();
      const crossing = state.scene === 'crossing';
      track.visible = crossing;
      ends.forEach(end => { end.visible = crossing; });
      const uniforms = earth.material.uniforms;
      uniforms.sun.value.copy(point(0, Z.sunLon(state.minute)));
      uniforms.bands.value = state.bands;
      uniforms.selected.value = crossing ? Z.flightOffset(state.flightLon) : Z.zone(state.place.lon);
      renderer.render(scene, camera);
    }

    return { canvas, controls, focus, pick, locate, render };
  }

  window.TimeZoneScene = { create };
})();
