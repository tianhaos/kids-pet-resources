// 理想时区与日期。时间用距示例 UTC 零点的分钟数表示。
(function () {
  'use strict';
  const DAY = 1440;
  const WEST = 173, EAST = 187, LAT = 28;
  const PLACES = [
    { id: 'beijing', name: '北京', lat: 39.9, lon: 116.4 },
    { id: 'tokyo', name: '东京', lat: 35.7, lon: 139.7 },
    { id: 'sydney', name: '悉尼', lat: -33.9, lon: 151.2 },
    { id: 'london', name: '伦敦', lat: 51.5, lon: 0 },
    { id: 'newyork', name: '纽约', lat: 40.7, lon: -74 },
    { id: 'delhi', name: '新德里', lat: 28.6, lon: 77.2 }
  ];
  const mod = (n, d) => ((n % d) + d) % d;
  const wrap = lon => mod(lon + 180, 360) - 180;
  const zone = lon => Math.floor((wrap(lon) + 7.5) / 15);
  const date = minute => {
    const d = new Date(Date.UTC(2026, 10, 20) + Math.floor(minute) * 60000);
    const pad = n => String(n).padStart(2, '0');
    return {
      day: `${d.getUTCMonth() + 1}月${d.getUTCDate()}日`,
      clock: `${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}`
    };
  };
  const time = (minute, offset) => date(minute + offset * 60);
  const solarTime = (minute, lon) => date(minute + wrap(lon) * 4);
  const sunLon = minute => wrap(180 - minute / 4);
  const offsetText = offset => `UTC${offset < 0 ? '−' : '+'}${Math.abs(offset)}`;
  const zoneName = offset => offset === 0 ? '中时区' : `${offset < 0 ? '西' : '东'}${Math.abs(offset)}区`;
  const flightOffset = lon => lon < 180 ? 12 : -12;
  window.TimeZones = {
    DAY, WEST, EAST, LAT, PLACES, mod, wrap, zone, date, time, solarTime,
    sunLon, offsetText, zoneName, flightOffset
  };
})();
