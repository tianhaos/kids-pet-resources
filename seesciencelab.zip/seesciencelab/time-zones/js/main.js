/* global TimeZones, TimeZoneScene, Analytics */
(function () {
  'use strict';
  const Z = TimeZones;
  const $ = id => document.getElementById(id);
  const query = new URLSearchParams(location.search);
  const clamp = (value, min, max) => Math.min(max, Math.max(min, value));
  const initialScene = query.get('scene') === 'crossing' ? 'crossing' : 'zones';
  const hasUTC = /^\d{1,4}$/.test(query.get('utc') || '');
  const limit = 2 * Z.DAY - 1;
  const state = {
    scene: initialScene,
    minute: hasUTC ? clamp(Number(query.get('utc')), 0, limit) : initialScene === 'crossing' ? 1320 : 390,
    place: Z.PLACES.find(place => place.id === query.get('place')) || Z.PLACES[0],
    bands: true,
    playing: false,
    flightLon: query.get('dir') === 'west' ? Z.EAST : Z.WEST,
    direction: query.get('dir') === 'west' ? -1 : 1,
    flying: false
  };
  const track = (action, label) => window.Analytics?.track('时区与日期变更线', action, label);
  const host = $('globe');
  let view;
  try {
    view = TimeZoneScene.create(host);
  } catch (error) {
    host.classList.add('fallback');
    $('globeHelp').textContent = '当前浏览器无法显示 3D 地球，仍可用滑块比较时区与日期。';
  }

  const placeList = $('places');
  for (const place of Z.PLACES) placeList.add(new Option(place.name, place.id));
  const utc = $('utcSlider'), route = $('routeSlider');
  const utcPlay = $('utcPlay'), flightPlay = $('flightPlay');
  const zoneButtons = [...document.querySelectorAll('[data-scene]')];
  const directionButtons = [...document.querySelectorAll('[data-direction]')];
  const stage = $('stage');
  let previous = 0, lastReadout = '';

  function fillClock(id, name, offset, time) {
    const card = $(id);
    card.querySelector('.clock-name').textContent = name;
    card.querySelector('.clock-zone').textContent = Z.offsetText(offset);
    card.querySelector('.clock-hour').textContent = time.clock;
    card.querySelector('.clock-day').textContent = time.day;
  }

  function updateReadouts() {
    const crossing = state.scene === 'crossing';
    const position = crossing ? state.flightLon.toFixed(1) : '';
    const flightOffset = crossing ? Z.flightOffset(state.flightLon) : 0;
    const key = [state.scene, Math.floor(state.minute), state.place.name, state.place.lon,
      position, flightOffset, state.direction, state.playing, state.flying, state.bands].join('|');
    if (key === lastReadout) return;
    lastReadout = key;
    const utcDate = Z.date(state.minute);
    const offset = Z.zone(state.place.lon);
    const local = Z.time(state.minute, offset);
    const solar = Z.solarTime(state.minute, state.place.lon);
    $('utcNow').textContent = `${utcDate.day} ${utcDate.clock}`;
    $('globeHelp').textContent = !view ? '当前浏览器无法显示 3D 地球，仍可用滑块比较时区与日期。'
      : crossing ? '拖飞机跨线 · 拖空白旋转 · 双指或滚轮缩放'
        : '点地球选时区 · 拖动旋转 · 双指或滚轮缩放';
    stage.dataset.scene = state.scene;
    $('stageTitle').textContent = crossing ? '跨越日期变更线' : '同一瞬间，各地几点？';
    $('zonePanel').hidden = crossing;
    $('flightPanel').hidden = !crossing;
    $('routeControls').hidden = !crossing;
    utc.value = Math.floor(state.minute);
    utc.setAttribute('aria-valuetext', `UTC ${utcDate.day} ${utcDate.clock}`);
    utcPlay.textContent = state.playing ? '暂停' : '播放';
    utcPlay.setAttribute('aria-label', state.playing ? '暂停 UTC 播放' : '播放 UTC 时间');
    utcPlay.setAttribute('aria-pressed', String(state.playing));
    for (const button of zoneButtons) {
      const on = button.dataset.scene === state.scene;
      button.classList.toggle('on', on);
      button.setAttribute('aria-pressed', String(on));
    }
    if (!crossing) {
      const lon = Math.abs(state.place.lon).toFixed(1);
      const lonText = state.place.lon === 0 ? '0°' : `${lon}°${state.place.lon < 0 ? 'W' : 'E'}`;
      fillClock('clockA', '中时区', 0, utcDate);
      fillClock('clockB', state.place.name, offset, local);
      $('clockA').classList.remove('active-side');
      $('clockB').classList.remove('active-side');
      $('clockBridge').textContent = offset === 0 ? '等时' : offset > 0 ? `＋${offset} 小时` : `−${-offset} 小时`;
      $('placeCoord').textContent = `${lonText} · ${Z.zoneName(offset)}`;
      $('solarClock').textContent = `${solar.day} ${solar.clock}`;
      $('zoneClock').textContent = `${local.day} ${local.clock}`;
      $('placeMarker').textContent = state.place.name;
      placeList.value = state.place.id;
      return;
    }

    const west = Z.time(state.minute, 12), east = Z.time(state.minute, -12);
    const eastbound = state.direction === 1;
    const crossed = eastbound ? flightOffset === -12 : flightOffset === 12;
    const here = flightOffset === 12 ? west : east;
    fillClock('clockA', '日界线西侧', 12, west);
    fillClock('clockB', '日界线东侧', -12, east);
    $('clockA').classList.toggle('active-side', flightOffset === 12);
    $('clockB').classList.toggle('active-side', flightOffset === -12);
    $('clockBridge').textContent = '相差一天';
    route.value = state.flightLon;
    route.setAttribute('aria-valuetext', `${flightOffset === 12 ? '西侧' : '东侧'}，${here.day} ${here.clock}`);
    $('flightStatus').textContent = `${eastbound ? '向东' : '向西'}${crossed ? '已跨线' : '待跨线'} · 日期${eastbound ? '减' : '加'}一天`;
    $('flightDate').textContent = `${here.day} ${here.clock}`;
    $('plane').classList.toggle('westbound', !eastbound);
    flightPlay.textContent = state.flying ? '暂停飞行' : '演示飞越';
    flightPlay.setAttribute('aria-pressed', String(state.flying));
    for (const button of directionButtons) {
      const on = Number(button.dataset.direction) === state.direction;
      button.classList.toggle('on', on);
      button.setAttribute('aria-pressed', String(on));
    }
  }

  function focus() {
    if (state.scene === 'crossing') view?.focus(9, 180, true);
    else view?.focus(clamp(state.place.lat * 0.45, -14, 25), state.place.lon + 3);
  }

  function setScene(scene) {
    if (state.scene === scene) return;
    state.scene = scene;
    state.flying = false;
    state.playing = false;
    updateReadouts();
    focus();
    track('切换场景', scene);
  }

  function selectPlace(place, recenter) {
    state.place = place;
    if (recenter) focus();
    track('选择地点', place.id || String(Z.zone(place.lon)));
  }

  function setFlight(lon, inferDirection) {
    const next = clamp(lon, Z.WEST, Z.EAST);
    if (inferDirection && Math.abs(next - state.flightLon) > 0.002) {
      state.direction = next > state.flightLon ? 1 : -1;
    }
    state.flightLon = next;
  }

  utc.addEventListener('input', () => {
    state.playing = false;
    state.minute = Number(utc.value);
  });
  utc.addEventListener('change', () => track('调整UTC', '时间滑块'));
  utcPlay.addEventListener('click', () => {
    if (state.minute >= limit) state.minute = 0;
    state.playing = !state.playing;
    if (state.playing) state.flying = false;
    if (state.playing) track('播放', 'UTC');
  });
  route.addEventListener('input', () => {
    state.flying = false;
    setFlight(Number(route.value), true);
  });
  route.addEventListener('change', () => track('拖动航线', state.direction > 0 ? '向东' : '向西'));
  flightPlay.addEventListener('click', () => {
    if (state.flying) {
      state.flying = false;
      return;
    }
    const end = state.direction > 0 ? Z.EAST : Z.WEST;
    if (state.flightLon === end) setFlight(state.direction > 0 ? Z.WEST : Z.EAST, false);
    state.flying = true;
    state.playing = false;
    track('演示飞越', state.direction > 0 ? '向东' : '向西');
  });
  for (const button of directionButtons) {
    button.addEventListener('click', () => {
      state.direction = Number(button.dataset.direction);
      state.flying = false;
      setFlight(state.direction > 0 ? Z.WEST : Z.EAST, false);
      track('选择飞行方向', button.textContent);
    });
  }
  for (const button of zoneButtons) button.addEventListener('click', () => setScene(button.dataset.scene));
  for (const button of document.querySelectorAll('[data-utc]')) {
    button.addEventListener('click', () => {
      state.playing = false;
      state.minute = Number(button.dataset.utc);
      track('选取UTC示例', button.textContent);
    });
  }
  placeList.addEventListener('change', () => {
    const place = Z.PLACES.find(item => item.id === placeList.value);
    if (place) selectPlace(place, true);
  });
  $('bands').addEventListener('change', event => { state.bands = event.target.checked; });
  $('resetView').addEventListener('click', focus);
  $('primeView').addEventListener('click', () => view?.focus(10, 0));
  $('dateView').addEventListener('click', () => view?.focus(9, 180));
  const panel = $('panel'), panelToggle = $('panelToggle');
  panelToggle.addEventListener('click', () => {
    const closed = panel.classList.toggle('collapsed');
    panelToggle.setAttribute('aria-expanded', String(!closed));
    panelToggle.textContent = closed ? '☰ 控制面板' : '收起面板 ↓';
  });

  if (view) {
    const canvas = view.canvas;
    let tap = null;
    canvas.addEventListener('pointerdown', event => {
      if (!event.isPrimary) {
        tap = null;
        return;
      }
      if (event.button === 0) tap = { id: event.pointerId, x: event.clientX, y: event.clientY };
    });
    canvas.addEventListener('pointermove', event => {
      if (tap && Math.hypot(event.clientX - tap.x, event.clientY - tap.y) > 7) tap = null;
      const canSelect = state.scene === 'zones' && !event.buttons && view.pick(event.clientX, event.clientY);
      canvas.classList.toggle('can-select', Boolean(canSelect));
    });
    canvas.addEventListener('pointercancel', () => { tap = null; });
    canvas.addEventListener('pointerup', event => {
      if (tap?.id === event.pointerId && state.scene === 'zones') {
        const location = view.pick(event.clientX, event.clientY);
        if (location) selectPlace({ ...location, id: '', name: '探测点' }, false);
      }
      tap = null;
    });
    const plane = $('plane');
    let dragging = null;
    plane.addEventListener('pointerdown', event => {
      if (!event.isPrimary || event.button !== 0) return;
      state.flying = false;
      dragging = event.pointerId;
      plane.setPointerCapture(dragging);
      plane.classList.add('dragging');
    });
    plane.addEventListener('pointermove', event => {
      if (event.pointerId !== dragging) return;
      const location = view.pick(event.clientX, event.clientY);
      if (location) setFlight(180 + Z.wrap(location.lon - 180), true);
    });
    plane.addEventListener('lostpointercapture', () => {
      dragging = null;
      plane.classList.remove('dragging');
      track('拖动飞机', state.direction > 0 ? '向东' : '向西');
    });
    plane.addEventListener('keydown', event => {
      if (!['ArrowLeft', 'ArrowRight'].includes(event.key)) return;
      event.preventDefault();
      state.flying = false;
      setFlight(state.flightLon + (event.key === 'ArrowRight' ? 1 : -1), true);
    });
  }

  function tick(now) {
    const elapsed = Math.min(0.05, (now - previous) / 1000);
    previous = now;
    if (state.playing) {
      state.minute = Math.min(limit, state.minute + elapsed * 100);
      if (state.minute === limit) state.playing = false;
    }
    if (state.flying) {
      setFlight(state.flightLon + elapsed * 3.5 * state.direction, false);
      if (state.flightLon === Z.EAST || state.flightLon === Z.WEST) state.flying = false;
    }
    updateReadouts();
    if (view) {
      view.render(state);
      const inFlight = state.scene === 'crossing';
      if (inFlight) {
        view.locate($('plane'), Z.LAT, state.flightLon, 1.05);
        $('placeMarker').hidden = true;
      } else {
        $('plane').hidden = true;
        view.locate($('placeMarker'), state.place.lat, state.place.lon);
      }
      view.locate($('lineMarker'), -28, 180);
      view.locate($('primeMarker'), -28, 0);
    }
    requestAnimationFrame(tick);
  }

  updateReadouts();
  focus();
  requestAnimationFrame(tick);
  window.__model = { state, setScene, setFlight, view };
})();
