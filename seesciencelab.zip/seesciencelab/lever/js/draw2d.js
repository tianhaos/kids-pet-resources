// 杠杆绘图：带刻度的杠杆（铁架台、平衡螺母、钩码、弹簧测力计、力臂标注）、撬棒的力臂作图、生活中的杠杆示意图
// 带刻度杠杆以格 g（px）为单位，支点在 (cx, cy)，ang > 0 为右端下沉；撬棒与工具用 cm 坐标（y 向上）缩放进画面
(function () {
  var V = window.Lever, TAU = Math.PI * 2;
  var C = { text: '#e6ebf2', muted: '#8d99ab', line: '#2a3446', accent: '#ffc94a', metal: '#cfd6e2', metal2: '#8e9aae',
    f1: '#ff7b6b', f2: '#4fc3f7', ok: '#7ee081', red: '#ff6b6b', wood: '#b9894f', rock: '#6f7787', ground: '#3a4456', hook: '#b4bccb' };
  var WH = 0.5, WW = 0.42, HOOK = 0.55;   // 钩码高、宽，挂钩长度（格）

  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }

  function LeverDraw(canvas) {
    var ctx = canvas.getContext('2d'), W = 0, H = 0, dpr = 1, L = {}, M = null;

    function resize(w, h) {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      W = w; H = h;
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
      canvas.style.width = w + 'px'; canvas.style.height = h + 'px';
      L.narrow = W <= 760; L.top = L.narrow ? 70 : 52; L.bottom = L.narrow ? 46 : 50;
    }
    function gridLayout(scene) {
      var up = scene === 'scale' ? 4.4 : 2.2, need = up + 7.6, avail = H - L.top - L.bottom;
      var g = Math.min((W - 24) / 16.2, avail / need, 80);
      L.g = g; L.cx = W / 2; L.cy = L.top + (avail - need * g) / 2 + up * g; L.baseY = L.cy + 6.9 * g;
      L.tray = { x: L.cx - 7.4 * g, y: L.baseY - 0.95 * g, w: 4.6 * g, h: 1.05 * g };
    }
    // 世界坐标（cm，y 向上）→ 画面
    function fit(box, area) {
      var s = Math.min(area[2] / (box[2] - box[0]), area[3] / (box[3] - box[1]));
      M = { s: s, ox: area[0] + (area[2] - s * (box[2] - box[0])) / 2 - box[0] * s, oy: area[1] + (area[3] + s * (box[3] - box[1])) / 2 + box[1] * s };
    }
    function P(p) { return [M.ox + p[0] * M.s, M.oy - p[1] * M.s]; }
    function unP(x, y) { return [(x - M.ox) / M.s, (M.oy - y) / M.s]; }

    function font(px, w) { ctx.font = (w || '') + ' ' + Math.round(px) + 'px -apple-system, "PingFang SC", "Microsoft YaHei", sans-serif'; }
    function text(s, x, y, col, align, px, w) {
      font(px, w); ctx.fillStyle = col; ctx.textAlign = align || 'center'; ctx.textBaseline = 'middle'; ctx.fillText(s, x, y);
    }
    function tag(s, x, y, col, px) {   // 带底色的标签
      font(px || 13, '600'); var w = ctx.measureText(s).width + 10, h = (px || 13) + 8;
      ctx.fillStyle = 'rgba(11,15,24,0.82)'; rrect(x - w / 2, y - h / 2, w, h, 5); ctx.fill();
      text(s, x, y, col, 'center', px || 13, '600');
    }
    function line(x1, y1, x2, y2) { ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke(); }
    function dash(x1, y1, x2, y2, col, w) { ctx.save(); ctx.setLineDash([6, 5]); ctx.strokeStyle = col; ctx.lineWidth = w || 1.2; line(x1, y1, x2, y2); ctx.restore(); }
    function rrect(x, y, w, h, r) {
      ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r);
      ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
    }
    function dot(x, y, r, col) { ctx.fillStyle = col; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill(); }
    function arrow(x1, y1, x2, y2, col, w, hd) {
      var a = Math.atan2(y2 - y1, x2 - x1), h = hd || 11;
      ctx.strokeStyle = col; ctx.fillStyle = col; ctx.lineWidth = w || 3; ctx.lineCap = 'round';
      line(x1, y1, x2 - Math.cos(a) * h * 0.7, y2 - Math.sin(a) * h * 0.7);
      ctx.beginPath(); ctx.moveTo(x2, y2);
      ctx.lineTo(x2 - Math.cos(a - 0.4) * h, y2 - Math.sin(a - 0.4) * h);
      ctx.lineTo(x2 - Math.cos(a + 0.4) * h, y2 - Math.sin(a + 0.4) * h); ctx.closePath(); ctx.fill();
    }
    // 力臂：支点到垂足的线段（两端短横），标注文字放在线段外侧
    function armSeg(o, f, col, label, side) {
      var dx = f[0] - o[0], dy = f[1] - o[1], l = Math.hypot(dx, dy);
      if (l < 2) return;
      var nx = -dy / l, ny = dx / l, k = side || 1;
      ctx.strokeStyle = col; ctx.lineWidth = 2.4; ctx.lineCap = 'round'; line(o[0], o[1], f[0], f[1]);
      ctx.lineWidth = 1.6; [o, f].forEach(function (p) { line(p[0] - nx * 6, p[1] - ny * 6, p[0] + nx * 6, p[1] + ny * 6); });
      tag(label, (o[0] + f[0]) / 2 + nx * 15 * k, (o[1] + f[1]) / 2 + ny * 15 * k, col, 13);
    }
    function rightAngle(f, a, b, col) {   // 垂足 f 处的直角符号，a、b 为两条边的方向
      var s = 9; ctx.strokeStyle = col; ctx.lineWidth = 1.2;
      ctx.beginPath(); ctx.moveTo(f[0] + a[0] * s, f[1] + a[1] * s); ctx.lineTo(f[0] + (a[0] + b[0]) * s, f[1] + (a[1] + b[1]) * s);
      ctx.lineTo(f[0] + b[0] * s, f[1] + b[1] * s); ctx.stroke();
    }
    function nrm(v) { var l = Math.hypot(v[0], v[1]) || 1; return [v[0] / l, v[1] / l]; }

    // ======================= 带刻度的杠杆 =======================
    function holePos(x, ang) { return [L.cx + x * L.g * Math.cos(ang), L.cy + x * L.g * Math.sin(ang)]; }
    function weight(x, y, g, alpha) {   // 一个钩码：上端挂钩在 (x, y)
      var w = WW * g, h = WH * g;
      ctx.globalAlpha = alpha == null ? 1 : alpha;
      ctx.strokeStyle = C.hook; ctx.lineWidth = Math.max(1, g * 0.035);
      ctx.beginPath(); ctx.arc(x, y + g * 0.06, g * 0.05, -Math.PI, Math.PI * 0.6); ctx.stroke();
      line(x, y + g * 0.1, x, y + h * 0.22);
      var grd = ctx.createLinearGradient(x - w / 2, 0, x + w / 2, 0);
      grd.addColorStop(0, '#7f8798'); grd.addColorStop(0.45, '#e2e6ee'); grd.addColorStop(1, '#6c7485');
      ctx.fillStyle = grd; rrect(x - w / 2, y + h * 0.22, w, h * 0.74, Math.min(4, g * 0.06)); ctx.fill();
      ctx.globalAlpha = 1;
    }
    function stack(x, y, n, g) { for (var i = 0; i < n; i++) weight(x, y + i * WH * g, g); }

    function drawGrid(st, info) {
      var g = L.g, cx = L.cx, cy = L.cy, ang = st.scene === 'scale' ? 0 : st.ang, ca = Math.cos(ang), sa = Math.sin(ang);
      // 铁架台
      ctx.fillStyle = '#2b3445'; rrect(cx - 2.6 * g, L.baseY, 5.2 * g, 0.38 * g, 4); ctx.fill();
      ctx.fillStyle = '#3c475b'; ctx.fillRect(cx - 0.11 * g, cy - 0.5 * g, 0.22 * g, L.baseY - cy + 0.5 * g);
      // 水平参考线
      dash(cx - 7.8 * g, cy, cx + 7.8 * g, cy, 'rgba(141,153,171,0.28)', 1);
      // 杠杆本体（旋转坐标系）
      ctx.save(); ctx.translate(cx, cy); ctx.rotate(ang);
      ctx.fillStyle = C.metal2; ctx.fillRect(-7.75 * g, -0.05 * g, 15.5 * g, 0.1 * g);   // 两端螺杆
      [-1, 1].forEach(function (s) {
        var nx = s * 7.3 * g + st.nut * 0.32 * g;
        ctx.fillStyle = st.nutHot ? C.accent : '#d7a74a'; rrect(nx - 0.16 * g, -0.22 * g, 0.32 * g, 0.44 * g, 3); ctx.fill();
        ctx.strokeStyle = 'rgba(0,0,0,0.35)'; ctx.lineWidth = 1; line(nx, -0.22 * g, nx, 0.22 * g);
      });
      var grd = ctx.createLinearGradient(0, -0.2 * g, 0, 0.2 * g);
      grd.addColorStop(0, '#eef1f6'); grd.addColorStop(1, '#9aa5b6');
      ctx.fillStyle = grd; rrect(-6.95 * g, -0.2 * g, 13.9 * g, 0.4 * g, 4); ctx.fill();
      for (var x = -V.HOLES; x <= V.HOLES; x++) {
        dot(x * g, 0, x ? Math.max(2, g * 0.08) : g * 0.13, x ? '#3a4253' : '#1c2230');
        if (x) text(String(Math.abs(x)), x * g, -0.42 * g, C.muted, 'center', clamp(g * 0.24, 9, 14));
      }
      ctx.restore();
      dot(cx, cy, g * 0.07, C.accent);
      text('O', cx + 0.3 * g, cy + 0.42 * g, C.accent, 'center', clamp(g * 0.3, 11, 16), '600');

      // 钩码
      Object.keys(st.hooks).forEach(function (k) {
        var n = st.hooks[k] - (st.drag && st.drag.from === +k ? 1 : 0);
        if (n <= 0) return;
        var h = holePos(+k, ang), top = h[1] + HOOK * g;
        ctx.strokeStyle = C.hook; ctx.lineWidth = Math.max(1, g * 0.03); line(h[0], h[1], h[0], top + g * 0.04);
        stack(h[0], top, n, g);
        if (st.hover && st.hover.type === 'stack' && st.hover.x === +k) { ctx.strokeStyle = C.accent; ctx.lineWidth = 1.5; rrect(h[0] - WW * g / 2 - 4, top - 4, WW * g + 8, n * WH * g + 8, 5); ctx.stroke(); }
        text(n * V.G + ' N', h[0], top + n * WH * g + 0.28 * g, +k < 0 ? C.f1 : C.f2, 'center', clamp(g * 0.26, 10, 14), '600');
      });
      // 力臂（竖直的力：力臂是支点到竖直作用线的水平距离）
      if (st.showArms) {
        [-1, 1].forEach(function (s) {
          var holes = (s < 0 ? info.left : info.right).holes.slice().sort(function (a, b) { return Math.abs(a) - Math.abs(b); });
          holes.forEach(function (x, i) {
            var h = holePos(x, ang), y = cy - (1.05 + i * 0.5) * g - Math.max(0, -Math.sin(ang) * s * Math.abs(x) * g);
            dash(h[0], h[1] - 0.2 * g, h[0], y, 'rgba(230,235,242,0.35)', 1);
            dash(cx, cy - 0.2 * g, cx, y, 'rgba(230,235,242,0.25)', 1);
            var lab = (s < 0 ? 'L₁' : 'L₂') + ' = ' + (Math.abs(x) * ca === Math.abs(x) ? Math.abs(x) + ' 格' : (Math.abs(x) * ca).toFixed(2) + ' 格');
            armSeg([cx, y], [h[0], y], s < 0 ? C.f1 : C.f2, lab, -1);
          });
        });
      }
      // 弹簧测力计
      if (st.scene === 'scale') drawScale(st, info);
      // 钩码盒
      var T = L.tray;
      ctx.fillStyle = 'rgba(255,255,255,0.04)'; ctx.strokeStyle = C.line; ctx.lineWidth = 1; rrect(T.x, T.y, T.w, T.h, 6); ctx.fill(); ctx.stroke();
      var left = info.free - (st.drag && st.drag.from == null ? 1 : 0);
      for (var i = 0; i < Math.min(left, 10); i++) weight(T.x + (0.38 + i * 0.43) * g, T.y + 0.16 * g, g, st.hover && st.hover.type === 'tray' ? 1 : 0.85);
      text('钩码盒 · 每个 0.5 N · 余 ' + left + ' 个', T.x + T.w / 2, T.y + T.h + 0.32 * g, C.muted, 'center', clamp(g * 0.24, 10, 13));
      // 拖动中的钩码与落点提示
      if (st.drag) {
        if (st.drag.to != null) { var hp = holePos(st.drag.to, ang); ctx.strokeStyle = C.accent; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(hp[0], hp[1], g * 0.22, 0, TAU); ctx.stroke(); }
        weight(st.drag.px, st.drag.py - 0.1 * g, g, 0.9);
      }
    }

    function scaleVec(st, sf) {   // 测力计拉力方向（画面坐标）
      var b = st.tilt * Math.PI / 180;
      return sf.dir > 0 ? [Math.sin(b), -Math.cos(b)] : [Math.sin(b), Math.cos(b)];
    }
    function drawScale(st, info) {
      var g = L.g, sf = info.sf, h = holePos(st.sx, 0), v = scaleVec(st, sf), a = Math.atan2(v[1], v[0]);
      // 作用线（虚线）与力臂
      if (st.showArms && sf.F > 0) {
        dash(h[0] - v[0] * 3 * g, h[1] - v[1] * 3 * g, h[0] + v[0] * 5.2 * g, h[1] + v[1] * 5.2 * g, 'rgba(126,224,129,0.55)', 1.2);
        var k = (h[0] - L.cx) * v[0] + (h[1] - L.cy) * v[1], foot = [h[0] - v[0] * k, h[1] - v[1] * k];
        if (Math.abs(st.tilt) > 0.5) rightAngle(foot, nrm([L.cx - foot[0], L.cy - foot[1]]), nrm([h[0] - foot[0], h[1] - foot[1]]), C.ok);
        armSeg([L.cx, L.cy], foot, C.ok, 'L = ' + sf.arm.toFixed(2) + ' 格', st.sx * sf.dir > 0 ? 1 : -1);
      }
      ctx.save(); ctx.translate(h[0], h[1]); ctx.rotate(a);
      var len = 3.3 * g, w = 0.62 * g, hk = 0.45 * g, over = sf.F > 5;
      ctx.strokeStyle = C.hook; ctx.lineWidth = Math.max(1.2, g * 0.035); line(0, 0, hk, 0);
      ctx.fillStyle = st.hover && st.hover.type === 'scale' ? '#36425a' : '#2c3648'; ctx.strokeStyle = over ? C.red : '#5a6880'; ctx.lineWidth = 1.5;
      rrect(hk, -w / 2, len, w, 5); ctx.fill(); ctx.stroke();
      // 刻度 0~5 N：0 在远离挂钩的一端，拉力越大指针越靠近挂钩
      var z = hk + len - 0.35 * g, f5 = hk + 0.4 * g;
      ctx.strokeStyle = 'rgba(230,235,242,0.6)'; ctx.lineWidth = 1;
      for (var i = 0; i <= 25; i++) { var xx = z + (f5 - z) * i / 25, tl = i % 5 ? 0.12 : 0.22; line(xx, -w / 2 + 2, xx, -w / 2 + 2 + tl * g); }
      var pf = z + (f5 - z) * Math.min(sf.F, 5.15) / 5;
      ctx.fillStyle = over ? C.red : C.accent; ctx.beginPath(); ctx.moveTo(pf, -w / 2 + 0.34 * g); ctx.lineTo(pf - 0.1 * g, w / 2 - 0.08 * g); ctx.lineTo(pf + 0.1 * g, w / 2 - 0.08 * g); ctx.closePath(); ctx.fill();
      ctx.strokeStyle = C.hook; ctx.lineWidth = Math.max(1.2, g * 0.04);
      ctx.beginPath(); ctx.arc(hk + len + 0.25 * g, 0, 0.2 * g, 0, TAU); ctx.stroke();   // 拉环
      ctx.restore();
      var tp = [h[0] + v[0] * (hk + len + 0.85 * g), h[1] + v[1] * (hk + len + 0.85 * g)];
      tag(over ? '超出量程 5 N' : 'F = ' + sf.F.toFixed(2) + ' N', tp[0], tp[1], over ? C.red : C.ok, clamp(g * 0.27, 11, 15));
      dot(h[0], h[1], g * 0.09, C.ok);
    }
    function scaleHit(st, info, x, y) {
      var g = L.g, h = holePos(st.sx, 0), v = scaleVec(st, info.sf), rx = x - h[0], ry = y - h[1];
      var t = rx * v[0] + ry * v[1], d = Math.abs(rx * v[1] - ry * v[0]);
      if (t > 0.3 * g && t < 4.4 * g && d < 0.55 * g) return 'scale';
      if (Math.hypot(rx, ry) < 0.35 * g) return 'scaleHook';
      return null;
    }

    // ======================= 撬棒：力臂作图 =======================
    function armLayout() { fit([-22, -34, 152, 95], [12, L.top, W - 24, H - L.top - L.bottom]); }
    function drawArm(st, sol) {
      var s = M.s, A = P(V.BAR.A), B = P(V.BAR.B), O = P(sol.O), g0 = P([0, 0]);
      // 地面、石头、支点垫块
      ctx.fillStyle = 'rgba(58,68,86,0.35)'; ctx.fillRect(P([-22, 0])[0], g0[1], 174 * s, 10 * s);
      ctx.strokeStyle = C.ground; ctx.lineWidth = 2; line(P([-22, 0])[0], g0[1], P([152, 0])[0], g0[1]);
      ctx.fillStyle = C.rock; ctx.beginPath();
      [[113, 0], [114, 18], [124, 34], [140, 37], [151, 26], [151, 0]].forEach(function (p, i) { var q = P(p); if (i) ctx.lineTo(q[0], q[1]); else ctx.moveTo(q[0], q[1]); });
      ctx.closePath(); ctx.fill();
      text('石头', P([136, 18])[0], P([136, 18])[1], '#d6dbe4', 'center', 13);
      var bw = 7 * s;
      ctx.fillStyle = st.hover === 'O' || st.dragging === 'O' ? '#8a96aa' : '#5d6779';
      ctx.beginPath(); ctx.moveTo(O[0], O[1] + 2); ctx.lineTo(O[0] + bw, g0[1]); ctx.lineTo(O[0] - bw, g0[1]); ctx.closePath(); ctx.fill();
      // 撬棒
      ctx.strokeStyle = '#aeb7c6'; ctx.lineWidth = Math.max(5, 2.6 * s); ctx.lineCap = 'round'; line(A[0], A[1], B[0], B[1]);
      dot(O[0], O[1], 5, C.accent);
      // 阻力 F2、动力 F1
      var base = 30 * s, P2 = P(sol.P2), e2 = [P2[0], P2[1] + base];
      var u1 = [sol.u1[0], -sol.u1[1]], P1 = P(sol.P1);
      var l1 = sol.ok ? clamp(base * sol.F1 / sol.F2, 14 * s, 62 * s) : base * 0.8, e1 = [P1[0] + u1[0] * l1, P1[1] + u1[1] * l1];
      if (st.showLines) {
        dash(P2[0], P2[1] - 60 * s, P2[0], P2[1] + base + 6, 'rgba(79,195,247,0.6)');
        dash(P1[0] - u1[0] * 150 * s, P1[1] - u1[1] * 150 * s, P1[0] + u1[0] * 150 * s, P1[1] + u1[1] * 150 * s, sol.ok ? 'rgba(255,123,107,0.6)' : 'rgba(141,153,171,0.4)');
      }
      if (st.showArms) {
        var f2 = P(sol.A2.foot);
        rightAngle(f2, nrm([O[0] - f2[0], O[1] - f2[1]]), [0, 1], C.f2);
        armSeg(O, f2, C.f2, 'L₂ = ' + sol.L2.toFixed(1) + ' cm', -1);
        if (sol.L1 > 0.5) {
          var f1 = P(sol.A1.foot), vo = nrm([O[0] - f1[0], O[1] - f1[1]]), vp = nrm([P1[0] - f1[0], P1[1] - f1[1]]);
          if (Math.hypot(P1[0] - f1[0], P1[1] - f1[1]) < 3) vp = u1;
          rightAngle(f1, vo, vp, sol.ok ? C.f1 : C.muted);
          armSeg(O, f1, sol.ok ? C.f1 : C.muted, 'L₁ = ' + sol.L1.toFixed(1) + ' cm', 1);
        }
      }
      arrow(P2[0], P2[1], e2[0], e2[1], C.f2, 3.5, 13);
      tag('F₂ = ' + sol.F2 + ' N', e2[0] - 4, e2[1] + 16, C.f2, 14);
      var c1 = sol.ok ? C.f1 : C.muted;
      arrow(P1[0], P1[1], e1[0], e1[1], c1, 3.5, 13);
      dot(P1[0], P1[1], st.hover === 'P1' || st.dragging === 'P1' ? 8 : 6, c1);
      ctx.strokeStyle = c1; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(e1[0], e1[1], st.hover === 'tip' || st.dragging === 'tip' ? 13 : 10, 0, TAU); ctx.stroke();
      tag(sol.ok ? 'F₁ = ' + sol.F1.toFixed(0) + ' N' : 'F₁ 不能使杠杆平衡', e1[0] + u1[0] * 26, e1[1] + u1[1] * 26 + (Math.abs(u1[1]) < 0.5 ? -18 : 0), c1, 14);
      tag('O', O[0], O[1] + 26, C.accent, 15);
      L.armHandles = { O: O, P1: P1, tip: e1 };
    }
    function armHit(x, y) {
      var h = L.armHandles; if (!h) return null;
      if (Math.hypot(x - h.tip[0], y - h.tip[1]) < 20) return 'tip';
      if (Math.hypot(x - h.P1[0], y - h.P1[1]) < 18) return 'P1';
      if (Math.hypot(x - h.O[0], y - h.O[1]) < 20) return 'O';
      var A = P(V.BAR.A), B = P(V.BAR.B), t = barT(x, y), q = [A[0] + (B[0] - A[0]) * t, A[1] + (B[1] - A[1]) * t];
      if (Math.hypot(x - q[0], y - q[1]) < 14) return 'bar';
      return null;
    }
    function barT(x, y) {   // 画面点在撬棒上的投影位置 0~1
      var A = P(V.BAR.A), B = P(V.BAR.B), dx = B[0] - A[0], dy = B[1] - A[1];
      return clamp(((x - A[0]) * dx + (y - A[1]) * dy) / (dx * dx + dy * dy), 0, 1);
    }

    // ======================= 生活中的杠杆 =======================
    function poly(pts, close) { ctx.beginPath(); pts.forEach(function (p, i) { var q = P(p); if (i) ctx.lineTo(q[0], q[1]); else ctx.moveTo(q[0], q[1]); }); if (close) ctx.closePath(); }
    function deco(t) {
      var s = M.s;
      ctx.lineCap = 'round'; ctx.lineJoin = 'round';
      if (t.id === 'crowbar') {
        ctx.strokeStyle = C.ground; ctx.lineWidth = 2; poly([[-10, 0], [150, 0]]); ctx.stroke();
        ctx.fillStyle = C.rock; poly([[114, 0], [115, 16], [124, 32], [140, 36], [150, 24], [150, 0]], true); ctx.fill();
        ctx.fillStyle = '#5d6779'; poly([[100, 10], [106, 0], [94, 0]], true); ctx.fill();
      } else if (t.id === 'hammer') {
        ctx.fillStyle = C.wood; poly([[-34, 0], [18, 0], [18, -8], [-34, -8]], true); ctx.fill();
        ctx.strokeStyle = '#d0d6df'; ctx.lineWidth = 0.9 * s; poly([[8, 3.6], [8, -5]]); ctx.stroke();
        ctx.lineWidth = 0.5 * s; poly([[6.6, 3.6], [9.4, 3.6]]); ctx.stroke();
        ctx.fillStyle = '#7d8799'; poly([[-4, 2], [0, 0], [3, 1.5], [9, 3], [9, 4.6], [3, 6.5], [0, 9], [-4, 7]], true); ctx.fill();
      } else if (t.id === 'barrow') {
        ctx.strokeStyle = C.ground; ctx.lineWidth = 2; poly([[-132, -18], [22, -18]]); ctx.stroke();
        ctx.strokeStyle = '#8e9aae'; ctx.lineWidth = 0.9 * s; poly([[-78, 16.9], [-82, -18]]); ctx.stroke();
        ctx.fillStyle = '#4b6a8f'; poly([[-72, 15.6], [-8, 1.7], [-2, 30], [-62, 42]], true); ctx.fill();
        ctx.fillStyle = '#c9a26a'; poly([[-60, 38], [-22, 30], [-24, 44], [-56, 50]], true); ctx.fill();
        var c = P([0, 0]); ctx.strokeStyle = '#9aa5b6'; ctx.lineWidth = 3 * s; ctx.beginPath(); ctx.arc(c[0], c[1], 16.5 * s, 0, TAU); ctx.stroke();
      } else if (t.id === 'opener') {
        ctx.fillStyle = '#3d7a5a'; poly([[-1.5, -8], [-1.5, -3], [-0.5, -1.2], [3.5, -1.2], [4.5, -3], [4.5, -8]], true); ctx.fill();
        ctx.fillStyle = '#d9b44a'; poly([[-0.3, -1.3], [3.3, -1.3], [3.3, -0.05], [-0.3, -0.05]], true); ctx.fill();
        ctx.strokeStyle = '#aeb7c6'; ctx.lineWidth = 0.5 * s; poly([[3, 0.3], [3.4, -1.4], [2.8, -1.6]]); ctx.stroke();
      } else if (t.id === 'rod') {
        ctx.strokeStyle = 'rgba(230,235,242,0.55)'; ctx.lineWidth = 1; poly([[240, 84], [240, -40]]); ctx.stroke();
        ctx.fillStyle = '#7fb2d9'; poly([[240, -40], [232, -47], [240, -56], [248, -47]], true); ctx.fill();
        ctx.strokeStyle = 'rgba(79,195,247,0.35)'; ctx.lineWidth = 1.5; poly([[150, -30], [255, -30]]); ctx.stroke();
      } else if (t.id === 'tweezers') {
        ctx.strokeStyle = 'rgba(207,214,226,0.45)'; ctx.lineWidth = 0.35 * s; poly([[0, -0.25], [12, -0.85]]); ctx.stroke();
        ctx.fillStyle = '#9ad08b'; var c2 = P([12.2, 0]); ctx.beginPath(); ctx.arc(c2[0], c2[1], 0.55 * s, 0, TAU); ctx.fill();
        ctx.fillStyle = '#8e9aae'; poly([[-1, 0.6], [0.3, 0.6], [0.3, -0.6], [-1, -0.6]], true); ctx.fill();
      } else if (t.id === 'forearm') {
        ctx.strokeStyle = 'rgba(232,214,190,0.75)'; ctx.lineWidth = 3.4 * s; poly([[0, 1], [-1, 32]]); ctx.stroke();
        ctx.strokeStyle = 'rgba(220,110,110,0.55)'; ctx.lineWidth = 3 * s; poly([[4, 1.2], [3.2, 12], [0.6, 28]]); ctx.stroke();
        ctx.fillStyle = 'rgba(126,180,224,0.8)'; poly([[29, 0], [35, 0], [34.4, -11], [29.6, -11]], true); ctx.fill();
        text('肱二头肌', P([10, 16])[0], P([10, 16])[1], 'rgba(255,170,160,0.9)', 'left', 12);
      } else if (t.id === 'balance') {
        ctx.fillStyle = '#3c475b'; poly([[-0.5, 0], [0.5, 0], [0.8, -12], [-0.8, -12]], true); ctx.fill();
        ctx.fillStyle = '#2b3445'; poly([[-9, -12], [9, -12], [9, -13.5], [-9, -13.5]], true); ctx.fill();
        [-10, 10].forEach(function (x) {
          ctx.strokeStyle = C.hook; ctx.lineWidth = 1; poly([[x, 0], [x - 3, -6]]); ctx.stroke(); poly([[x, 0], [x + 3, -6]]); ctx.stroke();
          ctx.fillStyle = '#9aa5b6'; poly([[x - 4.2, -6], [x + 4.2, -6], [x + 3.4, -7], [x - 3.4, -7]], true); ctx.fill();
        });
        ctx.fillStyle = '#d9b44a'; poly([[-11.5, -6], [-8.5, -6], [-8.5, -3.6], [-11.5, -3.6]], true); ctx.fill();
        ctx.fillStyle = '#c0c6cf'; poly([[8.8, -6], [11.2, -6], [11, -3.4], [9, -3.4]], true); ctx.fill();
      }
    }
    function drawTool(st, t, r) {
      var nar = L.narrow, area = nar ? [16, L.top + 4, W - 32, H - L.top - L.bottom - 70] : [40, L.top + 20, W - 80, H - L.top - L.bottom - 90];
      var b = t.box, padx = (b[2] - b[0]) * 0.12, pady = (b[3] - b[1]) * 0.18;
      fit([b[0] - padx, b[1] - pady, b[2] + padx, b[3] + pady], area);
      deco(t);
      ctx.strokeStyle = t.id === 'rod' ? '#c9a26a' : t.id === 'forearm' ? 'rgba(232,214,190,0.95)' : t.id === 'balance' ? '#cfd6e2' : '#aeb7c6';
      ctx.lineWidth = Math.max(4, Math.min(12, (t.id === 'forearm' ? 3.2 : 1.6) * M.s)); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
      poly(t.bar); ctx.stroke();
      if (t.id === 'tweezers' || t.id === 'opener') { ctx.lineWidth = Math.max(4, 0.45 * M.s); poly(t.bar); ctx.stroke(); }
      var O = P(t.O), P1 = P(t.P1), P2 = P(t.P2), u1 = [r.u1[0], -r.u1[1]], u2 = [r.u2[0], -r.u2[1]];
      var base = clamp(Math.min(W, H) * 0.09, 40, 70), l2 = base, l1 = clamp(base * r.ratio, 22, base * 2.6);
      var showLab = !st.quiz || st.answered;
      if (st.showLines) {
        var ext = Math.max(W, H);
        dash(P1[0] - u1[0] * ext, P1[1] - u1[1] * ext, P1[0] + u1[0] * ext, P1[1] + u1[1] * ext, 'rgba(255,123,107,0.4)');
        dash(P2[0] - u2[0] * ext, P2[1] - u2[1] * ext, P2[0] + u2[0] * ext, P2[1] + u2[1] * ext, 'rgba(79,195,247,0.4)');
      }
      if (st.showArms) {
        [[r.A1, P1, u1, C.f1, 'L₁', 1], [r.A2, P2, u2, C.f2, 'L₂', -1]].forEach(function (a) {
          var f = P(a[0].foot), vp = nrm([a[1][0] - f[0], a[1][1] - f[1]]);
          if (Math.hypot(a[1][0] - f[0], a[1][1] - f[1]) < 3) vp = a[2];
          if (a[0].L > 0.02 * (t.box[2] - t.box[0]) && Math.hypot(f[0] - a[1][0], f[1] - a[1][1]) > 3) rightAngle(f, nrm([O[0] - f[0], O[1] - f[1]]), vp, a[3]);
          armSeg(O, f, a[3], a[4] + (showLab ? ' = ' + fmtCm(a[0].L) : ''), a[5] * (t.id === 'balance' ? -1 : 1));
        });
      }
      arrow(P2[0], P2[1], P2[0] + u2[0] * l2, P2[1] + u2[1] * l2, C.f2, 3.5, 13);
      arrow(P1[0], P1[1], P1[0] + u1[0] * l1, P1[1] + u1[1] * l1, C.f1, 3.5, 13);
      tag('F₂ 阻力', P2[0] + u2[0] * (l2 + 18) + (Math.abs(u2[0]) < 0.3 ? 26 : 0), P2[1] + u2[1] * (l2 + 18), C.f2, 13);
      tag('F₁ 动力', P1[0] + u1[0] * (l1 + 18) + (Math.abs(u1[0]) < 0.3 ? -26 : 0), P1[1] + u1[1] * (l1 + 18), C.f1, 13);
      dot(O[0], O[1], 6, C.accent);
      var ol = OLAB[t.id] || [0, 22];
      tag('O 支点', O[0] + ol[0], O[1] + ol[1], C.accent, 13);
      var by = Math.min(H - L.bottom - 30, area[1] + area[3] + 40);
      if (showLab) tag(V.CLS[r.cls] + (r.cls === 'save' ? '：动力臂 > 阻力臂' : r.cls === 'cost' ? '：动力臂 < 阻力臂' : '：动力臂 = 阻力臂'), W / 2, by, r.cls === 'save' ? C.ok : r.cls === 'cost' ? C.f1 : C.accent, nar ? 14 : 16);
      else tag('它是省力、费力还是等臂杠杆？在面板里选一个', W / 2, by, C.muted, nar ? 13 : 15);
    }
    var OLAB = { barrow: [0, -24], balance: [0, -24], opener: [-44, 0], rod: [-34, -18], tweezers: [-52, 0], forearm: [-45, 22] };   // “O 支点”标签相对支点的偏移
    function fmtCm(v) { return (v >= 20 ? v.toFixed(0) : v >= 2 ? v.toFixed(1) : v.toFixed(2)) + ' cm'; }

    // ======================= 入口 =======================
    function draw(st, info) {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, W, H);
      ctx.fillStyle = '#05070d'; ctx.fillRect(0, 0, W, H);
      if (st.scene === 'balance' || st.scene === 'scale') { gridLayout(st.scene); drawGrid(st, info); }
      else if (st.scene === 'arm') { armLayout(); drawArm(st, info.arm); }
      else drawTool(st, info.tool, info.toolSol);
    }
    // 带刻度杠杆的命中检测：钩码堆、钩码盒、测力计
    function hitGrid(st, info, x, y) {
      gridLayout(st.scene);
      var g = L.g, ang = st.scene === 'scale' ? 0 : st.ang, T = L.tray;
      if (st.scene === 'scale') { var s = scaleHit(st, info, x, y); if (s) return { type: s }; }
      if (x > T.x && x < T.x + T.w && y > T.y && y < T.y + T.h) return { type: 'tray' };
      var keys = Object.keys(st.hooks);
      for (var i = 0; i < keys.length; i++) {
        var k = +keys[i], n = st.hooks[k]; if (!n) continue;
        var h = holePos(k, ang), top = h[1] + HOOK * g;
        if (Math.abs(x - h[0]) < Math.max(WW * g * 0.75, 12) && y > top - 0.1 * g && y < top + n * WH * g + 0.1 * g) return { type: 'stack', x: k };
      }
      for (var s2 = -1; s2 <= 1; s2 += 2) {
        var e = holePos(s2 * 7.3 + st.nut * 0.32, ang);
        if (Math.abs(x - e[0]) < 0.4 * g && Math.abs(y - e[1]) < 0.45 * g) return { type: 'nut' };
      }
      var hx = holeNear(st, x, y);
      if (hx != null) return { type: 'hole', x: hx };
      return null;
    }
    function holeNear(st, x, y) {   // 指针附近的孔位（用于放下钩码、挂测力计）
      var g = L.g, ang = st.scene === 'scale' ? 0 : st.ang;
      var t = ((x - L.cx) * Math.cos(ang) + (y - L.cy) * Math.sin(ang)) / g, k = Math.round(t);
      var hp = holePos(k, ang);
      if (!k || Math.abs(k) > V.HOLES || Math.abs(t - k) > 0.5 || y < hp[1] - 1.2 * g || y > hp[1] + 5 * g) return null;
      return k;
    }
    function scaleAngle(st, x, y) {   // 拖动测力计：由指针方向求偏离竖直的角度
      var h = holePos(st.sx, 0), dx = x - h[0], dy = y - h[1];
      return Math.atan2(dx, Math.abs(dy)) * 180 / Math.PI;
    }

    return { resize: resize, draw: draw, hitGrid: hitGrid, holeNear: holeNear, scaleAngle: scaleAngle,
      armHit: armHit, barT: barT, unP: unP, layout: function () { return L; } };
  }
  window.LeverDraw = LeverDraw;
})();
