// 杠杆计算：带刻度杠杆的力矩、平衡螺母、弹簧测力计拉力，一般杠杆的力臂与最小动力，生活中的杠杆数据。不碰 DOM
// 带刻度杠杆：孔位 x 以“格”为单位（±1…±6，右为正），每格 5 cm，每个钩码重 0.5 N；力矩以“使右端下沉”为正（N·格）
// 一般杠杆（撬棒、工具）：坐标 cm、y 向上，力矩以逆时针为正
(function () {
  var G = 0.5, GRID = 5, HOLES = 6, MAXN = 6;
  var NUT0 = -0.6, NUTK = 0.8, NUTOK = 0.75;   // 杠杆自身左端偏重的力矩；平衡螺母每移动 1 个单位的力矩；恰好调平的位置

  function sgn(v) { return v > 0 ? 1 : v < 0 ? -1 : 0; }

  // hooks: { 孔位: 钩码个数 }
  function side(hooks, s) {
    var holes = [], F = 0, FL = 0;
    Object.keys(hooks).forEach(function (k) {
      var x = +k, n = hooks[k];
      if (!n || sgn(x) !== s) return;
      holes.push(x); F += n * G; FL += n * G * Math.abs(x);
    });
    return { holes: holes, F: F, FL: FL, L: holes.length === 1 ? Math.abs(holes[0]) : null };
  }
  function hookTau(hooks) { return side(hooks, 1).FL - side(hooks, -1).FL; }
  function nutTau(nut) { return NUT0 + NUTK * nut; }
  function nutOK(nut) { return Math.abs(nutTau(nut)) < 0.02; }

  // 弹簧测力计挂在孔位 xs、拉力偏离竖直方向 beta 度，使杠杆在水平位置平衡所需的拉力
  // 返回 F（N）、力臂 arm（格）、dir（+1 竖直向上一侧 / −1 向下一侧）
  function scaleForce(tauW, xs, beta) {
    var arm = Math.abs(xs) * Math.cos(beta * Math.PI / 180);
    if (!xs || !tauW) return { F: 0, arm: arm, dir: xs > 0 ? -1 : 1 };
    return { F: Math.abs(tauW) / arm, arm: arm, dir: sgn(tauW * xs) };
  }

  // 力臂：支点 O 到力的作用线（过 P、方向 u 的直线）的距离；foot 为垂足，s 为力矩方向（+1 逆时针）
  function arm(O, P, u) {
    var rx = P[0] - O[0], ry = P[1] - O[1], c = rx * u[1] - ry * u[0], d = -(rx * u[0] + ry * u[1]);
    return { L: Math.abs(c), s: sgn(c), foot: [P[0] + u[0] * d, P[1] + u[1] * d] };
  }
  function unit(v) { var l = Math.hypot(v[0], v[1]) || 1; return [v[0] / l, v[1] / l]; }
  function classify(L1, L2) { return Math.abs(L1 - L2) <= 0.02 * Math.max(L1, L2) ? 'equal' : L1 > L2 ? 'save' : 'cost'; }

  // 撬棒（力臂作图场景）：杠杆从 A 到 B，阻力 F2（石头压在 B 端）竖直向下
  var BAR = { A: [0, 45], B: [120, 5], F2: 600 };
  function barAt(t) { return [BAR.A[0] + (BAR.B[0] - BAR.A[0]) * t, BAR.A[1] + (BAR.B[1] - BAR.A[1]) * t]; }
  function barLen() { return Math.hypot(BAR.B[0] - BAR.A[0], BAR.B[1] - BAR.A[1]); }
  // st: { o: 支点位置 0~1, p: 动力作用点 0~1, dir: 动力方向角（度，0 向右、90 向上） }
  function solveArm(st) {
    var O = barAt(st.o), P1 = barAt(st.p), P2 = BAR.B, a = st.dir * Math.PI / 180;
    var u1 = [Math.cos(a), Math.sin(a)], u2 = [0, -1];
    var A1 = arm(O, P1, u1), A2 = arm(O, P2, u2);
    var ok = A1.L > 0.5 && A1.s === -A2.s;
    return { O: O, P1: P1, P2: P2, u1: u1, u2: u2, A1: A1, A2: A2, L1: A1.L, L2: A2.L, F2: BAR.F2,
      F1: ok ? BAR.F2 * A2.L / A1.L : null, ok: ok, cls: ok ? classify(A1.L, A2.L) : null };
  }
  // 最小动力：作用点取离支点最远的一端，方向垂直于杠杆，转动方向与阻力相反
  function minForce(st) {
    var p = st.o > 0.5 ? 0 : 1, O = barAt(st.o), P = barAt(p), A2 = arm(O, BAR.B, [0, -1]);
    var r = unit([P[0] - O[0], P[1] - O[1]]), n = [-r[1], r[0]];   // n 使力矩为逆时针
    if (A2.s > 0) n = [-n[0], -n[1]];
    return { p: p, dir: Math.atan2(n[1], n[0]) * 180 / Math.PI };
  }

  // 生活中的杠杆（cm、y 向上）：bar 为杠杆主体折线，O 支点，P1/d1 动力，P2/d2 阻力，box 为画面范围
  var TOOLS = [
    { id: 'crowbar', name: '撬棒', bar: [[0, 40], [120, 4]], O: [100, 10], P1: [0, 40], d1: [0, -1], P2: [120, 4], d2: [0, -1],
      box: [-10, -12, 150, 55], act: '人在长的一端向下压，在短的一端撬起石头' },
    { id: 'hammer', name: '羊角锤拔钉子', bar: [[8, 3], [1, 6], [-22, 32]], O: [0, 0], P1: [-22, 32], d1: [-26, -21], P2: [8, 3], d2: [0, -1],
      box: [-34, -8, 18, 40], act: '锤头抵在木板上作支点，用力扳锤柄，羊角拔起钉子' },
    { id: 'barrow', name: '独轮车', bar: [[0, 0], [-120, 26]], O: [0, 0], P1: [-120, 26], d1: [0, 1], P2: [-40, 26 / 3], d2: [0, -1],
      box: [-132, -20, 22, 60], act: '车轮的轴是支点，车厢里的货物重力是阻力，人在车把上向上抬' },
    { id: 'opener', name: '开瓶器（起子）', bar: [[0, 0], [15, 1.5]], O: [0, 0], P1: [15, 1.5], d1: [0, 1], P2: [3, 0.3], d2: [0, -1],
      box: [-3, -8, 18, 5], act: '起子前端抵住瓶盖顶部作支点，钩住瓶盖边缘，向上抬手柄' },
    { id: 'rod', name: '钓鱼竿', bar: [[0, 0], [240, 84]], O: [0, 0], P1: [30, 10.5], d1: [0, 1], P2: [240, 84], d2: [0, -1],
      box: [-15, -60, 255, 100], act: '后面的手握住竿尾作支点，前面的手向上抬，鱼线拉着竿梢' },
    { id: 'tweezers', name: '镊子', bar: [[0, 0.25], [12, 0.85]], O: [0, 0], P1: [5, 0.5], d1: [0, -1], P2: [11.6, 0.83], d2: [0, 1],
      box: [-1.5, -2.6, 13.5, 2.6], act: '两片在尾部连在一起（支点），手指在中间捏，前端夹住物体' },
    { id: 'forearm', name: '人的前臂（端起杯子）', bar: [[0, 0], [32, 0]], O: [0, 0], P1: [4, 0], d1: [-3, 28], P2: [31, 0], d2: [0, -1],
      box: [-8, -20, 40, 34], act: '肘关节是支点，肱二头肌收缩向上拉前臂，手中杯子的重力是阻力', bio: true },
    { id: 'balance', name: '托盘天平', bar: [[-10, 0], [10, 0]], O: [0, 0], P1: [-10, 0], d1: [0, -1], P2: [10, 0], d2: [0, -1],
      box: [-15, -14, 15, 6], act: '横梁的中点是支点，左盘物体、右盘砝码对横梁的压力分别为动力和阻力' }
  ];
  function solveTool(t) {
    var u1 = unit(t.d1), u2 = unit(t.d2), A1 = arm(t.O, t.P1, u1), A2 = arm(t.O, t.P2, u2);
    return { u1: u1, u2: u2, A1: A1, A2: A2, L1: A1.L, L2: A2.L, ratio: A2.L / A1.L, cls: classify(A1.L, A2.L), opposite: A1.s === -A2.s };
  }
  var CLS = { save: '省力杠杆', cost: '费力杠杆', equal: '等臂杠杆' };

  window.Lever = { G: G, GRID: GRID, HOLES: HOLES, MAXN: MAXN, NUT0: NUT0, NUTK: NUTK, NUTOK: NUTOK,
    side: side, hookTau: hookTau, nutTau: nutTau, nutOK: nutOK, scaleForce: scaleForce,
    arm: arm, unit: unit, classify: classify, BAR: BAR, barAt: barAt, barLen: barLen, solveArm: solveArm, minForce: minForce,
    TOOLS: TOOLS, solveTool: solveTool, CLS: CLS };
})();
