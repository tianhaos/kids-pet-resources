(function () {
  var V = window.Lever;
  var $ = function (id) { return document.getElementById(id); };
  var qa = function (sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); };
  var NAME = '杠杆';
  var MAXW = 12, MAXROWS = 10, AMAX = 10 * Math.PI / 180;

  var SCENES = {
    balance: { name: '探究杠杆的平衡条件', hint: '拖钩码到杠杆的孔上（点孔位也能挂）· 把钩码拖离杠杆即取下 · 拖平衡螺母调平',
      note: '先调节平衡螺母使杠杆在水平位置平衡，再在两侧挂钩码，移动钩码位置使杠杆重新在水平位置平衡，记录动力、动力臂、阻力、阻力臂。' },
    scale: { name: '弹簧测力计斜拉', hint: '拖测力计改变拉力方向 · 拖挂钩换孔位 · 钩码可以拖动',
      note: '左侧挂钩码，用弹簧测力计拉住杠杆使它在水平位置平衡。让测力计由竖直方向逐渐倾斜，看拉力的力臂和测力计示数怎样变化。' },
    arm: { name: '力臂作图与最小动力', hint: '拖支点 O、动力作用点，拖箭头末端的圆圈改变动力方向',
      note: '用撬棒撬石头：力臂是支点到力的作用线的距离（不是支点到作用点的距离）。改变动力的作用点和方向，找出最省力的用法。' },
    tools: { name: '生活中的杠杆', hint: '在面板里选择工具 · 比较动力臂和阻力臂',
      note: '找出每种工具的支点、动力、阻力，画出两个力臂并比较长短，判断它是省力杠杆、费力杠杆还是等臂杠杆。' }
  };

  var state = {
    scene: 'balance', hooks: {}, nut: 0, ang: 0, nutMoved: false, showArms: true, showLines: true,
    sx: 3, tilt: 0, drag: null, hover: null, dragging: null,
    arm: { o: 100 / 120, p: 0, dir: -90 }, tool: 'crowbar', quiz: false, answered: false, guess: null,
    dataBy: { balance: [], scale: [] }
  };
  var info = {};

  var stage = $('stage'), canvas = $('lever'), panel = $('panel');
  var view = window.LeverDraw(canvas);

  function setSeg(attr, val) { qa('[data-' + attr + ']').forEach(function (b) { b.classList.toggle('on', b.dataset[attr] === String(val)); }); }
  function fmt(v, d) { return (+v.toFixed(d == null ? 2 : d)).toString(); }
  function toolDef() { return V.TOOLS.filter(function (t) { return t.id === state.tool; })[0] || V.TOOLS[0]; }

  // ---------- 计算 ----------
  function count() { return Object.keys(state.hooks).reduce(function (s, k) { return s + state.hooks[k]; }, 0); }
  function compute() {
    var st = state;
    info.left = V.side(st.hooks, -1); info.right = V.side(st.hooks, 1);
    info.tauH = V.hookTau(st.hooks);
    info.nutOK = V.nutOK(st.nut);
    info.tau = info.tauH + (st.scene === 'balance' && !info.nutOK ? V.nutTau(st.nut) : 0);
    info.balanced = Math.abs(info.tau) < 1e-9;
    info.free = MAXW - count();
    info.sf = V.scaleForce(info.tauH, st.sx, st.tilt);
    info.arm = V.solveArm(st.arm);
    info.tool = toolDef(); info.toolSol = V.solveTool(info.tool);
  }
  function update() { compute(); syncPanel(); }

  // ---------- 记录数据 ----------
  function canRecord() {
    var st = state;
    if (st.dataBy[st.scene].length >= MAXROWS) return '最多记录 ' + MAXROWS + ' 组，先清除数据';
    if (st.scene === 'balance') {
      if (!info.nutOK) return '先调节平衡螺母，使杠杆在水平位置平衡';
      if (!info.left.holes.length || !info.right.holes.length) return '两侧都要挂上钩码';
      if (info.left.holes.length > 1 || info.right.holes.length > 1) return '每侧只在一个位置挂钩码，便于读出力臂';
      if (!info.balanced) return '杠杆没有平衡，调整钩码的个数或位置';
      if (Math.abs(st.ang) > 0.01) return '等杠杆静止在水平位置再记录';
    } else {
      if (!info.tauH) return '先在杠杆上挂钩码';
      if (info.sf.F > 5) return '超出测力计量程，减小倾斜角度';
    }
    return '';
  }
  function record() {
    var why = canRecord(), st = state;
    if (why) { flash(why); return; }
    var d;
    if (st.scene === 'balance') d = { F1: info.left.F, L1: info.left.L * V.GRID, F2: info.right.F, L2: info.right.L * V.GRID };
    else d = { tilt: Math.round(Math.abs(st.tilt)), F: info.sf.F, L: info.sf.arm * V.GRID, FL: info.sf.F * info.sf.arm * V.GRID, W: Math.abs(info.tauH) * V.GRID };
    var rows = st.dataBy[st.scene], last = rows[rows.length - 1];
    if (last && JSON.stringify(last) === JSON.stringify(d)) { flash('和上一组一样，换一种挂法再记录'); return; }
    rows.push(d);
    Analytics.track(NAME, '记录数据', SCENES[st.scene].name);
    syncPanel();
  }
  var flashT = 0;
  function flash(msg) { $('recMsg').textContent = msg; clearTimeout(flashT); flashT = setTimeout(function () { $('recMsg').textContent = ''; }, 2600); }

  // ---------- 读数、提示 ----------
  function notes() {
    var n = [], st = state, l = info.left, r = info.right;
    if (st.scene === 'balance') {
      if (!info.nutOK) {
        var lowL = V.nutTau(st.nut) < 0;
        if (!count()) n.push('杠杆' + (lowL ? '左' : '右') + '端下沉：应把平衡螺母向' + (lowL ? '右' : '左') + '调（哪端高往哪端调），直到杠杆在水平位置平衡。');
        else n.push('还没调平杠杆就挂了钩码：杠杆自重的影响没有消除，F₁L₁ = F₂L₂ 时杠杆也不平衡。先取下钩码调平衡螺母。');
      } else if (!count()) n.push('杠杆已在水平位置平衡。调平是为了消除杠杆自重的影响，并且便于直接从杠杆上读出力臂。');
      if (st.nutMoved && count()) n.push('注意：挂上钩码后就不能再调节平衡螺母，只能改变钩码的个数或位置。');
      if (info.nutOK && count()) {
        if (info.balanced) n.push(l.holes.length && r.holes.length ? '杠杆平衡：左侧 F·L = ' + fmt(l.FL * V.GRID, 1) + ' N·cm，右侧 F·L = ' + fmt(r.FL * V.GRID, 1) + ' N·cm，相等。' : '');
        else n.push((info.tau < 0 ? '左' : '右') + '端下沉：' + (info.tau < 0 ? '左' : '右') + '侧的 F·L 较大。可以把' + (info.tau < 0 ? '左侧钩码向支点移，或把右侧钩码向外移' : '右侧钩码向支点移，或把左侧钩码向外移') + '，也可以增减钩码。');
        if (l.holes.length > 1 || r.holes.length > 1) n.push('一侧挂在几个位置时，这一侧的作用效果是各个 F·L 之和。');
      }
    } else if (st.scene === 'scale') {
      if (!info.tauH) n.push('杠杆上没有钩码（或两侧钩码已平衡），测力计不用拉。');
      else {
        var same = st.sx * info.tauH > 0;   // 测力计与钩码在同侧
        n.push('测力计与钩码在支点' + (same ? '同侧，要向上拉' : '两侧，要向下拉') + '。拉力偏离竖直方向 ' + Math.round(Math.abs(st.tilt)) + '°，力臂 L = ' + Math.abs(st.sx) + ' 格 × cos' + Math.round(Math.abs(st.tilt)) + '° = ' + fmt(info.sf.arm) + ' 格。');
        if (Math.abs(st.tilt) > 0.5) n.push('斜拉时力臂不在杠杆上，变短了，所以拉力比竖直拉时大：F = ' + fmt(V.scaleForce(info.tauH, st.sx, 0).F) + ' N → ' + fmt(info.sf.F) + ' N。');
        else n.push('竖直拉时力臂就在杠杆上，等于支点到挂钩的距离，示数最小。');
        if (info.sf.F > 5) n.push('所需拉力超过测力计的量程 5 N。');
      }
    } else if (st.scene === 'arm') {
      var a = info.arm;
      if (!a.ok) n.push(a.A1.L < 0.5 ? '动力的作用线通过支点，力臂为零，不能使杠杆转动。' : '这个方向的动力和阻力使杠杆向同一方向转动，不能使杠杆平衡。');
      else {
        n.push('F₁L₁ = F₂L₂：F₁ = ' + V.BAR.F2 + ' N × ' + fmt(a.L2, 1) + ' cm ÷ ' + fmt(a.L1, 1) + ' cm ≈ ' + fmt(a.F1, 0) + ' N，是' + V.CLS[a.cls] + '。');
        var m = V.minForce(st.arm), b = V.solveArm({ o: st.arm.o, p: m.p, dir: m.dir });
        if (a.F1 - b.F1 > 0.5) n.push('还能更省力：动力作用在离支点最远的一端、方向垂直于 OA 时力臂最长，最小动力约 ' + fmt(b.F1, 0) + ' N。');
        else n.push('这已经是最小的动力：作用点离支点最远，动力方向与杠杆垂直，动力臂等于 OA，最长。');
      }
    } else {
      var t = info.tool, ts = info.toolSol;
      n.push(t.act + '。');
      if (!st.quiz || st.answered) n.push(ts.cls === 'save' ? '动力臂是阻力臂的 ' + fmt(1 / ts.ratio, 1) + ' 倍，动力约为阻力的 ' + fmt(ts.ratio) + ' 倍：省力，但手要移动更长的距离（费距离）。' :
        ts.cls === 'cost' ? '动力臂只有阻力臂的 ' + fmt(1 / ts.ratio) + '，动力约为阻力的 ' + fmt(ts.ratio, 1) + ' 倍：费力，但阻力作用点移动的距离长（省距离），操作灵活。' : '动力臂等于阻力臂，动力等于阻力：既不省力也不费力，用来比较两边的质量。');
      if (st.quiz && st.answered) n.push(st.guess === ts.cls ? '✓ 判断正确！' : '✗ 不对，比较一下两个力臂的长短。');
    }
    return n.filter(Boolean);
  }
  function esc(s) { return String(s).replace(/[&<>]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]; }); }

  function syncPanel() {
    var st = state, sc = SCENES[st.scene], big = '', dl = [];
    setSeg('scene', st.scene); setSeg('tool', st.tool); setSeg('guess', st.answered ? st.guess : '');
    qa('[data-for]').forEach(function (el) { el.hidden = el.dataset.for.split(' ').indexOf(st.scene) < 0; });
    if (st.scene === 'balance') {
      var l = info.left, r = info.right;
      big = '<span class="f1">F₁L₁ = <b>' + fmt(l.FL * V.GRID, 1) + '</b></span><span class="f2">F₂L₂ = <b>' + fmt(r.FL * V.GRID, 1) + '</b></span><small>N·cm</small>';
      dl = [['动力 F₁（左）', l.F ? fmt(l.F) + ' N' : '—'], ['动力臂 L₁', l.L ? l.L + ' 格 = ' + l.L * V.GRID + ' cm' : l.holes.length ? '多个位置' : '—'],
        ['阻力 F₂（右）', r.F ? fmt(r.F) + ' N' : '—'], ['阻力臂 L₂', r.L ? r.L + ' 格 = ' + r.L * V.GRID + ' cm' : r.holes.length ? '多个位置' : '—'],
        ['杠杆状态', !info.nutOK && !count() ? '未调平' : info.balanced ? '平衡' : (info.tau < 0 ? '左' : '右') + '端下沉']];
    } else if (st.scene === 'scale') {
      var sf = info.sf;
      big = '<span class="ok">F = <b>' + (sf.F > 5 ? '超量程' : fmt(sf.F) + ' N') + '</b></span><span class="muted2">L = ' + fmt(sf.arm * V.GRID, 1) + ' cm</span>';
      dl = [['钩码一侧 F·L', fmt(Math.abs(info.tauH) * V.GRID, 1) + ' N·cm'], ['测力计 F·L', fmt(sf.F * sf.arm * V.GRID, 1) + ' N·cm'],
        ['挂在', (st.sx < 0 ? '左' : '右') + '侧第 ' + Math.abs(st.sx) + ' 格'], ['偏离竖直', Math.round(Math.abs(st.tilt)) + '°'], ['竖直拉时', fmt(V.scaleForce(info.tauH, st.sx, 0).F) + ' N']];
    } else if (st.scene === 'arm') {
      var a = info.arm;
      big = '<span class="f1">F₁ = <b>' + (a.ok ? fmt(a.F1, 0) + ' N' : '—') + '</b></span><span class="f2">F₂ = <b>' + V.BAR.F2 + ' N</b></span>';
      dl = [['动力臂 L₁', fmt(a.L1, 1) + ' cm'], ['阻力臂 L₂', fmt(a.L2, 1) + ' cm'], ['支点到作用点', fmt(Math.hypot(a.P1[0] - a.O[0], a.P1[1] - a.O[1]), 1) + ' cm'],
        ['判断', a.ok ? V.CLS[a.cls] : '不能平衡']];
    } else {
      var t = info.tool, ts = info.toolSol, show = !st.quiz || st.answered;
      big = '<span>' + esc(t.name) + '</span>' + (show ? '<span class="cls ' + ts.cls + '">' + V.CLS[ts.cls] + '</span>' : '<span class="muted2">？</span>');
      dl = [['动力臂 L₁', show ? fmt(ts.L1, ts.L1 < 20 ? 1 : 0) + ' cm' : '？'], ['阻力臂 L₂', show ? fmt(ts.L2, ts.L2 < 20 ? 1 : 0) + ' cm' : '？'],
        ['动力 F₁', show ? '≈ ' + fmt(ts.ratio, ts.ratio < 1 ? 2 : 1) + ' F₂' : '？']];
    }
    $('rBig').innerHTML = big;
    $('rDl').innerHTML = dl.map(function (d) { return '<dt>' + d[0] + '</dt><dd>' + d[1] + '</dd>'; }).join('');
    var nn = notes();
    $('rNotes').innerHTML = nn.map(function (t) { return '<li>' + esc(t) + '</li>'; }).join('');
    $('rNotes').hidden = !nn.length;
    $('rNotes').className = (st.scene === 'balance' && (st.nutMoved && count() || !info.nutOK && count())) || (st.scene === 'arm' && !info.arm.ok) || (st.scene === 'scale' && info.sf.F > 5) ? 'warn' : '';
    $('sceneNote').textContent = sc.note;
    $('hint').textContent = sc.hint;
    $('nutRange').value = Math.round(st.nut * 100); $('nutOut').textContent = info.nutOK ? '已调平' : st.nut > V.NUTOK ? '偏右' : '偏左';
    $('tiltRange').value = Math.round(st.tilt); $('tiltOut').textContent = Math.round(st.tilt) + '°';
    $('sxRange').value = st.sx; $('sxOut').textContent = (st.sx < 0 ? '左 ' : '右 ') + Math.abs(st.sx) + ' 格';
    $('oRange').value = Math.round(st.arm.o * 100); $('oOut').textContent = fmt(V.barLen() * st.arm.o, 0) + ' cm';
    $('dirRange').value = Math.round(st.arm.dir); $('dirOut').textContent = Math.round(st.arm.dir) + '°';
    $('showArms').checked = st.showArms; $('showLines').checked = st.showLines; $('quiz').checked = st.quiz;
    $('guessRow').hidden = !st.quiz;
    syncTable();
  }

  function syncTable() {
    var st = state, d = st.dataBy[st.scene] || [], head, rows, sum = '';
    if (st.scene === 'balance') {
      head = '<th>#</th><th>F₁/N</th><th>L₁/cm</th><th>F₂/N</th><th>L₂/cm</th><th>F₁L₁</th><th>F₂L₂</th>';
      rows = d.map(function (r, i) { return '<tr><td>' + (i + 1) + '</td><td>' + fmt(r.F1) + '</td><td>' + r.L1 + '</td><td>' + fmt(r.F2) + '</td><td>' + r.L2 + '</td><td>' + fmt(r.F1 * r.L1, 1) + '</td><td>' + fmt(r.F2 * r.L2, 1) + '</td></tr>'; });
      if (d.length && d.length < 3) sum = '<p class="bad">只做 ' + d.length + ' 次实验得出的结论具有偶然性，应改变钩码的个数和位置，至少做 3 次。</p>';
      if (d.length >= 3) sum = '<p>每一组都有 F₁L₁ = F₂L₂：<b>动力 × 动力臂 = 阻力 × 阻力臂</b>，这就是杠杆的平衡条件。</p>';
      if (d.length >= 2 && d.every(function (r) { return r.F1 * 2 === r.L1 / V.GRID && r.F2 * 2 === r.L2 / V.GRID; })) sum += '<p class="bad">这几组的力（个）与力臂（格）数值相同，容易得出“动力 + 动力臂 = 阻力 + 阻力臂”之类的错误结论，换些不同的组合。</p>';
    } else {
      head = '<th>#</th><th>偏角</th><th>F/N</th><th>L/cm</th><th>F·L/N·cm</th>';
      rows = d.map(function (r, i) { return '<tr><td>' + (i + 1) + '</td><td>' + r.tilt + '°</td><td>' + fmt(r.F) + '</td><td>' + fmt(r.L, 1) + '</td><td>' + fmt(r.FL, 1) + '</td></tr>'; });
      var tilts = d.map(function (r) { return r.tilt; });
      if (d.length >= 2 && Math.max.apply(null, tilts) > Math.min.apply(null, tilts) && d.every(function (r) { return r.W === d[0].W; }))
        sum = '<p>钩码不变时，<b>拉力越偏离竖直方向，力臂越短，拉力越大</b>；F·L 始终等于钩码一侧的 F·L。</p>';
    }
    $('dataTable').innerHTML = '<thead><tr>' + head + '</tr></thead><tbody>' + (rows.length ? rows.join('') : '<tr><td colspan="7" class="muted">还没有数据</td></tr>') + '</tbody>';
    $('dataSum').innerHTML = sum;
  }

  // ---------- 场景 ----------
  function loadScene(name) {
    state.scene = SCENES[name] ? name : 'balance';
    state.hooks = state.scene === 'scale' ? { '-2': 3 } : {};
    state.ang = 0; state.nutMoved = false; state.drag = null; state.hover = null;
    if (state.scene === 'scale') { state.nut = V.NUTOK; state.sx = 3; state.tilt = 0; }
    else if (state.scene === 'balance') state.nut = 0;
    update();
  }
  function setNut(v) {
    var old = state.nut;
    state.nut = Math.max(-1, Math.min(1, Math.round(v * 20) / 20));
    if (state.nut !== old && count()) state.nutMoved = true;
    update();
  }
  function addWeight(x) {
    if (state.hooks[x] >= V.MAXN) { flash('一个孔最多挂 ' + V.MAXN + ' 个钩码'); return false; }
    if (count() >= MAXW) { flash('钩码盒里没有钩码了'); return false; }
    state.hooks[x] = (state.hooks[x] || 0) + 1; return true;
  }
  function removeWeight(x) { if (state.hooks[x] > 0 && !--state.hooks[x]) delete state.hooks[x]; }
  function practice() {   // 出题：左侧随机挂钩码，右侧留给学生
    var n = 1 + Math.floor(Math.random() * 4), x = 1 + Math.floor(Math.random() * 6);
    state.hooks = {}; state.hooks[-x] = n;
    if (state.scene === 'balance') { state.nut = V.NUTOK; state.nutMoved = false; }
    update();
    flash('左侧挂了 ' + n + ' 个钩码在第 ' + x + ' 格，在右侧挂钩码使杠杆平衡');
  }

  // ---------- 画布交互 ----------
  var drag = null;
  function pos(e) { var r = canvas.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; }
  function grid() { return state.scene === 'balance' || state.scene === 'scale'; }
  canvas.addEventListener('pointerdown', function (e) {
    var p = pos(e), st = state;
    if (grid()) {
      var h = view.hitGrid(st, info, p[0], p[1]);
      if (!h) return;
      if (h.type === 'scale' || h.type === 'scaleHook') drag = { kind: h.type === 'scale' ? 'tilt' : 'sx' };
      else if (h.type === 'nut') drag = { kind: 'nut', x0: p[0], nut0: st.nut };
      else if (h.type === 'tray') { if (info.free > 0) drag = { kind: 'w', from: null, px: p[0], py: p[1], to: null, sx: p[0], sy: p[1], moved: true }; else flash('钩码盒里没有钩码了'); }
      else if (h.type === 'stack') drag = { kind: 'w', from: h.x, px: p[0], py: p[1], to: h.x, sx: p[0], sy: p[1], moved: false };
      else if (h.type === 'hole') { if (addWeight(h.x)) { update(); Analytics.track(NAME, '挂钩码', '点孔位'); } return; }
    } else if (st.scene === 'arm') {
      var a = view.armHit(p[0], p[1]);
      if (!a || a === 'bar') return;
      drag = { kind: a }; st.dragging = a;
    } else return;
    try { canvas.setPointerCapture(e.pointerId); } catch (err) {}
    state.drag = drag && drag.kind === 'w' ? drag : null;
    e.preventDefault();
    if (drag) move(p);
  });
  function move(p) {
    var st = state;
    if (drag.kind === 'w') {
      drag.px = p[0]; drag.py = p[1];
      if (Math.hypot(p[0] - drag.sx, p[1] - drag.sy) > 6) drag.moved = true;
      drag.to = view.holeNear(st, p[0], p[1]);
    } else if (drag.kind === 'tilt') { st.tilt = Math.max(-60, Math.min(60, Math.round(view.scaleAngle(st, p[0], p[1])))); if (Math.abs(st.tilt) <= 2) st.tilt = 0; update(); }
    else if (drag.kind === 'sx') { var k = view.holeNear(st, p[0], p[1]); if (k != null && k !== st.sx) { st.sx = k; update(); } }
    else if (drag.kind === 'nut') setNut(drag.nut0 + (p[0] - drag.x0) / (view.layout().g * 0.32));
    else if (drag.kind === 'O') { st.arm.o = Math.max(0.1, Math.min(0.95, view.barT(p[0], p[1]))); update(); }
    else if (drag.kind === 'P1') { st.arm.p = view.barT(p[0], p[1]); update(); }
    else if (drag.kind === 'tip') {
      var w = view.unP(p[0], p[1]), P1 = info.arm.P1, d = Math.atan2(w[1] - P1[1], w[0] - P1[0]) * 180 / Math.PI;
      var bar = Math.atan2(V.BAR.B[1] - V.BAR.A[1], V.BAR.B[0] - V.BAR.A[0]) * 180 / Math.PI;
      [-90, 90, bar + 90, bar - 90].forEach(function (s) { if (Math.abs(((d - s + 540) % 360) - 180) < 4) d = s; });   // 吸附到竖直方向、垂直于杠杆
      st.arm.dir = ((d + 540) % 360) - 180; update();
    }
  }
  canvas.addEventListener('pointermove', function (e) {
    var p = pos(e), st = state;
    if (drag) { move(p); return; }
    if (grid()) {
      var h = view.hitGrid(st, info, p[0], p[1]);
      st.hover = h;
      canvas.style.cursor = !h ? 'default' : h.type === 'nut' ? 'ew-resize' : h.type === 'hole' ? 'copy' : 'grab';
    } else if (st.scene === 'arm') {
      var a = view.armHit(p[0], p[1]); st.hover = a;
      canvas.style.cursor = a && a !== 'bar' ? 'grab' : 'default';
    }
  });
  function up() {
    if (!drag) return;
    var st = state, d = drag;
    drag = null; st.drag = null; st.dragging = null;
    if (d.kind === 'w') {
      if (!d.moved && d.from != null) { if (addWeight(d.from)) Analytics.track(NAME, '挂钩码', '点钩码'); }
      else if (d.to !== d.from) {
        if (d.from != null) removeWeight(d.from);
        if (d.to != null && !addWeight(d.to) && d.from != null) addWeight(d.from);
        Analytics.track(NAME, d.to != null ? '挂钩码' : '取下钩码', '拖动');
      }
      update();
    } else Analytics.track(NAME, '拖动', d.kind);
  }
  canvas.addEventListener('pointerup', up);
  canvas.addEventListener('pointercancel', up);
  canvas.addEventListener('pointerleave', function () { if (!drag) state.hover = null; });

  // ---------- 面板控件 ----------
  qa('[data-scene]').forEach(function (b) { b.addEventListener('click', function () { loadScene(b.dataset.scene); Analytics.track(NAME, '场景', SCENES[state.scene].name); }); });
  qa('[data-tool]').forEach(function (b) { b.addEventListener('click', function () { state.tool = b.dataset.tool; state.answered = false; state.guess = null; update(); Analytics.track(NAME, '工具', b.textContent); }); });
  qa('[data-guess]').forEach(function (b) { b.addEventListener('click', function () { state.guess = b.dataset.guess; state.answered = true; update(); Analytics.track(NAME, '判断', state.guess === info.toolSol.cls ? '对' : '错'); }); });
  $('nutRange').addEventListener('input', function () { setNut($('nutRange').value / 100); });
  $('nutRange').addEventListener('change', function () { Analytics.track(NAME, '调平衡螺母'); });
  $('tiltRange').addEventListener('input', function () { state.tilt = +$('tiltRange').value; update(); });
  $('sxRange').addEventListener('input', function () { var v = +$('sxRange').value; if (!v) v = state.sx > 0 ? -1 : 1; state.sx = v; update(); });
  $('oRange').addEventListener('input', function () { state.arm.o = $('oRange').value / 100; update(); });
  $('dirRange').addEventListener('input', function () { state.arm.dir = +$('dirRange').value; update(); });
  $('minBtn').addEventListener('click', function () { var m = V.minForce(state.arm); state.arm.p = m.p; state.arm.dir = m.dir; update(); Analytics.track(NAME, '最小动力'); });
  $('vertBtn').addEventListener('click', function () { state.arm.dir = -90; update(); });
  $('perpBtn').addEventListener('click', function () {
    var bar = Math.atan2(V.BAR.B[1] - V.BAR.A[1], V.BAR.B[0] - V.BAR.A[0]) * 180 / Math.PI, c = [bar + 90, bar - 90];
    var ok = c.filter(function (d) { return V.solveArm({ o: state.arm.o, p: state.arm.p, dir: d }).ok; });
    state.arm.dir = ((ok[0] != null ? ok[0] : c[1]) + 540) % 360 - 180; update();
  });
  $('recBtn').addEventListener('click', record);
  $('clearBtn').addEventListener('click', function () { state.dataBy[state.scene].length = 0; syncPanel(); Analytics.track(NAME, '清除数据'); });
  $('clearHooks').addEventListener('click', function () { state.hooks = {}; state.nutMoved = false; update(); });
  $('practice').addEventListener('click', function () { practice(); Analytics.track(NAME, '出题'); });
  $('showArms').addEventListener('change', function () { state.showArms = $('showArms').checked; });
  $('showLines').addEventListener('change', function () { state.showLines = $('showLines').checked; });
  $('quiz').addEventListener('change', function () { state.quiz = $('quiz').checked; state.answered = false; state.guess = null; update(); });

  // ---------- 面板开合 ----------
  $('panelToggle').addEventListener('click', function () { panel.classList.toggle('collapsed'); });
  if (window.matchMedia('(max-width: 760px)').matches) panel.classList.add('collapsed');
  if (window.matchMedia('(max-width: 640px)').matches) $('hint').hidden = true;

  function resize() { view.resize(stage.clientWidth, stage.clientHeight); }
  new ResizeObserver(resize).observe(stage);
  resize();

  // 演示数据：按教材的做法测三组
  function demo() {
    var keep = state.hooks;
    state.nut = V.NUTOK;
    if (state.scene === 'balance') [{ '-2': 3, '3': 2 }, { '-4': 2, '2': 4 }, { '-3': 1, '1': 3 }, { '-6': 2, '4': 3 }].forEach(function (c) {
      state.hooks = c; compute(); state.ang = 0; record();
    });
    if (state.scene === 'scale') [0, 30, 45, 60].forEach(function (t) { state.tilt = t; compute(); record(); });
    state.hooks = keep; state.tilt = 0;
  }

  // 支持 ?scene=balance|scale|arm|tools、&hooks=-2:3,3:2、&level=1、&nut=-1~1、&arms=0、&lines=0、&sx=±1~6、&tilt=-60~60、
  // &o=0.1~0.95、&p=0~1、&dir=度、&min=1、&tool=…、&quiz=1、&demo=1
  var qs = new URLSearchParams(location.search);
  loadScene(qs.get('scene') || 'balance');
  if (qs.get('demo') === '1') demo();
  if (qs.get('hooks') != null) {
    state.hooks = {};
    qs.get('hooks').split(',').forEach(function (s) {
      var m = /^(-?[1-6]):([1-6])$/.exec(s.trim());
      if (m) for (var i = 0; i < +m[2]; i++) addWeight(+m[1]);
    });
  }
  if (qs.get('level') === '1') state.nut = V.NUTOK;
  if (qs.get('nut') != null && isFinite(+qs.get('nut'))) state.nut = Math.max(-1, Math.min(1, +qs.get('nut')));
  if (qs.get('arms') === '0') state.showArms = false;
  if (qs.get('lines') === '0') state.showLines = false;
  if (/^-?[1-6]$/.test(qs.get('sx') || '')) state.sx = +qs.get('sx');
  if (qs.get('tilt') != null && isFinite(+qs.get('tilt'))) state.tilt = Math.max(-60, Math.min(60, +qs.get('tilt')));
  if (qs.get('o') != null && isFinite(+qs.get('o'))) state.arm.o = Math.max(0.1, Math.min(0.95, +qs.get('o')));
  if (qs.get('p') != null && isFinite(+qs.get('p'))) state.arm.p = Math.max(0, Math.min(1, +qs.get('p')));
  if (qs.get('dir') != null && isFinite(+qs.get('dir'))) state.arm.dir = +qs.get('dir');
  if (qs.get('min') === '1') { var m0 = V.minForce(state.arm); state.arm.p = m0.p; state.arm.dir = m0.dir; }
  if (V.TOOLS.some(function (t) { return t.id === qs.get('tool'); })) state.tool = qs.get('tool');
  if (qs.get('quiz') === '1') state.quiz = true;
  update();
  // 初始状态直接显示到位（不播放倾斜动画）
  state.ang = info.balanced ? 0 : (info.tau > 0 ? 1 : -1) * AMAX;

  var lastT = performance.now();
  function frame(t) {
    var dt = Math.min((t - lastT) / 1000, 0.1);
    lastT = t;
    if (state.scene === 'balance') {
      var target = info.balanced ? 0 : (info.tau > 0 ? 1 : -1) * AMAX, k = info.balanced ? 4 : 1.5 + Math.min(Math.abs(info.tau), 4);
      state.ang += (target - state.ang) * Math.min(1, dt * k);
      if (Math.abs(state.ang - target) < 1e-4) state.ang = target;
    }
    view.draw(state, info);
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // 调试用
  window.__model = { state: state, info: function () { return info; }, view: view, Lever: V, load: loadScene, update: update, record: record, demo: demo, setNut: setNut, practice: practice };
})();
