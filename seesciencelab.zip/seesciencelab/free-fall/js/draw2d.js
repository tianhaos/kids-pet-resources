/* 竖直运动实验台：计算比例的位置、等时频闪与有向速度面积。 */
(function(){'use strict';var ctx,W,H,geo;
var gold='#ffc94a',blue='#70cfff',muted='#91a4bc';
function line(x,y,X,Y,col,w,dash){ctx.beginPath();ctx.setLineDash(dash||[]);ctx.strokeStyle=col;ctx.lineWidth=w||1;ctx.moveTo(x,y);ctx.lineTo(X,Y);ctx.stroke();ctx.setLineDash([]);}
function text(s,x,y,col,size,align){ctx.fillStyle=col||muted;ctx.font=(size||12)+'px -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif';ctx.textAlign=align||'left';ctx.fillText(s,x,y);}
function ball(x,y,r,col,alpha){ctx.save();ctx.globalAlpha=alpha===undefined?1:alpha;var g=ctx.createRadialGradient(x-r*.35,y-r*.4,0,x,y,r);g.addColorStop(0,'#fff6d4');g.addColorStop(.35,col||gold);g.addColorStop(1,'#906028');ctx.fillStyle=g;ctx.shadowColor=col||gold;ctx.shadowBlur=r*.9;ctx.beginPath();ctx.arc(x,y,r,0,Math.PI*2);ctx.fill();ctx.shadowBlur=0;ctx.strokeStyle='#ffe7a099';ctx.stroke();ctx.restore();}
function arrow(x,y,dy,col,label){if(Math.abs(dy)<1){text('v = 0',x+6,y-4,col,12);return;}line(x,y,x,y+dy,col,2);var sign=Math.sign(dy);line(x,y+dy,x-4,y+dy-sign*7,col,2);line(x,y+dy,x+4,y+dy-sign*7,col,2);text(label,x+8,y+dy/2+4,col,11);}
function draw(canvas,s){ctx=canvas.getContext('2d');W=canvas.clientWidth;H=canvas.clientHeight;var d=Math.min(devicePixelRatio||1,2);if(canvas.width!==Math.round(W*d)||canvas.height!==Math.round(H*d)){canvas.width=Math.round(W*d);canvas.height=Math.round(H*d);}ctx.setTransform(d,0,0,d,0,0);ctx.clearRect(0,0,W,H);
var narrow=W<650,ground=narrow?H*.575:H-230,ceiling=narrow?Math.min(204,H*.30):190,max=Math.max(10,Flight.top(s)*1.18),scale=Math.max(1,(ground-ceiling)/max);
var left=narrow?57:76,right=narrow?W-48:W*.53,center=narrow?W*.41:(left+right)/2;
var P=narrow?{x:54,y:H*.69,w:W-90,h:H*.11}:{x:W*.64,y:H<740?200:226,w:W*.30,h:Math.min(285,Math.max(90,H-480))};
// 标尺与实验台；背景明暗只表现装置层次，不暗示空气阻力。
ctx.fillStyle='#05070d';ctx.fillRect(0,0,W,H);var glow=ctx.createRadialGradient(center,(ground+ceiling)/2,0,center,(ground+ceiling)/2,ground-ceiling);glow.addColorStop(0,'#101b2a');glow.addColorStop(1,'#05070d');ctx.fillStyle=glow;ctx.fillRect(left-25,ceiling-17,right-left+55,ground-ceiling+55);
ctx.fillStyle='#111b29';ctx.fillRect(left-12,ceiling-8,7,ground-ceiling+8);ctx.fillRect(right+14,ceiling-8,5,ground-ceiling+8);line(right+16,ceiling-8,right+16,ground,'#2c3a4d');
var step=max>100?40:max>50?20:max>25?10:5;for(var y=0;y<=max;y+=step){var py=ground-y*scale;line(left,py,right+5,py,'#263448',1,[2,6]);line(left-12,py,left-3,py,'#65758b');text(y+'',left-20,py+4,muted,11,'right');}
text('高度 / m ↑',left-13,ceiling-19,muted,11);line(center,ceiling,center,ground,'#344357',1,[3,5]);
ctx.fillStyle='#182230';ctx.fillRect(left-20,ground,right-left+55,11);line(left-20,ground,right+35,ground,'#768ba4',1.5);for(var i=left-12;i<right+29;i+=12)line(i,ground+11,i+6,ground+4,'#2c3b4d');
text('地面  y = 0',left-16,ground+28,muted,10);text('↑ 上升    ↓ 下降',right+20,ground+28,muted,10,'right');
var release=ground-s.h*scale,topY=ground-Flight.top(s)*scale;
line(left,release,right,release,'#718199',1,[5,5]);text('释放 '+s.h.toFixed(1)+' m',right,release-8,'#a7b6c9',10,'right');
if(s.scene==='throw'){line(center-21,topY,center+21,topY,'#647187',1);text('最高 '+Flight.top(s).toFixed(2)+' m',center+30,topY-18,'#b5c3d6',10);}
// 历史采样沿同一条竖直线，上升金色、下降蓝色；圆环不表示球的真实尺寸。
if(s.marks){for(var t=0;t<=s.t+1e-7;t+=s.interval){var mark=Flight.at(s,t);ctx.beginPath();ctx.arc(center,ground-mark.y*scale,4,0,Math.PI*2);ctx.strokeStyle=mark.v>=0?'#ffc94a99':'#70cfffaa';ctx.lineWidth=1.5;ctx.stroke();}}
ctx.strokeStyle='#93a8c1';ctx.lineWidth=1;ctx.strokeRect(center-9,release-9,18,18);
var q=Flight.at(s,s.t),bx=center,by=ground-q.y*scale;ctx.fillStyle='#0008';ctx.beginPath();ctx.ellipse(center,ground+4,16,3,0,0,Math.PI*2);ctx.fill();ball(bx,by,11,gold);
if(s.vectors){arrow(bx+25,by,Math.max(narrow?-44:-66,Math.min(narrow?44:66,-q.v*2.8)),gold,'v');arrow(bx+82,by,Math.min(narrow?38:52,s.g*4),blue,'a');}
text(q.y.toFixed(2)+' m',bx-17,by-13,'#f5de9e',12,'right');
if(!narrow){text('拖动小球 / 方框，改变释放高度',left-15,ground+58,muted,11);text('○ 等时间频闪   ·   上升金色 / 下降蓝色',left-15,ground+79,muted,11);}
// 速度图：未来虚线、已发生实线，时间轴上下分色以体现位移符号。
var T=Math.max(.1,Flight.duration(s)),v0=Flight.initial(s),vend=Flight.at(s,T).v,vmax=Math.max(4,v0,Math.abs(vend))*1.18;
function tx(t){return P.x+t/T*P.w;}function vy(v){return P.y+P.h/2-v/vmax*P.h/2;}
ctx.fillStyle='#0c111c';ctx.beginPath();ctx.roundRect(P.x-30,P.y-38,P.w+54,P.h+74,10);ctx.fill();text('速度 — 时间',P.x-12,P.y-17,'#dce5f0',12);text('v / m·s⁻¹',P.x+P.w+9,P.y-17,muted,10,'right');
[vmax/1.18,-vmax/1.18].forEach(function(v){line(P.x,vy(v),P.x+P.w,vy(v),'#1e2a3c');text(v.toFixed(0),P.x-8,vy(v)+3,muted,9,'right');});
[true,false].forEach(function(positive){ctx.save();ctx.beginPath();ctx.rect(P.x,positive?P.y:vy(0),P.w,P.h/2);ctx.clip();ctx.beginPath();ctx.moveTo(tx(0),vy(0));ctx.lineTo(tx(0),vy(v0));ctx.lineTo(tx(q.t),vy(q.v));ctx.lineTo(tx(q.t),vy(0));ctx.closePath();ctx.fillStyle=positive?'#ffc94a22':'#70cfff22';ctx.fill();ctx.restore();});
line(P.x,P.y,P.x,P.y+P.h,'#51647d');line(P.x,vy(0),P.x+P.w,vy(0),'#51647d');line(tx(0),vy(v0),tx(T),vy(vend),'#65758c',1.5,[4,5]);
line(tx(0),vy(v0),tx(q.t),vy(q.v),gold,2);line(tx(q.t),P.y,tx(q.t),P.y+P.h,'#91a4bc',1,[3,4]);ball(tx(q.t),vy(q.v),4,gold);
text('0',P.x-8,vy(0)+4,muted,9,'right');text('0',P.x,P.y+P.h+16,muted,10);text(T.toFixed(2)+' s',P.x+P.w,P.y+P.h+16,muted,10,'right');
if(!narrow){text('斜率 = −g',P.x-12,P.y+P.h+62,blue,13);text(s.scene==='throw'?'上升时减速，下降时加速':'从静止释放，下降时加速',P.x-12,P.y+P.h+86,muted,11);text(s.scene==='throw'?'最高点 v = 0，加速度依然向下':'刚释放时 v = 0，加速度已向下',P.x-12,P.y+P.h+109,'#d7e3f2',12);text('拖动图像探测 · 着色面积表示位移',P.x-12,P.y+P.h+138,muted,10);}else{text('拖图选时刻 · 面积为位移 · 斜率 = −g',P.x-12,P.y+P.h+32,muted,10);}
geo={ground:ground,scale:scale,center:center,bx:bx,by:by,plot:P,T:T};return geo;
}
window.FlightDraw={draw:draw,getGeometry:function(){return geo;}};
})();
