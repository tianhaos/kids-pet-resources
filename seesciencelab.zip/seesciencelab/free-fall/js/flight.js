/* 竖直向上为正；SI 单位；落地取接触前极限，不计算碰撞。 */
(function(){'use strict';
function initial(s){return s.scene==='fall'?0:s.v0;}
function duration(s){var v=initial(s);return (v+Math.sqrt(v*v+2*s.g*s.h))/s.g;}
function at(s,t){t=Math.max(0,Math.min(duration(s),t));var v=initial(s);return {t:t,y:Math.max(0,s.h+v*t-s.g*t*t/2),v:v-s.g*t,a:-s.g};}
function apex(s){return initial(s)/s.g;}
function top(s){var v=initial(s);return s.h+v*v/(2*s.g);}
function timesAtHeight(s,y){var v=initial(s),d=v*v+2*s.g*(s.h-y);if(d<0)return [];return [(v-Math.sqrt(d))/s.g,(v+Math.sqrt(d))/s.g].filter(function(t,i,a){return t>=0&&t<=duration(s)+1e-8&&(i===0||Math.abs(t-a[0])>1e-8);});}
window.Flight={initial:initial,duration:duration,at:at,apex:apex,top:top,timesAtHeight:timesAtHeight};
})();
