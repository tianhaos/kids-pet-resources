(function () {
  var N = window.Neutral;
  var $ = function (id) { return document.getElementById(id); };
  var qa = function (sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); };

  var state = {
    dir: 'base', acid: 'hcl', base: 'naoh', ind: 'pp', cBase: 0.10,
    rate: 0.3, ions: true, paper: true, labels: true,
    x: null, hover: null, initV: 0
  };
  var rec = null;

  var stage = $('labView'), canvas = $('neutral'), panel = $('panel');
  var view = window.NeutralDraw(canvas);
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)');
  var mobile = window.matchMedia('(max-width: 900px)');
  var pendingDrop = false;
  var lastSig = '';

  function setSeg(attr, val) {
    qa('[data-' + attr + ']').forEach(function (b) {
      var selected = b.dataset[attr] === String(val);
      b.classList.toggle('on', selected);
      b.setAttribute('aria-pressed', selected);
    });
  }
  function fmtV(v) { return v.toFixed(1) + ' mL'; }
  function fmtC(c) { return c.toFixed(2) + ' mol/L'; }
  function fmtMol(n) { return n < 0.01 ? '< 0.01' : n.toFixed(2); }

  // ---------- 记录 ----------
  function addRecord(m) {
    var x = state.x;
    if (rec.rows.length && rec.rows[rec.rows.length - 1].V >= m - 1e-9) return false;
    var p = N.pH(x, m);
    var ic = N.indicator(x, p);
    rec.rows.push({ V: m, pH: p, word: N.word(p), ind: ic.text, color: ic });
    return true;
  }

  // 滴入 dv mL；细分步长，保证每 1 mL 的记录和恰好反应点不被跳过
  function addVolume(dv, silent) {
    var x = state.x;
    if (!(dv > 0) || x.V >= N.VMAX - 1e-9) return false;
    var target = Math.min(N.VMAX, x.V + dv), prev = x.V, added = false, guard = 0;
    var ve = N.veq(x);
    while (x.V < target - 1e-9 && guard++ < 5000) {
      var step = Math.min(0.01, target - x.V);
      x.V += step;
      var from = Math.floor(prev + 1e-7), to = Math.floor(x.V + 1e-7);
      for (var m = from + 1; m <= to; m++) if (addRecord(m)) added = true;
      if (!rec.eqSeen && prev < ve - 1e-9 && x.V >= ve - 1e-9) rec.eqSeen = true;
      prev = x.V;
    }
    if (x.V >= N.VMAX - 1e-9) { x.V = N.VMAX; x.dropping = false; }
    if (added && !silent) syncTable();
    return added;
  }

  // ---------- 新的一次模拟 ----------
  function reset(v) {
    pendingDrop = false;
    state.dropHover = false;
    canvas.style.cursor = '';
    $('probe').textContent = '';
    state.x = N.create({
      dir: state.dir, acid: state.acid, base: state.base, ind: state.ind,
      cBase: state.cBase, cAcid: 0.10, V0: 10.0
    });
    state.hover = null;
    rec = { rows: [], eqSeen: false };
    view.resetIons(); view.resetDrops();
    addRecord(0);
    if (v > 0) {
      addVolume(v, true);
      if (!rec.eqSeen && v >= N.veq(state.x) - 1e-9) rec.eqSeen = true;
    }
    syncPanel();
    syncTable();
  }

  // ---------- 面板 ----------
  function processText() {
    var x = state.x, p = N.pH(x), ve = N.veq(x);
    if (N.word(p) === '中性') return '恰好中和 · H⁺ 与 OH⁻ 结合成水，此时 pH = 7。';
    if (Math.abs(x.V - ve) <= 0.050001) {
      return x.V < ve ? '接近中和 · 再单滴一次，观察 pH 和指示剂。'
        : '越过中和点 · 对照刚才的 pH 与指示剂颜色。';
    }
    return p < 7 ? '酸过量 · 烧杯中有剩余的 H⁺，pH < 7。' : '碱过量 · 烧杯中有剩余的 OH⁻，pH > 7。';
  }

  function syncPanel() {
    var x = state.x;
    setSeg('dir', state.dir);
    setSeg('acid', state.acid);
    setSeg('base', state.base);
    setSeg('ind', state.ind);
    $('cBase').value = state.cBase;
    $('cOut').textContent = fmtC(state.cBase);
    $('ionsChk').checked = state.ions;
    $('paperChk').checked = state.paper;
    $('labelsChk').checked = state.labels;

    var acid = N.ACIDS[state.acid], base = N.BASES[state.base];
    $('eqText').textContent = N.reaction(state.acid, state.base);
    $('saltText').textContent = '生成' + N.saltOf(state.acid, state.base).name + '和水。';
    $('rVeq').textContent = N.veq(x).toFixed(2) + ' mL';
    var dirText;
    if (state.dir === 'base') {
      dirText = '烧杯里是酸，滴管里是碱：pH 由小变大，';
      dirText += state.ind === 'pp' ? '酚酞由无色变红。'
        : state.ind === 'litmus' ? '石蕊由红变紫、再变蓝。'
        : '不加指示剂时，观察 pH 读数判断是否中和。';
    } else {
      dirText = '烧杯里是碱，滴管里是酸：pH 由大变小，';
      dirText += state.ind === 'pp' ? '酚酞由红色褪成无色。'
        : state.ind === 'litmus' ? '石蕊由蓝变紫、再变红。'
        : '不加指示剂时，观察 pH 读数判断是否中和。';
    }
    $('dirNote').textContent = dirText;
    $('mixNote').textContent = state.dir === 'base'
      ? '烧杯：10.0 mL ' + acid.name + '；滴管：' + base.name + '。'
      : '烧杯：10.0 mL ' + base.name + '；滴管：' + acid.name + '。';
    $('cNote').textContent = state.dir === 'base'
      ? '滴管中碱的浓度；酸的浓度固定为 0.10 mol/L。碱越浓，达到恰好反应所需的体积越小。'
      : '烧杯中碱的浓度；滴管中酸的浓度固定为 0.10 mol/L。';
    syncRate();
    lastSig = '';
    syncLive();
  }

  function syncRate() {
    setSeg('rate', state.rate);
    $('rateNote').textContent = state.rate.toFixed(2) + ' mL/s · 每滴按 0.05 mL 计';
  }

  function syncLive() {
    var x = state.x, p = N.pH(x), a = N.amounts(x), io = N.ions(x), ind = N.indicator(x, p);
    var sig = [p.toFixed(2), x.V.toFixed(3), ind.text, a.d.toFixed(3), x.dropping, pendingDrop].join('|');
    if (sig === lastSig) return;
    lastSig = sig;

    $('rPH').textContent = p.toFixed(2);
    var w = N.word(p);
    $('rKind').textContent = w;
    $('rKind').className = 'kind ' + (w === '酸性' ? 'acid' : w === '碱性' ? 'base' : 'neutral');
    $('rVol').textContent = x.V.toFixed(2) + ' mL';
    $('rDrops').textContent = Math.round(x.V / 0.05) + ' 滴';
    $('rExcess').textContent = w === '酸性' ? 'H⁺ 剩余 ' + fmtMol(a.d) + ' mmol'
      : w === '碱性' ? 'OH⁻ 剩余 ' + fmtMol(-a.d) + ' mmol' : '0（恰好完全反应）';
    $('indLabel').textContent = x.ind === 'none' ? '指示剂' : N.INDS[x.ind].name;
    $('rInd').textContent = x.ind === 'none' ? '未加' : ind.text;
    $('indSwatch').hidden = x.ind === 'none';
    $('indSwatch').style.background = ind.text === '无色'
      ? '#24384b' : 'rgba(' + ind.rgb.join(',') + ',' + ind.alpha + ')';
    var ionList = [];
    if (io.cat > 0.0005) ionList.push(io.catName);
    if (io.an > 0.0005) ionList.push(io.anName);
    if (io.h > 0.0005) ionList.push('H⁺');
    if (io.oh > 0.0005) ionList.push('OH⁻');
    $('rIon').textContent = ionList.join('、') || '—';
    $('rProc').textContent = processText();
    $('dropBtn').textContent = x.V >= N.VMAX - 1e-9 ? '已达上限' : x.dropping ? 'Ⅱ 暂停滴加' : '▶ 开始滴加';
    $('dropBtn').classList.toggle('hot', !x.dropping && x.V < N.VMAX - 1e-9);
    $('dropBtn').disabled = pendingDrop || x.V >= N.VMAX - 1e-9;
    $('singleBtn').disabled = pendingDrop || x.V >= N.VMAX - 1e-9;
    $('resetBtn').disabled = x.V <= 0 && !x.dropping && !pendingDrop;
  }

  function syncTable() {
    var rows = rec.rows;
    var head = '<tr><th>滴入 / mL</th><th>pH</th><th>溶液</th><th>指示剂</th></tr>';
    var body = rows.map(function (r) {
      var alpha = Math.max(0.35, r.color.alpha || 0);
      var dot = (r.color.key === 'none' || (r.color.alpha || 0) < 0.2)
        ? 'rgba(200,225,255,.18)' : 'rgba(' + r.color.rgb.join(',') + ',' + alpha + ')';
      return '<tr><td>' + r.V.toFixed(1) + '</td><td>' + r.pH.toFixed(2) + '</td><td>' + r.word +
        '</td><td><i class="dot" style="background:' + dot + '"></i>' + r.ind + '</td></tr>';
    }).join('');
    $('table').innerHTML = '<thead>' + head + '</thead><tbody>' + body + '</tbody>';
    var wrap = $('tableWrap');
    wrap.scrollTop = wrap.scrollHeight;
  }

  $('tableWrap').closest('details').addEventListener('toggle', function () {
    var wrap = $('tableWrap');
    if (this.open) wrap.scrollTop = wrap.scrollHeight;
  });

  // ---------- 操作 ----------
  function toggleDrop() {
    var x = state.x;
    if (pendingDrop || x.V >= N.VMAX - 1e-9) return;
    x.dropping = !x.dropping;
    if (x.dropping) Analytics.track('酸碱中和', '开始滴加', state.dir + '|' + state.ind);
    syncPanel();
  }
  $('dropBtn').addEventListener('click', toggleDrop);
  function singleDrop() {
    if (pendingDrop || state.x.V >= N.VMAX - 1e-9) return;
    Analytics.track('酸碱中和', '单滴', fmtV(state.x.V));
    if (reduce.matches) addVolume(0.05);
    else if (view.spawnDrop(state.x, !state.x.dropping) && !state.x.dropping) pendingDrop = true;
    syncLive();
  }
  $('singleBtn').addEventListener('click', singleDrop);
  $('nearBtn').addEventListener('click', function () {
    reset(N.veq(state.x) - 0.05);
    if (mobile.matches) setPanel(false, true);
    Analytics.track('酸碱中和', '中和前一滴', state.dir);
  });
  $('resetBtn').addEventListener('click', function () { reset(); Analytics.track('酸碱中和', '重置'); });

  qa('[data-rate]').forEach(function (b) {
    b.addEventListener('click', function () {
      state.rate = +b.dataset.rate;
      syncRate();
    });
  });

  qa('[data-dir]').forEach(function (b) {
    b.addEventListener('click', function () {
      if (state.dir === b.dataset.dir) return;
      state.dir = b.dataset.dir; reset();
      Analytics.track('酸碱中和', '滴加方向', state.dir);
    });
  });
  qa('[data-acid]').forEach(function (b) {
    b.addEventListener('click', function () {
      if (state.acid === b.dataset.acid) return;
      state.acid = b.dataset.acid; reset();
      Analytics.track('酸碱中和', '酸', N.ACIDS[state.acid].name);
    });
  });
  qa('[data-base]').forEach(function (b) {
    b.addEventListener('click', function () {
      if (state.base === b.dataset.base) return;
      state.base = b.dataset.base; reset();
      Analytics.track('酸碱中和', '碱', N.BASES[state.base].name);
    });
  });
  qa('[data-ind]').forEach(function (b) {
    b.addEventListener('click', function () {
      if (state.ind === b.dataset.ind) return;
      state.ind = b.dataset.ind; reset();
      Analytics.track('酸碱中和', '指示剂', N.INDS[state.ind].name);
    });
  });

  $('cBase').addEventListener('input', function () { $('cOut').textContent = fmtC(+this.value); });
  $('cBase').addEventListener('change', function () {
    state.cBase = +this.value; reset();
    Analytics.track('酸碱中和', '碱浓度', fmtC(state.cBase));
  });

  $('ionsChk').addEventListener('change', function () { state.ions = this.checked; if (state.ions) view.resetIons(); });
  $('paperChk').addEventListener('change', function () { state.paper = this.checked; });
  $('labelsChk').addEventListener('change', function () { state.labels = this.checked; });

  document.addEventListener('keydown', function (e) {
    if (/INPUT|SELECT|TEXTAREA|BUTTON/.test(e.target.tagName)) return;
    if (e.key === ' ') { e.preventDefault(); toggleDrop(); }
  });

  // ---------- 装置点按 / 曲线探测 ----------
  function canvasPoint(e) {
    var r = canvas.getBoundingClientRect();
    return [e.clientX - r.left, e.clientY - r.top];
  }
  function setProbe(value, announce) {
    state.hover = value;
    if (announce) $('probe').textContent = value
      ? '滴入 ' + value.V.toFixed(2) + ' mL，pH ' + N.pH(state.x, value.V).toFixed(2)
      : '';
  }
  canvas.addEventListener('pointermove', function (e) {
    if (e.pointerType === 'touch') return;
    var point = canvasPoint(e);
    var dropper = view.hitsDropper(point[0], point[1]);
    var graph = view.graphPoint(point[0], point[1]);
    state.dropHover = dropper && !$('singleBtn').disabled;
    canvas.style.cursor = state.dropHover ? 'pointer' : graph ? 'crosshair' : '';
    setProbe(graph, false);
  });
  canvas.addEventListener('click', function (e) {
    var point = canvasPoint(e);
    if (view.hitsDropper(point[0], point[1])) singleDrop();
    setProbe(view.graphPoint(point[0], point[1]), true);
  });
  canvas.addEventListener('pointerleave', function (e) {
    state.dropHover = false;
    if (e.pointerType !== 'touch') setProbe(null, false);
  });
  canvas.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') { setProbe(null, true); return; }
    if (e.key === 'Home') {
      e.preventDefault();
      setProbe({ V: N.veq(state.x) }, true);
      return;
    }
    if (e.key !== 'ArrowLeft' && e.key !== 'ArrowRight') return;
    e.preventDefault();
    var step = (e.shiftKey ? 0.05 : 1) * (e.key === 'ArrowLeft' ? -1 : 1);
    var v = state.hover ? state.hover.V + step : state.x.V;
    setProbe({ V: N.clamp(v, 0, N.VMAX) }, true);
  });

  // ---------- 手机控制抽屉 ----------
  function setPanel(open, focus) {
    panel.classList.toggle('collapsed', !open);
    panel.inert = !open;
    $('panelToggle').setAttribute('aria-expanded', open);
    if (focus) $(open ? 'panelClose' : 'panelToggle').focus();
  }
  $('panelToggle').addEventListener('click', function () { setPanel(panel.inert, true); });
  $('panelClose').addEventListener('click', function () { setPanel(false, true); });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && mobile.matches && !panel.inert) setPanel(false, true);
  });
  mobile.addEventListener('change', function () { setPanel(!mobile.matches); });
  setPanel(!mobile.matches);

  // ---------- 尺寸与主循环 ----------
  function resize() { view.resize(stage.clientWidth, stage.clientHeight); }
  new ResizeObserver(resize).observe(stage);
  resize();

  // URL 参数：?dir=base|acid、?acid=hcl|h2so4、?base=naoh|koh、?ind=pp|litmus|none、
  // ?c=0.10、?v=10、?rate=0.3、?ions=0、?paper=0、?labels=0
  var qs = new URLSearchParams(location.search);
  if (qs.get('dir') === 'acid' || qs.get('dir') === 'base') state.dir = qs.get('dir');
  if (N.ACIDS[qs.get('acid')]) state.acid = qs.get('acid');
  if (N.BASES[qs.get('base')]) state.base = qs.get('base');
  if (N.INDS[qs.get('ind')]) state.ind = qs.get('ind');
  if (qs.get('c') != null && isFinite(+qs.get('c'))) state.cBase = N.clamp(+qs.get('c'), 0.08, 0.20);
  if (qs.get('rate') != null && isFinite(+qs.get('rate'))) state.rate = N.clamp(+qs.get('rate'), 0.05, 1.2);
  if (qs.get('v') != null && isFinite(+qs.get('v'))) state.initV = N.clamp(+qs.get('v'), 0, N.VMAX);
  if (qs.get('ions') === '0') state.ions = false;
  if (qs.get('paper') === '0') state.paper = false;
  if (qs.get('labels') === '0') state.labels = false;
  state.rate = [0.05, 0.3, 1.2].reduce(function (best, r) { return Math.abs(r - state.rate) < Math.abs(best - state.rate) ? r : best; }, 0.3);

  reset(state.initV);
  if (qs.get('play') === '1') { state.x.dropping = true; syncPanel(); }

  var last = performance.now();
  function frame(t) {
    var dt = Math.min((t - last) / 1000, 0.1);
    last = t;
    var dV = 0;
    if (state.x.dropping && state.x.V < N.VMAX - 1e-9) {
      dV = state.rate * dt;
    }
    var landed = view.animateDrops(state, dt, dV, reduce.matches);
    if (landed.manual) pendingDrop = false;
    if (landed.count) addVolume(landed.count * 0.05);
    syncLive();
    view.draw(state, reduce.matches ? 0 : dt);
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // 调试句柄
  window.__model = { state: state, view: view, reset: reset, addVolume: addVolume, N: N };
})();
