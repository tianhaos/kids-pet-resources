// 酸碱中和绘图：胶头滴管与烧杯、pH 试纸比色卡、溶液中的离子示意、pH—滴入体积图像
// 传入的 st 是 main.js 的 state（含 st.x 化学状态、st.labels / st.paper / st.ions / st.hover）
(function () {
  var N = window.Neutral;
  var PI = Math.PI, TAU = PI * 2;
  var C = {
    text: '#e6ebf2', muted: '#a9b8cc', line: '#253447',
    accent: '#ffc94a', acid: '#ff947d', base: '#65d0ff', neutral: '#8ae49e',
    h: '#ff6b6b', oh: '#4fc3f7', cat: '#ffc94a', an: '#7ee081',
    glass: 'rgba(183,213,237,.75)', glassFill: 'rgba(160,200,255,.08)'
  };
  var VW = 460, VH = 352;          // 装置图的虚拟尺寸
  var BX = 150, BY = 172, BW = 180, BH = 142, BB = BY + BH;   // 烧杯
  var IL = BX + 8, IR = BX + BW - 8, IB = BB - 6, CAP = 50;   // 内壁与容量（mL）
  var TIP_Y = 135;                 // 滴管尖
  var ION_UNIT = 0.12, ION_MAX = 20;
  var ION_COL = { h: C.h, oh: C.oh, cat: C.cat, an: C.an };

  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
  function rng(seed) {
    return function () {
      seed |= 0; seed = seed + 0x6D2B79F5 | 0;
      var t = Math.imul(seed ^ seed >>> 15, 1 | seed);
      t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
      return ((t ^ t >>> 14) >>> 0) / 4294967296;
    };
  }

  function NeutralDraw(canvas) {
    var ctx = canvas.getContext('2d');
    var W = 1, H = 1, dpr = 1, narrow = false;
    var haloW = 3, plotRect = null, apparatus = null, appScale = 1;
    var curveState = null, curve = [], equivalence = null;
    var drops = [], ripples = [], flashes = [];
    var ionP = { h: [], oh: [], cat: [], an: [] };
    var ionSig = '', ionSeed = 7, dropAcc = 0;

    function resize(w, h) {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      W = w; H = h;
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
      canvas.style.width = w + 'px'; canvas.style.height = h + 'px';
      narrow = w < 640;
      apparatus = null; plotRect = null; equivalence = null;
    }
    function font(size, weight) {
      ctx.font = (weight || '') + ' ' + size + 'px -apple-system, "PingFang SC", "Microsoft YaHei", sans-serif';
    }
    function label(str, x, y, color, align, size, weight, halo) {
      font(size, weight);
      ctx.textAlign = align || 'center'; ctx.textBaseline = 'middle';
      if (halo !== false) { ctx.lineWidth = haloW; ctx.strokeStyle = 'rgba(5,7,13,0.82)'; ctx.strokeText(str, x, y); }
      ctx.fillStyle = color; ctx.fillText(str, x, y);
    }
    function rrect(x, y, w, h, r) {
      ctx.beginPath();
      if (ctx.roundRect) ctx.roundRect(x, y, w, h, r);
      else {
        ctx.moveTo(x + r, y); ctx.lineTo(x + w - r, y); ctx.quadraticCurveTo(x + w, y, x + w, y + r);
        ctx.lineTo(x + w, y + h - r); ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
        ctx.lineTo(x + r, y + h); ctx.quadraticCurveTo(x, y + h, x, y + h - r);
        ctx.lineTo(x, y + r); ctx.quadraticCurveTo(x, y, x + r, y); ctx.closePath();
      }
    }

    // ---------- 布局 ----------
    function layout() {
      var gap = narrow ? 8 : 12;
      if (W >= 700) {
        var aw = Math.round(W * 0.48);
        return { app: { x: 0, y: 0, w: aw, h: H }, graph: { x: aw + gap, y: 0, w: W - aw - gap, h: H } };
      }
      var ah = Math.round(Math.min(H * 0.58, W * 0.84));
      return { app: { x: 0, y: 0, w: W, h: ah }, graph: { x: 0, y: ah + gap, w: W, h: H - ah - gap } };
    }

    function drawCard(box, title) {
      rrect(box.x + 0.5, box.y + 0.5, box.w - 1, box.h - 1, 12);
      ctx.fillStyle = 'rgba(13,20,32,.8)'; ctx.fill();
      ctx.strokeStyle = C.line; ctx.lineWidth = 1; ctx.stroke();
      label(title, box.x + 13, box.y + 19, C.accent, 'left', narrow ? 16 : 18, '600', false);
    }

    // ---------- 溶液状态 ----------
    function surfaceY(x) {
      var frac = clamp((x.V0 + x.V) / CAP, 0, 1);
      return IB - (IB - (BY + 10)) * frac;
    }
    function titrant(x) {
      if (x.dir === 'base') return { name: N.BASES[x.base].name, short: N.BASES[x.base].short, tint: N.BASES[x.base].tint };
      return { name: N.ACIDS[x.acid].name, short: N.ACIDS[x.acid].short, tint: N.ACIDS[x.acid].tint };
    }
    function beakerName(x) {
      return x.dir === 'base' ? N.ACIDS[x.acid].short : N.BASES[x.base].short;
    }

    // ---------- 装置 ----------
    function drawApparatus(box, st, dt) {
      var x = st.x;
      drawCard(box, '滴加装置');
      var k = Math.min((box.w - 10) / VW, (box.h - 42) / VH);
      appScale = k;
      var ox = box.x + (box.w - VW * k) / 2, oy = box.y + 35 + (box.h - 39 - VH * k) / 2;
      apparatus = { x: ox, y: oy, k: k };
      ctx.save();
      ctx.translate(ox, oy); ctx.scale(k, k);
      haloW = 3 / k;
      var lw = 1.35 / k, thin = 1 / k;
      var fs = function (px) { return Math.max(px, 10.5 / k); };

      var bench = ctx.createLinearGradient(0, 305, 0, 338);
      bench.addColorStop(0, '#192536'); bench.addColorStop(1, 'rgba(19,31,47,0)');
      ctx.fillStyle = bench;
      ctx.fillRect(16, 307, VW - 32, 31);
      ctx.strokeStyle = 'rgba(141,169,200,.24)'; ctx.lineWidth = thin;
      ctx.beginPath(); ctx.moveTo(16, 307); ctx.lineTo(VW - 16, 307); ctx.stroke();
      ctx.fillStyle = 'rgba(0,0,0,.44)';
      ctx.beginPath(); ctx.ellipse(BX + BW / 2, BB + 5, BW * 0.52, 10, 0, 0, TAU); ctx.fill();

      drawBeaker(x, st, dt, lw, thin, fs);
      drawDropper(x, st, lw, thin);
      drawPaper(x, st, thin, fs);
      drawIonPanel(x, st, dt, thin, fs);

      if (st.labels !== false) {
        ctx.strokeStyle = 'rgba(141,169,200,.46)'; ctx.lineWidth = thin;
        ctx.beginPath(); ctx.moveTo(273, 46); ctx.lineTo(297, 46); ctx.stroke();
        label('胶头滴管 · 点按单滴', 305, 46, C.text, 'left', fs(12), '600');
        label(titrant(x).name, 305, 65, C.muted, 'left', fs(11));
        label('烧杯 · ' + x.V0.toFixed(1) + ' mL ' + beakerName(x) + (x.ind === 'none' ? '' : ' + ' + N.INDS[x.ind].name), 240, 337, C.muted, 'center', fs(11));
      }
      ctx.restore();
      haloW = 3;
    }

    function drawDropper(x, st, lw, thin) {
      var t = titrant(x);
      var squeeze = 1 + (drops.length ? .08 * Math.max(0, 1 - (drops[drops.length - 1].y - TIP_Y) / 20) : 0);
      if (st.dropHover) {
        var glow = ctx.createRadialGradient(240, 36, 9, 240, 36, 51);
        glow.addColorStop(0, 'rgba(255,201,74,.26)'); glow.addColorStop(1, 'rgba(255,201,74,0)');
        ctx.fillStyle = glow; ctx.fillRect(188, 0, 104, 88);
      }
      ctx.save();
      ctx.translate(240, 34);
      ctx.scale(squeeze, 1 / squeeze);
      var rubber = ctx.createLinearGradient(-25, -22, 24, 22);
      rubber.addColorStop(0, '#d98777'); rubber.addColorStop(.42, '#a95856'); rubber.addColorStop(1, '#482632');
      ctx.fillStyle = rubber;
      ctx.beginPath();
      ctx.moveTo(-16, 24); ctx.bezierCurveTo(-33, 13, -28, -26, 0, -27);
      ctx.bezierCurveTo(28, -26, 33, 13, 16, 24);
      ctx.quadraticCurveTo(0, 29, -16, 24); ctx.closePath(); ctx.fill();
      ctx.strokeStyle = st.dropHover ? C.accent : 'rgba(255,170,155,.42)'; ctx.lineWidth = thin; ctx.stroke();
      ctx.strokeStyle = 'rgba(255,200,184,.24)'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(-18, 1); ctx.quadraticCurveTo(-20, -16, -6, -20); ctx.stroke();
      ctx.restore();
      rrect(225, 55, 30, 10, 3);
      ctx.fillStyle = '#80484b'; ctx.fill();
      ctx.strokeStyle = 'rgba(255,162,153,.55)'; ctx.lineWidth = thin; ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(231, 65); ctx.lineTo(231, 109); ctx.lineTo(236, 126); ctx.lineTo(240, TIP_Y);
      ctx.lineTo(244, 126); ctx.lineTo(249, 109); ctx.lineTo(249, 65); ctx.closePath();
      ctx.fillStyle = C.glassFill; ctx.fill();
      ctx.strokeStyle = C.glass; ctx.lineWidth = lw; ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(234, 85); ctx.quadraticCurveTo(240, 89, 246, 85);
      ctx.lineTo(246, 109); ctx.lineTo(242, 125); ctx.lineTo(240, 130);
      ctx.lineTo(238, 125); ctx.lineTo(234, 109); ctx.closePath();
      ctx.fillStyle = t.tint; ctx.fill();
      ctx.strokeStyle = 'rgba(240,249,255,.66)'; ctx.lineWidth = thin;
      ctx.beginPath(); ctx.moveTo(234, 69); ctx.lineTo(234, 81); ctx.stroke();

      ctx.fillStyle = t.tint;
      for (var i = drops.length - 1; i >= 0; i--) {
        var d = drops[i];
        ctx.beginPath();
        ctx.moveTo(d.x, d.y - 6); ctx.bezierCurveTo(d.x - 10, d.y + 6, d.x + 10, d.y + 6, d.x, d.y - 6);
        ctx.fill();
      }
    }

    function drawBeaker(x, st, dt, lw, thin, fs) {
      var surf = surfaceY(x);
      var ind = N.indicator(x);

      var glass = ctx.createLinearGradient(BX, 0, BX + BW, 0);
      glass.addColorStop(0, 'rgba(180,220,248,.18)'); glass.addColorStop(.14, 'rgba(178,220,245,.05)');
      glass.addColorStop(.8, 'rgba(175,211,242,.025)'); glass.addColorStop(1, 'rgba(171,217,251,.15)');
      rrect(BX, BY, BW, BH, 12);
      ctx.fillStyle = glass; ctx.fill();

      liquidPath(surf);
      var liquid = ctx.createLinearGradient(IL, surf, IR, IB);
      liquid.addColorStop(0, 'rgba(126,176,215,.27)');
      liquid.addColorStop(1, 'rgba(79,118,164,.09)');
      ctx.fillStyle = liquid; ctx.fill();
      ctx.fillStyle = ind.text === '无色' ? 'transparent' : ind.css; ctx.fill();

      ctx.beginPath(); ctx.ellipse(BX + BW / 2, surf, (IR - IL) / 2, 4.5, 0, 0, TAU);
      ctx.fillStyle = 'rgba(200,225,255,.16)'; ctx.fill();
      if (ind.text !== '无色') { ctx.fillStyle = ind.css; ctx.fill(); }
      ctx.strokeStyle = ind.text === '无色' ? 'rgba(184,221,247,.62)' : 'rgba(' + ind.rgb.join(',') + ',.94)';
      ctx.lineWidth = lw; ctx.stroke();

      for (var r = ripples.length - 1; r >= 0; r--) {
        var rp = ripples[r];
        ctx.beginPath(); ctx.ellipse(rp.x, surf, rp.r, rp.r * 0.28, 0, 0, TAU);
        ctx.strokeStyle = 'rgba(200,225,255,' + (0.4 * (1 - rp.life)).toFixed(3) + ')'; ctx.lineWidth = thin; ctx.stroke();
        rp.r += 26 * dt; rp.life += dt * 2.2;
        if (rp.life >= 1) ripples.splice(r, 1);
      }

      ctx.strokeStyle = 'rgba(200,225,255,0.35)'; ctx.lineWidth = 7; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(179, 146); ctx.lineTo(207, IB - 10); ctx.stroke();
      ctx.strokeStyle = 'rgba(255,255,255,0.5)'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(177, 148); ctx.lineTo(204, IB - 13); ctx.stroke();
      ctx.lineCap = 'butt';

      ctx.strokeStyle = C.glass; ctx.lineWidth = lw;
      ctx.beginPath();
      ctx.moveTo(BX, BY); ctx.lineTo(BX, BB - 8);
      ctx.quadraticCurveTo(BX, BB, BX + 8, BB); ctx.lineTo(BX + BW - 8, BB);
      ctx.quadraticCurveTo(BX + BW, BB, BX + BW, BB - 8); ctx.lineTo(BX + BW, BY);
      ctx.stroke();
      ctx.beginPath(); ctx.ellipse(BX + BW / 2, BY, BW / 2, 7, 0, 0, TAU); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(BX + 1, BY - 2); ctx.lineTo(BX - 8, BY - 7); ctx.quadraticCurveTo(BX - 9, BY, BX + 4, BY + 5); ctx.stroke();
      ctx.strokeStyle = 'rgba(220,240,255,.25)'; ctx.lineWidth = thin;
      ctx.beginPath(); ctx.moveTo(BX + 9, BY + 14); ctx.lineTo(BX + 9, IB - 13); ctx.stroke();

      ctx.strokeStyle = 'rgba(200,225,255,0.35)'; ctx.lineWidth = thin;
      [[20, 0.6], [30, 0.8], [40, 1.0], [50, 1.2]].forEach(function (m) {
        var y = IB - (IB - (BY + 10)) * (m[0] / CAP);
        ctx.beginPath(); ctx.moveTo(BX + BW - 18, y); ctx.lineTo(BX + BW - 6, y); ctx.stroke();
        if (m[0] === 20 || m[0] === 50) label(m[0] + ' mL', BX + BW - 21, y, 'rgba(200,225,255,0.5)', 'right', fs(9), '', false);
      });


    }

    function liquidPath(surf) {
      ctx.beginPath();
      ctx.moveTo(IL, surf);
      ctx.lineTo(IL, IB - 7);
      ctx.quadraticCurveTo(IL, IB, IL + 7, IB);
      ctx.lineTo(IR - 7, IB);
      ctx.quadraticCurveTo(IR, IB, IR, IB - 7);
      ctx.lineTo(IR, surf);
      ctx.closePath();
    }

    // ---------- pH 试纸比色卡 ----------
    function drawPaper(x, st, thin, fs) {
      if (st.paper === false) return;
      var px = 344, py = 151, pw = 113, ph = 166;
      rrect(px, py, pw, ph, 8);
      ctx.fillStyle = 'rgba(17,23,35,0.8)'; ctx.fill();
      ctx.strokeStyle = C.line; ctx.lineWidth = thin; ctx.stroke();
      label('pH 试纸比色卡', px + pw / 2, py + 13, C.muted, 'center', fs(10));

      var top = py + 28, bot = py + ph - 10, sh = (bot - top) / 14;
      for (var i = 1; i <= 14; i++) {
        ctx.fillStyle = N.paperColor(i);
        ctx.fillRect(px + 8, top + (i - 1) * sh, 15, sh + 0.6);
        if (i === 1 || i === 4 || i === 7 || i === 10 || i === 14) {
          label(String(i), px + 28, top + (i - 0.5) * sh, C.muted, 'left', fs(9));
        }
      }
      var p = N.pH(x);
      var yy = top + (clamp(p, 1, 14) - 0.5) * sh;
      ctx.strokeStyle = C.accent; ctx.lineWidth = 1.6 / appScale;
      ctx.beginPath(); ctx.moveTo(px + 4, yy); ctx.lineTo(px + 28, yy); ctx.stroke();
      ctx.fillStyle = C.accent;
      ctx.beginPath(); ctx.moveTo(px + 4, yy); ctx.lineTo(px + 11, yy - 4); ctx.lineTo(px + 11, yy + 4); ctx.closePath(); ctx.fill();
      rrect(px + 62, top + 14, 13, 82, 2);
      ctx.fillStyle = '#e1d4b8'; ctx.fill();
      rrect(px + 62, top + 81, 13, 15, 2);
      ctx.fillStyle = N.paperColor(p); ctx.fill();
    }

    // ---------- 离子示意 ----------
    function drawIonPanel(x, st, dt, thin, fs) {
      if (st.ions === false) return;
      var ix = 4, iy = 143, iw = 135, ih = 174;
      rrect(ix, iy, iw, ih, 10);
      ctx.fillStyle = 'rgba(17,23,35,0.78)'; ctx.fill();
      ctx.strokeStyle = C.line; ctx.lineWidth = thin; ctx.stroke();
      label('离子示意', ix + iw / 2, iy + 14, C.text, 'center', fs(10), '600');

      var lg = [
        { k: 'h', n: 'H⁺', x: ix + 10, y: iy + 32 },
        { k: 'oh', n: 'OH⁻', x: ix + 76, y: iy + 32 },
        { k: 'cat', n: N.BASES[x.base].cation, x: ix + 10, y: iy + 47 },
        { k: 'an', n: N.ACIDS[x.acid].anion, x: ix + 76, y: iy + 47 }
      ];
      lg.forEach(function (it) {
        ctx.fillStyle = ION_COL[it.k];
        ctx.beginPath(); ctx.arc(it.x + 3, it.y, 3, 0, TAU); ctx.fill();
        label(it.n, it.x + 10, it.y, C.muted, 'left', fs(9), '', false);
      });

      var fx = ix + 7, fy = iy + 55, fw = iw - 14, fh = ih - 55 - 24;
      rrect(fx, fy, fw, fh, 6);
      ctx.fillStyle = 'rgba(5,7,13,0.42)'; ctx.fill();
      ctx.strokeStyle = 'rgba(42,52,70,0.8)'; ctx.lineWidth = thin; ctx.stroke();

      var sig = x.dir + '|' + x.acid + '|' + x.base;
      if (sig !== ionSig) { ionSig = sig; ionP = { h: [], oh: [], cat: [], an: [] }; ionSeed += 13; }

      var io = N.ions(x);
      var targets = {
        h: Math.min(ION_MAX, Math.round(io.h / ION_UNIT)),
        oh: Math.min(ION_MAX, Math.round(io.oh / ION_UNIT)),
        cat: Math.min(ION_MAX, Math.round(io.cat / ION_UNIT)),
        an: Math.min(ION_MAX, Math.round(io.an / ION_UNIT))
      };
      var consumeKey = x.dir === 'base' ? 'h' : 'oh';
      if (dt && ionP[consumeKey].length > targets[consumeKey]) {
        for (var c = 0; c < Math.min(ionP[consumeKey].length - targets[consumeKey], 4); c++) {
          var p0 = ionP[consumeKey].pop();
          if (p0) flashes.push({ x: p0.x, y: p0.y, life: 0 });
        }
      }
      Object.keys(targets).forEach(function (key) { syncSpecies(key, targets[key], fx, fy, fw, fh, x); });

      var dtc = Math.min(dt, 0.05);
      Object.keys(ionP).forEach(function (key) {
        var arr = ionP[key];
        for (var i = 0; i < arr.length; i++) {
          var p = arr[i];
          p.x += p.vx * dtc; p.y += p.vy * dtc;
          if (p.x < fx + 5) { p.x = fx + 5; p.vx = Math.abs(p.vx); }
          if (p.x > fx + fw - 5) { p.x = fx + fw - 5; p.vx = -Math.abs(p.vx); }
          if (p.y < fy + 5) { p.y = fy + 5; p.vy = Math.abs(p.vy); }
          if (p.y > fy + fh - 5) { p.y = fy + fh - 5; p.vy = -Math.abs(p.vy); }
          var isReact = key === 'h' || key === 'oh';
          var rr = isReact ? 3.4 : 2.7;
          ctx.globalAlpha = isReact ? 0.95 : 0.8;
          ctx.fillStyle = ION_COL[key];
          ctx.beginPath(); ctx.arc(p.x, p.y, rr, 0, TAU); ctx.fill();
          ctx.globalAlpha = 1;
          if (isReact) {
            ctx.strokeStyle = 'rgba(5,7,13,0.85)'; ctx.lineWidth = 0.9;
            ctx.beginPath();
            ctx.moveTo(p.x - 1.7, p.y); ctx.lineTo(p.x + 1.7, p.y);
            if (key === 'h') { ctx.moveTo(p.x, p.y - 1.7); ctx.lineTo(p.x, p.y + 1.7); }
            ctx.stroke();
          }
        }
      });
      for (var f = flashes.length - 1; f >= 0; f--) {
        var fl = flashes[f];
        fl.life += dt * 1.8;
        if (fl.life >= 1) { flashes.splice(f, 1); continue; }
        ctx.strokeStyle = 'rgba(255,255,255,' + (0.5 * (1 - fl.life)).toFixed(3) + ')';
        ctx.lineWidth = 1.2;
        ctx.beginPath(); ctx.arc(fl.x, fl.y, 4 + fl.life * 9, 0, TAU); ctx.stroke();
        label('H₂O', fl.x, fl.y - 11 - fl.life * 6, 'rgba(230,235,242,' + (1 - fl.life).toFixed(2) + ')', 'center', fs(9), '', false);
      }
      label('H⁺ + OH⁻ → H₂O', ix + iw / 2, iy + ih - 11, C.muted, 'center', fs(9.5), '', false);
    }

    function syncSpecies(key, target, fx, fy, fw, fh, x) {
      var arr = ionP[key];
      while (arr.length > target) arr.pop();
      var entersWithDrop = key === 'h' || key === 'oh' || key === (x.dir === 'base' ? 'cat' : 'an');
      var fromTop = entersWithDrop && x.dropping;
      var r = rng(ionSeed + arr.length * 31 + key.charCodeAt(0) * 7);
      while (arr.length < target) {
        var sp = 12 + r() * 8;
        arr.push({
          x: fx + 6 + r() * (fw - 12),
          y: fromTop ? fy + 4 + r() * 8 : fy + 6 + r() * (fh - 12),
          vx: (r() < 0.5 ? -1 : 1) * sp,
          vy: (r() - 0.5) * sp
        });
      }
    }

    // ---------- 图像 ----------
    function phY(p, g) { return g.y + g.h * (1 - p / 14); }
    function vX(v, g) { return g.x + g.w * v / N.VMAX; }

    function curvePoints(x) {
      if (curveState === x) return curve;
      var ve = N.veq(x);
      var volumes = Array.from({ length: 181 }, function (_, i) { return i * N.VMAX / 180; });
      volumes.push(ve);
      for (var offset = .2; offset >= 1e-6; offset /= 2) {
        volumes.push(ve - offset, ve + offset);
      }
      curveState = x;
      curve = volumes.filter(function (v) { return v >= 0 && v <= N.VMAX; })
        .sort(function (a, b) { return a - b; })
        .map(function (v) { return { v: v, p: N.pH(x, v) }; });
      return curve;
    }

    function drawGraph(box, st) {
      var x = st.x;
      drawCard(box, 'pH 曲线');
      var probe = st.hover;
      var tip = probe ? probe.V.toFixed(2) + ' mL · pH ' + N.pH(x, probe.V).toFixed(2) : '悬停或点按探测';
      label(tip, box.x + box.w - 13, box.y + 19, probe ? C.text : C.muted, 'right', 11, '', false);

      var padL = narrow ? 29 : 39, padR = narrow ? 15 : 22, padT = 43, padB = 37;
      var g = { x: box.x + padL, y: box.y + padT, w: box.w - padL - padR, h: box.h - padT - padB };
      if (g.w < 80 || g.h < 55) { plotRect = null; return; }
      plotRect = g;

      var axisSize = narrow ? 10 : 11;

      ctx.fillStyle = 'rgba(79,195,247,0.045)';
      ctx.fillRect(g.x, g.y, g.w, phY(7, g) - g.y);
      ctx.fillStyle = 'rgba(255,138,101,0.045)';
      ctx.fillRect(g.x, phY(7, g), g.w, g.y + g.h - phY(7, g));

      ctx.strokeStyle = 'rgba(255,255,255,0.065)'; ctx.lineWidth = 1;
      for (var p = 0; p <= 14; p += 2) {
        if (g.h < 185 && p !== 0 && p !== 14) continue;
        var y = phY(p, g);
        ctx.beginPath(); ctx.moveTo(g.x, y); ctx.lineTo(g.x + g.w, y); ctx.stroke();
        label(String(p), g.x - 7, y, C.muted, 'right', axisSize, '', false);
      }
      var xStep = g.w > 420 ? 5 : 10;
      for (var v = 0; v <= N.VMAX; v += xStep) {
        var xp = vX(v, g);
        ctx.beginPath(); ctx.moveTo(xp, g.y); ctx.lineTo(xp, g.y + g.h); ctx.stroke();
        label(String(v), xp, g.y + g.h + 11, C.muted, 'center', axisSize, '', false);
      }
      ctx.strokeStyle = 'rgba(255,255,255,0.3)'; ctx.lineWidth = 1; ctx.setLineDash([5, 4]);
      ctx.beginPath(); ctx.moveTo(g.x, phY(7, g)); ctx.lineTo(g.x + g.w, phY(7, g)); ctx.stroke();
      ctx.setLineDash([]);
      label('pH 7 中性', g.x + g.w - 4, phY(7, g) + 10, 'rgba(230,235,242,0.55)', 'right', axisSize, '', false);

      var ind = N.INDS[x.ind];
      if (ind.range) {
        var ya = phY(ind.range[1], g), yb = phY(ind.range[0], g);
        var ic = N.indicator(x, (ind.range[0] + ind.range[1]) / 2);
        ctx.fillStyle = 'rgba(' + ic.rgb.join(',') + ',0.10)';
        ctx.fillRect(g.x, ya, g.w, yb - ya);
        ctx.fillStyle = ic.css;
        ctx.fillRect(g.x + g.w - 4, ya, 4, yb - ya);
        label(ind.name + '变色 ' + ind.rangeText, g.x + g.w - 5, ya + (narrow ? -7 : -9), C.muted, 'right', axisSize, '', false);
      }

      ctx.save();
      ctx.beginPath(); ctx.rect(g.x, g.y, g.w, g.h); ctx.clip();
      ctx.lineCap = 'round'; ctx.lineJoin = 'round';
      ctx.beginPath();
      curvePoints(x).forEach(function (point, i) {
        var xp = vX(point.v, g), yp = phY(point.p, g);
        if (i) ctx.lineTo(xp, yp);
        else ctx.moveTo(xp, yp);
      });
      ctx.strokeStyle = 'rgba(165,214,255,.13)'; ctx.lineWidth = 7; ctx.stroke();
      var series = ctx.createLinearGradient(0, g.y, 0, g.y + g.h);
      series.addColorStop(.49, C.base); series.addColorStop(.5, C.neutral); series.addColorStop(.51, C.acid);
      ctx.strokeStyle = series; ctx.lineWidth = 2.4; ctx.stroke();
      ctx.restore();

      var ve = N.veq(x);
      equivalence = null;
      if (ve > 0 && ve <= N.VMAX) {
        var xe = vX(ve, g);
        equivalence = { x: xe, y: phY(7, g), v: ve };
        ctx.strokeStyle = 'rgba(126,224,129,0.55)'; ctx.lineWidth = 1; ctx.setLineDash([3, 4]);
        ctx.beginPath(); ctx.moveTo(xe, phY(7, g)); ctx.lineTo(xe, g.y + g.h); ctx.stroke();
        ctx.setLineDash([]);
        ctx.strokeStyle = C.neutral; ctx.lineWidth = 1.5;
        ctx.beginPath(); ctx.arc(xe, phY(7, g), 4, 0, TAU); ctx.stroke();

      }

      var cp = N.pH(x);
      var cx = vX(x.V, g), cy = phY(cp, g);
      ctx.strokeStyle = 'rgba(255,201,74,0.35)'; ctx.lineWidth = 1; ctx.setLineDash([2, 3]);
      ctx.beginPath(); ctx.moveTo(cx, g.y + g.h); ctx.lineTo(cx, cy); ctx.stroke();
      ctx.setLineDash([]);
      ctx.fillStyle = 'rgba(255,201,74,0.16)';
      ctx.beginPath(); ctx.arc(cx, cy, 9, 0, TAU); ctx.fill();
      ctx.fillStyle = C.accent;
      ctx.beginPath(); ctx.arc(cx, cy, 4.5, 0, TAU); ctx.fill();


      if (st.hover != null) {
        var hv = clamp(st.hover.V, 0, N.VMAX), hp = N.pH(x, hv);
        var hx = vX(hv, g), hy = phY(hp, g);
        ctx.strokeStyle = 'rgba(230,235,242,0.35)'; ctx.lineWidth = 1; ctx.setLineDash([3, 3]);
        ctx.beginPath(); ctx.moveTo(hx, g.y); ctx.lineTo(hx, g.y + g.h); ctx.stroke();
        ctx.setLineDash([]);
        ctx.fillStyle = 'rgba(230,235,242,0.9)';
        ctx.beginPath(); ctx.arc(hx, hy, 2.6, 0, TAU); ctx.fill();
      }

      ctx.strokeStyle = 'rgba(141,153,171,0.65)'; ctx.lineWidth = 1.2;
      ctx.beginPath(); ctx.moveTo(g.x, g.y); ctx.lineTo(g.x, g.y + g.h); ctx.lineTo(g.x + g.w, g.y + g.h); ctx.stroke();
      label('滴入体积 / mL', g.x + g.w, g.y + g.h + (narrow ? 24 : 26), C.muted, 'right', axisSize, '', false);
    }

    function draw(st, dt) {
      dt = Math.min(dt || 0, 0.05);
      var L = layout();
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, W, H);
      drawApparatus(L.app, st, dt);
      drawGraph(L.graph, st);
    }

    function spawnDrop(x, manual) {
      var room = Math.ceil((N.VMAX - x.V - 1e-9) / 0.05);
      if (drops.length >= Math.min(room, 32)) return false;
      drops.push({ x: 240, y: TIP_Y + 4, vy: 16, manual: manual });
      return true;
    }

    // 流量决定何时产生下一滴，落到液面时才计入烧杯体积。
    function animateDrops(st, dt, dV, reduced) {
      var x = st.x, count = 0, manual = false;
      dropAcc += dV;
      while (dropAcc >= 0.05) {
        dropAcc -= 0.05;
        spawnDrop(x);
      }
      if (reduced) {
        count = drops.length;
        manual = drops.some(function (drop) { return drop.manual; });
        drops = []; ripples = []; flashes = [];
        return { count: count, manual: manual };
      }
      var surf = surfaceY(x);
      for (var i = drops.length - 1; i >= 0; i--) {
        var d = drops[i];
        d.vy += 2300 * dt; d.y += d.vy * dt;
        if (d.y >= surf - 2) {
          if (ripples.length < 8) ripples.push({ x: d.x, r: 3, life: 0 });
          count++;
          manual = manual || !!d.manual;
          drops.splice(i, 1);
        }
      }
      return { count: count, manual: manual };
    }

    function hitsDropper(x, y) {
      if (!apparatus) return false;
      var a = apparatus;
      var u = (x - a.x) / a.k, v = (y - a.y) / a.k;
      return u >= 201 && u <= 280 && v >= 0 && v <= TIP_Y + 9;
    }

    function resetIons() { ionP = { h: [], oh: [], cat: [], an: [] }; flashes = []; }
    function resetDrops() { drops = []; ripples = []; dropAcc = 0; }

    // 图像上的鼠标位置 → 滴入体积
    function graphPoint(clientX, clientY) {
      if (!plotRect) return null;
      var g = plotRect;
      if (clientX < g.x || clientX > g.x + g.w || clientY < g.y || clientY > g.y + g.h) return null;
      if (equivalence && Math.hypot(clientX - equivalence.x, clientY - equivalence.y) <= 8) {
        return { V: equivalence.v };
      }
      return { V: (clientX - g.x) / g.w * N.VMAX };
    }

    return {
      resize: resize, draw: draw, animateDrops: animateDrops, graphPoint: graphPoint,
      spawnDrop: spawnDrop, hitsDropper: hitsDropper,
      resetIons: resetIons, resetDrops: resetDrops
    };
  }

  window.NeutralDraw = NeutralDraw;
  window.NeutralDraw.VW = VW;
  window.NeutralDraw.VH = VH;
})();
