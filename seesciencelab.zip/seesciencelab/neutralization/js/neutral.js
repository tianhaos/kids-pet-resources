// 酸碱中和：强酸与强碱的物质的量、pH 曲线、指示剂颜色（纯计算，不涉及绘图）
// 单位约定：浓度 mol/L，体积 mL，物质的量 mmol（c × V 的数值即为 mmol）
// pH 按 25 °C、Kw = 1×10⁻¹⁴ 计算；强酸、强碱近似为完全电离。
(function () {
  var KW = 1e-14;
  var VMAX = 30;         // 最多滴入 30 mL（图像横轴上限）

  var ACIDS = {
    hcl: {
      key: 'hcl', name: '稀盐酸', short: '盐酸', formula: 'HCl', z: 1,
      anion: 'Cl⁻', anionName: '氯离子', tint: 'rgba(255,214,170,0.75)'
    },
    h2so4: {
      key: 'h2so4', name: '稀硫酸', short: '硫酸', formula: 'H₂SO₄', z: 2,
      anion: 'SO₄²⁻', anionName: '硫酸根离子', tint: 'rgba(255,214,170,0.75)'
    }
  };

  var BASES = {
    naoh: {
      key: 'naoh', name: '氢氧化钠溶液', short: '氢氧化钠', formula: 'NaOH', z: 1,
      cation: 'Na⁺', cationName: '钠离子', tint: 'rgba(185,212,255,0.75)'
    },
    koh: {
      key: 'koh', name: '氢氧化钾溶液', short: '氢氧化钾', formula: 'KOH', z: 1,
      cation: 'K⁺', cationName: '钾离子', tint: 'rgba(185,212,255,0.75)'
    }
  };

  var SALTS = {
    'hcl|naoh': { formula: 'NaCl', name: '氯化钠' },
    'hcl|koh': { formula: 'KCl', name: '氯化钾' },
    'h2so4|naoh': { formula: 'Na₂SO₄', name: '硫酸钠' },
    'h2so4|koh': { formula: 'K₂SO₄', name: '硫酸钾' }
  };

  var INDS = {
    pp: {
      key: 'pp', name: '酚酞',
      acid: '无色', neutral: '无色', base: '红色',
      range: [8.2, 10.0], rangeText: '8.2～10.0'
    },
    litmus: {
      key: 'litmus', name: '紫色石蕊',
      acid: '红色', neutral: '紫色', base: '蓝色',
      range: [5.0, 8.0], rangeText: '5.0～8.0'
    },
    none: {
      key: 'none', name: '不加指示剂',
      acid: '无色', neutral: '无色', base: '无色',
      range: null, rangeText: ''
    }
  };

  // 广泛 pH 试纸比色卡（pH 1～14，颜色为示意图）
  var PAPER = [null,
    '#d32f2f', '#e53935', '#f4511e', '#fb8c00', '#fdd835', '#c0ca33', '#7cb342',
    '#26a69a', '#00897b', '#1e88e5', '#3949ab', '#5e35b1', '#6a1b9a', '#4a148c'];

  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }

  function reaction(acidKey, baseKey) {
    var a = ACIDS[acidKey], b = BASES[baseKey], salt = SALTS[acidKey + '|' + baseKey];
    if (acidKey === 'hcl') return 'HCl + ' + b.formula + ' = ' + salt.formula + ' + H₂O';
    return 'H₂SO₄ + 2' + b.formula + ' = ' + salt.formula + ' + 2H₂O';
  }

  function saltOf(acidKey, baseKey) { return SALTS[acidKey + '|' + baseKey]; }

  // 新建一次模拟。dir = 'base'：把碱滴入酸；'acid'：把酸滴入碱。
  function create(opts) {
    opts = opts || {};
    var st = {
      dir: opts.dir === 'acid' ? 'acid' : 'base',
      acid: ACIDS[opts.acid] ? opts.acid : 'hcl',
      base: BASES[opts.base] ? opts.base : 'naoh',
      ind: INDS[opts.ind] ? opts.ind : 'pp',
      cAcid: opts.cAcid != null ? +opts.cAcid : 0.10,
      cBase: opts.cBase != null ? +opts.cBase : 0.10,
      V0: opts.V0 != null ? +opts.V0 : 10.0,
      V: 0, t: 0, dropping: false
    };
    if (opts.V != null) st.V = clamp(+opts.V, 0, VMAX);
    return st;
  }

  // 已滴入 V mL 时，烧杯里酸、碱各有多少（mmol）；d > 0 表示酸过量
  function amounts(st, V) {
    if (V == null) V = st.V;
    V = clamp(V, 0, VMAX);
    var za = ACIDS[st.acid].z, zb = BASES[st.base].z, nAcid, nBase;
    if (st.dir === 'base') {
      nAcid = st.cAcid * st.V0 * za;      // 烧杯中酸的 H⁺
      nBase = st.cBase * V * zb;          // 滴入的 OH⁻
    } else {
      nAcid = st.cAcid * V * za;          // 滴入的 H⁺
      nBase = st.cBase * st.V0 * zb;      // 烧杯中碱的 OH⁻
    }
    return { V: V, nAcid: nAcid, nBase: nBase, d: nAcid - nBase, Vtot: st.V0 + V };
  }

  // 由过量 H⁺（或 OH⁻）浓度求 pH，含水的电离，恰好中和时得到 7
  function pHFromExcess(dMol) {
    if (dMol >= 0) {
      var h = (dMol + Math.sqrt(dMol * dMol + 4 * KW)) / 2;
      return -Math.log10(h);
    }
    var oh = (-dMol + Math.sqrt(dMol * dMol + 4 * KW)) / 2;
    return 14 + Math.log10(oh);
  }

  function pH(st, V) {
    var a = amounts(st, V);
    return pHFromExcess(a.d / a.Vtot);
  }

  function veq(st) {
    var za = ACIDS[st.acid].z, zb = BASES[st.base].z;
    if (st.dir === 'base') return st.cAcid * st.V0 * za / (st.cBase * zb);
    return st.cBase * st.V0 * zb / (st.cAcid * za);
  }

  function word(p) { return p < 6.999 ? '酸性' : p > 7.001 ? '碱性' : '中性'; }

  // 指示剂颜色：返回 rgb、透明度、文字
  function indicator(st, p) {
    if (p == null) p = pH(st);
    var ind = INDS[st.ind];
    if (st.ind === 'pp') {
      var a1 = ind.range[0], a2 = ind.range[1];
      var k = clamp((p - a1) / (a2 - a1), 0, 1);
      var alpha = 0.06 + 0.66 * k;
      var text = p < a1 ? '无色' : p <= (a1 + a2) / 2 ? '浅红' : '红色';
      if (p < a1) alpha = 0.035;
      return { key: 'pp', name: ind.name, rgb: [232, 62, 140], alpha: alpha, text: text, css: 'rgba(232,62,140,' + alpha.toFixed(3) + ')' };
    }
    if (st.ind === 'litmus') {
      // 红 → 紫（pH 7）→ 蓝
      var r, g, b;
      if (p <= 5) { r = 229; g = 72; b = 77; }
      else if (p <= 7) {
        var u = (p - 5) / 2;
        r = 229 + (150 - 229) * u; g = 72 + (90 - 72) * u; b = 77 + (200 - 77) * u;
      } else if (p <= 8) {
        var v = (p - 7) / 1;
        r = 150 + (63 - 150) * v; g = 90 + (126 - 90) * v; b = 200 + (240 - 200) * v;
      } else { r = 63; g = 126; b = 240; }
      var txt = p < 5.5 ? '红色' : p <= 7.5 ? '紫色' : '蓝色';
      return { key: 'litmus', name: ind.name, rgb: [r, g, b], alpha: 0.42, text: txt,
        css: 'rgba(' + Math.round(r) + ',' + Math.round(g) + ',' + Math.round(b) + ',0.42)' };
    }
    return { key: 'none', name: ind.name, rgb: [120, 180, 255], alpha: 0.06, text: '无色', css: 'rgba(120,180,255,0.06)' };
  }

  // 溶液中各离子的物质的量（mmol）。cat / an 为不参与反应的“旁观”离子。
  function ions(st, V) {
    var a = amounts(st, V);
    var baseMol = (st.dir === 'base' ? st.cBase * a.V : st.cBase * st.V0);
    var acidMol = (st.dir === 'base' ? st.cAcid * st.V0 : st.cAcid * a.V);
    return {
      h: Math.max(0, a.d), oh: Math.max(0, -a.d),
      cat: baseMol, an: acidMol,
      catName: BASES[st.base].cation, anName: ACIDS[st.acid].anion,
      catKey: BASES[st.base].cation, anKey: ACIDS[st.acid].anion
    };
  }

  function paperColor(p) {
    var i = clamp(Math.round(p), 1, 14);
    return PAPER[i];
  }

  window.Neutral = {
    ACIDS: ACIDS, BASES: BASES, INDS: INDS, SALTS: SALTS, PAPER: PAPER,
    VMAX: VMAX, KW: KW,
    reaction: reaction, saltOf: saltOf, create: create, amounts: amounts,
    pHFromExcess: pHFromExcess, pH: pH, veq: veq, word: word,
    indicator: indicator, ions: ions, paperColor: paperColor, clamp: clamp
  };
})();
