// 欧姆定律绘图：左（窄屏为上）画伏安法电路图——电源、开关、电流表、被测元件（定值电阻 / 小灯泡）、电压表、滑动变阻器（可拖滑片），
// 右（窄屏为下）画 I-U 或 I-R 图像（记录的数据点、拟合线、当前工作点）
(function () {
  var O = window.Ohm, TAU = Math.PI * 2;
  var C = { text: '#e6ebf2', muted: '#8d99ab', line: '#2a3446', grid: 'rgba(141,153,171,0.13)', accent: '#ffc94a', wire: '#c8d2e0',
    amm: '#4fc3f7', volt: '#7ee081', red: '#ff6b6b', used: '#ffc94a', unused: '#4a5568', bg: '#0b0f18' };
  var SERIES = { 5: '#ffc94a', 10: '#4fc3f7', 15: '#c9a7ff', 20: '#7ee081', 25: '#ff9b8a' };   // 各电阻的数据点颜色
  // 电路图里各元件的位置（单位 u）：回路四角 (0,0)(4,0)(4,2.4)(0,2.4)
  var RL = 1.1, RR = 2.75, RY = 2.4, RH = 0.13, AW = 3.05, AY = 2.85;   // 变阻器电阻丝左右端、所在行，滑片导线的拐点
  var VY = -1.0, VL = 1.05, VR = 2.95;                                  // 电压表支路

  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }

  function OhmDraw(canvas) {
    var ctx = canvas.getContext('2d'), W = 0, H = 0, dpr = 1, L = null, phase = 0;

    function resize(w, h) {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      W = w; H = h;
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
      canvas.style.width = w + 'px'; canvas.style.height = h + 'px';
      layout();
    }
    function layout() {
      var narrow = W <= 760, top = narrow ? 88 : 52, bottom = narrow ? 44 : 50, side = W >= 820;
      var cr, gr;
      if (side) {
        var cw = W * 0.56;
        cr = [8, top, cw - 8, H - top - bottom];
        var gw = W - cw - 28, gh = Math.min(H - top - bottom, gw * 0.95 + 40);
        gr = [cw + 4, top + (H - top - bottom - gh) / 2, gw, gh];
      } else {
        var ha = H - top - bottom, ch = ha * 0.56;
        cr = [8, top, W - 16, ch];
        gr = [12, top + ch + 6, W - 24, ha - ch - 6];
      }
      // 宽敞时电表画成表盘，否则画成小读数框（电流表的都放在回路内侧）
      var ex = [-0.75, 4.35, -2.3, 3.25], u = Math.min(cr[2] / (ex[1] - ex[0]), cr[3] / (ex[3] - ex[2])), dial = u >= 84;
      if (!dial) { ex = [-0.75, 4.35, -1.6, 3.25]; u = Math.min(cr[2] / (ex[1] - ex[0]), cr[3] / (ex[3] - ex[2])); }
      u = clamp(u, 40, 135);
      L = { u: u, dial: dial, narrow: narrow, g: gr,
        ox: cr[0] + (cr[2] - u * (ex[1] - ex[0])) / 2 - ex[0] * u,
        oy: cr[1] + (cr[3] - u * (ex[3] - ex[2])) / 2 - ex[2] * u };
    }
    function X(x) { return L.ox + x * L.u; }
    function Y(y) { return L.oy + y * L.u; }

    function font(px, w) { ctx.font = (w || '') + ' ' + Math.round(px) + 'px -apple-system, "PingFang SC", "Microsoft YaHei", sans-serif'; }
    function text(s, x, y, col, align, px, w) {
      font(px, w); ctx.fillStyle = col; ctx.textAlign = align || 'center'; ctx.textBaseline = 'middle'; ctx.fillText(s, x, y);
    }
    function line(x1, y1, x2, y2) { ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke(); }
    function poly(pts) { ctx.beginPath(); pts.forEach(function (p, i) { if (i) ctx.lineTo(X(p[0]), Y(p[1])); else ctx.moveTo(X(p[0]), Y(p[1])); }); ctx.stroke(); }
    function rrect(x, y, w, h, r) {
      ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r);
      ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
    }
    function dot(x, y, r, col) { ctx.fillStyle = col; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill(); }

    function sliderX(st) { return RL + (RR - RL) * clamp(st.pos, 0, 1); }
    function loadHalf(st) { return st.load === 'lamp' ? 0.2 : 0.45; }

    // 主回路（电流经过的路径），从电源正极出发：用于画电流点
    function mainPath(st) {
      var p = [[0, 1.2], [0, 0]], h = loadHalf(st);
      if (st.fault === 'short') p.push([1.3, 0], [1.3, -0.45], [2.7, -0.45], [2.7, 0]);
      p.push([4, 0], [4, RY]);
      if (st.fault === 'low') p.push([RL, RY]);
      else if (st.fault === 'high') p.push([AW, RY], [AW, RY - 0.3], [RL - 0.2, RY - 0.3], [RL - 0.2, RY]);
      else { var xp = sliderX(st); p.push([AW, RY], [AW, AY], [xp, AY], [xp, RY], [RL, RY]); }
      p.push([0, RY], [0, 1.2]);
      return p;
    }
    function masked(x, y, st) {     // 电流点不画进元件符号里
      var h = loadHalf(st);
      if (Math.abs(x) < 0.3 && Math.abs(y - 1.2) < 0.34) return true;
      if (Math.abs(x - 4) < 0.2 && Math.abs(y - 1.2) < 0.2) return true;
      if (Math.abs(y) < 0.2 && Math.abs(x - 2) < h + 0.02) return true;
      if (Math.abs(y - RY) < 0.25 && x > 3.22 && x < 3.78) return true;
      return false;
    }

    // ---------- 电路图 ----------
    function drawCircuit(st, sol, dt) {
      var u = L.u, lw = Math.max(2, u * 0.022), xp = sliderX(st), h = loadHalf(st);
      ctx.lineCap = 'round'; ctx.lineJoin = 'round';
      ctx.strokeStyle = C.wire; ctx.lineWidth = lw;
      var shortSrc = sol.status === 'short';

      // 导线：上边（被测元件两侧）、右边、左边、下边
      poly([[0, 0.9], [0, 0], [2 - h, 0]]);
      poly([[2 + h, 0], [4, 0], [4, 1.03]]);
      poly([[4, 1.37], [4, RY], [3.75, RY]]);
      poly([[0, 1.5], [0, RY], [st.fault === 'high' ? RL - 0.2 : RL, RY]]);
      if (st.fault === 'open') {     // 被测元件断路：左侧引线断开
        ctx.strokeStyle = C.red;
        line(X(1.36), Y(-0.08), X(1.44), Y(0.08));
        ctx.strokeStyle = C.wire;
      }
      // 电压表支路
      poly([[VL, 0], [VL, VY], [2 - 0.17, VY]]);
      poly([[2 + 0.17, VY], [VR, VY], [VR, 0]]);
      dot(X(VL), Y(0), Math.max(3, u * 0.035), C.wire); dot(X(VR), Y(0), Math.max(3, u * 0.035), C.wire);
      if (st.fault === 'short') {
        ctx.strokeStyle = C.red;
        poly([[1.3, 0], [1.3, -0.45], [2.7, -0.45], [2.7, 0]]);
        dot(X(1.3), Y(0), Math.max(3, u * 0.035), C.red); dot(X(2.7), Y(0), Math.max(3, u * 0.035), C.red);
        text('导线把它短接', X(2), Y(-0.58), C.red, 'center', Math.max(10, u * 0.11));
        ctx.strokeStyle = C.wire;
      }

      drawBattery(st, sol, lw, shortSrc);
      drawSwitch(st, lw);
      drawMeterSym(4, 1.2, 'A', C.amm, sol.overA);
      drawMeterSym(2, VY, 'V', C.volt, sol.overV);
      text('+', X(4) + u * 0.14, Y(1.2) - u * 0.25, C.red, 'center', u * 0.12, '700');
      text('+', X(2) - u * 0.27, Y(VY) - u * 0.12, C.red, 'center', u * 0.12, '700');
      if (st.load === 'lamp') drawLamp(st, sol, lw); else drawResistor(st, lw);
      drawRheostat(st, sol, lw, xp);

      drawFlow(st, sol, dt);

      // 电表读数
      drawMeterBox('A', st.rA, sol.I, sol.overA, st.closed);
      drawMeterBox('V', st.rV, sol.U, sol.overV, st.closed);
    }

    function drawBattery(st, sol, lw, shortSrc) {
      var u = L.u, n = Math.max(1, Math.round(st.E / 1.5)), gap = 0.07, w0 = (n - 1) * gap * 2 + gap, y0 = 1.2 - w0 / 2;
      ctx.strokeStyle = shortSrc && (st.time * 2.5 % 1) < 0.6 ? C.red : C.wire;
      line(X(0), Y(0.9), X(0), Y(y0)); line(X(0), Y(y0 + w0), X(0), Y(1.5));
      for (var i = 0; i < n; i++) {
        var yl = y0 + i * gap * 2, ys = yl + gap;            // 长线（正极）在上
        ctx.lineWidth = lw; line(X(-0.15), Y(yl), X(0.15), Y(yl));
        ctx.lineWidth = lw * 2.4; line(X(-0.075), Y(ys), X(0.075), Y(ys));
        if (i < n - 1) { ctx.lineWidth = lw; ctx.setLineDash([2, 3]); line(X(0), Y(ys), X(0), Y(ys + gap)); ctx.setLineDash([]); }
      }
      ctx.lineWidth = lw;
      var fs = Math.max(11, u * 0.12);
      text('+', X(0.22), Y(y0 - 0.06), C.red, 'center', u * 0.12, '700');
      text('电源', X(-0.24), Y(1.2) - fs * 0.6, C.text, 'right', fs, '600');
      text(st.E + ' V', X(-0.24), Y(1.2) + fs * 0.6, C.muted, 'right', fs * 0.9);
    }
    function drawSwitch(st, lw) {
      var u = L.u, x1 = 3.25, x2 = 3.75, rr = Math.max(3, u * 0.032);
      ctx.strokeStyle = C.wire;
      ctx.fillStyle = C.bg; ctx.lineWidth = Math.max(1.5, lw * 0.75);
      ctx.beginPath(); ctx.arc(X(x1), Y(RY), rr, 0, TAU); ctx.fill(); ctx.stroke();
      ctx.beginPath(); ctx.arc(X(x2), Y(RY), rr, 0, TAU); ctx.fill(); ctx.stroke();
      ctx.lineWidth = lw;
      var ang = st.closed ? 0 : 0.5, len = 0.5 * u;      // 刀片铰在右端，断开时往上翘
      ctx.strokeStyle = st.closed ? C.wire : C.accent;
      line(X(x2), Y(RY), X(x2) - len * Math.cos(ang), Y(RY) - len * Math.sin(ang));
      ctx.strokeStyle = C.wire; line(X(AW), Y(RY), X(x1) - rr, Y(RY));
      text('S', X(3.5), Y(RY + 0.24), st.closed ? C.text : C.accent, 'center', Math.max(11, u * 0.12), '600');
    }
    function drawMeterSym(x, y, ch, col, warn) {
      var u = L.u, r = 0.17 * u;
      ctx.fillStyle = C.bg; ctx.beginPath(); ctx.arc(X(x), Y(y), r, 0, TAU); ctx.fill();
      ctx.strokeStyle = warn ? C.red : col; ctx.stroke();
      text(ch, X(x), Y(y) + 0.5, warn ? C.red : col, 'center', u * 0.17, '700');
    }
    function drawResistor(st, lw) {
      var u = L.u, h = 0.45, open = st.fault === 'open';
      ctx.strokeStyle = C.wire; ctx.lineWidth = lw;
      ctx.fillStyle = C.bg; ctx.fillRect(X(2 - h), Y(-RH), 2 * h * u, 2 * RH * u);
      ctx.strokeRect(X(2 - h), Y(-RH), 2 * h * u, 2 * RH * u);
      var fs = Math.max(11, u * 0.12), name = st.scene === 'measure' ? '待测电阻 Rx' : '定值电阻 R';
      text(name, X(2), Y(0.3), open ? C.red : C.text, 'center', fs, '600');
      var val = st.scene === 'measure' && !st.reveal ? '= ?' : '= ' + st.R + ' Ω';
      text(open ? '（断路）' : st.fault === 'short' ? '（被短路）' : val, X(2), Y(0.3) + fs * 1.15, open || st.fault === 'short' ? C.red : C.muted, 'center', fs * 0.9);
    }
    function drawLamp(st, sol, lw) {
      var u = L.u, r = 0.2 * u, cx = X(2), cy = Y(0), b = st.broken ? 0 : clamp(sol.P / (O.LAMP.U * O.LAMP.I), 0, 1.6);
      if (b > 0.01) {
        var R = r * (1.4 + 2.2 * Math.min(b, 1.3)), gr = ctx.createRadialGradient(cx, cy, r * 0.3, cx, cy, R);
        gr.addColorStop(0, 'rgba(255,236,170,' + clamp(0.9 * b, 0, 0.95) + ')');
        gr.addColorStop(0.35, 'rgba(255,201,74,' + clamp(0.45 * b, 0, 0.6) + ')');
        gr.addColorStop(1, 'rgba(255,201,74,0)');
        ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(cx, cy, R, 0, TAU); ctx.fill();
      }
      ctx.fillStyle = b > 0.01 ? 'rgba(255,240,190,' + clamp(0.25 + 0.6 * b, 0, 0.9) + ')' : C.bg;
      ctx.beginPath(); ctx.arc(cx, cy, r, 0, TAU); ctx.fill();
      ctx.lineWidth = lw; ctx.strokeStyle = st.broken ? C.red : b > 0.01 ? C.accent : C.wire; ctx.stroke();
      var d = r * 0.707;
      ctx.strokeStyle = b > 0.01 ? '#8a5a00' : st.broken ? C.red : C.wire;
      if (st.broken) { line(cx - d, cy - d, cx - d * 0.2, cy - d * 0.2); line(cx + d * 0.2, cy + d * 0.2, cx + d, cy + d); line(cx - d, cy + d, cx + d, cy - d); }
      else { line(cx - d, cy - d, cx + d, cy + d); line(cx - d, cy + d, cx + d, cy - d); }
      var fs = Math.max(11, u * 0.12);
      text('小灯泡 L', cx, Y(0.34), st.broken ? C.red : C.text, 'center', fs, '600');
      text(st.broken ? '（灯丝烧断）' : st.fault === 'short' ? '（被短路）' : st.fault === 'open' ? '（断路）' : '2.5 V 0.3 A', cx, Y(0.34) + fs * 1.15,
        st.broken || st.fault === 'short' || st.fault === 'open' ? C.red : C.muted, 'center', fs * 0.9);
    }
    function drawRheostat(st, sol, lw, xp) {
      var u = L.u, f = st.fault, hy = RH * u;
      // 电阻丝：接入电路的一段涂成金色
      ctx.fillStyle = C.bg; ctx.fillRect(X(RL), Y(RY) - hy, (RR - RL) * u, 2 * hy);
      var u0 = RL, u1 = f === 'low' ? RR : f === 'high' ? RL : xp;
      if (u1 > u0) { ctx.fillStyle = 'rgba(255,201,74,0.28)'; ctx.fillRect(X(u0), Y(RY) - hy, (u1 - u0) * u, 2 * hy); }
      ctx.strokeStyle = C.wire; ctx.lineWidth = lw; ctx.strokeRect(X(RL), Y(RY) - hy, (RR - RL) * u, 2 * hy);
      // 电阻丝上的线圈纹
      ctx.strokeStyle = 'rgba(200,210,224,0.25)'; ctx.lineWidth = 1;
      for (var x = RL + 0.06; x < RR - 0.03; x += 0.06) line(X(x), Y(RY) - hy + 2, X(x), Y(RY) + hy - 2);
      ctx.lineWidth = lw;
      // 滑片（箭头）与它的导线
      var conn = f !== 'low' && f !== 'high', ah = 0.09 * u, tipY = Y(RY) + hy;
      ctx.strokeStyle = conn ? C.wire : C.unused; ctx.fillStyle = conn ? C.wire : C.unused;
      if (conn) poly([[AW, RY], [AW, AY], [xp, AY], [xp, RY + RH + 0.08]]);
      else { ctx.setLineDash([3, 4]); poly([[AW - 0.12, AY], [xp, AY], [xp, RY + RH + 0.08]]); ctx.setLineDash([]); }
      ctx.beginPath(); ctx.moveTo(X(xp), tipY); ctx.lineTo(X(xp) - ah * 0.6, tipY + ah); ctx.lineTo(X(xp) + ah * 0.6, tipY + ah); ctx.closePath(); ctx.fill();
      if (st.hoverP && conn) { ctx.strokeStyle = 'rgba(255,201,74,0.5)'; ctx.lineWidth = 6; ctx.beginPath(); ctx.arc(X(xp), Y(AY), u * 0.1, 0, TAU); ctx.stroke(); ctx.lineWidth = lw; }
      // 错误接法的导线
      ctx.strokeStyle = C.red;
      if (f === 'low') poly([[AW, RY], [RR, RY]]);
      if (f === 'high') {
        poly([[AW, RY], [AW, RY - 0.3], [RL - 0.2, RY - 0.3], [RL - 0.2, RY]]);
        text('接在金属杆两端', X((RL + RR) / 2), Y(RY - 0.42), C.red, 'center', Math.max(10, u * 0.11));
      }
      if (f === 'low') text('接在电阻丝两端', X((RL + RR) / 2), Y(RY - 0.3), C.red, 'center', Math.max(10, u * 0.11));
      ctx.strokeStyle = C.wire;
      var fs = Math.max(11, u * 0.12);
      text('P', X(xp) + u * 0.1, Y(AY) - u * 0.16, conn ? C.accent : C.unused, 'left', fs, '700');
      text('滑动变阻器 R′ = ' + O.rheoR(st).toFixed(1) + ' Ω', X((RL + RR) / 2), Y(AY + 0.22), C.text, 'center', fs, '600');
      text('最大 ' + st.Rmax + ' Ω · 滑片向右移，接入电阻变大', X((RL + RR) / 2), Y(AY + 0.22) + fs * 1.2, C.muted, 'center', fs * 0.85);
    }

    // 电流点（电流方向）
    function drawFlow(st, sol, dt) {
      if (!st.showFlow || sol.I < 2e-3) return;
      var u = L.u, gap = u / 4, pts = mainPath(st).map(function (p) { return [X(p[0]), Y(p[1])]; });
      var segs = [], tot = 0;
      for (var i = 1; i < pts.length; i++) { var l = Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]); segs.push(l); tot += l; }
      phase = (phase + u * 1.2 * Math.min(1.6, Math.sqrt(sol.I / 0.3)) * dt) % gap;
      var rad = Math.max(2, u * 0.026);
      ctx.fillStyle = sol.status === 'short' ? C.red : C.accent;
      var si = 0, acc = 0;
      for (var s = phase; s < tot; s += gap) {
        while (si < segs.length - 1 && s > acc + segs[si]) { acc += segs[si]; si++; }
        var f = segs[si] ? (s - acc) / segs[si] : 0, a = pts[si], b = pts[si + 1];
        var x = a[0] + (b[0] - a[0]) * f, y = a[1] + (b[1] - a[1]) * f;
        if (masked((x - L.ox) / u, (y - L.oy) / u, st)) continue;
        ctx.beginPath(); ctx.arc(x, y, rad, 0, TAU); ctx.fill();
      }
    }

    // 电表读数：表盘或小读数框
    function meterBox(kind) {
      var u = L.u;
      if (L.dial) return kind === 'A' ? { cx: X(4 - 0.3 - 0.6), cy: Y(1.2), w: 1.2 * u, h: 1.0 * u } : { cx: X(2), cy: Y(-1.77), w: 1.2 * u, h: 1.0 * u };
      var w = Math.max(0.78 * u, 54), hh = Math.max(0.3 * u, 20);
      return kind === 'A' ? { cx: X(4) - 0.3 * u - w / 2, cy: Y(1.2), w: w, h: hh } : { cx: X(2), cy: Y(VY - 0.2) - hh / 2, w: w, h: hh };
    }
    function drawMeterBox(kind, range, v, over, closed) {
      var B = meterBox(kind), u = L.u, x = B.cx - B.w / 2, y = B.cy - B.h / 2, col = kind === 'A' ? C.amm : C.volt;
      ctx.fillStyle = 'rgba(11,15,24,0.92)'; ctx.strokeStyle = over ? C.red : col; ctx.lineWidth = 1;
      rrect(x, y, B.w, B.h, 5); ctx.fill(); ctx.stroke();
      var unit = ' ' + kind, vs = over ? '超量程' : O.fmt(v, kind, range) + unit, fs = Math.max(10, u * 0.115);
      if (L.dial) {
        var ax = B.cx, ay = y + B.h * 0.7, R = Math.min(B.w * 0.36, (B.h * 0.7 - fs * 1.9) / 1.22), a0 = Math.PI * 1.2, a1 = Math.PI * 1.8;
        ctx.strokeStyle = C.muted; ctx.lineWidth = 1;
        ctx.beginPath(); ctx.arc(ax, ay, R, a0, a1); ctx.stroke();
        for (var i = 0; i <= 30; i++) {
          var a = a0 + (a1 - a0) * i / 30, l = i % 10 ? (i % 5 ? 0.93 : 0.88) : 0.82;
          if (i % 10 && R < 40 && i % 2) continue;
          line(ax + Math.cos(a) * R, ay + Math.sin(a) * R, ax + Math.cos(a) * R * l, ay + Math.sin(a) * R * l);
          if (!(i % 10)) {
            var lab = +(range * i / 30).toFixed(2);
            text(String(lab), ax + Math.cos(a) * R * 1.14, ay + Math.sin(a) * R * 1.14, C.muted, 'center', Math.max(9, fs * 0.72));
          }
        }
        var fr = clamp(v / range, 0, 1.06), an = a0 + (a1 - a0) * fr;
        ctx.strokeStyle = over ? C.red : C.text; ctx.lineWidth = 1.5;
        line(ax, ay, ax + Math.cos(an) * R * 0.95, ay + Math.sin(an) * R * 0.95);
        dot(ax, ay, 2, C.text);
        text((kind === 'A' ? '电流表' : '电压表') + ' 0~' + range + unit, B.cx, y + fs * 0.8, C.muted, 'center', Math.max(10, fs * 0.8));
        text(vs, B.cx, y + B.h * 0.86, over ? C.red : col, 'center', fs * 1.1, '700');
      } else text(vs, B.cx, B.cy + 0.5, over ? C.red : col, 'center', fs, '700');
    }

    // ---------- 图像 ----------
    function stepFor(max) {
      var c = [0.01, 0.02, 0.025, 0.05, 0.1, 0.2, 0.25, 0.5, 1, 2, 2.5, 5, 10, 20];
      for (var i = 0; i < c.length; i++) if (max / c[i] <= 8 + 1e-9) return c[i];
      return max / 5;
    }
    function drawGraph(st, sol) {
      var g = L.g, gx = g[0], gy = g[1], gw = g[2], gh = g[3];
      ctx.fillStyle = 'rgba(17,23,35,0.6)'; ctx.strokeStyle = C.line; ctx.lineWidth = 1;
      rrect(gx, gy, gw, gh, 10); ctx.fill(); ctx.stroke();
      var fs = L.narrow ? 11 : 12, ir = st.scene === 'ir', inv = ir && st.inv;
      var ml = 46, mr = 16, mt = 34, mb = 34;
      var px = gx + ml, py = gy + mt, pw = gw - ml - mr, ph = gh - mt - mb;
      if (pw < 60 || ph < 50) return;
      var data = st.data, live = st.closed && sol.status !== 'short';
      // 坐标范围
      var xmax, ymax, xv, yv = function (d) { return d.I; };
      if (ir) {
        xv = inv ? function (d) { return 1 / d.R; } : function (d) { return d.R; };
        xmax = inv ? 0.25 : 25;
        ymax = O.niceCeil(Math.max(0.5, live && st.fault !== 'short' ? sol.I : 0, Math.max.apply(null, data.map(yv).concat(0))) * 1.05);
      } else {
        xv = function (d) { return d.U; };
        xmax = O.niceCeil(Math.max(st.E, Math.max.apply(null, data.map(xv).concat(0))));
        // 测未知电阻时不按真实值定坐标范围，免得泄露答案
        var imax = st.load === 'lamp' ? O.lampI(Math.min(st.E, O.LAMP.U * O.LAMP.burn)) : st.E / (st.scene === 'measure' ? 5 : st.R);
        ymax = O.niceCeil(Math.max(0.1, imax * 1.05, Math.max.apply(null, data.map(yv).concat(0))));
      }
      function sx(v) { return px + v / xmax * pw; }
      function sy(v) { return py + ph - v / ymax * ph; }
      // 网格与刻度
      var xs = stepFor(xmax), ys = stepFor(ymax), v;
      ctx.strokeStyle = C.grid; ctx.lineWidth = 1;
      for (v = xs; v <= xmax + 1e-9; v += xs) line(sx(v), py, sx(v), py + ph);
      for (v = ys; v <= ymax + 1e-9; v += ys) line(px, sy(v), px + pw, sy(v));
      ctx.strokeStyle = C.muted; line(px, py + ph, px + pw + 6, py + ph); line(px, py + ph, px, py - 6);
      for (v = 0; v <= xmax + 1e-9; v += xs) text(String(+v.toFixed(3)), sx(v), py + ph + 11, C.muted, 'center', fs - 1);
      for (v = ys; v <= ymax + 1e-9; v += ys) text(String(+v.toFixed(3)), px - 5, sy(v), C.muted, 'right', fs - 1);
      text(ir ? (inv ? '1/R / Ω⁻¹' : 'R / Ω') : 'U / V', px + pw, py + ph + 25, C.muted, 'right', fs);
      text('I / A', px + 4, py - 12, C.muted, 'left', fs);
      var title = ir ? (inv ? 'I-1/R 图像（电压一定）' : 'I-R 图像（电压一定）') : st.load === 'lamp' ? '小灯泡的 I-U 图像' : 'I-U 图像';
      text(title, gx + gw / 2, gy + 14, C.text, 'center', fs + 1, '600');

      ctx.save(); ctx.beginPath(); ctx.rect(px, py - 4, pw + 4, ph + 4); ctx.clip();
      // 拟合线
      if (ir) {
        var good = data.filter(function (d) { return !d.warn; });
        if (good.length >= 2) {
          var U0 = O.mean(good.map(function (d) { return d.U; }));
          ctx.strokeStyle = 'rgba(255,201,74,0.7)'; ctx.lineWidth = 1.5; ctx.setLineDash([6, 5]); ctx.beginPath();
          if (inv) { ctx.moveTo(sx(0), sy(0)); ctx.lineTo(sx(xmax), sy(U0 * xmax)); }
          else for (var R = 2; R <= 25; R += 0.25) { var yy = sy(U0 / R); if (R === 2) ctx.moveTo(sx(R), yy); else ctx.lineTo(sx(R), yy); }
          ctx.stroke(); ctx.setLineDash([]);
          ctx.restore(); ctx.save();
          text('U = ' + U0.toFixed(1) + ' V 时 ' + (inv ? 'I 与 1/R 成正比' : 'I 与 R 成反比'), px + pw - 4, py + 6, C.accent, 'right', fs);
          ctx.beginPath(); ctx.rect(px, py - 4, pw + 4, ph + 4); ctx.clip();
        }
      } else if (st.load === 'lamp') {
        // 用平滑曲线连接各点（读数按分度值取整会有小的起伏，曲线取灯丝的实际特性）
        var um = Math.max.apply(null, data.map(xv).concat(0));
        if (data.length >= 2) {
          ctx.strokeStyle = 'rgba(255,201,74,0.75)'; ctx.lineWidth = 1.8; ctx.beginPath(); ctx.moveTo(sx(0), sy(0));
          for (var k = 1; k <= 60; k++) { var uu = um * k / 60; ctx.lineTo(sx(uu), sy(O.lampI(uu))); }
          ctx.stroke();
        }
      } else {
        var groups = {};
        data.forEach(function (d) { (groups[d.R] = groups[d.R] || []).push(d); });
        Object.keys(groups).forEach(function (R) {
          var gp = groups[R], r = O.fitR(gp);
          if (gp.length < 2 || !r) return;
          var col = st.scene === 'measure' ? C.accent : SERIES[R] || C.accent;
          ctx.strokeStyle = col; ctx.globalAlpha = 0.75; ctx.lineWidth = 1.5; ctx.setLineDash([6, 5]);
          var xe = Math.min(xmax, ymax * r);
          line(sx(0), sy(0), sx(xe), sy(xe / r)); ctx.setLineDash([]); ctx.globalAlpha = 1;
          var lab = st.scene === 'measure' ? 'Rx ≈ ' + r.toFixed(1) + ' Ω' : 'R = ' + R + ' Ω';
          var lx = sx(xe), ly = sy(xe / r);
          text(lab, Math.min(lx, px + pw - 4) - 4, Math.max(ly, py + 8) + 10, col, 'right', fs, '600');
        });
      }
      // 数据点
      data.forEach(function (d) {
        var col = ir ? (d.warn ? C.red : SERIES[d.R] || C.accent) : st.scene === 'iu' ? SERIES[d.R] || C.accent : C.accent;
        dot(sx(xv(d)), sy(d.I), 4.5, col);
        ctx.strokeStyle = C.bg; ctx.lineWidth = 1; ctx.beginPath(); ctx.arc(sx(xv(d)), sy(d.I), 4.5, 0, TAU); ctx.stroke();
      });
      // 当前工作点
      if (st.closed && sol.status === 'ok') {
        var cur = { U: O.read(sol.U, 'V', st.rV), I: O.read(sol.I, 'A', st.rA), R: st.R };
        var cx = sx(xv(cur)), cy = sy(cur.I);
        ctx.strokeStyle = 'rgba(230,235,242,0.35)'; ctx.setLineDash([3, 4]); ctx.lineWidth = 1;
        line(cx, cy, cx, py + ph); line(cx, cy, px, cy); ctx.setLineDash([]);
        ctx.strokeStyle = C.text; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(cx, cy, 6, 0, TAU); ctx.stroke();
      }
      ctx.restore();
      if (!data.length) text('点“记录数据”把读数画到图上', px + pw / 2, py + ph * 0.42, C.muted, 'center', fs);
      // 图例：探究电流与电压关系时按电阻分色
      if (st.scene === 'iu') [5, 10, 20].forEach(function (R, i) {
        dot(px + 10, py + 8 + i * 16, 4, SERIES[R]); text('R = ' + R + ' Ω', px + 18, py + 8 + i * 16, C.muted, 'left', fs - 1);
      });
    }

    function draw(st, sol, dt) {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, W, H);
      drawCircuit(st, sol, dt);
      drawGraph(st, sol);
    }

    // 命中：滑片（箭头及其导线横段、电阻丝）或开关
    function hit(px, py) {
      var u = L.u, x = (px - L.ox) / u, y = (py - L.oy) / u;
      if (x > RL - 0.15 && x < RR + 0.15 && y > RY - 0.25 && y < AY + 0.15) return 'slider';
      if (x > 3.15 && x < 3.85 && y > RY - 0.4 && y < RY + 0.2) return 'switch';
      return null;
    }
    function posAt(px) { return clamp(((px - L.ox) / L.u - RL) / (RR - RL), 0, 1); }

    return { resize: resize, draw: draw, hit: hit, posAt: posAt };
  }

  window.OhmDraw = OhmDraw;
})();
