(function () {
  var O = window.Ohm;
  var $ = function (id) { return document.getElementById(id); };
  var qa = function (sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); };
  var NAME = '欧姆定律';
  var MAXROWS = 12;

  var SCENES = {
    iu: { name: '电流与电压的关系', load: 'R', R: 10, E: 3, Rmax: 20, Rs: [5, 10, 20],
      note: '保持电阻 R 不变，移动滑片 P 改变 R 两端的电压，记录几组电压表、电流表的示数。再换一个电阻重复，比较几条图线。' },
    ir: { name: '电流与电阻的关系', load: 'R', R: 5, E: 4.5, Rmax: 50, Rs: [5, 10, 15, 20, 25],
      note: '依次换用 5 Ω、10 Ω、15 Ω……的电阻。每换一次，都要移动滑片 P，使电压表示数回到同一个值，再读电流表——这是控制变量。' },
    measure: { name: '伏安法测电阻', load: 'R', R: 10, E: 3, Rmax: 20,
      note: '用电压表测出 Rx 两端的电压 U、用电流表测出通过它的电流 I，由 R = U/I 求电阻。移动滑片多测几组，求平均值减小误差。' },
    lamp: { name: '测小灯泡的电阻', load: 'lamp', R: 10, E: 3, Rmax: 20,
      note: '从低电压开始，移动滑片使小灯泡两端电压逐渐升高（不要超过额定电压太多），记录几组数据，比较不同电压下灯丝的电阻。' }
  };
  var RX = [6, 8, 12, 15, 18];
  var FAULTS = { none: '无', open: '被测元件断路', short: '被测元件短路', low: '变阻器接两个下接线柱', high: '变阻器接两个上接线柱' };

  var state = {
    scene: 'iu', load: 'R', R: 10, E: 3, Rmax: 20, pos: 1, closed: true, fault: 'none', broken: false,
    rA: 0.6, rV: 3, U0: 2, inv: false, reveal: false, rx: 12, showFlow: true,
    dataBy: { iu: [], ir: [], measure: [], lamp: [] }, data: null, time: 0, hoverP: false, closeTip: false
  };
  var sol = null;

  var stage = $('stage'), canvas = $('ohm'), panel = $('panel');
  var view = window.OhmDraw(canvas);

  function setSeg(attr, val) { qa('[data-' + attr + ']').forEach(function (b) { b.classList.toggle('on', b.dataset[attr] === String(val)); }); }
  function fmtA(v) { return O.fmt(v, 'A', state.rA); }
  function fmtV(v) { return O.fmt(v, 'V', state.rV); }

  // ---------- 场景与计算 ----------
  function loadScene(name) {
    var sc = SCENES[name] ? SCENES[name] : SCENES.iu;
    state.scene = SCENES[name] ? name : 'iu';
    state.load = sc.load; state.E = sc.E; state.Rmax = sc.Rmax;
    state.R = state.scene === 'measure' ? state.rx : sc.R;
    state.pos = 1; state.closed = true; state.fault = 'none'; state.broken = false; state.closeTip = false;
    state.rA = 0.6; state.rV = 3;
    state.data = state.dataBy[state.scene];
    update();
  }
  function update() {
    sol = O.solve(state);
    if (sol.burn && !state.broken) { state.broken = true; sol = O.solve(state); Analytics.track(NAME, '灯丝烧断'); }
    sol.overA = sol.I > state.rA * 1.04;
    sol.overV = sol.U > state.rV * 1.04;
    syncPanel();
  }
  function setPos(p) { state.pos = Math.max(0, Math.min(1, p)); if (state.pos > 0.97) state.closeTip = false; update(); }

  function canRecord() {
    if (!state.closed) return '先闭合开关';
    if (sol.status === 'short') return '电源短路，不能记录';
    if (sol.overA || sol.overV) return '电表超量程，换大量程再读';
    if (state.data.length >= MAXROWS) return '最多记录 ' + MAXROWS + ' 组，先清除数据';
    return '';
  }
  function record() {
    var why = canRecord();
    if (why) { flash(why); return; }
    var d = { R: state.load === 'lamp' ? null : state.R, U: O.read(sol.U, 'V', state.rV), I: O.read(sol.I, 'A', state.rA), fault: state.fault !== 'none' };
    if (state.scene === 'ir') d.warn = Math.abs(d.U - state.U0) > 0.05;
    state.data.push(d);
    Analytics.track(NAME, '记录数据', SCENES[state.scene].name);
    syncPanel();
  }
  var flashT = 0;
  function flash(msg) { $('recMsg').textContent = msg; clearTimeout(flashT); flashT = setTimeout(function () { $('recMsg').textContent = ''; }, 2500); }

  // ---------- 读数、提示 ----------
  function notes() {
    var n = [], st = state;
    if (!st.closed) { n.push('开关断开，电路中没有电流。'); return n; }
    if (st.closeTip) n.push('闭合开关前，应把滑片 P 移到阻值最大处（最右端），使电路中电流最小，保护电路。');
    if (sol.status === 'short') n.push('被测元件短路，滑片又移到了阻值为零的位置：电源短路，电流很大，会烧坏电流表和电源！');
    if (st.broken) n.push('小灯泡两端的实际电压远超额定电压，灯丝烧断了（电路断路）。点“换新灯泡”，并把滑片移回阻值最大处。');
    else if (st.fault === 'open') n.push('现象：电流表几乎无示数，电压表示数接近电源电压 → 被测元件断路（电压表被串联进了电路）。');
    if (st.fault === 'short' && sol.status !== 'short') n.push('现象：电压表无示数，电流表有示数 → 被测元件短路。');
    if (st.fault === 'low') n.push('现象：移动滑片，两表示数都不变，而且电流较小 → 变阻器接了两个下接线柱，整根电阻丝都接入，起不到变阻作用。');
    if (st.fault === 'high') n.push('现象：移动滑片，两表示数都不变，而且电流较大 → 变阻器接了两个上接线柱，接入电阻为零。');
    if (sol.overA) n.push('电流超过电流表量程 0~' + st.rA + ' A：指针打到头，可能损坏电表。增大变阻器阻值或换用大量程。');
    if (sol.overV) n.push('电压超过电压表量程 0~' + st.rV + ' V：换用 0~15 V 量程，或增大变阻器阻值。');
    if (st.scene === 'ir' && st.fault === 'none' && sol.status === 'ok') {
      var U = O.read(sol.U, 'V', st.rV), need = O.needRP(st.E, st.R, st.U0);
      if (need > st.Rmax + 1e-9) n.push('要让 ' + st.R + ' Ω 电阻两端电压降到 ' + st.U0 + ' V，变阻器需接入 ' + need.toFixed(1) + ' Ω，超过了它的最大阻值 ' + st.Rmax + ' Ω：换用最大阻值更大的变阻器，或降低电源电压。');
      else if (Math.abs(U - st.U0) > 0.05) n.push('电压表示数 ' + U.toFixed(1) + ' V，' + (U > st.U0 ? '大于' : '小于') + ' ' + st.U0 + ' V：应把滑片向' + (U > st.U0 ? '右' : '左') + '移（变阻器分得的电压' + (U > st.U0 ? '变大' : '变小') + '），使电压表示数回到 ' + st.U0 + ' V。');
      else n.push('电压表示数为 ' + st.U0 + ' V，可以记录这组数据。');
    }
    if (st.scene === 'lamp' && !st.broken && sol.status === 'ok' && sol.U > O.LAMP.U * 1.04) n.push('灯泡两端电压已超过额定电压 2.5 V，灯很亮，再升高可能烧坏灯丝。');
    return n;
  }
  function esc(s) { return String(s).replace(/[&<>]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]; }); }

  function syncPanel() {
    var st = state, sc = SCENES[st.scene];
    setSeg('scene', st.scene); setSeg('e', st.E); setSeg('rmax', st.Rmax); setSeg('ra', st.rA); setSeg('rv', st.rV);
    setSeg('r', st.R); setSeg('u0', st.U0); setSeg('fault', st.fault); setSeg('axis', st.inv ? 'inv' : 'r');
    $('rI').textContent = sol.overA ? '超量程' : fmtA(sol.I) + ' A';
    $('rU').textContent = sol.overV ? '超量程' : fmtV(sol.U) + ' V';
    $('rRP').textContent = O.rheoR(st).toFixed(1) + ' Ω';
    var I = O.read(sol.I, 'A', st.rA), U = O.read(sol.U, 'V', st.rV);
    $('rRatio').textContent = st.closed && I > 0 && !sol.overA && !sol.overV ? (U / I).toFixed(1) + ' Ω' : '—';
    $('rRatioLab').textContent = st.load === 'lamp' ? '灯丝电阻 U/I' : 'U/I';
    $('rUP').textContent = st.closed ? sol.UP.toFixed(2) + ' V' : '—';
    if (st.load === 'lamp') {
      $('rP').textContent = st.closed && !st.broken ? (U * I).toFixed(2) + ' W' : '—';
    }
    $('rP').hidden = $('rPLab').hidden = st.load !== 'lamp';
    var nn = notes();
    $('rNotes').innerHTML = nn.map(function (t) { return '<li>' + esc(t) + '</li>'; }).join('');
    $('rNotes').hidden = !nn.length;
    $('rNotes').className = st.fault !== 'none' || sol.overA || sol.overV || st.broken || sol.status === 'short' ? 'warn' : '';

    $('sceneNote').textContent = sc.note;
    $('switchBtn').textContent = st.closed ? '断开开关 S' : '闭合开关 S';
    $('posRange').value = Math.round(st.pos * 100);
    $('posOut').textContent = O.rheoR(st).toFixed(1) + ' Ω';
    // 器材：按场景显示
    $('rowR').hidden = !sc.Rs;
    if (sc.Rs) qa('[data-r]').forEach(function (b) { b.hidden = sc.Rs.indexOf(+b.dataset.r) < 0; });
    $('rowU0').hidden = st.scene !== 'ir';
    $('rowAxis').hidden = st.scene !== 'ir';
    $('revealRow').hidden = st.scene !== 'measure';
    $('newLamp').hidden = !st.broken;
    $('showFlow').checked = st.showFlow; $('reveal').checked = st.reveal;
    $('faultNote').textContent = st.fault === 'none' ? '选一种常见故障，观察两只电表的示数和移动滑片时的变化，学会“由现象找原因”。' : '故障：' + FAULTS[st.fault] + '。';
    syncTable();
  }

  function syncTable() {
    var st = state, d = st.data, sc = st.scene, head, rows, sum = '';
    if (sc === 'ir') {
      head = '<th>#</th><th>R/Ω</th><th>U/V</th><th>I/A</th><th>IR/V</th>';
      rows = d.map(function (r, i) {
        return '<tr class="' + (r.warn ? 'bad' : '') + '"><td>' + (i + 1) + '</td><td>' + r.R + '</td><td>' + r.U.toFixed(1) + '</td><td>' + r.I.toFixed(2) + '</td><td>' + (r.I * r.R).toFixed(2) + '</td></tr>';
      });
      var good = d.filter(function (r) { return !r.warn; });
      if (d.length > good.length) sum += '<p class="bad">红色的几组电压没有控制在 ' + st.U0 + ' V，不符合控制变量的要求。</p>';
      if (good.length >= 2) sum += '<p>电压一定时，IR 基本不变：<b>导体中的电流与导体的电阻成反比</b>。</p>';
    } else {
      head = '<th>#</th>' + (sc === 'iu' ? '<th>R/Ω</th>' : '') + '<th>U/V</th><th>I/A</th><th>' + (sc === 'iu' ? 'U/I' : 'R=U/I') + '</th>';
      rows = d.map(function (r, i) {
        return '<tr' + (r.fault ? ' class="bad"' : '') + '><td>' + (i + 1) + '</td>' + (sc === 'iu' ? '<td>' + r.R + '</td>' : '') + '<td>' + r.U.toFixed(1) + '</td><td>' + r.I.toFixed(2) + '</td><td>' +
          (r.I > 0 ? (r.U / r.I).toFixed(1) + ' Ω' : '—') + '</td></tr>';
      });
      var ok = d.filter(function (r) { return r.I > 0 && !r.fault; });
      if (sc === 'iu' && ok.length >= 2) sum = '<p>同一个电阻的 U/I 基本不变：<b>电阻一定时，导体中的电流与导体两端的电压成正比</b>。</p>';
      if (sc === 'measure' && ok.length) {
        var avg = O.mean(ok.map(function (r) { return r.U / r.I; }));
        sum = '<p>' + ok.length + ' 次测量的平均值 <b>Rx ≈ ' + avg.toFixed(1) + ' Ω</b>' + (st.reveal ? '（真实值 ' + st.rx + ' Ω）' : '') + (ok.length < 3 ? '，至少测 3 组再求平均' : '') + '。</p>';
      }
      if (sc === 'lamp' && ok.length >= 2) {
        var srt = ok.slice().sort(function (a, b) { return a.U - b.U; }), r0 = srt[0].U / srt[0].I, r1 = srt[srt.length - 1].U / srt[srt.length - 1].I;
        sum = '<p>电压从 ' + srt[0].U.toFixed(1) + ' V 升到 ' + srt[srt.length - 1].U.toFixed(1) + ' V，灯丝电阻从 ' + r0.toFixed(1) + ' Ω 变为 ' + r1.toFixed(1) + ' Ω：<b>灯丝电阻随温度升高而增大</b>，所以不能求平均值。</p>';
      }
    }
    $('dataTable').innerHTML = '<thead><tr>' + head + '</tr></thead><tbody>' +
      (rows.length ? rows.join('') : '<tr><td colspan="6" class="muted">还没有数据</td></tr>') + '</tbody>';
    $('dataSum').innerHTML = sum;
  }

  // ---------- 画布交互：拖滑片、点开关 ----------
  var drag = null;
  function pos(e) { var r = canvas.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; }
  canvas.addEventListener('pointerdown', function (e) {
    var p = pos(e), h = view.hit(p[0], p[1]);
    if (h === 'slider') {
      drag = { id: e.pointerId };
      try { canvas.setPointerCapture(e.pointerId); } catch (err) {}
      setPos(view.posAt(p[0]));
      e.preventDefault();
    } else if (h === 'switch') toggleSwitch();
  });
  canvas.addEventListener('pointermove', function (e) {
    var p = pos(e), h = view.hit(p[0], p[1]);
    state.hoverP = h === 'slider' || !!drag;
    canvas.style.cursor = h === 'slider' || drag ? 'ew-resize' : h === 'switch' ? 'pointer' : 'default';
    if (drag) setPos(view.posAt(p[0]));
  });
  function up() { if (drag) Analytics.track(NAME, '拖动滑片', SCENES[state.scene].name); drag = null; }
  canvas.addEventListener('pointerup', up);
  canvas.addEventListener('pointercancel', up);
  canvas.addEventListener('pointerleave', function () { if (!drag) state.hoverP = false; });

  function toggleSwitch() {
    state.closed = !state.closed;
    state.closeTip = state.closed && state.pos < 0.97 && state.fault !== 'low' && state.fault !== 'high';
    update();
    Analytics.track(NAME, state.closed ? '闭合开关' : '断开开关');
  }

  // ---------- 面板控件 ----------
  qa('[data-scene]').forEach(function (b) { b.addEventListener('click', function () { loadScene(b.dataset.scene); Analytics.track(NAME, '场景', SCENES[state.scene].name); }); });
  $('switchBtn').addEventListener('click', toggleSwitch);
  $('posRange').addEventListener('input', function () { setPos($('posRange').value / 100); });
  $('recBtn').addEventListener('click', record);
  $('clearBtn').addEventListener('click', function () { state.data.length = 0; syncPanel(); Analytics.track(NAME, '清除数据'); });
  $('newLamp').addEventListener('click', function () { state.broken = false; state.pos = 1; update(); Analytics.track(NAME, '换新灯泡'); });
  function bindSeg(attr, fn, label) {
    qa('[data-' + attr + ']').forEach(function (b) {
      b.addEventListener('click', function () { fn(b.dataset[attr]); update(); Analytics.track(NAME, label, b.textContent); });
    });
  }
  bindSeg('e', function (v) { state.E = +v; }, '电源电压');
  bindSeg('rmax', function (v) { state.Rmax = +v; }, '变阻器规格');
  bindSeg('ra', function (v) { state.rA = +v; }, '电流表量程');
  bindSeg('rv', function (v) { state.rV = +v; }, '电压表量程');
  bindSeg('r', function (v) { state.R = +v; }, '换电阻');
  bindSeg('u0', function (v) { state.U0 = +v; state.data.forEach(function (d) { d.warn = Math.abs(d.U - state.U0) > 0.05; }); }, '控制电压');
  bindSeg('fault', function (v) { state.fault = v; state.closeTip = false; }, '故障');
  bindSeg('axis', function (v) { state.inv = v === 'inv'; }, '横轴');
  $('showFlow').addEventListener('change', function () { state.showFlow = $('showFlow').checked; });
  $('reveal').addEventListener('change', function () { state.reveal = $('reveal').checked; syncPanel(); });

  // ---------- 面板开合 ----------
  $('panelToggle').addEventListener('click', function () { panel.classList.toggle('collapsed'); });
  if (window.matchMedia('(max-width: 760px)').matches) panel.classList.add('collapsed');
  if (window.matchMedia('(max-width: 640px)').matches) $('hint').hidden = true;

  // ---------- 尺寸与主循环 ----------
  function resize() { view.resize(stage.clientWidth, stage.clientHeight); }
  new ResizeObserver(resize).observe(stage);
  resize();

  // 演示数据：按教材的做法自动测几组
  function demo() {
    var sc = state.scene, keepR = state.R, keepPos = state.pos;
    function at(p) { state.pos = p; update(); record(); }
    if (sc === 'iu') [10, 5].forEach(function (R) { state.R = R; [1, 0.6, 0.3, 0].forEach(at); });
    else if (sc === 'ir') SCENES.ir.Rs.forEach(function (R) { state.R = R; var need = O.needRP(state.E, R, state.U0); if (need <= state.Rmax) at(need / state.Rmax); });
    else if (sc === 'measure') [1, 0.5, 0.15].forEach(at);
    else [1, 0.7, 0.45, 0.25, 0.12, 0.05].forEach(at);
    state.R = keepR; state.pos = keepPos; update();
  }

  // 支持 ?scene=iu|ir|measure|lamp、&E=、&R=、&Rmax=20|50、&pos=0~1、&closed=0、&fault=…、&rA=0.6|3、&rV=3|15、&U0=、&axis=inv、&rx=、&reveal=1、&flow=0、&demo=1
  var qs = new URLSearchParams(location.search);
  if (RX.indexOf(+qs.get('rx')) >= 0) state.rx = +qs.get('rx');
  else state.rx = RX[Math.floor(Math.random() * RX.length)];
  loadScene(qs.get('scene') || 'iu');
  var sc0 = SCENES[state.scene];
  if (['1.5', '3', '4.5', '6'].indexOf(qs.get('E')) >= 0) state.E = +qs.get('E');
  if (sc0.Rs && sc0.Rs.indexOf(+qs.get('R')) >= 0) state.R = +qs.get('R');
  if (/^(20|50)$/.test(qs.get('Rmax') || '')) state.Rmax = +qs.get('Rmax');
  if (/^(0\.6|3)$/.test(qs.get('rA') || '')) state.rA = +qs.get('rA');
  if (/^(3|15)$/.test(qs.get('rV') || '')) state.rV = +qs.get('rV');
  if (/^(1\.5|2|2\.5)$/.test(qs.get('U0') || '')) state.U0 = +qs.get('U0');
  if (FAULTS[qs.get('fault')]) state.fault = qs.get('fault');
  if (qs.get('axis') === 'inv') state.inv = true;
  if (qs.get('reveal') === '1') state.reveal = true;
  if (qs.get('flow') === '0') state.showFlow = false;
  if (qs.get('demo') === '1') demo();
  if (qs.get('pos') != null && isFinite(+qs.get('pos'))) state.pos = Math.max(0, Math.min(1, +qs.get('pos')));
  if (qs.get('closed') === '0') state.closed = false;
  update();

  var lastT = performance.now();
  function frame(t) {
    var dt = Math.min((t - lastT) / 1000, 0.1);
    lastT = t;
    state.time += dt;
    view.draw(state, sol, dt);
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // 调试用
  window.__model = { state: state, sol: function () { return sol; }, view: view, Ohm: O, load: loadScene, setPos: setPos, record: record, demo: demo, update: update };
})();
