// 欧姆定律计算：定值电阻 / 小灯泡与滑动变阻器串联，电流表、电压表读数，故障，数据拟合（不碰 DOM）
// 单位：V、A、Ω、W。电源、电表看成理想的（电压表内阻只在电路断开时用来求示数）
(function () {
  var RV = 1e7;                     // 电压表内阻：被测元件断路时它串联进电路
  var LAMP = { U: 2.5, I: 0.3, R0: 2, burn: 1.25 };   // 2.5 V 0.3 A 小灯泡；实际电压超过额定电压的 1.25 倍灯丝烧断

  // 灯丝电阻随两端电压（温度）升高而变大：R = R0 + b·U^0.75，额定电压时 R = 2.5/0.3 ≈ 8.33 Ω
  var LB = (LAMP.U / LAMP.I - LAMP.R0) / Math.pow(LAMP.U, 0.75);
  function lampR(U) { return LAMP.R0 + LB * Math.pow(Math.max(0, U), 0.75); }
  function lampI(U) { return U / lampR(U); }

  // 滑动变阻器接入电路的电阻（“一上一下”接法时为 pos·Rmax，pos 为滑片离下接线柱 A 的比例 0~1）
  function rheoR(st) {
    if (st.fault === 'low') return st.Rmax;        // 接了两个下接线柱：整根电阻丝都接入，相当于定值电阻
    if (st.fault === 'high') return 0;             // 接了两个上接线柱：只接入金属杆，电阻为零
    return st.Rmax * Math.min(1, Math.max(0, st.pos));
  }

  // st: { E, closed, load: 'R'|'lamp', R, Rmax, pos, fault: none|open|short|low|high, broken 灯丝已断 }
  // 返回 { I 电流表, U 电压表, UP 变阻器两端, RP, Rload, P 元件功率, status: open|ok|short|none, burn 本次会烧断灯丝 }
  function solve(st) {
    var RP = rheoR(st), out = { I: 0, U: 0, UP: 0, RP: RP, Rload: st.load === 'lamp' ? lampR(0) : st.R, P: 0, status: 'open', burn: false };
    if (!st.closed) return out;
    var E = st.E;
    if (st.fault === 'open' || (st.load === 'lamp' && st.broken)) {
      // 被测元件断路：电压表串联进电路，电流几乎为零，电压表示数接近电源电压
      out.I = E / (RV + RP); out.U = out.I * RV; out.UP = out.I * RP; out.Rload = Infinity; out.status = 'none';
      return out;
    }
    if (st.fault === 'short') {
      out.Rload = 0; out.U = 0;
      if (RP < 0.05) { out.status = 'short'; out.I = E / 0.05; out.UP = E; return out; }    // 电源短路
      out.I = E / RP; out.UP = E; out.status = 'ok';
      return out;
    }
    var U;
    if (st.load === 'lamp') {
      // 解 U + I(U)·RP = E（左边随 U 单调增），二分
      var lo = 0, hi = E;
      for (var k = 0; k < 60; k++) { var m = (lo + hi) / 2; if (m + lampI(m) * RP > E) hi = m; else lo = m; }
      U = (lo + hi) / 2;
      out.I = lampI(U); out.Rload = lampR(U);
      out.burn = U > LAMP.U * LAMP.burn;
    } else {
      out.I = E / (st.R + RP); U = out.I * st.R;
    }
    out.U = U; out.UP = out.I * RP; out.P = U * out.I; out.status = 'ok';
    return out;
  }

  // 学生读数：按分度值读（0~0.6 A 分度值 0.02 A，0~3 A 0.1 A；0~3 V 0.1 V，0~15 V 0.5 V）
  function division(kind, range) { return kind === 'A' ? (range === 3 ? 0.1 : 0.02) : (range === 15 ? 0.5 : 0.1); }
  function read(v, kind, range) {
    var d = division(kind, range), r = Math.round(v / d) * d;
    return Math.min(r, range);
  }
  function fmt(v, kind, range) { return read(v, kind, range).toFixed(kind === 'A' ? 2 : 1); }

  // 过原点直线拟合 I = kU（最小二乘），返回电阻 1/k
  function fitR(pts) {
    var su = 0, sui = 0;
    pts.forEach(function (p) { su += p.U * p.U; sui += p.U * p.I; });
    return sui > 0 ? su / sui : null;
  }
  function mean(a) { return a.length ? a.reduce(function (s, v) { return s + v; }, 0) / a.length : null; }

  // 能把定值电阻 R 两端电压调到 U0 所需的变阻器阻值（串联分压：U0/R = (E−U0)/RP）
  function needRP(E, R, U0) { return U0 >= E ? 0 : R * (E - U0) / U0; }

  // 坐标轴取整：1、2、2.5、5 × 10^n
  function niceCeil(v) {
    if (!(v > 0)) return 1;
    var p = Math.pow(10, Math.floor(Math.log10(v))), f = v / p;
    var s = [1, 1.2, 1.5, 2, 2.5, 3, 4, 5, 6, 8, 10].filter(function (x) { return x >= f - 1e-9; })[0];
    return s * p;
  }

  window.Ohm = { LAMP: LAMP, RV: RV, lampR: lampR, lampI: lampI, rheoR: rheoR, solve: solve, division: division,
    read: read, fmt: fmt, fitR: fitR, mean: mean, needRP: needRP, niceCeil: niceCeil };
})();
