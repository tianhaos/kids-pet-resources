(function () {
  var E = window.Equil, D = window.EquilDraw, f = E.f, sig = E.sig;
  var $ = function (id) { return document.getElementById(id); };
  var qa = function (sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); };
  var NAME = '化学平衡';

  var state = {
    scene: 'sim', rx: 'nh3', from: 'react', speed: 1, paused: false, particles: true, showC: true,
    sim: null, hist: [], marks: [], last: null, queue: [],
    quiz: null, quizOnly: null, answered: false, correct: false, choice: null, score: { n: 0, ok: 0 }
  };
  var HINTS = {
    sim: '在面板里改变浓度、压强、温度，看 v正、v逆 和各物质浓度怎样变化',
    quiz: '化学平衡 · 判断练习'
  };
  var GROUPS = { conc: '浓度', press: '压强', temp: '温度与催化剂' };

  var stage = $('stage'), panel = $('panel'), cv = $('view');
  var view = D.View(cv);
  function setSeg(attr, val) { qa('[data-' + attr + ']').forEach(function (b) { b.classList.toggle('on', b.dataset[attr] === String(val)); }); }

  // ---------- 一次新的实验 ----------
  // eq：直接从平衡状态开始；温度沿用上一次（同一反应）
  function reset(eq, T) {
    if (T == null && state.sim && state.sim.rx.id === state.rx) T = state.sim.T;
    state.sim = E.create(state.rx, state.from, T);
    state.from = state.sim.from;
    if (eq) E.settle(state.sim);
    state.hist = []; state.marks = []; state.last = null; state.queue = [];
    sampleAcc = 0;
    sample();
    view.resetParticles(state.sim);
    buildActions();
    syncUI();
  }
  var sampleAcc = 0;
  function sample() {
    var s = state.sim, r = E.info(s);
    state.hist.push({ t: s.t, vf: r.vf, vr: r.vr, c: r.c });
    while (state.hist.length > 2 && state.hist[0].t < s.t - 45) state.hist.shift();
  }

  // ---------- 改变条件 ----------
  function actionOf(id) { return E.actions(state.sim.rx).filter(function (a) { return a.id === id; })[0]; }
  function doAction(id) {
    var s = state.sim, a = actionOf(id);
    if (!a) return false;
    var why = E.can(s, id);
    if (why) { view.flash(why); return false; }
    var before = E.info(s), p0 = s.rx.gas ? E.pressure(s) : null;
    var out = E.apply(s, id), after = E.info(s);
    sample();
    state.marks.push({ t: s.t, text: a.short });
    state.last = { id: id, a: a, ex: E.explain(s, id, before, after), t: s.t,
      c0: before.c, K0: before.K, p0: p0, c1: after.c, p1: s.rx.gas ? E.pressure(s) : null, done: false };
    (out.inject || []).forEach(function (it) { view.inject(s, it[0], s.rx.gas ? 'inlet' : 'top'); });
    if (out.ar) view.inject(s, -1, 'inlet');
    view.flash(a.label);
    syncUI();
    return true;
  }
  function buildActions() {
    var box = $('acts'), rx = state.sim.rx, html = '', g = '';
    E.actions(rx).forEach(function (a) {
      if (a.group !== g) { if (g) html += '</div>'; g = a.group; html += '<h3>' + (rx.gas ? GROUPS[g] : '向试管中') + '</h3><div class="acts">'; }
      html += '<button data-act="' + a.id + '">' + a.label + '</button>';
    });
    box.innerHTML = html + '</div>';
    qa('[data-act]').forEach(function (b) {
      b.addEventListener('click', function () {
        if (state.paused) { state.paused = false; }
        if (doAction(b.dataset.act)) Analytics.track(NAME, '改变条件', E.RX[state.rx].name + ' ' + b.textContent);
      });
    });
    $('rxNote').textContent = rx.note + (rx.gas ? '' : '。溶液中的反应不讨论压强。');
  }

  // ---------- 控件 ----------
  qa('[data-scene]').forEach(function (b) {
    b.addEventListener('click', function () { setScene(b.dataset.scene); Analytics.track(NAME, '场景', b.textContent); });
  });
  function setScene(sc) {
    state.scene = sc;
    if (sc === 'quiz' && !state.quiz) newQuiz();
    syncUI();
  }
  qa('[data-rx]').forEach(function (b) {
    b.addEventListener('click', function () {
      state.rx = b.dataset.rx; state.sim = null; state.paused = false;
      reset(); Analytics.track(NAME, '反应', E.RX[state.rx].name);
    });
  });
  qa('[data-from]').forEach(function (b) {
    b.addEventListener('click', function () {
      state.from = b.dataset.from; state.paused = false;
      reset(); Analytics.track(NAME, '起始', b.textContent);
    });
  });
  $('resetBtn').addEventListener('click', function () { state.paused = false; reset(); Analytics.track(NAME, '重新开始'); });
  $('eqBtn').addEventListener('click', function () { state.paused = false; reset(true); Analytics.track(NAME, '直接从平衡开始'); });
  qa('[data-speed]').forEach(function (b) {
    b.addEventListener('click', function () { state.speed = +b.dataset.speed; syncUI(); });
  });
  function togglePause() { state.paused = !state.paused; syncUI(); }
  $('pauseBtn').addEventListener('click', togglePause);
  $('particles').addEventListener('change', function () { state.particles = $('particles').checked; });
  $('showC').addEventListener('change', function () { state.showC = $('showC').checked; });
  window.addEventListener('keydown', function (e) {
    var tg = e.target.tagName;
    if (tg === 'INPUT' || tg === 'SELECT' || tg === 'BUTTON' || tg === 'TEXTAREA') return;
    if (e.code === 'Space' && state.scene === 'sim') { e.preventDefault(); togglePause(); }
  });

  // ---------- 练习 ----------
  function newQuiz() {
    state.quiz = E.quiz(Math.random, state.quiz, state.quizOnly);
    state.answered = false; state.choice = null;
    var box = $('quizOpts');
    box.innerHTML = '';
    state.quiz.options.forEach(function (o) {
      var b = document.createElement('button');
      b.className = 'small';
      b.textContent = o;
      b.addEventListener('click', function () { answer(o); });
      box.appendChild(b);
    });
    box.classList.toggle('one', state.quiz.options.some(function (o) { return o.length > 12; }));
    syncUI();
  }
  function answer(o) {
    if (state.answered) return;
    state.answered = true; state.choice = o;
    state.correct = o === state.quiz.answer;
    state.score.n++; if (state.correct) state.score.ok++;
    Analytics.track(NAME, '练习', state.quiz.type + (state.correct ? ' 对' : ' 错'));
    syncUI();
  }
  $('nextQ').addEventListener('click', newQuiz);
  // 把题目里的反应和操作搬到模型里：从平衡开始，3 s 后执行操作
  $('showQ').addEventListener('click', function () {
    var q = state.quiz;
    state.rx = q.rx; state.from = 'react'; state.sim = null; state.paused = false;
    reset(true);
    state.queue = [{ t: 3, id: q.act }];
    setScene('sim');
    Analytics.track(NAME, '练习 → 模型', q.type);
  });

  // ---------- 面板 ----------
  $('panelToggle').addEventListener('click', function () { panel.classList.toggle('collapsed'); });
  if (window.matchMedia('(max-width: 760px)').matches) panel.classList.add('collapsed');

  function syncUI() {
    var sc = state.scene, s = state.sim, rx = s.rx;
    setSeg('scene', sc);
    qa('[data-for]').forEach(function (el) { el.hidden = el.dataset.for.split(' ').indexOf(sc) < 0; });
    $('hint').textContent = HINTS[sc];
    setSeg('rx', state.rx);
    setSeg('from', state.from);
    setSeg('speed', state.speed);
    qa('[data-from="prod"]').forEach(function (b) { b.disabled = !rx.start.prod; });
    $('pauseBtn').textContent = state.paused ? '▶ 继续' : '❚❚ 暂停';
    $('particles').checked = state.particles; $('showC').checked = state.showC;
    syncActs();
    var q = state.quiz;
    if (q) {
      $('quizQ').textContent = q.prompt;
      qa('#quizOpts button').forEach(function (b) {
        b.disabled = state.answered;
        b.classList.toggle('on', state.answered && b.textContent === q.answer);
        b.classList.toggle('no', state.answered && b.textContent === state.choice && !state.correct);
      });
      $('quizMsg').innerHTML = !state.answered ? ''
        : '<b class="' + (state.correct ? 'ok">✓ 答对了' : 'bad">✗ 应选「' + q.answer + '」') + '</b>' + q.explain;
      $('nextQ').textContent = state.answered ? '下一题 →' : '换一题';
      $('showQ').hidden = !state.answered || q.type === 'qk';
    }
  }
  var actSig = '';
  function syncActs() {
    var s = state.sim, sigs = [];
    qa('[data-act]').forEach(function (b) { var w = E.can(s, b.dataset.act); b.disabled = !!w; b.title = w || ''; sigs.push(!!w); });
    actSig = sigs.join();
  }

  // ---------- 读数 ----------
  var lastText = {};
  function setText(id, t) { if (lastText[id] !== t) { lastText[id] = t; $(id).textContent = t; } }
  function rows(list) {
    for (var k = 1; k <= 7; k++) {
      var r = list[k - 1] || ['', ''];
      setText('d' + k, r[0]); setText('r' + k, r[1]);
      $('d' + k).hidden = $('r' + k).hidden = !r[0];
    }
  }
  function cf(x) { return x >= 10 ? f(x, 1) : x >= 1 ? f(x, 2) : f(x, 3); }
  function chain(a, b, c) { return cf(a) + ' → ' + cf(b) + '（瞬间）→ ' + cf(c) + '（新平衡）'; }
  // 达到新平衡后：比较原平衡、改变的瞬间、新平衡，说明“减弱但不能抵消”
  function weaken(L, s, r) {
    var rx = s.rx, p = L.id.split(':'), i, out = '';
    if (p[0] === 'add' || p[0] === 'rm' || L.id === 'iron') {
      i = L.id === 'iron' ? 0 : E.idx(rx, p[1]);
      var up = r.c[i] > L.c0[i];
      out = 'c(' + rx.sp[i].f + ')：' + chain(L.c0[i], L.c1[i], r.c[i]) + '。新平衡时仍比原平衡' + (up ? '大' : '小') + '——平衡移动只能减弱这种改变，不能抵消。';
    } else if (p[0] === 'V' || L.id === 'ar:p') {
      if (E.gasDelta(rx) !== 0) out = '总压 p：' + chain(L.p0, L.p1, E.pressure(s)).replace(/(\d)（/g, '$1 p₀（').replace(/(\d) →/g, '$1 p₀ →') + '，平衡移动减弱了压强的变化。';
      rx.sp.forEach(function (sp, j) {
        if (sp.look !== '无色') out += 'c(' + sp.f + ')：' + chain(L.c0[j], L.c1[j], r.c[j]) + '，' + (r.c[j] > L.c0[j] ? '颜色比原来深' : '颜色比原来浅') + '。';
      });
    } else if (p[0] === 'T') {
      out = 'K：' + sig(L.K0, 3) + ' → ' + sig(r.K, 3) + '。K 只随温度变化。';
    } else if (L.id === 'water') {
      i = 2;
      out = 'c(Fe(SCN)₃)：' + chain(L.c0[i], L.c1[i], r.c[i]) + '，红色变浅。';
    }
    return out;
  }
  function readSim() {
    var s = state.sim, rx = s.rx, r = E.info(s), L = state.last;
    if (L && !L.done && s.t - L.t > 0.3 && r.eq) { L.done = true; L.weak = weaken(L, s, r); }
    var status;
    if (r.eq) status = L ? (L.ex.dir ? '达到新的平衡' : '平衡没有移动') : '已达到化学平衡';
    else if (!L) status = '正在建立化学平衡';
    else status = r.dir > 0 ? '平衡正向移动中…' : '平衡逆向移动中…';
    setText('rName', status);
    $('rName').className = r.eq ? 'gold' : r.dir > 0 ? 'fwd' : 'rev';
    setText('rKind', rx.name);
    var tip;
    if (L) {
      var ex = L.ex;
      tip = D.tName(state.marks.length - 1) + ' ' + L.a.label + '：' + ex.why + '。改变的瞬间 ' + ex.vText + '，' + ex.cmp + '，' + ex.dirText + '。' + (L.done ? L.weak : '');
    } else if (!r.eq) {
      tip = state.from === 'react' ? '从反应物开始：开始时 v逆 = 0；随着反应进行，反应物浓度减小、v正 减小，生成物浓度增大、v逆 增大，直到 v正 = v逆。'
        : '从生成物开始：开始时 v正 = 0，反应逆向进行，最终达到与“从反应物开始”相同的平衡状态。';
    } else {
      tip = '化学平衡是动态平衡：v正 = v逆 ≠ 0，各物质的浓度保持不变。粒子仍在不断反应（橙色圈为正反应，蓝色圈为逆反应）。现在可以在下方改变条件。';
    }
    setText('rTip', tip);
    var list = [
      ['时间', 't = ' + f(s.t, 1) + ' s'],
      ['速率', 'v正 = ' + sig(r.vf, 3) + '，v逆 = ' + sig(r.vr, 3)],
      ['Q 与 K', 'Q = ' + (r.Q > 0 ? sig(r.Q, 3) : '0') + '，K = ' + sig(r.K, 3)],
      ['浓度', rx.sp.map(function (sp, i) { return 'c(' + sp.f + ') = ' + cf(r.c[i]); }).join('，') + ' ' + rx.unit]
    ];
    if (rx.gas) {
      list.push(['条件', 'T = ' + Math.round(s.T) + ' °C，p = ' + f(E.pressure(s), 2) + ' p₀，V = ' + f(s.V, 2) + ' V₀' + (s.cat ? '，有催化剂' : '')]);
      var tot = E.nGas(s), pi = rx.sp.length - 1;
      list.push(['体积分数', rx.sp[pi].f + '：' + f(s.n[pi] / tot * 100, 1) + '%（不计 Ar）']);
    }
    var conv = rx.sp.map(function (sp, i) { var a = E.conversion(s, i); return a == null ? '' : sp.f + ' ' + f(a * 100, 1) + '%'; }).filter(Boolean);
    if (conv.length) list.push(['转化率', conv.join('，')]);
    rows(list);
  }
  function readQuiz() {
    var q = state.quiz, sc = state.score;
    setText('rName', !state.answered ? '判断练习' : state.correct ? '✓ 答对了' : '✗ 答错了');
    $('rName').className = !state.answered ? '' : state.correct ? 'ok' : 'bad';
    setText('rKind', '得分 ' + sc.ok + ' / ' + sc.n);
    setText('rTip', state.answered ? q.explain : q.prompt);
    rows([]);
  }

  // ---------- 推进 ----------
  function advance(dts) {
    var s = state.sim;
    while (dts > 1e-9) {
      var h = Math.min(0.05, dts);
      if (state.queue.length && s.t + h >= state.queue[0].t) {
        h = Math.max(0, state.queue[0].t - s.t);
        E.step(s, h); dts -= h; sampleAcc += h;
        doAction(state.queue.shift().id);
        continue;
      }
      E.step(s, h); dts -= h; sampleAcc += h;
      if (sampleAcc >= 0.1 - 1e-9) { sampleAcc = 0; sample(); }
    }
  }

  // ---------- 尺寸与主循环 ----------
  function resize() { view.resize(stage.clientWidth, stage.clientHeight); }
  new ResizeObserver(resize).observe(stage);

  // 支持 ?scene=sim|quiz、&rx=nh3|no2|hi|fescn、&from=react|prod、&eq=1（直接从平衡开始）、&T=（°C）、&cat=1、
  // &do=操作1,操作2（达到平衡后从 t = 3 s 起每隔 10 s 执行一个，如 V:0.5、add:N2、T:+、ar:p、iron）、&t=（快进到该时刻 s）、
  // &speed=0.5|1|2、&particles=0、&c=0（不显示 c–t 图像）、练习 &q=graph|shift|qk
  var qs = new URLSearchParams(location.search);
  if (HINTS[qs.get('scene')]) state.scene = qs.get('scene');
  if (E.RX[qs.get('rx')]) state.rx = qs.get('rx');
  if (qs.get('from') === 'prod') state.from = 'prod';
  if (['0.5', '1', '2'].indexOf(qs.get('speed')) >= 0) state.speed = +qs.get('speed');
  if (qs.get('particles') === '0') state.particles = false;
  if (qs.get('c') === '0') state.showC = false;
  if (E.TYPES.indexOf(qs.get('q')) >= 0) state.quizOnly = qs.get('q');
  var acts = (qs.get('do') || '').split(',').filter(Boolean);
  resize();
  var T0 = parseFloat(qs.get('T'));
  reset(qs.get('eq') === '1' || acts.length > 0, isFinite(T0) ? T0 : null);
  if (qs.get('cat') === '1' && state.sim.rx.cat) state.sim.cat = true;
  state.queue = acts.filter(function (id) { return actionOf(id); }).map(function (id, k) { return { t: 3 + 10 * k, id: id }; });
  var ff = parseFloat(qs.get('t'));
  if (isFinite(ff) && ff > 0) { advance(Math.min(ff, 120)); view.resetParticles(state.sim); view.flash(''); }
  setScene(state.scene);

  var lastT = performance.now(), tick = 0;
  function frame(now) {
    var dt = Math.min((now - lastT) / 1000, 0.1);
    lastT = now;
    if (state.scene === 'sim') {
      var dts = state.paused ? 0 : dt * state.speed;
      if (dts) advance(dts);
      view.drawSim(state, state.paused ? 0 : dt, dts);
      readSim();
      if ((tick += dt) > 0.3) { tick = 0; syncActs(); }
    } else {
      view.drawQuiz(state.quiz, state.answered, { quizH: $('quizBar').offsetHeight });
      readQuiz();
    }
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // 调试用
  window.__model = {
    state: state, E: E, view: view, reset: reset, doAction: doAction, advance: advance, setScene: setScene, newQuiz: newQuiz,
    answer: function (o) { answer(o == null ? state.quiz.answer : o); }
  };
})();
