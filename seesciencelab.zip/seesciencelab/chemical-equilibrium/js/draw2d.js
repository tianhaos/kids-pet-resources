// 2D 绘制：反应容器（气体：带活塞的气缸；溶液：烧杯）与微观粒子、Q 与 K 的比较条、v–t 与 c–t 图像、练习题画面
// 粒子只负责“看”：数量 = 物质的量 × scale，位置用容器内的归一化坐标 (u 右, w 下) ∈ [0,1]，容器变小粒子就变密；
// 反应进度 xi 每增加 1/scale 就发生一次“正反应事件”（反应物粒子聚到一起变成生成物），平衡时另按 v 的大小成对发生正、逆反应事件
(function () {
  var E = window.Equil, f = E.f, sig = E.sig;
  var MUTED = '#8d99ab', TEXT = '#e6ebf2', LINE = '#2a3446', GOLD = '#ffc94a';
  var VF = '#ff7a59', VR = '#4fc3f7', AR = '#9aa5b5';
  var FONT = '-apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", sans-serif';
  var TAU = Math.PI * 2;
  // 颜色深浅：每 1 浓度单位的不透明度
  var TINT = { NO2: [224, 112, 58, 0.42], I2: [181, 124, 255, 0.3], FeSCN: [220, 30, 50, 0.32], Fe: [255, 183, 77, 0.06] };
  // 粒子形状：[dx, dy, r, 颜色]，以“原子半径单位”计
  var ATOM = { N: '#5b7cff', H: '#e9eef5', O: '#ff5a4a', I: '#a46bff', Fe: '#ffb74d', S: '#ffe066', C: '#7d8796', Ar: AR };
  var SHAPE = {
    N2: [[-0.6, 0, 1, 'N'], [0.6, 0, 1, 'N']],
    H2: [[-0.42, 0, 0.62, 'H'], [0.42, 0, 0.62, 'H']],
    NH3: [[0, 0, 1, 'N'], [0.95, 0.45, 0.6, 'H'], [-0.95, 0.45, 0.6, 'H'], [0, -1.05, 0.6, 'H']],
    NO2: [[0, 0, 0.9, 'N'], [0.95, 0.55, 0.85, 'O'], [-0.95, 0.55, 0.85, 'O']],
    N2O4: [[-0.55, 0, 0.85, 'N'], [0.55, 0, 0.85, 'N'], [-1.3, 0.75, 0.75, 'O'], [-1.3, -0.75, 0.75, 'O'], [1.3, 0.75, 0.75, 'O'], [1.3, -0.75, 0.75, 'O']],
    I2: [[-0.75, 0, 1.2, 'I'], [0.75, 0, 1.2, 'I']],
    HI: [[-0.85, 0, 0.62, 'H'], [0.35, 0, 1.2, 'I']],
    Fe: [[0, 0, 1.1, 'Fe']],
    SCN: [[-0.95, 0, 0.8, 'S'], [0, 0, 0.62, 'C'], [0.85, 0, 0.7, 'N']],
    FeSCN: [[0, 0, 1.15, 'Fe'], [1.5, 0, 0.6, 'S'], [-0.75, 1.3, 0.6, 'S'], [-0.75, -1.3, 0.6, 'S'], [2.4, 0, 0.55, 'N'], [-1.2, 2.08, 0.55, 'N'], [-1.2, -2.08, 0.55, 'N']],
    Ar: [[0, 0, 0.85, 'Ar']]
  };

  function font(px, w) { return (w ? w + ' ' : '') + px + 'px ' + FONT; }
  function label(ctx, s, x, y, o) {
    o = o || {};
    ctx.font = font(o.size || 12, o.bold ? 600 : null);
    ctx.textAlign = o.align || 'center'; ctx.textBaseline = o.base || 'middle';
    ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(5,7,13,.85)'; ctx.strokeText(s, x, y);
    ctx.fillStyle = o.color || TEXT; ctx.fillText(s, x, y);
  }
  function line(ctx, x1, y1, x2, y2, color, o) {
    o = o || {};
    ctx.strokeStyle = color; ctx.lineWidth = o.width || 1.2; ctx.setLineDash(o.dash || []);
    ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke(); ctx.setLineDash([]);
  }
  function head(ctx, x, y, a, size, color) {
    ctx.fillStyle = color; ctx.beginPath(); ctx.moveTo(x, y);
    ctx.lineTo(x - size * Math.cos(a - 0.45), y - size * Math.sin(a - 0.45));
    ctx.lineTo(x - size * Math.cos(a + 0.45), y - size * Math.sin(a + 0.45)); ctx.closePath(); ctx.fill();
  }
  function rrect(ctx, x, y, w, h, r) {
    ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
  }
  function mol(ctx, id, x, y, r, a, alpha) {
    var sh = SHAPE[id]; if (!sh) return;
    var c = Math.cos(a), s = Math.sin(a);
    ctx.globalAlpha = alpha;
    for (var k = sh.length - 1; k >= 0; k--) {
      var p = sh[k], px = x + (p[0] * c - p[1] * s) * r, py = y + (p[0] * s + p[1] * c) * r;
      ctx.fillStyle = ATOM[p[3]]; ctx.beginPath(); ctx.arc(px, py, p[2] * r, 0, TAU); ctx.fill();
      ctx.strokeStyle = 'rgba(0,0,0,.45)'; ctx.lineWidth = 0.8; ctx.stroke();
    }
    ctx.globalAlpha = 1;
  }
  // 坐标轴刻度取整：1、2、2.5、5 × 10ⁿ
  function nice(x) {
    if (!(x > 0)) return 1;
    var e = Math.pow(10, Math.floor(Math.log10(x))), m = x / e;
    return (m <= 1 ? 1 : m <= 2 ? 2 : m <= 2.5 ? 2.5 : m <= 5 ? 5 : 10) * e;
  }
  var SUBN = ['₁', '₂', '₃', '₄', '₅', '₆', '₇', '₈', '₉'];
  function tName(k) { return 't' + (k < 9 ? SUBN[k] : (k + 1)); }

  // ---------- 粒子 ----------
  function Particles() {
    var list = [], rings = [], evt = 0, acc = 0, rx = null, scale = 1, now = 0;
    function make(i, u, w, born) {
      var a = Math.random() * TAU, sp = 0.6 + Math.random() * 0.8;
      return { i: i, u: u == null ? Math.random() : u, w: w == null ? Math.random() : w, vu: Math.cos(a) * sp, vw: Math.sin(a) * sp,
        a: Math.random() * TAU, va: (Math.random() - 0.5) * 3, born: born == null ? -9 : born, die: 0 };
    }
    function reset(s) {
      rx = s.rx; scale = rx.scale; list = []; rings = []; acc = 0;
      s.n.forEach(function (n, i) { for (var k = 0, m = Math.round(n * scale); k < m; k++) list.push(make(i)); });
      for (var k = 0, m = arCount(s); k < m; k++) list.push(make(-1));
      evt = Math.round(s.xi * scale);
    }
    function arCount(s) { return Math.min(90, Math.round(s.ar * scale * 0.6)); }
    function alive(i) { return list.filter(function (p) { return p.i === i && !p.die && now - p.born > 0.4; }); }
    // dirn = 1 正反应，−1 逆反应；ar 为容器宽高比（算距离用）
    function react(dirn, asp) {
      var from = [], to = [];
      rx.sp.forEach(function (sp, i) { if (sp.nu * dirn < 0) from.push([i, -sp.nu * dirn]); else to.push([i, sp.nu * dirn]); });
      var pool0 = alive(from[0][0]);
      if (!pool0.length) return false;
      var seed = pool0[Math.floor(Math.random() * pool0.length)], chosen = [seed];
      for (var j = 0; j < from.length; j++) {
        var need = from[j][1] - (j === 0 ? 1 : 0);
        if (need <= 0) continue;
        var cand = alive(from[j][0]).filter(function (p) { return chosen.indexOf(p) < 0; });
        if (cand.length < need) return false;
        cand.sort(function (a, b) { return d2(a, seed, asp) - d2(b, seed, asp); });
        chosen = chosen.concat(cand.slice(0, need));
      }
      var cu = 0, cw = 0;
      chosen.forEach(function (p) { cu += p.u; cw += p.w; });
      cu /= chosen.length; cw /= chosen.length;
      chosen.forEach(function (p) { p.die = 0.35; p.tu = cu; p.tw = cw; });
      to.forEach(function (t) {
        for (var k = 0; k < t[1]; k++) list.push(make(t[0], clamp01(cu + (Math.random() - 0.5) * 0.04), clamp01(cw + (Math.random() - 0.5) * 0.04), now + 0.2));
      });
      rings.push({ u: cu, w: cw, t: now, c: dirn > 0 ? VF : VR });
      return true;
    }
    function d2(a, b, asp) { var du = (a.u - b.u) * asp, dw = a.w - b.w; return du * du + dw * dw; }
    function clamp01(x) { return Math.max(0.02, Math.min(0.98, x)); }
    // 每帧：dt 真实秒，dts 模拟秒；info 为当前速率；asp 容器宽 / 高
    function update(s, r, dt, dts, asp, speedK) {
      now += dt;
      var target = Math.round(s.xi * scale), tries = 0;
      while (evt !== target && tries++ < 4) {
        var d = target > evt ? 1 : -1;
        if (react(d, asp)) evt += d; else { evt = target; break; }
      }
      // 动态平衡：正、逆反应一直在进行
      acc += Math.min(r.vf, r.vr) * s.V * scale * dts;
      if (acc > 3) acc = 3;
      while (acc >= 1) { acc -= 1; if (react(1, asp)) react(-1, asp); }
      for (var k = list.length - 1; k >= 0; k--) {
        var p = list[k];
        if (p.die) {
          p.die -= dt;
          p.u += (p.tu - p.u) * Math.min(1, dt * 10); p.w += (p.tw - p.w) * Math.min(1, dt * 10);
          if (p.die <= 0) list.splice(k, 1);
          continue;
        }
        var sp = speedK * (p.i < 0 ? 1.2 : 1);
        p.u += p.vu * sp * dt; p.w += p.vw * sp * dt * asp; p.a += p.va * dt;
        if (p.u < 0.02) { p.u = 0.02; p.vu = Math.abs(p.vu); } else if (p.u > 0.98) { p.u = 0.98; p.vu = -Math.abs(p.vu); }
        if (p.w < 0.02) { p.w = 0.02; p.vw = Math.abs(p.vw); } else if (p.w > 0.98) { p.w = 0.98; p.vw = -Math.abs(p.vw); }
        // 随机微扰，看起来更像热运动
        if (Math.random() < dt * 0.8) { var a = Math.random() * TAU, m = Math.hypot(p.vu, p.vw); p.vu = Math.cos(a) * m; p.vw = Math.sin(a) * m; }
      }
      rings = rings.filter(function (g) { return now - g.t < 0.7; });
    }
    // 外界加入 / 移走物质：数量对齐到 round(n·scale)；from 为 'inlet'（气体从左下进气口进入）或 'top'（溶液从液面滴入）
    function inject(s, i, from) {
      var have = list.filter(function (p) { return p.i === i && !p.die; }), want = i < 0 ? arCount(s) : Math.round(s.n[i] * scale);
      if (want > have.length) {
        for (var k = 0; k < want - have.length; k++) {
          var p = from === 'top' ? make(i, 0.35 + Math.random() * 0.3, 0.03, now) : make(i, 0.03, 0.75 + Math.random() * 0.2, now);
          if (from === 'top') { p.vw = 0.8 + Math.random(); p.vu *= 0.3; } else { p.vu = 1 + Math.random() * 1.5; }
          list.push(p);
        }
      } else {
        for (var j = 0; j < have.length - want; j++) {
          var q = have.splice(Math.floor(Math.random() * have.length), 1)[0];
          q.die = 0.5; q.tu = from === 'top' ? q.u : 0; q.tw = from === 'top' ? 0 : 0.85;
        }
      }
    }
    function counts() {
      var c = {};
      list.forEach(function (p) { if (!p.die) c[p.i] = (c[p.i] || 0) + 1; });
      return c;
    }
    return { reset: reset, update: update, inject: inject, counts: counts,
      list: function () { return list; }, rings: function () { return rings; }, now: function () { return now; } };
  }

  // ---------- 视图 ----------
  function View(canvas) {
    var ctx = canvas.getContext('2d'), W = 0, H = 0, dpr = 1, narrow = false, geo = null;
    var parts = Particles(), flash = null;
    function resize(w, h) {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      W = w; H = h; narrow = w < 640;
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
      canvas.style.width = w + 'px'; canvas.style.height = h + 'px';
    }
    function bg() {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      var g = ctx.createLinearGradient(0, 0, 0, H);
      g.addColorStop(0, '#04060c'); g.addColorStop(1, '#0a1120');
      ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    }
    function layout(showC) {
      var top = narrow ? 84 : 44, bottom = narrow ? 40 : 50, L = {};
      if (!narrow) {
        var lw = Math.min(Math.max(W * 0.4, 300), 470), hh = H - top - bottom;
        L.vessel = { x: 16, y: top, w: lw - 16, h: hh - 96 };
        L.gauge = { x: 16, y: top + hh - 84, w: lw - 16, h: 84 };
        var cx = lw + 28, cw = W - cx - 16;
        if (showC) {
          var h1 = (hh - 16) / 2;
          L.vt = { x: cx, y: top, w: cw, h: h1 };
          L.ct = { x: cx, y: top + h1 + 16, w: cw, h: h1 };
        } else L.vt = { x: cx, y: top, w: cw, h: hh };
      } else {
        var vh = Math.max(190, Math.min(300, (H - top - bottom) * 0.42));
        L.vessel = { x: 8, y: top, w: W * 0.56 - 8, h: vh };
        L.gauge = { x: W * 0.56 + 4, y: top + 4, w: W * 0.44 - 14, h: vh - 8, tall: true };
        var y0 = top + vh + 10, rest = H - bottom - y0;
        if (showC) {
          var h2 = (rest - 10) / 2;
          L.vt = { x: 10, y: y0, w: W - 20, h: h2 };
          L.ct = { x: 10, y: y0 + h2 + 10, w: W - 20, h: h2 };
        } else L.vt = { x: 10, y: y0, w: W - 20, h: rest };
      }
      return L;
    }

    // ---------- 容器 ----------
    function tempColor(rx, T) {
      if (!rx.T) return null;
      var k = (T - rx.T.min) / (rx.T.max - rx.T.min);
      var a = [80, 160, 255], b = [255, 110, 60];
      return [0, 1, 2].map(function (j) { return Math.round(a[j] + (b[j] - a[j]) * k); });
    }
    function bathName(T) { return T <= 0 ? '冰水' : T < 20 ? '冷水' : T <= 30 ? '室温' : T < 60 ? '温水' : '热水'; }
    function vessel(R, s, o) {
      var rx = s.rx, gas = rx.gas;
      var legendH = 26, titleH = 24;
      var inner = { x: R.x, y: R.y + titleH, w: R.w, h: R.h - titleH - legendH };
      label(ctx, rx.eq, R.x + R.w / 2, R.y + 10, { size: narrow ? 12 : 14, bold: true });
      var cw = Math.min(inner.w * 0.66, inner.h * 0.78, 250), cx = inner.x + inner.w / 2 - (gas ? 0 : 0);
      var yb = inner.y + inner.h - 14, hMax = inner.h - 34;
      var x0 = cx - cw / 2, x1 = cx + cw / 2, frac = gas ? s.V / E.V_RANGE[1] : s.V / 2.2;
      var yt = yb - hMax * frac;
      var tc = tempColor(rx, s.T);
      // 水浴 / 加热
      if (gas && rx.T.bath) {
        var by0 = yb - hMax * 0.42;
        ctx.fillStyle = 'rgba(' + tc.join(',') + ',.16)';
        rrect(ctx, x0 - 18, by0, cw + 36, yb - by0 + 10, 6); ctx.fill();
        ctx.strokeStyle = 'rgba(' + tc.join(',') + ',.55)'; ctx.lineWidth = 1.2; ctx.stroke();
        label(ctx, bathName(s.T) + ' ' + Math.round(s.T) + ' °C', x1 + 16, by0 - 10, { size: 11, align: 'right', color: 'rgb(' + tc.join(',') + ')' });
      } else if (gas) {
        var hg = ctx.createLinearGradient(0, yb, 0, yb + 12);
        hg.addColorStop(0, 'rgba(' + tc.join(',') + ',.85)'); hg.addColorStop(1, 'rgba(' + tc.join(',') + ',0)');
        ctx.fillStyle = hg; ctx.fillRect(x0 - 6, yb, cw + 12, 12);
        label(ctx, '加热 ' + Math.round(s.T) + ' °C', x1 + 4, yb + 6, { size: 11, align: 'left', color: 'rgb(' + tc.join(',') + ')' });
      }
      // 内容物底色
      var c = E.conc(s);
      ctx.fillStyle = gas ? 'rgba(160,190,230,.05)' : 'rgba(120,170,230,.12)';
      ctx.fillRect(x0, yt, cw, yb - yt);
      rx.sp.forEach(function (sp, i) {
        var t = TINT[sp.id]; if (!t) return;
        ctx.fillStyle = 'rgba(' + t[0] + ',' + t[1] + ',' + t[2] + ',' + Math.min(0.85, t[3] * c[i]) + ')';
        ctx.fillRect(x0, yt, cw, yb - yt);
      });
      // 催化剂
      if (s.cat) {
        ctx.fillStyle = '#5d6676';
        for (var k = 0; k < 9; k++) { ctx.beginPath(); ctx.arc(x0 + cw * (0.1 + k * 0.1), yb - 4, 3.2, 0, TAU); ctx.fill(); }
        label(ctx, rx.cat, x1 - 4, yb - 14, { size: 10, align: 'right', color: MUTED });
      }
      // 粒子
      var r = Math.max(2.2, Math.min(4.2, cw / 60)), box = { x: x0 + 3, y: yt + 3, w: cw - 6, h: yb - yt - 6 };
      if (o.particles) {
        ctx.save(); ctx.beginPath(); ctx.rect(x0, yt, cw, yb - yt); ctx.clip();
        var now = parts.now();
        parts.list().forEach(function (p) {
          var id = p.i < 0 ? 'Ar' : rx.sp[p.i].id, al = p.die ? Math.max(0, p.die / 0.35) : Math.min(1, Math.max(0, (now - p.born) / 0.3));
          mol(ctx, id, box.x + p.u * box.w, box.y + p.w * box.h, r, p.a, al);
        });
        parts.rings().forEach(function (g) {
          var k = (now - g.t) / 0.7;
          ctx.strokeStyle = g.c; ctx.globalAlpha = 1 - k; ctx.lineWidth = 1.6;
          ctx.beginPath(); ctx.arc(box.x + g.u * box.w, box.y + g.w * box.h, 4 + 14 * k, 0, TAU); ctx.stroke();
          ctx.globalAlpha = 1;
        });
        ctx.restore();
      }
      // 器壁
      ctx.strokeStyle = 'rgba(200,220,245,.75)'; ctx.lineWidth = 2;
      if (gas) {
        var top = yb - hMax - 6;
        ctx.beginPath(); ctx.moveTo(x0, top); ctx.lineTo(x0, yb); ctx.lineTo(x1, yb); ctx.lineTo(x1, top); ctx.stroke();
        // 活塞与活塞杆
        ctx.fillStyle = '#56627a'; ctx.fillRect(x0 + 1, yt - 10, cw - 2, 10);
        ctx.fillStyle = '#3d475a'; ctx.fillRect(cx - 4, top - 16, 8, yt - 10 - top + 16);
        // 进气口
        var iy = yb - (yb - yt) * 0.15;
        ctx.strokeStyle = 'rgba(200,220,245,.55)'; ctx.lineWidth = 1.5;
        line(ctx, x0 - 16, iy - 4, x0, iy - 4, 'rgba(200,220,245,.55)', { width: 1.5 });
        line(ctx, x0 - 16, iy + 4, x0, iy + 4, 'rgba(200,220,245,.55)', { width: 1.5 });
        label(ctx, 'V = ' + f(s.V, 2) + ' V₀', x1 + 6, yt - 5, { size: 11, align: 'left', color: MUTED });
      } else {
        var ty = yb - hMax - 4;
        ctx.beginPath(); ctx.moveTo(x0 - 6, ty); ctx.lineTo(x0, ty + 6); ctx.lineTo(x0, yb - 8); ctx.quadraticCurveTo(x0, yb, x0 + 8, yb);
        ctx.lineTo(x1 - 8, yb); ctx.quadraticCurveTo(x1, yb, x1, yb - 8); ctx.lineTo(x1, ty + 6); ctx.lineTo(x1 + 6, ty); ctx.stroke();
        line(ctx, x0, yt, x1, yt, 'rgba(160,200,240,.6)', { width: 1 });
      }
      // 浮动提示（刚做的操作）
      if (flash && flash.text) {
        var age = parts.now() - flash.t;
        if (age < 2.2) {
          ctx.globalAlpha = Math.min(1, (2.2 - age) * 2);
          label(ctx, flash.text, cx, Math.max(inner.y + 10, yt - 26) - age * 6, { size: 13, bold: true, color: GOLD });
          ctx.globalAlpha = 1;
        } else flash = null;
      }
      // 图例
      var items = rx.sp.map(function (sp) { return { id: sp.id, text: sp.f + (sp.look !== '无色' ? '（' + sp.look + '）' : '') }; });
      if (s.ar > 0) items.push({ id: 'Ar', text: 'Ar' });
      var ly = R.y + R.h - 10, widths = items.map(function (it) { ctx.font = font(11); return ctx.measureText(it.text).width + 26; });
      var tw = widths.reduce(function (a, b) { return a + b; }, 0), lx = R.x + Math.max(0, (R.w - tw) / 2);
      items.forEach(function (it, j) {
        mol(ctx, it.id, lx + 8, ly, 2.6, 0, 1);
        label(ctx, it.text, lx + 18, ly, { size: 11, align: 'left', color: MUTED });
        lx += widths[j];
      });
      return { asp: box.w / Math.max(20, box.h) };
    }

    // ---------- Q 与 K ----------
    function gauge(R, Q, K, o) {
      o = o || {};
      var lr = Q > 0 ? Math.log10(Q / K) : -Infinity, span = 2;
      var x0 = R.x + 8, x1 = R.x + R.w - 8, cx = (x0 + x1) / 2, y = R.tall ? R.y + R.h * 0.42 : R.y + 46;
      var X = function (v) { return cx + Math.max(-1.08, Math.min(1.08, v / span)) * (x1 - cx); };
      label(ctx, o.title || '浓度商 Q 与平衡常数 K', R.x + R.w / 2, R.tall ? R.y + 12 : R.y + 6, { size: 11, color: MUTED });
      var g = ctx.createLinearGradient(x0, 0, x1, 0);
      g.addColorStop(0, 'rgba(255,122,89,.55)'); g.addColorStop(0.5, 'rgba(255,201,74,.25)'); g.addColorStop(1, 'rgba(79,195,247,.55)');
      ctx.fillStyle = g; rrect(ctx, x0, y - 4, x1 - x0, 8, 4); ctx.fill();
      line(ctx, cx, y - 11, cx, y + 11, GOLD, { width: 2 });
      label(ctx, 'K = ' + sig(K, 3), cx, y + (R.tall ? 22 : 19), { size: 11, color: GOLD });
      var qx = X(lr);
      ctx.fillStyle = TEXT; ctx.beginPath(); ctx.moveTo(qx, y - 6); ctx.lineTo(qx - 6, y - 15); ctx.lineTo(qx + 6, y - 15); ctx.closePath(); ctx.fill();
      label(ctx, 'Q = ' + (Q > 0 ? sig(Q, 3) : '0'), Math.max(x0 + 26, Math.min(x1 - 26, qx)), y - 24, { size: 11 });
      var dir = Math.abs(lr) < 0.01 ? 0 : lr < 0 ? 1 : -1;
      var txt = dir > 0 ? 'Q < K：正向进行，v正 > v逆' : dir < 0 ? 'Q > K：逆向进行，v正 < v逆' : 'Q = K：平衡状态，v正 = v逆';
      if (R.tall) {
        label(ctx, dir > 0 ? 'Q < K' : dir < 0 ? 'Q > K' : 'Q = K', cx, y + 48, { size: 15, bold: true, color: dir > 0 ? VF : dir < 0 ? VR : GOLD });
        label(ctx, dir > 0 ? '正向进行' : dir < 0 ? '逆向进行' : '平衡状态', cx, y + 68, { size: 12, color: MUTED });
        label(ctx, dir > 0 ? 'v正 > v逆' : dir < 0 ? 'v正 < v逆' : 'v正 = v逆', cx, y + 86, { size: 12, color: MUTED });
      } else label(ctx, txt, cx, y + 38, { size: 12, bold: true, color: dir > 0 ? VF : dir < 0 ? VR : GOLD });
      label(ctx, '正向', x0 + 2, y + 19, { size: 10, align: 'left', color: VF });
      label(ctx, '逆向', x1 - 2, y + 19, { size: 10, align: 'right', color: VR });
    }

    // ---------- 图像 ----------
    // series：[{ color, name, ys: [...] }]，ts：时间数组；marks：[{ t, text }]
    function chart(R, ts, series, o) {
      var padL = 46, padR = 10, padT = 22, padB = 24;
      var P = { x: R.x + padL, y: R.y + padT, w: R.w - padL - padR, h: R.h - padT - padB };
      ctx.fillStyle = 'rgba(17,23,35,.6)'; rrect(ctx, R.x, R.y, R.w, R.h, 8); ctx.fill();
      ctx.strokeStyle = LINE; ctx.lineWidth = 1; ctx.stroke();
      label(ctx, o.title, R.x + 10, R.y + 11, { size: 12, align: 'left', bold: true, color: TEXT });
      var t0 = o.t0, t1 = o.t1, ymax = 0;
      series.forEach(function (s) { s.ys.forEach(function (y, k) { if (ts[k] >= t0 - 1e-9 && y > ymax) ymax = y; }); });
      var step = nice((ymax || 1) / 4), top = Math.max(step * Math.ceil(ymax * 1.08 / step), step);
      var X = function (t) { return P.x + (t - t0) / (t1 - t0) * P.w; }, Y = function (v) { return P.y + P.h - v / top * P.h; };
      ctx.font = font(10); ctx.fillStyle = MUTED; ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
      for (var v = 0; v <= top + 1e-9; v += step) {
        line(ctx, P.x, Y(v), P.x + P.w, Y(v), 'rgba(42,52,70,.7)', { width: 1 });
        ctx.fillStyle = MUTED; ctx.fillText(sig(v, 3), P.x - 5, Y(v));
      }
      var tStep = nice((t1 - t0) / (narrow ? 4 : 6));
      ctx.textAlign = 'center'; ctx.textBaseline = 'top';
      for (var t = Math.ceil(t0 / tStep) * tStep; t <= t1 + 1e-9; t += tStep) { if (!o.noT && X(t) < P.x + P.w - 30) ctx.fillText(f(t, 1), X(t), P.y + P.h + 4); }
      line(ctx, P.x, P.y + P.h, P.x + P.w, P.y + P.h, MUTED, { width: 1 });
      line(ctx, P.x, P.y, P.x, P.y + P.h, MUTED, { width: 1 });
      label(ctx, 't / s', P.x + P.w, P.y + P.h + 11, { size: 10, align: 'right', color: MUTED });
      label(ctx, o.unit, R.x + R.w - 10, R.y + 11, { size: 10, align: 'right', color: MUTED });
      // 事件标记
      (o.marks || []).forEach(function (m) {
        if (m.t < t0 || m.t > t1) return;
        line(ctx, X(m.t), P.y, X(m.t), P.y + P.h, 'rgba(255,201,74,.55)', { dash: [4, 4] });
        label(ctx, m.name + (m.text ? ' ' + m.text : ''), X(m.t) + 4, P.y + 8, { size: 11, align: 'left', color: GOLD });
      });
      ctx.save(); ctx.beginPath(); ctx.rect(P.x, P.y - 2, P.w, P.h + 4); ctx.clip();
      series.forEach(function (s) {
        ctx.strokeStyle = s.color; ctx.lineWidth = s.width || 2; ctx.setLineDash(s.dash || []);
        ctx.beginPath();
        var started = false;
        for (var k = 0; k < ts.length; k++) {
          if (ts[k] < t0 - 0.2) continue;
          var x = X(ts[k]), y = Y(s.ys[k]);
          if (started) ctx.lineTo(x, y); else { ctx.moveTo(x, y); started = true; }
        }
        ctx.stroke(); ctx.setLineDash([]);
      });
      ctx.restore();
      // 图例：标题右边一行（不和事件标记重叠）
      ctx.font = font(12, 600);
      var lx = R.x + 22 + ctx.measureText(o.title).width;
      series.forEach(function (s) {
        ctx.font = font(11);
        label(ctx, s.name, lx, R.y + 11, { size: 11, align: 'left', color: s.color });
        lx += ctx.measureText(s.name).width + 12;
      });
      return { X: X, Y: Y, P: P };
    }

    // ---------- 主场景 ----------
    function drawSim(st, dt, dts) {
      bg();
      var s = st.sim, rx = s.rx, L = layout(st.showC), r = E.info(s);
      var spK = 0.22 * (rx.gas ? Math.sqrt(E.TK(s.T) / E.TK(rx.T ? rx.T.t0 : 25)) : 0.4);
      var vg = vessel(L.vessel, s, { particles: st.particles });
      parts.update(s, r, dt, dts, vg.asp, spK);
      gauge(L.gauge, r.Q, r.K);
      // 图像窗口：最近 30 s
      var hist = st.hist, ts = hist.map(function (h) { return h.t; });
      var t1 = Math.max(30, s.t), t0 = t1 - 30;
      var marks = st.marks.map(function (m, k) { return { t: m.t, name: tName(k), text: narrow ? '' : m.text }; });
      chart(L.vt, ts, [
        { color: VF, name: 'v正', ys: hist.map(function (h) { return h.vf; }) },
        { color: VR, name: 'v逆', ys: hist.map(function (h) { return h.vr; }), dash: [6, 3] }
      ], { title: '速率—时间图像', unit: rx.unit.replace('/L', '·L⁻¹') + '·s⁻¹', t0: t0, t1: t1, marks: marks });
      if (L.ct) {
        chart(L.ct, ts, rx.sp.map(function (sp, i) { return { color: sp.color, name: 'c(' + sp.f + ')', ys: hist.map(function (h) { return h.c[i]; }) }; }),
          { title: '浓度—时间图像', unit: rx.unit.replace('/L', '·L⁻¹'), t0: t0, t1: t1, marks: marks });
      }
      geo = { scene: 'sim' };
    }

    // ---------- 练习 ----------
    function area(bottomExtra) {
      var t0 = narrow ? 84 : 44, bottom = (narrow ? 40 : 50) + (bottomExtra || 0);
      return { x: 14, y: t0, w: W - 28, h: Math.max(160, H - t0 - bottom) };
    }
    function drawQuiz(q, answered, o) {
      bg();
      var R = area((o.quizH || 180) + 8);
      if (!q) return;
      if (q.type === 'graph') quizGraph(R, q, answered);
      else if (q.type === 'shift') quizShift(R, q, answered);
      else quizQK(R, q, answered);
      geo = { scene: 'quiz' };
    }
    function quizGraph(R, q, answered) {
      var pts = q.curve.pts, ts = pts.map(function (p) { return p.t; }), rx = E.RX[q.rx];
      var w = Math.min(R.w, 760), x = R.x + (R.w - w) / 2;
      var two = answered && R.h > 300, h = two ? (R.h - 12) / 2 : Math.min(R.h, 420);
      var V = { x: x, y: R.y, w: w, h: h };
      chart(V, ts, [
        { color: VF, name: 'v正', ys: pts.map(function (p) { return p.vf; }) },
        { color: VR, name: 'v逆', ys: pts.map(function (p) { return p.vr; }), dash: [6, 3] }
      ], { title: 'v–t 图像', unit: '', t0: 0, t1: ts[ts.length - 1], marks: [{ t: q.curve.t1, name: 't₁', text: answered ? q.answer : '' }], noT: true });
      if (two) {
        chart({ x: x, y: R.y + h + 12, w: w, h: h }, ts, rx.sp.map(function (sp, i) { return { color: sp.color, name: 'c(' + sp.f + ')', ys: pts.map(function (p) { return p.c[i]; }) }; }),
          { title: 'c–t 图像（模型计算）', unit: '', t0: 0, t1: ts[ts.length - 1], marks: [{ t: q.curve.t1, name: 't₁' }], noT: true });
      }
    }
    function card(x, y, w, h, title, lines, color) {
      ctx.fillStyle = 'rgba(17,23,35,.75)'; rrect(ctx, x, y, w, h, 10); ctx.fill();
      ctx.strokeStyle = color || LINE; ctx.lineWidth = 1; ctx.stroke();
      label(ctx, title, x + w / 2, y + 16, { size: 12, color: MUTED });
      lines.forEach(function (ln, k) { label(ctx, ln.t, x + w / 2, y + 42 + k * 24, { size: ln.size || 15, bold: ln.bold, color: ln.color || TEXT }); });
    }
    function bars(x, y, w, h, title, vf, vr, top) {
      label(ctx, title, x + w / 2, y + h + 12, { size: 12, color: MUTED });
      var bw = Math.min(34, w / 4);
      [[vf, VF, 'v正'], [vr, VR, 'v逆']].forEach(function (b, k) {
        var bh = b[0] / top * h, bx = x + w / 2 + (k ? 6 : -6 - bw);
        ctx.fillStyle = b[1]; ctx.globalAlpha = 0.8; ctx.fillRect(bx, y + h - bh, bw, bh); ctx.globalAlpha = 1;
        label(ctx, b[2], bx + bw / 2, y + h - bh - 10, { size: 11, color: b[1] });
      });
      line(ctx, x, y + h, x + w, y + h, MUTED, { width: 1 });
    }
    function quizShift(R, q, answered) {
      var rx = E.RX[q.rx], cx = R.x + R.w / 2;
      label(ctx, rx.eq + (rx.dH != null ? '　ΔH < 0' : ''), cx, R.y + 24, { size: narrow ? 15 : 20, bold: true });
      var w = Math.min(R.w, 520), y = R.y + 56;
      card(cx - w / 2, y, w, 70, '达到平衡后', [{ t: q.cond, color: GOLD, bold: true }]);
      if (!answered) {
        label(ctx, '平衡向哪个方向移动？', cx, y + 104, { size: 14, color: MUTED });
        return;
      }
      var s = E.create(q.rx, 'react'); E.settle(s);
      var b = E.info(s); E.apply(s, q.act); var a = E.info(s);
      var top = Math.max(b.vf, b.vr, a.vf, a.vr) * 1.15, bh = Math.min(150, R.h - 200), bw = Math.min(160, w / 2 - 10);
      if (bh > 50) {
        bars(cx - bw - 20, y + 96, bw, bh, '原平衡', b.vf, b.vr, top);
        bars(cx + 20, y + 96, bw, bh, '改变条件的瞬间', a.vf, a.vr, top);
      }
      var arrow = a.dir > 0 ? '平衡 → 正向移动' : a.dir < 0 ? '平衡 ← 逆向移动' : '平衡不移动';
      label(ctx, arrow, cx, Math.min(R.y + R.h - 10, y + 96 + Math.max(bh, 0) + 40), { size: 15, bold: true, color: a.dir > 0 ? VF : a.dir < 0 ? VR : GOLD });
    }
    function quizQK(R, q, answered) {
      var rx = E.RX[q.rx], cx = R.x + R.w / 2, w = Math.min(R.w, 520);
      label(ctx, rx.eq, cx, R.y + 24, { size: narrow ? 15 : 20, bold: true });
      var lines = rx.sp.map(function (sp, i) { return { t: 'c(' + sp.f + ') = ' + q.c[i] + ' mol/L', size: 14, color: sp.color }; });
      card(cx - w / 2, R.y + 50, w, 34 + lines.length * 24, '某时刻　K = ' + sig(q.K, 3), lines);
      var y = R.y + 50 + 34 + lines.length * 24 + 16;
      if (!answered) { label(ctx, 'Q = ' + q.expr + ' = ?', cx, y + 14, { size: 14, color: MUTED }); return; }
      label(ctx, 'Q = ' + q.expr + ' = ' + sig(q.Q, 3), cx, y + 14, { size: 14, color: TEXT });
      if (R.h - (y - R.y) > 110) gauge({ x: cx - w / 2, y: y + 36, w: w, h: 66 }, q.Q, q.K, { title: '比较 Q 与 K' });
    }

    return {
      resize: resize, drawSim: drawSim, drawQuiz: drawQuiz,
      resetParticles: function (s) { parts.reset(s); },
      inject: function (s, i, from) { parts.inject(s, i, from); },
      counts: function () { return parts.counts(); },
      flash: function (text) { flash = { text: text, t: parts.now() }; },
      geo: function () { return geo; }, narrow: function () { return narrow; }
    };
  }

  window.EquilDraw = { View: View, tName: tName };
})();
