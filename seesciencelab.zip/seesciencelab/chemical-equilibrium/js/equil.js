// 化学平衡与勒夏特列原理的计算：反应数据、质量作用定律的速率、平衡常数随温度变化、
// 隐式（后向欧拉）推进、求平衡组成、改变条件的操作与平衡移动判断、练习题
// 单位：气体反应浓度 mol/L、溶液反应 mmol/L，时间 s（示意，比真实反应快得多），温度 °C，体积以开始时为 1
// 速率：v正 = k正·∏c(反应物)^系数，v逆 = k逆·∏c(生成物)^系数（按基元反应处理，便于画 v–t 图像），K = k正/k逆
// 温度：ln K = ln K₀ + VH·(1/T − 1/T₀)（VH = −ΔH/R 的示意值，放热反应 VH > 0）；k正 ∝ exp(−EA·(1/T − 1/T₀))
(function () {
  var CAT = 3;           // 催化剂使 k正、k逆 同时增大的倍数
  var H = 0.02;          // 推进步长 s
  var V_RANGE = [0.25, 2.4];

  // sp：物质（nu < 0 为反应物、> 0 为生成物），add：每次加入的量（按开始时的体积折算成浓度）
  // start：从反应物 / 从生成物开始时的浓度（两者等效），scale：每 1 浓度单位（体积 1 时）画几个粒子
  var RX = {
    nh3: {
      id: 'nh3', name: '合成氨', eq: 'N₂(g) + 3H₂(g) ⇌ 2NH₃(g)', dH: -92.4, gas: true, unit: 'mol/L',
      sp: [
        { id: 'N2', f: 'N₂', nu: -1, color: '#6b8cff', add: 0.5, look: '无色' },
        { id: 'H2', f: 'H₂', nu: -3, color: '#cfd8e3', add: 1.5, look: '无色' },
        { id: 'NH3', f: 'NH₃', nu: 2, color: '#7ee081', add: 0.5, look: '无色', rm: true }
      ],
      start: { react: [1, 3, 0], prod: [0, 0, 2] },
      T: { t0: 500, min: 400, max: 600, step: 50 }, K0: 0.18, VH: 4200, kf: 0.05, EA: 6000, scale: 22,
      cat: '铁触媒', note: '工业合成氨：铁触媒、400～500 °C、10～30 MPa，并及时把氨液化分离'
    },
    no2: {
      id: 'no2', name: 'NO₂ 与 N₂O₄', eq: '2NO₂(g) ⇌ N₂O₄(g)', dH: -56.9, gas: true, unit: 'mol/L',
      sp: [
        { id: 'NO2', f: 'NO₂', nu: -2, color: '#e0703a', add: 0.5, look: '红棕色' },
        { id: 'N2O4', f: 'N₂O₄', nu: 1, color: '#e8dcc4', add: 0.25, look: '无色', rm: true }
      ],
      start: { react: [1.2, 0], prod: [0, 0.6] },
      T: { t0: 25, min: 0, max: 100, step: 25, bath: true }, K0: 2, VH: 2600, kf: 0.6, EA: 2500, scale: 50,
      cat: '催化剂', note: '把封有 NO₂ 的烧瓶放进热水颜色变深、放进冰水颜色变浅'
    },
    hi: {
      id: 'hi', name: '氢气与碘蒸气', eq: 'H₂(g) + I₂(g) ⇌ 2HI(g)', dH: -9.4, gas: true, unit: 'mol/L',
      sp: [
        { id: 'H2', f: 'H₂', nu: -1, color: '#cfd8e3', add: 0.5, look: '无色' },
        { id: 'I2', f: 'I₂', nu: -1, color: '#b57cff', add: 0.5, look: '紫色' },
        { id: 'HI', f: 'HI', nu: 2, color: '#ffc94a', add: 0.5, look: '无色', rm: true }
      ],
      start: { react: [1, 1, 0], prod: [0, 0, 2] },
      T: { t0: 400, min: 300, max: 500, step: 50 }, K0: 16, VH: 2000, kf: 1, EA: 5000, scale: 30,
      cat: '催化剂', note: '反应前后气体分子数相等，改变压强平衡不移动'
    },
    fescn: {
      id: 'fescn', name: 'Fe³⁺ 与 SCN⁻', eq: 'Fe³⁺ + 3SCN⁻ ⇌ Fe(SCN)₃', dH: null, gas: false, unit: 'mmol/L',
      sp: [
        { id: 'Fe', f: 'Fe³⁺', nu: -1, color: '#ffb74d', add: 1, look: '黄色' },
        { id: 'SCN', f: 'SCN⁻', nu: -3, color: '#8fd0ff', add: 3, look: '无色' },
        { id: 'FeSCN', f: 'Fe(SCN)₃', nu: 1, color: '#ff4d5e', look: '红色' }
      ],
      start: { react: [2.5, 7.5, 0], prod: null },
      T: null, K0: 0.0075, kf: 0.002, scale: 6,
      cat: null, note: '5 mL 0.005 mol/L FeCl₃ 溶液与 5 mL 0.015 mol/L KSCN 溶液混合'
    }
  };
  var ORDER = ['nh3', 'no2', 'hi', 'fescn'];

  function clamp(x, a, b) { return Math.max(a, Math.min(b, x)); }
  function f(x, n) { return (+x.toFixed(n == null ? 2 : n)).toString(); }
  // 有效数字
  function sig(x, n) {
    if (!isFinite(x)) return '∞';
    if (x === 0) return '0';
    n = n || 3;
    var e = Math.floor(Math.log10(Math.abs(x)));
    if (e >= 5 || e <= -4) {
      var m = x / Math.pow(10, e);
      return (+m.toFixed(n - 1)) + '×10' + sup(e);
    }
    return (+x.toPrecision(n)).toString();
  }
  function sup(e) {
    var map = { '-': '⁻', 0: '⁰', 1: '¹', 2: '²', 3: '³', 4: '⁴', 5: '⁵', 6: '⁶', 7: '⁷', 8: '⁸', 9: '⁹' };
    return String(e).split('').map(function (ch) { return map[ch]; }).join('');
  }
  function pick(rand, arr) { return arr[Math.floor(rand() * arr.length) % arr.length]; }
  function shuffle(rand, arr) {
    arr = arr.slice();
    for (var i = arr.length - 1; i > 0; i--) { var j = Math.floor(rand() * (i + 1)); var t = arr[i]; arr[i] = arr[j]; arr[j] = t; }
    return arr;
  }
  function TK(t) { return t + 273.15; }

  // ---------- 平衡常数与速率常数 ----------
  function K(rx, T) {
    if (!rx.T) return rx.K0;
    return rx.K0 * Math.exp(rx.VH * (1 / TK(T) - 1 / TK(rx.T.t0)));
  }
  function kf(rx, T, cat) {
    var k = rx.kf * (cat ? CAT : 1);
    if (!rx.T) return k;
    return k * Math.exp(-rx.EA * (1 / TK(T) - 1 / TK(rx.T.t0)));
  }
  function prodPow(rx, c, side) {
    var p = 1;
    rx.sp.forEach(function (s, i) { if (side * s.nu > 0) p *= Math.pow(Math.max(c[i], 0), Math.abs(s.nu)); });
    return p;
  }
  // 浓度商 Q（生成物浓度幂之积 / 反应物浓度幂之积）
  function Q(rx, c) {
    var den = prodPow(rx, c, -1), num = prodPow(rx, c, 1);
    return den > 0 ? num / den : num > 0 ? Infinity : NaN;
  }
  function rates(rx, c, T, cat) {
    var a = kf(rx, T, cat), b = a / K(rx, T);
    return { vf: a * prodPow(rx, c, -1), vr: b * prodPow(rx, c, 1) };
  }
  // 反应进度 x（浓度单位）的取值范围：各物质浓度不能为负
  function xBounds(rx, c) {
    var lo = -Infinity, hi = Infinity;
    rx.sp.forEach(function (s, i) {
      if (s.nu < 0) hi = Math.min(hi, c[i] / -s.nu);
      else lo = Math.max(lo, -c[i] / s.nu);
    });
    return [lo, hi];
  }
  function shifted(rx, c, x) { return c.map(function (ci, i) { return Math.max(0, ci + rx.sp[i].nu * x); }); }

  // 求平衡：Q(x) 随 x 单调增大，二分求 Q = K
  function equilibrium(rx, c, T) {
    var b = xBounds(rx, c), Kt = K(rx, T), lo = b[0], hi = b[1];
    for (var i = 0; i < 80; i++) {
      var m = (lo + hi) / 2, q = Q(rx, shifted(rx, c, m));
      if (!(q < Kt)) hi = m; else lo = m;
    }
    return shifted(rx, c, (lo + hi) / 2);
  }

  // 后向欧拉一步：x = h·(v正 − v逆)(c + νx)，左边减右边随 x 单调增，二分求根（稳定且浓度不会变负）
  function stepC(rx, c, T, cat, h) {
    var b = xBounds(rx, c), lo = b[0], hi = b[1];
    function g(x) { var r = rates(rx, shifted(rx, c, x), T, cat); return x - h * (r.vf - r.vr); }
    if (g(0) === 0) return c.slice();
    if (g(0) > 0) hi = 0; else lo = 0;
    for (var i = 0; i < 60; i++) { var m = (lo + hi) / 2; if (g(m) > 0) hi = m; else lo = m; }
    return shifted(rx, c, (lo + hi) / 2);
  }

  // ---------- 模拟状态 ----------
  // n：各物质的物质的量（体积 1 时与浓度数值相同），V：体积，ar：充入的稀有气体，fed：各反应物累计加入量（算转化率）
  function create(id, from, T) {
    var rx = RX[id];
    if (!rx.start[from]) from = 'react';
    var n = rx.start[from].slice();
    var s = {
      rx: rx, from: from, n: n, V: 1, ar: 0, T: rx.T ? (T != null ? clamp(T, rx.T.min, rx.T.max) : rx.T.t0) : 25, cat: false,
      t: 0, xi: 0, fed: n.map(function (v, i) { return rx.sp[i].nu < 0 ? v : 0; }), p0: 0
    };
    s.p0 = pressure(s, true);
    return s;
  }
  function conc(s) { return s.n.map(function (v) { return v / s.V; }); }
  function nGas(s) { return s.n.reduce(function (a, b) { return a + b; }, 0); }
  // 气体总压（任意单位）：p ∝ n·T/V；raw 为 true 时返回原始值
  function pressure(s, raw) {
    var p = (nGas(s) + s.ar) * TK(s.T) / s.V;
    return raw ? p : p / s.p0;
  }
  function clone(s) {
    var o = {};
    for (var k in s) o[k] = Array.isArray(s[k]) ? s[k].slice() : s[k];
    return o;
  }
  function step(s, dt) {
    var c = conc(s), rx = s.rx;
    while (dt > 1e-9) {
      var h = Math.min(H, dt);
      var c2 = stepC(rx, c, s.T, s.cat, h);
      // 进度（物质的量）：用第一种物质的变化换算
      s.xi += (c2[0] - c[0]) / rx.sp[0].nu * s.V;
      c = c2; dt -= h; s.t += h;
    }
    s.n = c.map(function (v) { return v * s.V; });
  }
  function settle(s) {
    var c = equilibrium(s.rx, conc(s), s.T);
    s.xi += (c[0] - conc(s)[0]) / s.rx.sp[0].nu * s.V;
    s.n = c.map(function (v) { return v * s.V; });
  }
  function info(s) {
    var c = conc(s), r = rates(s.rx, c, s.T, s.cat), q = Q(s.rx, c), k = K(s.rx, s.T);
    var lr = Math.log(q / k), eqd = Math.abs(r.vf - r.vr) <= 0.01 * Math.max(r.vf, r.vr, 1e-12) || Math.abs(lr) < 0.01;
    return { c: c, vf: r.vf, vr: r.vr, Q: q, K: k, dir: eqd ? 0 : lr < 0 ? 1 : -1, eq: eqd };
  }
  function conversion(s, i) {
    if (!(s.fed[i] > 0)) return null;
    var a = (s.fed[i] - s.n[i]) / s.fed[i];
    return a >= -1e-9 ? Math.max(0, a) : null;
  }

  // ---------- 改变条件 ----------
  // 每个操作：id、按钮文字 label、简称 short（标在图像上）、kind
  function actions(rx) {
    var list = [];
    if (rx.gas) {
      rx.sp.forEach(function (sp) {
        list.push({ id: 'add:' + sp.id, label: '充入 ' + sp.f, short: '增大 c(' + sp.f + ')', kind: 'conc', group: 'conc' });
      });
      rx.sp.forEach(function (sp) {
        if (sp.rm) list.push({ id: 'rm:' + sp.id, label: '分离出一半 ' + sp.f, short: '减小 c(' + sp.f + ')', kind: 'conc', group: 'conc' });
      });
      list.push({ id: 'V:0.5', label: '压缩到原体积的 1/2', short: '增大压强', kind: 'press', group: 'press' });
      list.push({ id: 'V:2', label: '扩大到原体积的 2 倍', short: '减小压强', kind: 'press', group: 'press' });
      list.push({ id: 'ar:V', label: '恒容充入 Ar', short: '恒容充 Ar', kind: 'inert', group: 'press' });
      list.push({ id: 'ar:p', label: '恒压充入 Ar', short: '恒压充 Ar', kind: 'inert', group: 'press' });
      list.push({ id: 'T:+', label: '升高温度', short: '升温', kind: 'temp', group: 'temp' });
      list.push({ id: 'T:-', label: '降低温度', short: '降温', kind: 'temp', group: 'temp' });
      list.push({ id: 'cat', label: '加入' + rx.cat, short: '催化剂', kind: 'cat', group: 'temp' });
    } else {
      list.push({ id: 'add:Fe', label: '滴加 FeCl₃ 浓溶液', short: '加 FeCl₃', kind: 'conc', group: 'conc' });
      list.push({ id: 'add:SCN', label: '滴加 KSCN 浓溶液', short: '加 KSCN', kind: 'conc', group: 'conc' });
      list.push({ id: 'iron', label: '加入少量铁粉', short: '加铁粉', kind: 'conc', group: 'conc' });
      list.push({ id: 'kcl', label: '加入少量 KCl 固体', short: '加 KCl', kind: 'none', group: 'conc' });
      list.push({ id: 'water', label: '加水稀释到 2 倍体积', short: '加水稀释', kind: 'dilute', group: 'conc' });
    }
    return list;
  }
  function idx(rx, id) { for (var i = 0; i < rx.sp.length; i++) if (rx.sp[i].id === id) return i; return -1; }

  // 能否执行（返回 null 表示可以，否则返回原因）
  function can(s, id) {
    var rx = s.rx, p = id.split(':'), i;
    if (p[0] === 'add') { i = idx(rx, p[1]); return s.n[i] / Math.max(rx.start.react[i] || 0, rx.sp[i].add * 2) > 4 ? '加得太多了，先重新开始' : null; }
    if (p[0] === 'rm') { i = idx(rx, p[1]); return s.n[i] < 1e-3 ? '已经没有 ' + rx.sp[i].f + ' 了' : null; }
    if (p[0] === 'V') return s.V * +p[1] < V_RANGE[0] - 1e-9 ? '已经压缩到最小' : s.V * +p[1] > V_RANGE[1] + 1e-9 ? '已经扩大到最大' : null;
    if (id === 'ar:p') return s.V * (1 + 0.5) > V_RANGE[1] + 1e-9 ? '容器已经扩大到最大' : s.ar > 3 * nGas(s) ? '充入太多了' : null;
    if (id === 'ar:V') return s.ar > 3 * nGas(s) ? '充入太多了' : null;
    if (p[0] === 'T') return !rx.T ? '本实验不讨论温度' : (p[1] === '+' ? s.T >= rx.T.max : s.T <= rx.T.min) ? '已到温度范围的' + (p[1] === '+' ? '上限' : '下限') : null;
    if (id === 'cat') return s.cat ? '已经加入了催化剂' : null;
    if (id === 'iron') return s.n[0] < 0.2 * s.V ? 'Fe³⁺ 已经很少了' : null;
    if (id === 'water') return s.V * 2 > 2.01 ? '已经稀释过了' : null;
    return null;
  }

  // 执行操作，直接修改 s。返回 { inject: [物质下标, 粒子变化量（物质的量）], vScale } 供画面做动画
  function apply(s, id) {
    var rx = s.rx, p = id.split(':'), i, out = { id: id };
    if (p[0] === 'add') {
      i = idx(rx, p[1]);
      var dn = rx.sp[i].add;
      s.n[i] += dn; if (rx.sp[i].nu < 0) s.fed[i] += dn;
      out.inject = [[i, dn]];
    } else if (p[0] === 'rm') {
      i = idx(rx, p[1]);
      out.inject = [[i, -s.n[i] / 2]];
      s.n[i] /= 2;
    } else if (p[0] === 'V') {
      out.vScale = +p[1]; s.V *= +p[1];
    } else if (id === 'ar:V') {
      var a = 0.5 * nGas(s); s.ar += a; out.ar = a;
    } else if (id === 'ar:p') {
      // 恒压：充入后容器体积按总物质的量成比例增大（之后活塞固定）
      var add = 0.5 * (nGas(s) + s.ar);
      out.vScale = (nGas(s) + s.ar + add) / (nGas(s) + s.ar);
      s.V *= out.vScale; s.ar += add; out.ar = add;
    } else if (p[0] === 'T') {
      s.T = clamp(s.T + (p[1] === '+' ? 1 : -1) * rx.T.step, rx.T.min, rx.T.max);
    } else if (id === 'cat') {
      s.cat = true;
    } else if (id === 'iron') {
      // 2Fe³⁺ + Fe = 3Fe²⁺：消耗约 40% 的 Fe³⁺
      out.inject = [[0, -s.n[0] * 0.4]];
      s.n[0] *= 0.6;
    } else if (id === 'water') {
      out.vScale = 2; s.V *= 2;
    }
    return out;
  }

  // 操作瞬间的速率变化与平衡移动方向（用于读数里的解释）
  // before / after：操作前后的 info()
  function explain(s, id, before, after) {
    var rx = s.rx, p = id.split(':'), dir = after.dir, i;
    var dirText = dir > 0 ? '平衡向正反应方向移动' : dir < 0 ? '平衡向逆反应方向移动' : '平衡不移动';
    var dv = function (a, b) { var r = b / a; return r > 1.005 ? '增大' : r < 0.995 ? '减小' : '不变'; };
    var vText = 'v正' + dv(before.vf, after.vf) + '、v逆' + dv(before.vr, after.vr);
    var cmp = dir > 0 ? 'v正 > v逆' : dir < 0 ? 'v正 < v逆' : 'v正 = v逆';
    var dn = gasDelta(rx), why = '';
    if (p[0] === 'add' || p[0] === 'rm') {
      i = idx(rx, p[1]);
      var w = p[0] === 'add' ? '增大' : '减小';
      why = w + ' c(' + rx.sp[i].f + ')，即' + w + (rx.sp[i].nu < 0 ? '反应物' : '生成物') + '浓度';
    } else if (p[0] === 'V') {
      why = (+p[1] < 1 ? '体积缩小、压强增大，各物质浓度都增大到原来的 2 倍' : '体积扩大、压强减小，各物质浓度都减小为原来的一半');
      why += dn === 0 ? '，但反应前后气体分子数相等，Q 不变' : '，平衡向气体分子数' + ((+p[1] < 1) === (dn < 0) ? '减少' : '增多') + '的方向移动';
    } else if (id === 'ar:V') {
      why = '容积不变，充入 Ar 后总压增大，但各物质的浓度不变';
    } else if (id === 'ar:p') {
      why = '压强不变，充入 Ar 后容器体积增大，各物质浓度减小，相当于减压' + (dn === 0 ? '；反应前后气体分子数相等' : '');
    } else if (p[0] === 'T') {
      why = (p[1] === '+' ? '温度升高，平衡向吸热' : '温度降低，平衡向放热') + '反应方向移动（正反应放热，ΔH < 0），K 变' + (after.K > before.K ? '大' : '小');
    } else if (id === 'cat') {
      why = '催化剂同等程度地增大正、逆反应速率，只缩短达到平衡的时间';
    } else if (id === 'iron') {
      why = '2Fe³⁺ + Fe = 3Fe²⁺，c(Fe³⁺) 减小';
    } else if (id === 'kcl') {
      why = 'K⁺、Cl⁻ 不参与反应，各物质浓度不变';
    } else if (id === 'water') {
      why = '稀释后各离子浓度都减小，Q = c(Fe(SCN)₃)/[c(Fe³⁺)·c³(SCN⁻)] 变为原来的 8 倍，Q > K';
    }
    return { why: why, vText: vText, cmp: cmp, dirText: dirText, dir: dir };
  }
  function gasDelta(rx) { return rx.sp.reduce(function (a, s) { return a + s.nu; }, 0); }

  // ---------- 练习 ----------
  var CHANGES = {
    addR: { text: '增大反应物浓度', act: function (rx) { return 'add:' + rx.sp[0].id; } },
    rmP: { text: '减小生成物浓度', act: function (rx) { return 'rm:' + rx.sp[rx.sp.length - 1].id; } },
    up: { text: '增大压强（缩小容积）', act: function () { return 'V:0.5'; } },
    down: { text: '减小压强（扩大容积）', act: function () { return 'V:2'; } },
    hot: { text: '升高温度', act: function () { return 'T:+'; } },
    cold: { text: '降低温度', act: function () { return 'T:-'; } },
    cat: { text: '使用催化剂', act: function () { return 'cat'; } }
  };
  var CH_KEYS = ['addR', 'rmP', 'up', 'down', 'hot', 'cold', 'cat'];
  // 生成一段 v–t、c–t 曲线：先达到平衡，pre 秒后执行操作，再推进 post 秒
  function curve(id, act, pre, post) {
    var s = create(id, 'react');
    settle(s);
    var pts = [], dt = 0.1;
    function rec() { var r = info(s); pts.push({ t: s.t, vf: r.vf, vr: r.vr, c: r.c }); }
    s.t = 0;
    for (; s.t < pre - 1e-9;) { rec(); step(s, dt); }
    rec();
    var t1 = s.t;
    apply(s, act);
    rec();
    for (var k = 0; k < post / dt; k++) { step(s, dt); rec(); }
    return { pts: pts, t1: t1, s: s };
  }
  function dirOf(id, act) {
    var s = create(id, 'react'); settle(s); apply(s, act);
    return info(s).dir;
  }

  function quizGraph(rand) {
    var id = pick(rand, ['nh3', 'nh3', 'no2', 'hi']), rx = RX[id];
    var key = pick(rand, CH_KEYS);
    if (id === 'hi' && (key === 'addR' || key === 'rmP')) key = pick(rand, ['up', 'cat', 'hot']);
    var cv = curve(id, CHANGES[key].act(rx), 4, 14);
    var same = id === 'hi' && (key === 'up' || key === 'cat');
    var answer = same ? '使用催化剂或增大压强' : CHANGES[key].text;
    var pool = CH_KEYS.filter(function (k) { return k !== key && !(id === 'hi' && (k === 'addR' || k === 'rmP' || k === 'up' || k === 'cat')); })
      .map(function (k) { return CHANGES[k].text; });
    if (id === 'hi') pool.push(same ? '只能是使用催化剂' : '使用催化剂或增大压强');
    var opts = shuffle(rand, [answer].concat(shuffle(rand, pool).slice(0, 3)));
    var dn = gasDelta(rx), e;
    var after = cv.pts[cv.pts.length - 1];
    if (key === 'addR') e = 't₁ 时 v正 突然增大而 v逆 瞬间不变（图像连续），说明增大了反应物浓度，v正 > v逆，平衡正向移动。';
    else if (key === 'rmP') e = 't₁ 时 v逆 突然减小而 v正 瞬间不变，说明减小了生成物浓度，v正 > v逆，平衡正向移动。';
    else if (same) e = 't₁ 时 v正、v逆 同等程度增大，平衡不移动。使用催化剂可以；该反应前后气体分子数相等，增大压强也会使两个速率同等程度增大。';
    else if (key === 'cat') e = 't₁ 时 v正、v逆 同等程度增大，仍然相等，平衡不移动——这是使用催化剂。该反应前后气体分子数不等，改变压强时两个速率增大的程度不同。';
    else if (key === 'up' || key === 'down') e = 't₁ 时两个速率都突然' + (key === 'up' ? '增大' : '减小') + '，且 v正 ' + (key === 'up' ? '>' : '<') + ' v逆。正反应气体分子数' + (dn < 0 ? '减少' : '增多') + '，' + (key === 'up' ? '增大压强平衡向气体分子数减少的方向' : '减小压强平衡向气体分子数增多的方向') + '移动，即' + (key === 'up' ? '正' : '逆') + '向移动。';
    else e = 't₁ 时两个速率都突然' + (key === 'hot' ? '增大' : '减小') + '，且 v逆 ' + (key === 'hot' ? '>' : '<') + ' v正，平衡' + (key === 'hot' ? '逆' : '正') + '向移动。正反应放热，' + (key === 'hot' ? '升高温度平衡向吸热（逆反应）' : '降低温度平衡向放热（正反应）') + '方向移动，吸热方向的速率变化更大。';
    if (key === 'up' && !same) e += '若是升温，两个速率也都增大，但 v逆 增大得更多。';
    return {
      type: 'graph', rx: id, key: key, act: CHANGES[key].act(rx), curve: cv, after: after,
      prompt: '对于 ' + rx.eq + '　ΔH < 0，达到平衡后在 t₁ 时刻只改变一个条件，v–t 图像如图。改变的条件可能是：',
      answer: answer, options: opts, explain: e
    };
  }

  // 平衡移动方向（含易错情形）
  var SHIFTS = [
    { rx: 'nh3', act: 'add:N2', q: '增大 N₂ 的浓度', more: 'H₂ 的转化率增大，N₂ 自身的转化率反而减小。' },
    { rx: 'nh3', act: 'rm:NH3', q: '及时把生成的 NH₃ 分离出去', more: '工业上把氨液化分离，就是为了使平衡不断正向移动。' },
    { rx: 'nh3', act: 'V:0.5', q: '缩小容器体积（增大压强）', more: '正反应是气体分子数减少的反应。' },
    { rx: 'nh3', act: 'T:+', q: '升高温度', more: '正反应放热，升温平衡逆向移动，K 减小；工业上选 400～500 °C 是兼顾速率和催化剂活性。' },
    { rx: 'nh3', act: 'cat', q: '加入铁触媒', more: '使用催化剂能缩短达到平衡的时间，但不能提高 NH₃ 的平衡含量。' },
    { rx: 'nh3', act: 'ar:V', q: '保持容积不变，充入氩气', more: '总压增大，但 N₂、H₂、NH₃ 的浓度都没变，Q 仍等于 K。' },
    { rx: 'nh3', act: 'ar:p', q: '保持压强不变，充入氩气', more: '容器体积增大，各物质浓度减小，相当于减压，平衡向气体分子数增多的方向移动。' },
    { rx: 'no2', act: 'V:0.5', q: '把容器体积压缩为原来的一半', more: '颜色先变深（浓度突然变为 2 倍）后变浅，但最终比原来深——平衡移动只能减弱这种改变。' },
    { rx: 'no2', act: 'T:+', q: '把烧瓶放进热水中', more: '正反应放热，升温平衡向生成 NO₂ 的方向移动，颜色变深。' },
    { rx: 'no2', act: 'T:-', q: '把烧瓶放进冰水中', more: '降温平衡向放热方向（生成 N₂O₄）移动，颜色变浅。' },
    { rx: 'no2', act: 'add:N2O4', q: '恒容时再充入一些 N₂O₄', more: '只看操作瞬间：c(N₂O₄) 增大，Q > K。' },
    { rx: 'hi', act: 'V:0.5', q: '缩小容器体积（增大压强）', more: '反应前后气体分子数相等，平衡不移动；但 c(I₂) 变大，颜色变深。' },
    { rx: 'hi', act: 'add:H2', q: '恒容时充入 H₂', more: 'I₂ 的转化率增大，颜色变浅。' },
    { rx: 'hi', act: 'T:+', q: '升高温度', more: '正反应放热，升温平衡逆向移动。' },
    { rx: 'fescn', act: 'add:SCN', q: '滴加几滴 KSCN 浓溶液', more: '溶液红色加深。' },
    { rx: 'fescn', act: 'iron', q: '加入少量铁粉', more: 'Fe 把 Fe³⁺ 还原为 Fe²⁺，c(Fe³⁺) 减小，红色变浅。' },
    { rx: 'fescn', act: 'kcl', q: '加入少量 KCl 固体', more: '实际参加反应的是 Fe³⁺ 和 SCN⁻，K⁺、Cl⁻ 不参与反应，颜色基本不变。' },
    { rx: 'fescn', act: 'water', q: '加水稀释', more: 'Q = c(Fe(SCN)₃)/[c(Fe³⁺)·c³(SCN⁻)]，各浓度都减半时 Q 变为原来的 8 倍，Q > K。' }
  ];
  var DIRS = ['向正反应方向移动', '向逆反应方向移动', '不移动'];
  function quizShift(rand, avoid) {
    var it, tries = 0;
    do { it = pick(rand, SHIFTS); } while (avoid && it.q + it.rx === avoid && ++tries < 8);
    var rx = RX[it.rx], d = dirOf(it.rx, it.act);
    var ans = DIRS[d > 0 ? 0 : d < 0 ? 1 : 2];
    var s = create(it.rx, 'react'); settle(s);
    var b = info(s); apply(s, it.act);
    var ex = explain(s, it.act, b, info(s));
    return {
      type: 'shift', rx: it.rx, act: it.act, cid: it.q + it.rx, cond: it.q,
      prompt: '反应 ' + rx.eq + (rx.dH != null ? '　ΔH < 0' : '') + ' 达到平衡后，' + it.q + '，平衡：',
      answer: ans, options: DIRS.slice(), explain: ex.why + '。' + (ex.dir ? '操作后 ' + ex.cmp + '，' : '') + ex.dirText + '。' + it.more
    };
  }

  // 由 Q 与 K 的大小判断反应进行的方向
  var QK_SET = {
    hi: { K: [4, 9, 16, 25, 49, 64], c: [0.1, 0.2, 0.4, 0.5, 0.8, 1, 1.2, 1.6, 2] },
    no2: { K: [0.5, 1, 2, 4, 5, 10], c: [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.8, 1, 2] },
    nh3: { K: [0.5, 1, 2, 4], c: [0.2, 0.4, 0.5, 1, 2] }
  };
  var QK_OPTS = ['v正 > v逆，反应向正反应方向进行', 'v正 < v逆，反应向逆反应方向进行', 'v正 = v逆，反应处于平衡状态'];
  function quizQK(rand) {
    var id = pick(rand, ['hi', 'no2', 'nh3']), rx = RX[id], set = QK_SET[id];
    var want = pick(rand, [1, -1, 0, 1, -1]), c, q, k, rel, tries = 0;
    do {
      c = rx.sp.map(function () { return pick(rand, set.c); });
      q = Q(rx, c); k = pick(rand, set.K);
      if (want === 0) k = q;
      rel = Math.abs(q / k - 1) < 1e-9 ? 0 : q < k ? 1 : -1;
    } while ((rel !== want || (want === 0 && (q !== +sig(q, 3) || q < 0.1 || q > 100)) || Math.abs(Math.log(q / k)) < (want ? 0.15 : 0)) && ++tries < 400);
    var ans = QK_OPTS[rel > 0 ? 0 : rel < 0 ? 1 : 2];
    var cText = rx.sp.map(function (s, i) { return 'c(' + s.f + ') = ' + c[i] + ' mol/L'; }).join('，');
    var expr = rx.sp.filter(function (s) { return s.nu > 0; }).map(function (s) { return 'c' + (s.nu > 1 ? sup(s.nu) : '') + '(' + s.f + ')'; }).join('·') + ' / [' +
      rx.sp.filter(function (s) { return s.nu < 0; }).map(function (s) { return 'c' + (-s.nu > 1 ? sup(-s.nu) : '') + '(' + s.f + ')'; }).join('·') + ']';
    return {
      type: 'qk', rx: id, c: c, Q: q, K: k, expr: expr,
      prompt: '某温度下 ' + rx.eq + ' 的平衡常数 K = ' + sig(k, 3) + '。某时刻测得 ' + cText + '，此时：',
      answer: ans, options: QK_OPTS.slice(),
      explain: '浓度商 Q = ' + expr + ' = ' + sig(q, 3) + '，' + (rel > 0 ? 'Q < K，反应向正反应方向进行，v正 > v逆。' : rel < 0 ? 'Q > K，反应向逆反应方向进行，v正 < v逆。' : 'Q = K，反应处于平衡状态，v正 = v逆。')
    };
  }

  var TYPES = ['graph', 'shift', 'qk'];
  function quiz(rand, avoid, only) {
    var t = only || pick(rand, TYPES), q, tries = 0;
    do {
      q = t === 'graph' ? quizGraph(rand) : t === 'shift' ? quizShift(rand, avoid && avoid.cid) : quizQK(rand);
      q.id = q.type + '|' + q.prompt + '|' + (q.key || '');
    } while (avoid && q.id === avoid.id && ++tries < 10);
    return q;
  }

  window.Equil = {
    RX: RX, ORDER: ORDER, CAT: CAT, V_RANGE: V_RANGE, TYPES: TYPES, CHANGES: CHANGES,
    clamp: clamp, f: f, sig: sig, sup: sup, TK: TK,
    K: K, kf: kf, Q: Q, rates: rates, equilibrium: equilibrium, gasDelta: gasDelta,
    create: create, conc: conc, nGas: nGas, pressure: pressure, clone: clone, step: step, settle: settle, info: info, conversion: conversion,
    actions: actions, can: can, apply: apply, explain: explain, idx: idx, curve: curve, quiz: quiz
  };
})();
