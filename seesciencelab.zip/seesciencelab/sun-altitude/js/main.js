(function () {
  var S = window.SunPath, A = window.Astro, D = window.SunDraw;
  var $ = function (id) { return document.getElementById(id); };
  var qa = function (sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); };
  var VIEW0 = { yaw: 155, pitch: 20 };

  var state = {
    scene: 'path',
    lat: 39.9, day: 173, t: 9,
    yaw: VIEW0.yaw, pitch: VIEW0.pitch,
    mode: 'lat',
    play: { path: false, globe: false },
    show: { refs: true, equator: false, labels: true, chord: true },
    quiz: null, quizOnly: null, answered: false, correct: false, choice: null, score: { n: 0, ok: 0 }
  };

  var HINTS = {
    path: '拖动画面旋转视角 · 拖动太阳或下方时间条改变时刻',
    globe: '在剖面图上拖动绿点改变纬度 · 点击右侧曲线跳到对应纬度或日期',
    quiz: '正午太阳高度与昼夜长短练习'
  };
  var TERM_KEYS = { spring: 0, summer: 1, autumn: 2, winter: 3 };

  var stage = $('stage'), panel = $('panel'), cv = $('view');
  var view = D.View(cv);
  function decl() { return A.declination(state.day); }
  function setSeg(attr, val) { qa('[data-' + attr + ']').forEach(function (b) { b.classList.toggle('on', b.dataset[attr] === String(val)); }); }

  // ---------- 场景 ----------
  qa('[data-scene]').forEach(function (b) {
    b.addEventListener('click', function () { setScene(b.dataset.scene); Analytics.track('正午太阳高度', '场景', b.textContent); });
  });
  function setScene(sc) {
    state.scene = sc;
    setPlay('path', false); setPlay('globe', false);
    if (sc === 'quiz' && !state.quiz) newQuiz();
    $('rName').className = '';
    syncUI();
  }
  var PLAY_BTN = { path: 'playPath', globe: 'playGlobe' };
  function setPlay(k, on) {
    state.play[k] = on;
    $(PLAY_BTN[k]).textContent = on ? '❚❚ 暂停' : '▶ 播放';
    $(PLAY_BTN[k]).classList.toggle('on', on);
  }
  Object.keys(PLAY_BTN).forEach(function (k) {
    $(PLAY_BTN[k]).addEventListener('click', function () {
      setPlay(k, !state.play[k]);
      if (state.play[k]) {
        if (k === 'path' && state.t >= 23.95) state.t = 0;
        Analytics.track('正午太阳高度', '播放', k);
      }
    });
  });

  // ---------- 纬度、日期、时刻 ----------
  function bindSlider(id, get, set) {
    var el = $(id);
    el.addEventListener('input', function () { set(parseFloat(el.value)); });
    return { el: el, get: get };
  }
  var sliders = [
    bindSlider('lat', function () { return state.lat; }, function (v) { state.lat = v; }),
    bindSlider('day', function () { return state.day; }, function (v) { setPlay('globe', false); state.day = v; }),
    bindSlider('time', function () { return state.t; }, function (v) { setPlay('path', false); state.t = v; })
  ];
  var cityBox = $('cityBtns');
  S.CITIES.forEach(function (c) {
    var b = document.createElement('button');
    b.dataset.city = c.key;
    b.textContent = c.name;
    b.addEventListener('click', function () { state.lat = c.lat; Analytics.track('正午太阳高度', '地点', c.name); });
    cityBox.appendChild(b);
  });
  qa('[data-term]').forEach(function (b) {
    b.addEventListener('click', function () {
      setPlay('globe', false);
      state.day = A.TERMS[TERM_KEYS[b.dataset.term]].day;
      Analytics.track('正午太阳高度', '节气', b.textContent);
    });
  });
  qa('[data-mode]').forEach(function (b) {
    b.addEventListener('click', function () { state.mode = b.dataset.mode; syncUI(); Analytics.track('正午太阳高度', '横轴', b.textContent); });
  });
  [['showRefs', 'refs'], ['showEquator', 'equator'], ['showLabels', 'labels'], ['showChord', 'chord']].forEach(function (p) {
    $(p[0]).addEventListener('change', function () { state.show[p[1]] = $(p[0]).checked; });
  });
  $('resetView').addEventListener('click', function () { state.yaw = VIEW0.yaw; state.pitch = VIEW0.pitch; });
  $('topView').addEventListener('click', function () { state.yaw = 180; state.pitch = 89; Analytics.track('正午太阳高度', '视角', '俯视'); });
  $('southView').addEventListener('click', function () { state.yaw = 180; state.pitch = 6; Analytics.track('正午太阳高度', '视角', '面向北'); });

  // ---------- 画布拖动 ----------
  var drag = null, last = null;
  function local(e) { var r = cv.getBoundingClientRect(); return { x: e.clientX - r.left, y: e.clientY - r.top }; }
  function nearestTime(p, g) {
    var best = state.t, bd = Infinity, dc = decl();
    for (var i = 0; i <= 288; i++) {
      var t = 24 * i / 288, q = g.dome.cam.p(S.sunVec(state.lat, dc, t));
      var dd = (q.x - p.x) * (q.x - p.x) + (q.y - p.y) * (q.y - p.y);
      if (dd < bd) { bd = dd; best = t; }
    }
    return best;
  }
  function hit(p) {
    var g = view.geo(); if (!g) return null;
    if (g.scene === 'path') {
      if (p.y >= g.bar.y0 - 6 && p.y <= g.bar.y1 + 4 && p.x >= g.barRect.x && p.x <= g.barRect.x + g.barRect.w) return 'bar';
      if (Math.hypot(p.x - g.dome.sun.x, p.y - g.dome.sun.y) < 22) return 'sun';
      return 'rotate';
    }
    if (g.scene === 'globe') {
      var s = g.sec;
      if (s.P && Math.hypot(p.x - s.P.x, p.y - s.P.y) < 22) return 'obs';
      if (Math.hypot(p.x - s.cx, p.y - s.cy) < s.r * 1.1) return 'obs';
      if (inside(p, g.c1) || inside(p, g.c2)) return 'chart';
    }
    return null;
  }
  function inside(p, c) { return p.x >= c.x0 - 4 && p.x <= c.x1 + 4 && p.y >= c.y0 && p.y <= c.y1; }
  function latFromSection(p, s) {
    var a = Math.atan2(s.cy - p.y, p.x - s.cx) / S.DEG, lat;
    if (p.x >= s.cx) lat = a + s.decl;
    else lat = (a > 0 ? 180 - a : -180 - a) - s.decl;
    return S.clamp(Math.round(lat * 10) / 10, -90, 90);
  }
  function dragTo(p) {
    var g = view.geo();
    if (drag === 'bar') state.t = g.bar.tAt(p.x);
    else if (drag === 'sun') state.t = nearestTime(p, g);
    else if (drag === 'rotate') {
      state.yaw = (state.yaw - (p.x - last.x) * 0.45 + 360) % 360;
      state.pitch = S.clamp(state.pitch + (p.y - last.y) * 0.35, 4, 89);
    } else if (drag === 'obs') state.lat = latFromSection(p, g.sec);
    else if (drag === 'chart') {
      var c = (inside(p, g.c1) || p.y < g.c1.y1 + 5) ? g.c1 : g.c2, v = c.vAt(p.x);
      if (state.mode === 'lat') state.lat = Math.round(v * 10) / 10;
      else { setPlay('globe', false); state.day = Math.round(v); }
    }
    last = p;
  }
  cv.addEventListener('pointerdown', function (e) {
    if (e.button !== 0) return;
    var p = local(e);
    drag = hit(p);
    if (!drag) return;
    if (drag === 'bar' || drag === 'sun') setPlay('path', false);
    try { cv.setPointerCapture(e.pointerId); } catch (err) { /* 合成事件 */ }
    cv.style.cursor = 'grabbing';
    last = p;
    if (drag !== 'rotate') Analytics.track('正午太阳高度', '拖动', drag);
    dragTo(p);
  });
  cv.addEventListener('pointermove', function (e) {
    var p = local(e);
    if (drag) { dragTo(p); return; }
    if (e.buttons === 0) {
      var h = hit(p);
      cv.style.cursor = h === 'rotate' ? 'grab' : h ? 'pointer' : '';
    }
  });
  function endDrag(e) {
    if (!drag) return;
    drag = null;
    if (cv.hasPointerCapture(e.pointerId)) cv.releasePointerCapture(e.pointerId);
    cv.style.cursor = '';
  }
  cv.addEventListener('pointerup', endDrag);
  cv.addEventListener('pointercancel', endDrag);

  // ---------- 练习 ----------
  function newQuiz() {
    state.quiz = S.quiz(Math.random, state.quiz && state.quiz.id, state.quizOnly);
    state.answered = false; state.choice = null;
    var box = $('quizOpts');
    box.innerHTML = '';
    state.quiz.options.forEach(function (o) {
      var b = document.createElement('button');
      b.className = 'small';
      b.textContent = o;
      b.addEventListener('click', function () { answer(o); });
      box.appendChild(b);
    });
    syncUI();
  }
  function answer(o) {
    if (state.answered) return;
    state.answered = true;
    state.choice = o;
    state.correct = o === state.quiz.answer;
    state.score.n++; if (state.correct) state.score.ok++;
    Analytics.track('正午太阳高度', '练习', state.quiz.type + (state.correct ? ' 对' : ' 错'));
    syncUI();
  }
  $('nextQ').addEventListener('click', newQuiz);
  $('showQ').addEventListener('click', function () {
    var q = state.quiz;
    state.lat = q.lat; state.day = q.day;
    if (q.type === 'dir') { state.t = /升起/.test(q.answer) ? 6 : 12; setScene('path'); }
    else { state.mode = 'lat'; setScene('globe'); }
  });

  // ---------- 面板 ----------
  $('panelToggle').addEventListener('click', function () { panel.classList.toggle('collapsed'); });
  if (window.matchMedia('(max-width: 760px)').matches) panel.classList.add('collapsed');
  window.addEventListener('keydown', function (e) {
    var tg = e.target.tagName;
    if (tg === 'INPUT' || tg === 'SELECT' || tg === 'BUTTON' || tg === 'TEXTAREA') return;
    if (e.code === 'Space' && PLAY_BTN[state.scene]) { e.preventDefault(); setPlay(state.scene, !state.play[state.scene]); }
  });

  function syncUI() {
    var sc = state.scene;
    setSeg('scene', sc);
    qa('[data-for]').forEach(function (el) { el.hidden = el.dataset.for.split(' ').indexOf(sc) < 0; });
    $('hint').textContent = HINTS[sc];
    setSeg('mode', state.mode);
    [['showRefs', 'refs'], ['showEquator', 'equator'], ['showLabels', 'labels'], ['showChord', 'chord']].forEach(function (p) { $(p[0]).checked = state.show[p[1]]; });
    var q = state.quiz;
    if (q) {
      $('quizQ').textContent = q.prompt;
      qa('#quizOpts button').forEach(function (b) {
        b.disabled = state.answered;
        b.classList.toggle('on', state.answered && b.textContent === q.answer);
        b.classList.toggle('no', state.answered && b.textContent === state.choice && !state.correct);
      });
      $('quizMsg').innerHTML = !state.answered ? ''
        : '<b class="' + (state.correct ? 'ok">✓ 答对了' : 'bad">✗ 应选「' + q.answer + '」') + '</b>' + q.explain;
      $('nextQ').textContent = state.answered ? '下一题 →' : '换一题';
      $('showQ').hidden = !state.answered;
    }
  }

  // ---------- 读数 ----------
  var lastText = {};
  function setText(id, s) { if (lastText[id] !== s) { lastText[id] = s; $(id).textContent = s; } }
  function rows(list) {
    for (var k = 1; k <= 5; k++) {
      var r = list[k - 1] || ['', ''];
      setText('d' + k, r[0]); setText('r' + k, r[1]);
      $('d' + k).hidden = $('r' + k).hidden = !r[0];
    }
  }
  function deg(v) { return v.toFixed(1) + '°'; }
  function latNum(v) { return Math.abs(v) < 0.05 ? '0°' : (v < 0 ? '(−' + Math.abs(v).toFixed(1) + '°)' : v.toFixed(1) + '°'); }
  function formula(lat, dc) {
    var H = A.noonAltitude(lat, dc);
    return '90° − |' + latNum(lat) + ' − ' + latNum(dc) + '| = ' + (H > 0 ? deg(H) : deg(H) + '（太阳不升起）');
  }
  function dateText() {
    var T = S.termOf(state.day);
    return S.fmtDate(state.day) + (T ? '（' + T.name + '）' : '');
  }
  function declText(dc) {
    var mv = A.declination(state.day + 1) - dc;
    var T = S.termOf(state.day);
    var dir = T && T.key === 'summer' ? '，到达最北' : T && T.key === 'winter' ? '，到达最南' : mv > 0 ? '，向北移' : '，向南移';
    return S.fmtLat(dc) + dir;
  }
  function lenText(info) {
    if (info.kind === 'polarDay') return '24 小时（极昼）';
    if (info.kind === 'polarNight') return '0（极夜）';
    return A.formatHours(info.len) + '（' + A.formatClock(info.rise) + '—' + A.formatClock(info.set) + '）';
  }

  function readPath() {
    var dc = decl(), info = S.dayInfo(state.lat, dc), sun = S.sunAt(state.lat, dc, state.t);
    var up = sun.alt > 0;
    setText('rName', up ? '太阳高度 ' + deg(sun.alt) : '太阳在地平线以下');
    var tt = state.t;
    setText('rKind', Math.abs(tt - 12) < 0.05 ? '正午' : !up ? '夜晚' : tt < 12 ? '上午' : '下午');
    var tip;
    if (info.kind === 'polarDay') tip = '极昼：太阳整天不落，绕着天空转一圈，子夜时太阳在正' + (state.lat > 0 ? '北' : '南') + '方，高度 ' + deg(info.midAlt) + '。';
    else if (info.kind === 'polarNight') tip = '极夜：太阳整天在地平线以下，正午也看不到太阳。';
    else if (Math.abs(state.lat) > 89.9) tip = '极点上太阳一天中高度不变，绕着地平线转圈。';
    else if (Math.abs(dc) < 0.3) tip = '二分日太阳直射赤道：全球日出正东、日落正西，昼夜等长。';
    else tip = '直射点在' + (dc > 0 ? '北' : '南') + '半球：日出' + S.riseDir(dc) + '、日落' + S.setDir(dc) + '；' +
      (state.lat * dc > 0 ? '这里与直射点同在一个半球，昼长夜短。' : Math.abs(state.lat) < 0.05 ? '赤道上始终昼夜等长。' : '这里与直射点不在同一半球，昼短夜长。');
    setText('rTip', tip);
    var sh = S.shadow(sun.alt, sun.az);
    var shText = !sh ? '—' : sh.len > 50 ? '很长，朝' + S.dirName(sh.az, 3) : sh.len < 0.01 ? '几乎没有（太阳在头顶）' : '竿高的 ' + sh.len.toFixed(2) + ' 倍，朝' + S.dirName(sh.az, 3);
    var noonDir = info.noonDir === 'zenith' ? '正午太阳在天顶' : '正午太阳在正' + (info.noonDir === 'S' ? '南' : '北');
    rows([
      ['直射点', declText(dc)],
      ['正午太阳高度', formula(state.lat, dc)],
      ['昼长', lenText(info)],
      ['日出、日落', info.kind === 'normal' ? S.dirName(info.riseAz, 0.6) + '升、' + S.dirName(info.setAz, 0.6) + '落 · ' + noonDir : noonDir],
      ['此刻影子', shText]
    ]);
  }

  function readGlobe() {
    var dc = decl(), info = S.dayInfo(state.lat, dc), H = info.noonAlt;
    setText('rName', H > 0 ? '正午太阳高度 ' + deg(H) : '正午太阳不升起');
    setText('rKind', dateText());
    var tip;
    if (Math.abs(state.lat - dc) < 0.3) tip = '这里正是直射点：正午太阳在头顶，高度 90°，竿子没有影子。';
    else tip = '正午太阳高度从直射点（90°）向南北两侧递减，纬度相差多少度，高度就减少多少度。' + (H > 0 ? '这里离直射点 ' + deg(Math.abs(state.lat - dc)) + '。' : '');
    setText('rTip', tip);
    var good = H > 3;
    rows([
      ['直射点', declText(dc)],
      ['计算', formula(state.lat, dc)],
      ['昼长', lenText(info)],
      ['楼间距', good ? '≥ 楼高 × ' + (1 / Math.tan(H * S.DEG)).toFixed(2) + '（1 / tan H）' : '—'],
      ['热水器倾角', H > 0 ? deg(90 - H) + '（90° − H）' : '—']
    ]);
  }

  function readQuiz() {
    var q = state.quiz, sc = state.score;
    setText('rName', !state.answered ? '判断练习' : state.correct ? '✓ 答对了' : '✗ 答错了');
    $('rName').className = !state.answered ? '' : state.correct ? 'ok' : 'bad';
    setText('rKind', '得分 ' + sc.ok + ' / ' + sc.n);
    setText('rTip', state.answered ? q.explain : q.prompt);
    rows([]);
  }

  // ---------- 尺寸与主循环 ----------
  function resize() { view.resize(stage.clientWidth, stage.clientHeight); }
  new ResizeObserver(resize).observe(stage);

  // 支持 ?scene=path|globe|quiz；&lat=−90~90 或 &city=beijing；&date=MM-DD 或 &term=spring|summer|autumn|winter；
  // &t=0~24（地方时）；&x=lat|date（分布图横轴）；&q=calc|dir|len 只出某一类题
  var qs = new URLSearchParams(location.search);
  if (HINTS[qs.get('scene')]) state.scene = qs.get('scene');
  function num(k, lo, hi) { var v = parseFloat(qs.get(k)); return isFinite(v) && v >= lo && v <= hi ? v : null; }
  var v;
  var city = S.CITIES.filter(function (c) { return c.key === qs.get('city'); })[0];
  if (city) state.lat = city.lat;
  if ((v = num('lat', -90, 90)) != null) state.lat = v;
  if (TERM_KEYS[qs.get('term')] != null) state.day = A.TERMS[TERM_KEYS[qs.get('term')]].day;
  var dm = /^(\d{1,2})-(\d{1,2})$/.exec(qs.get('date') || '');
  if (dm && +dm[1] >= 1 && +dm[1] <= 12 && +dm[2] >= 1 && +dm[2] <= 31) state.day = A.wrapDay(A.dateToDay(+dm[1], +dm[2]));
  if ((v = num('t', 0, 24)) != null) state.t = v;
  if (qs.get('x') === 'date') state.mode = 'date';
  if (S.TYPES.indexOf(qs.get('q')) >= 0) state.quizOnly = qs.get('q');

  resize();
  setScene(state.scene);

  var lastT = performance.now();
  function frame(now) {
    var dt = Math.min((now - lastT) / 1000, 0.1);
    lastT = now;
    var sc = state.scene;
    if (sc === 'path' && state.play.path) {
      state.t += 2 * dt;
      if (state.t >= 24) state.t -= 24;
    }
    if (sc === 'globe' && state.play.globe) {
      state.day += 20 * dt;
      if (state.day >= 366) state.day -= 365;
    }
    sliders.forEach(function (s) { if (document.activeElement !== s.el) s.el.value = s.get(); });
    setText('latOut', S.fmtLat(state.lat).replace('（赤道）', ' 赤道'));
    setText('dayOut', S.fmtDate(state.day));
    setText('timeOut', A.formatClock(state.t));
    qa('[data-city]').forEach(function (b) {
      var c = S.CITIES.filter(function (x) { return x.key === b.dataset.city; })[0];
      b.classList.toggle('on', Math.abs(c.lat - state.lat) < 0.05);
    });
    var T = S.termOf(state.day);
    setSeg('term', T ? T.key : '');

    var dc = decl();
    if (sc === 'path') {
      view.drawPath({ lat: state.lat, decl: dc, t: state.t, yaw: state.yaw, pitch: state.pitch, show: state.show });
      readPath();
    } else if (sc === 'globe') {
      view.drawGlobe({ lat: state.lat, decl: dc, day: state.day, mode: state.mode, chord: state.show.chord });
      readGlobe();
    } else {
      view.drawQuiz(state.quiz, state.answered, { quizH: $('quizBar').offsetHeight });
      readQuiz();
    }
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // 调试用
  window.__model = {
    state: state, setScene: setScene, newQuiz: newQuiz, syncUI: syncUI,
    setLat: function (x) { state.lat = S.clamp(x, -90, 90); },
    setDay: function (d) { state.day = A.wrapDay(d); },
    setTime: function (t) { state.t = S.clamp(t, 0, 24); },
    setView: function (yaw, pitch) { state.yaw = yaw; state.pitch = S.clamp(pitch, 4, 89); }
  };
})();
