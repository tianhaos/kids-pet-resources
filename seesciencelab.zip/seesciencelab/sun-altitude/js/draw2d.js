// 2D 绘制：太阳视运动天球（正交投影的伪 3D，可拖动旋转）、正午经线剖面（光照与正午太阳高度）、纬度/日期分布图、24 小时昼夜条、练习题画面
// 天球坐标同 SunPath：x 东、y 北、z 天顶，天球半径 1；剖面图太阳光从右边水平射来，纬度 φ 的点在“自直射点起逆时针 φ − δ”处
(function () {
  var S = window.SunPath, A = window.Astro, DEG = S.DEG;
  var GOLD = '#ffc94a', CYAN = '#4fc3f7', MUTED = '#8d99ab', LINE = '#2a3446', TEXT = '#e6ebf2', NIGHT = '#6f86c9';
  var FONT = '-apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", sans-serif';
  var TERM_DECL = [{ name: '夏至', d: 23.44 }, { name: '二分', d: 0 }, { name: '冬至', d: -23.44 }];
  var STARS = [];
  for (var i = 0; i < 160; i++) STARS.push([Math.random(), Math.random() * 0.7, 0.4 + Math.random() * 1.1]);

  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
  function font(px, w) { return (w ? w + ' ' : '') + px + 'px ' + FONT; }
  function roundRect(ctx, x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
  }
  function label(ctx, s, x, y, o) {
    o = o || {};
    ctx.font = font(o.size || 12, o.bold ? 600 : null);
    ctx.textAlign = o.align || 'center'; ctx.textBaseline = o.base || 'middle';
    ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(5,7,13,.85)'; ctx.strokeText(s, x, y);
    ctx.fillStyle = o.color || TEXT; ctx.fillText(s, x, y);
  }
  function arrow(ctx, x1, y1, x2, y2, size) {
    var a = Math.atan2(y2 - y1, x2 - x1);
    ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(x2, y2);
    ctx.lineTo(x2 - size * Math.cos(a - 0.4), y2 - size * Math.sin(a - 0.4));
    ctx.lineTo(x2 - size * Math.cos(a + 0.4), y2 - size * Math.sin(a + 0.4));
    ctx.closePath(); ctx.fill();
  }
  function sunDisc(ctx, x, y, r, dim) {
    var g = ctx.createRadialGradient(x, y, 0, x, y, r * 3);
    g.addColorStop(0, dim ? 'rgba(255,200,80,.25)' : 'rgba(255,220,120,.9)');
    g.addColorStop(0.35, dim ? 'rgba(255,180,60,.08)' : 'rgba(255,190,60,.35)');
    g.addColorStop(1, 'rgba(255,160,0,0)');
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r * 3, 0, 7); ctx.fill();
    ctx.fillStyle = dim ? 'rgba(255,201,74,.45)' : '#ffd54f';
    ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.fill();
  }

  // ---------- 天球：正交投影 ----------
  // yaw：相机所在方位角（从北顺时针），pitch：相机仰角
  function camera(yaw, pitch, cx, cy, R) {
    var a = yaw * DEG, p = pitch * DEG;
    var c = { x: Math.sin(a) * Math.cos(p), y: Math.cos(a) * Math.cos(p), z: Math.sin(p) };
    var f = { x: -c.x, y: -c.y, z: -c.z };
    var rl = Math.hypot(f.y, f.x);
    var right = { x: f.y / rl, y: -f.x / rl, z: 0 };
    var up = { x: right.y * f.z - right.z * f.y, y: right.z * f.x - right.x * f.z, z: right.x * f.y - right.y * f.x };
    return {
      cx: cx, cy: cy, R: R, c: c,
      p: function (v, s) {
        s = s == null ? 1 : s;
        return {
          x: cx + R * s * (v.x * right.x + v.y * right.y + v.z * right.z),
          y: cy - R * s * (v.x * up.x + v.y * up.y + v.z * up.z),
          d: v.x * c.x + v.y * c.y + v.z * c.z
        };
      }
    };
  }
  function polyline(ctx, cam, vs, s) {
    ctx.beginPath();
    vs.forEach(function (v, i) { var q = cam.p(v, s); if (i) ctx.lineTo(q.x, q.y); else ctx.moveTo(q.x, q.y); });
  }
  // 把一条轨迹按地平线切成地上、地下两组线段
  function splitByHorizon(pts) {
    var up = [], down = [], cur = null, curUp = null;
    pts.forEach(function (p) {
      var u = p.v.z >= 0;
      if (cur && u === curUp) cur.push(p);
      else {
        // 在交界处补一个地平线上的点，避免断开
        if (cur && cur.length) {
          var a = cur[cur.length - 1], k = a.v.z / (a.v.z - p.v.z);
          var m = { t: a.t + (p.t - a.t) * k, v: { x: a.v.x + (p.v.x - a.v.x) * k, y: a.v.y + (p.v.y - a.v.y) * k, z: 0 } };
          cur.push(m);
          cur = [m, p];
        } else cur = [p];
        curUp = u;
        (u ? up : down).push(cur);
      }
    });
    return { up: up, down: down };
  }

  // o: { lat, decl, t, yaw, pitch, show:{refs, grid, labels}, narrow }
  function dome(ctx, rect, o) {
    var narrow = o.narrow;
    var R = Math.min(rect.w * (narrow ? 0.44 : 0.4), rect.h * 0.62);
    var cam = camera(o.yaw, o.pitch, rect.x + rect.w / 2, rect.y + rect.h * 0.08 + R * Math.cos(o.pitch * DEG) + 18, R);
    var info = S.dayInfo(o.lat, o.decl), sun = S.sunAt(o.lat, o.decl, o.t);
    var show = o.show || {};

    // 地平线以上的天穹轮廓（正交投影下是半个圆）与高度圈
    ctx.save();
    var skyA = clamp((sun.alt + 6) / 30, 0, 1);
    var g = ctx.createRadialGradient(cam.cx, cam.cy, 0, cam.cx, cam.cy, R);
    g.addColorStop(0, 'rgba(70,120,190,' + (0.08 + 0.32 * skyA) + ')');
    g.addColorStop(1, 'rgba(40,70,130,' + (0.05 + 0.2 * skyA) + ')');
    ctx.fillStyle = g;
    var horizon = [];
    for (var k = 0; k <= 96; k++) { var a = k / 96 * Math.PI * 2; horizon.push({ x: Math.sin(a), y: Math.cos(a), z: 0 }); }
    // 天穹 = 半圆（上）+ 地平椭圆的上半部分包络：用填充圆、再盖地面即可
    ctx.beginPath(); ctx.arc(cam.cx, cam.cy, R, Math.PI, 0); ctx.closePath(); ctx.fill();
    if (show.grid !== false) {
      ctx.strokeStyle = 'rgba(141,153,171,.18)'; ctx.lineWidth = 1;
      [30, 60].forEach(function (h) {
        var r = Math.cos(h * DEG), z = Math.sin(h * DEG), pts = [];
        for (var k = 0; k <= 96; k++) { var a = k / 96 * Math.PI * 2; pts.push({ x: r * Math.sin(a), y: r * Math.cos(a), z: z }); }
        polyline(ctx, cam, pts); ctx.stroke();
      });
      // 子午圈（南—天顶—北）
      var mer = [];
      for (var m = 0; m <= 48; m++) { var b = m / 48 * Math.PI; mer.push({ x: 0, y: Math.cos(b), z: Math.sin(b) }); }
      polyline(ctx, cam, mer); ctx.stroke();
    }
    ctx.strokeStyle = 'rgba(141,153,171,.35)';
    ctx.beginPath(); ctx.arc(cam.cx, cam.cy, R, Math.PI, 0); ctx.stroke();
    ctx.restore();

    var today = splitByHorizon(S.path(o.lat, o.decl, 192));
    // 地平线以下的轨迹：虚线、暗
    ctx.save();
    ctx.setLineDash([4, 5]); ctx.lineWidth = 1.5; ctx.strokeStyle = 'rgba(255,201,74,.35)';
    today.down.forEach(function (seg) { polyline(ctx, cam, seg.map(function (p) { return p.v; })); ctx.stroke(); });
    ctx.restore();

    // 地面
    ctx.save();
    polyline(ctx, cam, horizon); ctx.closePath();
    var gg = ctx.createLinearGradient(0, cam.cy - R * Math.sin(o.pitch * DEG), 0, cam.cy + R * Math.sin(o.pitch * DEG));
    gg.addColorStop(0, 'rgba(46,70,52,.92)'); gg.addColorStop(1, 'rgba(30,48,36,.92)');
    ctx.fillStyle = gg; ctx.fill();
    ctx.strokeStyle = 'rgba(126,224,129,.5)'; ctx.lineWidth = 1.2; ctx.stroke();
    // 东西、南北两条方向线
    ctx.strokeStyle = 'rgba(230,235,242,.16)'; ctx.setLineDash([3, 4]);
    [[{ x: -1, y: 0, z: 0 }, { x: 1, y: 0, z: 0 }], [{ x: 0, y: -1, z: 0 }, { x: 0, y: 1, z: 0 }]].forEach(function (l) { polyline(ctx, cam, l); ctx.stroke(); });
    ctx.restore();

    // 天赤道与天轴：说明太阳每天的轨迹都与天赤道平行
    if (show.equator) {
      ctx.save();
      var p = o.lat * DEG, eq = [];
      for (var k2 = 0; k2 <= 96; k2++) {
        var h = k2 / 96 * Math.PI * 2;
        eq.push({ x: -Math.sin(h), y: -Math.sin(p) * Math.cos(h), z: Math.cos(p) * Math.cos(h) });
      }
      var eqs = splitByHorizon(eq.map(function (v, i) { return { t: i, v: v }; }));
      ctx.strokeStyle = 'rgba(79,195,247,.55)'; ctx.lineWidth = 1; ctx.setLineDash([6, 4]);
      eqs.up.forEach(function (seg) { polyline(ctx, cam, seg.map(function (q) { return q.v; })); ctx.stroke(); });
      var pole = { x: 0, y: Math.cos(p) * (o.lat >= 0 ? 1 : -1), z: Math.abs(Math.sin(p)) };
      var pc = cam.p({ x: 0, y: 0, z: 0 }), pp = cam.p(pole, 1.12);
      ctx.setLineDash([2, 4]); ctx.strokeStyle = 'rgba(79,195,247,.7)';
      ctx.beginPath(); ctx.moveTo(pc.x, pc.y); ctx.lineTo(pp.x, pp.y); ctx.stroke();
      ctx.restore();
      if (show.labels !== false) {
        label(ctx, o.lat >= 0 ? '北极星方向（仰角 = 纬度）' : '天南极方向', pp.x, pp.y - 10, { size: 11, color: CYAN });
        var top = eqs.up.length ? eqs.up[0].reduce(function (a, b) { return b.v.z > a.v.z ? b : a; }) : null;
        if (top && Math.abs(o.lat) < 80) { var tq = cam.p(top.v); label(ctx, '天赤道', tq.x + 26, tq.y - 8, { size: 11, color: CYAN }); }
      }
    }

    // 二分二至的参考轨迹
    if (show.refs !== false) {
      TERM_DECL.forEach(function (T) {
        if (Math.abs(T.d - o.decl) < 0.6) return;
        var sp = splitByHorizon(S.path(o.lat, T.d, 144));
        ctx.save(); ctx.strokeStyle = 'rgba(230,235,242,.32)'; ctx.lineWidth = 1.2;
        sp.up.forEach(function (seg) { polyline(ctx, cam, seg.map(function (q) { return q.v; })); ctx.stroke(); });
        ctx.restore();
        if (show.labels !== false && sp.up.length) {
          var hi = S.sunAt(o.lat, T.d, 12);
          if (hi.alt > 2) {
            var q = cam.p(S.sunVec(o.lat, T.d, 12));
            label(ctx, T.name, q.x, q.y - 9, { size: 11, color: MUTED });
          }
        }
      });
    }

    // 今天的轨迹：天球背面（离相机远的一侧）画得淡一些，帮助看出前后
    ctx.save(); ctx.lineJoin = 'round'; ctx.lineCap = 'round';
    today.up.forEach(function (seg) {
      for (var n = 1; n < seg.length; n++) {
        var a1 = cam.p(seg[n - 1].v), a2 = cam.p(seg[n].v), back = a1.d + a2.d < 0;
        ctx.strokeStyle = back ? 'rgba(255,201,74,.55)' : GOLD; ctx.lineWidth = back ? 1.8 : 2.8;
        ctx.beginPath(); ctx.moveTo(a1.x, a1.y); ctx.lineTo(a2.x, a2.y); ctx.stroke();
      }
    });
    // 整点刻度
    ctx.fillStyle = 'rgba(255,201,74,.85)';
    for (var hr = 0; hr < 24; hr++) {
      var v = S.sunVec(o.lat, o.decl, hr);
      if (v.z < 0.005) continue;
      var q2 = cam.p(v); ctx.beginPath(); ctx.arc(q2.x, q2.y, hr % 6 === 0 ? 2.6 : 1.6, 0, 7); ctx.fill();
    }
    ctx.restore();

    // 方位字
    [['北', 0, 1], ['东', 1, 0], ['南', 0, -1], ['西', -1, 0]].forEach(function (d) {
      var q = cam.p({ x: d[1], y: d[2], z: 0 }, 1.1);
      label(ctx, d[0], q.x, q.y, { size: 14, bold: true, color: '#cfe8d0' });
    });

    // 正午太阳高度角（画在子午面上，靠近中心）
    var noon = S.sunVec(o.lat, o.decl, 12), noonAlt = info.noonAlt;
    if (noonAlt > 0.5 && show.labels !== false) {
      var sgn = noon.y >= 0 ? 1 : -1, arc = [];
      var top2 = Math.min(noonAlt, 89.5);
      for (var j = 0; j <= 24; j++) { var b2 = j / 24 * top2 * DEG; arc.push({ x: 0, y: sgn * Math.cos(b2), z: Math.sin(b2) }); }
      ctx.save(); ctx.strokeStyle = GOLD; ctx.lineWidth = 1.4;
      polyline(ctx, cam, arc, 0.28); ctx.stroke();
      ctx.setLineDash([4, 4]); ctx.strokeStyle = 'rgba(255,201,74,.6)';
      polyline(ctx, cam, [{ x: 0, y: 0, z: 0 }, noon]); ctx.stroke();
      polyline(ctx, cam, [{ x: 0, y: 0, z: 0 }, { x: 0, y: sgn, z: 0 }]); ctx.stroke();
      ctx.restore();
      // 字写在角的地平线一端外侧，避开立竿
      var foot = cam.p({ x: 0, y: sgn, z: 0 }, 0.3), ctr = cam.p({ x: 0, y: 0, z: 0 });
      var lx = foot.x >= ctr.x ? 1 : -1;
      label(ctx, 'H = ' + noonAlt.toFixed(1) + '°', foot.x + lx * 8, foot.y + 12, { size: 12, bold: true, color: GOLD, align: lx > 0 ? 'left' : 'right' });
      var nq = cam.p(noon);
      label(ctx, '正午 12:00', nq.x, nq.y - 16, { size: 11, color: GOLD });
    }

    // 日出、日落点
    if (show.labels !== false) {
      if (info.kind === 'normal') {
        var rq = cam.p(S.sunVec(o.lat, o.decl, info.rise)), sq = cam.p(S.sunVec(o.lat, o.decl, info.set));
        ctx.fillStyle = GOLD;
        [rq, sq].forEach(function (q) { ctx.beginPath(); ctx.arc(q.x, q.y, 3.5, 0, 7); ctx.fill(); });
        label(ctx, '日出 ' + A.formatClock(info.rise), rq.x, rq.y + 14, { size: 11, color: GOLD });
        label(ctx, '日落 ' + A.formatClock(info.set), sq.x, sq.y + 14, { size: 11, color: GOLD });
      } else {
        label(ctx, info.kind === 'polarDay' ? '极昼：太阳整天在地平线以上' : '极夜：太阳整天在地平线以下',
          cam.cx, cam.cy + R * Math.sin(o.pitch * DEG) + 34, { size: 13, bold: true, color: info.kind === 'polarDay' ? GOLD : NIGHT });
      }
    }

    // 立竿与影子
    var poleH = 0.16, base = cam.p({ x: 0, y: 0, z: 0 }), tip = cam.p({ x: 0, y: 0, z: poleH });
    var sh = S.shadow(sun.alt, sun.az);
    if (sh) {
      var L = Math.min(sh.len, 5.5) * poleH;
      var e = cam.p({ x: sh.dx / sh.len * L, y: sh.dy / sh.len * L, z: 0 });
      ctx.save();
      ctx.strokeStyle = 'rgba(0,0,0,.75)'; ctx.lineWidth = 4; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(base.x, base.y); ctx.lineTo(e.x, e.y); ctx.stroke();
      // 光线：太阳 → 竿顶 → 影子末端
      if (sh.len < 5.5) {
        ctx.strokeStyle = 'rgba(255,201,74,.45)'; ctx.lineWidth = 1; ctx.setLineDash([3, 3]);
        ctx.beginPath(); ctx.moveTo(tip.x, tip.y); ctx.lineTo(e.x, e.y); ctx.stroke();
      }
      ctx.restore();
      if (show.labels !== false) label(ctx, '影子', e.x, e.y + 11, { size: 11, color: '#cfd6e0' });
    }
    ctx.save(); ctx.strokeStyle = '#e6ebf2'; ctx.lineWidth = 2.5; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(base.x, base.y); ctx.lineTo(tip.x, tip.y); ctx.stroke(); ctx.restore();

    // 太阳
    var sp2 = cam.p(sun.v);
    sunDisc(ctx, sp2.x, sp2.y, narrow ? 8 : 10, sun.alt < 0);
    if (show.labels !== false && sun.alt >= 0) {
      label(ctx, A.formatClock(o.t) + ' · 高度 ' + sun.alt.toFixed(1) + '°', sp2.x, sp2.y - (narrow ? 20 : 24), { size: 12, color: TEXT });
    }

    return { cam: cam, sun: sp2, R: R };
  }

  // ---------- 24 小时昼夜条 ----------
  function dayBar(ctx, rect, o) {
    var info = S.dayInfo(o.lat, o.decl);
    var x0 = rect.x + 34, x1 = rect.x + rect.w - 34, y = rect.y + 10, h = 12;
    var X = function (t) { return x0 + (x1 - x0) * t / 24; };
    roundRect(ctx, rect.x, rect.y - 4, rect.w, rect.h + 4, 8);
    ctx.fillStyle = 'rgba(8,11,18,.78)'; ctx.fill();
    ctx.fillStyle = '#1b2440'; ctx.fillRect(x0, y, x1 - x0, h);
    ctx.fillStyle = 'rgba(255,201,74,.85)';
    if (info.kind === 'polarDay') ctx.fillRect(x0, y, x1 - x0, h);
    else if (info.kind === 'normal') ctx.fillRect(X(info.rise), y, X(info.set) - X(info.rise), h);
    ctx.font = font(10); ctx.fillStyle = MUTED; ctx.textAlign = 'center'; ctx.textBaseline = 'top';
    for (var t = 0; t <= 24; t += 3) {
      ctx.fillRect(X(t) - 0.5, y + h, 1, 4);
      ctx.fillText(t + '时', X(t), y + h + 5);
    }
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    var mx = X(o.t);
    ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.moveTo(mx, y - 2); ctx.lineTo(mx - 5, y - 8); ctx.lineTo(mx + 5, y - 8); ctx.closePath(); ctx.fill();
    ctx.fillRect(mx - 1, y - 2, 2, h + 4);
    var txt = info.kind === 'normal' ? '昼 ' + A.formatHours(info.len) : info.kind === 'polarDay' ? '极昼 24 小时' : '极夜 24 小时';
    ctx.font = font(10, 600); ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillStyle = info.kind === 'polarNight' ? TEXT : '#111';
    ctx.fillText(txt, info.kind === 'normal' ? X(12) : (x0 + x1) / 2, y + h / 2 + 0.5);
    return { tAt: function (px) { return clamp((px - x0) / (x1 - x0) * 24, 0, 24); }, y0: rect.y - 4, y1: rect.y + rect.h };
  }

  // ---------- 正午经线剖面 ----------
  // o: { lat, decl, chord, reveal, marks:[{lat,name}], narrow, title }
  function section(ctx, rect, o) {
    var narrow = o.narrow;
    var r = Math.min(rect.w * 0.3, rect.h * 0.36);
    var cx = rect.x + rect.w * 0.42, cy = rect.y + rect.h / 2 + 6;
    var d = o.decl;
    function pt(lat, rr) { var a = (lat - d) * DEG; return { x: cx + (rr || r) * Math.cos(a), y: cy - (rr || r) * Math.sin(a) }; }
    function farPt(lat, rr) { var a = (180 - lat - d) * DEG; return { x: cx + (rr || r) * Math.cos(a), y: cy - (rr || r) * Math.sin(a) }; }

    // 太阳光
    ctx.save();
    ctx.strokeStyle = 'rgba(255,201,74,.5)'; ctx.fillStyle = 'rgba(255,201,74,.6)'; ctx.lineWidth = 1;
    for (var k = -4; k <= 4; k++) {
      if (k === 0) continue;
      var yy = cy + k * r * 0.24, dy = k * 0.24, xs = cx + r * Math.sqrt(1 - dy * dy);
      arrow(ctx, rect.x + rect.w - 8, yy, xs + 3, yy, 6);
    }
    ctx.restore();
    label(ctx, '太阳光', rect.x + rect.w - 30, cy - r * 1.18, { size: 11, color: GOLD, align: 'right' });

    // 地球：昼半球、夜半球
    ctx.save();
    ctx.beginPath(); ctx.arc(cx, cy, r, 0, 7); ctx.fillStyle = '#16233d'; ctx.fill();
    ctx.beginPath(); ctx.arc(cx, cy, r, -Math.PI / 2, Math.PI / 2); ctx.closePath();
    var gd = ctx.createLinearGradient(cx, 0, cx + r, 0);
    gd.addColorStop(0, '#2f5d8f'); gd.addColorStop(1, '#4f8fc9');
    ctx.fillStyle = gd; ctx.fill();
    ctx.beginPath(); ctx.arc(cx, cy, r, 0, 7); ctx.strokeStyle = 'rgba(230,235,242,.5)'; ctx.lineWidth = 1.2; ctx.stroke();
    // 晨昏线
    ctx.strokeStyle = 'rgba(230,235,242,.55)'; ctx.setLineDash([5, 4]);
    ctx.beginPath(); ctx.moveTo(cx, cy - r - 8); ctx.lineTo(cx, cy + r + 8); ctx.stroke();
    ctx.restore();
    label(ctx, '晨昏线', cx + 6, cy + r + 16, { size: 11, color: MUTED, align: 'left' });
    if (!narrow) {
      label(ctx, '昼半球', cx + r * 0.5, cy + r * 0.62, { size: 11, color: '#cfe3f7' });
      label(ctx, '夜半球', cx - r * 0.5, cy + r * 0.62, { size: 11, color: MUTED });
    }

    // 纬线（剖面里是一条弦）
    var LATS = [{ v: 0, n: '赤道', c: 'rgba(230,235,242,.55)' }, { v: 23.44, n: '北回归线', c: 'rgba(255,167,38,.6)' }, { v: -23.44, n: '南回归线', c: 'rgba(255,167,38,.6)' },
      { v: 66.56, n: '北极圈', c: 'rgba(79,195,247,.6)' }, { v: -66.56, n: '南极圈', c: 'rgba(79,195,247,.6)' }];
    ctx.save(); ctx.lineWidth = 1; ctx.setLineDash([3, 3]);
    LATS.forEach(function (L) {
      var a = pt(L.v), b = farPt(L.v);
      ctx.strokeStyle = L.c; ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
    });
    ctx.restore();
    if (!narrow || rect.w > 420) LATS.forEach(function (L) {
      var b = farPt(L.v, r + 4);
      label(ctx, L.n, b.x - 4, b.y, { size: 10, color: MUTED, align: 'right' });
    });

    // 地轴
    var nP = pt(90, r * 1.22), sP = pt(-90, r * 1.22);
    ctx.save(); ctx.strokeStyle = 'rgba(230,235,242,.8)'; ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.moveTo(sP.x, sP.y); ctx.lineTo(nP.x, nP.y); ctx.stroke(); ctx.restore();
    label(ctx, 'N', pt(90, r * 1.32).x, pt(90, r * 1.32).y, { size: 12, bold: true });
    label(ctx, 'S', pt(-90, r * 1.32).x, pt(-90, r * 1.32).y, { size: 12, bold: true });

    // 直射光线
    var sub = pt(d);
    ctx.save(); ctx.strokeStyle = GOLD; ctx.fillStyle = GOLD; ctx.lineWidth = 2;
    arrow(ctx, rect.x + rect.w - 8, sub.y, sub.x + 2, sub.y, 8);
    ctx.restore();
    ctx.fillStyle = GOLD; ctx.beginPath(); ctx.arc(sub.x, sub.y, 4, 0, 7); ctx.fill();
    // 观察者在直射点以北时，直射点的字写在光线下方，H 的字写在观察者光线上方，避免挤在一起
    var obsAbove = o.lat >= d;
    label(ctx, '直射点 ' + S.fmtLat(d).replace('（赤道）', ''), rect.x + rect.w - 8, sub.y + (obsAbove ? 11 : -11), { size: 11, color: GOLD, align: 'right' });

    // 练习里标几个城市
    (o.marks || []).forEach(function (m) {
      var q = pt(m.lat);
      ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(q.x, q.y, 3.5, 0, 7); ctx.fill();
      var out = pt(m.lat, r + 12);
      label(ctx, m.name, out.x, out.y, { size: 11, align: out.x >= cx ? 'left' : 'right' });
    });

    // 纬线的昼弧（金）与夜弧（蓝）：剖面里被晨昏线分成两段
    function chord(lat, w) {
      var P = pt(lat), Q = farPt(lat);
      ctx.save(); ctx.lineWidth = w; ctx.lineCap = 'round';
      var t0 = (cx - P.x) / (Q.x - P.x);
      if (Math.abs(Q.x - P.x) < 1e-6 || t0 <= 0 || t0 >= 1) {
        ctx.strokeStyle = (P.x + Q.x) / 2 >= cx ? GOLD : NIGHT;
        ctx.beginPath(); ctx.moveTo(P.x, P.y); ctx.lineTo(Q.x, Q.y); ctx.stroke();
      } else {
        var M = { x: cx, y: P.y + (Q.y - P.y) * t0 };
        var day = P.x >= cx ? P : Q, night = P.x >= cx ? Q : P;
        ctx.strokeStyle = GOLD; ctx.beginPath(); ctx.moveTo(day.x, day.y); ctx.lineTo(M.x, M.y); ctx.stroke();
        ctx.strokeStyle = NIGHT; ctx.beginPath(); ctx.moveTo(M.x, M.y); ctx.lineTo(night.x, night.y); ctx.stroke();
      }
      ctx.restore();
    }
    var lat = o.lat, P = pt(lat);
    if (o.chord) chord(lat, 3);
    (o.chords || []).forEach(function (l) { chord(l, 2.2); });

    // 观察者：地平面（切线）与正午太阳高度角
    var th = (lat - d) * DEG, H = 90 - Math.abs(lat - d);
    var res = { cx: cx, cy: cy, r: r, decl: d };
    if (o.observer !== false) {
      var tx = Math.sin(th), ty = -Math.cos(th); // 数学坐标里的切线方向
      if (th < 0) { tx = -tx; ty = -ty; }
      var L2 = r * 0.42;
      ctx.save();
      ctx.strokeStyle = '#7ee081'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(P.x - tx * L2, P.y + ty * L2); ctx.lineTo(P.x + tx * L2, P.y - ty * L2); ctx.stroke();
      // 竿子（指向天顶）
      ctx.strokeStyle = '#e6ebf2'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(P.x, P.y); ctx.lineTo(P.x + Math.cos(th) * 14, P.y - Math.sin(th) * 14); ctx.stroke();
      ctx.restore();
      ctx.fillStyle = '#7ee081'; ctx.beginPath(); ctx.arc(P.x, P.y, 5, 0, 7); ctx.fill();
      if (H > 0) {
        ctx.save(); ctx.strokeStyle = GOLD; ctx.fillStyle = GOLD; ctx.lineWidth = 1.8;
        arrow(ctx, rect.x + rect.w - 8, P.y, P.x + 3, P.y, 7);
        // 角：从切线方向（屏幕角）到水平向右（0）
        var tAng = Math.atan2(ty, tx); // 数学坐标
        ctx.lineWidth = 1.4;
        ctx.beginPath(); ctx.arc(P.x, P.y, 26, -Math.max(tAng, 0), -Math.min(tAng, 0)); ctx.stroke();
        ctx.restore();
        var hy = P.y + (obsAbove ? -13 : 13);
        label(ctx, o.reveal !== false ? 'H = ' + H.toFixed(1) + '°' : 'H = ?', P.x + 22, hy, { size: 12, bold: true, color: GOLD, align: 'left' });
      }
      label(ctx, o.name || S.fmtLat(lat).replace('（赤道）', ''), P.x - Math.cos(th) * 18 - 4, P.y + Math.sin(th) * 18, { size: 11, color: '#7ee081', align: 'right' });
      res.P = P;
    }
    res.latAt = function (x, y) {
      var a = Math.atan2(cy - y, x - cx) / DEG;
      return clamp(a + d, -90, 90);
    };
    return res;
  }

  // ---------- 分布图 ----------
  // o: { mode:'lat'|'date', lat, day, decl }
  function chart(ctx, rect, c) {
    var pl = 40, pr = 12, pt = 26, pb = 24;
    var x0 = rect.x + pl, x1 = rect.x + rect.w - pr, y0 = rect.y + pt, y1 = rect.y + rect.h - pb;
    var X = function (v) { return x0 + (x1 - x0) * (v - c.xMin) / (c.xMax - c.xMin); };
    var Y = function (v) { return y1 - (y1 - y0) * (v - c.yMin) / (c.yMax - c.yMin); };
    roundRect(ctx, rect.x, rect.y, rect.w, rect.h, 10);
    ctx.fillStyle = 'rgba(12,16,26,.85)'; ctx.fill();
    ctx.strokeStyle = LINE; ctx.stroke();
    label(ctx, c.title, rect.x + 12, rect.y + 13, { size: 12, bold: true, align: 'left', color: c.color });
    ctx.font = font(10); ctx.textBaseline = 'middle';
    c.yTicks.forEach(function (t) {
      ctx.strokeStyle = 'rgba(141,153,171,.14)'; ctx.beginPath(); ctx.moveTo(x0, Y(t)); ctx.lineTo(x1, Y(t)); ctx.stroke();
      ctx.fillStyle = MUTED; ctx.textAlign = 'right'; ctx.fillText(t + c.yUnit, x0 - 4, Y(t));
    });
    ctx.textAlign = 'center'; ctx.textBaseline = 'top';
    c.xTicks.forEach(function (t) {
      ctx.strokeStyle = t.major ? 'rgba(141,153,171,.3)' : 'rgba(141,153,171,.12)';
      ctx.beginPath(); ctx.moveTo(X(t.v), y0); ctx.lineTo(X(t.v), y1); ctx.stroke();
      if (t.label) { ctx.fillStyle = t.color || MUTED; ctx.fillText(t.label, X(t.v), y1 + 5); }
    });
    // 曲线
    ctx.save(); ctx.beginPath(); ctx.rect(x0, y0 - 2, x1 - x0, y1 - y0 + 4); ctx.clip();
    if (c.fill) {
      ctx.beginPath(); ctx.moveTo(X(c.pts[0][0]), Y(c.yMin));
      c.pts.forEach(function (p) { ctx.lineTo(X(p[0]), Y(p[1])); });
      ctx.lineTo(X(c.pts[c.pts.length - 1][0]), Y(c.yMin)); ctx.closePath();
      ctx.fillStyle = c.fill; ctx.fill();
    }
    ctx.strokeStyle = c.color; ctx.lineWidth = 2; ctx.lineJoin = 'round';
    ctx.beginPath(); c.pts.forEach(function (p, i) { if (i) ctx.lineTo(X(p[0]), Y(p[1])); else ctx.moveTo(X(p[0]), Y(p[1])); }); ctx.stroke();
    ctx.restore();
    (c.notes || []).forEach(function (n) { label(ctx, n.text, X(n.x), Y(n.y), { size: 10, color: n.color || MUTED }); });
    // 当前点
    if (c.marker) {
      var mx = X(c.marker.x), my = Y(c.marker.y);
      ctx.strokeStyle = 'rgba(126,224,129,.6)'; ctx.setLineDash([3, 3]);
      ctx.beginPath(); ctx.moveTo(mx, y0); ctx.lineTo(mx, y1); ctx.stroke(); ctx.setLineDash([]);
      ctx.fillStyle = '#7ee081'; ctx.beginPath(); ctx.arc(mx, my, 4.5, 0, 7); ctx.fill();
      var right = mx < (x0 + x1) / 2;
      label(ctx, c.marker.label, mx + (right ? 8 : -8), Math.max(my - 12, y0 + 6), { size: 11, bold: true, color: '#7ee081', align: right ? 'left' : 'right' });
    }
    return { x0: x0, x1: x1, y0: rect.y, y1: rect.y + rect.h, vAt: function (px) { return clamp(c.xMin + (px - x0) / (x1 - x0) * (c.xMax - c.xMin), c.xMin, c.xMax); } };
  }

  var MONTH_START = [1, 32, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335];
  function charts(ctx, R1, R2, o) {
    var latTicks = [-90, -66.56, -23.44, 0, 23.44, 66.56, 90].map(function (v) {
      var n = { '-90': '90°S', '-66.56': '', '-23.44': '23.4°S', '0': '0°', '23.44': '23.4°N', '66.56': '', '90': '90°N' }[String(v)];
      return { v: v, label: n, major: v === 0 };
    });
    var dateTicks = MONTH_START.map(function (d, i) { return { v: d, label: (i % 3 === 0 || !o.narrow) ? (i + 1) + '月' : '' }; });
    var termTicks = A.TERMS.map(function (T) { return { v: T.day, label: '', major: true }; });
    var g1, g2;
    if (o.mode === 'lat') {
      var ph = [], pl = [];
      for (var lat = -90; lat <= 90; lat += 1) {
        ph.push([lat, Math.max(0, A.noonAltitude(lat, o.decl))]);
        pl.push([lat, A.dayLength(lat, o.decl)]);
      }
      var H = A.noonAltitude(o.lat, o.decl), L = A.dayLength(o.lat, o.decl);
      var notes = [{ x: o.decl, y: 90, text: '直射点 90°', color: GOLD }];
      g1 = chart(ctx, R1, { title: '正午太阳高度随纬度的分布（' + S.fmtDate(o.day) + '）', color: GOLD, fill: 'rgba(255,201,74,.12)', pts: ph,
        xMin: -90, xMax: 90, yMin: 0, yMax: 100, yTicks: [0, 30, 60, 90], yUnit: '°', xTicks: latTicks, notes: notes,
        marker: { x: o.lat, y: Math.max(H, 0), label: H > 0 ? H.toFixed(1) + '°' : '太阳不升起' } });
      var n2 = [];
      if (Math.abs(o.decl) > 0.5) {
        var pd = 90 - Math.abs(o.decl);
        n2.push({ x: o.decl > 0 ? (pd + 90) / 2 : -(pd + 90) / 2, y: 21.5, text: '极昼', color: GOLD });
        n2.push({ x: o.decl > 0 ? -(pd + 90) / 2 : (pd + 90) / 2, y: 2.5, text: '极夜', color: NIGHT });
      } else n2.push({ x: 0, y: 14, text: '全球昼夜等长', color: CYAN });
      g2 = chart(ctx, R2, { title: '昼长随纬度的分布', color: CYAN, fill: 'rgba(79,195,247,.1)', pts: pl,
        xMin: -90, xMax: 90, yMin: 0, yMax: 24, yTicks: [0, 6, 12, 18, 24], yUnit: 'h', xTicks: latTicks, notes: n2,
        marker: { x: o.lat, y: L, label: A.formatHours(L).replace(' 小时 ', 'h').replace(' 分', 'm') } });
    } else {
      var dh = [], dl = [];
      for (var d = 1; d <= 365; d += 2) {
        var dc = A.declination(d);
        dh.push([d, Math.max(0, A.noonAltitude(o.lat, dc))]);
        dl.push([d, A.dayLength(o.lat, dc)]);
      }
      var Hd = A.noonAltitude(o.lat, o.decl), Ld = A.dayLength(o.lat, o.decl);
      var tn = A.TERMS.map(function (T) { return { x: T.day, y: 96, text: T.name, color: MUTED }; });
      g1 = chart(ctx, R1, { title: '正午太阳高度的年变化（' + S.fmtLat(o.lat).replace('（赤道）', '') + '）', color: GOLD, fill: 'rgba(255,201,74,.12)', pts: dh,
        xMin: 1, xMax: 365, yMin: 0, yMax: 100, yTicks: [0, 30, 60, 90], yUnit: '°', xTicks: dateTicks.concat(termTicks), notes: tn,
        marker: { x: o.day, y: Math.max(Hd, 0), label: Hd > 0 ? Hd.toFixed(1) + '°' : '太阳不升起' } });
      g2 = chart(ctx, R2, { title: '昼长的年变化', color: CYAN, fill: 'rgba(79,195,247,.1)', pts: dl,
        xMin: 1, xMax: 365, yMin: 0, yMax: 24, yTicks: [0, 6, 12, 18, 24], yUnit: 'h', xTicks: dateTicks.concat(termTicks),
        marker: { x: o.day, y: Ld, label: A.formatHours(Ld).replace(' 小时 ', 'h').replace(' 分', 'm') } });
    }
    return [g1, g2];
  }

  // ---------- 视图 ----------
  function View(canvas) {
    var ctx = canvas.getContext('2d'), W = 0, H = 0, dpr = 1, narrow = false, geo = null;
    function resize(w, h) {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      W = w; H = h; narrow = w < 640;
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
      canvas.style.width = w + 'px'; canvas.style.height = h + 'px';
    }
    function bg(sky) {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      var g = ctx.createLinearGradient(0, 0, 0, H);
      g.addColorStop(0, '#04060c'); g.addColorStop(1, '#0a1120');
      ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
      if (sky) {
        ctx.fillStyle = 'rgba(255,255,255,.4)';
        STARS.forEach(function (s) { ctx.fillRect(s[0] * W, s[1] * H, s[2], s[2]); });
      }
    }
    function top() { return narrow ? 84 : 44; }

    // 场景一：太阳视运动
    function drawPath(o) {
      bg(true);
      var t0 = top(), barH = 34, bottom = narrow ? 44 : 50;
      var R = { x: 12, y: t0, w: W - 24, h: H - t0 - bottom - barH - 8 };
      var d = dome(ctx, R, { lat: o.lat, decl: o.decl, t: o.t, yaw: o.yaw, pitch: o.pitch, show: o.show, narrow: narrow });
      var BR = { x: Math.max(12, W / 2 - 260), y: H - bottom - barH, w: Math.min(W - 24, 520), h: barH };
      var bar = dayBar(ctx, BR, { lat: o.lat, decl: o.decl, t: o.t });
      geo = { scene: 'path', dome: d, bar: bar, barRect: BR };
      return geo;
    }

    // 场景二：正午太阳高度与昼长的分布
    function layout2() {
      var t0 = top(), bottom = narrow ? 44 : 50, avail = H - t0 - bottom;
      if (W >= 760) {
        var lw = Math.round((W - 36) * 0.5);
        var ch = (avail - 10) / 2;
        return { sec: { x: 12, y: t0, w: lw, h: avail },
          c1: { x: 24 + lw, y: t0, w: W - 36 - lw, h: ch }, c2: { x: 24 + lw, y: t0 + ch + 10, w: W - 36 - lw, h: ch } };
      }
      var sh = Math.round(avail * 0.44), rest = avail - sh - 16;
      return { sec: { x: 12, y: t0, w: W - 24, h: sh },
        c1: { x: 12, y: t0 + sh + 8, w: W - 24, h: rest / 2 }, c2: { x: 12, y: t0 + sh + 16 + rest / 2, w: W - 24, h: rest / 2 } };
    }
    function drawGlobe(o) {
      bg(false);
      var L = layout2();
      var s = section(ctx, L.sec, { lat: o.lat, decl: o.decl, chord: o.chord, narrow: narrow });
      label(ctx, '正午所在经线的剖面（太阳光从右边射来）', L.sec.x + 6, L.sec.y + 10, { size: 11, color: MUTED, align: 'left' });
      var c = charts(ctx, L.c1, L.c2, { mode: o.mode, lat: o.lat, day: o.day, decl: o.decl, narrow: narrow });
      geo = { scene: 'globe', sec: s, secRect: L.sec, c1: c[0], c2: c[1] };
      return geo;
    }

    // 练习：剖面图（作答前不标答案）
    function drawQuiz(q, answered, o) {
      bg(false);
      var t0 = top(), quizH = o.quizH || 180;
      var R = { x: 12, y: t0, w: W - 24, h: Math.max(160, H - t0 - quizH - 56) };
      var decl = A.declination(q.day);
      var marks = q.type === 'len' ? q.cities.map(function (c) { return { lat: c.lat, name: c.name }; }) : [];
      section(ctx, R, { lat: q.lat, decl: decl, chords: answered && q.type === 'len' ? q.cities.map(function (c) { return c.lat; }) : null, reveal: answered, narrow: narrow,
        observer: q.type !== 'len', marks: marks, name: q.type === 'len' ? '' : null });
      label(ctx, S.fmtDate(q.day) + '（' + (S.termOf(q.day) || {}).name + '）正午所在经线的剖面', R.x + 6, R.y + 10, { size: 11, color: MUTED, align: 'left' });
      geo = { scene: 'quiz' };
      return geo;
    }

    return {
      resize: resize, drawPath: drawPath, drawGlobe: drawGlobe, drawQuiz: drawQuiz,
      geo: function () { return geo; }, narrow: function () { return narrow; }
    };
  }

  window.SunDraw = { View: View, dome: dome, section: section, charts: charts, dayBar: dayBar, camera: camera };
})();
