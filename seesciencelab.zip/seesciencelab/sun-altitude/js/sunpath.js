// 纯计算：某纬度、某日期太阳的视运动（地方时、高度角、方位）、日出日落、立竿影子、判断练习（不碰 DOM）
// 依赖 shared/astro.js（直射点 declination、昼长 dayLength、正午太阳高度 noonAltitude）
// 地平坐标：x 指向正东、y 指向正北、z 指向天顶；方位角 az 从正北起顺时针（北 0°、东 90°、南 180°、西 270°）
// 时刻一律用地方时（以当地正午太阳在正南或正北方为 12 时），不考虑大气折射、太阳视半径和均时差
(function () {
  var A = window.Astro, DEG = Math.PI / 180;

  var CITIES = [
    { key: 'mohe', name: '漠河', lat: 53.0 },
    { key: 'harbin', name: '哈尔滨', lat: 45.8 },
    { key: 'beijing', name: '北京', lat: 39.9 },
    { key: 'shanghai', name: '上海', lat: 31.2 },
    { key: 'guangzhou', name: '广州', lat: 23.1 },
    { key: 'singapore', name: '新加坡', lat: 1.3 },
    { key: 'sydney', name: '悉尼', lat: -33.9 },
    { key: 'arctic', name: '北极圈', lat: 66.6 },
    { key: 'pole', name: '北极点', lat: 90 }
  ];

  function clamp(v, lo, hi) { return v < lo ? lo : v > hi ? hi : v; }

  // 时角（度）：正午为 0，上午为负
  function hourAngle(t) { return (t - 12) * 15; }

  // 太阳在地平坐标里的单位方向
  function sunVec(lat, decl, t) {
    var p = lat * DEG, d = decl * DEG, h = hourAngle(t) * DEG;
    return {
      x: -Math.cos(d) * Math.sin(h),
      y: Math.cos(p) * Math.sin(d) - Math.sin(p) * Math.cos(d) * Math.cos(h),
      z: Math.sin(p) * Math.sin(d) + Math.cos(p) * Math.cos(d) * Math.cos(h)
    };
  }

  // 太阳高度角、方位角（度）
  function sunAt(lat, decl, t) {
    var v = sunVec(lat, decl, t);
    var alt = Math.asin(clamp(v.z, -1, 1)) / DEG;
    var az = Math.atan2(v.x, v.y) / DEG;
    if (az < 0) az += 360;
    // 极点、天顶附近方位不确定
    if (Math.hypot(v.x, v.y) < 1e-6) az = NaN;
    return { alt: alt, az: az, v: v };
  }

  // 昼夜情况：normal 有日出日落，polarDay 极昼，polarNight 极夜
  function dayInfo(lat, decl) {
    var L = A.dayLength(lat, decl);
    var r = { len: L, noonAlt: A.noonAltitude(lat, decl), decl: decl, lat: lat };
    r.kind = L >= 24 - 1e-9 ? 'polarDay' : L <= 1e-9 ? 'polarNight' : 'normal';
    if (r.kind === 'normal') {
      r.rise = 12 - L / 2;
      r.set = 12 + L / 2;
      r.riseAz = sunAt(lat, decl, r.rise).az;
      r.setAz = 360 - r.riseAz;
    }
    // 正午太阳在哪个方向：直射点在北 → 太阳在正北（φ < δ）
    r.noonDir = Math.abs(lat - decl) < 0.05 ? 'zenith' : lat > decl ? 'S' : 'N';
    // 子夜太阳高度（极昼时 > 0）
    r.midAlt = -90 + Math.abs(lat + decl);
    if (Math.abs(lat) > 89.99) r.midAlt = r.noonAlt;
    return r;
  }

  // 方位角 → 八方位文字
  var DIR8 = ['正北', '东北', '正东', '东南', '正南', '西南', '正西', '西北'];
  function dirName(az, tol) {
    if (!isFinite(az)) return '—';
    tol = tol == null ? 1.5 : tol;
    var exact = [0, 90, 180, 270];
    for (var i = 0; i < 4; i++) {
      var d = Math.abs(((az - exact[i]) % 360 + 540) % 360 - 180);
      if (d < tol) return DIR8[i * 2];
    }
    if (az < 90) return '东北';
    if (az < 180) return '东南';
    if (az < 270) return '西南';
    return '西北';
  }
  // 日出方位：只分东北、正东、东南（课本说法）
  function riseDir(decl) { return Math.abs(decl) < 0.3 ? '正东' : decl > 0 ? '东北' : '东南'; }
  function setDir(decl) { return Math.abs(decl) < 0.3 ? '正西' : decl > 0 ? '西北' : '西南'; }

  // 立竿影子：竿高 1，返回影长与影子朝向（影子在太阳的反方向）
  function shadow(alt, az) {
    if (alt <= 0) return null;
    var len = 1 / Math.tan(alt * DEG);
    var saz = (az + 180) % 360;
    return { len: len, az: saz, dx: Math.sin(saz * DEG) * len, dy: Math.cos(saz * DEG) * len };
  }

  // 一天中太阳的轨迹（周日圆）：返回 n+1 个点（地方时 0→24），供绘图
  function path(lat, decl, n) {
    n = n || 144;
    var pts = [];
    for (var i = 0; i <= n; i++) {
      var t = 24 * i / n;
      pts.push({ t: t, v: sunVec(lat, decl, t) });
    }
    return pts;
  }

  function fmtLat(v) {
    if (Math.abs(v) < 0.05) return '0°（赤道）';
    return Math.abs(v).toFixed(1) + '°' + (v > 0 ? 'N' : 'S');
  }
  function fmtDate(day) {
    var d = A.dayToDate(day);
    return d.month + '月' + d.date + '日';
  }
  // 当天恰好是二分二至时返回节气
  function termOf(day) {
    var ti = A.termInfo(day);
    return ti.exact || null;
  }

  // ---------- 判断练习 ----------
  // calc：已知纬度和节气求正午太阳高度（或楼间距、热水器倾角）；dir：日出方位、正午影子朝向；len：比较昼长
  var TYPES = ['calc', 'dir', 'len'];
  var QCITIES = CITIES.filter(function (c) { return c.lat < 70; });

  function pick(rng, arr) { return arr[Math.floor(rng() * arr.length)]; }
  function shuffle(rng, arr) {
    for (var i = arr.length - 1; i > 0; i--) {
      var j = Math.floor(rng() * (i + 1)), t = arr[i]; arr[i] = arr[j]; arr[j] = t;
    }
    return arr;
  }
  function deg(v) { return (Math.round(v * 10) / 10).toFixed(1).replace(/\.0$/, '') + '°'; }
  function uniqOptions(rng, answer, cand, n) {
    var out = [answer];
    for (var i = 0; i < cand.length && out.length < n; i++) if (out.indexOf(cand[i]) < 0) out.push(cand[i]);
    return shuffle(rng, out);
  }
  var TERM_DECL = { spring: 0, summer: 23.44, autumn: 0, winter: -23.44 };
  function termByKey(k) { return A.TERMS.filter(function (t) { return t.key === k; })[0]; }

  function quizCalc(rng) {
    var c = pick(rng, QCITIES.filter(function (x) { return x.key !== 'arctic'; }));
    var useTropic = rng() < 0.75;
    var term = pick(rng, useTropic ? ['summer', 'winter'] : ['spring', 'summer', 'winter']);
    var T = termByKey(term), d = TERM_DECL[term];
    var lat = Math.round(c.lat * 10) / 10;
    var H = 90 - Math.abs(lat - d);
    var sub = c.lat > 25 && term === 'winter' && rng() < 0.4 ? 'building' : c.lat > 15 && rng() < 0.2 ? 'heater' : 'H';
    var q = { type: 'calc', lat: lat, day: T.day, term: term };
    var latText = c.name + '（' + fmtLat(lat).replace('（赤道）', '') + '）';
    if (sub === 'building') {
      var k = 1 / Math.tan(H * DEG);
      q.prompt = latText + '新建住宅楼，要使冬至日正午前楼的影子不挡住后楼底层，楼间距至少约为楼高的几倍？';
      var ans = k.toFixed(1) + ' 倍';
      var wrong = [Math.tan(H * DEG), 1 / Math.tan((90 - Math.abs(lat + d)) * DEG), 1 / Math.tan((90 - lat) * DEG), k * 1.5]
        .filter(function (x) { return isFinite(x) && x > 0 && x < 20; })
        .map(function (x) { return x.toFixed(1) + ' 倍'; });
      q.answer = ans;
      q.options = uniqOptions(rng, ans, wrong, 4);
      q.explain = '冬至日正午太阳高度 H = 90° − |' + deg(lat) + ' − (−23.4°)| = ' + deg(H) + '，影长 = 楼高 ÷ tan H ≈ ' + k.toFixed(2) + ' × 楼高。冬至日北半球正午太阳高度一年中最小、影子最长，所以按冬至日计算。';
    } else if (sub === 'heater') {
      var tilt = 90 - H;
      q.prompt = latText + '在' + T.name + '日正午，要使屋顶太阳能热水器的集热板与阳光垂直，集热板与地面的夹角应为多少？';
      var ansT = deg(tilt);
      q.answer = ansT;
      q.options = uniqOptions(rng, ansT, [deg(H), deg(Math.abs(lat)), deg(90 - Math.abs(lat + d)), deg(Math.abs(tilt - 10))], 4);
      q.explain = '先求正午太阳高度 H = 90° − |' + deg(lat) + ' − ' + (d < 0 ? '(−23.4°)' : deg(d)) + '| = ' + deg(H) + '。集热板与阳光垂直时，集热板与地面的夹角 = 90° − H = ' + ansT + '（也等于当地纬度与直射点纬度之差）。';
    } else {
      q.prompt = latText + '在' + T.name + '日的正午太阳高度约为多少？';
      var ansH = deg(H);
      q.answer = ansH;
      var cand = [90 - Math.abs(lat + d), 90 - Math.abs(lat), Math.abs(lat - d), 90 - Math.abs(lat - d) + 23.4, 90 - Math.abs(lat - d) - 23.4]
        .filter(function (x) { return x > 0 && x <= 90; }).map(deg);
      q.answer = ansH;
      q.options = uniqOptions(rng, ansH, cand, 4);
      q.explain = 'H = 90° − |φ − δ|，φ 为当地纬度 ' + fmtLat(lat).replace('（赤道）', '') + '，δ 为直射点纬度：' + T.name + '日 δ = ' + (d === 0 ? '0°（赤道）' : d > 0 ? '23.4°N' : '23.4°S（代入 −23.4°）') + '。所以 H = 90° − |' + deg(lat) + ' − ' + (d < 0 ? '(−23.4°)' : deg(d)) + '| = ' + ansH + '。';
    }
    return q;
  }

  function quizDir(rng) {
    var term = pick(rng, ['spring', 'summer', 'winter', 'autumn']);
    var T = termByKey(term), d = TERM_DECL[term];
    var q = { type: 'dir', day: T.day, term: term };
    if (rng() < 0.5) {
      var c = pick(rng, QCITIES.filter(function (x) { return Math.abs(x.lat) < 60; }));
      q.lat = c.lat;
      q.prompt = T.name + '日，' + c.name + '的太阳从哪个方向升起？';
      q.answer = '从' + riseDir(d) + '升起';
      q.options = ['从东北升起', '从正东升起', '从东南升起', '从正南升起'];
      q.explain = '日出方位只取决于直射点：直射点在北半球（春分到秋分），全球（极昼极夜地区除外）日出东北、日落西北；直射点在南半球时日出东南、日落西南；二分日直射赤道，日出正东、日落正西，与在南北半球无关。' + T.name + '日直射点' + (d === 0 ? '在赤道' : d > 0 ? '在北回归线' : '在南回归线') + '。';
    } else {
      var pool = QCITIES.filter(function (x) { return x.key !== 'arctic'; });
      var c2 = pick(rng, pool);
      q.lat = c2.lat;
      var info = dayInfo(c2.lat, d);
      q.prompt = T.name + '日正午，' + c2.name + '（' + fmtLat(c2.lat).replace('（赤道）', '') + '）立竿的影子朝向哪里？';
      q.answer = info.noonDir === 'S' ? '正北' : info.noonDir === 'N' ? '正南' : '没有影子';
      q.options = ['正北', '正南', '正东', '没有影子'];
      q.explain = '正午太阳在正南或正北：当地纬度 φ 在直射点 δ 以北，太阳在正南，影子朝正北；在直射点以南，太阳在正北，影子朝正南；直射时太阳在头顶，竿子没有影子。' + T.name + '日直射点 ' + fmtLat(d).replace('（赤道）', '') + '，' + c2.name + '在它以' + (c2.lat > d ? '北' : '南') + '。';
    }
    return q;
  }

  function quizLen(rng) {
    var term = pick(rng, ['summer', 'winter']);
    var T = termByKey(term), d = TERM_DECL[term];
    var pool = shuffle(rng, QCITIES.filter(function (c) { return c.key !== 'arctic'; }).slice()).slice(0, 4);
    var longest = rng() < 0.5;
    var best = pool.reduce(function (a, b) {
      var la = A.dayLength(a.lat, d), lb = A.dayLength(b.lat, d);
      return (longest ? lb > la : lb < la) ? b : a;
    });
    var q = { type: 'len', day: T.day, term: term, cities: pool, lat: best.lat };
    q.prompt = T.name + '日，下列地方中白昼' + (longest ? '最长' : '最短') + '的是？';
    q.answer = best.name;
    q.options = pool.map(function (c) { return c.name; });
    var north = d > 0;
    q.explain = T.name + '日直射点在' + (north ? '北' : '南') + '回归线，' + (north ? '北' : '南') + '半球昼长夜短，纬度越高昼越长；' + (north ? '南' : '北') + '半球昼短夜长，纬度越高昼越短。' +
      pool.map(function (c) { return c.name + ' ' + A.formatHours(A.dayLength(c.lat, d)); }).join('，') + '。';
    return q;
  }

  var MAKERS = { calc: quizCalc, dir: quizDir, len: quizLen };
  function quiz(rng, prevId, only) {
    rng = rng || Math.random;
    for (var k = 0; k < 20; k++) {
      var type = only && MAKERS[only] ? only : pick(rng, TYPES);
      var q = MAKERS[type](rng);
      q.id = q.type + '|' + q.prompt;
      if (q.id !== prevId && q.options.indexOf(q.answer) >= 0 && q.options.length >= 3) return q;
    }
    return q;
  }

  window.SunPath = {
    DEG: DEG,
    CITIES: CITIES,
    TYPES: TYPES,
    clamp: clamp,
    hourAngle: hourAngle,
    sunVec: sunVec,
    sunAt: sunAt,
    dayInfo: dayInfo,
    dirName: dirName,
    riseDir: riseDir,
    setDir: setDir,
    shadow: shadow,
    path: path,
    fmtLat: fmtLat,
    fmtDate: fmtDate,
    termOf: termOf,
    quiz: quiz
  };
})();
