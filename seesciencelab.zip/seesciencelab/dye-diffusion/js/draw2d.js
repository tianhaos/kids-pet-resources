(function () {
  'use strict';

  const physics = window.DyeDiffusion;
  const resolution = 72;
  const colors = ['#ffc2ed', '#f89add', '#f478cb', '#ea8be7'];

  function create(canvas) {
    const ctx = canvas.getContext('2d');
    const layer = document.createElement('canvas');
    layer.width = layer.height = resolution;
    const pigment = layer.getContext('2d');
    const image = pigment.createImageData(resolution, resolution);
    let cups = [];

    function concentrate(cup, state, temperature) {
      const spread = physics.variance(temperature, state.time);
      const axis = length => Array.from({ length: resolution }, (_, i) => (i + 0.5) / resolution * length);
      const horizontal = axis(1).map(p => physics.density(p, state.x, 1, spread));
      const vertical = axis(physics.height).map(p => physics.density(p, state.y, physics.height, spread));
      for (let j = 0; j < resolution; j++) {
        for (let i = 0; i < resolution; i++) {
          const offset = (j * resolution + i) * 4;
          const c = horizontal[i] * vertical[j];
          image.data[offset] = 221;
          image.data[offset + 1] = 44;
          image.data[offset + 2] = 143;
          image.data[offset + 3] = Math.round(242 * (1 - Math.exp(-0.48 * c)));
        }
      }
      pigment.putImageData(image, 0, 0);
      ctx.drawImage(layer, cup.x, cup.y, cup.w, cup.h);
    }

    function drawTracers(cup, state, temperature) {
      const point = (index, time) => {
        const [x, y] = physics.tracer(index, temperature, time, state.x, state.y);
        return [cup.x + x * cup.w, cup.y + y / physics.height * cup.h];
      };
      for (let i = 0; i < physics.count; i++) {
        const [x, y] = point(i, state.time);
        if (i < 4) {
          ctx.beginPath();
          ctx.moveTo(x, y);
          for (let j = 1; j <= 12; j++) {
            ctx.lineTo(...point(i, Math.max(0, state.time - j * 0.12)));
          }
          ctx.strokeStyle = colors[i] + '99';
          ctx.lineWidth = 1;
          ctx.stroke();
        }
        ctx.beginPath();
        ctx.arc(x, y, i < 4 ? 2.5 : 1.45, 0, 2 * Math.PI);
        ctx.fillStyle = colors[i % colors.length];
        ctx.fill();
      }
    }

    function drawCup(cup, state, index) {
      const { x, y, w, h } = cup;
      const bottom = y + h;
      const lip = y - w * 0.22;
      const oval = Math.max(6, w * 0.065);
      const right = x + w;
      const center = x + w / 2;
      const edge = ctx.createLinearGradient(x, 0, right, 0);
      edge.addColorStop(0, '#273e50');
      edge.addColorStop(0.11, '#7b9cb4');
      edge.addColorStop(0.42, '#3a556b');
      edge.addColorStop(0.86, '#60859e');
      edge.addColorStop(1, '#244053');

      ctx.save();
      ctx.fillStyle = '#010309';
      ctx.beginPath();
      ctx.ellipse(center, bottom + oval + 6, w * 0.62, oval * 0.8, 0, 0, Math.PI * 2);
      ctx.fill();

      ctx.beginPath();
      ctx.moveTo(x, lip);
      ctx.lineTo(x, bottom);
      ctx.bezierCurveTo(x, bottom + oval * 1.4, right, bottom + oval * 1.4, right, bottom);
      ctx.lineTo(right, lip);
      ctx.closePath();
      const glass = ctx.createLinearGradient(x, 0, right, 0);
      glass.addColorStop(0, '#132638');
      glass.addColorStop(0.14, '#101e2e');
      glass.addColorStop(0.48, '#0a121d');
      glass.addColorStop(0.9, '#142235');
      glass.addColorStop(1, '#192e40');
      ctx.fillStyle = glass;
      ctx.fill();
      ctx.strokeStyle = edge;
      ctx.lineWidth = 1.7;
      ctx.stroke();

      const water = ctx.createLinearGradient(x, y, right, bottom);
      water.addColorStop(0, '#193247');
      water.addColorStop(0.5, '#112339');
      water.addColorStop(1, '#1c364a');
      ctx.fillStyle = water;
      ctx.fillRect(x + 1, y, w - 2, h);
      ctx.save();
      ctx.beginPath();
      ctx.rect(x + 1, y, w - 2, h);
      ctx.clip();
      concentrate(cup, state, state.temperatures[index]);
      if (state.tracers) drawTracers(cup, state, state.temperatures[index]);

      const shine = ctx.createLinearGradient(x, 0, right, 0);
      shine.addColorStop(0, '#d1edff08');
      shine.addColorStop(0.07, '#d1edff23');
      shine.addColorStop(0.12, '#d1edff04');
      shine.addColorStop(0.91, '#d1edff00');
      shine.addColorStop(0.975, '#d1edff25');
      shine.addColorStop(1, '#d1edff06');
      ctx.fillStyle = shine;
      ctx.fillRect(x, y, w, h);
      ctx.restore();

      ctx.beginPath();
      ctx.ellipse(center, y, w / 2, oval, 0, Math.PI, 2 * Math.PI);
      ctx.fillStyle = '#213c5188';
      ctx.fill();
      ctx.strokeStyle = '#57778f98';
      ctx.lineWidth = 1;
      ctx.stroke();
      ctx.beginPath();
      ctx.ellipse(center, y, w / 2, oval, 0, 0, Math.PI);
      ctx.strokeStyle = '#a0cede94';
      ctx.stroke();
      ctx.beginPath();
      ctx.ellipse(center, lip, w / 2, oval, 0, 0, Math.PI * 2);
      ctx.strokeStyle = edge;
      ctx.lineWidth = 1.7;
      ctx.stroke();
      // 杯壁刻度仅用于辨认实验器皿，两杯液面等高。
      ctx.strokeStyle = '#b8d3e076';
      ctx.lineWidth = 1;
      for (let i = 1; i <= 6; i++) {
        const tick = y + h * i / 7;
        ctx.beginPath();
        ctx.moveTo(right - w * 0.055, tick);
        ctx.lineTo(right - w * (i % 2 ? 0.105 : 0.15), tick);
        ctx.stroke();
      }

      const sx = x + state.x * w;
      const sy = y + state.y / physics.height * h;
      const inFocus = state.hover === index || state.dragging === index;
      ctx.beginPath();
      ctx.arc(sx, sy, inFocus ? 10 : 6, 0, 2 * Math.PI);
      ctx.setLineDash(inFocus ? [] : [2, 2]);
      ctx.strokeStyle = inFocus ? '#fff0ad' : '#fff0ad80';
      ctx.stroke();
      ctx.setLineDash([]);
      if (inFocus) {
        ctx.beginPath();
        ctx.moveTo(sx - 4, sy); ctx.lineTo(sx + 4, sy);
        ctx.moveTo(sx, sy - 4); ctx.lineTo(sx, sy + 4);
        ctx.stroke();
      }
      ctx.restore();
    }

    function draw(state) {
      const w = canvas.clientWidth, h = canvas.clientHeight;
      if (!w || !h) return;
      const ratio = Math.min(2, window.devicePixelRatio || 1);
      const pixelW = Math.round(w * ratio), pixelH = Math.round(h * ratio);
      if (canvas.width !== pixelW) canvas.width = pixelW;
      if (canvas.height !== pixelH) canvas.height = pixelH;
      ctx.setTransform(pixelW / w, 0, 0, pixelH / h, 0, 0);
      ctx.clearRect(0, 0, w, h);

      const cupWidth = Math.min(w * 0.40, h * 0.67, 322);
      const cupHeight = cupWidth * physics.height;
      const top = (h - cupHeight) / 2 + cupWidth * 0.08;
      cups = [0.25, 0.75].map(center => ({ x: w * center - cupWidth / 2, y: top, w: cupWidth, h: cupHeight }));
      const benchY = top + cupHeight + cupWidth * 0.12;
      const bench = ctx.createLinearGradient(0, benchY, 0, benchY + 26);
      bench.addColorStop(0, '#172737');
      bench.addColorStop(1, '#111a2700');
      ctx.fillStyle = bench;
      ctx.fillRect(w * 0.035, benchY, w * 0.93, 26);
      ctx.strokeStyle = '#293c50';
      ctx.beginPath();
      ctx.moveTo(w * 0.035, benchY);
      ctx.lineTo(w * 0.965, benchY);
      ctx.stroke();
      cups.forEach((cup, i) => drawCup(cup, state, i));
    }

    function hit(x, y) {
      return cups.findIndex(cup => x >= cup.x - 6 && x <= cup.x + cup.w + 6 &&
        y >= cup.y - 6 && y <= cup.y + cup.h + 6);
    }

    function source(index, x, y) {
      const cup = cups[index];
      const clamp = (p, max) => Math.max(max * 0.06, Math.min(p, max * 0.94));
      return [clamp((x - cup.x) / cup.w, 1), clamp((y - cup.y) / cup.w, physics.height)];
    }

    return { draw, hit, source };
  }
  window.DyeDraw = { create };
})();
