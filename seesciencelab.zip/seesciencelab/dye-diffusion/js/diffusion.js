// 封闭静水中的二维扩散，长度以水层宽度为 1，时间为演示刻度。
(function () {
  'use strict';
  const height = 1.08;
  const initialSigma = 0.035;
  const modes = 48;
  const end = 65;
  const count = 12;
  const step = 0.01;
  const frames = Math.ceil(end * diffusivity(80) / step) + 2;

  function diffusivity(temperature) {
    return 0.004 * Math.exp((temperature - 20) / 43);
  }

  // 镜像高斯满足零通量边界。各轴积分为 1，二维浓度归一到均匀值。
  function density(position, source, length, variance) {
    const gaussian = offset => Math.exp(-offset * offset / (2 * variance));
    let sum = 0;
    for (let k = -6; k <= 6; k++) {
      const shift = 2 * k * length;
      sum += gaussian(position - source + shift) + gaussian(position + source + shift);
    }
    return length * sum / Math.sqrt(2 * Math.PI * variance);
  }

  function variance(temperature, time) {
    return initialSigma ** 2 + 2 * diffusivity(temperature) * time;
  }

  // 由余弦展开和 Parseval 等式计算浓度变异系数，避免读数随画布分辨率变化。
  function unevenness(x, y, spread) {
    function meanSquare(source, length) {
      let sum = 1;
      for (let n = 1; n <= modes; n++) {
        const wave = n * Math.PI / length;
        sum += 2 * Math.cos(wave * source) ** 2 * Math.exp(-(wave ** 2) * spread);
      }
      return sum;
    }
    return Math.sqrt(Math.max(0, meanSquare(x, 1) * meanSquare(y, height) - 1));
  }

  function reflect(position, length) {
    const period = 2 * length;
    const wrapped = ((position % period) + period) % period;
    return wrapped <= length ? wrapped : period - wrapped;
  }

  // 固定随机样本用作对照和回看。扩散时钟为 D·t，步进中每轴方差为 2Δ(D·t)。
  let seed = 193813;
  function random() {
    seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
    return (seed + 0.5) / 4294967296;
  }

  const walks = Array.from({ length: count }, () => {
    const points = new Float32Array(frames * 2);
    let x = 0, y = 0;
    for (let i = 0; i < frames; i++) {
      const angle = Math.PI * 2 * random();
      const radius = Math.sqrt(-2 * Math.log(random())) * (i ? Math.sqrt(2 * step) : initialSigma);
      x += radius * Math.cos(angle);
      y += radius * Math.sin(angle);
      points[2 * i] = x;
      points[2 * i + 1] = y;
    }
    return points;
  });

  function tracer(index, temperature, time, x, y) {
    const frame = diffusivity(temperature) * time / step;
    const start = Math.floor(frame) * 2;
    const fraction = frame % 1;
    const points = walks[index];
    const interpolate = offset => points[start + offset] * (1 - fraction) + points[start + offset + 2] * fraction;
    return [reflect(x + interpolate(0), 1), reflect(y + interpolate(1), height)];
  }

  window.DyeDiffusion = { height, end, count, diffusivity, density, variance, unevenness, tracer };
})();
