(function () {
  'use strict';

  const physics = window.DyeDiffusion;
  const $ = id => document.getElementById(id);
  const canvas = $('cups');
  const sceneButtons = [...document.querySelectorAll('[data-scene]')];
  const mobile = matchMedia('(max-width: 760px)');
  const reduce = matchMedia('(prefers-reduced-motion: reduce)');
  const query = new URLSearchParams(location.search);
  const presets = { compare: [20, 65], equal: [20, 20] };
  const defaultSource = [0.42, 0.39];
  const clamp = (value, min, max) => Math.max(min, Math.min(max, value));

  function param(name, fallback, min, max) {
    const raw = query.get(name);
    const value = raw && raw.trim() ? Number(raw) : NaN;
    return Number.isFinite(value) ? clamp(value, min, max) : fallback;
  }

  const initialScene = query.get('scene') === 'equal' ? 'equal' : 'compare';
  const state = {
    temperatures: [
      Math.round(param('a', presets[initialScene][0], 10, 80)),
      Math.round(param('b', presets[initialScene][1], 10, 80))
    ],
    x: param('x', defaultSource[0], 0.06, 0.94),
    y: param('y', defaultSource[1], 0.06, 0.94) * physics.height,
    time: param('t', 3.3, 0, physics.end),
    playing: query.get('play') === '1' && param('t', 3.3, 0, physics.end) < physics.end,
    tracers: query.get('tracers') === '1',
    hover: -1,
    dragging: -1
  };
  const view = window.DyeDraw.create(canvas);
  let dirty = true;

  function track(action, label) {
    window.Analytics?.track('品红扩散与分子运动', action, label);
  }

  function syncSettings() {
    state.temperatures.forEach((temperature, i) => {
      const [suffix, group] = i ? ['B', $('cupB')] : ['A', $('cupA')];
      const reading = temperature + ' °C';
      group.querySelector('strong').textContent = reading;
      group.style.setProperty('--temperature', temperature <= 33 ? '#8bd4ff' : temperature >= 47 ? '#ffc294' : '#d2c1ff');
      $('temp' + suffix).value = temperature;
      $('out' + suffix).textContent = reading;
    });
    sceneButtons.forEach(button => {
      const selected = presets[button.dataset.scene].every((temperature, i) => temperature === state.temperatures[i]);
      button.classList.toggle('on', selected);
      button.setAttribute('aria-pressed', selected);
    });
    $('tracers').checked = state.tracers;
    const ratio = physics.diffusivity(state.temperatures[1]) / physics.diffusivity(state.temperatures[0]);
    $('ratio').textContent = ratio.toFixed(2) + ' 倍';
    dirty = true;
  }

  function paint() {
    view.draw(state);
    state.temperatures.forEach((temperature, i) => {
      const spread = physics.variance(temperature, state.time);
      const index = physics.unevenness(state.x, state.y, spread);
      const cup = i ? $('cupB') : $('cupA');
      cup.querySelector('.variation').textContent = index < 0.005 && index > 0 ? '<0.01' : index.toFixed(2);
      cup.style.setProperty('--variation', (100 * Math.log1p(index) / Math.log(14)) + '%');
    });
    $('scrub').value = state.time;
    $('time').textContent = state.time.toFixed(1) + ' / 65';
    $('play').textContent = state.playing ? '暂停' : state.time >= physics.end ? '再做一次' : '播放';
    dirty = false;
  }

  function reset(playing = false) {
    state.time = 0;
    state.playing = playing;
    dirty = true;
  }

  function seek(time) {
    state.time = clamp(time, 0, physics.end);
    state.playing = false;
    dirty = true;
  }

  function setScene(scene) {
    state.temperatures = [...presets[scene]];
    [state.x, state.y] = [defaultSource[0], defaultSource[1] * physics.height];
    reset(!reduce.matches);
    syncSettings();
  }

  $('play').onclick = () => {
    if (state.time >= physics.end) reset(true);
    else state.playing = !state.playing;
    dirty = true;
    track(state.playing ? '播放' : '暂停');
  };

  $('reset').onclick = () => { reset(); track('重新滴加'); };
  $('scrub').oninput = event => seek(Number(event.target.value));
  $('scrub').onchange = () => track('拖动时间');
  sceneButtons.forEach(button => {
    button.onclick = () => { setScene(button.dataset.scene); track('切换对照', button.textContent); };
  });

  ['A', 'B'].forEach((suffix, i) => {
    $('temp' + suffix).oninput = event => {
      state.temperatures[i] = Number(event.target.value);
      reset();
      syncSettings();
    };
    $('temp' + suffix).onchange = () => track('调整水温', suffix);
  });

  $('tracers').onchange = event => {
    state.tracers = event.target.checked;
    dirty = true;
    track('示踪粒子', state.tracers ? '显示' : '隐藏');
  };

  function setPanel(open) {
    const shown = open || !mobile.matches;
    $('panel').classList.toggle('collapsed', !shown);
    $('panel').inert = !shown;
    $('panelToggle').setAttribute('aria-expanded', shown);
    $('panelToggle').textContent = open ? '收起设置' : '实验设置';
  }

  $('panelToggle').onclick = () => setPanel($('panel').classList.contains('collapsed'));
  mobile.addEventListener('change', () => setPanel(false));

  function point(event) {
    const box = canvas.getBoundingClientRect();
    return [event.clientX - box.left, event.clientY - box.top];
  }

  function moveSource(index, position) {
    [state.x, state.y] = view.source(index, ...position);
    reset();
  }

  let activePointer = null;
  canvas.addEventListener('pointerdown', event => {
    if (activePointer !== null || event.button !== 0) return;
    const position = point(event);
    const index = view.hit(...position);
    if (index < 0) return;
    canvas.setPointerCapture(event.pointerId);
    activePointer = event.pointerId;
    state.dragging = index;
    canvas.style.cursor = 'grabbing';
    moveSource(index, position);
  });

  canvas.addEventListener('pointermove', event => {
    const position = point(event);
    if (event.pointerId === activePointer) {
      moveSource(state.dragging, position);
    } else if (activePointer === null && event.pointerType === 'mouse') {
      const hover = view.hit(...position);
      if (state.hover === hover) return;
      state.hover = hover;
      canvas.style.cursor = hover < 0 ? '' : 'crosshair';
      dirty = true;
    }
  });

  function release(event) {
    if (event.pointerId !== activePointer) return;
    activePointer = null;
    state.dragging = -1;
    state.hover = event.pointerType === 'mouse' ? view.hit(...point(event)) : -1;
    canvas.style.cursor = state.hover < 0 ? '' : 'crosshair';
    dirty = true;
    if (event.type === 'pointerup') track('移动滴加点');
  }

  ['pointerup', 'pointercancel', 'lostpointercapture'].forEach(type => canvas.addEventListener(type, release));
  canvas.addEventListener('pointerleave', () => {
    state.hover = -1;
    dirty = true;
  });

  canvas.addEventListener('keydown', event => {
    const directions = { ArrowLeft: [-1, 0], ArrowRight: [1, 0], ArrowUp: [0, -1], ArrowDown: [0, 1] };
    const shift = directions[event.key];
    if (!shift) return;
    event.preventDefault();
    state.x = clamp(state.x + shift[0] * 0.04, 0.06, 0.94);
    state.y = clamp(state.y + shift[1] * 0.04, 0.06 * physics.height, 0.94 * physics.height);
    reset();
    if (!event.repeat) track('移动滴加点', '键盘');
  });

  function shareURL() {
    const url = new URL(location.pathname, location.origin);
    url.search = new URLSearchParams({
      scene: state.temperatures[0] === state.temperatures[1] ? 'equal' : 'compare',
      a: state.temperatures[0], b: state.temperatures[1], x: state.x.toFixed(4),
      y: (state.y / physics.height).toFixed(4), t: state.time.toFixed(1),
      play: 0, tracers: Number(state.tracers)
    });
    return url.href;
  }

  $('share').onclick = async () => {
    const link = shareURL();
    try {
      await navigator.clipboard.writeText(link);
      $('shareStatus').textContent = '已复制实验链接';
      $('shareLink').hidden = true;
    } catch {
      $('shareLink').value = link;
      $('shareLink').hidden = false;
      $('shareLink').select();
      $('shareStatus').textContent = '可手动复制下方链接';
    }
    track('分享实验');
  };

  setPanel(false);
  syncSettings();
  new ResizeObserver(() => { dirty = true; }).observe(canvas);
  let last = performance.now();
  function frame(now) {
    if (state.playing) {
      state.time = clamp(state.time + (now - last) * 0.005, 0, physics.end);
      if (state.time >= physics.end) state.playing = false;
      dirty = true;
    }
    last = now;
    if (dirty) paint();
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
  window.__model = { state, preset: setScene, seek, reset, shareURL };
})();
