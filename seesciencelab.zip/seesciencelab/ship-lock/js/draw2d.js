/* 响应式水工剖面：几何按屏幕布局，文字与船体保留原始比例。 */
(function () {
  'use strict';
  let hits = [], view = {};
  function draw(canvas, s) {
    const w = canvas.clientWidth, h = canvas.clientHeight, dpr = window.devicePixelRatio || 1;
    if (canvas.width !== Math.round(w*dpr) || canvas.height !== Math.round(h*dpr)) {canvas.width=Math.round(w*dpr);canvas.height=Math.round(h*dpr);}
    const c=canvas.getContext('2d');c.setTransform(dpr,0,0,dpr,0,0);c.clearRect(0,0,w,h);
    const mobile=w<600, compact=!mobile&&h<680, x=n=>n*w/1000;
    const top=mobile?Math.max(155,h*.24):Math.max(195,h*.25), depth=Math.max(100,Math.min(mobile?260:340,h-top-(mobile?340:compact?230:290))), unit=depth/9, base=top+depth;
    const y=n=>base-n*unit;
    view={w,base,unit};hits=[];
    const fs=mobile?11:13;
    function line(a,b,d,e,color,width=1){c.beginPath();c.moveTo(a,b);c.lineTo(d,e);c.strokeStyle=color;c.lineWidth=width;c.stroke();}
    function rect(a,b,d,e,color){c.fillStyle=color;c.fillRect(a,b,d,e);}
    function text(t,a,b,color='#c2d1de',size=fs,align='center'){c.font=`${size}px -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif`;c.textAlign=align;c.fillStyle=color;c.fillText(t,a,b);}
    function hit(id,a,b,d,e){hits.push({id,x:a,y:b,w:d,h:e});}
    function round(a,b,d,e,color,r=6){c.beginPath();c.roundRect(a,b,d,e,r);c.fillStyle=color;c.fill();}
    // 暗色背景、淡网格与工程剖面，颜色只强调水、船与操作状态。
    rect(0,0,w,h,'#05070d');
    const glow=c.createRadialGradient(w*.48,top+100,10,w*.48,top+100,w*.65);glow.addColorStop(0,'#102335');glow.addColorStop(1,'#05070d');rect(0,90,w,h-90,glow);
    for(let n=0;n<=8;n+=2){c.setLineDash([3,6]);line(x(35),y(n),x(965),y(n),'#25344866');c.setLineDash([]);}
    function water(a,b,level){const yy=y(level),g=c.createLinearGradient(0,yy,0,base);g.addColorStop(0,'#287e9c99');g.addColorStop(1,'#103145bb');rect(a,yy,b,base-yy,g);line(a,yy,a+b,yy,'#7ddbed',2);
      for(let j=0;j<3;j++){const xx=a+b*(.16+j*.28);line(xx,yy+9,xx+Math.min(20,b*.12),yy+9,'#72cddd55');}return yy;}
    function valve(id,a,b,on,label){round(a-19,b-17,38,34,on?'#ffc94a':'#1b2c3d');c.strokeStyle=on?'#ffe5a0':'#638399';c.lineWidth=1;c.strokeRect(a-15,b-13,30,26);line(a-9,b-7,a+9,b+7,on?'#45340e':'#9ab6c8',2);line(a-9,b+7,a+9,b-7,on?'#45340e':'#9ab6c8',2);text(label,a,b+36,on?'#ffda7c':'#b7c9d8',fs);hit(id,a-23,b-23,46,46);}
    function flow(a,b,yy,dir){c.save();c.beginPath();c.rect(a,yy-7,b-a,14);c.clip();const shift=s.time*22%22;for(let xx=a-22+shift*dir;xx<b+22;xx+=22){const tip=xx+dir*8;line(xx,yy,tip,yy,'#86eaff',2);line(tip-dir*4,yy-4,tip,yy,'#86eaff',2);line(tip-dir*4,yy+4,tip,yy,'#86eaff',2);}c.restore();}
    if(s.scene==='vessels'){
      const centers=[x(260),x(700)],widths=[x(130),x(130*s.area)],pipeY=base+16;
      line(centers[0],pipeY,centers[1],pipeY,'#445b70',18);line(centers[0],pipeY,centers[1],pipeY,'#1c5670',12);
      [s.a,s.b].forEach((level,i)=>{const a=centers[i]-widths[i]/2,b=widths[i];water(a,b,level);line(a,y(9.1),a,base,'#9bb8c9',3);line(a+b,y(9.1),a+b,base,'#9bb8c9',3);line(a,base,a+b,base,'#9bb8c9',3);line(centers[i],base,centers[i],pipeY,'#39839b',11);
        text(i?'B 管':'A 管',centers[i],top-31,'#e1ecf5',mobile?13:15);text(`${level.toFixed(2)} m`,centers[i],y(level)-13,'#8ae2f0',mobile?13:16);text(`截面积 ${i?s.area:1}`,centers[i],base+65,'#93aabc');});
      const probeY=y(s.probe);c.setLineDash([5,5]);line(x(100),probeY,x(930),probeY,'#c1a0ed',1.5);c.setLineDash([]);hit('probe',x(90),probeY-22,x(850),44);
      valve('connect',x(480),pipeY,s.connected,'底部连通阀');if(Math.abs(s.flow)>.001)flow(x(300),x(415),pipeY,Math.sign(s.flow));
    }else{
      const left=x(330),right=x(670),gateW=mobile?12:20,pipeY=base+29;
      // 基础、上游抬高的河床与可辨认的混凝土接缝。
      const concrete=c.createLinearGradient(0,base,0,base+85);concrete.addColorStop(0,'#354354');concrete.addColorStop(1,'#17202e');rect(x(20),base,w-x(40),83,concrete);
      water(x(20),left-x(20)-gateW/2,8);water(left+gateW/2,right-left-gateW,s.h);water(right+gateW/2,x(980)-right-gateW/2,4);
      rect(x(20),y(2.92),left-x(20)-gateW/2,base-y(2.92),concrete);
      for(let a=x(45);a<x(970);a+=mobile?32:55)line(a,base+50,a+14,base+67,'#5e6d7b55');
      [left,right].forEach((a,i)=>{const open=s[i?'rightGate':'leftGate'];
        rect(a-gateW/2,top-4,gateW,base-top+9,'#12202e');
        const gy=open?top-3:top+22,gh=open?24:base-gy;
        round(a-gateW/2,gy,gateW,gh,open?'#70bbaa':'#b6a16a',2);
        for(let b=gy+9;b<gy+gh-3;b+=15)line(a-gateW/2+2,b,a+gateW/2-2,b,'#17273288',2);
        round(a-15,top-13,30,12,'#718595',3);
        text(i?'下游门':'上游门',a,top-45,'#a9bece',fs);text(open?'已开':'已关',a,top-26,open?'#8be4bd':'#d8bd77',fs-1);
        hit(i?'rightGate':'leftGate',a-22,top-65,44,base-top+65);
      });
      [[150,8,'上游'],[500,s.h,'闸室'],[850,4,'下游']].forEach(([a,level,label])=>{text(label,x(a),top-45,'#8fa9bb',fs);text(`${level.toFixed(2)} m`,x(a),top-23,a===500?'#ffda7c':'#b6e5f1',mobile?14:18);});
      [[150,450,'leftValve',s.valve==='left','进水阀'],[550,850,'rightValve',s.valve==='right','排水阀']].forEach(([a,b,id,on,label])=>{
        const yy1=y(a===150?3.6:1.2),yy2=y(1.2);
        c.beginPath();c.moveTo(x(a),yy1);c.lineTo(x(a),pipeY);c.lineTo(x(b),pipeY);c.lineTo(x(b),yy2);c.strokeStyle='#0a1521';c.lineWidth=12;c.lineJoin='round';c.stroke();c.strokeStyle=on?'#38849c':'#29475d';c.lineWidth=6;c.stroke();
        if(on&&Math.abs(s.flow)>.001)flow(x(a)+7,x(b)-7,pipeY,1);
        valve(id,x((a+b)/2),pipeY,on,label);
      });
      const probeY=y(s.probe);c.setLineDash([5,5]);line(left+14,probeY,right-14,probeY,'#c1a0ed',1.5);c.setLineDash([]);
      c.beginPath();c.arc(x(500),probeY,4,0,Math.PI*2);c.fillStyle='#d1afff';c.fill();hit('probe',left+22,probeY-22,right-left-44,44);
      const level=Lock.zone(s.x)==='left'?8:Lock.zone(s.x)==='right'?4:s.h, boatY=y(level),boatX=x(s.x),k=mobile?.68:1;
      c.save();c.translate(boatX,boatY);c.scale(k,k);
      // 船体和舱室固定比例；船底吃水跟随计算水面。
      c.beginPath();c.moveTo(-43,-10);c.lineTo(46,-10);c.lineTo(32,11);c.quadraticCurveTo(0,18,-33,10);c.closePath();c.fillStyle='#e8b747';c.fill();line(-38,-5,40,-5,'#ffe6a4',2);
      round(-25,-33,44,23,'#e9e5d9',2);rect(-17,-28,10,10,'#25495e');rect(-2,-28,10,10,'#25495e');rect(-13,-44,25,11,'#9cbdc9');line(28,-10,28,-43,'#d8e0e6',2);c.beginPath();c.moveTo(29,-43);c.lineTo(43,-37);c.lineTo(29,-32);c.fillStyle='#ed8165';c.fill();c.restore();
      hits.unshift({id:'boat',x:boatX-34,y:boatY-37,w:68,h:55});
      text('拖船过闸 · 点门 / 阀操作',w/2,base+111,'#748b9f',11);
    }
    if(!mobile&&!compact)text('教学剖面 · 水位以闸室底为基准',x(30),base+139,'#60778d',10,'left');
    // 压强探测的即时反馈贴近画面，同时保留面板精确读数。
    const hs=s.scene==='vessels'?[s.a,s.b]:[8,s.h,4],labels=s.scene==='vessels'?['A','B']:['上游','闸室','下游'];
    const boxTop=mobile?h-215:Math.min(h-145,base+164);
    if(!compact){round(16,boxTop,w-32,47,'#101824',8);text(`同高 ${s.probe.toFixed(1)} m  ·  压强 kPa`,28,boxTop+17,'#bc9de0',10,'left');
    text(hs.map((v,i)=>`${labels[i]} ${Lock.pressure(v,s.probe).toFixed(1)}`).join('    /    '),28,boxTop+35,'#c3d4e3',mobile?11:12,'left');}
  }
  function point(e,canvas){const r=canvas.getBoundingClientRect(),px=e.clientX-r.left,py=e.clientY-r.top;return{x:px/view.w*1000,y:470-(view.base-py)/view.unit*36,px,py};}
  function hit(p){return hits.find(h=>p.px>=h.x&&p.px<=h.x+h.w&&p.py>=h.y&&p.py<=h.y+h.h)?.id;}
  window.LockDraw={draw,point,hit};
})();
