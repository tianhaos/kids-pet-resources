(function () {
  'use strict';
  const $ = id => document.getElementById(id), canvas = $('canvas');
  const params = new URLSearchParams(location.search);
  let state = Lock.create(['rise','fall','vessels'].includes(params.get('scene')) ? params.get('scene') : 'rise');
  function numeric(key, fallback, min, max) { const raw=params.get(key), n=raw===null?NaN:Number(raw); return Number.isFinite(n)?Math.max(min,Math.min(max,n)):fallback; }
  state.h=numeric('h',state.h,4,8); state.x=numeric('x',state.x,120,880); state.area=numeric('area',3,1,4); state.a=numeric('a',8,1,9);state.b=numeric('b',4,1,9);state.probe=numeric('z',3.5,3.2,3.8);state.play=params.get('play')!=='0';
  [330,670].forEach(g=>{if(Math.abs(state.x-g)<65)state.x=state.x<=g?g-65:g+65;});
  // 无参数首屏直接呈现升船现象；显式场景链接从进船步骤开始。
  if(!location.search){state.h=5.2;state.x=500;state.valve='left';state.message='上游水正流入闸室，船随水面上升。平水后关阀、开上游门出船。';}
  const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
  if(reduced&&params.get('play')===null)state.play=false;
  let dragging='', last=performance.now();
  function track(action,label) { if(window.Analytics) Analytics.track('连通器与船闸',action,label||state.scene); }
  function act(id) {
    if(id==='leftGate'||id==='rightGate') state.message=Lock.gate(state,id==='leftGate'?'left':'right');
    else if(id==='leftValve'||id==='rightValve') state.message=Lock.valve(state,id==='leftValve'?'left':'right');
    else if(id==='next') state.message=Lock.next(state);
    else if(id==='move') {
      const z=Lock.zone(state.x);
      if(z!=='chamber') Lock.move(state,500); else Lock.move(state,state.scene==='fall'?860:140);
      state.message='船只能通过已打开的闸门，拖船也可以操作。';
    } else if(id==='connect') { state.connected=!state.connected;state.message=state.connected?'水从高液面侧流向低液面侧。':'阀门关闭，液面差可以保持。'; }
    track(id); sync();
  }
  function sync() {
    $('scene').value=state.scene; $('lockControls').hidden=state.scene==='vessels'; $('vesselControls').hidden=state.scene!=='vessels';
    $('area').value=state.area;$('areaOut').textContent=state.area.toFixed(1)+' 倍';$('probe').value=state.probe;$('probeOut').textContent=state.probe.toFixed(1)+' m';
    $('play').textContent=state.play?'暂停平水':'继续平水';$('quickPlay').textContent=state.play?'暂停':'继续';$('quickPlay').setAttribute('aria-label',state.play?'暂停平水':'继续平水');$('quickNext').textContent=state.scene==='vessels'?(state.connected?'关闭底阀':'打开底阀'):'下一步演示 →';
    ['leftGate','rightGate'].forEach(id=>{$(id).setAttribute('aria-pressed',String(state[id]));$(id).classList.toggle('on',state[id]);$(id).textContent=(id==='leftGate'?'上游闸门':'下游闸门')+(state[id]?' · 开':' · 关');});
    ['leftValve','rightValve'].forEach(id=>{$(id).setAttribute('aria-pressed',String(state.valve===(id==='leftValve'?'left':'right')));$(id).classList.toggle('on',state.valve===(id==='leftValve'?'left':'right'));});
    $('connect').textContent=state.connected?'关闭连通阀':'打开连通阀';
  }
  ['leftGate','rightGate','leftValve','rightValve','move','next','connect'].forEach(id=>$(id).onclick=()=>act(id));
  $('scene').onchange=()=>{state=Lock.create($('scene').value);if(state.scene==='vessels')state.message='两管同种液体，上方均为大气。先预测平水高度，再打开底阀。';sync();track('切换场景');};
  $('reset').onclick=()=>{state=Lock.create(state.scene);sync();track('重置');};
  $('play').onclick=()=>{state.play=!state.play;sync();track('播放');};
  $('area').oninput=()=>{state.area=Number($('area').value);state.a=8;state.b=4;state.connected=false;sync();};
  $('area').onchange=()=>track('改变面积');
  $('probe').oninput=()=>{state.probe=Number($('probe').value);sync();};
  $('quickNext').onclick=()=>act(state.scene==='vessels'?'connect':'next');
  $('quickPlay').onclick=()=>$('play').click();
  $('panelToggle').onclick=()=>$('panel').classList.toggle('collapsed');
  $('share').onclick=async()=>{
    const url=new URL(location.href);url.search='';url.hash='';
    const data={scene:state.scene,h:state.h.toFixed(3),x:state.x.toFixed(1),area:state.area,a:state.a.toFixed(3),b:state.b.toFixed(3),z:state.probe.toFixed(1),play:0};
    Object.entries(data).forEach(([k,v])=>url.searchParams.set(k,v));
    // 分享静止状态，门与阀复位，避免重建危险的开门组合。
    try {await navigator.clipboard.writeText(url.href);state.message='场景链接已复制（暂停、门阀关闭）。';track('复制链接');} catch {state.message='复制不可用，可复制地址栏场景参数。';history.replaceState(null,'',url.href);}
  };
  canvas.onpointerdown=e=>{const p=LockDraw.point(e,canvas),id=LockDraw.hit(p);if(id==='boat'||id==='probe'){dragging=id;canvas.setPointerCapture(e.pointerId);}else if(id)act(id);};
  canvas.onpointermove=e=>{const p=LockDraw.point(e,canvas);if(dragging==='boat')Lock.move(state,p.x);else if(dragging==='probe'){state.probe=Math.max(3.2,Math.min(3.8,(470-p.y)/36));sync();}canvas.style.cursor=dragging?'grabbing':LockDraw.hit(p)?'grab':'default';};
  function release(){if(dragging)track('拖动',dragging);dragging='';}
  canvas.onpointerup=release;canvas.onpointercancel=release;
  function frame(now){const dt=Math.min(.05,(now-last)/1000);last=now;Lock.step(state,dt);LockDraw.draw(canvas,state);
    const v=state.scene==='vessels',diff=v?state.a-state.b:(state.valve==='left'?8-state.h:state.h-4);
    const caption=v?(state.area===1?'一样粗的管，也会液面相平':'粗管、细管，最终一样高')+'<small>同种液体 · 同一气压 · 静止时液面相平</small>':(state.scene==='fall'?'让船随水位降到下游':'让水把船抬到上游')+'<small>先关门 → 开输水阀 → 平水 → 关阀开门</small>';
    if($('caption').innerHTML!==caption)$('caption').innerHTML=caption;
    $('status').textContent=state.message;
    $('reading').textContent=v?`液面差 ${Math.abs(diff).toFixed(2)} m`:`闸室水位 ${state.h.toFixed(2)} m`;
    $('explain').textContent=v?`总体积（相对单位）：${(state.a+state.area*state.b).toFixed(2)}；平衡 ${( (state.a+state.area*state.b)/(1+state.area)).toFixed(2)} m`:(Math.abs(state.flow)>.001?(state.flow>0?'上游 → 闸室，船随水面上升':'闸室 → 下游，船随水面下降'):'水位静止；开门前先确认两侧水位相平');
    const hs=v?[state.a,state.b]:[8,state.h,4];
    $('pressure').textContent=(v?['A','B']:['上游','闸室','下游']).map((label,i)=>`${label} ${Lock.pressure(hs[i],state.probe).toFixed(1)} kPa`).join(' · ');
    requestAnimationFrame(frame);
  }
  sync();requestAnimationFrame(frame);
  window.__model={get state(){return state;},act,setScene(scene){if(['rise','fall','vessels'].includes(scene)){state=Lock.create(scene);sync();}},advance(t){for(let i=0;i<t/.02;i++)Lock.step(state,.02);},move(x){Lock.move(state,x);}};
})();
