/* 理想船闸与连通器计算；长度m，面积为相对单位，压强kPa。 */
(function () {
  'use strict';
  const HIGH = 8, LOW = 4;
  function create(scene) {
    return { scene, h: scene === 'fall' ? HIGH : LOW, x: scene === 'fall' ? 140 : 860,
      leftGate: false, rightGate: false, valve: '', a: 8, b: 4, area: 3, connected: false,
      probe: 3.5, play: true, time: 0, flow: 0, message: scene === 'vessels' ? '两管同种液体、上方气压相同，打开底阀观察平水。' : '先打开进船一侧的闸门，让船进入闸室。' };
  }
  function pressure(h, z) { return 10 * Math.max(0, h - z); }
  function equal(s, side) { return Math.abs(s.h - (side === 'left' ? HIGH : LOW)) < 0.001; }
  function zone(x) { return x < 330 ? 'left' : x > 670 ? 'right' : 'chamber'; }
  function gate(s, side) {
    const key = side + 'Gate';
    if (s[key]) {
      if (Math.abs(s.x - (side === 'left' ? 330 : 670)) < 70) return '船身仍在门口，请先移开船。';
      s[key] = false; return '闸门已关闭。';
    }
    if (s.leftGate || s.rightGate || s.valve) return '先关闭另一道闸门与输水阀。';
    if (!equal(s, side)) return '两侧水位不同：先关门、开对应输水阀平水。';
    s[key] = true; return '水位相平，闸门已打开，可以拖船通行。';
  }
  function valve(s, side) {
    if (s.leftGate || s.rightGate) return '请先关闭两道闸门。';
    if (zone(s.x) !== 'chamber') return '先让船进入闸室，再进行升降演示。';
    s.valve = s.valve === side ? '' : side;
    return s.valve ? '输水阀已打开：观察水流方向和闸室水位。' : '输水阀已关闭。';
  }
  function move(s, x) {
    x = Math.min(880, Math.max(120, x));
    // 船长110，船身不可穿越关闭的闸门。
    for (const [g, open] of [[330, s.leftGate], [670, s.rightGate]]) {
      if (open) continue;
      if (s.x < g) x = Math.min(x, g - 65); else x = Math.max(x, g + 65);
    }
    s.x = x;
  }
  function step(s, dt) {
    s.flow = 0;
    if (!s.play) return;
    s.time += dt;
    if (s.scene === 'vessels' && s.connected) {
      const d = s.a - s.b;
      const q = Math.sign(d) * Math.min(Math.abs(d) / (1 + 1 / s.area), 0.75 * Math.sqrt(Math.abs(d)) * dt);
      s.a -= q; s.b += q / s.area; s.flow = dt ? q / dt : 0;
      if (Math.abs(s.a - s.b) < 0.001) { const h = (s.a + s.area * s.b) / (1 + s.area); s.a = s.b = h; s.flow = 0; }
    } else if (s.scene !== 'vessels' && s.valve) {
      const target = s.valve === 'left' ? HIGH : LOW, d = target - s.h;
      const delta = Math.sign(d) * Math.min(Math.abs(d), 0.7 * Math.sqrt(Math.abs(d)) * dt);
      s.h += delta; s.flow = dt ? delta / dt : 0;
      if (Math.abs(s.h - target) < 0.001) { s.h = target; s.flow = 0; }
    }
  }
  function next(s) {
    const entry = s.scene === 'fall' ? 'left' : 'right', exit = entry === 'left' ? 'right' : 'left';
    const z = zone(s.x);
    if (z === entry) {
      if (!s[entry + 'Gate']) return gate(s, entry);
      move(s, 500); return '船已进入闸室。下一步关闭进船闸门。';
    }
    if (z === 'chamber') {
      if (s[entry + 'Gate']) return gate(s, entry);
      if (!equal(s, exit)) {
        if (s.valve !== exit) return valve(s, exit);
        s.play = true; return '正在平水，等液面相平后继续。';
      }
      if (s.valve) { s.valve = ''; return '已平水，关闭输水阀。下一步打开出船闸门。'; }
      if (!s[exit + 'Gate']) return gate(s, exit);
      move(s, exit === 'left' ? 140 : 860); return '过闸完成！切换方向再试一次。';
    }
    return '过闸完成，可重置或切换方向。';
  }
  window.Lock = { HIGH, LOW, create, pressure, equal, gate, valve, move, step, next, zone };
})();
