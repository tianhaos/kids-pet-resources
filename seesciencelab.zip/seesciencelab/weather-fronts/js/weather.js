(function () {
  'use strict';

  const scenes = {
    cold: { title: '冷锋', front: true, color: '#69b8ff', slope: -.27, rain: [-.145, .018], duration: 16 },
    warm: { title: '暖锋', front: true, color: '#ff927a', slope: .60, rain: [.018, .31], duration: 24 },
    low: { title: '气旋', front: false, color: '#6dd4fb', center: 992 },
    high: { title: '反气旋', front: false, color: '#ffc078', center: 1032 },
  };
  const clamp = (n, min = 0, max = 1) => Math.max(min, Math.min(max, n));
  const mix = (a, b, t) => a + (b - a) * t;
  const smooth = t => {
    const x = clamp(t);
    return x * x * (3 - 2 * x);
  };
  const frontX = t => mix(-.12, 1.08, clamp(t));
  const frontTime = x => clamp((x + .12) / 1.20);
  const boundary = (scene, x, height) => x + scenes[scene].slope * height;

  function rainAt(scene, distance) {
    const [left, right] = scenes[scene].rain;
    if (distance <= left || distance >= right) return 0;
    const t = (distance - left) / (right - left);
    return (scene === 'cold' ? 1 : .48) * smooth(t / .22) * smooth((1 - t) / .24);
  }

  function station(scene, t, x) {
    const cold = scene === 'cold';
    const distance = x - frontX(t);
    const warmFraction = smooth(.5 + (cold ? distance : -distance) / .065);
    const rain = rainAt(scene, distance);
    const phase = Math.abs(distance) < .025 ? '锋线经过' : distance > 0 ? '锋线到达前' : '锋线通过后';
    const weather = rain > .12 ? (cold ? '阵雨' : '持续性降雨') :
      rain > 0 ? '零星降雨' : Math.abs(distance) < .035 ? '多云' : '晴到少云';
    return { distance, phase, weather, rain, temperature: mix(9, 22, warmFraction),
      pressure: mix(1018, 1006, warmFraction), hours: t * scenes[scene].duration };
  }

  function passage(scene, x) {
    const [left, right] = scenes[scene].rain;
    return { start: frontTime(x - right), crossing: frontTime(x), end: frontTime(x - left) };
  }

  function circulation(scene, hemisphere) {
    const low = scene === 'low';
    const rotation = (low ? -1 : 1) * (hemisphere === 'south' ? -1 : 1);
    return { low, rotation, radial: low ? -1 : 1, vertical: low ? 1 : -1,
      spin: rotation < 0 ? '逆时针' : '顺时针', surface: low ? '辐合' : '辐散',
      aloft: low ? '辐散' : '辐合', rise: low ? '上升' : '下沉',
      weather: low ? '多云雨' : '多晴朗' };
  }

  // 半径以最外侧等压线为 1。角度按屏幕坐标，向下为正。
  function pressureAt(scene, radius) {
    return mix(scenes[scene].center, 1012, Math.min(1.45, radius) ** 2);
  }

  function windAt(scene, hemisphere, x, y) {
    const radius = Math.hypot(x, y);
    if (radius < .001) return { x: 0, y: 0 };
    const { radial, rotation } = circulation(scene, hemisphere);
    const r = .29 * radial;
    const tangent = Math.sqrt(1 - r * r) * rotation;
    return { x: (r * x - tangent * y) / radius, y: (r * y + tangent * x) / radius };
  }

  function flowPoint(scene, hemisphere, angle, t) {
    const { radial, rotation } = circulation(scene, hemisphere);
    const progress = radial > 0 ? t : 1 - t;
    const radius = mix(.22, 1.07, progress);
    // 对数螺线保持与等压线的夹角，与探针风向一致。
    const sweep = Math.sqrt(1 - .29 ** 2) / .29 * Math.log(radius / (radial > 0 ? .22 : 1.07));
    const theta = angle + rotation * radial * sweep;
    return { x: radius * Math.cos(theta), y: radius * Math.sin(theta) };
  }

  window.Weather = { scenes, clamp, mix, frontX, frontTime, boundary, rainAt, station, passage,
    circulation, pressureAt, windAt, flowPoint };
})();
