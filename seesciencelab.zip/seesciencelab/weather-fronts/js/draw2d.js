(function () {
  'use strict';

  const W = window.Weather;
  const TAU = 2 * Math.PI;
  const GOLD = '#ffc94a';
  const ICE = '#95d5ff';
  const WARM = '#ffad94';
  const WHITE = '#e8f4ff';
  const fract = x => x - Math.floor(x);
  const seed = i => fract(Math.sin(i * 71.47 + .13) * 47339.14);

  function line(ctx, points, color, width = 1) {
    ctx.beginPath();
    points.forEach(([x, y], i) => i ? ctx.lineTo(x, y) : ctx.moveTo(x, y));
    ctx.strokeStyle = color;
    ctx.lineWidth = width;
    ctx.stroke();
  }

  function area(ctx, points, fill) {
    ctx.beginPath();
    points.forEach(([x, y], i) => i ? ctx.lineTo(x, y) : ctx.moveTo(x, y));
    ctx.closePath();
    ctx.fillStyle = fill;
    ctx.fill();
  }

  function circle(ctx, x, y, r, fill, stroke) {
    ctx.beginPath();
    ctx.arc(x, y, r, 0, TAU);
    if (fill) { ctx.fillStyle = fill; ctx.fill(); }
    if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = 1.25; ctx.stroke(); }
  }

  function text(ctx, value, x, y, color = WHITE, size = 12, align = 'center', weight = 500) {
    ctx.font = `${weight} ${size}px system-ui, sans-serif`;
    ctx.textAlign = align;
    ctx.textBaseline = 'middle';
    ctx.fillStyle = color;
    ctx.fillText(value, x, y);
  }

  function tag(ctx, value, x, y, color = WHITE, size = 12) {
    ctx.font = `600 ${size}px system-ui, sans-serif`;
    const width = ctx.measureText(value).width + 18;
    ctx.beginPath();
    ctx.roundRect(x - width / 2, y - 12, width, 24, 6);
    ctx.fillStyle = '#0c1826eb';
    ctx.fill();
    text(ctx, value, x, y, color, size, 'center', 600);
  }

  function arrow(ctx, x, y, dx, dy, color, tip = 7, weight = 2) {
    const length = Math.hypot(dx, dy);
    if (length < .01) return;
    const ux = dx / length, uy = dy / length;
    const endX = x + dx, endY = y + dy;
    line(ctx, [[x, y], [endX, endY]], color, weight);
    area(ctx, [[endX, endY], [endX - tip * ux - .48 * tip * uy, endY - tip * uy + .48 * tip * ux],
      [endX - tip * ux + .48 * tip * uy, endY - tip * uy - .48 * tip * ux]], color);
  }

  function sky(ctx, width, height, ground, storm) {
    const gradient = ctx.createLinearGradient(0, 0, 0, height);
    gradient.addColorStop(0, '#081726');
    gradient.addColorStop(.67, storm ? '#203b52' : '#294759');
    gradient.addColorStop(Math.min(.97, ground / height), '#506777');
    gradient.addColorStop(1, '#304657');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);
  }

  function cloud(ctx, x, y, w, h, storm, flat = false) {
    if (w <= 0 || h <= 0) return;
    ctx.save();
    ctx.translate(x, y);
    ctx.scale(w, h);
    ctx.beginPath();
    ctx.moveTo(-.5, .58);
    ctx.bezierCurveTo(-.55, .34, -.43, .04, -.33, .15);
    ctx.bezierCurveTo(-.33, flat ? -.12 : -.42, -.14, flat ? -.27 : -.62, -.04, -.29);
    ctx.bezierCurveTo(.08, flat ? -.4 : -.98, .25, flat ? -.17 : -.69, .31, .11);
    ctx.bezierCurveTo(.43, -.02, .54, .24, .5, .58);
    ctx.bezierCurveTo(.3, .68, -.27, .68, -.5, .58);
    const fill = ctx.createLinearGradient(0, -.75, .09, .65);
    fill.addColorStop(0, storm ? '#dae8f1' : '#f6e9da');
    fill.addColorStop(.42, storm ? '#9eb5cc' : '#ccced1');
    fill.addColorStop(1, storm ? '#3d5572' : '#697c90');
    ctx.fillStyle = fill;
    ctx.fill();
    ctx.restore();
  }

  function sun(ctx, x, y, radius) {
    const halo = ctx.createRadialGradient(x, y, radius, x, y, radius * 3.9);
    halo.addColorStop(0, '#ffc77a45');
    halo.addColorStop(1, '#ffc77a00');
    circle(ctx, x, y, radius * 3.9, halo);
    circle(ctx, x, y, radius, '#ffe5a7');
  }

  function terrain(ctx, w, ground, h) {
    const horizon = (base, amplitude, shift, fill) => {
      const points = Array.from({ length: 66 }, (_, i) => {
        const x = i / 65;
        const profile = .38 * Math.sin((x + shift) * 13) + .34 * Math.sin(x * 32 + shift) +
          .16 * Math.cos(x * 63 + shift) + .08 * Math.sin(x * 126);
        return [x * w, ground + base - amplitude * (1 + profile)];
      });
      area(ctx, [...points, [w, h], [0, h]], fill);
    };
    horizon(2, Math.min(48, h * .115), 3.4, '#516476');
    horizon(7, Math.min(30, h * .072), 1.6, '#344c60');
    horizon(7, Math.min(15, h * .033), .8, '#253f49');
    const fill = ctx.createLinearGradient(0, ground, 0, h);
    fill.addColorStop(0, '#1f3839');
    fill.addColorStop(1, '#0c1b23');
    area(ctx, [[0, ground], [w, ground], [w, h], [0, h]], fill);
    for (let i = 0; i < 43; i++) {
      const x = seed(i + 203) * w, y = ground + 3 + seed(i + 28) * (h - ground - 5);
      line(ctx, [[x, y], [x + 6 + 12 * seed(i), y]], '#5c8c813c');
    }
    line(ctx, [[0, ground], [w, ground]], '#7b9b9c');
  }

  function rain(ctx, left, right, top, bottom, time, intensity) {
    if (bottom <= top) return;
    ctx.save();
    ctx.lineWidth = 1.35;
    for (let i = 0; i < 150; i++) {
      const fraction = seed(i + 581);
      const density = intensity(fraction);
      if (seed(i + 982) > density) continue;
      const speed = .68 + seed(i + 641) * .42;
      const y = W.mix(top, bottom, fract(seed(i + 335) + time * speed));
      const x = W.mix(left, right, fraction);
      ctx.globalAlpha = .22 + .51 * density;
      line(ctx, [[x, y], [x + 1.7, Math.min(bottom, y + 5 + 5 * speed)]], '#a7d8ff', 1.25);
    }
    ctx.restore();
  }

  function layout(w, h, front) {
    if (front) return { w, h, ground: Math.max(h * .65, h - Math.max(60, h * .19)), air: h * .65 };
    const beside = w / h > 1.43 && w > 710;
    const map = { w: beside ? w * .58 : w, h: beside ? h : h * .59 };
    map.cx = map.w * .5;
    map.cy = map.h * .53;
    map.r = Math.min(map.w * .404, map.h * .38);
    return { w, h, beside, map, section: { x: beside ? map.w : 0, y: beside ? 0 : map.h,
      w: beside ? w - map.w : w, h: beside ? h : h - map.h } };
  }

  function stationHouse(ctx, x, y, active) {
    if (active) circle(ctx, x, y - 19, 25, '#ffc94a24', '#ffc94a73');
    area(ctx, [[x - 11, y], [x - 11, y - 15], [x + 10, y - 15], [x + 10, y]], '#dcc9b5');
    area(ctx, [[x - 15, y - 14], [x, y - 26], [x + 14, y - 14]], '#c5705b');
    area(ctx, [[x - 3, y], [x - 3, y - 9], [x + 3, y - 9], [x + 3, y]], '#425c71');
    area(ctx, [[x + 16, y], [x + 16, y - 26], [x + 18, y - 26], [x + 18, y]], '#d9d7c6');
    area(ctx, [[x + 17, y - 26], [x + 27, y - 23], [x + 17, y - 20]], GOLD);
    line(ctx, [[x, y + 2], [x, y + 12]], GOLD, 1.4);
    tag(ctx, '观测站 ↔', x, y + 27, GOLD, 12);
  }

  function frontFlow(ctx, w, ground, air, fx, cold, clock) {
    const extent = cold ? -.23 : .32;
    const entry = cold ? .19 : -.21;
    const curve = t => {
      const x = t < .3 ? W.mix(entry, 0, t / .3) : extent * (t - .3) / .7;
      const z = t < .3 ? .1 + .05 * t / .3 : .15 + (cold ? .68 : .40) * (t - .3) / .7;
      return [(fx + x) * w, ground - air * z];
    };
    const trace = Array.from({ length: 26 }, (_, i) => curve(i / 25));
    line(ctx, trace, '#ffd1a994', 2);
    [0, .27, .54, .81].forEach((offset, i) => {
      const t = fract(offset + clock * .45);
      const a = curve(t), b = curve(Math.min(1, t + .055));
      ctx.globalAlpha = Math.min(1, t * 18, (1 - t) * 18);
      arrow(ctx, ...a, b[0] - a[0], b[1] - a[1], '#ffe2b0', 7, i % 2 ? 1.5 : 2.6);
      ctx.globalAlpha = 1;
    });
  }

  function front(ctx, box, state) {
    const { w, h, ground, air } = box;
    const cfg = W.scenes[state.scene], cold = state.scene === 'cold';
    const fx = W.frontX(state.t), x = fx * w;
    const topX = W.boundary(state.scene, fx, ground / air) * w;
    const small = w < 470;
    sky(ctx, w, h, ground, true);
    const tint = (a, b) => {
      const g = ctx.createLinearGradient(0, 0, 0, ground);
      g.addColorStop(0, a);
      g.addColorStop(1, b);
      return g;
    };
    ctx.save();
    ctx.beginPath();
    ctx.rect(0, 0, w, ground);
    ctx.clip();
    const coldSide = cold ? 0 : w;
    const warmSide = cold ? w : 0;
    area(ctx, [[warmSide, 0], [topX, 0], [x, ground], [warmSide, ground]],
      tint('#c6815c20', '#b26a494a'));
    area(ctx, [[coldSide, 0], [topX, 0], [x, ground], [coldSide, ground]],
      tint('#348dce20', '#168de747'));

    ctx.restore();
    terrain(ctx, w, ground, h);
    ctx.save();
    ctx.beginPath();
    ctx.rect(0, 0, w, ground);
    ctx.clip();
    [0.2, 0.43, 0.66].forEach(z => {
      const y = ground - air * z;
      line(ctx, [[0, y], [w, y]], '#b6d0e520');
    });
    // 雨带范围与站点降水、时间轴共用同一组边界。
    const [left, right] = cfg.rain.map(offset => (fx + offset) * w);
    const band = right - left;
    const base = ground - air * (cold ? .46 : .43);
    const clearX = cold ? x + w * .29 : x - w * .26;
    sun(ctx, clearX, ground - air * .80, Math.min(24, h * .045));
    cloud(ctx, clearX + (cold ? .14 : -.15) * w, ground - air * .66, .13 * w, .065 * air, false, true);

    const haze = ctx.createLinearGradient(left, 0, right, 0);
    haze.addColorStop(0, '#38619700');
    haze.addColorStop(.3, '#5089c744');
    haze.addColorStop(.72, '#5089c744');
    haze.addColorStop(1, '#38619700');
    ctx.fillStyle = haze;
    ctx.fillRect(left, base, band, ground - base);
    rain(ctx, left, right, base, ground, state.clock, t => W.rainAt(state.scene, W.mix(...cfg.rain, t)));

    line(ctx, [[topX, 0], [x, ground]], cfg.color, 2.5);
    if (cold) {
      cloud(ctx, left + band * .48, base - air * .13, band * 1.32, air * .36, true);
      cloud(ctx, left + band * .74, base + air * .014, band * .85, air * .13, true, true);
    } else {
      cloud(ctx, left + band * .55, base - air * .04, band * 1.20, air * .17, true, true);
      cloud(ctx, left + band * .72, base + air * .018, band * .88, air * .105, true, true);
      cloud(ctx, right + w * .045, base - air * .20, band * .48, air * .081, false, true);
    }
    frontFlow(ctx, w, ground, air, fx, cold, state.clock);
    const positions = cold ? [[x - w * .25, ICE, '冷气团'], [x + w * .20, WARM, '暖气团']] :
      [[x - w * .19, WARM, '暖气团'], [x + w * .29, ICE, '冷气团']];
    for (const [labelX, color, value] of positions) {
      if (labelX > 34 && labelX < w - 34) tag(ctx, value, labelX, ground - air * .24, color, small ? 11 : 13);
    }
    if (left + band / 2 > 46 && left + band / 2 < w - 46) {
      tag(ctx, cold ? '窄雨带' : '宽雨带', left + band / 2, base - air * (cold ? .38 : .21), ICE);
    }
    ctx.restore();

    const range = [Math.max(0, left), Math.min(w, right)];
    if (range[1] > range[0]) line(ctx, [[range[0], ground + 2], [range[1], ground + 2]], '#6eb9ff', 4);
    if (cold) {
      area(ctx, [[x - 6, ground + 1], [x + 6, ground + 1], [x + 8, ground - 12]], cfg.color);
    } else {
      ctx.beginPath();
      ctx.arc(x, ground, 8, Math.PI, TAU);
      ctx.fillStyle = cfg.color;
      ctx.fill();
    }
    const directionLen = small ? 24 : 41;
    const directionX = W.clamp(x + 12, 18, w - directionLen - 21);
    arrow(ctx, directionX, ground + 11, directionLen, 0, cfg.color);
    const stationX = state.site * w;
    stationHouse(ctx, stationX, ground, state.hover || state.dragging);
    text(ctx, '锋面和雨带向右移动', 11, h - 15, '#b7c9da', small ? 10 : 12, 'left');
    text(ctx, '蓝线为地面雨区', w - 11, h - 15, '#a8c8e5', small ? 10 : 12, 'right');
  }

  function mapBackdrop(ctx, w, h) {
    const background = ctx.createLinearGradient(0, 0, w, h);
    background.addColorStop(0, '#102943');
    background.addColorStop(1, '#071626');
    ctx.fillStyle = background;
    ctx.fillRect(0, 0, w, h);
    const coast = [[0, 0], [.38, 0], [.34, .14], [.25, .19], [.28, .28], [.36, .33],
      [.31, .38], [.2, .38], [.22, .45], [.15, .48], [.17, .59], [.12, .68], [.19, .77],
      [.12, .84], [.15, 1], [0, 1]].map(([x, y]) => [x * w, y * h]);
    area(ctx, coast, '#294744');
    line(ctx, coast.slice(1, -1), '#57777799', 1.5);
    const island = [[.89, .54], [.94, .51], [.96, .59], [.92, .66], [.88, .68], [.87, .59]].map(([x, y]) => [x*w, y*h]);
    area(ctx, island, '#284144');
    line(ctx, [...island, island[0]], '#52757786');
    for (let y = h * .15; y < h; y += 34) line(ctx, [[0, y], [w, y]], '#8eabc417');
    for (let x = w * .09; x < w; x += 42) line(ctx, [[x, 0], [x, h]], '#8eabc417');
  }

  function pressureMap(ctx, map, state) {
    const { w, h, cx, cy, r } = map;
    const cfg = W.scenes[state.scene], flow = W.circulation(state.scene, state.hemi);
    const px = x => cx + r * x, py = y => cy + r * y;
    ctx.save();
    ctx.beginPath();
    ctx.rect(0, 0, w, h);
    ctx.clip();
    mapBackdrop(ctx, w, h);
    const glow = ctx.createRadialGradient(cx, cy, 0, cx, cy, r * 1.18);
    glow.addColorStop(0, flow.low ? '#4589b88a' : '#c0793c7a');
    glow.addColorStop(1, flow.low ? '#4589b800' : '#c0793c00');
    circle(ctx, cx, cy, r * 1.2, glow);
    if (flow.low) {
      // 用宽云带表示湿润上升区，风向由独立的流线提供。
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(state.hemi === 'north' ? -.46 : .46);
      ctx.globalAlpha = .33;
      cloud(ctx, 0, -.065 * r, 1.48 * r, .49 * r, true, true);
      cloud(ctx, .23 * r, .33 * r, .90 * r, .28 * r, true, true);
      ctx.restore();
    }
    for (let i = 1; i <= 4; i++) {
      const radius = Math.sqrt(i / 4);
      circle(ctx, cx, cy, r * radius, null, '#adc6de88');
      const angle = -.78;
      const value = W.pressureAt(state.scene, radius).toFixed(0);
      const x = px(radius * Math.cos(angle)), y = py(radius * Math.sin(angle));
      ctx.font = '11px system-ui';
      ctx.fillStyle = '#102236';
      ctx.fillRect(x - 16, y - 7, 32, 14);
      text(ctx, value, x, y, '#c4d8eb', 11);
    }
    for (let i = 0; i < 6; i++) {
      const angle = i * TAU / 6 + .2;
      const point = t => W.flowPoint(state.scene, state.hemi, angle, t);
      const trace = Array.from({ length: 40 }, (_, i) => {
        const p = point(i / 39);
        return [px(p.x), py(p.y)];
      });
      line(ctx, trace, flow.low ? '#78daf054' : '#ffbb705c', 1.25);
      for (let j = 0; j < 2; j++) {
        const t = fract(state.clock * .28 + j * .52 + i * .077 + .13);
        const p = point(t);
        const v = W.windAt(state.scene, state.hemi, p.x, p.y);
        ctx.globalAlpha = Math.min(1, t * 12, (1 - t) * 12);
        arrow(ctx, px(p.x) - 3 * v.x, py(p.y) - 3 * v.y, v.x * 16, v.y * 16, cfg.color, 7, 2.2);
      }
    }
    ctx.globalAlpha = 1;
    circle(ctx, cx, cy, 25, '#0e1d2c', cfg.color);
    text(ctx, flow.low ? '低' : '高', cx, cy - 4, cfg.color, 19, 'center', 700);
    text(ctx, cfg.center, cx, cy + 13, WHITE, 10);
    arrow(ctx, w - 28, 47, 0, -17, '#b6c8dd');
    text(ctx, '北', w - 28, 20, '#b6c8dd', 11);
    text(ctx, '等压线 · hPa', 12, h - 15, '#bccddf', 11, 'left');
    text(ctx, state.hemi === 'south' ? '南半球' : '北半球', w - 12, h - 15, '#bccddf', 11, 'right');
    if (state.probe) {
      const { x, y } = state.probe;
      const v = W.windAt(state.scene, state.hemi, x, y);
      circle(ctx, px(x), py(y), 6, '#0e1d2c', GOLD);
      arrow(ctx, px(x), py(y), 26 * v.x, 26 * v.y, GOLD, 8);
    }
    ctx.restore();
  }

  function pressureSection(ctx, rect, state) {
    const { x, y, w, h } = rect;
    const flow = W.circulation(state.scene, state.hemi), color = W.scenes[state.scene].color;
    const ground = h * .82, center = w * .5, top = h * .27;
    ctx.save();
    ctx.translate(x, y);
    ctx.beginPath();
    ctx.rect(0, 0, w, h);
    ctx.clip();
    sky(ctx, w, h, ground, flow.low);
    terrain(ctx, w, ground, h);
    if (flow.low) {
      rain(ctx, w * .37, w * .63, h * .44, ground, state.clock, t => .68 * Math.sin(t * Math.PI));
      cloud(ctx, center, h * .38, w * .38, h * .17, true);
      cloud(ctx, w * .57, h * .43, w * .25, h * .105, true, true);
    } else {
      sun(ctx, w * .70, h * .40, Math.min(22, .071 * h));
      cloud(ctx, w * .25, h * .46, w * .16, h * .05, false, true);
    }
    const near = ground - Math.min(20, h * .075);
    [1, -1].forEach(side => {
      const span = w * .26;
      const a = center + side * w * .14, b = a + span * side;
      const run = (level, sign) => arrow(ctx, sign > 0 ? a : b, level, sign * span * side, 0, color, 9, 2.4);
      run(top, -flow.radial);
      run(near, flow.radial);
    });
    const y1 = flow.low ? near : top;
    const y2 = flow.low ? top : near;
    arrow(ctx, center, y1, 0, y2 - y1, color, 10, 2.6);
    for (let i = 0; i < 3; i++) {
      const t = fract(state.clock * .6 + i / 3);
      circle(ctx, center, W.mix(y1, y2, t), 2.9, WHITE);
    }
    text(ctx, '垂直剖面', 12, 18, WHITE, 13, 'left', 700);
    tag(ctx, '高空' + flow.aloft, center, top - 16, color, 11);
    tag(ctx, flow.rise, center + 29, (top + near) / 2, color, 11);
    text(ctx, '近地面' + flow.surface, center, ground + (h - ground) * .48, WHITE, 12);
    ctx.restore();
    const border = x ? [[x, y], [x, y + h]] : [[x, y], [x + w, y]];
    line(ctx, border, '#557088', 1);
  }

  function draw(ctx, box, state) {
    if (W.scenes[state.scene].front) front(ctx, box, state);
    else {
      pressureMap(ctx, box.map, state);
      pressureSection(ctx, box.section, state);
    }
  }
  window.WeatherDraw = { layout, draw };
})();
