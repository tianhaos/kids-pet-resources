(function () {
  'use strict';

  const W = window.Weather, Draw = window.WeatherDraw;
  const $ = id => document.getElementById(id);
  const motion = matchMedia('(prefers-reduced-motion: reduce)');
  const params = new URLSearchParams(location.search);
  const scene = Object.hasOwn(W.scenes, params.get('scene')) ? params.get('scene') : 'cold';
  const defaults = { cold: .57, warm: .44, low: .57, high: .57 };

  function numberParam(name, fallback, min, max) {
    const value = params.get(name);
    return value?.trim() && Number.isFinite(Number(value)) ? W.clamp(Number(value), min, max) : fallback;
  }

  const state = {
    scene, hemi: params.get('hemi') === 'south' ? 'south' : 'north',
    site: numberParam('site', .52, .24, .76),
    t: numberParam('t', defaults[scene], 0, 1),
    clock: .37, playing: params.get('play') === '1' && !motion.matches,
    animate: params.get('play') !== '0' && !motion.matches,
    probe: null, hover: false, dragging: false,
  };
  const canvas = $('weather'), visual = $('visual'), ctx = canvas.getContext('2d');
  const buttons = [...document.querySelectorAll('[data-scene]')];
  const hemispheres = [...document.querySelectorAll('[data-hemi]')];
  const phases = [...document.querySelectorAll('[data-phase]')];
  let box, pointer = null, previousTime, dirty = true, lastReading = '';

  function report(action, label) {
    window.Analytics?.track('锋面与气旋、反气旋', action, label);
  }

  function selectButtons(list, key, value) {
    list.forEach(btn => {
      const selected = btn.dataset[key] === value;
      btn.classList.toggle('on', selected);
      btn.setAttribute('aria-pressed', String(selected));
    });
  }

  function resize() {
    const w = canvas.clientWidth, h = canvas.clientHeight;
    if (!w || !h) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const width = Math.round(w * dpr), height = Math.round(h * dpr);
    if (canvas.width !== width || canvas.height !== height) {
      canvas.width = width;
      canvas.height = height;
    }
    ctx.setTransform(width / w, 0, 0, height / h, 0, 0);
    box = Draw.layout(w, h, W.scenes[state.scene].front);
    dirty = true;
  }

  function updateScene() {
    const cfg = W.scenes[state.scene];
    selectButtons(buttons, 'scene', state.scene);
    $('stage-title').textContent = cfg.title + (cfg.front ? '过境' : '与天气');
    $('stage-hint').textContent = cfg.front ? '拖动观测站或时间轴，看同一地点的天气变化' : '点选天气图，探测当地气压和近地面风向';
    $('front-controls').hidden = !cfg.front;
    $('front-settings').hidden = !cfg.front;
    $('phase-buttons').hidden = !cfg.front;
    if (cfg.front) {
      const order = state.scene === 'cold' ? ['before', 'cross', 'rain', 'after'] : ['before', 'rain', 'cross', 'after'];
      $('phase-buttons').append(...order.map(phase => phases.find(btn => btn.dataset.phase === phase)));
    }
    $('hemispheres').hidden = cfg.front;
    $('keys').hidden = !cfg.front;
    $('scene-note').textContent = cfg.front ?
      '锋面两侧气团的颜色表示相对冷暖。剖面坡度、温度和气压为教学示意。' :
      '天气图为理想化气压场。金色箭头指向风的去向，中心点只显示气压。';
    visual.classList.toggle('is-front', cfg.front);
    visual.classList.toggle('is-pressure', !cfg.front);
    $('weather').setAttribute('aria-label', cfg.front ? '锋面剖面和观测站' : '地面等压线天气图与垂直剖面');
    $('station-slider').value = Math.round(state.site * 100);
    $('station-output').value = Math.round(state.site * 100) + '%';
    lastReading = '';
    resize();
  }

  function switchScene(next) {
    if (!Object.hasOwn(W.scenes, next) || next === state.scene) return;
    state.scene = next;
    state.t = defaults[next];
    state.playing = false;
    state.probe = null;
    state.hover = false;
    updateScene();
    report('切换场景', next);
  }

  function setHemisphere(hemi) {
    if (!['north', 'south'].includes(hemi) || hemi === state.hemi) return;
    state.hemi = hemi;
    dirty = true;
    report('切换半球', hemi);
  }

  function setTime(t) {
    state.t = W.clamp(t);
    state.playing = false;
    dirty = true;
  }

  function setSite(x) {
    state.site = W.clamp(x, .24, .76);
    const p = Math.round(state.site * 100);
    $('station-slider').value = p;
    $('station-output').value = p + '%';
    dirty = true;
  }

  function phaseTime(phase) {
    const { start, crossing, end } = W.passage(state.scene, state.site);
    // “到达前”同时避开先到的暖锋雨带，“通过后”同时等到雨带完全过去。
    if (phase === 'before') return Math.max(0, start - .13);
    if (phase === 'cross') return crossing;
    if (phase === 'rain') return (start + end) / 2;
    return Math.min(1, end + .13);
  }

  function readings() {
    const cfg = W.scenes[state.scene];
    if (cfg.front) {
      const one = W.station(state.scene, state.t, state.site);
      const { start, end, crossing } = W.passage(state.scene, state.site);
      const mode = Math.abs(one.distance) < .025 ? 'cross' : one.rain > .12 ? 'rain' :
        state.t < crossing ? 'before' : 'after';
      selectButtons(phases, 'phase', mode);
      $('time').value = Math.round(state.t * 1000);
      $('clock').value = one.hours.toFixed(1) + ' h';
      $('rain-span').style.left = start * 100 + '%';
      $('rain-span').style.width = (end - start) * 100 + '%';
      $('crossing-mark').style.left = crossing * 100 + '%';
      $('play').textContent = state.playing ? '暂停' : state.t >= 1 ? '重播' : '播放';
      $('play').classList.toggle('on', state.playing);
      const t = one.temperature.toFixed(0) + ' °C', p = one.pressure.toFixed(0) + ' hPa';
      return { local: [one.phase, one.weather, t].join(' · '), title: one.weather,
        items: [['观测时刻', one.phase], ['示意气温', t], ['示意气压', p], ['主要雨区', state.scene === 'cold' ? '锋后及锋线附近' : '锋前冷气团一侧']] };
    }
    const flow = W.circulation(state.scene, state.hemi);
    selectButtons(hemispheres, 'hemi', state.hemi);
    const pressure = W.pressureAt(state.scene, state.probe ? Math.hypot(state.probe.x, state.probe.y) : 0);
    const p = pressure.toFixed(0) + ' hPa';
    return { local: (state.probe ? '探针 ' + p : '中心 ' + p) + ' · ' + flow.spin + flow.surface,
      title: flow.weather,
      items: [[state.probe ? '探针气压' : '中心气压', p], ['近地面气流', flow.spin + flow.surface],
        ['中心气流', flow.rise], ['高空气流', flow.aloft]] };
  }

  function updateReadings() {
    const reading = readings(), signature = JSON.stringify(reading);
    if (signature === lastReading) return;
    lastReading = signature;
    $('local').textContent = reading.local;
    $('reading-title').textContent = reading.title;
    $('reading-items').replaceChildren(...reading.items.flatMap(([key, val]) => {
      const name = document.createElement('dt'), value = document.createElement('dd');
      name.textContent = key;
      value.textContent = val;
      return [name, value];
    }));
  }

  function frame(now) {
    const elapsed = previousTime === undefined ? 0 : Math.min(.05, (now - previousTime) / 1000);
    previousTime = now;
    if (state.playing && W.scenes[state.scene].front) {
      state.t = Math.min(1, state.t + elapsed / (state.scene === 'warm' ? 17 : 12));
      if (state.t === 1) state.playing = false;
      dirty = true;
    }
    if (state.animate) {
      state.clock += elapsed;
      dirty = true;
    }
    if (dirty && box) {
      Draw.draw(ctx, box, state);
      updateReadings();
      dirty = false;
    }
    requestAnimationFrame(frame);
  }

  function xy(event) {
    const rect = canvas.getBoundingClientRect();
    return { x: event.clientX - rect.left, y: event.clientY - rect.top };
  }

  function isGround(p) {
    return p.y >= box.ground - 37 && p.y <= box.ground + 43;
  }

  function probeAt(p) {
    const { cx, cy, r } = box.map;
    const x = (p.x - cx) / r, y = (p.y - cy) / r;
    const radius = Math.hypot(x, y);
    if (radius > 1.45) return false;
    state.probe = { x, y };
    dirty = true;
    return true;
  }

  canvas.addEventListener('pointerdown', event => {
    if (!box || pointer !== null || event.button !== 0) return;
    const p = xy(event);
    if (W.scenes[state.scene].front) {
      if (!isGround(p)) return;
      state.dragging = true;
      if (Math.abs(p.x - state.site * box.w) > 24) setSite(p.x / box.w);
    } else {
      if (p.x > box.map.w || p.y > box.map.h || !probeAt(p)) return;
    }
    pointer = event.pointerId;
    canvas.setPointerCapture(pointer);
    visual.classList.add('is-dragging');
    dirty = true;
  });

  canvas.addEventListener('pointermove', event => {
    if (!box) return;
    const p = xy(event);
    if (event.pointerId === pointer) {
      if (state.dragging) setSite(p.x / box.w);
      else if (p.x >= 0 && p.y >= 0 && p.x <= box.map.w && p.y <= box.map.h) probeAt(p);
    } else if (W.scenes[state.scene].front) {
      const hover = isGround(p) && Math.abs(p.x - state.site * box.w) < 27;
      if (hover !== state.hover) { state.hover = hover; dirty = true; }
    }
  });

  function release(event) {
    if (pointer !== event.pointerId) return;
    if (event.type === 'pointerup') report(state.dragging ? '移动观测站' : '探测气压', state.scene);
    pointer = null;
    state.dragging = false;
    visual.classList.remove('is-dragging');
    dirty = true;
  }

  ['pointerup', 'pointercancel', 'lostpointercapture'].forEach(event => canvas.addEventListener(event, release));
  canvas.addEventListener('pointerleave', () => { state.hover = false; dirty = true; });
  buttons.forEach(btn => btn.addEventListener('click', () => switchScene(btn.dataset.scene)));
  hemispheres.forEach(btn => btn.addEventListener('click', () => setHemisphere(btn.dataset.hemi)));
  phases.forEach(btn => btn.addEventListener('click', () => {
    setTime(phaseTime(btn.dataset.phase));
    report('观察过境阶段', state.scene + '/' + btn.dataset.phase);
  }));
  $('station-slider').addEventListener('input', event => setSite(Number(event.target.value) / 100));
  $('station-slider').addEventListener('change', () => report('移动观测站', state.scene));
  $('time').addEventListener('input', event => setTime(Number(event.target.value) / 1000));
  $('time').addEventListener('change', () => report('拖动时间轴', state.scene));
  $('play').addEventListener('click', () => {
    if (!state.playing && state.t >= 1) state.t = 0;
    state.playing = !state.playing;
    report(state.playing ? '播放过境' : '暂停过境', state.scene);
    dirty = true;
  });
  motion.addEventListener('change', () => {
    state.animate = !motion.matches && params.get('play') !== '0';
    if (motion.matches) state.playing = false;
    dirty = true;
  });
  $('panelToggle').addEventListener('click', () => {
    const closed = $('panel').classList.toggle('collapsed');
    $('panelToggle').setAttribute('aria-expanded', String(!closed));
  });

  function shareUrl() {
    const url = new URL(location.href);
    url.search = '';
    url.hash = '';
    url.searchParams.set('scene', state.scene);
    url.searchParams.set('play', '0');
    if (W.scenes[state.scene].front) {
      url.searchParams.set('t', state.t.toFixed(3));
      url.searchParams.set('site', state.site.toFixed(3));
    } else url.searchParams.set('hemi', state.hemi);
    return url.href;
  }

  $('share').addEventListener('click', async () => {
    const url = shareUrl();
    try {
      await navigator.clipboard.writeText(url);
      $('share-status').textContent = '已复制当前场景链接';
      report('复制场景链接', state.scene);
    } catch {
      $('share-url').hidden = false;
      $('share-url').value = url;
      $('share-url').select();
      $('share-status').textContent = '选中链接后即可复制';
    }
  });

  new ResizeObserver(resize).observe(canvas);
  window.__model = { state, switchScene, setHemisphere, setTime, setSite, shareUrl };
  updateScene();
  requestAnimationFrame(frame);
})();
