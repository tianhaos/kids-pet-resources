// 2D 绘制：① 打点计时器与纸带（装置、展开的纸带、描点作 v-t 图）② v-t 图像与位移（轨道 + v-t / x-t 图像、微元法）
// ③ 推论（频闪照片 + v-t 图像上的面积分割）
// 世界坐标：x 右、y 上，单位 m；图像用 plot(R, o) 建坐标系，返回 X(t)、Y(v) 和反算 tOf(px)
(function () {
  var K = window.Kin, f = K.f;
  var MUTED = '#8d99ab', TEXT = '#e6ebf2', GRID = 'rgba(141,153,171,.14)', LINE = '#4a5670';
  var GOLD = '#ffc94a', VEL = '#4fc3f7', ACC = '#ff7a59', GREEN = '#7ee081', PURPLE = '#c9a7ff', BLUE = '#6f86c9';
  var FONT = '-apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", sans-serif';
  var SEGC = ['#ffc94a', '#4fc3f7', '#7ee081', '#ff9b8a', '#c9a7ff', '#f2a65a'];

  function font(px, w) { return (w ? w + ' ' : '') + px + 'px ' + FONT; }
  function label(ctx, s, x, y, o) {
    o = o || {};
    ctx.font = font(o.size || 12, o.bold ? 600 : null);
    ctx.textAlign = o.align || 'center'; ctx.textBaseline = o.base || 'middle';
    ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(5,7,13,.85)'; ctx.strokeText(s, x, y);
    ctx.fillStyle = o.color || TEXT; ctx.fillText(s, x, y);
  }
  function arrow(ctx, x1, y1, x2, y2, color, o) {
    o = o || {};
    var a = Math.atan2(y2 - y1, x2 - x1), len = Math.hypot(x2 - x1, y2 - y1), size = Math.min(o.size || 9, len * 0.6);
    if (len < 2) return;
    ctx.strokeStyle = ctx.fillStyle = color; ctx.lineWidth = o.width || 2.2; ctx.setLineDash(o.dash || []);
    ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2 - Math.cos(a) * size * 0.6, y2 - Math.sin(a) * size * 0.6); ctx.stroke();
    ctx.setLineDash([]);
    ctx.beginPath();
    ctx.moveTo(x2, y2);
    ctx.lineTo(x2 - size * Math.cos(a - 0.42), y2 - size * Math.sin(a - 0.42));
    ctx.lineTo(x2 - size * Math.cos(a + 0.42), y2 - size * Math.sin(a + 0.42));
    ctx.closePath(); ctx.fill();
  }
  function line(ctx, x1, y1, x2, y2, color, o) {
    o = o || {};
    ctx.strokeStyle = color; ctx.lineWidth = o.width || 1.2; ctx.setLineDash(o.dash || []);
    ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke(); ctx.setLineDash([]);
  }
  function poly(ctx, pts, fill, stroke, w) {
    ctx.beginPath(); pts.forEach(function (p, i) { if (i) ctx.lineTo(p[0], p[1]); else ctx.moveTo(p[0], p[1]); }); ctx.closePath();
    if (fill) { ctx.fillStyle = fill; ctx.fill(); }
    if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = w || 1.5; ctx.setLineDash([]); ctx.stroke(); }
  }
  // 1、2、5 × 10ⁿ 的刻度间隔
  function niceStep(range, n) {
    var raw = range / n, p = Math.pow(10, Math.floor(Math.log10(raw))), m = raw / p;
    return (m < 1.5 ? 1 : m < 3.5 ? 2 : m < 7.5 ? 5 : 10) * p;
  }
  function dec(step) { return step >= 1 ? 0 : Math.min(3, Math.ceil(-Math.log10(step) - 1e-9)); }
  // 竖直方向的双向标注线（量距离用）：x1..x2 在 y 处，文字在上方
  function span(ctx, x1, x2, y, color, text, o) {
    o = o || {};
    line(ctx, x1, y - 4, x1, y + 4, color); line(ctx, x2, y - 4, x2, y + 4, color);
    if (x2 - x1 > 14) { arrow(ctx, (x1 + x2) / 2, y, x1, y, color, { width: 1, size: 5 }); arrow(ctx, (x1 + x2) / 2, y, x2, y, color, { width: 1, size: 5 }); }
    else line(ctx, x1, y, x2, y, color);
    if (text) label(ctx, text, (x1 + x2) / 2, y - (o.dy || 9), { size: o.size || 11, color: color, bold: o.bold });
  }

  function View(canvas) {
    var ctx = canvas.getContext('2d'), W = 0, H = 0, dpr = 1, narrow = false;
    var hits = [];   // 可拖动改时刻的图像区域 [{ P, tOf }]
    function resize(w, h) {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      W = w; H = h; narrow = w < 640;
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
      canvas.style.width = w + 'px'; canvas.style.height = h + 'px';
    }
    function bg() {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      var g = ctx.createLinearGradient(0, 0, 0, H);
      g.addColorStop(0, '#04060c'); g.addColorStop(1, '#0a1120');
      ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
      hits = [];
    }
    function area() {
      var t0 = narrow ? 84 : 44, bottom = narrow ? 44 : 30;
      return { x: 14, y: t0, w: W - 28, h: Math.max(200, H - t0 - bottom) };
    }

    // ---------- 坐标系 ----------
    // o: { x0, x1, y0, y1, xl, yl, title, pad }；t 轴画在 y = 0 处
    function plot(R, o) {
      ctx.fillStyle = 'rgba(17,23,35,.6)'; ctx.fillRect(R.x, R.y, R.w, R.h);
      ctx.strokeStyle = 'rgba(42,52,70,.9)'; ctx.lineWidth = 1; ctx.strokeRect(R.x + 0.5, R.y + 0.5, R.w - 1, R.h - 1);
      var P = { x: R.x + 46, y: R.y + 28, w: R.w - 66, h: R.h - 54 };
      var X = function (t) { return P.x + (t - o.x0) / (o.x1 - o.x0) * P.w; };
      var Y = function (v) { return P.y + P.h - (v - o.y0) / (o.y1 - o.y0) * P.h; };
      var sx = o.xs || niceStep(o.x1 - o.x0, Math.max(3, Math.min(10, P.w / 60))), sy = o.ys || niceStep(o.y1 - o.y0, Math.max(3, Math.min(8, P.h / 34)));
      ctx.strokeStyle = GRID; ctx.lineWidth = 1; ctx.beginPath();
      var i, v;
      for (i = Math.ceil(o.x0 / sx - 1e-9); i * sx <= o.x1 + 1e-9; i++) { v = X(i * sx); ctx.moveTo(v, P.y); ctx.lineTo(v, P.y + P.h); }
      for (i = Math.ceil(o.y0 / sy - 1e-9); i * sy <= o.y1 + 1e-9; i++) { v = Y(i * sy); ctx.moveTo(P.x, v); ctx.lineTo(P.x + P.w, v); }
      ctx.stroke();
      var y0 = Y(Math.max(o.y0, Math.min(o.y1, 0)));
      for (i = Math.ceil(o.x0 / sx - 1e-9); i * sx <= o.x1 + 1e-9; i++) if (i) label(ctx, f(i * sx, dec(sx)), X(i * sx), Math.min(y0 + 11, P.y + P.h + 11), { size: 10, color: MUTED });
      for (i = Math.ceil(o.y0 / sy - 1e-9); i * sy <= o.y1 + 1e-9; i++) label(ctx, f(i * sy, dec(sy)), P.x - 6, Y(i * sy), { size: 10, color: MUTED, align: 'right' });
      arrow(ctx, P.x, y0, P.x + P.w + 12, y0, MUTED, { width: 1.2, size: 7 });
      arrow(ctx, P.x, P.y + P.h, P.x, P.y - 14, MUTED, { width: 1.2, size: 7 });
      label(ctx, o.xl, P.x + P.w + 6, y0 - 11, { size: 11, color: MUTED, align: 'right' });
      label(ctx, o.yl, P.x + 6, R.y + 11, { size: 11, color: MUTED, align: 'left' });
      if (o.title) label(ctx, o.title, R.x + R.w - 8, R.y + 12, { size: 11, color: MUTED, align: 'right' });
      return { P: P, X: X, Y: Y, tOf: function (px) { return o.x0 + (px - P.x) / P.w * (o.x1 - o.x0); } };
    }
    function clipP(g) { ctx.save(); ctx.beginPath(); ctx.rect(g.P.x - 1, g.P.y - 6, g.P.w + 8, g.P.h + 7); ctx.clip(); }

    // ---------- ① 打点计时器与纸带 ----------
    function car(x0, yb, L, hgt) {   // 车尾 x0、车底 yb（屏幕）
      var r = hgt * 0.32;
      ctx.fillStyle = GOLD; ctx.strokeStyle = '#7a5a12'; ctx.lineWidth = 1.2;
      ctx.beginPath(); ctx.roundRect(x0, yb - 2 * r - hgt * 0.7, L, hgt * 0.7, 3); ctx.fill(); ctx.stroke();
      [0.22, 0.78].forEach(function (u) {
        ctx.fillStyle = '#2a2f3a'; ctx.beginPath(); ctx.arc(x0 + L * u, yb - r, r, 0, 7); ctx.fill();
        ctx.fillStyle = '#9aa4b5'; ctx.beginPath(); ctx.arc(x0 + L * u, yb - r, r * 0.4, 0, 7); ctx.fill();
      });
    }
    // o: { tp, t, marks, pts, fit, hook }
    function drawTape(o) {
      bg();
      var tp = o.tp, R = area(), st = K.tapeAt(tp, o.t);
      var aH = Math.min(narrow ? 150 : 190, R.h * 0.3), tH = narrow ? 112 : 120, gap = 12;
      var gH = R.h - aH - tH - 2 * gap;
      apparatus({ x: R.x, y: R.y, w: R.w, h: aH }, tp, o.t, st);
      var printed = 0;
      tp.dots.forEach(function (d, i) { if (d.t <= o.t + 1e-9) printed = i + 1; });
      tapeBand({ x: R.x, y: R.y + aH + gap, w: R.w, h: tH }, tp, printed, o);
      if (gH > 120) vtTape({ x: R.x, y: R.y + aH + tH + 2 * gap, w: R.w, h: gH }, tp, printed, o);
    }
    function apparatus(R, tp, t, st) {
      // 世界：打点计时器出口在 x = 0，长木板 −0.1 … BOARD，滑轮在木板右端
      var x0 = -0.2, x1 = K.BOARD + 0.12, k = Math.min(R.w / (x1 - x0), R.h / 0.42);
      var ox = R.x + (R.w - (x1 - x0) * k) / 2 - x0 * k, top = R.y + R.h * 0.62;
      var X = function (x) { return ox + x * k; };
      // 桌面与长木板
      ctx.fillStyle = 'rgba(111,134,201,.25)'; ctx.fillRect(X(-0.12), top, (K.BOARD + 0.12) * k, Math.max(5, k * 0.02));
      ctx.strokeStyle = BLUE; ctx.lineWidth = 1.5; ctx.strokeRect(X(-0.12), top, (K.BOARD + 0.12) * k, Math.max(5, k * 0.02));
      label(ctx, '长木板', X(0.5), top + Math.max(5, k * 0.02) + 11, { size: 11, color: MUTED });
      // 挡板
      var stopX = K.START + K.CAR_L + 0.04 + (K.BOARD - K.START - K.CAR_L - 0.04);
      ctx.fillStyle = '#8a6a4a'; ctx.fillRect(X(stopX), top - k * 0.05, Math.max(3, k * 0.012), k * 0.05);
      // 滑轮、细绳、钩码
      var pr = Math.max(5, k * 0.025), px = X(K.BOARD + 0.035), py = top - pr * 0.4;
      ctx.strokeStyle = MUTED; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(X(K.BOARD), top); ctx.lineTo(px, py); ctx.stroke();
      ctx.fillStyle = '#2a2f3a'; ctx.strokeStyle = '#9aa4b5'; ctx.beginPath(); ctx.arc(px, py, pr, 0, 7); ctx.fill(); ctx.stroke();
      var carH = Math.max(12, k * 0.06), carL = K.CAR_L * k, rear = X(K.START + st.x), ropeY = top - carH * 0.75;
      ropeY = Math.min(ropeY, py - pr);
      line(ctx, rear + carL, ropeY, px, py - pr, '#cfd6e2', { width: 1 });
      var hy0 = py + Math.max(14, k * 0.06) + st.x * k * 0.5;   // 钩码下降（画面上按 1/2 缩放，免得出界）
      hy0 = Math.min(hy0, R.y + R.h - 6 - tp.n * Math.max(5, k * 0.022));
      line(ctx, px + pr, py, px + pr, hy0, '#cfd6e2', { width: 1 });
      for (var i = 0; i < tp.n; i++) {
        var hh = Math.max(5, k * 0.022);
        ctx.fillStyle = '#9aa4b5'; ctx.strokeStyle = '#4a5670';
        ctx.beginPath(); ctx.roundRect(px + pr - hh * 0.8, hy0 + i * hh, hh * 1.6, hh - 1, 2); ctx.fill(); ctx.stroke();
      }
      var right = px + pr + hh + 52 < R.x + R.w;
      label(ctx, '钩码 ×' + tp.n, right ? px + pr + hh + 6 : px + pr - hh - 6, hy0 + tp.n * hh / 2, { size: 11, color: MUTED, align: right ? 'left' : 'right' });
      // 纸带：从左边的纸带卷穿过打点计时器，连到车尾；已打上的点随纸带向右移动
      var tapeY = top - carH * 0.55, th = Math.max(4, k * 0.016);
      ctx.fillStyle = '#e9e2cc'; ctx.fillRect(X(-0.19), tapeY - th / 2, rear - X(-0.19), th);
      ctx.fillStyle = '#1a1a1a';
      tp.dots.forEach(function (d) {
        if (d.t > t + 1e-9) return;
        var dx = X(st.x - d.x);
        if (dx < rear) { ctx.beginPath(); ctx.arc(dx, tapeY, Math.max(0.8, th * 0.22), 0, 7); ctx.fill(); }
      });
      // 打点计时器
      var tw = Math.max(26, k * 0.12), tH = Math.max(18, k * 0.08);
      ctx.fillStyle = '#3b5a8f'; ctx.strokeStyle = BLUE; ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.roundRect(X(0) - tw, top - tH, tw, tH, 3); ctx.fill(); ctx.stroke();
      ctx.fillStyle = '#ff7a59'; ctx.fillRect(X(0) - tw * 0.55, top - tH - 4, 4, 4);
      label(ctx, '打点计时器', X(0) - tw / 2, top - tH - 13, { size: 11, color: MUTED });
      // 小车
      car(rear, top, carL, carH);
      if (st.v > 0.005) arrow(ctx, rear + carL / 2, top - carH * 1.6 - 6, rear + carL / 2 + 16 + st.v * k * 0.18, top - carH * 1.6 - 6, VEL, { width: 2.2 });
      label(ctx, t > 0 ? 'v = ' + f(st.v) + ' m/s' : '接通电源后释放小车', rear + carL / 2, top - carH * 1.6 - 20, { size: 11, color: VEL });
    }
    // 展开的纸带：计数点 0 在左，纸带上的点越来越稀
    function tapeBand(R, tp, printed, o) {
      var cps = tp.cps, d0 = tp.dots[cps[0]].x, d6 = tp.dots[cps[K.N_SEG]].x;
      var xa = -0.012, xb = d6 - d0 + 0.012, k = (R.w - 20) / (xb - xa);
      var X = function (x) { return R.x + 10 + (x - d0 - xa) * k; };
      var ty = R.y + 44, th = 26;
      ctx.fillStyle = '#e9e2cc'; ctx.fillRect(R.x, ty - th / 2, R.w, th);
      ctx.strokeStyle = 'rgba(0,0,0,.25)'; ctx.strokeRect(R.x + 0.5, ty - th / 2 + 0.5, R.w - 1, th - 1);
      label(ctx, '纸带（放大）：舍去开头过于密集的点，每 5 个间隔取一个计数点，T = 0.1 s', R.x + 4, R.y + 10, { size: 11, color: MUTED, align: 'left' });
      ctx.save(); ctx.beginPath(); ctx.rect(R.x, ty - th / 2, R.w, th); ctx.clip();
      for (var i = 0; i < printed; i++) {
        var px = X(tp.dots[i].x), isC = cps.indexOf(i) >= 0;
        ctx.fillStyle = '#1a1a1a'; ctx.beginPath(); ctx.arc(px, ty, isC && o.marks ? 2.6 : 1.8, 0, 7); ctx.fill();
        if (isC && o.marks) { ctx.strokeStyle = '#b3362a'; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.arc(px, ty, 6, 0, 7); ctx.stroke(); }
      }
      ctx.restore();
      // 刻度尺：0 刻度对准计数点 0
      var ry = ty + th / 2 + 2, mm = 0.001 * k;
      ctx.fillStyle = 'rgba(141,153,171,.12)'; ctx.fillRect(R.x, ry, R.w, 22);
      for (var j = Math.ceil(xa * 1000); j <= xb * 1000; j++) {
        var q = X(d0 + j / 1000);
        if (j % 10 === 0) { line(ctx, q, ry, q, ry + 9, MUTED); if (j % (mm * 10 < 22 ? 20 : 10) === 0 && q < R.x + R.w - 26) label(ctx, String(j / 10), q, ry + 16, { size: 10, color: MUTED }); }
        else if (j % 5 === 0) line(ctx, q, ry, q, ry + 6, MUTED);
        else if (mm > 2.4) line(ctx, q, ry, q, ry + 3.5, MUTED, { width: 0.8 });
      }
      label(ctx, 'cm', R.x + R.w - 12, ry + 16, { size: 10, color: MUTED });
      if (!o.marks) return;
      // 计数点编号与间距
      for (i = 0; i <= K.N_SEG; i++) {
        if (cps[i] >= printed) break;
        label(ctx, String(i), X(tp.dots[cps[i]].x), ty - th / 2 - 8, { size: 11, color: '#ff9b8a', bold: true });
      }
      for (i = 0; i < K.N_SEG; i++) {
        if (cps[i + 1] >= printed) break;
        var a = X(tp.dots[cps[i]].x), b = X(tp.dots[cps[i + 1]].x), c = SEGC[i];
        span(ctx, a, b, ry + 32, c, b - a > 70 ? 'x' + (i + 1) + ' = ' + (tp.xs[i] * 100).toFixed(2) : b - a > 30 ? 'x' + (i + 1) : '', { dy: -12, size: narrow ? 10 : 11 });
      }
    }
    function vtTape(R, tp, printed, o) {
      var vs = K.instV(tp.xs), vMax = (tp.xs[5] / K.T) * 1.15, nShow = 0;
      vs.forEach(function (p, i) { if (tp.cps[i + 2] < printed) nShow = i + 1; });
      var g = plot(R, { x0: 0, x1: 0.62, y0: 0, y1: Math.max(0.3, vMax), xs: 0.1, xl: 't / s', yl: 'v / (m·s⁻¹)', title: '以计数点 0 为计时起点，描出计数点 1～5 的速度' });
      if (!o.pts) return;
      var pts = vs.slice(0, nShow);
      clipP(g);
      if (o.fit && pts.length >= 5) {
        var fl = K.fit(pts), t1 = 0.6;
        line(ctx, g.X(0), g.Y(fl.b), g.X(t1), g.Y(fl.b + fl.k * t1), GOLD, { width: 2 });
        // 斜率三角形
        var ta = 0.15, tb = 0.45, va = fl.b + fl.k * ta, vb = fl.b + fl.k * tb;
        line(ctx, g.X(ta), g.Y(va), g.X(tb), g.Y(va), ACC, { dash: [4, 3] });
        line(ctx, g.X(tb), g.Y(va), g.X(tb), g.Y(vb), ACC, { dash: [4, 3] });
        label(ctx, 'Δt = ' + f(tb - ta, 1) + ' s', (g.X(ta) + g.X(tb)) / 2, g.Y(va) + 12, { size: 11, color: ACC });
        label(ctx, 'Δv = ' + f(vb - va, 3) + ' m/s', g.X(tb) + 6, (g.Y(va) + g.Y(vb)) / 2, { size: 11, color: ACC, align: 'left' });
        label(ctx, 'a = Δv/Δt ≈ ' + f(fl.k, 2) + ' m/s²', g.X(0.03), g.P.y + 8, { size: 13, color: GOLD, bold: true, align: 'left' });
        label(ctx, 'v₀ ≈ ' + f(fl.b, 3) + ' m/s', g.X(0) + 6, g.Y(fl.b) + 12, { size: 11, color: GOLD, align: 'left' });
      }
      pts.forEach(function (p, i) {
        ctx.fillStyle = SEGC[i]; ctx.strokeStyle = '#05070d'; ctx.lineWidth = 1.5;
        ctx.beginPath(); ctx.arc(g.X(p.t), g.Y(p.v), 5, 0, 7); ctx.fill(); ctx.stroke();
        if (!narrow || !o.fit) label(ctx, 'v' + p.k, g.X(p.t) - 10, g.Y(p.v) - 11, { size: 11, color: SEGC[i] });
      });
      ctx.restore();
    }

    // ---------- ② v-t 图像与位移 ----------
    // o: { m, t, tMax, n (微元段数，0 为不显示), xt, range: { v0, v1, x0, x1 } }
    function drawVT(o) {
      bg();
      var R = area(), m = o.m, st = m.at(o.t), rg = o.range;
      var trH = narrow ? 92 : 110;
      track({ x: R.x, y: R.y, w: R.w, h: trH }, o, st);
      var GR = { x: R.x, y: R.y + trH + 12, w: R.w, h: R.h - trH - 12 }, g1, g2;
      if (o.xt) {
        if (GR.w > 900) { g1 = { x: GR.x, y: GR.y, w: GR.w / 2 - 6, h: GR.h }; g2 = { x: GR.x + GR.w / 2 + 6, y: GR.y, w: GR.w / 2 - 6, h: GR.h }; }
        else { g1 = { x: GR.x, y: GR.y, w: GR.w, h: GR.h / 2 - 6 }; g2 = { x: GR.x, y: GR.y + GR.h / 2 + 6, w: GR.w, h: GR.h / 2 - 6 }; }
      } else g1 = GR;
      vtPlot(g1, o, rg);
      if (g2) xtPlot(g2, o, rg);
    }
    function track(R, o, st) {
      var rg = o.range, m = o.m, pad = 30, k = (R.w - 2 * pad) / (rg.x1 - rg.x0);
      var X = function (x) { return R.x + pad + (x - rg.x0) * k; }, ty = R.y + R.h - 34;
      line(ctx, R.x, ty, R.x + R.w, ty, LINE, { width: 2 });
      var sx = niceStep(rg.x1 - rg.x0, Math.max(4, R.w / 70));
      for (var i = Math.ceil(rg.x0 / sx); i * sx <= rg.x1 + 1e-9; i++) {
        var q = X(i * sx);
        line(ctx, q, ty, q, ty + (i === 0 ? 9 : 5), i === 0 ? TEXT : MUTED);
        if (q < R.x + R.w - 34) label(ctx, f(i * sx, dec(sx)), q, ty + 16, { size: 10, color: i === 0 ? TEXT : MUTED });
      }
      label(ctx, 'x / m', R.x + R.w - 4, ty + 16, { size: 10, color: MUTED, align: 'right' });
      // 每 1 s 的位置（频闪）
      if (o.ghost) for (var s = 0; s <= o.t + 1e-9; s += 1) {
        var gx = X(m.at(s).x);
        ctx.strokeStyle = 'rgba(255,201,74,.6)'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.arc(gx, ty - 9, 7, 0, 7); ctx.stroke();
        label(ctx, f(s, 0) + ' s', gx, ty - 26, { size: 9, color: MUTED });
      }
      // 起点到当前位置的位移
      var x0p = X(0), xp = X(st.x);
      if (Math.abs(xp - x0p) > 3) arrow(ctx, x0p, ty - 40, xp, ty - 40, GREEN, { width: 2 });
      // 物体（小球）
      var gr = ctx.createRadialGradient(xp - 3, ty - 12, 1, xp, ty - 9, 9);
      gr.addColorStop(0, '#fff'); gr.addColorStop(0.35, GOLD); gr.addColorStop(1, '#6b5214');
      ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(xp, ty - 9, 9, 0, 7); ctx.fill();
      if (Math.abs(st.v) > 0.01) arrow(ctx, xp, ty - 9, xp + st.v * 9, ty - 9, VEL, { width: 2.4 });
      if (Math.abs(st.a) > 0.01) arrow(ctx, xp, ty - 24, xp + st.a * 14, ty - 24, ACC, { width: 2, size: 7 });
      label(ctx, 'x = ' + f(st.x, 2) + ' m', xp, ty - 52, { size: 12, color: GREEN, bold: true });
      if (!narrow) label(ctx, '速度 v（蓝）  加速度 a（橙）  位移 x（绿）', R.x + 4, R.y + 6, { size: 11, color: MUTED, align: 'left' });
    }
    function vtPlot(R, o, rg) {
      var m = o.m, t = o.t;
      var g = plot(R, { x0: 0, x1: o.tMax, y0: rg.v0, y1: rg.v1, xs: o.tMax > 4 ? 1 : 0.5, xl: 't / s', yl: 'v / (m·s⁻¹)', title: 'v-t 图像：图线与 t 轴围成的面积 = 位移' });
      hits.push(g);
      clipP(g);
      var Y0 = g.Y(0), N = 160, j, tt;
      // 面积：t 轴上方为正（绿），下方为负（红）
      if (t > 0) {
        [[1, 'rgba(126,224,129,.28)'], [-1, 'rgba(255,122,89,.28)']].forEach(function (sg) {
          ctx.beginPath(); ctx.moveTo(g.X(0), Y0);
          for (j = 0; j <= N; j++) { tt = t * j / N; var v = m.at(tt).v; ctx.lineTo(g.X(tt), g.Y(sg[0] > 0 ? Math.max(0, v) : Math.min(0, v))); }
          ctx.lineTo(g.X(t), Y0); ctx.closePath(); ctx.fillStyle = sg[1]; ctx.fill();
        });
      }
      // 微元法矩形
      if (o.n && t > 0) {
        var rs = K.rects(m, t, o.n);
        ctx.strokeStyle = 'rgba(79,195,247,.9)'; ctx.lineWidth = o.n > 20 ? 0.8 : 1.3; ctx.fillStyle = 'rgba(79,195,247,.12)';
        rs.list.forEach(function (r) {
          var x1 = g.X(r.t0), x2 = g.X(r.t1), yv = g.Y(r.v);
          ctx.fillRect(x1, Math.min(yv, Y0), x2 - x1, Math.abs(yv - Y0)); ctx.strokeRect(x1, Math.min(yv, Y0), x2 - x1, Math.abs(yv - Y0));
        });
      }
      // 整条图线（淡）与已走过的部分
      ctx.strokeStyle = 'rgba(255,201,74,.35)'; ctx.lineWidth = 1.5; ctx.setLineDash([5, 4]); ctx.beginPath();
      for (j = 0; j <= N; j++) { tt = o.tMax * j / N; if (j) ctx.lineTo(g.X(tt), g.Y(m.at(tt).v)); else ctx.moveTo(g.X(tt), g.Y(m.at(tt).v)); }
      ctx.stroke(); ctx.setLineDash([]);
      ctx.strokeStyle = GOLD; ctx.lineWidth = 2.6; ctx.beginPath();
      for (j = 0; j <= N; j++) { tt = t * j / N; if (j) ctx.lineTo(g.X(tt), g.Y(m.at(tt).v)); else ctx.moveTo(g.X(tt), g.Y(m.at(tt).v)); }
      ctx.stroke();
      var st = m.at(t);
      line(ctx, g.X(t), g.P.y, g.X(t), g.P.y + g.P.h, 'rgba(230,235,242,.35)', { dash: [3, 3] });
      ctx.fillStyle = GOLD; ctx.beginPath(); ctx.arc(g.X(t), g.Y(st.v), 5, 0, 7); ctx.fill();
      // 刹车：标出停止时刻
      if (isFinite(m.tStop) && m.tStop < o.tMax) {
        line(ctx, g.X(m.tStop), Y0 - 6, g.X(m.tStop), Y0 + 6, ACC, { width: 2 });
        label(ctx, '停止 t₀ = ' + f(m.tStop) + ' s', g.X(m.tStop) + 4, Y0 - 30, { size: 11, color: ACC, align: 'left' });
      }
      if (isFinite(m.tTurn) && m.tTurn < o.tMax) label(ctx, '速度反向', g.X(m.tTurn) + 4, Y0 - 14, { size: 11, color: ACC, align: 'left' });
      ctx.restore();
      // 面积读数
      var txt = (t > m.tTurn ? '上方面积 − 下方面积 = x = ' : '面积 = x = ') + f(st.x, 2) + ' m';
      if (o.n && t > 0) txt = o.n + ' 个矩形面积之和 ≈ ' + f(K.rects(m, t, o.n).sum, 2) + ' m　精确值 x = ' + f(st.x, 2) + ' m';
      label(ctx, txt, g.P.x + 8, g.P.y + 6, { size: 12, color: o.n ? VEL : GREEN, bold: true, align: 'left' });
      label(ctx, 'v = v₀ + at = ' + f(st.v) + ' m/s', g.P.x + 8, g.P.y + 24, { size: 11, color: GOLD, align: 'left' });
    }
    function xtPlot(R, o, rg) {
      var m = o.m, t = o.t, N = 160, j, tt;
      var g = plot(R, { x0: 0, x1: o.tMax, y0: rg.x0, y1: rg.x1, xs: o.tMax > 4 ? 1 : 0.5, xl: 't / s', yl: 'x / m', title: 'x-t 图像：切线斜率 = 速度' });
      hits.push(g);
      clipP(g);
      ctx.strokeStyle = 'rgba(126,224,129,.35)'; ctx.lineWidth = 1.5; ctx.setLineDash([5, 4]); ctx.beginPath();
      for (j = 0; j <= N; j++) { tt = o.tMax * j / N; if (j) ctx.lineTo(g.X(tt), g.Y(m.at(tt).x)); else ctx.moveTo(g.X(tt), g.Y(m.at(tt).x)); }
      ctx.stroke(); ctx.setLineDash([]);
      ctx.strokeStyle = GREEN; ctx.lineWidth = 2.6; ctx.beginPath();
      for (j = 0; j <= N; j++) { tt = t * j / N; if (j) ctx.lineTo(g.X(tt), g.Y(m.at(tt).x)); else ctx.moveTo(g.X(tt), g.Y(m.at(tt).x)); }
      ctx.stroke();
      var st = m.at(t), d = o.tMax * 0.18;
      line(ctx, g.X(t - d), g.Y(st.x - st.v * d), g.X(t + d), g.Y(st.x + st.v * d), VEL, { width: 1.6, dash: [6, 4] });
      line(ctx, g.X(t), g.P.y, g.X(t), g.P.y + g.P.h, 'rgba(230,235,242,.35)', { dash: [3, 3] });
      ctx.fillStyle = GREEN; ctx.beginPath(); ctx.arc(g.X(t), g.Y(st.x), 5, 0, 7); ctx.fill();
      ctx.restore();
      label(ctx, 'x = v₀t + ½at² = ' + f(st.x, 2) + ' m', g.P.x + 8, g.P.y + 6, { size: 12, color: GREEN, bold: true, align: 'left' });
      label(ctx, '切线斜率 = v = ' + f(st.v) + ' m/s', g.P.x + 8, g.P.y + 24, { size: 11, color: VEL, align: 'left' });
    }

    // ---------- ③ 推论 ----------
    // o: { mode: ratio|dx|mid, v0, a, T0, n, t }
    function drawRules(o) {
      bg();
      var R = area(), trH = narrow ? 104 : 120;
      strobe({ x: R.x, y: R.y, w: R.w, h: trH }, o);
      rulesPlot({ x: R.x, y: R.y + trH + 12, w: R.w, h: R.h - trH - 12 }, o);
    }
    function strobe(R, o) {
      var m = K.motion(o.v0, o.a, false), xs = [], i;
      for (i = 0; i <= o.n; i++) xs.push(m.at(i * o.T0).x);
      var pad = 24, k = (R.w - 2 * pad) / (xs[o.n] || 1), X = function (x) { return R.x + pad + x * k; }, ty = R.y + R.h - 44;
      line(ctx, R.x, ty + 10, R.x + R.w, ty + 10, LINE, { width: 2 });
      label(ctx, '频闪照片：每隔 T = ' + f(o.T0) + ' s 拍一次', R.x + 4, R.y + 6, { size: 11, color: MUTED, align: 'left' });
      for (i = 0; i <= o.n; i++) {
        if (i * o.T0 > o.t + 1e-9) break;
        var px = X(xs[i]);
        ctx.fillStyle = i * o.T0 === 0 || i * o.T0 <= o.t ? 'rgba(255,201,74,.75)' : GOLD;
        ctx.beginPath(); ctx.arc(px, ty, 7, 0, 7); ctx.fill();
        label(ctx, f(i * o.T0) + ' s', px, ty + 22, { size: 10, color: MUTED });
        if (i > 0) span(ctx, X(xs[i - 1]), px, ty - 22, SEGC[(i - 1) % 6], 'x' + i + (narrow ? '' : ' = ' + f(xs[i] - xs[i - 1], 2) + ' m'), { size: 11 });
      }
      var cur = X(m.at(Math.min(o.t, o.n * o.T0)).x);
      var gr = ctx.createRadialGradient(cur - 3, ty - 3, 1, cur, ty, 8);
      gr.addColorStop(0, '#fff'); gr.addColorStop(0.35, GOLD); gr.addColorStop(1, '#6b5214');
      ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(cur, ty, 8, 0, 7); ctx.fill();
    }
    function rulesPlot(R, o) {
      var m = K.motion(o.v0, o.a, false), T0 = o.T0, n = o.n, tEnd = n * T0, vEnd = o.v0 + o.a * tEnd, i, j;
      var g = plot(R, { x0: 0, x1: tEnd * 1.06, y0: 0, y1: vEnd * 1.15, xs: T0, ys: o.mode === 'ratio' ? o.a * T0 : null, xl: 't / s', yl: 'v / (m·s⁻¹)', title: o.mode === 'ratio' ? '每个小三角形面积相同' : o.mode === 'dx' ? '相邻两段位移之差 = 阴影平行四边形 = aT²' : '梯形面积 = 以中间时刻速度为高的矩形面积' });
      hits.push(g);
      var done = Math.min(n, Math.floor(o.t / T0 + 1e-9)), Y0 = g.Y(0);
      var V = function (t) { return o.v0 + o.a * t; };
      clipP(g);
      if (o.mode === 'ratio' || o.mode === 'dx') {
        for (i = 0; i < n; i++) {
          var ta = i * T0, tb = Math.min((i + 1) * T0, o.t);
          if (tb <= ta) break;
          poly(ctx, [[g.X(ta), Y0], [g.X(ta), g.Y(V(ta))], [g.X(tb), g.Y(V(tb))], [g.X(tb), Y0]], hexA(SEGC[i % 6], 0.22), null);
        }
      }
      if (o.mode === 'ratio') {
        // 单位三角形：底 T、高 aT；第 k 段由 (2k − 1) 个组成
        var u = o.a * T0;
        for (i = 0; i < done; i++) {
          for (j = 0; j <= i; j++) {
            var xa = g.X(i * T0), xb = g.X((i + 1) * T0), ya = g.Y(j * u), yb = g.Y((j + 1) * u);
            ctx.strokeStyle = 'rgba(230,235,242,.55)'; ctx.lineWidth = 1; ctx.beginPath();
            if (j < i) { ctx.rect(xa, yb, xb - xa, ya - yb); }
            ctx.moveTo(xa, ya); ctx.lineTo(xb, yb);
            if (j === i) ctx.lineTo(xb, ya);
            ctx.stroke();
          }
          label(ctx, String(2 * i + 1) + ' 个', (g.X(i * T0) + g.X((i + 1) * T0)) / 2, g.Y(V((i + 0.5) * T0)) - 14, { size: 12, bold: true, color: SEGC[i % 6] });
        }
      } else if (o.mode === 'dx') {
        // 把上一段梯形向右平移 T：多出来的是底 T、高 aT 的平行四边形
        for (i = 1; i < done; i++) {
          var a0 = i * T0, a1 = (i + 1) * T0;
          poly(ctx, [[g.X(a0), g.Y(V(a0 - T0))], [g.X(a1), g.Y(V(a0))], [g.X(a1), g.Y(V(a1))], [g.X(a0), g.Y(V(a0))]], 'rgba(255,122,89,.45)', ACC, 1.2);
          line(ctx, g.X(a0), g.Y(V(a0 - T0)), g.X(a1), g.Y(V(a0)), ACC, { dash: [4, 3] });
          label(ctx, 'aT²', (g.X(a0) + g.X(a1)) / 2, g.Y(V(a0)) + 2, { size: 11, bold: true, color: '#fff' });
        }
        for (i = 0; i < done; i++) label(ctx, 'x' + (i + 1), (g.X(i * T0) + g.X((i + 1) * T0)) / 2, (Y0 + g.Y(V(i * T0))) / 2, { size: 12, bold: true, color: SEGC[i % 6] });
      } else {
        // 中间时刻：梯形 = 矩形（两个小三角形面积相等）
        var tt = Math.min(o.t, tEnd);
        if (tt > 0) {
          var tm = tt / 2, vm = V(tm);
          poly(ctx, [[g.X(0), Y0], [g.X(0), g.Y(o.v0)], [g.X(tt), g.Y(V(tt))], [g.X(tt), Y0]], 'rgba(126,224,129,.2)', null);
          poly(ctx, [[g.X(0), g.Y(o.v0)], [g.X(0), g.Y(vm)], [g.X(tm), g.Y(vm)]], 'rgba(255,122,89,.5)', ACC, 1);
          poly(ctx, [[g.X(tm), g.Y(vm)], [g.X(tt), g.Y(vm)], [g.X(tt), g.Y(V(tt))]], 'rgba(79,195,247,.5)', VEL, 1);
          line(ctx, g.X(0), g.Y(vm), g.X(tt), g.Y(vm), TEXT, { dash: [5, 4] });
          line(ctx, g.X(tm), Y0, g.X(tm), g.Y(vm), TEXT, { dash: [3, 3] });
          label(ctx, 't/2', g.X(tm), Y0 + 11, { size: 11, bold: true, color: TEXT });
          label(ctx, 'v(t/2) = ' + f(vm) + ' m/s', g.X(0) + 8, g.Y(vm) + 12, { size: 11, color: TEXT, align: 'left' });
          // 中间位置的速度
          var vx = Math.sqrt((o.v0 * o.v0 + V(tt) * V(tt)) / 2);
          line(ctx, g.P.x - 4, g.Y(vx), g.P.x + 10, g.Y(vx), PURPLE, { width: 2 });
          label(ctx, 'v(x/2) = ' + f(vx) + ' m/s', g.P.x + 14, Math.min(g.Y(vx), g.Y(vm) - 12), { size: 11, color: PURPLE, align: 'left' });
        }
      }
      // 图线
      ctx.strokeStyle = GOLD; ctx.lineWidth = 2.6; ctx.beginPath();
      ctx.moveTo(g.X(0), g.Y(o.v0)); ctx.lineTo(g.X(Math.min(o.t, tEnd)), g.Y(V(Math.min(o.t, tEnd)))); ctx.stroke();
      ctx.fillStyle = GOLD; ctx.beginPath(); ctx.arc(g.X(Math.min(o.t, tEnd)), g.Y(V(Math.min(o.t, tEnd))), 5, 0, 7); ctx.fill();
      ctx.restore();
      var head = { ratio: 'x₁ : x₂ : x₃ : x₄ = 1 : 3 : 5 : 7', dx: 'Δx = x₂ − x₁ = x₃ − x₂ = … = aT² = ' + f(o.a * T0 * T0, 2) + ' m', mid: 'v̄ = (v₀ + v)/2 = v(t/2)，v(x/2) > v(t/2)' }[o.mode];
      label(ctx, head, g.P.x + 10, g.P.y + 6, { size: 13, bold: true, color: GOLD, align: 'left' });
    }
    function hexA(hex, a) {
      var n = parseInt(hex.slice(1), 16);
      return 'rgba(' + (n >> 16) + ',' + ((n >> 8) & 255) + ',' + (n & 255) + ',' + a + ')';
    }

    return {
      resize: resize, drawTape: drawTape, drawVT: drawVT, drawRules: drawRules,
      size: function () { return { w: W, h: H, narrow: narrow }; },
      // 屏幕坐标落在某个图像里时返回对应的时刻
      hitT: function (x, y) {
        for (var i = 0; i < hits.length; i++) {
          var P = hits[i].P;
          if (x >= P.x - 10 && x <= P.x + P.w + 10 && y >= P.y - 10 && y <= P.y + P.h + 10) return hits[i].tOf(x);
        }
        return null;
      }
    };
  }

  window.KinDraw = { View: View, niceStep: niceStep };
})();
