(function () {
  var K = window.Kin, D = window.KinDraw, f = K.f;
  var $ = function (id) { return document.getElementById(id); };
  var qa = function (sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); };
  var NAME = '匀变速直线运动';

  var state = {
    scene: 'tape',
    slows: { tape: 0.25, vt: 1, rules: 0.5 },
    t: { tape: 0, vt: 0, rules: 0 }, running: false, paused: false,
    // ① 纸带
    hook: 2, ideal: false, tp: null, marks: true, pts: true, fit: true,
    // ② v-t 图像
    v0: 2, a: 1.5, brake: false, n: 0, xt: true, ghost: true, m: null,
    // ③ 推论
    mode: 'ratio', rv0: 1, ra: 2
  };
  var TMAX = 6, RT = 1, RN = 4;   // v-t 场景时长 6 s；推论场景 T = 1 s、4 段

  var HINTS = {
    tape: '接通电源、释放小车，纸带上打出的点记录了小车的运动',
    vt: '拖动图像改变时刻：v-t 图线与 t 轴围成的面积就是位移',
    rules: '频闪照片与 v-t 图像对照，用面积推出匀变速直线运动的推论'
  };
  var PRESETS = { acc: [2, 1.5, false], dec: [8, -2, false], brake: [10, -2, true], back: [6, -3, false] };
  var MODES = { ratio: '初速度为零的比例', dx: 'Δx = aT²', mid: '中间时刻的速度' };

  var stage = $('stage'), panel = $('panel'), cv = $('view');
  var view = D.View(cv);
  function setSeg(attr, val) { qa('[data-' + attr + ']').forEach(function (b) { b.classList.toggle('on', b.dataset[attr] === String(val)); }); }

  // ---------- 各场景的时长 ----------
  function tEnd() { var sc = state.scene; return sc === 'tape' ? state.tp.tEnd : sc === 'vt' ? TMAX : RN * RT; }
  function rebuildTape() { state.tp = K.tape(state.hook, state.ideal); state.t.tape = 0; state.running = false; }
  function rebuildVT() { state.m = K.motion(state.v0, state.a, state.brake); }
  // 坐标范围在一组参数下固定，不随时刻变化
  function vtRange() {
    var m = state.m, v0 = 0, v1 = 0, x0 = 0, x1 = 0;
    for (var i = 0; i <= 120; i++) {
      var s = m.at(TMAX * i / 120);
      v0 = Math.min(v0, s.v); v1 = Math.max(v1, s.v); x0 = Math.min(x0, s.x); x1 = Math.max(x1, s.x);
    }
    function nice(lo, hi) {
      var st = D.niceStep(Math.max(hi - lo, 1), 5);
      return [lo < 0 ? Math.floor(lo * 1.08 / st) * st : 0, hi > 0 ? Math.ceil(hi * 1.08 / st) * st : st];
    }
    var vr = nice(v0, v1), xr = nice(x0, x1);
    return { v0: vr[0], v1: vr[1], x0: xr[0], x1: xr[1] };
  }

  function play() {
    var sc = state.scene;
    if (state.t[sc] >= tEnd() - 1e-9) state.t[sc] = 0;
    state.running = true; state.paused = false; syncUI();
    Analytics.track(NAME, sc === 'tape' ? '释放小车' : '播放', sc === 'tape' ? state.hook + ' 个钩码' : sc);
  }
  function togglePause() { if (!state.running) { play(); return; } state.paused = !state.paused; syncUI(); }
  function reset() { state.t[state.scene] = 0; state.running = false; state.paused = false; syncUI(); }
  function finish() { state.t[state.scene] = tEnd(); state.running = false; state.paused = false; syncUI(); }

  // ---------- 控件 ----------
  qa('[data-scene]').forEach(function (b) {
    b.addEventListener('click', function () { setScene(b.dataset.scene); Analytics.track(NAME, '场景', b.textContent); });
  });
  function setScene(sc) { state.scene = sc; state.running = false; state.paused = false; syncUI(); }
  qa('[data-hook]').forEach(function (b) {
    b.addEventListener('click', function () { state.hook = +b.dataset.hook; rebuildTape(); syncUI(); Analytics.track(NAME, '钩码', b.textContent); });
  });
  qa('[data-slow]').forEach(function (b) {
    b.addEventListener('click', function () { state.slows[state.scene] = parseFloat(b.dataset.slow); syncUI(); Analytics.track(NAME, '播放速度', b.textContent); });
  });
  qa('[data-preset]').forEach(function (b) {
    b.addEventListener('click', function () {
      var p = PRESETS[b.dataset.preset];
      state.v0 = p[0]; state.a = p[1]; state.brake = p[2]; rebuildVT(); state.t.vt = 0; play();
      Analytics.track(NAME, '情形', b.textContent);
    });
  });
  qa('[data-n]').forEach(function (b) {
    b.addEventListener('click', function () { state.n = +b.dataset.n; syncUI(); Analytics.track(NAME, '微元法', b.textContent); });
  });
  qa('[data-mode]').forEach(function (b) {
    b.addEventListener('click', function () { state.mode = b.dataset.mode; state.t.rules = 0; play(); Analytics.track(NAME, '推论', MODES[state.mode]); });
  });
  function slider(id, key, after, track) {
    var el = $(id);
    el.addEventListener('input', function () { state[key] = parseFloat(el.value); after(); syncUI(); });
    el.addEventListener('change', function () { Analytics.track(NAME, '滑块', track); });
  }
  slider('v0', 'v0', rebuildVT, 'v0');
  slider('a', 'a', rebuildVT, 'a');
  slider('rv0', 'rv0', function () {}, '推论 v0');
  slider('ra', 'ra', function () {}, '推论 a');
  function check(id, key, after) {
    $(id).addEventListener('change', function () { state[key] = $(id).checked; if (after) after(); syncUI(); Analytics.track(NAME, '开关', id + '=' + state[key]); });
  }
  check('ideal', 'ideal', rebuildTape);
  check('marks', 'marks'); check('pts', 'pts'); check('fit', 'fit');
  check('brake', 'brake', rebuildVT); check('xt', 'xt'); check('ghost', 'ghost');

  qa('.play').forEach(function (b) { b.addEventListener('click', togglePause); });
  qa('.reset').forEach(function (b) { b.addEventListener('click', reset); });
  qa('.finish').forEach(function (b) { b.addEventListener('click', function () { finish(); Analytics.track(NAME, '直接看结果', state.scene); }); });

  // 拖动图像改时刻；没有拖到图像上时点画布开始/暂停
  var dragging = false;
  function scrub(e) {
    var r = cv.getBoundingClientRect(), t = view.hitT(e.clientX - r.left, e.clientY - r.top);
    if (t == null || state.scene === 'tape') return false;
    state.t[state.scene] = K.clamp(t, 0, tEnd()); state.paused = true; state.running = true;
    return true;
  }
  cv.addEventListener('pointerdown', function (e) {
    if (e.button !== 0) return;
    if (scrub(e)) { dragging = true; cv.setPointerCapture(e.pointerId); syncUI(); return; }
    togglePause();
  });
  cv.addEventListener('pointermove', function (e) { if (dragging) scrub(e); });
  cv.addEventListener('pointerup', function () { if (dragging) { dragging = false; syncUI(); Analytics.track(NAME, '拖动图像', state.scene); } });

  // ---------- 面板 ----------
  $('panelToggle').addEventListener('click', function () { panel.classList.toggle('collapsed'); });
  if (window.matchMedia('(max-width: 760px)').matches) panel.classList.add('collapsed');
  window.addEventListener('keydown', function (e) {
    var tg = e.target.tagName;
    if (tg === 'INPUT' || tg === 'SELECT' || tg === 'BUTTON' || tg === 'TEXTAREA') return;
    if (e.code === 'Space') { e.preventDefault(); togglePause(); }
  });

  function syncUI() {
    var sc = state.scene;
    setSeg('scene', sc);
    qa('[data-for]').forEach(function (el) { el.hidden = el.dataset.for.split(' ').indexOf(sc) < 0; });
    $('hint').textContent = HINTS[sc];
    setSeg('hook', state.hook); setSeg('slow', state.slows[sc]); setSeg('n', state.n); setSeg('mode', state.mode);
    setSeg('preset', Object.keys(PRESETS).filter(function (k) { var p = PRESETS[k]; return p[0] === state.v0 && p[1] === state.a && p[2] === state.brake; })[0] || '');
    $('v0').value = state.v0; $('v0Out').textContent = f(state.v0, 1) + ' m/s';
    $('a').value = state.a; $('aOut').textContent = f(state.a, 1) + ' m/s²';
    $('rv0').value = state.rv0; $('rv0Out').textContent = f(state.mode === 'ratio' ? 0 : state.rv0, 1) + ' m/s';
    $('ra').value = state.ra; $('raOut').textContent = f(state.ra, 1) + ' m/s²';
    $('rv0').disabled = state.mode === 'ratio';
    ['ideal', 'marks', 'pts', 'fit', 'brake', 'xt', 'ghost'].forEach(function (k) { $(k).checked = state[k]; });
    var lbl = sc === 'tape' ? (state.t.tape > 0 && !state.running ? '↺ 再打一条' : '▶ 释放小车') : '▶ 播放';
    qa('.play').forEach(function (b) { b.textContent = state.running ? (state.paused ? '▶ 继续' : '❚❚ 暂停') : lbl; });
    renderTable();
  }

  // 纸带数据表
  function renderTable() {
    var tp = state.tp, vs = K.instV(tp.xs), dx = K.diffs(tp.xs), done = state.t.tape >= tp.tEnd - 1e-9;
    var html = '<thead><tr><th>段</th><th>x / cm</th><th>Δx / cm</th><th>计数点</th><th>v / (m·s⁻¹)</th></tr></thead><tbody>';
    for (var i = 0; i < K.N_SEG; i++) {
      var ok = done || tp.dots[tp.cps[i + 1]].t <= state.t.tape, okV = i < 5 && (done || tp.dots[tp.cps[i + 2]].t <= state.t.tape);
      html += '<tr><td>x' + (i + 1) + '</td><td>' + (ok ? (tp.xs[i] * 100).toFixed(2) : '—') + '</td><td>'
        + (i < 5 && okV ? (dx[i] * 100).toFixed(2) : '') + '</td><td>' + (i < 5 ? i + 1 : '') + '</td><td>'
        + (i < 5 ? (okV ? vs[i].v.toFixed(3) : '—') : '') + '</td></tr>';
    }
    $('table').innerHTML = html + '</tbody>';
  }

  // ---------- 读数 ----------
  var lastText = {};
  function setText(id, s) { if (lastText[id] !== s) { lastText[id] = s; $(id).textContent = s; } }
  function rows(list) {
    for (var k = 1; k <= 5; k++) {
      var r = list[k - 1] || ['', ''];
      setText('d' + k, r[0]); setText('r' + k, r[1]);
      $('d' + k).hidden = $('r' + k).hidden = !r[0];
    }
  }

  function readTape() {
    var tp = state.tp, t = state.t.tape, done = t >= tp.tEnd - 1e-9, st = K.tapeAt(tp, t);
    var nDots = tp.dots.filter(function (d) { return d.t <= t + 1e-9; }).length;
    setText('rName', '纸带 · ' + state.hook + ' 个钩码');
    setText('rKind', done ? '打点完成' : state.running ? (state.paused ? '暂停' : '打点中') : '准备');
    var a1 = K.diffMethod(tp.xs), fl = K.fit(K.instV(tp.xs));
    setText('rTip', !t ? '先接通电源，待打点稳定后再释放小车。打点计时器每隔 0.02 s 打一个点。'
      : !done ? '小车越来越快，纸带上相邻两点的间距越来越大。'
      : '相邻计数点间的位移差 Δx 近似相等，说明小车做匀加速直线运动；v-t 图像是一条倾斜的直线，斜率就是加速度。');
    rows([
      ['已打点', nDots + ' 个（' + f((nDots - 1) * K.DOT) + ' s）'],
      ['小车速度', f(st.v, 3) + ' m/s'],
      ['逐差法', done ? 'a = ' + f(a1, 3) + ' m/s²' : '打完后计算'],
      ['图像斜率', done ? 'a ≈ ' + f(fl.k, 3) + ' m/s²' : '打完后计算'],
      ['理论值', 'a = ' + f(tp.a, 3) + ' m/s²' + (tp.ideal ? '' : '（读数有误差）')]
    ]);
  }

  function readVT() {
    var m = state.m, t = state.t.vt, st = m.at(t);
    setText('rName', 'v₀ = ' + f(state.v0, 1) + ' m/s，a = ' + f(state.a, 1) + ' m/s²');
    var kind = state.a === 0 ? (state.v0 ? '匀速直线运动' : '静止') : st.stopped ? '已停止' : st.v === 0 ? '速度为 0' : st.v * state.a > 0 ? (st.v < 0 ? '反向匀加速' : '匀加速') : '匀减速';
    setText('rKind', kind);
    var tip;
    if (state.n) tip = '把运动分成 ' + state.n + ' 小段，每段近似看作匀速：段数越多，矩形面积之和越接近梯形面积——这就是微元法。';
    else if (isFinite(m.tStop)) tip = '刹车问题：汽车 ' + f(m.tStop) + ' s 就停下，之后位移不再增加。求位移前先算停车时间，不能直接把 t 代入 x = v₀t + ½at²。';
    else if (isFinite(m.tTurn)) tip = '速度减到 0 后反向加速，图线穿过 t 轴：t 轴下方的面积表示负方向的位移，位移等于上下面积之差，路程等于两者之和。';
    else tip = 'v-t 图线是倾斜直线，斜率 = 加速度；图线与 t 轴围成的梯形面积 = 位移 x = v₀t + ½at²。';
    setText('rTip', tip);
    rows([
      ['时刻', 't = ' + f(t) + ' s'],
      ['速度', 'v = ' + f(st.v) + ' m/s'],
      ['位移', 'x = ' + f(st.x) + ' m'],
      ['路程', f(m.path(t)) + ' m'],
      ['平均速度', t > 0 ? 'x / t = ' + f(st.x / t) + ' m/s' : '—']
    ]);
  }

  function readRules() {
    var v0 = state.mode === 'ratio' ? 0 : state.rv0, a = state.ra, xs = K.segs(v0, a, RT, RN), t = state.t.rules;
    setText('rName', MODES[state.mode]);
    setText('rKind', 'T = ' + RT + ' s');
    var done = Math.min(RN, Math.floor(t / RT + 1e-9)), part = xs.slice(0, done).map(function (x) { return f(x, 2); });
    if (state.mode === 'ratio') {
      var u = xs[0];
      setText('rTip', '初速度为零：连续相等时间内的位移之比 x₁ : x₂ : x₃ : … = 1 : 3 : 5 : …；前 1T、2T、3T 内的位移之比 1 : 4 : 9 : …；1T、2T、3T 末的速度之比 1 : 2 : 3 : …');
      rows([
        ['各段位移', part.length ? part.join('、') + ' m' : '—'],
        ['比值', part.length ? xs.slice(0, done).map(function (x) { return f(x / u, 1); }).join(' : ') : '—'],
        ['总位移比', part.length ? xs.slice(0, done).map(function (x, i) { return f(Math.pow(i + 1, 2), 0); }).join(' : ') : '—'],
        ['末速度', done ? f(a * done * RT) + ' m/s' : '—']
      ]);
    } else if (state.mode === 'dx') {
      var dx = K.diffs(xs.slice(0, done));
      setText('rTip', '任意两个连续相等时间 T 内的位移之差都相等：Δx = x₂ − x₁ = aT²。纸带上 Δx 近似相等，就能判断物体做匀变速直线运动，并求出 a = Δx / T²。');
      rows([
        ['各段位移', part.length ? part.join('、') + ' m' : '—'],
        ['位移差', dx.length ? dx.map(function (d) { return f(d, 2); }).join('、') + ' m' : '—'],
        ['aT²', f(a * RT * RT, 2) + ' m'],
        ['x₄ − x₁', done >= 4 ? f(xs[3] - xs[0], 2) + ' m = 3aT²' : '—']
      ]);
    } else {
      var tt = Math.min(t, RN * RT), m = K.motion(v0, a, false), v = m.at(tt).v;
      setText('rTip', '匀变速直线运动中，某段时间中间时刻的瞬时速度等于这段时间内的平均速度，也等于初、末速度的平均值；中间位置的速度总大于中间时刻的速度。');
      rows([
        ['时间', 't = ' + f(tt) + ' s'],
        ['平均速度', tt > 0 ? 'x / t = ' + f(m.at(tt).x / tt) + ' m/s' : '—'],
        ['(v₀ + v) / 2', f((v0 + v) / 2) + ' m/s'],
        ['中间时刻', 'v(t/2) = ' + f(m.at(tt / 2).v) + ' m/s'],
        ['中间位置', 'v(x/2) = ' + f(Math.sqrt((v0 * v0 + v * v) / 2)) + ' m/s']
      ]);
    }
  }

  // ---------- 尺寸与主循环 ----------
  function resize() { view.resize(stage.clientWidth, stage.clientHeight); }
  new ResizeObserver(resize).observe(stage);

  // 支持 ?scene=tape|vt|rules；纸带 &hook=1~4、&ideal=1、&done=1（直接打完）、&marks=0、&fit=0；
  // v-t 图像 &v0=-6~10、&a=-4~4、&brake=1、&rect=4|8|16|64、&xt=0；推论 &mode=ratio|dx|mid、&rv0=0~4、&ra=0.5~3；
  // 通用 &slow=1|0.5|0.25、&t=（秒，运动到该时刻后暂停）
  var qs = new URLSearchParams(location.search), x;
  if (HINTS[qs.get('scene')]) state.scene = qs.get('scene');
  x = parseInt(qs.get('hook'), 10); if (x >= 1 && x <= 4) state.hook = x;
  if (qs.get('ideal') === '1') state.ideal = true;
  if (qs.get('marks') === '0') state.marks = false;
  if (qs.get('fit') === '0') state.fit = false;
  x = parseFloat(qs.get('v0')); if (x >= -6 && x <= 10) state.v0 = Math.round(x * 2) / 2;
  x = parseFloat(qs.get('a')); if (x >= -4 && x <= 4) state.a = Math.round(x * 2) / 2;
  if (qs.get('brake') === '1') state.brake = true;
  x = parseInt(qs.get('rect'), 10); if ([4, 8, 16, 64].indexOf(x) >= 0) state.n = x;
  if (qs.get('xt') === '0') state.xt = false;
  if (MODES[qs.get('mode')]) state.mode = qs.get('mode');
  x = parseFloat(qs.get('rv0')); if (x >= 0 && x <= 4) state.rv0 = Math.round(x * 2) / 2;
  x = parseFloat(qs.get('ra')); if (x >= 0.5 && x <= 3) state.ra = Math.round(x * 2) / 2;
  x = parseFloat(qs.get('slow')); if ([1, 0.5, 0.25].indexOf(x) >= 0) state.slows[state.scene] = x;

  rebuildTape(); rebuildVT();
  resize();
  setScene(state.scene);
  x = parseFloat(qs.get('t'));
  if (qs.get('done') === '1' && state.scene === 'tape') finish();
  else if (x > 0) { state.t[state.scene] = Math.min(x, tEnd()); state.running = state.t[state.scene] < tEnd(); state.paused = true; syncUI(); }

  var lastT = performance.now(), lastSync = 0;
  function frame(now) {
    var dt = Math.min((now - lastT) / 1000, 0.1) * state.slows[state.scene], sc = state.scene;
    lastT = now;
    if (state.running && !state.paused) {
      state.t[sc] += dt;
      if (state.t[sc] >= tEnd()) { state.t[sc] = tEnd(); state.running = false; syncUI(); }
      else if (sc === 'tape' && now - lastSync > 120) { lastSync = now; renderTable(); }
    }
    if (sc === 'tape') {
      view.drawTape({ tp: state.tp, t: state.t.tape, marks: state.marks, pts: state.pts, fit: state.fit });
      readTape();
    } else if (sc === 'vt') {
      view.drawVT({ m: state.m, t: state.t.vt, tMax: TMAX, n: state.n, xt: state.xt, ghost: state.ghost, range: vtRange() });
      readVT();
    } else {
      view.drawRules({ mode: state.mode, v0: state.mode === 'ratio' ? 0 : state.rv0, a: state.ra, T0: RT, n: RN, t: state.t.rules });
      readRules();
    }
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // 调试用
  window.__model = {
    state: state, setScene: setScene, syncUI: syncUI, play: play, finish: finish,
    setHook: function (n) { state.hook = K.clamp(Math.round(n), 1, 4); rebuildTape(); syncUI(); },
    setVT: function (v0, a, brake) { state.v0 = v0; state.a = a; state.brake = !!brake; rebuildVT(); syncUI(); },
    setT: function (t) { state.t[state.scene] = K.clamp(t, 0, tEnd()); syncUI(); }
  };
})();
