// 匀变速直线运动：计算模块（不碰 DOM）
// 单位：m、s、m/s、m/s²；位移、速度以向右为正
// ① 纸带：小车由静止被钩码拉动做匀加速运动，打点计时器每 0.02 s 打一个点；每 5 个间隔取一个计数点（T = 0.1 s），
//    量出相邻计数点间的距离 x1…x6，用 vn = (xn + xn+1)/(2T) 求各计数点的瞬时速度，描点作 v-t 图像，斜率即加速度；也可用逐差法
// ② v-t 图像：v = v0 + at，x = v0t + at²/2；图线与 t 轴围成的面积等于位移（t 轴下方为负）；可选“刹车”：速度减到 0 后停止
// ③ 推论：中间时刻速度 = 平均速度、连续相等时间位移差 Δx = aT²、初速度为零的比例 1:3:5…
(function () {
  var G = 9.8;
  var F_HZ = 50, DOT = 1 / F_HZ, PER = 5, T = PER * DOT;   // 打点周期 0.02 s，计数周期 0.1 s
  var N_SEG = 6;                                          // 6 段计数间隔 x1…x6
  var CAR_M = 0.5, HOOK_M = 0.025;                        // 小车 500 g，每个钩码 25 g（已平衡摩擦）
  var BOARD = 1.0, START = 0.12, CAR_L = 0.16;           // 长木板 1 m，小车（长 16 cm）车尾起点离打点计时器 12 cm
  var SKIP = 5;                                           // 舍去开头过于密集的 5 个点，第 6 个点作为计数点 0

  function clamp(x, a, b) { return Math.max(a, Math.min(b, x)); }
  function f(x, n) { n = n == null ? 2 : n; var s = (+x).toFixed(n); return s.indexOf('.') >= 0 ? s.replace(/0+$/, '').replace(/\.$/, '') : s; }
  // 固定种子的伪随机数，让“测量误差”每次一样、可复现
  function rng(seed) { var s = seed >>> 0; return function () { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; }; }

  // ---------- 通用运动 ----------
  // stop：减速到 0 后停止（刹车），否则继续反向加速
  function motion(v0, a, stop) {
    var tStop = stop && v0 * a < 0 ? -v0 / a : Infinity;
    function at(t) {
      var u = Math.min(t, tStop);
      return { t: t, v: t >= tStop ? 0 : v0 + a * t, x: v0 * u + a * u * u / 2, a: t >= tStop ? 0 : a, stopped: t >= tStop };
    }
    // 0..t 内的路程（速度反向时分段）
    function path(t) {
      var u = Math.min(t, tStop), tz = a !== 0 ? -v0 / a : -1;
      if (tz > 0 && tz < u) return Math.abs(at(tz).x) + Math.abs(at(u).x - at(tz).x);
      return Math.abs(at(u).x);
    }
    return { v0: v0, a: a, stop: !!stop, tStop: tStop, tTurn: !stop && a !== 0 && -v0 / a > 0 ? -v0 / a : Infinity, at: at, path: path };
  }

  // 微元法：把 0..t 分成 n 段，每段按起点速度当作匀速，返回矩形面积之和（近似位移）与各矩形
  function rects(m, t, n) {
    var dt = t / n, sum = 0, list = [];
    for (var i = 0; i < n; i++) {
      var v = m.at(i * dt).v;
      list.push({ t0: i * dt, t1: (i + 1) * dt, v: v });
      sum += v * dt;
    }
    return { sum: sum, list: list, exact: m.at(t).x };
  }

  // ---------- ① 纸带 ----------
  function hookAcc(n) { return n * HOOK_M * G / (CAR_M + n * HOOK_M); }

  // n 个钩码；ideal 为 true 时不加读数误差
  function tape(n, ideal) {
    var a = hookAcc(n);
    var tEnd = Math.sqrt(2 * (BOARD - START - CAR_L - 0.04) / a);   // 小车车头到达木板末端的挡板时停下
    var nDots = Math.floor(tEnd / DOT + 1e-9) + 1;
    var dots = [];
    for (var i = 0; i < nDots; i++) dots.push({ t: i * DOT, x: a * Math.pow(i * DOT, 2) / 2 });
    // 计数点：第 SKIP 个点起每 PER 个点取一个
    var cps = [];
    for (var k = 0; k <= N_SEG; k++) cps.push(SKIP + k * PER);
    var r = rng(20 + n * 7), xs = [], xsTrue = [];
    for (k = 0; k < N_SEG; k++) {
      var d = dots[cps[k + 1]].x - dots[cps[k]].x;
      xsTrue.push(d);
      // 毫米刻度尺估读到 0.1 mm（0.01 cm），加 ±0.3 mm 以内的读数误差
      var e = ideal ? 0 : (r() - 0.5) * 0.0006;
      xs.push(Math.round((d + e) * 10000) / 10000);
    }
    return { n: n, a: a, tEnd: tEnd, dots: dots, cps: cps, xs: xs, xsTrue: xsTrue, tC0: dots[cps[0]].t, ideal: !!ideal };
  }

  // 小车（纸带）在 t 时刻的位移
  function tapeAt(tp, t) { t = clamp(t, 0, tp.tEnd); return { x: tp.a * t * t / 2, v: tp.a * t }; }

  // 计数点 1…5 的瞬时速度：vn = (xn + xn+1) / (2T)
  function instV(xs, T0) {
    T0 = T0 || T;
    var out = [];
    for (var i = 0; i + 1 < xs.length; i++) out.push({ k: i + 1, t: (i + 1) * T0, v: (xs[i] + xs[i + 1]) / (2 * T0) });
    return out;
  }
  // 相邻位移差 Δx = x(n+1) − xn
  function diffs(xs) { var out = []; for (var i = 0; i + 1 < xs.length; i++) out.push(xs[i + 1] - xs[i]); return out; }
  // 逐差法：a = [(x4 + x5 + x6) − (x1 + x2 + x3)] / (9T²)
  function diffMethod(xs, T0) {
    T0 = T0 || T;
    var h = xs.length / 2, s1 = 0, s2 = 0;
    for (var i = 0; i < h; i++) { s1 += xs[i]; s2 += xs[i + h]; }
    return (s2 - s1) / (h * h * T0 * T0);
  }
  // 最小二乘拟合 v = k t + b
  function fit(pts) {
    var n = pts.length, st = 0, sv = 0, stt = 0, stv = 0;
    pts.forEach(function (p) { st += p.t; sv += p.v; stt += p.t * p.t; stv += p.t * p.v; });
    var k = (n * stv - st * sv) / (n * stt - st * st);
    return { k: k, b: (sv - k * st) / n };
  }

  // ---------- ③ 推论 ----------
  // 从 v0 开始以 a 运动，n 段相等时间 T0 内的位移
  function segs(v0, a, T0, n) {
    var m = motion(v0, a, false), out = [];
    for (var i = 0; i < n; i++) out.push(m.at((i + 1) * T0).x - m.at(i * T0).x);
    return out;
  }

  window.Kin = {
    G: G, F_HZ: F_HZ, DOT: DOT, PER: PER, T: T, N_SEG: N_SEG, BOARD: BOARD, START: START, CAR_L: CAR_L, SKIP: SKIP,
    CAR_M: CAR_M, HOOK_M: HOOK_M,
    clamp: clamp, f: f, motion: motion, rects: rects,
    hookAcc: hookAcc, tape: tape, tapeAt: tapeAt, instV: instV, diffs: diffs, diffMethod: diffMethod, fit: fit,
    segs: segs
  };
})();
