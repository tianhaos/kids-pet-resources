// 溶解度曲线绘图：左边烧杯（水、溶解的粒子、杯底未溶解的晶体、温度计、加热/冷却），右边溶解度曲线与状态点
(function () {
  var U = window.Solub, SUBS = U.SUBS;
  var PI = Math.PI, TAU = PI * 2;
  var C = { text: '#e6ebf2', muted: '#8d99ab', line: '#2a3446', grid: '#1c2433', panel: '#111723', panel2: '#1a2231', accent: '#ffc94a',
    glass: 'rgba(200,225,255,0.55)', water: 'rgba(79,160,255,0.16)', mercury: '#ff5a5a' };
  var KIND = { unsat: '#7ee081', sat: '#ffc94a', over: '#ff7a59' };
  var KIND_TEXT = { unsat: '不饱和溶液', sat: '恰好饱和', over: '饱和溶液（有固体剩余）' };
  var MAXC = 220, MAXP = 110;

  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
  function rng(seed) {
    return function () {
      seed |= 0; seed = seed + 0x6D2B79F5 | 0;
      var t = Math.imul(seed ^ seed >>> 15, 1 | seed);
      t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
      return ((t ^ t >>> 14) >>> 0) / 4294967296;
    };
  }
  function fmtM(v, small) {
    if (small) return (+v.toFixed(3)).toString();
    return v >= 100 ? v.toFixed(0) : v >= 10 ? v.toFixed(1) : v.toFixed(2).replace(/\.?0+$/, '') || '0';
  }

  // ---------- 杯底晶体堆：每种物质一组固定随机位置，自下而上堆成小丘（单位：晶粒尺寸） ----------
  var pileCache = {};
  function pile(key) {
    if (pileCache[key]) return pileCache[key];
    var r = rng(key.charCodeAt(0) * 977 + key.length * 31), NB = 26, h = [], out = [];
    for (var b = 0; b < NB; b++) h.push(0);
    for (var i = 0; i < MAXC; i++) {
      var u = (r() + r() + r()) / 3, bi = clamp(Math.floor(u * NB), 0, NB - 1);
      var s = 0.75 + r() * 0.5;
      out.push({ x: (bi + r()) / NB * 2 - 1, y: h[bi] + s * 0.45, s: s, a: r() * PI, fy: 0.15 + r() * 0.6, fx: (r() - 0.5) * 1.6 });
      h[bi] += s * 0.62;
      if (bi > 0) h[bi - 1] += s * 0.18;
      if (bi < NB - 1) h[bi + 1] += s * 0.18;
    }
    return (pileCache[key] = out);
  }

  function SolDraw(canvas) {
    var ctx = canvas.getContext('2d');
    var W = 1, H = 1, dpr = 1, narrow = false, gMap = null;
    var ud = 0, shown = 0, born = [], instant = true, parts = [], prnd = rng(7), steam = [], lastKey = '';

    function resize(w, h) {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      W = w; H = h;
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
      canvas.style.width = w + 'px'; canvas.style.height = h + 'px';
      narrow = w < 640;
    }
    function font(size, weight) { ctx.font = (weight || '') + ' ' + size + 'px -apple-system, "PingFang SC", "Microsoft YaHei", sans-serif'; }
    function label(str, x, y, color, align, size, weight, halo) {
      font(size, weight);
      ctx.textAlign = align || 'center'; ctx.textBaseline = 'middle';
      if (halo !== false) { ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(5,7,13,0.85)'; ctx.strokeText(str, x, y); }
      ctx.fillStyle = color; ctx.fillText(str, x, y);
    }
    function line(x0, y0, x1, y1) { ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke(); }
    function rrect(x, y, w, h, r) { ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(x, y, w, h, r); else ctx.rect(x, y, w, h); }
    function arrow(x0, y0, x1, y1, color, lw) {
      ctx.strokeStyle = color; ctx.fillStyle = color; ctx.lineWidth = lw || 1.5;
      line(x0, y0, x1, y1);
      var a = Math.atan2(y1 - y0, x1 - x0), s = 7;
      ctx.beginPath(); ctx.moveTo(x1, y1);
      ctx.lineTo(x1 - s * Math.cos(a - 0.4), y1 - s * Math.sin(a - 0.4));
      ctx.lineTo(x1 - s * Math.cos(a + 0.4), y1 - s * Math.sin(a + 0.4)); ctx.closePath(); ctx.fill();
    }

    // ---------- 布局 ----------
    function layout() {
      var top = narrow ? 84 : 44, bot = 40, side = narrow ? 6 : 18;
      var a = { x: side, y: top, w: W - 2 * side, h: H - top - bot };
      if (a.w >= a.h * 1.2) {
        var bw = Math.min(a.w * 0.36, a.h * 0.78);
        return { cup: { x: a.x, y: a.y, w: bw, h: a.h }, graph: { x: a.x + bw + 14, y: a.y, w: a.w - bw - 14, h: a.h } };
      }
      var gh = Math.round(a.h * 0.6);
      return { graph: { x: a.x, y: a.y, w: a.w, h: gh }, cup: { x: a.x, y: a.y + gh + 6, w: a.w, h: a.h - gh - 6 } };
    }

    // ---------- 烧杯 ----------
    function drawCup(box, st, r, dt) {
      var s = SUBS[st.sub], fs = narrow ? 11 : 12;
      var bh = Math.min(box.h - 70, box.w * 0.95), bw = Math.min(bh * 0.86, box.w * 0.62);
      if (bh < 60) { bh = Math.max(40, box.h - 44); bw = bh * 0.86; }
      var cx = box.x + box.w / 2 - (narrow ? 0 : 6), top = box.y + 28 + (box.h - 70 - bh) * 0.35, bot = top + bh;
      var x0 = cx - bw / 2, x1 = cx + bw / 2, lw = Math.max(1.2, bw / 140);
      // 液面高度 ∝ 水的质量（200 g 约到 85%），溶解的溶质让体积略增
      var lvl = bot - bh * clamp((st.w + r.dissolved * 0.35) / 235, 0.04, 0.93);

      // 冷水浴 / 加热
      if (st.heat < -0.05) {
        ctx.fillStyle = 'rgba(120,190,255,' + (0.1 * Math.min(1, -st.heat)).toFixed(3) + ')';
        rrect(x0 - 14, top + bh * 0.3, bw + 28, bh * 0.7 + 10, 10); ctx.fill();
        label('❄ 冷却', x0 - 8, bot + 14, '#8fd0ff', 'left', fs);
      }
      if (st.heat > 0.05) {
        var fl = Math.min(1, st.heat);
        for (var k = 0; k < 3; k++) {
          var fx = cx + (k - 1) * bw * 0.22, fh = (12 + 5 * Math.sin(st.now * 13 + k * 2)) * fl;
          ctx.fillStyle = 'rgba(255,140,60,' + (0.75 * fl).toFixed(2) + ')';
          ctx.beginPath(); ctx.moveTo(fx - 6, bot + 18); ctx.quadraticCurveTo(fx - 5, bot + 18 - fh * 0.6, fx, bot + 18 - fh);
          ctx.quadraticCurveTo(fx + 5, bot + 18 - fh * 0.6, fx + 6, bot + 18); ctx.closePath(); ctx.fill();
        }
        label('🔥 加热', x0 - 8, bot + 14, '#ffb37a', 'left', fs);
      }
      // 陶土网
      ctx.strokeStyle = '#4a5568'; ctx.lineWidth = 2; line(x0 - 10, bot + 4, x1 + 10, bot + 4);

      // 溶液
      ctx.save();
      ctx.beginPath(); ctx.moveTo(x0, lvl); ctx.lineTo(x0, bot - 6); ctx.quadraticCurveTo(x0, bot, x0 + 6, bot); ctx.lineTo(x1 - 6, bot); ctx.quadraticCurveTo(x1, bot, x1, bot - 6); ctx.lineTo(x1, lvl); ctx.closePath();
      ctx.clip();
      ctx.fillStyle = C.water; ctx.fillRect(x0, lvl, bw, bot - lvl);
      // 石灰水变浑浊
      if (s.small && ud > 1e-4) {
        ctx.fillStyle = 'rgba(235,240,248,' + clamp(ud / 0.12 * 0.55, 0.05, 0.55).toFixed(3) + ')';
        ctx.fillRect(x0, lvl, bw, bot - lvl);
      }
      // 溶解在水中的粒子（示意）
      if (st.micro) drawParticles(st, r, x0, lvl, bw, bot - lvl, dt);
      // 杯底未溶解的固体
      drawPile(st, x0 + 4, bot - 2, bw - 8, lvl, dt);
      ctx.restore();
      ctx.strokeStyle = 'rgba(160,200,255,0.6)'; ctx.lineWidth = 1.2; line(x0, lvl, x1, lvl);

      // 杯壁与刻度
      ctx.strokeStyle = C.glass; ctx.lineWidth = lw * 1.4;
      ctx.beginPath(); ctx.moveTo(x0 - 5, top - 2); ctx.lineTo(x0, top + 4); ctx.lineTo(x0, bot - 6); ctx.quadraticCurveTo(x0, bot, x0 + 6, bot);
      ctx.lineTo(x1 - 6, bot); ctx.quadraticCurveTo(x1, bot, x1, bot - 6); ctx.lineTo(x1, top); ctx.stroke();
      ctx.lineWidth = 1; ctx.strokeStyle = 'rgba(200,225,255,0.35)';
      for (var g = 1; g <= 4; g++) { var gy = bot - bh * g * 50 / 235; line(x0, gy, x0 + (g % 2 ? 8 : 13), gy); }

      // 温度计
      var tx = x1 - bw * 0.16, tTop = top - 22, tBot = bot - bh * 0.1, bulb = 5;
      ctx.fillStyle = 'rgba(230,240,255,0.12)'; ctx.strokeStyle = 'rgba(220,235,255,0.6)'; ctx.lineWidth = 1;
      rrect(tx - 3.5, tTop, 7, tBot - tTop, 3.5); ctx.fill(); ctx.stroke();
      ctx.beginPath(); ctx.arc(tx, tBot, bulb, 0, TAU); ctx.fillStyle = C.mercury; ctx.fill();
      var ty = function (T) { return tBot - 8 - T / 100 * (tBot - 8 - tTop - 8); };
      ctx.fillStyle = C.mercury; ctx.fillRect(tx - 1.5, ty(st.T), 3, tBot - ty(st.T));
      label(st.T.toFixed(0) + ' °C', tx + 9, ty(st.T), '#ff9b8a', 'left', fs + 1, '600');

      // 蒸发的水汽
      if (st.evap > 0 && Math.random() < dt * 14) steam.push({ x: x0 + bw * (0.2 + Math.random() * 0.5), y: lvl, t: 0 });
      steam = steam.filter(function (p) { p.t += dt; return p.t < 1.4; });
      steam.forEach(function (p) {
        ctx.fillStyle = 'rgba(220,230,245,' + (0.35 * (1 - p.t / 1.4)).toFixed(3) + ')';
        ctx.beginPath(); ctx.arc(p.x + Math.sin(p.t * 5 + p.x) * 4, p.y - p.t * 60, 4 + p.t * 6, 0, TAU); ctx.fill();
      });

      // 状态标签与数量
      var kc = KIND[r.kind];
      font(fs + 1, '600');
      var ttl = KIND_TEXT[r.kind], tw = ctx.measureText(ttl).width + 18;
      rrect(cx - tw / 2, top - 26, tw, 22, 11); ctx.fillStyle = 'rgba(17,23,35,0.9)'; ctx.fill(); ctx.strokeStyle = kc; ctx.lineWidth = 1.2; ctx.stroke();
      label(ttl, cx, top - 15, kc, 'center', fs + 1, '600', false);
      if (st.labels) {
        var yy = bot + (st.heat > 0.05 || st.heat < -0.05 ? 32 : 18);
        label('水 ' + fmtM(st.w) + ' g · ' + s.name + '共 ' + fmtM(st.m, s.small) + ' g', cx, yy, C.text, 'center', fs);
        label('已溶解 ' + fmtM(r.dissolved, s.small) + ' g' + (r.undissolved > 0 ? ' · 未溶解 ' + fmtM(r.undissolved, s.small) + ' g' : ' · 还能溶解 ' + fmtM(r.room, s.small) + ' g'), cx, yy + fs + 5, C.muted, 'center', fs);
        if (st.micro && !narrow) label('● 溶解的溶质粒子（示意）', cx, yy + 2 * (fs + 5), s.color, 'center', fs - 1);
      }
    }

    function drawParticles(st, r, x, y, w, h, dt) {
      var s = SUBS[st.sub], FMAX = s.small ? 0.0025 : 0.72;
      var n = Math.round(clamp(r.frac / FMAX, 0, 1) * MAXP);
      while (parts.length < n) parts.push({ x: prnd(), y: prnd(), vx: prnd() - 0.5, vy: prnd() - 0.5 });
      if (parts.length > n) parts.length = n;
      var spd = 0.12 + st.T / 100 * 0.3;
      ctx.fillStyle = s.color; ctx.globalAlpha = 0.75;
      parts.forEach(function (p) {
        p.vx += (prnd() - 0.5) * 2 * dt; p.vy += (prnd() - 0.5) * 2 * dt;
        var v = Math.hypot(p.vx, p.vy) || 1; p.vx *= spd / v; p.vy *= spd / v;
        p.x += p.vx * dt; p.y += p.vy * dt;
        if (p.x < 0.03 || p.x > 0.97) { p.vx = -p.vx; p.x = clamp(p.x, 0.03, 0.97); }
        if (p.y < 0.03 || p.y > 0.97) { p.vy = -p.vy; p.y = clamp(p.y, 0.03, 0.97); }
        ctx.beginPath(); ctx.arc(x + p.x * w, y + p.y * h, 1.7, 0, TAU); ctx.fill();
      });
      ctx.globalAlpha = 1;
    }

    function crystal(shape, x, y, sz, a, color) {
      ctx.save(); ctx.translate(x, y); ctx.rotate(a);
      ctx.fillStyle = 'rgba(240,246,255,0.88)'; ctx.strokeStyle = color; ctx.lineWidth = 0.8;
      ctx.beginPath();
      if (shape === 'cube') ctx.rect(-sz * 0.5, -sz * 0.5, sz, sz);
      else if (shape === 'needle') { ctx.moveTo(-sz * 1.1, 0); ctx.lineTo(-sz * 0.6, -sz * 0.3); ctx.lineTo(sz * 1.1, -sz * 0.1); ctx.lineTo(sz * 0.6, sz * 0.3); ctx.closePath(); }
      else if (shape === 'powder') ctx.arc(0, 0, sz * 0.35, 0, TAU);
      else { ctx.moveTo(0, -sz * 0.6); ctx.lineTo(sz * 0.55, 0); ctx.lineTo(0, sz * 0.6); ctx.lineTo(-sz * 0.55, 0); ctx.closePath(); }
      ctx.fill(); if (shape !== 'powder') ctx.stroke();
      ctx.restore();
    }
    function drawPile(st, x, bot, w, lvl, dt) {
      var s = SUBS[st.sub], ps = pile(st.sub);
      var n = Math.min(MAXC, Math.round(ud / s.grain + (ud > 1e-6 ? 0.5 : 0)));
      var now = st.now;
      if (n > shown) for (var i = shown; i < n; i++) born[i] = instant ? -9 : now;
      shown = n; instant = false;
      var sz = Math.max(4, Math.min(9, w / 26));
      for (i = 0; i < n; i++) {
        var p = ps[i], px = x + w / 2 + p.x * w / 2 * 0.92, py = bot - p.y * sz;
        var age = (now - (born[i] == null ? -9 : born[i])) / 0.9;
        if (age < 1) {
          // 新析出的晶体：从溶液里出现，慢慢沉到杯底
          var sy = lvl + (bot - lvl) * p.fy, e = age * age;
          px += p.fx * sz * (1 - e); py = sy + (py - sy) * e;
        }
        crystal(s.shape, px, py, sz * p.s, p.a + (s.shape === 'needle' ? 0 : 0), s.color);
      }
    }

    // ---------- 溶解度曲线 ----------
    function drawGraph(box, st, r) {
      var s = SUBS[st.sub], fs = narrow ? 11 : 12, small = !!s.small;
      var ml = narrow ? 40 : 48, mr = narrow ? 50 : 64, mt = 22, mb = 34;
      var gx = box.x + ml, gy = box.y + mt, gw = box.w - ml - mr, gh = box.h - mt - mb;
      if (gw < 60 || gh < 60) return;
      var ymax = small ? 0.2 : st.ymax;
      var X = function (T) { return gx + T / 100 * gw; }, Y = function (v) { return gy + gh - v / ymax * gh; };
      gMap = { gx: gx, gy: gy, gw: gw, gh: gh, ymax: ymax, X: X, Y: Y };

      // 网格与坐标轴
      var step = small ? 0.02 : ymax >= 250 ? 25 : ymax >= 100 ? 10 : 5;
      ctx.lineWidth = 1; ctx.strokeStyle = C.grid;
      for (var T = 0; T <= 100; T += 10) line(X(T), gy, X(T), gy + gh);
      for (var v = 0; v <= ymax + 1e-9; v += step) line(gx, Y(v), gx + gw, Y(v));
      ctx.strokeStyle = '#3a4558'; line(gx, gy - 6, gx, gy + gh); line(gx, gy + gh, gx + gw + 8, gy + gh);
      for (T = 0; T <= 100; T += (narrow && gw < 300 ? 20 : 10)) label(String(T), X(T), gy + gh + 11, C.muted, 'center', fs - 1, '', false);
      var lab = small ? 2 : ymax >= 250 ? 2 : 1;
      for (var i = 0; i * step <= ymax + 1e-9; i++) if (i % lab === 0) label(small ? (i * step).toFixed(2) : String(i * step), gx - 6, Y(i * step), C.muted, 'right', fs - 1, '', false);
      label('温度 / °C', gx + gw, gy + gh + 25, C.muted, 'right', fs - 1, '', false);
      label('溶解度 / g' + (small ? '（纵轴放大）' : ''), gx - ml + 2, gy - 12, C.muted, 'left', fs - 1, '', false);

      // 曲线上方 / 下方的含义
      if (st.regions) {
        ctx.save(); ctx.beginPath(); ctx.rect(gx, gy, gw, gh); ctx.clip();
        ctx.beginPath(); ctx.moveTo(X(0), gy);
        for (T = 0; T <= 100; T += 1) ctx.lineTo(X(T), Y(U.S(st.sub, T)));
        ctx.lineTo(X(100), gy); ctx.closePath();
        ctx.fillStyle = 'rgba(255,122,89,0.06)'; ctx.fill();
        ctx.restore();
        var tA = U.trend(st.sub) > 0 ? 12 : 85, tB = U.trend(st.sub) > 0 ? 75 : 15;
        var yA = (Math.min(ymax, ymax) + Math.min(U.S(st.sub, tA), ymax)) / 2, yB = Math.min(U.S(st.sub, tB), ymax) * 0.55;
        label('曲线上方：饱和，且有固体剩余', X(tA), Y(yA), 'rgba(255,150,120,0.75)', U.trend(st.sub) > 0 ? 'left' : 'right', fs - 1);
        label('曲线下方：不饱和', X(tB), Y(yB), 'rgba(126,224,129,0.75)', U.trend(st.sub) > 0 ? 'right' : 'left', fs - 1);
      }

      // 曲线
      ctx.save(); ctx.beginPath(); ctx.rect(gx - 2, gy - 2, gw + 4, gh + 4); ctx.clip();
      st.vis.forEach(function (k) {
        if (!!SUBS[k].small !== small) return;
        var on = k === st.sub;
        ctx.strokeStyle = SUBS[k].color; ctx.lineWidth = on ? 3 : 1.6; ctx.globalAlpha = on ? 1 : 0.6;
        ctx.beginPath();
        for (var T = 0; T <= 100; T += 0.5) { var px = X(T), py = Y(U.S(k, T)); if (T) ctx.lineTo(px, py); else ctx.moveTo(px, py); }
        ctx.stroke();
        if (on && st.points) {
          ctx.fillStyle = SUBS[k].color;
          SUBS[k].data.forEach(function (d, j) { if (d <= ymax) { ctx.beginPath(); ctx.arc(X(j * 10), Y(d), 2.6, 0, TAU); ctx.fill(); } });
        }
      });
      ctx.globalAlpha = 1; ctx.restore();
      // 曲线名称：写在右端，超出顶部的写在出界处
      var used = [];
      st.vis.slice().sort(function (a, b) { return a === st.sub ? 1 : b === st.sub ? -1 : 0; }).forEach(function (k) {
        if (!!SUBS[k].small !== small) return;
        var on = k === st.sub, e = U.S(k, 100), lx, ly, al;
        if (e <= ymax) { lx = X(100) + 5; ly = Y(e); al = 'left'; }
        else { var tt = U.tempOf(k, ymax); lx = X(tt) - 4; ly = gy + 8; al = 'right'; }
        used.forEach(function (u) { if (Math.abs(u.y - ly) < fs + 1 && Math.abs(u.x - lx) < 60) ly = u.y + (ly >= u.y ? fs + 2 : -(fs + 2)); });
        used.push({ x: lx, y: ly });
        label(SUBS[k].name, lx, ly, SUBS[k].color, al, fs, on ? '600' : '');
      });

      var taken = [];
      // 交点：标签按温度排开，挤在一起时依次往下错开，用细线连回交点
      if (st.cross && !small) {
        var xs = [];
        st.vis.forEach(function (k) {
          if (k === st.sub || SUBS[k].small) return;
          U.intersections(st.sub, k).forEach(function (p) { if (p.S <= ymax) xs.push({ k: k, T: p.T, S: p.S, px: X(p.T), py: Y(p.S) }); });
        });
        xs.sort(function (a, b) { return a.T - b.T; });
        xs.forEach(function (p, j) {
          var q = xs[j - 1];
          p.ly = q && p.px - q.px < 150 ? Math.max(p.py + 16, q.ly + fs + 4) : p.py + 16;
          p.lx = p.px + 10;
        });
        xs.forEach(function (p) {
          ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.arc(p.px, p.py, 4.5, 0, TAU); ctx.stroke();
          ctx.setLineDash([2, 3]); ctx.strokeStyle = 'rgba(255,255,255,0.3)'; ctx.lineWidth = 1;
          line(p.px, p.py + 5, p.px, gy + gh); ctx.setLineDash([]);
          if (p.ly - p.py > 20) { ctx.strokeStyle = 'rgba(255,255,255,0.45)'; line(p.px + 3, p.py + 4, p.lx - 2, p.ly - 4); }
        });
        xs.forEach(function (p) {
          font(fs - 1); taken.push({ x0: p.lx, x1: p.lx + ctx.measureText('交点 ' + SUBS[p.k].formula + '：00 °C、00 g').width, y0: p.ly - fs / 2 - 2, y1: p.ly + fs / 2 + 2 });
          label('交点 ' + SUBS[p.k].formula + '：' + p.T.toFixed(0) + ' °C、' + p.S.toFixed(0) + ' g', p.lx, p.ly, SUBS[p.k].color, 'left', fs - 1);
        });
      }

      // 轨迹
      if (st.trail && st.path.length > 1) {
        ctx.strokeStyle = 'rgba(230,235,242,0.45)'; ctx.lineWidth = 1.4; ctx.setLineDash([4, 4]);
        ctx.beginPath();
        st.path.forEach(function (p, j) { var px = X(p.T), py = Y(Math.min(p.y, ymax)); if (j) ctx.lineTo(px, py); else ctx.moveTo(px, py); });
        ctx.stroke(); ctx.setLineDash([]);
        var p0 = st.path[0];
        ctx.fillStyle = 'rgba(230,235,242,0.6)'; ctx.beginPath(); ctx.arc(X(p0.T), Y(Math.min(p0.y, ymax)), 3, 0, TAU); ctx.fill();
      }

      // 当前温度的竖线与各曲线读数
      var tx = X(st.T);
      ctx.setLineDash([3, 4]); ctx.strokeStyle = 'rgba(255,155,138,0.55)'; ctx.lineWidth = 1; line(tx, gy, tx, gy + gh); ctx.setLineDash([]);
      st.vis.forEach(function (k) {
        if (!!SUBS[k].small !== small || k === st.sub) return;
        var v = U.S(k, st.T); if (v > ymax) return;
        ctx.fillStyle = SUBS[k].color; ctx.beginPath(); ctx.arc(tx, Y(v), 3, 0, TAU); ctx.fill();
      });

      // 状态点
      var kc = KIND[r.kind], sy = Y(Math.min(r.S, ymax)), py = Y(Math.min(r.y, ymax)), clipped = r.y > ymax;
      if (r.S <= ymax) {
        ctx.setLineDash([3, 3]); ctx.strokeStyle = 'rgba(255,201,74,0.5)'; line(gx, sy, tx, sy); ctx.setLineDash([]);
        ctx.fillStyle = s.color; ctx.beginPath(); ctx.arc(tx, sy, 4, 0, TAU); ctx.fill();
        // S 标签：依次试右下（或右上）、左边、换到曲线另一侧，选第一个不和交点标签重叠的位置
        var sl = 'S = ' + fmtM(r.S, small) + ' g', d0 = r.kind === 'unsat' ? -12 : 13;
        font(fs, '600');
        var slw = ctx.measureText(sl).width, rightFirst = st.T <= 80;
        var cands = [[rightFirst, d0], [!rightFirst, d0], [!rightFirst, -d0], [rightFirst, -d0]];
        var pick = cands.filter(function (c) {
          var bx0 = c[0] ? tx + 8 : tx - 8 - slw, by = sy + c[1];
          return !taken.some(function (b) { return bx0 < b.x1 && bx0 + slw > b.x0 && by - fs / 2 < b.y1 && by + fs / 2 > b.y0; });
        })[0] || cands[0];
        label(sl, tx + (pick[0] ? 8 : -8), sy + pick[1], s.color, pick[0] ? 'left' : 'right', fs, '600');
      }
      if (r.kind === 'over') {
        // 投入的溶质折算到 100 g 水的位置 → 曲线：多出来的部分没有溶解
        arrow(tx, py + 7, tx, sy - 6, 'rgba(255,122,89,0.9)', 1.5);
        var ux = st.T > 70 ? tx - 10 : tx + 10;
        if (sy - py > 26) label('未溶解 ' + fmtM(r.undissolved, small) + ' g', ux, (py + sy) / 2, KIND.over, st.T > 70 ? 'right' : 'left', fs);
      }
      ctx.beginPath(); ctx.arc(tx, py, 7, 0, TAU);
      ctx.fillStyle = 'rgba(5,7,13,0.85)'; ctx.fill(); ctx.lineWidth = 2.5; ctx.strokeStyle = kc; ctx.stroke();
      ctx.beginPath(); ctx.arc(tx, py, 2.5, 0, TAU); ctx.fillStyle = kc; ctx.fill();
      if (clipped) label('↑ ' + fmtM(r.y, small) + ' g', tx, py + 18, kc, 'center', fs - 1);

      // 温度标在横轴上
      font(fs, '600');
      var tl = st.T.toFixed(0) + ' °C', tlw = ctx.measureText(tl).width + 10;
      rrect(tx - tlw / 2, gy + gh + 2, tlw, 18, 4); ctx.fillStyle = '#3a1f1c'; ctx.fill();
      label(tl, tx, gy + gh + 11, '#ff9b8a', 'center', fs, '600', false);
    }

    function draw(st, r, dt) {
      if (st.sub !== lastKey) { lastKey = st.sub; snap(r); parts = []; }
      ud += (r.undissolved - ud) * (1 - Math.exp(-dt * 3));
      if (Math.abs(r.undissolved - ud) < 1e-5) ud = r.undissolved;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.fillStyle = '#05070d'; ctx.fillRect(0, 0, W, H);
      var L = layout();
      drawCup(L.cup, st, r, dt);
      drawGraph(L.graph, st, r);
    }
    // 不播放析出动画，直接到位（换物质、重置时）
    function snap(r) { ud = r.undissolved; shown = 0; born = []; instant = true; }

    // 画布坐标 → 图像上的 {T, y}；不在图上返回 null
    function graphAt(px, py, loose) {
      if (!gMap) return null;
      var g = gMap, pad = loose ? 30 : 0;
      if (px < g.gx - pad || px > g.gx + g.gw + pad || py < g.gy - pad || py > g.gy + g.gh + pad) return null;
      return { T: clamp((px - g.gx) / g.gw * 100, 0, 100), y: clamp((g.gy + g.gh - py) / g.gh * g.ymax, 0, g.ymax) };
    }
    function yToPx(v) { return gMap ? gMap.Y(v) : 0; }

    return { resize: resize, draw: draw, snap: snap, graphAt: graphAt, yToPx: yToPx };
  }
  SolDraw.KIND = KIND; SolDraw.KIND_TEXT = KIND_TEXT;
  window.SolDraw = SolDraw;
})();
