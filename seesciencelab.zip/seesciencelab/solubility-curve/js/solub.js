// 溶解度计算：几种物质的溶解度数据（人教版九年级下册表 9-1 等，0~100 °C 每 10 °C 一个值），
// 单调三次插值成光滑曲线；给定温度、水和溶质的质量，求溶解了多少、剩多少、饱和与否、溶质质量分数。
// 单位：温度 °C，质量 g；溶解度 S 指 100 g 水中最多溶解的溶质质量。
(function () {
  var TS = [0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100];
  var SUBS = {
    kno3: { name: '硝酸钾', formula: 'KNO₃', color: '#ffc94a', grain: 1.6, shape: 'needle', add: 10,
      data: [13.3, 20.9, 31.6, 45.8, 63.9, 85.5, 110, 138, 169, 202, 246],
      fact: '溶解度受温度影响很大（陡升型），适合用降温结晶（冷却热饱和溶液）得到晶体。' },
    nacl: { name: '氯化钠', formula: 'NaCl', color: '#4fc3f7', grain: 0.7, shape: 'cube', add: 5,
      data: [35.7, 35.8, 36.0, 36.3, 36.6, 37.0, 37.3, 37.8, 38.4, 39.0, 39.8],
      fact: '溶解度受温度影响很小（缓升型），降温几乎不析出晶体，要用蒸发结晶，海水晒盐就是这个道理。' },
    nh4cl: { name: '氯化铵', formula: 'NH₄Cl', color: '#7ee081', grain: 0.9, shape: 'grain', add: 5,
      data: [29.4, 33.3, 37.2, 41.4, 45.8, 50.4, 55.2, 60.2, 65.6, 71.3, 77.3],
      fact: '溶解度随温度升高而增大；溶于水时吸热，溶液温度会降低。' },
    kcl: { name: '氯化钾', formula: 'KCl', color: '#ff8fa3', grain: 0.9, shape: 'cube', add: 5,
      data: [27.6, 31.0, 34.0, 37.0, 40.0, 42.6, 45.5, 48.3, 51.1, 54.0, 56.7],
      fact: '溶解度随温度升高而增大，增大的幅度比硝酸钾小、比氯化钠大。' },
    nano3: { name: '硝酸钠', formula: 'NaNO₃', color: '#ff8a65', grain: 1.6, shape: 'grain', add: 10,
      data: [73, 80, 88, 96, 104, 114, 124, 136, 148, 161, 180],
      fact: '溶解度很大，约 68 °C 时与硝酸钾的溶解度曲线相交，此温度下两者溶解度相等。' },
    caoh2: { name: '氢氧化钙', formula: 'Ca(OH)₂', color: '#c9a7ff', grain: 0.004, shape: 'powder', add: 0.02, small: true,
      data: [0.185, 0.176, 0.165, 0.153, 0.141, 0.128, 0.116, 0.106, 0.094, 0.085, 0.077],
      fact: '微溶于水，溶解度随温度升高反而减小：给饱和石灰水加热，溶液会变浑浊。' }
  };
  var KEYS = ['kno3', 'nacl', 'nh4cl', 'kcl', 'nano3', 'caoh2'];

  // ---------- 单调三次 Hermite 插值（Fritsch–Carlson），保证曲线不出现多余的起伏 ----------
  KEYS.forEach(function (k) {
    var y = SUBS[k].data, n = y.length, h = 10, d = [], m = [];
    for (var i = 0; i < n - 1; i++) d.push((y[i + 1] - y[i]) / h);
    m[0] = d[0]; m[n - 1] = d[n - 2];
    for (i = 1; i < n - 1; i++) m[i] = d[i - 1] * d[i] <= 0 ? 0 : (d[i - 1] + d[i]) / 2;
    for (i = 0; i < n - 1; i++) {
      if (d[i] === 0) { m[i] = m[i + 1] = 0; continue; }
      var a = m[i] / d[i], b = m[i + 1] / d[i], s = a * a + b * b;
      if (s > 9) { var t = 3 / Math.sqrt(s); m[i] = t * a * d[i]; m[i + 1] = t * b * d[i]; }
    }
    SUBS[k].slope = m;
  });

  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }

  // 溶解度 S(T)，g / 100 g 水
  function S(key, T) {
    var s = SUBS[key], y = s.data, m = s.slope;
    T = clamp(T, 0, 100);
    var i = Math.min(9, Math.floor(T / 10)), u = (T - i * 10) / 10, h = 10;
    var u2 = u * u, u3 = u2 * u;
    return (2 * u3 - 3 * u2 + 1) * y[i] + (u3 - 2 * u2 + u) * h * m[i] + (-2 * u3 + 3 * u2) * y[i + 1] + (u3 - u2) * h * m[i + 1];
  }
  // 溶解度随温度升高是增大（1）还是减小（−1）
  function trend(key) { var y = SUBS[key].data; return y[10] > y[0] ? 1 : -1; }
  // 溶解度等于 s 时的温度（不在 0~100 °C 范围内返回 null）
  function tempOf(key, s) {
    var lo = 0, hi = 100, sg = trend(key);
    if ((s - S(key, 0)) * sg < 0 || (s - S(key, 100)) * sg > 0) return null;
    for (var i = 0; i < 50; i++) { var mid = (lo + hi) / 2; if ((S(key, mid) - s) * sg < 0) lo = mid; else hi = mid; }
    return (lo + hi) / 2;
  }
  // 两条溶解度曲线的交点 [{T, S}]
  function intersections(a, b) {
    var out = [], f = function (T) { return S(a, T) - S(b, T); }, prev = f(0);
    for (var T = 0.5; T <= 100 + 1e-9; T += 0.5) {
      var cur = f(T);
      if (prev === 0 || prev * cur < 0) {
        var lo = T - 0.5, hi = T;
        for (var i = 0; i < 40; i++) { var mid = (lo + hi) / 2; if (f(lo) * f(mid) <= 0) hi = mid; else lo = mid; }
        var t = (lo + hi) / 2;
        out.push({ T: t, S: S(a, t) });
      }
      prev = cur;
    }
    return out;
  }

  // 给定温度 T、水 w g、溶质共 m g：溶液的状态
  function solve(key, T, w, m) {
    var s = S(key, T), cap = s * w / 100;           // 这些水最多能溶解的溶质
    var dis = Math.min(m, cap), und = m - dis;
    var tol = Math.max(cap * 0.004, SUBS[key].small ? 1e-5 : 0.02);
    var kind = und > tol ? 'over' : cap - m <= tol ? 'sat' : 'unsat';
    return {
      S: s, cap: cap, dissolved: dis, undissolved: Math.max(0, und),
      kind: kind,                                       // unsat 不饱和 / sat 恰好饱和 / over 饱和且有固体剩余
      room: Math.max(0, cap - m),                       // 还能再溶解多少
      y: w > 0 ? 100 * m / w : 0,                       // 状态点的纵坐标（折算成每 100 g 水）
      solution: w + dis,                                // 溶液质量
      frac: dis / (w + dis),                            // 溶质质量分数
      satFrac: s / (100 + s)                            // 该温度下饱和溶液的溶质质量分数（最大值）
    };
  }

  // 饱和溶液从 T1 变到 T2（水 w g）析出的晶体质量；不析出返回 0
  function crystallize(key, T1, T2, w) {
    return Math.max(0, (S(key, T1) - S(key, T2)) * w / 100);
  }

  // ---------- 读图练习：都用表中整 10 °C 的数据，答案唯一 ----------
  function fmt(v, d) { return (+v.toFixed(d)).toString(); }
  function shuffle(a, rnd) { for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(rnd() * (i + 1)), t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
  function pick(a, rnd) { return a[Math.floor(rnd() * a.length)]; }
  function tab(key, T) { return SUBS[key].data[T / 10]; }
  // 正确答案 + 干扰项（去重、补足 4 个）→ { choices, answer }
  function options(right, wrong, rnd) {
    var list = [right];
    wrong.forEach(function (w) { if (list.indexOf(w) < 0 && list.length < 4) list.push(w); });
    shuffle(list, rnd);
    return { choices: list, answer: list.indexOf(right) };
  }
  var QTYPES = ['read', 'order', 'cryst', 'frac', 'dissolve', 'method'];
  var METHOD = [
    { text: '硝酸钾中混有少量氯化钠，要提纯硝酸钾，应采用的方法是', right: '降温结晶（冷却热饱和溶液）', wrong: ['蒸发结晶', '升高温度', '加水溶解后直接过滤'],
      explain: '硝酸钾的溶解度受温度影响大，氯化钠受温度影响小。配成热的饱和溶液再降温，大量硝酸钾析出，氯化钠仍留在溶液中，过滤即可。', focus: { sub: 'kno3', T: 80, others: ['nacl'] } },
    { text: '氯化钠中混有少量硝酸钾，要提纯氯化钠，应采用的方法是', right: '蒸发结晶', wrong: ['降温结晶（冷却热饱和溶液）', '降低温度后过滤', '加入更多的水'],
      explain: '氯化钠的溶解度受温度影响很小，降温析出很少；蒸发溶剂使氯化钠析出，少量的硝酸钾仍溶解在剩余的溶液里，趁热过滤。', focus: { sub: 'nacl', T: 60, others: ['kno3'] } },
    { text: '要把接近饱和的硝酸钾溶液变成饱和溶液，下列方法中不可行的是', right: '升高温度', wrong: ['加入硝酸钾', '恒温蒸发水', '降低温度'],
      explain: '硝酸钾的溶解度随温度升高而增大，升温后能溶解的更多，溶液离饱和更远。加溶质、蒸发溶剂、降温都能使它变成饱和溶液。', focus: { sub: 'kno3', T: 40 } },
    { text: '要把接近饱和的氢氧化钙溶液（石灰水）变成饱和溶液，下列方法中可行的是', right: '升高温度', wrong: ['降低温度', '加入水', '倒出一部分溶液'],
      explain: '氢氧化钙的溶解度随温度升高而减小，升温后溶解度变小，溶液变成饱和溶液甚至析出固体（变浑浊）。倒出一部分溶液不改变剩下溶液的组成。', focus: { sub: 'caoh2', T: 20 } },
    { text: '将 60 °C 时等质量的硝酸钾、氯化钠饱和溶液都降温到 20 °C，析出晶体较多的是', right: '硝酸钾', wrong: ['氯化钠', '一样多', '都不析出'],
      explain: '60 °C→20 °C，硝酸钾的溶解度从 110 g 降到 31.6 g，氯化钠只从 37.3 g 降到 36.0 g，所以硝酸钾析出的晶体多得多。', focus: { sub: 'kno3', T: 20, others: ['nacl'] } }
  ];
  function quiz(type, rnd) {
    rnd = rnd || Math.random;
    type = QTYPES.indexOf(type) >= 0 ? type : pick(QTYPES, rnd);
    var q, o, k, T, s, nm;
    if (type === 'read') {
      k = pick(['kno3', 'nacl', 'nh4cl', 'kcl', 'nano3'], rnd); T = pick([10, 20, 30, 40, 50, 60, 70, 80], rnd);
      s = tab(k, T); nm = SUBS[k].name;
      var near = [tab(k, T - 10), tab(k, T + 10)], other = KEYS.slice(0, 5).filter(function (x) { return x !== k; }).map(function (x) { return tab(x, T); });
      o = options(s + ' g', near.concat(shuffle(other, rnd)).map(function (v) { return v + ' g'; }), rnd);
      q = { text: T + ' °C 时，' + nm + '的溶解度约为', explain: '在横轴上找到 ' + T + ' °C，向上作垂线与' + nm + '的曲线相交，交点的纵坐标就是溶解度，约 ' + s + ' g，即 ' + T + ' °C 时 100 g 水中最多溶解 ' + s + ' g ' + nm + '。', focus: { sub: k, T: T } };
    } else if (type === 'order') {
      var trio, ok = false;
      while (!ok) {
        trio = shuffle(['kno3', 'nacl', 'nh4cl', 'kcl'], rnd).slice(0, 3); T = pick([0, 10, 40, 50, 60, 70, 80], rnd);
        var v = trio.map(function (x) { return tab(x, T); }).sort(function (a, b) { return a - b; });
        ok = v[1] - v[0] > 1.5 && v[2] - v[1] > 1.5;
      }
      var sorted = trio.slice().sort(function (a, b) { return tab(b, T) - tab(a, T); });
      var str = function (arr) { return arr.map(function (x) { return SUBS[x].name; }).join(' > '); };
      var perms = [[0, 2, 1], [1, 0, 2], [2, 1, 0], [1, 2, 0], [2, 0, 1]].map(function (p) { return str(p.map(function (i) { return sorted[i]; })); });
      o = options(str(sorted), shuffle(perms, rnd), rnd);
      q = { text: T + ' °C 时，' + trio.map(function (x) { return SUBS[x].name; }).join('、') + '三种物质溶解度由大到小的顺序是',
        explain: T + ' °C 时作一条竖直线，与曲线的交点越高溶解度越大：' + sorted.map(function (x) { return SUBS[x].name + ' ' + tab(x, T) + ' g'; }).join('，') + '。',
        focus: { sub: sorted[0], T: T, others: trio } };
    } else if (type === 'cryst') {
      k = pick(['kno3', 'nh4cl', 'kcl'], rnd); nm = SUBS[k].name;
      var w = pick([100, 50], rnd), T1 = pick([50, 60, 70, 80], rnd), T2 = pick([10, 20, 30], rnd);
      var s1 = tab(k, T1), s2 = tab(k, T2), r = (s1 - s2) * w / 100;
      o = options(fmt(r, 2) + ' g', [fmt(s1 - s2, 2), fmt(s1 * w / 100, 2), fmt(s2 * w / 100, 2), fmt((s1 - s2) * 2, 2), fmt(s1, 2), fmt(s2, 2)].map(function (x) { return x + ' g'; }), rnd);
      q = { text: '把 ' + T1 + ' °C 时用 ' + w + ' g 水配成的' + nm + '饱和溶液降温到 ' + T2 + ' °C，析出晶体的质量约为',
        explain: T1 + ' °C 时溶解度 ' + s1 + ' g，' + T2 + ' °C 时 ' + s2 + ' g。' + w + ' g 水中析出 (' + s1 + ' − ' + s2 + ') × ' + w + '/100 = ' + fmt(r, 2) + ' g（水的质量不变，析出后仍是饱和溶液）。',
        focus: { sub: k, T: T2, w: w, m: s1 * w / 100, from: T1 } };
    } else if (type === 'frac') {
      k = pick(['kno3', 'nacl', 'nh4cl', 'kcl'], rnd); T = pick([10, 20, 30, 40, 50, 60], rnd); s = tab(k, T); nm = SUBS[k].name;
      var pct = function (x) { return fmt(x * 100, 1) + '%'; };
      o = options(pct(s / (100 + s)), [pct(Math.min(s / 100, 0.999)), pct(tab(k, T + 10) / (100 + tab(k, T + 10))), pct(tab(k, T - 10) / (100 + tab(k, T - 10))), pct(s / (100 + s) / 2), pct(Math.min(s / 200, 0.999))], rnd);
      q = { text: T + ' °C 时，' + nm + '饱和溶液的溶质质量分数约为（' + T + ' °C 时溶解度 ' + s + ' g）',
        explain: '饱和溶液中溶质质量分数 = S / (100 g + S) × 100% = ' + s + ' / ' + fmt(100 + s, 2) + ' × 100% ≈ ' + pct(s / (100 + s)) + '。注意分母是溶液质量，不是 100 g 水，所以不等于 ' + s + '%。',
        focus: { sub: k, T: T, w: 100, m: s } };
    } else if (type === 'dissolve') {
      k = pick(['kno3', 'nacl', 'nh4cl', 'kcl'], rnd); T = pick([10, 20, 30, 40, 50, 60], rnd); s = tab(k, T); nm = SUBS[k].name;
      var add = Math.round(s / 2 + pick([-8, -5, 5, 10, 15], rnd)); add = Math.max(5, add);
      var dis = Math.min(add, s / 2), sol = 50 + dis;
      o = options(fmt(sol, 2) + ' g', [fmt(50 + add, 2), fmt(50 + s, 2), fmt(add < s / 2 ? 50 + s / 2 : add, 2), fmt(add, 2), fmt(50 + s / 2, 2), fmt(100 + s, 2)].map(function (x) { return x + ' g'; }), rnd);
      q = { text: T + ' °C 时，把 ' + add + ' g ' + nm + '放入 50 g 水中充分溶解，所得溶液的质量为（' + T + ' °C 时溶解度 ' + s + ' g）',
        explain: '50 g 水最多溶解 ' + s + ' × 50/100 = ' + fmt(s / 2, 2) + ' g。' + (add > s / 2 ? '加入 ' + add + ' g，只能溶解 ' + fmt(s / 2, 2) + ' g，剩下 ' + fmt(add - s / 2, 2) + ' g 不溶，得到饱和溶液 ' + fmt(sol, 2) + ' g（没溶解的固体不算溶液的质量）。' : '加入的 ' + add + ' g 能全部溶解，得到不饱和溶液 ' + fmt(sol, 2) + ' g。'),
        focus: { sub: k, T: T, w: 50, m: add } };
    } else {
      var mq = pick(METHOD, rnd);
      o = options(mq.right, shuffle(mq.wrong.slice(), rnd), rnd);
      q = { text: mq.text, explain: mq.explain, focus: mq.focus };
    }
    q.type = type; q.choices = o.choices; q.answer = o.answer;
    return q;
  }

  window.Solub = { SUBS: SUBS, KEYS: KEYS, TS: TS, S: S, trend: trend, tempOf: tempOf, intersections: intersections,
    solve: solve, crystallize: crystallize, clamp: clamp, quiz: quiz, QTYPES: QTYPES };
})();
