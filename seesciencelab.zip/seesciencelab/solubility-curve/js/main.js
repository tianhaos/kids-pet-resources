(function () {
  var U = window.Solub, SUBS = U.SUBS, KEYS = U.KEYS;
  var $ = function (id) { return document.getElementById(id); };
  var qa = function (sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); };
  var YMAX = { kno3: 250, nano3: 250, nacl: 50, kcl: 100, nh4cl: 100, caoh2: 0.2 };

  var state = {
    sub: 'kno3', T: 40, w: 100, m: 50, ymax: 250,
    others: true, cross: true, regions: true, points: false, micro: true, trail: true, labels: true,
    extra: [], vis: [], path: [], heat: 0, evap: 0, now: 0,
    anim: null, msg: '', quiz: null, qType: 'all', score: [0, 0]
  };

  var stage = $('stage'), canvas = $('sol'), panel = $('panel');
  var view = window.SolDraw(canvas), KIND = window.SolDraw.KIND, KIND_TEXT = window.SolDraw.KIND_TEXT;

  function setSeg(attr, val) { qa('[data-' + attr + ']').forEach(function (b) { b.classList.toggle('on', b.dataset[attr] === String(val)); }); }
  function small() { return !!SUBS[state.sub].small; }
  function fm(v) {
    if (small()) return (+v.toFixed(3)).toString();
    return (+v.toFixed(v >= 100 ? 1 : 2)).toString();
  }
  function cur() { return U.solve(state.sub, state.T, state.w, state.m); }
  function sMax(k) { return Math.max(U.S(k, 0), U.S(k, 100)); }
  function mStep() { return small() ? 0.001 : 0.5; }
  function roundM(v) { var s = mStep(); return Math.max(0, Math.round(v / s) * s); }

  // ---------- 一次改变：记下开始时的状态，结束时说明发生了什么 ----------
  var snap0 = null;
  function begin() { if (!snap0) snap0 = { T: state.T, w: state.w, m: state.m, r: cur() }; }
  function end() {
    if (!snap0) return;
    var b = snap0, a = cur(), s = SUBS[state.sub], out = [], tol = small() ? 2e-4 : 0.05;
    snap0 = null;
    if (Math.abs(state.T - b.T) >= 0.5) {
      var up = state.T > b.T;
      out.push((up ? '升高' : '降低') + '温度 ' + b.T.toFixed(0) + ' → ' + state.T.toFixed(0) + ' °C，溶解度' + (a.S > b.r.S ? '增大' : '减小') + '（' + fm(b.r.S) + ' → ' + fm(a.S) + ' g）');
    }
    if (Math.abs(state.w - b.w) >= 0.5) out.push(state.w < b.w ? '恒温蒸发 ' + fm(b.w - state.w) + ' g 水（温度不变，溶解度不变）' : '加入 ' + fm(state.w - b.w) + ' g 水');
    if (Math.abs(state.m - b.m) > tol / 2) out.push(state.m > b.m ? '加入 ' + fm(state.m - b.m) + ' g ' + s.name : '取出 ' + fm(b.m - state.m) + ' g ' + s.name);
    if (!out.length) return;
    var d = a.undissolved - b.r.undissolved;
    if (d > tol) out.push(state.m > b.m + tol / 2
      ? '有 ' + fm(a.undissolved) + ' g 溶不进去，得到饱和溶液'
      : (s.small ? '析出氢氧化钙 ' + fm(d) + ' g，溶液变浑浊' : '析出晶体 ' + fm(d) + ' g' + (state.T < b.T - 0.5 ? '（降温结晶）' : state.w < b.w ? '（蒸发结晶）' : '')));
    else if (d < -tol) out.push('杯底的固体又溶解了 ' + fm(-d) + ' g');
    if (a.kind !== b.r.kind) out.push(b.r.kind === 'unsat' ? '不饱和溶液变成饱和溶液' : a.kind === 'unsat' ? '饱和溶液变成不饱和溶液' : '');
    else if (a.kind === 'unsat') out.push('仍是不饱和溶液');
    state.msg = (state.expIntro ? state.expIntro + '\n' : '') + out.filter(Boolean).join('；') + '。';
    state.expIntro = '';
    syncPanel();
  }
  function pushPath() {
    var y = 100 * state.m / state.w, p = state.path[state.path.length - 1];
    if (!p || Math.abs(p.T - state.T) > 0.3 || Math.abs(p.y - y) > (small() ? 0.0005 : 0.3)) state.path.push({ T: state.T, y: y });
    if (state.path.length > 600) state.path.shift();
  }

  // ---------- 设置状态 ----------
  function setSub(k, keepExtra) {
    if (!SUBS[k]) return;
    var changed = k !== state.sub;
    state.sub = k; state.ymax = YMAX[k];
    if (!keepExtra) state.extra = [];
    if (changed) { state.m = roundM(U.S(k, state.T) * state.w / 100 * 0.7); state.path = []; state.msg = ''; }
    state.anim = null;
    pushPath();
    syncPanel();
  }
  function setT(T, heatDir) {
    T = U.clamp(T, 0, 100);
    if (heatDir !== false && T !== state.T) state.heat = T > state.T ? 1 : -1;
    state.T = T; pushPath();
  }
  function setM(m) { state.m = roundM(U.clamp(m, 0, 1e4)); pushPath(); }
  function setW(w) { state.w = U.clamp(Math.round(w * 10) / 10, 10, 200); pushPath(); }

  // ---------- 动画：慢慢改变温度或蒸发水 ----------
  function animate(key, to, rate) { begin(); state.anim = { key: key, to: to, rate: rate }; }
  function stepAnim(dt) {
    var a = state.anim; if (!a) return;
    var v = state[a.key], d = a.to - v, s = a.rate * dt;
    var nv = Math.abs(d) <= s ? a.to : v + Math.sign(d) * s;
    if (a.key === 'T') setT(nv); else { setW(nv); state.evap = 0.4; }
    if (nv === a.to) { state.anim = null; end(); }
  }

  // ---------- 实验 ----------
  var EXPS = {
    cool: { sub: 'kno3', T: 60, w: 100, m: 110, run: ['T', 20, 8], label: '硝酸钾：冷却热饱和溶液',
      intro: '60 °C 时 100 g 水中溶解 110 g 硝酸钾，恰好饱和。慢慢降温到 20 °C，看析出多少晶体。' },
    nacl: { sub: 'nacl', T: 60, w: 100, m: 37.3, run: ['T', 20, 8], ymax: 50, label: '氯化钠：降温几乎不析出',
      intro: '60 °C 时 100 g 水中溶解 37.3 g 氯化钠，恰好饱和。同样降温到 20 °C，和硝酸钾比一比。' },
    evap: { sub: 'nacl', T: 20, w: 100, m: 36, run: ['w', 50, 20], ymax: 100, label: '氯化钠：蒸发结晶',
      intro: '20 °C 时 100 g 水中溶解 36 g 氯化钠，恰好饱和。保持温度不变，蒸发掉 50 g 水。' },
    lime: { sub: 'caoh2', T: 20, w: 100, m: 0.165, run: ['T', 80, 10], label: '石灰水：加热变浑浊',
      intro: '20 °C 时 100 g 水中溶解 0.165 g 氢氧化钙，恰好饱和。给它加热到 80 °C。' }
  };
  function runExp(id) {
    var e = EXPS[id]; if (!e) return;
    setSub(e.sub);
    state.T = e.T; state.w = e.w; state.m = e.m; state.ymax = e.ymax || YMAX[e.sub];
    state.path = []; pushPath(); view.snap(cur());
    state.msg = e.intro;
    state.expIntro = e.intro;
    animate(e.run[0], e.run[1], e.run[2]);
    syncPanel();
    Analytics.track('溶解度曲线', '实验', e.label);
  }

  // ---------- 控件 ----------
  qa('[data-sub]').forEach(function (b) {
    b.addEventListener('click', function () { setSub(b.dataset.sub); view.snap(cur()); Analytics.track('溶解度曲线', '物质', SUBS[state.sub].name); });
  });
  qa('[data-exp]').forEach(function (b) { b.addEventListener('click', function () { runExp(b.dataset.exp); }); });
  qa('[data-ymax]').forEach(function (b) { b.addEventListener('click', function () { state.ymax = +b.dataset.ymax; syncPanel(); }); });

  function slider(id, fn) {
    var el = $(id);
    el.addEventListener('input', function () { state.anim = null; begin(); fn(+el.value); syncPanel(); });
    el.addEventListener('change', end);
  }
  slider('tR', function (v) { setT(v); });
  slider('wR', function (v) { setW(v); });
  slider('mR', function (v) { setM(v); });

  $('addM').addEventListener('click', function () { state.anim = null; begin(); setM(state.m + SUBS[state.sub].add); end(); });
  $('addW').addEventListener('click', function () { state.anim = null; begin(); setW(state.w + 10); end(); });
  $('evapW').addEventListener('click', function () {
    if (state.w <= 10) return;
    animate('w', Math.max(10, state.w - 10), 12);
    Analytics.track('溶解度曲线', '蒸发');
  });
  $('heatB').addEventListener('click', function () { animate('T', Math.min(100, state.T + 20), 10); });
  $('coolB').addEventListener('click', function () { animate('T', Math.max(0, state.T - 20), 10); });
  $('clearPath').addEventListener('click', function () { state.path = []; pushPath(); });

  [['others', 'others'], ['cross', 'cross'], ['regions', 'regions'], ['points', 'points'], ['micro', 'micro'], ['trail', 'trail'], ['labels', 'labels']].forEach(function (p) {
    $(p[0]).checked = state[p[1]];
    $(p[0]).addEventListener('change', function () { state[p[1]] = $(p[0]).checked; syncPanel(); });
  });

  document.addEventListener('keydown', function (e) {
    if (/INPUT|SELECT|TEXTAREA|BUTTON/.test(e.target.tagName)) return;
    var k = { ArrowLeft: -1, ArrowRight: 1 }[e.key];
    if (k) { e.preventDefault(); state.anim = null; begin(); setT(state.T + k); syncPanel(); clearTimeout(keyT); keyT = setTimeout(end, 500); }
  });
  var keyT = 0;

  // ---------- 在图像上拖动状态点：左右改温度，上下改溶质的量 ----------
  var drag = false;
  function pointAt(e) {
    var rc = canvas.getBoundingClientRect(), px = e.clientX - rc.left, py = e.clientY - rc.top;
    var g = view.graphAt(px, py, drag);
    if (!g) return false;
    var T = Math.round(g.T), y = g.y, S = U.S(state.sub, T);
    if (Math.abs(view.yToPx(S) - py) < 7) y = S;      // 靠近曲线时吸附到曲线上：恰好饱和
    setT(T); setM(y * state.w / 100);
    return true;
  }
  canvas.addEventListener('pointerdown', function (e) {
    state.anim = null; begin();
    if (pointAt(e)) { drag = true; canvas.setPointerCapture(e.pointerId); syncPanel(); }
    else snap0 = null;
  });
  canvas.addEventListener('pointermove', function (e) { if (drag) { pointAt(e); syncPanel(); } });
  function up() { if (drag) { drag = false; end(); Analytics.track('溶解度曲线', '拖动状态点', SUBS[state.sub].name); } }
  canvas.addEventListener('pointerup', up);
  canvas.addEventListener('pointercancel', up);

  // ---------- 读图练习 ----------
  function newQuiz() {
    var q = U.quiz(state.qType === 'all' ? null : state.qType);
    state.quiz = { q: q, picked: -1 };
    renderQuiz();
  }
  function renderQuiz() {
    var z = state.quiz;
    if (!z) { $('qText').textContent = '点“出一道题”开始。看图回答，答完模型会跳到题目说的状态。'; $('qChoices').innerHTML = ''; $('qExplain').textContent = ''; return; }
    var q = z.q;
    $('qText').textContent = q.text + '（　　）';
    $('qChoices').innerHTML = q.choices.map(function (c, i) {
      var cls = z.picked < 0 ? '' : i === q.answer ? ' right' : i === z.picked ? ' wrong' : '';
      return '<button data-ch="' + i + '" class="' + cls + '"' + (z.picked >= 0 ? ' disabled' : '') + '>' + 'ABCD'[i] + '. ' + c + '</button>';
    }).join('');
    $('qExplain').textContent = z.picked < 0 ? '' : (z.picked === q.answer ? '✔ 正确。' : '✘ 正确答案是 ' + 'ABCD'[q.answer] + '。') + q.explain;
    $('qScore').textContent = state.score[1] ? '答对 ' + state.score[0] + ' / ' + state.score[1] : '';
    qa('[data-ch]').forEach(function (b) { b.addEventListener('click', function () { answer(+b.dataset.ch); }); });
  }
  function answer(i) {
    var z = state.quiz; if (!z || z.picked >= 0) return;
    z.picked = i; state.score[1]++; if (i === z.q.answer) state.score[0]++;
    renderQuiz();
    Analytics.track('溶解度曲线', '练习', z.q.type + (i === z.q.answer ? ' 对' : ' 错'));
    // 让模型显示题目说的状态
    var f = z.q.focus;
    setSub(f.sub, true);
    state.extra = f.others || [];
    state.w = f.w || 100;
    if (f.from != null) { state.T = f.from; state.m = f.m; state.path = []; pushPath(); view.snap(cur()); animate('T', f.T, 10); }
    else {
      state.T = f.T;
      state.m = f.m != null ? f.m : roundM(U.S(f.sub, f.T) * state.w / 100);
      state.path = []; pushPath(); view.snap(cur()); state.msg = '';
    }
    syncPanel();
  }
  $('qNew').addEventListener('click', newQuiz);
  $('qType').addEventListener('change', function () { state.qType = $('qType').value; newQuiz(); });

  // ---------- 面板 ----------
  function visible() {
    var sm = small();
    var v = KEYS.filter(function (k) { return !!SUBS[k].small === sm && (k === state.sub || state.others || state.extra.indexOf(k) >= 0); });
    state.vis = v;
  }
  var lastSig = '';
  function syncPanel() {
    visible();
    var s = SUBS[state.sub], r = cur(), sm = small();
    setSeg('sub', state.sub);
    setSeg('ymax', sm ? '' : state.ymax);
    qa('[data-ymax]').forEach(function (b) { b.disabled = sm; });
    $('others').disabled = sm; $('cross').disabled = sm;

    var tR = $('tR'), wR = $('wR'), mR = $('mR');
    tR.value = state.T; $('tO').textContent = state.T.toFixed(0) + ' °C';
    wR.value = state.w; $('wO').textContent = fm(state.w) + ' g';
    var mMax = sm ? 0.4 : Math.ceil(sMax(state.sub) * state.w / 100 * 1.25 / 10) * 10;
    mR.max = Math.max(mMax, state.m); mR.step = mStep(); mR.value = state.m;
    $('mO').textContent = fm(state.m) + ' g';
    $('mLabel').textContent = s.name;
    $('addM').textContent = '+ ' + s.add + ' g ' + s.name;

    $('rName').textContent = s.name;
    $('rFormula').textContent = s.formula;
    $('rKind').textContent = KIND_TEXT[r.kind];
    $('rKind').style.color = KIND[r.kind];
    $('rS').textContent = fm(r.S) + ' g（' + state.T.toFixed(0) + ' °C 时 100 g 水最多溶解 ' + fm(r.S) + ' g）';
    $('rDis').textContent = fm(r.dissolved) + ' g' + (r.undissolved > 0 ? '，未溶解 ' + fm(r.undissolved) + ' g' : r.kind === 'unsat' ? '，还能再溶解 ' + fm(r.room) + ' g' : '');
    $('rSol').textContent = fm(r.solution) + ' g' + (r.undissolved > 0 ? '（未溶解的固体不算）' : '');
    $('rFrac').textContent = (r.frac * 100).toFixed(sm ? 3 : 1) + '%' + (r.kind !== 'unsat' ? '（饱和，此温度下最大）' : '（饱和时可达 ' + (r.satFrac * 100).toFixed(sm ? 3 : 1) + '%）');
    $('rMsg').textContent = state.msg;
    $('rFact').textContent = '💡 ' + s.fact;

    // 当前温度下各物质的溶解度
    var sig = state.T + '|' + state.sub;
    if (sig !== lastSig) {
      lastSig = sig;
      $('sTable').innerHTML = '<tr><th>物质</th><th>' + state.T.toFixed(0) + ' °C 时溶解度</th><th>变化</th></tr>' + KEYS.map(function (k) {
        var x = SUBS[k], v = U.S(k, state.T);
        return '<tr' + (k === state.sub ? ' class="on"' : '') + '><td><i class="sw" style="background:' + x.color + '"></i>' + x.name + '</td><td>' +
          (x.small ? (+v.toFixed(3)) : (+v.toFixed(1))) + ' g</td><td>' + (k === 'kno3' || k === 'nano3' ? '陡升' : k === 'nacl' ? '缓升' : x.small ? '下降' : '上升') + '</td></tr>';
      }).join('');
    }
  }

  // ---------- 面板开合 ----------
  $('panelToggle').addEventListener('click', function () { panel.classList.toggle('collapsed'); });
  if (window.matchMedia('(max-width: 760px)').matches) panel.classList.add('collapsed');
  if (window.matchMedia('(max-width: 640px)').matches) $('hint').hidden = true;

  // ---------- 尺寸与主循环 ----------
  function resize() { view.resize(stage.clientWidth, stage.clientHeight); }
  new ResizeObserver(resize).observe(stage);
  resize();

  // 支持 ?sub=kno3|nacl|nh4cl|kcl|nano3|caoh2、&t=温度、&w=水、&m=溶质、&ymax=250|100|50、&exp=cool|nacl|evap|lime、
  // &others=0、&cross=0、&quiz=all|read|order|cryst|frac|dissolve|method
  var qs = new URLSearchParams(location.search);
  if (SUBS[qs.get('sub')]) setSub(qs.get('sub'));
  if (qs.has('t')) state.T = U.clamp(+qs.get('t') || 0, 0, 100);
  if (qs.has('w')) state.w = U.clamp(+qs.get('w') || 100, 10, 200);
  if (qs.has('m')) state.m = Math.max(0, +qs.get('m') || 0);
  if ({ 250: 1, 100: 1, 50: 1 }[qs.get('ymax')]) state.ymax = +qs.get('ymax');
  ['others', 'cross'].forEach(function (k) { if (qs.get(k) === '0') { state[k] = false; $(k).checked = false; } });
  state.path = []; pushPath();
  syncPanel();
  view.snap(cur());
  if (EXPS[qs.get('exp')]) runExp(qs.get('exp'));
  if (qs.has('quiz')) {
    var qt = qs.get('quiz');
    if (U.QTYPES.indexOf(qt) >= 0) { state.qType = qt; $('qType').value = qt; }
    newQuiz();
    panel.classList.remove('collapsed');
    setTimeout(function () { panel.scrollTop += $('quizSec').getBoundingClientRect().top - panel.getBoundingClientRect().top - 8; }, 50);
  } else renderQuiz();

  var lastT = performance.now();
  function frame(t) {
    var dt = Math.max(0, Math.min((t - lastT) / 1000, 0.1));
    lastT = t;
    state.now += dt;
    stepAnim(dt);
    if (state.anim) syncPanel();
    state.heat *= Math.exp(-dt * (state.anim ? 0.5 : 2.2));
    state.evap = Math.max(0, state.evap - dt);
    view.draw(state, cur(), dt);
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // 调试用
  window.__model = { state: state, view: view, U: U, setSub: setSub, setT: setT, setM: setM, setW: setW, runExp: runExp, newQuiz: newQuiz, answer: answer };
})();
