// 开普勒三定律的计算：椭圆轨道几何、开普勒方程求位置与速度、等时间扇形、各中心天体的卫星数据与 a³/T²、练习题
// 轨道坐标：中心天体在原点（椭圆的一个焦点），近日点在 +x、远日点在 −x，逆时针绕行，椭圆中心在 (−c, 0)
// 场景一、二以太阳为中心天体：单位 AU、年，GM = 4π² AU³/年²，所以 T = a^1.5（年）。不碰 DOM
(function () {
  var TAU = Math.PI * 2, DEG = Math.PI / 180;
  var GM = TAU * TAU;                        // 太阳，AU³/年²
  var AU_KM = 1.495978707e8, YR_S = 3.15576e7, DAY_S = 86400;
  var KMS = AU_KM / YR_S;                    // 1 AU/年 ≈ 4.74 km/s
  var A_RANGE = [0.3, 40], E_RANGE = [0, 0.97];

  function clamp(x, a, b) { return Math.max(a, Math.min(b, x)); }
  function f(x, d) {
    if (d == null) d = Math.abs(x) >= 100 ? 0 : Math.abs(x) >= 10 ? 1 : 2;
    var s = x.toFixed(d);
    s = s.indexOf('.') >= 0 ? s.replace(/\.?0+$/, '') : s;
    return s === '-0' ? '0' : s;
  }
  // 有效数字（读数表格用）
  function sig(x, n) {
    if (x === 0) return '0';
    var d = Math.max(0, (n || 3) - 1 - Math.floor(Math.log10(Math.abs(x))));
    return f(x, Math.min(d, 6));
  }
  // 科学计数法：3.36 × 10¹⁸
  var SUP = '⁰¹²³⁴⁵⁶⁷⁸⁹';
  function sci(x, n) {
    var p = Math.floor(Math.log10(Math.abs(x))), m = x / Math.pow(10, p);
    if (Math.abs(m) >= 9.995) { m /= 10; p++; }
    var e = String(Math.abs(p)).split('').map(function (c) { return SUP[+c]; }).join('');
    return m.toFixed((n || 3) - 1) + ' × 10' + (p < 0 ? '⁻' : '') + e;
  }
  // 时长：不到 1 年显示天
  function dur(yr) { return yr < 1 ? f(yr * 365.25, yr * 365.25 < 10 ? 1 : 0) + ' 天' : f(yr, yr < 10 ? 2 : 1) + ' 年'; }

  // ---------- 椭圆轨道（太阳为中心天体） ----------
  function period(a) { return Math.pow(a, 1.5); }
  // 活力公式 v² = GM(2/r − 1/a)
  function vis(a, r, gm) { return Math.sqrt((gm || GM) * (2 / r - 1 / a)); }
  function geom(a, e) {
    var c = a * e, b = a * Math.sqrt(1 - e * e);
    return {
      a: a, b: b, c: c, e: e, rp: a - c, ra: a + c, T: period(a),
      area: Math.PI * a * b,                       // 椭圆面积
      vp: vis(a, a - c), va: vis(a, a + c)         // 近日点、远日点速率（AU/年），vp·rp = va·ra
    };
  }
  // 开普勒方程 E − e·sinE = M（牛顿迭代）
  function solveE(M, e) {
    M = ((M % TAU) + TAU) % TAU;
    var E = e < 0.8 ? M : Math.PI;
    for (var i = 0; i < 50; i++) {
      var d = (E - e * Math.sin(E) - M) / (1 - e * Math.cos(E));
      E -= d;
      if (Math.abs(d) < 1e-13) break;
    }
    return E;
  }
  // 平近点角 M（= 2π·t/T，从近日点起）时的位置与速度；gm 缺省为太阳
  function at(a, e, M, gm) {
    var E = solveE(M, e), b = a * Math.sqrt(1 - e * e), cE = Math.cos(E), sE = Math.sin(E);
    var x = a * (cE - e), y = b * sE, r = a * (1 - e * cE);
    var n = Math.sqrt((gm || GM) / (a * a * a)), dE = n / (1 - e * cE);
    var vx = -a * sE * dE, vy = b * cE * dE;
    return { M: ((M % TAU) + TAU) % TAU, E: E, nu: Math.atan2(y, x), x: x, y: y, r: r, vx: vx, vy: vy, v: Math.hypot(vx, vy) };
  }
  // 由真近点角（从太阳看的方向）求平近点角，拖动行星用
  function mOfNu(nu, e) {
    var E = 2 * Math.atan2(Math.sqrt(1 - e) * Math.sin(nu / 2), Math.sqrt(1 + e) * Math.cos(nu / 2));
    return (((E - e * Math.sin(E)) % TAU) + TAU) % TAU;
  }
  // 行星与太阳的连线从 M0 扫到 M1 扫过的扇形：多边形顶点，首点是太阳
  function sector(a, e, M0, M1, n) {
    n = n || 48;
    var pts = [{ x: 0, y: 0 }];
    for (var i = 0; i <= n; i++) { var s = at(a, e, M0 + (M1 - M0) * i / n); pts.push({ x: s.x, y: s.y }); }
    return pts;
  }
  // 扇形面积按第二定律 = πab·Δt/T；多边形面积用于验证
  function sectorArea(a, e, dM) { return Math.PI * a * a * Math.sqrt(1 - e * e) * dM / TAU; }
  function polyArea(pts) {
    var s = 0;
    for (var i = 0; i < pts.length; i++) { var p = pts[i], q = pts[(i + 1) % pts.length]; s += p.x * q.y - q.x * p.y; }
    return Math.abs(s) / 2;
  }
  // 椭圆上的弧长（数值积分），比较等时间内走过的路程
  function arcLen(a, e, M0, M1, n) {
    n = n || 60;
    var L = 0, p = at(a, e, M0);
    for (var i = 1; i <= n; i++) { var q = at(a, e, M0 + (M1 - M0) * i / n); L += Math.hypot(q.x - p.x, q.y - p.y); p = q; }
    return L;
  }

  // ---------- 第三定律：各中心天体的环绕天体 ----------
  // a、T 的单位见 aUnit / tUnit，toM / toS 把它们换成 m、s；e 偏心率，w 近日点经度（°），L0 J2000 平黄经（°），用于初始位置
  var SYSTEMS = {
    sun: {
      name: '太阳', what: '八大行星', aUnit: 'AU', tUnit: '年', toM: AU_KM * 1e3, toS: YR_S, inner: 4,
      bodies: [
        { name: '水星', a: 0.3871, T: 0.2408, e: 0.2056, w: 77.46, L0: 252.25, color: '#b8b1a6' },
        { name: '金星', a: 0.7233, T: 0.6152, e: 0.0068, w: 131.53, L0: 181.98, color: '#e8c27a' },
        { name: '地球', a: 1.0000, T: 1.0000, e: 0.0167, w: 102.94, L0: 100.46, color: '#4fc3f7' },
        { name: '火星', a: 1.5237, T: 1.8809, e: 0.0934, w: 336.04, L0: 355.45, color: '#ff7a59' },
        { name: '木星', a: 5.2034, T: 11.862, e: 0.0484, w: 14.75, L0: 34.40, color: '#d9a066' },
        { name: '土星', a: 9.5371, T: 29.457, e: 0.0539, w: 92.43, L0: 49.94, color: '#e6d18b' },
        { name: '天王星', a: 19.191, T: 84.011, e: 0.0473, w: 170.96, L0: 313.23, color: '#8fe3e0' },
        { name: '海王星', a: 30.069, T: 164.79, e: 0.0086, w: 44.97, L0: 304.88, color: '#6f86ff' }
      ],
      custom: [0.2, 40, 2.5]
    },
    jupiter: {
      name: '木星', what: '伽利略卫星', aUnit: '万 km', tUnit: '天', toM: 1e7, toS: DAY_S, inner: 4, R: 7.149,
      bodies: [
        { name: '木卫一', a: 42.17, T: 1.769, e: 0.004, w: 0, L0: 30, color: '#e8c27a' },
        { name: '木卫二', a: 67.11, T: 3.551, e: 0.009, w: 0, L0: 140, color: '#cfd6e2' },
        { name: '木卫三', a: 107.04, T: 7.155, e: 0.001, w: 0, L0: 250, color: '#b8a58c' },
        { name: '木卫四', a: 188.27, T: 16.689, e: 0.007, w: 0, L0: 330, color: '#8d99ab' }
      ],
      custom: [30, 250, 150]
    },
    earth: {
      name: '地球', what: '月球与人造卫星', aUnit: '万 km', tUnit: '天', toM: 1e7, toS: DAY_S, inner: 3, R: 0.6371,
      bodies: [
        { name: '空间站', a: 0.6784, T: 0.06436, e: 0.0005, w: 0, L0: 20, color: '#cfd6e2' },
        { name: 'GPS 卫星', a: 2.656, T: 0.4986, e: 0.01, w: 0, L0: 160, color: '#7ee081' },
        { name: '同步卫星', a: 4.216, T: 0.9973, e: 0, w: 0, L0: 270, color: '#f4a3d0' },
        { name: '月球', a: 38.44, T: 27.32, e: 0.0549, w: 0, L0: 60, color: '#e6ebf2' }
      ],
      custom: [0.7, 45, 10]
    }
  };
  // 各中心天体的 k = a³/T²（以第一个环绕天体为准；月球质量约为地球的 1/81，a³/T² 略大）
  function kOf(sys) { var b = sys.bodies[0]; return b.a * b.a * b.a / (b.T * b.T); }
  function kSI(sys, k) { return (k == null ? kOf(sys) : k) * Math.pow(sys.toM, 3) / (sys.toS * sys.toS); }
  // 由 a³/T² = k 求周期
  function periodK(a, k) { return Math.sqrt(a * a * a / k); }
  // t 时刻（单位 tUnit）环绕天体 b 的位置（中心天体为原点，x 轴指向春分点方向，已按近日点经度旋转）
  function bodyAt(b, t) {
    var M = (b.L0 - b.w) * DEG + TAU * t / b.T, a = b.a;
    var s = at(a, b.e, M, TAU * TAU * a * a * a / (b.T * b.T)), w = b.w * DEG, c = Math.cos(w), sn = Math.sin(w);
    return { x: s.x * c - s.y * sn, y: s.x * sn + s.y * c, r: s.r };
  }

  // ---------- 练习 ----------
  var TYPES = ['speed', 'period', 'concept'];
  function pick(rand, a) { return a[Math.floor(rand() * a.length)]; }
  function shuffle(rand, a) {
    a = a.slice();
    for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(rand() * (i + 1)), t = a[i]; a[i] = a[j]; a[j] = t; }
    return a;
  }
  function uniq(a) { return a.filter(function (x, i) { return a.indexOf(x) === i; }); }
  function options(rand, answer, pool, n) {
    var rest = shuffle(rand, uniq(pool).filter(function (o) { return o !== answer; })).slice(0, (n || 4) - 1);
    return shuffle(rand, rest.concat([answer]));
  }

  // 第二定律：近日点、远日点速率之比 / 速率变化
  var RPA = [[1, 2], [1, 3], [2, 3], [2, 5], [3, 5], [1, 4], [3, 4]];
  function quizSpeed(rand) {
    var sub = pick(rand, ['ratio', 'ratio', 'trend', 'earth']);
    if (sub === 'ratio') {
      var p = pick(rand, RPA), rp = p[0], ra = p[1], vp = ra * pick(rand, [6, 8, 10, 12]);
      var va = vp * rp / ra, u = ' km/s';
      var ans = f(va) + u;
      return { type: 'speed', sub: sub, rp: rp, ra: ra, vp: vp, answer: ans,
        options: options(rand, ans, [vp * ra / rp, vp, vp * Math.sqrt(rp / ra), vp * rp * rp / (ra * ra), vp * (ra - rp) / ra].map(function (x) { return f(x) + u; })),
        prompt: '某行星绕太阳沿椭圆轨道运动，近日点到太阳的距离为 ' + rp + 'r、远日点为 ' + ra + 'r，经过近日点时速率为 ' + vp + ' km/s，经过远日点时速率为？',
        explain: '由开普勒第二定律，在近日点和远日点附近取极短时间 Δt，扫过的面积近似为三角形：½·v_p·Δt·r_p = ½·v_a·Δt·r_a，所以 v_a = v_p·r_p/r_a = ' + vp + ' × ' + rp + '/' + ra + ' = ' + ans + '。（只在近日点、远日点速度与连线垂直时才能这样写）' };
    }
    if (sub === 'trend') {
      var to = rand() < 0.5;
      var ans2 = to ? '逐渐减小' : '逐渐增大';
      return { type: 'speed', sub: sub, toAph: to, answer: ans2, options: shuffle(rand, ['逐渐增大', '逐渐减小', '先增大后减小', '大小不变']),
        prompt: '行星沿椭圆轨道从' + (to ? '近日点运动到远日点' : '远日点运动到近日点') + '的过程中，速率怎样变化？',
        explain: '相等时间内与太阳连线扫过的面积相等，离太阳越远，同样的面积对应的弧长越短，所以离太阳越远速率越小。从' + (to ? '近日点到远日点，距离增大，速率' : '远日点到近日点，距离减小，速率') + ans2 + '（太阳引力与速度成' + (to ? '钝角，做负功' : '锐角，做正功') + '）。' };
    }
    var ans3 = '1 月初快';
    return { type: 'speed', sub: sub, answer: ans3, options: shuffle(rand, ['1 月初快', '7 月初快', '一样快', '春分、秋分时最快']),
      prompt: '地球每年 1 月初经过近日点、7 月初经过远日点。地球公转的速率在 1 月初和 7 月初相比？',
      explain: '近日点离太阳近，由开普勒第二定律，速率最大（约 30.3 km/s）；远日点速率最小（约 29.3 km/s）。所以 1 月初地球公转得快，这也是北半球冬半年比夏半年短几天的原因。' };
  }

  // 第三定律：周期之比 / 求周期 / 由周期求半长轴
  var AR = [[1, 4, '1 : 8'], [4, 1, '8 : 1'], [1, 9, '1 : 27'], [1, 16, '1 : 64'], [9, 4, '27 : 8'], [1, 2, '1 : 2√2']];
  var AY = [[4, 8], [9, 27], [16, 64], [0.25, 0.125], [100, 1000], [2.25, 3.375]];
  function quizPeriod(rand) {
    var sub = pick(rand, ['ratio', 'year', 'year', 'halley']), ans;
    if (sub === 'ratio') {
      var r = pick(rand, AR);
      ans = r[2];
      return { type: 'period', sub: sub, a1: r[0], a2: r[1], answer: ans,
        options: options(rand, ans, [r[0] + ' : ' + r[1], (r[0] * r[0]) + ' : ' + (r[1] * r[1]), sq(r[0]) + ' : ' + sq(r[1]), (r[0] * r[0] * r[0]) + ' : ' + (r[1] * r[1] * r[1]), r[2]]),
        prompt: '两颗行星绕太阳运动，轨道半长轴之比 a₁ : a₂ = ' + r[0] + ' : ' + r[1] + '，它们的公转周期之比 T₁ : T₂ = ？',
        explain: '由开普勒第三定律 a³/T² = k，同一中心天体 k 相同，所以 T₁/T₂ = (a₁/a₂)^(3/2) = (' + r[0] + '/' + r[1] + ')^(3/2)，T₁ : T₂ = ' + ans + '。半长轴越大，周期越长，而且比半长轴增长得更快。' };
    }
    if (sub === 'year') {
      var y = pick(rand, AY);
      ans = f(y[1], 3) + ' 年';
      return { type: 'period', sub: sub, a: y[0], answer: ans,
        options: options(rand, ans, [y[0], y[0] * y[0], Math.sqrt(y[0]), Math.pow(y[0], 2 / 3), y[1] * 2].map(function (x) { return f(x, 3) + ' 年'; })),
        prompt: '某小行星绕太阳运动的轨道半长轴是地球公转轨道半径（1 AU）的 ' + f(y[0], 2) + ' 倍，它绕太阳一周需要多长时间？',
        explain: '与地球比较，中心天体都是太阳：a³/T² = (1 AU)³/(1 年)²，所以 T = (a/1 AU)^(3/2) 年 = ' + f(y[0], 2) + '^(3/2) 年 = ' + ans + '。' };
    }
    ans = '约 18 AU';
    return { type: 'period', sub: sub, answer: ans, options: shuffle(rand, ['约 8.7 AU', '约 18 AU', '约 38 AU', '约 76 AU']),
      prompt: '哈雷彗星绕太阳运行的周期约为 76 年，它的轨道半长轴约为多少？（地球公转轨道半径为 1 AU，76^(2/3) ≈ 18）',
      explain: '与地球比较：a³/T² 相同，a = (T/1 年)^(2/3) AU = 76^(2/3) AU ≈ 18 AU。哈雷彗星的偏心率约 0.97，近日点只有约 0.6 AU，远日点约 35 AU，在海王星轨道之外。' };
  }
  function sq(n) { var s = Math.sqrt(n); return Math.abs(s - Math.round(s)) < 1e-9 ? String(Math.round(s)) : '√' + n; }

  // 概念辨析
  var CONCEPTS = [
    { id: 'shape', q: '关于行星绕太阳运动的轨道，下列说法正确的是？', a: '是椭圆，太阳在椭圆的一个焦点上',
      o: ['是正圆，太阳在圆心', '是椭圆，太阳在椭圆的中心', '是椭圆，太阳在椭圆的一个焦点上', '是椭圆，太阳在近日点上'],
      x: '开普勒第一定律（轨道定律）：所有行星绕太阳运动的轨道都是椭圆，太阳处在椭圆的一个焦点上。不同行星的椭圆不同，但太阳是它们共同的焦点。大多数行星的偏心率很小，中学阶段常近似看作匀速圆周运动。' },
    { id: 'k', q: '开普勒第三定律 a³/T² = k 中的常量 k 由什么决定？', a: '只与中心天体有关',
      o: ['只与环绕的行星有关', '只与中心天体有关', '与行星和中心天体都有关', '与轨道的偏心率有关'],
      x: 'k 只与中心天体有关：绕太阳运动的八大行星 k 相同；绕地球运动的月球和人造卫星是另一个 k。不同中心天体的 k 不能混用，所以不能拿月球和地球直接列 a³/T² 相等。' },
    { id: 'diff', q: '在相等时间内，地球与太阳的连线、火星与太阳的连线扫过的面积相等吗？', a: '不一定相等，第二定律只针对同一颗行星',
      o: ['一定相等', '不一定相等，第二定律只针对同一颗行星', '只在近日点附近相等', '只在远日点附近相等'],
      x: '开普勒第二定律说的是“对任意一个行星来说”，它与太阳的连线在相等时间内扫过的面积相等。不同行星之间不能比较——实际上火星的连线每秒扫过的面积比地球大。' },
    { id: 'season', q: '北半球的夏半年（春分到秋分）与冬半年（秋分到次年春分）相比，天数？', a: '夏半年多几天',
      o: ['夏半年多几天', '冬半年多几天', '天数相等', '每年不一定'],
      x: '夏半年地球在远日点（7 月初）附近，离太阳远、公转慢，由第二定律，走过这半圈用时多；冬半年经过近日点附近，公转快。所以北半球夏半年约 186 天，冬半年约 179 天。' },
    { id: 'kepler', q: '开普勒行星运动定律是怎样得出的？', a: '分析第谷的天文观测数据总结出来的',
      o: ['由牛顿万有引力定律推导出来的', '分析第谷的天文观测数据总结出来的', '伽利略用望远镜观测得出的', '哥白尼根据日心说提出的'],
      x: '开普勒在第谷二十多年精确观测数据的基础上，发现火星的观测位置与匀速圆周轨道相差 8′，最终总结出三条定律，是经验定律。几十年后牛顿才用万有引力定律从理论上解释了它们。' }
  ];
  function quizConcept(rand) {
    var c = pick(rand, CONCEPTS);
    return { type: 'concept', sub: c.id, answer: c.a, options: shuffle(rand, c.o), prompt: c.q, explain: c.x };
  }

  function quiz(rand, avoid, only) {
    var gen = { speed: quizSpeed, period: quizPeriod, concept: quizConcept }, q;
    for (var i = 0; i < 10; i++) {
      q = gen[only && gen[only] ? only : pick(rand, TYPES)](rand);
      q.id = q.type + '|' + q.prompt;
      if (q.id !== avoid && q.options.indexOf(q.answer) >= 0) break;
    }
    return q;
  }

  window.Kepler = {
    TAU: TAU, DEG: DEG, GM: GM, KMS: KMS, AU_KM: AU_KM, A_RANGE: A_RANGE, E_RANGE: E_RANGE, SYSTEMS: SYSTEMS, TYPES: TYPES,
    clamp: clamp, f: f, sig: sig, sci: sci, dur: dur,
    period: period, vis: vis, geom: geom, solveE: solveE, at: at, mOfNu: mOfNu,
    sector: sector, sectorArea: sectorArea, polyArea: polyArea, arcLen: arcLen,
    kOf: kOf, kSI: kSI, periodK: periodK, bodyAt: bodyAt,
    quiz: quiz
  };
})();
