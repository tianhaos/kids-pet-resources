// 2D 绘制：椭圆轨道（焦点、半轴、细绳画椭圆、近日点与远日点）、等时间扇形、太阳系/木星/地球的环绕天体俯视图与 T²–a³ 图像、练习题画面
// 世界坐标同 Kepler：中心天体在原点，x 右 y 上；frame(R, box) 把世界范围 box 等比放进屏幕矩形 R
(function () {
  var K = window.Kepler, TAU = K.TAU, f = K.f;
  var PLANET = '#4fc3f7', ORBIT = 'rgba(207,214,226,.75)', CA = '#ffc94a', CB = '#7ee081', CC = '#ff7a59', VEL = '#ff7a59';
  var S1 = 'rgba(255,201,74,', S2 = 'rgba(79,195,247,';
  var MUTED = '#8d99ab', TEXT = '#e6ebf2', GRID = 'rgba(141,153,171,.12)';
  var FONT = '-apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", sans-serif';

  function font(px, w) { return (w ? w + ' ' : '') + px + 'px ' + FONT; }
  function label(ctx, s, x, y, o) {
    o = o || {};
    ctx.font = font(o.size || 12, o.bold ? 600 : null);
    ctx.textAlign = o.align || 'center'; ctx.textBaseline = o.base || 'middle';
    ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(5,7,13,.85)'; ctx.strokeText(s, x, y);
    ctx.fillStyle = o.color || TEXT; ctx.fillText(s, x, y);
  }
  function arrow(ctx, x1, y1, x2, y2, color, o) {
    o = o || {};
    var a = Math.atan2(y2 - y1, x2 - x1), len = Math.hypot(x2 - x1, y2 - y1), size = Math.min(o.size || 10, len * 0.6);
    if (len < 1) return;
    ctx.strokeStyle = ctx.fillStyle = color; ctx.lineWidth = o.width || 2.4; ctx.setLineDash(o.dash || []);
    ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2 - Math.cos(a) * size * 0.6, y2 - Math.sin(a) * size * 0.6); ctx.stroke();
    ctx.setLineDash([]);
    ctx.beginPath();
    ctx.moveTo(x2, y2);
    ctx.lineTo(x2 - size * Math.cos(a - 0.42), y2 - size * Math.sin(a - 0.42));
    ctx.lineTo(x2 - size * Math.cos(a + 0.42), y2 - size * Math.sin(a + 0.42));
    ctx.closePath(); ctx.fill();
  }
  function line(ctx, a, b, color, o) {
    o = o || {};
    ctx.strokeStyle = color; ctx.lineWidth = o.width || 1.2; ctx.setLineDash(o.dash || []);
    ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke(); ctx.setLineDash([]);
  }
  function dot(ctx, p, color, r) { ctx.fillStyle = color; ctx.beginPath(); ctx.arc(p.x, p.y, r || 3.5, 0, 7); ctx.fill(); }
  function shade(c) {
    var n = parseInt(c.slice(1), 16);
    return 'rgb(' + ((n >> 16) * 0.4 | 0) + ',' + ((n >> 8 & 255) * 0.4 | 0) + ',' + ((n & 255) * 0.4 | 0) + ')';
  }
  function ball(ctx, p, color, r) {
    var g = ctx.createRadialGradient(p.x - r * 0.35, p.y - r * 0.35, r * 0.1, p.x, p.y, r);
    g.addColorStop(0, '#fff'); g.addColorStop(0.35, color); g.addColorStop(1, shade(color));
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(p.x, p.y, r, 0, 7); ctx.fill();
  }
  function sun(ctx, p, r) {
    var g = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, r * 2.6);
    g.addColorStop(0, 'rgba(255,200,90,.55)'); g.addColorStop(1, 'rgba(255,160,60,0)');
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(p.x, p.y, r * 2.6, 0, 7); ctx.fill();
    g = ctx.createRadialGradient(p.x - r * 0.3, p.y - r * 0.3, r * 0.1, p.x, p.y, r);
    g.addColorStop(0, '#fff7d6'); g.addColorStop(0.5, '#ffd36b'); g.addColorStop(1, '#ff9a3c');
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(p.x, p.y, r, 0, 7); ctx.fill();
  }
  function poly(ctx, fr, pts) {
    ctx.beginPath();
    pts.forEach(function (q, i) { var p = fr.p(q.x, q.y); if (i) ctx.lineTo(p.x, p.y); else ctx.moveTo(p.x, p.y); });
    ctx.closePath();
  }
  // 椭圆路径（中心天体在焦点原点，近点方向 w）
  function ellipsePath(ctx, fr, a, e, w) {
    var b = a * Math.sqrt(1 - e * e), c = Math.cos(w || 0), s = Math.sin(w || 0);
    ctx.beginPath();
    for (var i = 0; i <= 120; i++) {
      var E = TAU * i / 120, x = a * (Math.cos(E) - e), y = b * Math.sin(E), p = fr.p(x * c - y * s, x * s + y * c);
      if (i) ctx.lineTo(p.x, p.y); else ctx.moveTo(p.x, p.y);
    }
    ctx.closePath();
  }
  // 长度标注：屏幕点 p1→p2 的平行线段（向法线方向偏 off 像素）
  function dim(ctx, p1, p2, off, color, text, o) {
    o = o || {};
    var dx = p2.x - p1.x, dy = p2.y - p1.y, L = Math.hypot(dx, dy);
    if (L < 6) return;
    var nx = -dy / L * off, ny = dx / L * off, a = { x: p1.x + nx, y: p1.y + ny }, b = { x: p2.x + nx, y: p2.y + ny };
    line(ctx, a, b, color, { width: 1.6 });
    line(ctx, { x: a.x - nx * 0.3, y: a.y - ny * 0.3 }, { x: a.x + nx * 0.3, y: a.y + ny * 0.3 }, color, { width: 1.4 });
    line(ctx, { x: b.x - nx * 0.3, y: b.y - ny * 0.3 }, { x: b.x + nx * 0.3, y: b.y + ny * 0.3 }, color, { width: 1.4 });
    var k = (o.gap || 11) / Math.abs(off);
    if (L > (o.minL || 16)) label(ctx, text, (a.x + b.x) / 2 + nx * k, (a.y + b.y) / 2 + ny * k, { color: color, size: 12, bold: true });
  }

  // ---------- 世界 ⇄ 屏幕 ----------
  function frame(R, box) {
    var k = Math.min(R.w / (box.x1 - box.x0), R.h / (box.y1 - box.y0));
    var cx = R.x + R.w / 2, cy = R.y + R.h / 2, mx = (box.x0 + box.x1) / 2, my = (box.y0 + box.y1) / 2;
    return {
      k: k, R: R,
      p: function (x, y) { return { x: cx + (x - mx) * k, y: cy - (y - my) * k }; },
      w: function (sx, sy) { return { x: mx + (sx - cx) / k, y: my - (sy - cy) / k }; }
    };
  }
  // 坐标轴刻度：让 span 分成约 n 格
  function niceStep(span, n) {
    var raw = span / (n || 5), p = Math.pow(10, Math.floor(Math.log10(raw))), m = raw / p;
    return (m < 1.5 ? 1 : m < 3.5 ? 2 : m < 7.5 ? 5 : 10) * p;
  }
  function tick(x) { return Math.abs(x) >= 1e4 ? K.sig(x / 1e4, 3) + '万' : K.sig(x, 4); }

  // ---------- 视图 ----------
  function View(canvas) {
    var ctx = canvas.getContext('2d'), W = 0, H = 0, dpr = 1, narrow = false, geo = null;
    function resize(w, h) {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      W = w; H = h; narrow = w < 640;
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
      canvas.style.width = w + 'px'; canvas.style.height = h + 'px';
    }
    function bg() {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      var g = ctx.createLinearGradient(0, 0, 0, H);
      g.addColorStop(0, '#04060c'); g.addColorStop(1, '#0a1120');
      ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
      // 稀疏的星点（固定伪随机）
      ctx.fillStyle = 'rgba(230,235,242,.35)';
      for (var i = 0; i < 90; i++) { var x = (i * 7919 % 1000) / 1000 * W, y = (i * 104729 % 997) / 997 * H; ctx.fillRect(x, y, 1.2, 1.2); }
    }
    function area(bottomExtra) {
      var t0 = narrow ? 84 : 44, bottom = (narrow ? 44 : 50) + (bottomExtra || 0);
      return { x: 16, y: t0, w: W - 32, h: Math.max(120, H - t0 - bottom) };
    }
    function corner(R, lines) {
      lines.forEach(function (s, i) { if (s) label(ctx, s, R.x + R.w - 6, R.y + 4 + i * 17, { align: 'right', size: 12, color: i ? MUTED : TEXT }); });
    }
    // 让椭圆放进 R：横向 [−ra, rp]，纵向 ±b，留出标注空间
    function orbitFrame(R, a, e, extraY) {
      var g = K.geom(a, e), mx = a * 0.2, hy = Math.max(g.b * 1.18, a * 0.42) + (extraY || 0) * a;
      return frame(R, { x0: -g.ra - mx, x1: g.rp + mx, y0: -hy, y1: hy });
    }
    function sunR(fr, rp) { return Math.max(5, Math.min(13, rp * fr.k * 0.55)); }

    // 场景一、二：椭圆轨道
    // o: { scene: 'ellipse'|'area', a, e, M, show: { axes, string, apsides, vel }, n, mode: 'pair'|'all' }
    function drawOrbit(o) {
      bg();
      var R = area(), a = o.a, e = o.e, g = K.geom(a, e), sh = o.show || {};
      // 宽屏时左右让出近日点、远日点的文字
      var pad = sh.apsides && !narrow ? 92 : 0, fr = orbitFrame({ x: R.x + pad, y: R.y, w: R.w - 2 * pad, h: R.h }, a, e);
      var S = fr.p(0, 0), F2 = fr.p(-2 * g.c, 0), C = fr.p(-g.c, 0), P = fr.p(g.rp, 0), A = fr.p(-g.ra, 0);
      var st = K.at(a, e, o.M), pp = fr.p(st.x, st.y);
      // 扇形
      if (o.scene === 'area') {
        var n = o.n, dM = TAU / n;
        if (o.mode === 'all') {
          for (var i = 0; i < n; i++) {
            poly(ctx, fr, K.sector(a, e, i * dM, (i + 1) * dM));
            ctx.fillStyle = (i % 2 ? S2 : S1) + '.16)'; ctx.fill();
            ctx.strokeStyle = (i % 2 ? S2 : S1) + '.45)'; ctx.lineWidth = 1; ctx.stroke();
          }
        } else {
          [[-dM / 2, dM / 2, S1], [Math.PI - dM / 2, Math.PI + dM / 2, S2]].forEach(function (s) {
            poly(ctx, fr, K.sector(a, e, s[0], s[1]));
            ctx.fillStyle = s[2] + '.3)'; ctx.fill();
            ctx.strokeStyle = s[2] + '.85)'; ctx.lineWidth = 1.4; ctx.stroke();
          });
          var pm = K.at(a, e, 0), am = K.at(a, e, Math.PI), sArea = 'S = ' + K.sig(g.area / n, 3) + ' AU²';
          var pl = fr.p(pm.x * 0.55, 0), al = fr.p(am.x * 0.55, 0);
          if (P.x - S.x > 46) label(ctx, 'S₁', pl.x, pl.y - 2, { color: CA, size: 13, bold: true });
          label(ctx, 'S₂', al.x, al.y - 9, { color: PLANET, size: 13, bold: true });
          label(ctx, sArea, al.x, al.y + 9, { color: PLANET, size: 11 });
        }
        // 当前这一段 Δt 内扫过的扇形
        var k0 = Math.floor(st.M / dM + 1e-9), m0 = k0 * dM;
        if (o.mode === 'pair') { m0 = st.M - ((st.M + dM / 2) % dM); }
        if (st.M - m0 > 1e-4) {
          poly(ctx, fr, K.sector(a, e, m0, st.M));
          ctx.fillStyle = o.mode === 'all' ? (k0 % 2 ? S2 : S1) + '.5)' : 'rgba(230,235,242,.2)'; ctx.fill();
        }
        line(ctx, S, pp, 'rgba(230,235,242,.8)', { width: 1.4 });
      }
      // 轨道
      ellipsePath(ctx, fr, a, e);
      ctx.strokeStyle = ORBIT; ctx.lineWidth = 1.8; ctx.stroke();
      // 半轴与焦距
      if (sh.axes) {
        var B = fr.p(-g.c, g.b);
        line(ctx, A, P, 'rgba(141,153,171,.6)', { dash: [4, 4] });
        line(ctx, fr.p(-g.c, -g.b), B, 'rgba(141,153,171,.6)', { dash: [4, 4] });
        dot(ctx, C, MUTED, 2.5);
        dim(ctx, A, C, -18, CA, 'a = ' + K.sig(a, 3), { minL: 30 });
        dim(ctx, C, B, 14, CB, 'b', { minL: 14 });
        if (g.c > 0) dim(ctx, C, S, 16, CC, 'c', { minL: 8 });
      }
      // 细绳画椭圆：两个焦点到行星的距离之和为 2a
      if (sh.string) {
        line(ctx, S, pp, 'rgba(230,235,242,.9)', { width: 1.5 });
        line(ctx, F2, pp, 'rgba(230,235,242,.9)', { width: 1.5 });
        var r2 = Math.hypot(st.x + 2 * g.c, st.y);
        label(ctx, 'r₁', (S.x + pp.x) / 2 + 10, (S.y + pp.y) / 2 - 8, { size: 12, bold: true });
        label(ctx, 'r₂', (F2.x + pp.x) / 2 - 10, (F2.y + pp.y) / 2 - 8, { size: 12, bold: true });
        corner(R, ['r₁ + r₂ = ' + K.sig(st.r, 3) + ' + ' + K.sig(r2, 3) + ' = ' + K.sig(st.r + r2, 3) + ' AU = 2a']);
      }
      // 空焦点
      if (g.c > 0 && (sh.axes || sh.string)) {
        ctx.strokeStyle = MUTED; ctx.lineWidth = 1.5;
        ctx.beginPath(); ctx.moveTo(F2.x - 5, F2.y - 5); ctx.lineTo(F2.x + 5, F2.y + 5); ctx.moveTo(F2.x - 5, F2.y + 5); ctx.lineTo(F2.x + 5, F2.y - 5); ctx.stroke();
        if (S.x - F2.x > 30) label(ctx, 'F₂', F2.x, F2.y + 16, { size: 12, color: MUTED });
      }
      // 近日点与远日点
      if (sh.apsides) {
        dot(ctx, P, TEXT, 3); dot(ctx, A, TEXT, 3);
        var vp = g.vp * K.KMS, va = g.va * K.KMS;
        // 窄屏时文字放在点的内侧
        var ins = narrow ? -1 : 1, ty = narrow ? 30 : 0;
        label(ctx, '近日点', P.x + 8 * ins, P.y - 22 - ty, { align: narrow ? 'right' : 'left', size: 12, bold: true });
        label(ctx, 'a − c = ' + K.sig(g.rp, 3) + ' AU', P.x + 8 * ins, P.y + 20 + ty, { align: narrow ? 'right' : 'left', size: 11, color: MUTED });
        if (o.scene === 'area') label(ctx, 'v = ' + f(vp, 1) + ' km/s', P.x + 8 * ins, P.y + 36 + ty, { align: narrow ? 'right' : 'left', size: 11, color: VEL });
        label(ctx, '远日点', A.x - 8 * ins, A.y - 22 - ty, { align: narrow ? 'left' : 'right', size: 12, bold: true });
        label(ctx, 'a + c = ' + K.sig(g.ra, 3) + ' AU', A.x - 8 * ins, A.y + 20 + ty, { align: narrow ? 'left' : 'right', size: 11, color: MUTED });
        if (o.scene === 'area') label(ctx, 'v = ' + f(va, 1) + ' km/s', A.x - 8 * ins, A.y + 36 + ty, { align: narrow ? 'left' : 'right', size: 11, color: VEL });
      }
      sun(ctx, S, sunR(fr, g.rp));
      // 太阳的名字放在上方（下方是焦距 c 的标注）；近日点贴得很近时往左挪
      var tight = P.x - S.x < 60;
      if (o.scene === 'ellipse') label(ctx, g.c > 0 ? 'F₁ 太阳' : '太阳', tight ? S.x - 8 : S.x, S.y - sunR(fr, g.rp) - 12, { size: 12, color: '#ffd36b', align: tight ? 'right' : 'center' });
      // 速度
      if (sh.vel) {
        var kv = Math.min(R.w, R.h) * 0.2 / g.vp;
        arrow(ctx, pp.x, pp.y, pp.x + st.vx * kv, pp.y - st.vy * kv, VEL, { width: 2.4 });
      }
      ball(ctx, pp, PLANET, 9);
      if (o.scene === 'area') corner(R, ['Δt = T/' + o.n + ' = ' + K.dur(g.T / o.n), '每段面积 πab/' + o.n + ' = ' + K.sig(g.area / o.n, 3) + ' AU²']);
      geo = { fr: fr };
      return geo;
    }

    // 场景三：第三定律
    // o: { sys, t, zoom: 'all'|'inner', chart: 'lin'|'log', custom: a 或 null }
    function drawPeriod(o) {
      bg();
      var R = area(), sys = o.sys, k = K.kOf(sys), bodies = sys.bodies;
      var vis = o.zoom === 'inner' ? bodies.slice(0, sys.inner) : bodies;
      var gap = 18, Ro, Rc;
      if (R.w >= R.h * 1.25) {
        var sw = Math.min(R.h, R.w * 0.52);
        Ro = { x: R.x, y: R.y, w: sw, h: R.h }; Rc = { x: R.x + sw + gap, y: R.y + 6, w: R.w - sw - gap, h: R.h - 12 };
      } else {
        var sh = Math.min(R.w, R.h * 0.56);
        Ro = { x: R.x, y: R.y, w: R.w, h: sh }; Rc = { x: R.x, y: R.y + sh + gap, w: R.w, h: R.h - sh - gap };
      }
      // ---- 俯视轨道 ----
      var ext = 0;
      vis.forEach(function (b) { ext = Math.max(ext, b.a * (1 + b.e)); });
      // “近处”也要容下不超过下一个天体轨道的自定义天体
      if (o.custom != null && (o.zoom !== 'inner' || !bodies[sys.inner] || o.custom < bodies[sys.inner].a)) ext = Math.max(ext, o.custom);
      ext *= 1.12;
      var fr = frame(Ro, { x0: -ext, x1: ext, y0: -ext, y1: ext }), O = fr.p(0, 0);
      ctx.save(); ctx.beginPath(); ctx.rect(Ro.x, Ro.y, Ro.w, Ro.h); ctx.clip();
      bodies.forEach(function (b) {
        ellipsePath(ctx, fr, b.a, b.e, b.w * K.DEG);
        ctx.strokeStyle = b.color; ctx.globalAlpha = 0.45; ctx.lineWidth = 1.2; ctx.stroke(); ctx.globalAlpha = 1;
      });
      if (o.custom != null) {
        ctx.strokeStyle = CA; ctx.lineWidth = 1.4; ctx.setLineDash([5, 4]);
        ctx.beginPath(); ctx.arc(O.x, O.y, o.custom * fr.k, 0, 7); ctx.stroke(); ctx.setLineDash([]);
      }
      if (sys.R) {
        var rr = Math.max(6, sys.R * fr.k);
        ball(ctx, O, sys.name === '木星' ? '#d9a066' : '#3f8fd8', rr);
        label(ctx, sys.name, O.x, O.y + rr + 12, { size: 12, color: MUTED });
      } else { sun(ctx, O, 9); label(ctx, '太阳', O.x, O.y + 22, { size: 12, color: '#ffd36b' }); }
      bodies.forEach(function (b) {
        var q = K.bodyAt(b, o.t), p = fr.p(q.x, q.y);
        if (p.x < Ro.x - 20 || p.x > Ro.x + Ro.w + 20 || p.y < Ro.y - 20 || p.y > Ro.y + Ro.h + 20) return;
        ball(ctx, p, b.color, 5.5);
        label(ctx, b.name, p.x, p.y - 13, { size: 11, color: b.color });
      });
      if (o.custom != null) {
        var tc = K.periodK(o.custom, k), ac = TAU * o.t / tc + 0.6, pc = fr.p(o.custom * Math.cos(ac), o.custom * Math.sin(ac));
        ball(ctx, pc, CA, 6);
        label(ctx, '自定义', pc.x, pc.y - 14, { size: 11, color: CA, bold: true });
      }
      ctx.restore();
      label(ctx, 't = ' + K.sig(o.t, 3) + ' ' + sys.tUnit, Ro.x + 4, Ro.y + 6, { align: 'left', size: 12 });
      // ---- 图像 ----
      chart(Rc, o, sys, k, vis);
      geo = { fr: fr };
      return geo;
    }

    function chart(Rc, o, sys, k, vis) {
      var lg = o.chart === 'log', pts = vis.map(function (b) { return { name: b.name, a: b.a, T: b.T, color: b.color }; });
      if (o.custom != null) pts.push({ name: '自定义', a: o.custom, T: K.periodK(o.custom, k), color: CA, custom: true });
      var X = function (p) { return lg ? Math.log10(p.a) : Math.pow(p.a, 3); }, Y = function (p) { return lg ? Math.log10(p.T) : p.T * p.T; };
      var x0, x1, y0, y1;
      if (lg) {
        x0 = Infinity; x1 = -Infinity; y0 = Infinity; y1 = -Infinity;
        pts.forEach(function (p) { x0 = Math.min(x0, X(p)); x1 = Math.max(x1, X(p)); y0 = Math.min(y0, Y(p)); y1 = Math.max(y1, Y(p)); });
        var px = Math.max(0.3, (x1 - x0) * 0.12), py = Math.max(0.45, (y1 - y0) * 0.12);
        x0 = Math.floor((x0 - px) * 2) / 2; x1 = Math.ceil((x1 + px) * 2) / 2; y0 = Math.floor((y0 - py) * 2) / 2; y1 = Math.ceil((y1 + py) * 2) / 2;
      } else {
        x0 = 0; y0 = 0; x1 = 0; y1 = 0;
        pts.forEach(function (p) { x1 = Math.max(x1, X(p)); y1 = Math.max(y1, Y(p)); });
        x1 *= 1.12; y1 *= 1.12;
      }
      var padL = 46, padB = 34, padT = 26;
      var G = { x: Rc.x + padL, y: Rc.y + padT, w: Rc.w - padL - 10, h: Rc.h - padT - padB };
      if (G.w < 60 || G.h < 50) return;
      var sx = function (x) { return G.x + (x - x0) / (x1 - x0) * G.w; }, sy = function (y) { return G.y + G.h - (y - y0) / (y1 - y0) * G.h; };
      ctx.fillStyle = 'rgba(17,23,35,.55)'; ctx.fillRect(Rc.x, Rc.y, Rc.w, Rc.h);
      // 网格与刻度
      var stx = lg ? 0.5 : niceStep(x1, G.w < 220 ? 3 : 5), sty = lg ? 0.5 : niceStep(y1, G.h < 160 ? 3 : 5), v;
      if (lg && x1 - x0 > 3) stx = 1;
      if (lg && y1 - y0 > 3) sty = 1;
      ctx.strokeStyle = GRID; ctx.lineWidth = 1; ctx.beginPath();
      for (v = Math.ceil(x0 / stx) * stx; v <= x1 + 1e-9; v += stx) { ctx.moveTo(sx(v), G.y); ctx.lineTo(sx(v), G.y + G.h); }
      for (v = Math.ceil(y0 / sty) * sty; v <= y1 + 1e-9; v += sty) { ctx.moveTo(G.x, sy(v)); ctx.lineTo(G.x + G.w, sy(v)); }
      ctx.stroke();
      for (v = Math.ceil(x0 / stx) * stx; v <= x1 + 1e-9; v += stx) label(ctx, lg ? f(v, 1) : tick(v), sx(v), G.y + G.h + 11, { size: 10, color: MUTED });
      for (v = Math.ceil(y0 / sty) * sty; v <= y1 + 1e-9; v += sty) label(ctx, lg ? f(v, 1) : tick(v), G.x - 5, sy(v), { size: 10, color: MUTED, align: 'right' });
      line(ctx, { x: G.x, y: G.y }, { x: G.x, y: G.y + G.h }, MUTED);
      line(ctx, { x: G.x, y: G.y + G.h }, { x: G.x + G.w, y: G.y + G.h }, MUTED);
      var au = sys.aUnit, tu = sys.tUnit;
      label(ctx, lg ? 'lg(a / ' + au + ')' : 'a³ / ' + (au === 'AU' ? 'AU³' : '(' + au + ')³'), G.x + G.w, G.y + G.h + 26, { size: 11, color: MUTED, align: 'right' });
      label(ctx, lg ? 'lg(T / ' + tu + ')' : 'T² / ' + tu + '²', G.x - 4, G.y - 14, { size: 11, color: MUTED, align: 'left' });
      // 理论直线：T² = a³/k；双对数 lgT = 1.5·lga − 0.5·lgk
      ctx.save(); ctx.beginPath(); ctx.rect(G.x, G.y, G.w, G.h); ctx.clip();
      var L = lg ? function (x) { return 1.5 * x - 0.5 * Math.log10(k); } : function (x) { return x / k; };
      line(ctx, { x: sx(x0), y: sy(L(x0)) }, { x: sx(x1), y: sy(L(x1)) }, 'rgba(255,201,74,.55)', { width: 1.6, dash: [6, 4] });
      ctx.restore();
      label(ctx, lg ? '斜率 3/2' : '过原点的直线，斜率 1/k', G.x + G.w - 4, G.y + 8, { size: 11, color: CA, align: 'right' });
      // 数据点（离上一个已标名字的点太近就不标名字）
      var placed = [];
      pts.forEach(function (p) {
        var q = { x: sx(X(p)), y: sy(Y(p)) };
        dot(ctx, q, p.color, p.custom ? 5 : 4);
        if (p.custom) { ctx.strokeStyle = CA; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.arc(q.x, q.y, 8, 0, 7); ctx.stroke(); }
        var near = placed.some(function (r) { return Math.abs(r.x - q.x) < 34 && Math.abs(r.y - q.y) < 14; });
        if (!near || p.custom) { label(ctx, p.name, q.x - 7, q.y - 9, { size: 11, color: p.color, align: 'right' }); placed.push(q); }
      });
    }

    // 练习题画面
    function drawQuiz(q, answered, opt) {
      bg();
      var R = area((opt.quizH || 0) + 10);
      if (!q) return;
      var t = q.type, sub = q.sub;
      if (t === 'speed' && sub === 'ratio') {
        var e = (q.ra - q.rp) / (q.ra + q.rp), a = (q.ra + q.rp) / 2, fr = orbitFrame(R, a, e, 0.1), g = K.geom(a, e);
        var S = fr.p(0, 0), P = fr.p(g.rp, 0), A = fr.p(-g.ra, 0);
        ellipsePath(ctx, fr, a, e); ctx.strokeStyle = ORBIT; ctx.lineWidth = 1.8; ctx.stroke();
        line(ctx, A, P, 'rgba(141,153,171,.6)', { dash: [4, 4] });
        dim(ctx, S, P, 16, CA, q.rp + 'r'); dim(ctx, A, S, 16, CA, q.ra + 'r');
        sun(ctx, S, 11);
        var len = Math.min(R.h * 0.32, 110);
        arrow(ctx, P.x, P.y, P.x, P.y - len, VEL); label(ctx, 'v_p = ' + q.vp + ' km/s', P.x + 8, P.y - len, { align: 'left', color: VEL, bold: true });
        arrow(ctx, A.x, A.y, A.x, A.y + len * q.rp / q.ra, VEL);
        label(ctx, 'v_a = ' + (answered ? q.answer : '?'), A.x - 8, A.y + len * q.rp / q.ra, { align: 'right', color: VEL, bold: true });
        ball(ctx, P, PLANET, 8); ball(ctx, A, PLANET, 8);
        return;
      }
      if (t === 'period' && sub !== 'halley') {
        var a1 = sub === 'ratio' ? q.a1 : 1, a2 = sub === 'ratio' ? q.a2 : q.a, m = Math.max(a1, a2) * 1.25;
        var fr2 = frame(R, { x0: -m, x1: m, y0: -m, y1: m }), O = fr2.p(0, 0);
        sun(ctx, O, 9);
        [[a1, PLANET, sub === 'ratio' ? '行星 1' : '地球', 0.9], [a2, CA, sub === 'ratio' ? '行星 2' : '小行星', 2.4]].forEach(function (s) {
          ctx.strokeStyle = s[1]; ctx.globalAlpha = 0.6; ctx.lineWidth = 1.4;
          ctx.beginPath(); ctx.arc(O.x, O.y, s[0] * fr2.k, 0, 7); ctx.stroke(); ctx.globalAlpha = 1;
          var p = fr2.p(s[0] * Math.cos(s[3]), s[0] * Math.sin(s[3]));
          ball(ctx, p, s[1], 6); label(ctx, s[2], p.x, p.y - 14, { color: s[1], size: 12, bold: true });
        });
        label(ctx, sub === 'ratio' ? 'a₁ : a₂ = ' + q.a1 + ' : ' + q.a2 : '地球 a = 1 AU，小行星 a = ' + f(q.a, 2) + ' AU', O.x, R.y + 8, { size: 13 });
        return;
      }
      // 其余：椭圆示意图（哈雷彗星、地球公转、概念题）
      var ea = 1, ee = 0.55, labels = null;
      if (sub === 'halley') { ea = 18; ee = 0.967; }
      var fr3 = orbitFrame(R, ea, ee, 0.05), g3 = K.geom(ea, ee), S3 = fr3.p(0, 0);
      if (t === 'concept' && sub !== 'season' || t === 'speed' && sub === 'trend') {
        var dM = TAU / 12;
        [[-dM / 2, dM / 2, S1], [Math.PI - dM / 2, Math.PI + dM / 2, S2]].forEach(function (s) {
          poly(ctx, fr3, K.sector(ea, ee, s[0], s[1])); ctx.fillStyle = s[2] + '.25)'; ctx.fill();
        });
      }
      ellipsePath(ctx, fr3, ea, ee); ctx.strokeStyle = ORBIT; ctx.lineWidth = 1.8; ctx.stroke();
      if (sub === 'halley') {
        ctx.strokeStyle = PLANET; ctx.globalAlpha = 0.7; ctx.beginPath(); ctx.arc(S3.x, S3.y, fr3.k, 0, 7); ctx.stroke(); ctx.globalAlpha = 1;
        label(ctx, '地球轨道 1 AU', S3.x, S3.y - fr3.k - 26, { size: 11, color: PLANET });
        label(ctx, 'T = 76 年，a = ' + (answered ? '≈ 18 AU' : '?'), fr3.p(-ea, 0).x, fr3.p(0, g3.b).y - 14, { size: 13, bold: true });
        ball(ctx, fr3.p(g3.rp, 0), '#cfd6e2', 5);
      }
      if (sub === 'season' || sub === 'earth') labels = [['近日点 · 1 月初', 0], ['远日点 · 7 月初', Math.PI]];
      if (t === 'speed' && sub === 'trend') {
        var from = q.toAph ? 0.15 : Math.PI + 0.15, to = q.toAph ? Math.PI - 0.15 : TAU - 0.15, pts = [];
        for (var i = 0; i <= 40; i++) { var s = K.at(ea, ee, from + (to - from) * i / 40); pts.push(fr3.p(s.x, s.y)); }
        ctx.strokeStyle = VEL; ctx.lineWidth = 2; ctx.beginPath(); pts.forEach(function (p, j) { if (j) ctx.lineTo(p.x, p.y); else ctx.moveTo(p.x, p.y); }); ctx.stroke();
        arrow(ctx, pts[38].x, pts[38].y, pts[40].x, pts[40].y, VEL, { size: 12 });
        labels = [['近日点', 0], ['远日点', Math.PI]];
      }
      if (labels) labels.forEach(function (l) {
        var s = K.at(ea, ee, l[1]), p = fr3.p(s.x, s.y);
        ball(ctx, p, PLANET, 6);
        label(ctx, l[0], p.x + (l[1] ? -10 : 10), p.y - 18, { align: l[1] ? 'right' : 'left', size: 12, bold: true });
      });
      if (t === 'concept' && sub === 'k') {
        [0.45, 0.75].forEach(function (rr, j) { ctx.strokeStyle = j ? CA : CB; ctx.globalAlpha = 0.6; ctx.beginPath(); ctx.arc(S3.x, S3.y, rr * fr3.k, 0, 7); ctx.stroke(); ctx.globalAlpha = 1; });
      }
      sun(ctx, S3, sub === 'halley' ? 6 : 11);
      if (t === 'concept' && sub !== 'season' && sub !== 'k' || t === 'speed' && sub === 'trend') {
        if (answered || sub !== 'shape') { label(ctx, '太阳（焦点）', S3.x, S3.y + 24, { size: 12, color: '#ffd36b' }); }
        if (sub !== 'shape' || answered) label(ctx, '相等时间扫过的面积相等', fr3.p(-ea * 0.6, 0).x, fr3.p(0, -g3.b).y + 22, { size: 12, color: MUTED });
      }
    }

    return { resize: resize, drawOrbit: drawOrbit, drawPeriod: drawPeriod, drawQuiz: drawQuiz, geo: function () { return geo; }, narrow: function () { return narrow; } };
  }

  window.KeplerDraw = { View: View, frame: frame };
})();
