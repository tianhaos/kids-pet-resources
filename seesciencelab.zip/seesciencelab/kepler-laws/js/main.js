(function () {
  var K = window.Kepler, D = window.KeplerDraw, TAU = K.TAU, f = K.f, sig = K.sig;
  var $ = function (id) { return document.getElementById(id); };
  var qa = function (sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); };
  var NAME = '开普勒定律';
  var ORBIT_S = 12;  // 场景一、二：“中速”时绕一周的秒数

  var PRESETS = {
    circle: { name: '正圆轨道', a: 1, e: 0 },
    earth: { name: '地球', a: 1, e: 0.0167 },
    mars: { name: '火星', a: 1.524, e: 0.0934 },
    mercury: { name: '水星', a: 0.387, e: 0.2056 },
    pluto: { name: '冥王星', a: 39.48, e: 0.2488 },
    halley: { name: '哈雷彗星', a: 17.8, e: 0.967 }
  };

  var state = {
    scene: 'ellipse',
    a: 1, e: 0.6, preset: null, M: 0.9, speed: 1, paused: false,
    show: { axes: true, string: true, apsides: true },
    n: 12, mode: 'pair', vel: true,
    sys: 'sun', t: 0, zoom: 'inner', chart: 'lin', custom: true, ca: {}, rate: 1,
    quiz: null, quizOnly: null, answered: false, correct: false, choice: null, score: { n: 0, ok: 0 }
  };
  Object.keys(K.SYSTEMS).forEach(function (k) { state.ca[k] = K.SYSTEMS[k].custom[2]; });

  var HINTS = {
    ellipse: '拖动行星沿轨道移动 · 改偏心率看椭圆变扁',
    area: '相等时间内扫过的面积相等 · 拖动行星',
    period: '半长轴越大，周期越长：a³/T² = k',
    quiz: '开普勒定律 · 判断练习'
  };
  var SHOWS = ['axes', 'string', 'apsides'];

  var stage = $('stage'), panel = $('panel'), cv = $('view');
  var view = D.View(cv);
  function sys() { return K.SYSTEMS[state.sys]; }
  function setSeg(attr, val) { qa('[data-' + attr + ']').forEach(function (b) { b.classList.toggle('on', b.dataset[attr] === String(val)); }); }

  // ---------- 场景 ----------
  qa('[data-scene]').forEach(function (b) {
    b.addEventListener('click', function () { setScene(b.dataset.scene); Analytics.track(NAME, '场景', b.textContent); });
  });
  function setScene(sc) {
    state.scene = sc;
    if (sc === 'quiz' && !state.quiz) newQuiz();
    $('rName').className = '';
    syncUI();
  }

  // ---------- 控件 ----------
  function setOrbit(a, e, preset) {
    state.a = K.clamp(a, K.A_RANGE[0], K.A_RANGE[1]); state.e = K.clamp(e, K.E_RANGE[0], K.E_RANGE[1]);
    state.preset = preset || null;
    syncUI();
  }
  qa('[data-preset]').forEach(function (b) {
    b.addEventListener('click', function () {
      var p = PRESETS[b.dataset.preset];
      setOrbit(p.a, p.e, b.dataset.preset);
      Analytics.track(NAME, '预设', p.name);
    });
  });
  qa('[data-speed]').forEach(function (b) {
    b.addEventListener('click', function () { state.speed = parseFloat(b.dataset.speed); syncUI(); });
  });
  qa('[data-n]').forEach(function (b) {
    b.addEventListener('click', function () { state.n = parseInt(b.dataset.n, 10); syncUI(); Analytics.track(NAME, '等分', b.dataset.n); });
  });
  qa('[data-mode]').forEach(function (b) {
    b.addEventListener('click', function () { state.mode = b.dataset.mode; syncUI(); Analytics.track(NAME, '扇形', b.textContent); });
  });
  qa('[data-sys]').forEach(function (b) {
    b.addEventListener('click', function () { state.sys = b.dataset.sys; state.t = 0; buildTable(); syncUI(); Analytics.track(NAME, '中心天体', b.textContent); });
  });
  qa('[data-zoom]').forEach(function (b) {
    b.addEventListener('click', function () { state.zoom = b.dataset.zoom; syncUI(); Analytics.track(NAME, '范围', b.textContent); });
  });
  qa('[data-chart]').forEach(function (b) {
    b.addEventListener('click', function () { state.chart = b.dataset.chart; syncUI(); Analytics.track(NAME, '图像', b.textContent); });
  });
  qa('[data-rate]').forEach(function (b) {
    b.addEventListener('click', function () { state.rate = parseFloat(b.dataset.rate); syncUI(); });
  });

  // 半长轴滑块按对数刻度
  function logTo(v, lo, hi) { return lo * Math.pow(hi / lo, v / 1000); }
  function logFrom(x, lo, hi) { return Math.round(Math.log(x / lo) / Math.log(hi / lo) * 1000); }
  function bindSlider(id, get, set) {
    var el = $(id);
    el.addEventListener('input', function () { set(parseFloat(el.value)); });
    el.addEventListener('change', function () { Analytics.track(NAME, '滑块', id); });
    return { el: el, get: get };
  }
  var sliders = [
    bindSlider('aSl', function () { return logFrom(state.a, K.A_RANGE[0], K.A_RANGE[1]); }, function (v) { state.a = logTo(v, K.A_RANGE[0], K.A_RANGE[1]); state.preset = null; syncUI(); }),
    bindSlider('eSl', function () { return state.e; }, function (v) { state.e = v; state.preset = null; syncUI(); }),
    bindSlider('caSl', function () { var r = sys().custom; return logFrom(state.ca[state.sys], r[0], r[1]); }, function (v) { var r = sys().custom; state.ca[state.sys] = logTo(v, r[0], r[1]); })
  ];
  SHOWS.forEach(function (k) {
    var el = $('show-' + k);
    el.addEventListener('change', function () { state.show[k] = el.checked; Analytics.track(NAME, '显示', k); });
  });
  $('vel').addEventListener('change', function () { state.vel = $('vel').checked; });
  $('custom').addEventListener('change', function () { state.custom = $('custom').checked; syncUI(); Analytics.track(NAME, '自定义天体', String(state.custom)); });
  function togglePause() { state.paused = !state.paused; syncUI(); }
  qa('.pause').forEach(function (b) { b.addEventListener('click', togglePause); });
  $('reset').addEventListener('click', function () { state.t = 0; });

  // ---------- 画布：拖动行星沿轨道移动 ----------
  var drag = false;
  function local(e) { var r = cv.getBoundingClientRect(); return { x: e.clientX - r.left, y: e.clientY - r.top }; }
  function canDrag() { return state.scene === 'ellipse' || state.scene === 'area'; }
  function scrubTo(p) {
    var gm = view.geo(); if (!gm || !gm.fr) return;
    var w = gm.fr.w(p.x, p.y);
    state.M = K.mOfNu(Math.atan2(w.y, w.x), state.e);
  }
  cv.addEventListener('pointerdown', function (e) {
    if (e.button !== 0 || !canDrag()) return;
    drag = true; state.paused = true; syncUI();
    try { cv.setPointerCapture(e.pointerId); } catch (err) { /* 合成事件 */ }
    Analytics.track(NAME, '拖动', state.scene);
    scrubTo(local(e));
  });
  cv.addEventListener('pointermove', function (e) {
    if (drag) { scrubTo(local(e)); return; }
    cv.style.cursor = canDrag() ? 'grab' : '';
  });
  function endDrag(e) {
    if (!drag) return;
    drag = false;
    if (cv.hasPointerCapture(e.pointerId)) cv.releasePointerCapture(e.pointerId);
  }
  cv.addEventListener('pointerup', endDrag);
  cv.addEventListener('pointercancel', endDrag);

  // ---------- 第三定律的数据表 ----------
  function buildTable() {
    var s = sys();
    $('tblHead').innerHTML = '<tr><th>' + s.what + '</th><th>a / ' + s.aUnit + '</th><th>T / ' + s.tUnit + '</th><th>a³/T²</th></tr>';
    $('tblBody').innerHTML = s.bodies.map(function (b) {
      var kk = b.a * b.a * b.a / (b.T * b.T);
      return '<tr><td><i style="background:' + b.color + '"></i>' + b.name + '</td><td>' + sig(b.a, 4) + '</td><td>' + sig(b.T, 4) + '</td><td>' + (kk >= 1000 ? Math.round(kk) : kk.toPrecision(4)) + '</td></tr>';
    }).join('');
    $('tblNote').textContent = state.sys === 'sun' ? '八大行星的 a³/T² 都约等于 1 AU³/年²（与地球相同）。'
      : state.sys === 'jupiter' ? '木星的四颗伽利略卫星 a³/T² 相同，但与绕太阳的行星不同：k 只由中心天体决定。'
      : '人造卫星的 a³/T² 相同；月球质量约为地球的 1/81，不能完全忽略，所以月球的值略大。';
  }

  // ---------- 练习 ----------
  function newQuiz() {
    state.quiz = K.quiz(Math.random, state.quiz && state.quiz.id, state.quizOnly);
    state.answered = false; state.choice = null;
    var box = $('quizOpts');
    box.innerHTML = '';
    box.classList.toggle('one-col', state.quiz.options.some(function (o) { return o.length > 11; }));
    state.quiz.options.forEach(function (o) {
      var b = document.createElement('button');
      b.className = 'small';
      b.textContent = o;
      b.addEventListener('click', function () { answer(o); });
      box.appendChild(b);
    });
    syncUI();
  }
  function answer(o) {
    if (state.answered) return;
    state.answered = true;
    state.choice = o;
    state.correct = o === state.quiz.answer;
    state.score.n++; if (state.correct) state.score.ok++;
    Analytics.track(NAME, '练习', state.quiz.type + (state.correct ? ' 对' : ' 错'));
    syncUI();
  }
  $('nextQ').addEventListener('click', newQuiz);
  // 把题目的情境搬到模型里
  $('showQ').addEventListener('click', function () {
    var q = state.quiz, sub = q.sub;
    state.paused = false;
    if (q.type === 'speed') {
      if (sub === 'ratio') setOrbit(1, (q.ra - q.rp) / (q.ra + q.rp));
      else if (sub === 'earth') setOrbit(1, 0.0167, 'earth');
      else setOrbit(1, 0.6);
      state.mode = 'pair'; state.vel = true;
      setScene('area');
    } else if (q.type === 'period') {
      if (sub === 'halley') { setOrbit(17.8, 0.967, 'halley'); setScene('ellipse'); return; }
      state.sys = 'sun'; state.custom = true; state.chart = 'lin';
      var a = sub === 'ratio' ? Math.max(q.a1, q.a2) / Math.min(q.a1, q.a2) : q.a;
      state.ca.sun = K.clamp(a, K.SYSTEMS.sun.custom[0], K.SYSTEMS.sun.custom[1]);
      state.zoom = state.ca.sun > 2 ? 'all' : 'inner';
      buildTable(); setScene('period');
    } else if (sub === 'k') { state.sys = 'jupiter'; buildTable(); setScene('period'); }
    else if (sub === 'diff' || sub === 'season') {
      if (sub === 'season') setOrbit(1, 0.0167, 'earth'); else setOrbit(1, 0.6);
      state.mode = 'pair'; setScene('area');
    } else { setOrbit(1, 0.6); setScene('ellipse'); }
  });

  // ---------- 面板 ----------
  $('panelToggle').addEventListener('click', function () { panel.classList.toggle('collapsed'); });
  if (window.matchMedia('(max-width: 760px)').matches) panel.classList.add('collapsed');
  window.addEventListener('keydown', function (e) {
    var tg = e.target.tagName;
    if (tg === 'INPUT' || tg === 'SELECT' || tg === 'BUTTON' || tg === 'TEXTAREA') return;
    if (e.code === 'Space' && state.scene !== 'quiz') { e.preventDefault(); togglePause(); }
  });

  function syncUI() {
    var sc = state.scene;
    setSeg('scene', sc);
    qa('[data-for]').forEach(function (el) { el.hidden = el.dataset.for.split(' ').indexOf(sc) < 0; });
    $('hint').textContent = HINTS[sc];
    setSeg('preset', state.preset);
    setSeg('speed', state.speed);
    setSeg('n', state.n);
    setSeg('mode', state.mode);
    setSeg('sys', state.sys);
    setSeg('zoom', state.zoom);
    setSeg('chart', state.chart);
    setSeg('rate', state.rate);
    SHOWS.forEach(function (k) { $('show-' + k).checked = state.show[k]; });
    $('vel').checked = state.vel; $('custom').checked = state.custom;
    $('caRow').hidden = !state.custom;
    qa('.pause').forEach(function (b) { b.textContent = state.paused ? '▶ 继续' : '❚❚ 暂停'; });
    var q = state.quiz;
    if (q) {
      $('quizQ').textContent = q.prompt;
      qa('#quizOpts button').forEach(function (b) {
        b.disabled = state.answered;
        b.classList.toggle('on', state.answered && b.textContent === q.answer);
        b.classList.toggle('no', state.answered && b.textContent === state.choice && !state.correct);
      });
      $('quizMsg').innerHTML = !state.answered ? ''
        : '<b class="' + (state.correct ? 'ok">✓ 答对了' : 'bad">✗ 应选「' + q.answer + '」') + '</b>' + q.explain;
      $('nextQ').textContent = state.answered ? '下一题 →' : '换一题';
      $('showQ').hidden = !state.answered;
    }
  }

  // ---------- 读数 ----------
  var lastText = {};
  function setText(id, s) { if (lastText[id] !== s) { lastText[id] = s; $(id).textContent = s; } }
  function rows(list) {
    for (var k = 1; k <= 5; k++) {
      var r = list[k - 1] || ['', ''];
      setText('d' + k, r[0]); setText('r' + k, r[1]);
      $('d' + k).hidden = $('r' + k).hidden = !r[0];
    }
  }
  function kms(v) { return f(v * K.KMS, 1) + ' km/s'; }

  function readEllipse() {
    var g = K.geom(state.a, state.e), st = K.at(state.a, state.e, state.M), sh = state.show;
    setText('rName', state.preset ? PRESETS[state.preset].name : 'e = ' + f(state.e, 3));
    setText('rKind', state.e === 0 ? '正圆' : state.e < 0.1 ? '近似正圆的椭圆' : '椭圆');
    setText('rTip', sh.string ? '行星到两个焦点的距离之和 r₁ + r₂ 始终等于 2a——这正是椭圆的定义，太阳在其中一个焦点上。'
      : state.e < 0.1 ? '偏心率很小时椭圆几乎是正圆，太阳几乎在圆心——所以中学常把行星轨道近似成圆。'
      : '所有行星绕太阳运动的轨道都是椭圆，太阳处在椭圆的一个焦点上（第一定律）。');
    rows([
      ['半轴', 'a = ' + sig(g.a, 3) + ' AU，b = √(a² − c²) = ' + sig(g.b, 3) + ' AU'],
      ['焦距', 'c = ' + sig(g.c, 3) + ' AU，偏心率 e = c/a = ' + f(state.e, 3)],
      ['近日点', 'a − c = ' + sig(g.rp, 3) + ' AU'],
      ['远日点', 'a + c = ' + sig(g.ra, 3) + ' AU'],
      ['此刻', 'r = ' + sig(st.r, 3) + ' AU，周期 T = ' + K.dur(g.T)]
    ]);
  }

  function readArea() {
    var g = K.geom(state.a, state.e), st = K.at(state.a, state.e, state.M), n = state.n;
    setText('rName', 'Δt = T/' + n + ' = ' + K.dur(g.T / n));
    setText('rKind', st.r < state.a * (1 - 1e-9) ? '靠近近日点' : '靠近远日点');
    setText('rTip', state.e < 0.1 ? '偏心率很小，各段扇形几乎一样，速率变化很小。试试更扁的轨道。'
      : state.mode === 'pair' ? '近日点附近的扇形“短而宽”、远日点附近“长而窄”，面积相等：离太阳近时走得快。'
      : '每段都用同样的时间 Δt，面积都相等；近日点附近一段弧长，远日点附近一段弧短。');
    rows([
      ['此刻', 'r = ' + sig(st.r, 3) + ' AU，v = ' + kms(st.v)],
      ['近日点', 'v_p = ' + kms(g.vp) + '（最快）'],
      ['远日点', 'v_a = ' + kms(g.va) + '（最慢）'],
      ['速率比', 'v_p : v_a = r_a : r_p = ' + f(g.vp / g.va, 2) + ' : 1'],
      ['每段', '面积 πab/' + n + ' = ' + sig(g.area / n, 3) + ' AU²，弧长 ' + sig(K.arcLen(state.a, state.e, -TAU / n / 2, TAU / n / 2), 3) + ' / ' + sig(K.arcLen(state.a, state.e, Math.PI - TAU / n / 2, Math.PI + TAU / n / 2), 3) + ' AU']
    ]);
  }

  function readPeriod() {
    var s = sys(), k = K.kOf(s), au = s.aUnit, tu = s.tUnit;
    setText('rName', s.name + '的' + s.what);
    setText('rKind', 'k = ' + sig(k, 3) + ' ' + (au === 'AU' ? 'AU³/年²' : '(' + au + ')³/' + tu + '²'));
    setText('rTip', state.chart === 'log' ? '双对数坐标下是斜率为 3/2 的直线：lgT = (3/2)lga − (1/2)lgk。'
      : '所有环绕同一中心天体的 a³/T² 都相等，T²–a³ 图像是过原点的直线。');
    var list = [
      ['k（SI）', K.sci(K.kSI(s)) + ' m³/s²'],
      ['最内', s.bodies[0].name + '：a = ' + sig(s.bodies[0].a, 3) + ' ' + au + '，T = ' + sig(s.bodies[0].T, 3) + ' ' + tu],
      ['最外', s.bodies[s.bodies.length - 1].name + '：a = ' + sig(s.bodies[s.bodies.length - 1].a, 3) + ' ' + au + '，T = ' + sig(s.bodies[s.bodies.length - 1].T, 3) + ' ' + tu]
    ];
    if (state.custom) {
      var a = state.ca[state.sys], T = K.periodK(a, k);
      list.push(['自定义', 'a = ' + sig(a, 3) + ' ' + au + ' → T = √(a³/k) = ' + sig(T, 3) + ' ' + tu]);
      if (state.sys === 'earth') list.push(['同步', 'T = 1 天（恒星日 0.9973 天）时 a = ' + sig(Math.cbrt(k * 0.9973 * 0.9973), 3) + ' 万 km']);
    }
    rows(list);
  }

  function readQuiz() {
    var q = state.quiz, sc = state.score;
    setText('rName', !state.answered ? '判断练习' : state.correct ? '✓ 答对了' : '✗ 答错了');
    $('rName').className = !state.answered ? '' : state.correct ? 'ok' : 'bad';
    setText('rKind', '得分 ' + sc.ok + ' / ' + sc.n);
    setText('rTip', state.answered ? q.explain : q.prompt);
    rows([]);
  }

  // ---------- 尺寸与主循环 ----------
  function resize() { view.resize(stage.clientWidth, stage.clientHeight); }
  new ResizeObserver(resize).observe(stage);

  // 支持 ?scene=ellipse|area|period|quiz；轨道 &preset=circle|earth|mars|mercury|pluto|halley 或 &a=（AU）&e=、&m=（平近点角°，暂停在该处）、&speed=0.5|1|2；
  // 第一定律 &show=axes,string,apsides；第二定律 &n=6|8|12|16、&mode=pair|all、&vel=0；第三定律 &sys=sun|jupiter|earth、&zoom=inner|all、&chart=lin|log、&ca=、&custom=0；练习 &q=speed|period|concept
  var qs = new URLSearchParams(location.search);
  function num(k, lo, hi) { var x = parseFloat(qs.get(k)); return isFinite(x) && x >= lo && x <= hi ? x : null; }
  var x;
  if (HINTS[qs.get('scene')]) state.scene = qs.get('scene');
  if (PRESETS[qs.get('preset')]) { state.a = PRESETS[qs.get('preset')].a; state.e = PRESETS[qs.get('preset')].e; state.preset = qs.get('preset'); }
  if ((x = num('a', K.A_RANGE[0], K.A_RANGE[1])) != null) { state.a = x; state.preset = null; }
  if ((x = num('e', K.E_RANGE[0], K.E_RANGE[1])) != null) { state.e = x; state.preset = null; }
  if ([0.5, 1, 2].indexOf(parseFloat(qs.get('speed'))) >= 0) state.speed = parseFloat(qs.get('speed'));
  if (qs.get('show') != null) {
    var want = qs.get('show').split(',');
    SHOWS.forEach(function (k) { state.show[k] = want.indexOf(k) >= 0; });
  }
  if ([6, 8, 12, 16].indexOf(parseInt(qs.get('n'), 10)) >= 0) state.n = parseInt(qs.get('n'), 10);
  if (qs.get('mode') === 'pair' || qs.get('mode') === 'all') state.mode = qs.get('mode');
  if (qs.get('vel') === '0') state.vel = false;
  if (K.SYSTEMS[qs.get('sys')]) state.sys = qs.get('sys');
  if (qs.get('zoom') === 'inner' || qs.get('zoom') === 'all') state.zoom = qs.get('zoom');
  if (qs.get('chart') === 'lin' || qs.get('chart') === 'log') state.chart = qs.get('chart');
  var cr = K.SYSTEMS[state.sys].custom;
  if ((x = num('ca', cr[0], cr[1])) != null) state.ca[state.sys] = x;
  if (qs.get('custom') === '0') state.custom = false;
  if (K.TYPES.indexOf(qs.get('q')) >= 0) state.quizOnly = qs.get('q');

  resize();
  buildTable();
  setScene(state.scene);
  if ((x = num('m', 0, 360)) != null) { state.M = x * K.DEG; state.paused = true; syncUI(); }

  var lastT = performance.now();
  function frame(now) {
    var dt = Math.min((now - lastT) / 1000, 0.1);
    lastT = now;
    var sc = state.scene, s = sys();
    if (!state.paused && !drag) {
      if (sc === 'ellipse' || sc === 'area') state.M = (state.M + TAU * dt / ORBIT_S * state.speed) % TAU;
      // 第三定律：可见范围内最外面的天体约 30 s 绕一周
      if (sc === 'period') state.t += dt * state.rate * s.bodies[(state.zoom === 'inner' ? s.inner : s.bodies.length) - 1].T / 30;
    }
    sliders.forEach(function (sl) { if (document.activeElement !== sl.el) sl.el.value = sl.get(); });
    setText('aOut', sig(state.a, 3) + ' AU');
    setText('eOut', f(state.e, 3));
    setText('caOut', sig(state.ca[state.sys], 3) + ' ' + s.aUnit);

    if (sc === 'ellipse' || sc === 'area') {
      view.drawOrbit({ scene: sc, a: state.a, e: state.e, M: state.M, n: state.n, mode: state.mode,
        show: sc === 'ellipse' ? state.show : { apsides: true, vel: state.vel } });
      if (sc === 'ellipse') readEllipse(); else readArea();
    } else if (sc === 'period') {
      view.drawPeriod({ sys: s, t: state.t, zoom: state.zoom, chart: state.chart, custom: state.custom ? state.ca[state.sys] : null });
      readPeriod();
    } else {
      view.drawQuiz(state.quiz, state.answered, { quizH: $('quizBar').offsetHeight });
      readQuiz();
    }
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  // 调试用
  window.__model = {
    state: state, setScene: setScene, newQuiz: newQuiz, syncUI: syncUI,
    setOrbit: setOrbit,
    setM: function (deg) { state.M = deg * K.DEG; state.paused = true; syncUI(); },
    setSys: function (k) { if (K.SYSTEMS[k]) { state.sys = k; state.t = 0; buildTable(); syncUI(); } }
  };
})();
